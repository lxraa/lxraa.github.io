﻿local GMPageStyle = require("UI.UIGMPanel.Configs.GMPageStyle")
local GMPageConfig = require("UI.UIGMPanel.Configs.GMPageConfig")
local config = GMPageConfig.New("SeasonDebug")
config.style = GMPageStyle.PageTemplate.Vertical
config.order = 2000
config.label = "\232\181\155\229\173\163"
config.icon = "Assets/Main/Sprites/UI/GMPanel/gmIconSeason.png"
config:Add({
  name = "\230\152\190\231\164\186\230\178\153\233\177\188\232\161\140\229\134\155\231\186\191",
  icon = "Assets/Main/Sprites/HeroIconsBig/mjc_S3_touxiang_jushachong.png",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  get = function()
    return GMUtils.GetBool(GMConst.DebugSandFishTroopLineEnable, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.DebugSandFishTroopLineEnable, val)
    UIUtil.ShowTips(val and "\230\178\153\233\177\188\232\161\140\229\134\155\231\186\191\229\188\128\229\144\175" or "\230\178\153\233\177\188\232\161\140\229\134\155\231\186\191\229\133\179\233\151\173")
  end
})
config:Add({
  name = "\230\137\147\229\188\128\230\140\135\229\174\154\232\129\148\231\155\159\231\155\184\229\134\140",
  icon = "Assets/Main/Sprites/ItemIcons/icon_kelongxinpian_1.png",
  style = GMPageStyle.ItemTemplate.InputRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("[\230\137\147\229\188\128\232\181\155\229\173\163\231\155\184\229\134\140]")
    sb:AppendLine("\194\183\232\190\147\229\133\165\232\181\155\229\173\163id\229\146\140\232\129\148\231\155\159id\229\143\175\228\187\165\230\159\165\231\156\139\230\137\128\229\156\168\229\185\179\229\143\176\229\133\168\230\156\141\231\154\132\228\187\187\230\132\143\231\155\184\229\134\140")
    sb:AppendLine("\194\183\232\190\147\229\133\165\230\160\188\229\188\143\239\188\154\232\181\155\229\173\163\229\186\143\229\143\183(1,2,3,4,5...);\232\129\148\231\155\159\229\148\175\228\184\128id(\228\184\128\229\160\134\229\173\151\231\172\166\228\184\178)")
    sb:AppendLine("\194\183\229\166\130\239\188\1543;a4ffb117903a4875bdb2d7687b1d34bc")
    sb:AppendLine("\194\183\229\166\130\228\189\149\229\143\141\229\164\141\230\137\147\229\188\128\231\155\184\229\134\140\239\188\154\231\130\185\229\135\187\232\190\147\229\133\165\230\161\134\239\188\140\229\134\141\231\130\185\229\135\187\229\133\182\228\187\150\229\156\176\230\150\185\229\143\150\230\182\136\232\190\147\229\133\165\230\161\134\233\128\137\228\184\173\228\184\186\228\184\128\230\172\161\231\161\174\232\174\164\230\147\141\228\189\156")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return DataCenter.SeasonPhotoManager.GMParam or "3;a4ffb117903a4875bdb2d7687b1d34bc"
  end,
  set = function(val)
    DataCenter.SeasonPhotoManager.GMParam = val
    if string.IsNullOrEmpty(val) then
      return
    end
    local params = string.split(val, ";")
    local season = params[1] and tonumber(params[1])
    local allianceId = params[2]
    if season and allianceId then
      UIManager:GetInstance():DestroyWindow(UIWindowNames.UIGMPanel)
      UIManager:GetInstance():OpenWindow(UIWindowNames.SeasonPhotoCanvaShare, {anim = true}, season, allianceId)
    else
      UIUtil.ShowTips("\231\155\184\229\134\140\232\190\147\229\133\165\230\160\188\229\188\143\233\148\153\232\175\175\239\188\140\232\175\183\230\159\165\231\156\139\229\184\174\229\138\169\230\143\144\231\164\186")
    end
  end,
  contentType = 0
})
config:Add({
  name = "\232\129\148\231\155\159\231\155\184\229\134\140\230\152\190\231\164\186\231\189\145\230\160\188\230\140\137\233\146\174",
  icon = "Assets/Main/Sprites/ItemIcons/icon_kelongxinpian_2.png",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("[\232\181\155\229\173\163\231\155\184\229\134\140\231\189\145\230\160\188\230\140\137\233\146\174]")
    sb:AppendLine("\229\139\190\233\128\137\229\144\142\239\188\140\232\181\155\229\173\163\231\155\184\229\134\140\229\143\179\228\184\139\232\167\146\230\152\190\231\164\186\231\189\145\230\160\188\230\140\137\233\146\174\239\188\140\231\130\185\229\135\187\229\143\175\228\187\165\230\152\190\231\164\186\231\172\155\229\141\161\229\176\148\229\157\144\230\160\135\229\146\140\231\189\145\230\160\188\230\150\185\228\190\191\232\175\134\229\136\171\229\157\144\230\160\135\228\189\141\231\189\174")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return Setting:GetPrivateBool("GM_PHOTO_SHOW_GRID_BTN", false)
  end,
  set = function(val)
    Setting:SetPrivateBool("GM_PHOTO_SHOW_GRID_BTN", val)
    UIUtil.ShowTips(val and "\230\152\190\231\164\186\231\155\184\229\134\140\231\189\145\230\160\188\230\140\137\233\146\174" or "\233\154\144\232\151\143\231\155\184\229\134\140\231\189\145\230\160\188\230\140\137\233\146\174")
  end
})
local delayTimer
config:Add({
  name = "S1\229\164\169\230\176\148\233\154\143\230\156\186\229\136\135\230\141\162\229\129\135\230\149\176\230\141\174",
  icon = "Assets/Main/Sprites/UI/UISeason/UISeason1/Weather/mjc_S1YH_tianqi_icon_yu.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  onClicked = function()
    local GetSeasonWeatherInfoMessage = require("Net.Msgs.Season.GetSeasonWeatherInfoMessage")
    local t = GetSeasonWeatherInfoMessage:GetTestData()
    local weatherId = t.curWeather.weatherId
    local info = weatherId and DataCenter.SeasonWeatherManager:GetWeatherTypeInfo(weatherId)
    if info then
      UIUtil.ShowTips(string.format("5\231\167\146\229\144\142\229\136\135\230\141\162\229\136\176\229\164\169\230\176\148\239\188\154%s", CS.GameEntry.Localization:GetString(info.name)))
      if delayTimer ~= nil then
        delayTimer:Stop()
      end
      delayTimer = TimerManager:GetInstance():DelayInvoke(function()
        if GetSeasonWeatherInfoMessage then
          GetSeasonWeatherInfoMessage:HandleMessage(t)
        end
      end, 5)
    end
  end,
  btnName = "\229\136\135\230\141\162\229\164\169\230\176\148"
})
config:Add({
  name = "S1\229\164\169\230\176\148\231\166\129\231\148\168",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  icon = "Assets/Main/Sprites/UI/UISeason/UISeason1/Weather/zxl_s1_tianqi_yu.png",
  get = function()
    return GMUtils.GetBool(GMConst.DisableSeasonWeather)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.DisableSeasonWeather, val)
    DataCenter.GMManager:DisableSeasonWeather(val)
  end
})
config:Add({
  name = "\228\191\132\231\189\151\230\150\175\230\150\185\229\157\151\229\176\143\230\184\184\230\136\143\228\187\187\230\132\143\230\148\190\231\189\174\239\188\129",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  icon = "Assets/Main/Sprites/ItemIcons/ljq_s1_xqsj_zhuan01.png",
  get = function()
    return GMUtils.GetBool(GMConst.TetrisDisablePlaceCheck)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.TetrisDisablePlaceCheck, val)
  end
})
config:Add({
  name = "\230\137\147\229\188\128\230\159\165\232\175\162\230\156\141\229\138\161\229\153\168world\233\152\187\230\140\161",
  icon = "Assets/Main/Sprites/HeroIconsBig/mjc_S3_touxiang_jushachong.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  onClicked = function()
    local gmWindow = UIManager:GetInstance():GetWindow(UIWindowNames.UIGMBar)
    if gmWindow then
      gmWindow.View:StartDebugWorldBlockInfo()
    end
    UIUtil.ShowTips("\230\137\147\229\188\128")
    UIManager:GetInstance():DestroyWindow(UIWindowNames.UIGMPanel)
  end,
  btnName = "\229\188\128\229\167\139\229\143\145\233\128\129\230\181\139\232\175\149\230\182\136\230\129\175"
})
return config
