﻿local InterfaceConfig = {}
InterfaceConfig.Describable = {
  "Description"
}
InterfaceConfig.BattlefieldManager = {
  "GetCfgValue",
  "GetActInfo",
  "UpdateMapBR",
  "GetBuildData",
  "GetCurGroup",
  "FillBuildBtnList",
  "CheckBattleStart",
  "BuildOpenCheck",
  "HandleBuildingHpChange",
  "CanMultiAssistance",
  "GetClosestPos",
  "GetWorldCamp",
  "GetBuildUpEffInfo",
  "GetBuildBestMarch",
  "GetAttackInfo",
  "CanShowEnter",
  "GetBattleStartTimeSec",
  "ReqBattleEffect"
}
InterfaceConfig.BattlefieldTreatment = {
  "SendDragonHospitalViewMsg",
  "SendDragonHospitalFinishMsg",
  "GetTreatmentSpeed",
  "GetAccumulativeTreatmentSoldierNum",
  "GetTreatmentFinishSoldierNum",
  "GetTreatmentSoldierDataList"
}
InterfaceConfig.BattlefieldTemplateMgr = {
  "GetBuildTemplate",
  "GetALLTime",
  "GetBuffTemplate"
}
InterfaceConfig.BattlefieldEnterCheck = {
  "CheckCanEnterBattlefield"
}
return InterfaceConfig
