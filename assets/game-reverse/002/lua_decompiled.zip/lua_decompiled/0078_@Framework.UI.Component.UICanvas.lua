﻿local UICanvas = BaseClass("UICanvas", UIBaseComponent)
local base = UIBaseComponent
local UnityCanvas = typeof(CS.UnityEngine.Canvas)
local OnCreate = function(self)
  base.OnCreate(self)
  self.unity_canvas = self.gameObject:GetComponent(UnityCanvas)
end
local OnDestroy = function(self)
  self.unity_canvas = nil
  base.OnDestroy(self)
end
local SetOverrideSorting = function(self, value)
  self.unity_canvas.overrideSorting = value
end
local SetSortingOrder = function(self, value)
  self.unity_canvas.sortingOrder = value
end
local SetSortingLayerName = function(self, value)
  self.unity_canvas.sortingLayerName = value
end
UICanvas.OnCreate = OnCreate
UICanvas.OnDestroy = OnDestroy
UICanvas.SetOverrideSorting = SetOverrideSorting
UICanvas.SetSortingOrder = SetSortingOrder
UICanvas.SetSortingLayerName = SetSortingLayerName
return UICanvas
