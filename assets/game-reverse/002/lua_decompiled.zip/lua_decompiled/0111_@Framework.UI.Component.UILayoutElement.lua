﻿local UILayoutElement = BaseClass("UILayoutElement", UIBaseContainer)
local base = UIBaseContainer
local UnityLayoutElement = typeof(CS.UnityEngine.UI.LayoutElement)
local OnCreate = function(self, ...)
  base.OnCreate(self)
  self.unity_LayoutElement = self.gameObject:GetComponent(UnityLayoutElement)
end
local OnDestroy = function(self)
  self.unity_LayoutElement = nil
  base.OnDestroy(self)
end
local GetUnityHandler = function(self)
  return self.unity_LayoutElement
end
local SetPreferredHeight = function(self, value)
  self.unity_LayoutElement.preferredHeight = value
end
local SetPreferredWidth = function(self, value)
  self.unity_LayoutElement.preferredWidth = value
end
local SetMinHeight = function(self, value)
  self.unity_LayoutElement.minHeight = value
end
local SetMinWidth = function(self, value)
  self.unity_LayoutElement.minWidth = value
end
local GetMinWidth = function(self)
  return self.unity_LayoutElement.minWidth
end
local GetMinHeight = function(self)
  return self.unity_LayoutElement.minHeight
end
local SetEnable = function(self, enable)
  if self.unity_LayoutElement then
    self.unity_LayoutElement.enabled = enable
  end
end

function UILayoutElement:SetIgnoreLayout(ignoreLayout)
  if self.unity_LayoutElement then
    self.unity_LayoutElement.ignoreLayout = ignoreLayout
  end
end

UILayoutElement.OnCreate = OnCreate
UILayoutElement.OnDestroy = OnDestroy
UILayoutElement.SetPreferredHeight = SetPreferredHeight
UILayoutElement.SetPreferredWidth = SetPreferredWidth
UILayoutElement.SetMinHeight = SetMinHeight
UILayoutElement.SetMinWidth = SetMinWidth
UILayoutElement.GetMinWidth = GetMinWidth
UILayoutElement.GetMinHeight = GetMinHeight
UILayoutElement.GetUnityHandler = GetUnityHandler
UILayoutElement.SetEnable = SetEnable
return UILayoutElement
