﻿local UISimpleAnimation = BaseClass("UISimpleAnimation", UIBaseContainer)
local base = UIBaseContainer
local SimpleAnimation = typeof(CS.SimpleAnimation)
local OnCreate = function(self, ...)
  base.OnCreate(self)
  self.simpleAnimation = self.gameObject:GetComponent(SimpleAnimation)
end
local OnDestroy = function(self)
  self.simpleAnimation = nil
  base.OnDestroy(self)
end
local Play = function(self, name)
  self.simpleAnimation:Play(name)
end
local PlayQueued = function(self, name)
  self.simpleAnimation:PlayQueued(name)
end
local Rewind = function(self, name)
  self.simpleAnimation:Rewind(name)
end
local Enable = function(self, value)
  self.simpleAnimation.enabled = value
end
local PlayAnimationReturnTime = function(self, animName)
  local anim = self.simpleAnimation:GetState(animName)
  if anim == nil then
    return false
  end
  self.simpleAnimation:Play(animName)
  return true, self.simpleAnimation:GetClipLength(animName)
end
local GetAnimationReturnTime = function(self, animName)
  local anim = self.simpleAnimation:GetState(animName)
  if anim == nil then
    return false
  end
  return true, self.simpleAnimation:GetClipLength(animName)
end
local IsPlaying = function(self, animName)
  local anim = self.simpleAnimation:GetState(animName)
  if anim == nil then
    return false
  end
  return self.simpleAnimation:IsPlaying(animName)
end
local Stop = function(self)
  self.simpleAnimation:Stop()
end
local SampleAnimationAtTime = function(self, animName, time)
  local anim = self.simpleAnimation:GetState(animName)
  if anim == nil then
    return false
  end
  return self.simpleAnimation:SampleAnimationAtTime(animName, time)
end
local SetStateSpeed = function(self, animName, speed)
  self.simpleAnimation:SetStateSpeed(animName, speed)
end
UISimpleAnimation.OnCreate = OnCreate
UISimpleAnimation.OnDestroy = OnDestroy
UISimpleAnimation.Play = Play
UISimpleAnimation.PlayQueued = PlayQueued
UISimpleAnimation.Rewind = Rewind
UISimpleAnimation.Enable = Enable
UISimpleAnimation.PlayAnimationReturnTime = PlayAnimationReturnTime
UISimpleAnimation.GetAnimationReturnTime = GetAnimationReturnTime
UISimpleAnimation.IsPlaying = IsPlaying
UISimpleAnimation.Stop = Stop
UISimpleAnimation.SampleAnimationAtTime = SampleAnimationAtTime
UISimpleAnimation.SetStateSpeed = SetStateSpeed
return UISimpleAnimation
