﻿local SeasonWorldSkinUtil = {tryGotoServer = 0}

function SeasonWorldSkinUtil.GetSkin(skinId, skinCfg)
  if CS.SceneSkinMeta == nil then
    return nil
  end
  if not LocalController:instance():hasTable(TableName.World_Skin) then
    return nil
  end
  if skinId then
    local line = skinCfg or LocalController:instance():getLine(TableName.World_Skin, toInt(skinId))
    if line and line.id then
      local meta = CS.SceneSkinMeta()
      meta.id = line.id
      meta.mapType = line.season_type or SeasonMapType.Nothing
      meta.loading_bg = line.loading_bg
      meta.loading_logo = line.logo
      meta.world_deco_byte = line.world_deco_byte
      meta.world_deco_asset = line.world_deco_asset
      meta.world_block = line.world_block
      meta.world_terrain = line.world_terrain
      meta.world_terrain_low = line.world_terrain_low
      meta.world_terrain_control = line.world_terrain_control
      meta.world_terrain_black = line.world_terrain_black
      meta.world_map = line.world_map
      meta.world_city_color = "worldcity_color"
      meta.splash_fill_mode = 1
      meta.world_zone_line = line.world_zone_line
      meta.city_deco = line.city_deco
      meta.city_terrain = line.city_terrain
      meta.city_fog = line.city_fog
      meta.radar_bg = line.radar_bg
      meta.world_city_table_name = "lw_worldcity"
      meta.world_terrain_mode = line.world_terrain_mode
      meta.world_terrain_mode_mat = line.world_terrain_mode_mat
      meta.troop_line_color = line.troopline_color or ""
      meta.camera_scaling = tonumber(line.camera_scaling) or 1
      meta.seasonType = line.season_type or SeasonMapType.Nothing
      meta.world_fog = line.world_fog
      meta.world_fog_bloody = line.world_fog_bloody
      meta.edge_performance = line.edge_performance
      meta.light_monster = line.light_monster
      meta.loading_bgm = line.loading_bgm
      meta.home_bgm = line.home_bgm
      meta.world_bgm = line.world_bgm
      meta.city_sound = line.city_sound
      meta.world_sound = line.world_sound
      meta.edge_world_fog = line.edge_world_fog
      return meta
    end
  end
  return nil
end

function SeasonWorldSkinUtil.DoChangeWorldSkin(seasonInfo)
  if seasonInfo ~= nil then
    DataCenter.BirthPointTemplateManager:InitAllBirthPoint(seasonInfo.serverId)
    seasonInfo:ActiveViewModeSkin()
  end
end

function SeasonWorldSkinUtil.ChangeWorldSkin(toServerId)
  local nServerId = toInt(toServerId)
  if nServerId <= 0 then
    return
  end
  DataCenter.AllianceCityTipManager:RemoveAllAllianceCityTip()
  DataCenter.SurpriseBuildingTipManager:RemoveAllSurpriseBuildingTip()
  if 9000 <= nServerId then
    SeasonWorldSkinUtil.tryGotoServer = 0
    return
  end
  local seasonInfo = SeasonUtil.GetSeasonInfo(nServerId)
  if seasonInfo ~= nil then
    DataCenter.BirthPointTemplateManager:InitAllBirthPoint(nServerId)
  end
  if seasonInfo == nil or seasonInfo:GetServerType(false) ~= SeasonMapType.Nothing then
    SFSNetwork.SendMessage(MsgDefines.GetStrongholdBattleState, nServerId)
    DataCenter.WorldAllianceCityDataManager:CleanStrongholdBattleState(nServerId)
  end
  if seasonInfo == nil or seasonInfo:GetServerType(false) == SeasonMapType.Darkness then
    DataCenter.BloodyNightDataManager:AddBloodyData(nServerId)
  end
  local thePresident = DataCenter.GovernmentManager:GetCurPresident(nServerId)
  if thePresident == nil then
    DataCenter.GovernmentManager:GetKingInfoByServerId(nServerId)
  end
  if seasonInfo == nil then
    SeasonWorldSkinUtil.tryGotoServer = nServerId
    SFSNetwork.SendMessage(MsgDefines.GetSpecialServerSeasonInfo, nServerId)
  else
    SeasonWorldSkinUtil.tryGotoServer = 0
    SeasonWorldSkinUtil.DoChangeWorldSkin(seasonInfo)
  end
end

function SeasonWorldSkinUtil.GetTryGotoServer()
  return SeasonWorldSkinUtil.tryGotoServer
end

function SeasonWorldSkinUtil.SetTryGotoServer(serverId)
  SeasonWorldSkinUtil.tryGotoServer = serverId
end

return ConstClass("SeasonWorldSkinUtil", SeasonWorldSkinUtil)
