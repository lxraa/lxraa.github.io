﻿local UITextMeshProUGUI = BaseClass("UITextMeshProUGUI", UIBaseComponent)
local base = UIBaseComponent
local UnityTextMeshPro = typeof(CS.TMPro.TextMeshProUGUI)
local OnCreate = function(self, cs_comp)
  base.OnCreate(self)
  if not cs_comp then
    self.unity_tmpro = self.gameObject:GetComponent(UnityTextMeshPro)
  else
    self.unity_tmpro = cs_comp
  end
end
local GetText = function(self)
  return self.unity_tmpro.text
end
local SetText = function(self, text)
  self.unity_tmpro:Native_SetText(text)
end
local OnDestroy = function(self)
  self.unity_tmpro = nil
  base.OnDestroy(self)
end
local SetColor = function(self, value)
  self.unity_tmpro.color = value
end
local GetColor = function(self)
  return self.unity_tmpro.color
end
local GetWidth = function(self)
  return self.unity_tmpro.preferredWidth
end
local GetHeight = function(self)
  return self.unity_tmpro.preferredHeight
end
local GetLinkInfo = function(self)
  return self.unity_tmpro.textInfo.linkInfo
end
UITextMeshProUGUI.OnCreate = OnCreate
UITextMeshProUGUI.GetText = GetText
UITextMeshProUGUI.SetText = SetText
UITextMeshProUGUI.OnDestroy = OnDestroy
UITextMeshProUGUI.SetColor = SetColor
UITextMeshProUGUI.GetWidth = GetWidth
UITextMeshProUGUI.GetHeight = GetHeight
UITextMeshProUGUI.GetColor = GetColor
UITextMeshProUGUI.GetLinkInfo = GetLinkInfo
return UITextMeshProUGUI
