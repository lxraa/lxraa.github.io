﻿local UIGridLayoutGroup = BaseClass("UIGridLayoutGroup", UIBaseContainer)
local base = UIBaseContainer
local UnityGridLayoutGroup = typeof(CS.UnityEngine.UI.GridLayoutGroup)
local OnCreate = function(self)
  base.OnCreate(self)
  self.unity_layout = self.gameObject:GetComponent(UnityGridLayoutGroup)
end
local OnDestroy = function(self)
  self.unity_layout = nil
  base.OnDestroy(self)
end
local SetConstraintCount = function(self, value)
  if not self.unity_layout then
    return
  end
  self.unity_layout.constraintCount = value
end
local GetCellSize = function(self)
  if not self.unity_layout then
    return
  end
  return self.unity_layout.cellSize
end
local GetCellSpacing = function(self)
  if not self.unity_layout then
    return
  end
  return self.unity_layout.spacing
end
local SetCellSpacing = function(self, x, y)
  if not self.unity_layout then
    return
  end
  self.unity_layout.spacing = Vector2.New(x or 0, y or 0)
end
local GetCellPadding = function(self)
  if not self.unity_layout then
    return
  end
  return self.unity_layout.padding
end
local SetCellSize = function(self, x, y)
  if not self.unity_layout then
    return
  end
  self.unity_layout.cellSize = Vector2.New(x or 0, y or 0)
end

function UIGridLayoutGroup:SetEnable(enable)
  if self.unity_layout == nil then
    return
  end
  self.unity_layout.enabled = enable
end

UIGridLayoutGroup.OnCreate = OnCreate
UIGridLayoutGroup.OnDestroy = OnDestroy
UIGridLayoutGroup.SetConstraintCount = SetConstraintCount
UIGridLayoutGroup.GetCellSize = GetCellSize
UIGridLayoutGroup.GetCellSpacing = GetCellSpacing
UIGridLayoutGroup.SetCellSpacing = SetCellSpacing
UIGridLayoutGroup.GetCellPadding = GetCellPadding
UIGridLayoutGroup.SetCellSize = SetCellSize
return UIGridLayoutGroup
