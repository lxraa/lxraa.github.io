﻿local base = UIBaseContainer
local UIGhostreconPlayerItem = BaseClass("UIGhostreconPlayerItem", base)
local joinIcon_path = "joinIcon"
local headHolder_path = "headIcon"
local joinBtn_path = "joinBtn"
local selfFlag_path = "selfFlag"
local playerHead_path = "headIcon/UIPlayerHead"
local OnCreate = function(self)
  base.OnCreate(self)
  self:ComponentDefine()
  self:DataDefine()
end
local OnDestroy = function(self)
  self:DataDestroy()
  self:ComponentDestroy()
  base.OnDestroy(self)
end
local OnEnable = function(self)
  base.OnEnable(self)
end
local OnDisable = function(self)
  base.OnDisable(self)
end
local ComponentDefine = function(self)
  self.joinIcon = self:AddComponent(UIBaseContainer, joinIcon_path)
  self.headHolder = self:AddComponent(UIBaseContainer, headHolder_path)
  self.joinBtn = self:AddComponent(UIButton, joinBtn_path)
  self.selfFlag = self:AddComponent(UIBaseContainer, selfFlag_path)
  self.playerHead = self:AddComponent(UICommonHead, playerHead_path)
  self.playerHead:SetEnableClickShowInfo(true, true)
  self.joinBtn:SetOnClick(function()
    if self.headHolder:GetActive() then
      self.playerHead:OnHeadClick()
    elseif self.joinFunc then
      self.joinFunc()
    end
  end)
  self.selfFlag:SetActive(false)
end
local ComponentDestroy = function(self)
  self.joinIcon = nil
  self.headHolder = nil
  self.joinBtn = nil
  self.selfFlag = nil
end
local DataDefine = function(self)
end
local DataDestroy = function(self)
  self.joinFunc = nil
  self.headInfo = nil
end
local SetData = function(self, headInfo)
  if headInfo then
    self.headInfo = headInfo
    self.headHolder:SetActive(true)
    self.playerHead:ParseHeadInfo(headInfo)
  else
    self.headHolder:SetActive(false)
  end
end
local SetJoinFunc = function(self, joinFunc)
  self.joinFunc = joinFunc
end
local SetJoinActive = function(self, active)
  self.joinIcon:SetActive(active)
end
local SetEmpty = function(self)
  self.joinIcon:SetActive(false)
  self.headHolder:SetActive(false)
end
local RefreshHead = function(self)
  if self.headInfo then
    self.playerHead:ParseHeadInfo(self.headInfo)
  end
end
UIGhostreconPlayerItem.OnCreate = OnCreate
UIGhostreconPlayerItem.OnDestroy = OnDestroy
UIGhostreconPlayerItem.OnEnable = OnEnable
UIGhostreconPlayerItem.OnDisable = OnDisable
UIGhostreconPlayerItem.ComponentDefine = ComponentDefine
UIGhostreconPlayerItem.ComponentDestroy = ComponentDestroy
UIGhostreconPlayerItem.DataDefine = DataDefine
UIGhostreconPlayerItem.DataDestroy = DataDestroy
UIGhostreconPlayerItem.SetData = SetData
UIGhostreconPlayerItem.SetJoinActive = SetJoinActive
UIGhostreconPlayerItem.SetEmpty = SetEmpty
UIGhostreconPlayerItem.SetJoinFunc = SetJoinFunc
UIGhostreconPlayerItem.RefreshHead = RefreshHead
return UIGhostreconPlayerItem
