﻿local UIPlayerHead = BaseClass("UIPlayerHead", UIBaseComponent)
local base = UIBaseComponent
local OnCreate = function(self)
  base.OnCreate(self)
  self.unityHead = self.gameObject:GetComponent(typeof(CS.UIPlayerHead))
end
local OnDestroy = function(self)
  if self.unityHead ~= nil then
    self.unityHead:SetCustomLoadCallback(nil)
  end
  self.unityHead = nil
  base.OnDestroy(self)
end

function UIPlayerHead:ParseHeadInfo(cfg)
  if cfg then
    self:SetData(cfg.uid or cfg.ownerUid or cfg.Uid or cfg.tUid, cfg.pic or cfg.headPic or cfg.tPic or "", cfg.picVer or cfg.headPicVer or cfg.picver or cfg.tPicVer or 0)
  end
end

local SetData = function(self, uid, pic, picVer, useBig)
  if useBig == nil then
    useBig = false
  end
  if not string.IsNullOrEmpty(uid) then
    if not (pic or picVer) or picVer == 0 and pic == "" then
      self.unityHead:UseSystemHead()
    else
      self.unityHead:SetData(uid, pic, tonumber(picVer), useBig)
    end
  end
end
local SetBigData = function(self, uid, pic, picVer, useBig)
  if useBig == nil then
    useBig = false
  end
  if not string.IsNullOrEmpty(uid) then
    if not pic and not picVer then
      self.unityHead:UseSystemHead()
    else
      self.unityHead:SetBigData(uid, pic, tonumber(picVer), useBig)
    end
  end
end
local UseSystemHead = function(self)
  self.unityHead:UseSystemHead()
end
local UseSpecifiedRes = function(self, imgPath)
  if imgPath then
    self.unityHead:UseSpecifiedRes(imgPath)
  end
end
local SetCustomLoadCallback = function(self, callback)
  self.unityHead:SetCustomLoadCallback(callback)
end
local ShowWerewolf = function(self)
  self.unityHead:UseSpecifiedRes(WerewolfHeadPic)
end
UIPlayerHead.OnCreate = OnCreate
UIPlayerHead.OnDestroy = OnDestroy
UIPlayerHead.SetData = SetData
UIPlayerHead.SetCustomLoadCallback = SetCustomLoadCallback
UIPlayerHead.SetBigData = SetBigData
UIPlayerHead.UseSystemHead = UseSystemHead
UIPlayerHead.UseSpecifiedRes = UseSpecifiedRes
UIPlayerHead.ShowWerewolf = ShowWerewolf
return UIPlayerHead
