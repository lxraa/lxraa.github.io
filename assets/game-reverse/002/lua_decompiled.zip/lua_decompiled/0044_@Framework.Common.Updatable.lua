﻿local Updatable = BaseClass("Updatable")
local AddUpdate = function(self)
  if self.Update ~= nil then
    function self.__update_handle()
      self:Update()
    end
    
    UpdateManager:GetInstance():AddUpdate(self.__update_handle)
  end
end
local RemoveUpdate = function(self)
  if self.__update_handle ~= nil then
    UpdateManager:GetInstance():RemoveUpdate(self.__update_handle)
    self.__update_handle = nil
  end
end
local __init = function(self)
  self:EnableUpdate(true)
end
local __delete = function(self)
  self:EnableUpdate(false)
end
local EnableUpdate = function(self, enable)
  RemoveUpdate(self)
  if enable then
    AddUpdate(self)
  end
end
Updatable.__init = __init
Updatable.__delete = __delete
Updatable.EnableUpdate = EnableUpdate
return Updatable
