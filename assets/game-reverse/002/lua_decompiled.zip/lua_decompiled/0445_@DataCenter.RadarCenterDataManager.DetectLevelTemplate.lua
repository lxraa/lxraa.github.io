﻿local DetectLevelTemplate = BaseClass("DetectLevelTemplate")
local Localization = CS.GameEntry.Localization
local __init = function(self)
  self.id = ""
end
local __delete = function(self)
  self.id = nil
end
local InitData = function(self, row)
  if row == nil then
    return
  end
  self.id = tonumber(row:getValue("id"))
end
DetectLevelTemplate.__init = __init
DetectLevelTemplate.__delete = __delete
DetectLevelTemplate.InitData = InitData
return DetectLevelTemplate
