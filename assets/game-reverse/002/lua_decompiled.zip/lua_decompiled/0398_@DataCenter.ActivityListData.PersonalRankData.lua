﻿local PersonalRankData = BaseClass("PersonalRankData")
local __init = function(self)
  self.uid = ""
  self.name = ""
  self.pic = ""
  self.picVer = -1
  self.abbr = ""
  self.score = 0
  self.rank = 0
end
local __delete = function(self)
  self.uid = nil
  self.name = nil
  self.pic = nil
  self.picVer = nil
  self.abbr = nil
  self.score = nil
  self.rank = nil
end
local ParseData = function(self, message)
  if message == nil then
    return
  end
  if message.uid ~= nil then
    self.uid = message.uid
  end
  if message.name ~= nil then
    self.name = message.name
  end
  if message.pic ~= nil then
    self.pic = message.pic
  end
  if message.picVer ~= nil then
    self.picVer = message.picVer
  end
  if message.abbr ~= nil then
    self.abbr = message.abbr
  end
  if message.score ~= nil then
    self.score = message.score
  end
  if message.r ~= nil then
    self.rank = message.r
  end
  if message.rank ~= nil then
    self.rank = message.rank
  end
end
PersonalRankData.__init = __init
PersonalRankData.__delete = __delete
PersonalRankData.ParseData = ParseData
return PersonalRankData
