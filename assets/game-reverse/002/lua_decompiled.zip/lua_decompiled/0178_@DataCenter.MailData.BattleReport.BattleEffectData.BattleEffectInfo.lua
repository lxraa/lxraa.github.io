﻿local BattleEffectInfo = BaseClass("BattleEffectInfo")
local BattleEffectReason = require("DataCenter.MailData.BattleReport.BattleEffectData.BattleEffectReason")

function BattleEffectInfo:InitData(battleEffectInfo)
  self.effectId = battleEffectInfo.effectId
  self.value = battleEffectInfo.value
  self.reasonList = {}
  for k, v in pairs(battleEffectInfo.reasons) do
    local oneData = BattleEffectReason.New()
    oneData:InitData(v)
    if oneData.reason ~= nil and oneData.reason >= 0 then
      self.reasonList[oneData.reason] = oneData.value
    end
  end
end

function BattleEffectInfo:GetValue()
  if self.value ~= nil then
    return self.value
  end
  return 0
end

function BattleEffectInfo:GetReasonList()
  return self.reasonList
end

return BattleEffectInfo
