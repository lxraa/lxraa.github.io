﻿RestrictType = {BLOCK = 1, BAN = 2}
