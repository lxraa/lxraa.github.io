﻿local AllFightLost = BaseClass("AllFightLost")

function AllFightLost:InitData(allFightLost)
  self.uuid = 0
  self.resLostArr = {}
  self.resItemLostArr = {}
  local lostData = allFightLost.lost
  if lostData ~= nil then
    self.uuid = allFightLost.uuid
    local lostArr = lostData.resLostArr
    for _, itemInfo in pairs(lostArr) do
      self.resLostArr[itemInfo.type] = itemInfo.value
    end
    local resItemsLostArr = lostData.resItemLostArr or {}
    for _, itemInfo in pairs(resItemsLostArr) do
      self.resItemLostArr[tonumber(itemInfo.itemId)] = itemInfo.value
    end
  end
end

function AllFightLost:GetResLostList()
  return self.resLostArr
end

function AllFightLost:GetResItemLostArr()
  return self.resItemLostArr
end

return AllFightLost
