﻿local UIHeroCellSmall = BaseClass("UIHeroCellSmall", UIBaseContainer)
local base = UIBaseContainer
local UIHeroStars = require("UI.UIHero2.Common.UIHeroStars")
local LWHeroRankStar = require("UI.UIHero2.Common.LWHeroRankStar")
local GameObject = CS.UnityEngine.GameObject
local Type_CS_Image = typeof(CS.UnityEngine.UI.Image)
local Type_CS_RectTransform = typeof(CS.UnityEngine.RectTransform)
local btn_go_path = ""
local img_quality_path = "imgQuality"
local img_camp_path = "imgCamp"
local img_level_bg_path = "LVBg"
local text_level_path = "textLevel"
local img_rank_path = "ImgRank"
local img_type_path = "ImgType"
local img_Job_path = "ImgJob"
local img_mask_path = "Mask"
local img_selected_path = "SelectedMark"
local text_name_path = "textName"
local OnCreate = function(self)
  base.OnCreate(self)
  self:ComponentDefine()
  self:DataDefine()
end
local OnDestroy = function(self)
  self:ComponentDestroy()
  self:DataDestroy()
  base.OnDestroy(self)
end
local OnEnable = function(self)
  base.OnEnable(self)
end
local OnDisable = function(self)
  base.OnDisable(self)
end
local ComponentDefine = function(self)
  self.img_quality = self:AddComponent(UIImage, img_quality_path)
  self.img_icon = self:AddComponent(UIImage, "imgIcon")
  self.level_bg = self:AddComponent(UIImage, img_level_bg_path)
  self.text_level = self:AddComponent(UIText, text_level_path)
  self.text_level.transform:Set_localScale(ResetScale.x, ResetScale.y, ResetScale.z)
  self.img_rank = self:AddComponent(UIImage, img_rank_path)
  self.img_type = self:AddComponent(UIImage, img_type_path)
  self.img_job = self:AddComponent(UIImage, img_Job_path)
  self.mask = self:AddComponent(UIImage, img_mask_path)
  self.selected_mark = self:AddComponent(UIImage, img_selected_path)
  self.text_name = self:AddComponent(UIText, text_name_path)
  self.btn_go = self:AddComponent(UIButton, btn_go_path)
  self.btn_go:SetOnClick(function()
    CS.GameEntry.Sound:PlayEffect(SoundAssets.Music_Effect_Button)
    self:OnBtnClick()
  end)
  self.heroRankStar = self:AddComponent(LWHeroRankStar, "HeroRankStar")
  self.empty = self:AddComponent(UIBaseComponent, "imgEmpty")
end
local ComponentDestroy = function(self)
  self.img_icon = nil
  self.img_camp = nil
  self.level_bg = nil
  self.text_level = nil
  self.img_rank = nil
  self.img_type = nil
  self.img_job = nil
  self.mask = nil
  self.selected_mark = nil
  self.text_name = nil
  self.btn_go = nil
  if self.img_dominatorRank then
    local go = self.img_dominatorRank.gameObject
    if not IsNull(go) then
      go.name = "Deleted"
      self:RemoveComponent(self.img_dominatorRank:GetName(), UIImage)
      CS.UnityEngine.GameObject.Destroy(go)
    else
      Logger.LogError("img_dominatorRank gameObject is null")
    end
    self.img_dominatorRank = nil
  end
end
local DataDefine = function(self)
  self.heroUuid = 0
  self.callBack = nil
end
local DataDestroy = function(self)
  self.heroUuid = nil
  self.callBack = nil
end
local GetSelected = function(self)
  if self.selected == nil then
    self.selected = false
  end
  return self.selected
end
local SetMask = function(self, stat)
  self.mask:SetActive(stat)
end
local SetSelected = function(self, state)
  local oldState = self.selected
  self.selected = state
  self.selected_mark:SetActive(state)
  if not oldState and state then
    SetMask(self, true)
  elseif oldState and not state then
    SetMask(self, false)
  end
end
local Reinit = function(self, param)
  self:SetData(param.heroUuid)
end
local SetData = function(self, heroUuid, callBack, showGrade, showZeroStar, iconType)
  if heroUuid == nil then
    self.empty:SetActive(true)
    return
  else
    self.empty:SetActive(false)
  end
  self.heroUuid = heroUuid
  self.callBack = callBack
  self.showZeroStar = showZeroStar
  local heroData = DataCenter.BattleLevel:GetPveHeroData(heroUuid)
  assert(heroData ~= nil, "heroData is nil! heroUuid:" .. tostring(heroUuid))
  self:SetHeroData(heroData)
  if self.img_dominatorRank then
    self.img_dominatorRank:SetEnable(false)
  end
end
local SetHeroData = function(self, heroData, iconType)
  local quality = heroData.quality
  self.quality = quality
  self.heroId = heroData.heroId
  self.isWaken = heroData.IsWakeUp ~= nil and heroData:IsWakeUp() or false
  local iconPath = HeroUtils.GetHeroIconPath(heroData.modelId, iconType)
  self.img_icon:LoadSprite(iconPath)
  self.img_type:SetEnable(true)
  self.img_job:SetEnable(true)
  self.img_type:LoadSprite(HeroUtils.GetHeroTypeIcon(heroData.heroType, heroData:IsUniqueWeaponOpen() and heroData:HasUniqueWeapon()))
  self.img_job:LoadSprite(HeroUtils.GetHeroJobIcon(heroData.meta.job, 2))
  self.text_name:SetText(heroData:GetName())
  self.text_level:SetText("Lv." .. tostring(heroData.level))
  self:SetQuality(quality, false)
  self:SetRank(heroData:GetRank(), heroData.meta.maxRank)
  SetSelected(self, false)
  SetMask(self, false)
  if self.img_dominatorRank then
    self.img_dominatorRank:SetEnable(false)
  end
end
local SetHeroStationSkill = function(self, skillId)
end
local CheckInStation = function(self, stationId)
end
local InitWithConfigId = function(self, heroConfigId, quality, level, rankId, weaponLv)
  if heroConfigId == nil then
    self.empty:SetActive(true)
    return
  else
    self.empty:SetActive(false)
  end
  local heroConfig = DataCenter.HeroTemplateManager:GetTemplate(heroConfigId)
  if heroConfig == nil then
    return
  end
  if heroConfig.heroData_type == HeroTemplateType.Dominator then
    self:SetDominatorConfig(heroConfigId, rankId)
    return
  end
  if quality == nil then
    quality = heroConfig.quality
  end
  local modelId = heroConfig.appearance
  local _weaponLevel = weaponLv or 0
  if _weaponLevel ~= nil and 0 < _weaponLevel then
    local weaponInfo = DataCenter.HeroUniqueWeaponTemplateManager:GetTemplateByHeroId(heroConfigId, _weaponLevel)
    if weaponInfo ~= nil then
      modelId = weaponInfo.modelId
    end
  end
  local iconPath = HeroUtils.GetHeroIconPath(modelId)
  self.img_icon:LoadSprite(iconPath)
  self.text_name:SetLocalText(heroConfig.name)
  self.quality = heroConfig.rarity
  self.heroId = heroConfig.id
  self:SetQuality(quality, false)
  self.level_bg:LoadSprite(HeroUtils.GetLevelBg(quality))
  self.text_level:SetText(level ~= nil and "Lv." .. tostring(level) or "")
  self.img_type:SetEnable(true)
  self.img_job:SetEnable(true)
  self.img_job:LoadSprite(HeroUtils.GetHeroJobIcon(heroConfig.job, 2))
  local isShowUniqueWeapon = heroConfig:IsUnqueWeaponShow()
  local hasWeapon = _weaponLevel ~= nil and 0 < _weaponLevel
  self.img_type:LoadSprite(HeroUtils.GetHeroTypeIcon(heroConfig.type, isShowUniqueWeapon and hasWeapon))
  self:SetRank(rankId, heroConfig.maxRank)
  SetSelected(self, false)
  SetMask(self, false)
  if self.img_dominatorRank then
    self.img_dominatorRank:SetEnable(false)
  end
end
local SetQuality = function(self, quality, isPoster, isWaken)
  self.img_quality:SetActive(not isPoster)
  self.img_icon:SetActive(not isPoster)
  self.level_bg:SetActive(not isPoster)
  self:ToggleLevel(not isPoster)
  if isPoster then
    self:ToggleLevel(false)
  else
    local icon = HeroUtils.GetQualityIconPath(quality, false)
    self.img_quality:LoadSprite(icon)
    self.level_bg:LoadSprite(HeroUtils.GetLevelBg(quality))
  end
end
local InitWithConfigIdByPoster = function(self, heroConfigId, quality, level)
  if heroConfigId == nil then
    self.empty:SetActive(true)
    return
  else
    self.empty:SetActive(false)
  end
  local heroConfig = LocalController:instance():getLine(HeroUtils.GetHeroXmlName(), heroConfigId)
  if quality == nil then
    quality = heroConfig.init_quality_level
  end
  self.text_name:SetLocalText(heroConfig.name)
  self.rarity = heroConfig.rarity
  self.heroId = heroConfig.id
  self:SetQuality(quality, true)
  self.level_bg:SetActive(level ~= nil)
  SetSelected(self, false)
  SetMask(self, false)
  if self.img_dominatorRank then
    self.img_dominatorRank:SetEnable(false)
  end
end
local SetRank = function(self, rank, maxRank)
  if rank == nil or rank == 0 then
    self.heroRankStar:SetActive(false)
    return
  end
  self.heroRankStar:SetActive(true)
  self.heroRankStar:ShowRank(rank, maxRank)
end
local SetDisplayLevel = function(self, level)
  self.text_level:SetText("Lv." .. level)
end
local OnBtnClick = function(self)
  if self.callBack ~= nil then
    self.callBack(self.transform, self.heroUuid)
  end
end
local SetLvTextBiggest = function(self)
  self.text_level.transform:Set_localScale(1.3, 1.3, 1.3)
end
local ToggleRayCast = function(self, t)
  local empty4Raycast = self.btn_go.transform:GetComponent(typeof(CS.UnityEngine.UI.Empty4Raycast))
  if empty4Raycast ~= nil then
    empty4Raycast.raycastTarget = t
  end
end
local ToggleRank = function(self, t)
  self.img_rank:SetActive(t)
end
local ToggleLevel = function(self, t)
  self.level_bg:SetActive(t)
  self.text_level:SetActive(t)
end

function UIHeroCellSmall:ToggleJob(t)
  self.img_job:SetEnable(t)
end

local SetStarActive = function(self, active)
end
local SetCampActive = function(self, active)
  if self.img_camp ~= nil then
    self.img_camp:SetActive(active)
  end
end
local GetLastStarPos = function(self)
  return Vector3.New(0, 0, 0)
end
local ShowUpgradeStarEffect = function(self)
end
local ShowStarProgress = function(self)
end
local SetAllImageGrey = function(self, showGrey, click)
  CS.UIGray.SetGray(self.transform, showGrey, click)
end

function UIHeroCellSmall:SetDominatorConfig(id, rank, showRank)
  local appearanceId = DataCenter.DominatorTemplateManager:GetAppearanceId(id, rank)
  local iconPath = HeroUtils.GetHeroIconPath(appearanceId)
  self.img_icon:LoadSprite(iconPath)
  self.img_quality:LoadSprite(LoadPath.DominatorIconBg)
  self:ToggleLevel(false)
  self:ToggleRank(false)
  self.img_type:SetEnable(false)
  self.img_job:SetEnable(false)
  self:SetRank(0)
  if showRank == nil then
    showRank = true
  end
  local rank = rank or 0
  if rank < 0 or not showRank then
    if self.img_dominatorRank then
      self.img_dominatorRank:SetEnable(false)
    end
    return
  end
  if self.img_dominatorRank == nil then
    local go = GameObject("img_dominatorRank")
    go:AddComponent(Type_CS_Image)
    local rectTransform = go:GetComponent(Type_CS_RectTransform)
    rectTransform:SetParent(self.img_icon.transform)
    rectTransform:SetAsLastSibling()
    self.img_dominatorRank = self:AddComponent(UIImage, "imgIcon/img_dominatorRank")
    self.img_dominatorRank:SetLocalScaleXYZ(1, 1, 1)
    self.img_dominatorRank:SetPivotXY(0, 1)
    self.img_dominatorRank:SetAnchorMinXY(0, 1)
    self.img_dominatorRank:SetAnchorMaxXY(0, 1)
    self.img_dominatorRank:SetAnchoredPositionXY(-13.2, 11.5)
    self.img_dominatorRank:SetSizeDeltaXY(60, 60)
  end
  local rankShowTemplate = DataCenter.DominatorTemplateManager:GetRankShowTemplateByIdAndRank(id, rank)
  if rankShowTemplate == nil then
    self.img_dominatorRank:SetEnable(false)
    return
  end
  self.img_dominatorRank:SetEnable(true)
  self.img_dominatorRank:LoadSprite(rankShowTemplate:GetRankIconPathSmall())
end

function UIHeroCellSmall:SetImgIcon(imgPath)
  if self.img_icon then
    self.img_icon:LoadSprite(imgPath)
  end
end

UIHeroCellSmall.OnCreate = OnCreate
UIHeroCellSmall.OnDestroy = OnDestroy
UIHeroCellSmall.OnEnable = OnEnable
UIHeroCellSmall.OnDisable = OnDisable
UIHeroCellSmall.ComponentDefine = ComponentDefine
UIHeroCellSmall.ComponentDestroy = ComponentDestroy
UIHeroCellSmall.DataDefine = DataDefine
UIHeroCellSmall.DataDestroy = DataDestroy
UIHeroCellSmall.GetLastStarPos = GetLastStarPos
UIHeroCellSmall.ShowUpgradeStarEffect = ShowUpgradeStarEffect
UIHeroCellSmall.Reinit = Reinit
UIHeroCellSmall.SetData = SetData
UIHeroCellSmall.SetHeroData = SetHeroData
UIHeroCellSmall.ToggleRayCast = ToggleRayCast
UIHeroCellSmall.SetHeroStationSkill = SetHeroStationSkill
UIHeroCellSmall.CheckInStation = CheckInStation
UIHeroCellSmall.InitWithConfigId = InitWithConfigId
UIHeroCellSmall.InitWithConfigIdByPoster = InitWithConfigIdByPoster
UIHeroCellSmall.SetQuality = SetQuality
UIHeroCellSmall.SetRank = SetRank
UIHeroCellSmall.SetDisplayLevel = SetDisplayLevel
UIHeroCellSmall.OnBtnClick = OnBtnClick
UIHeroCellSmall.SetLvTextBiggest = SetLvTextBiggest
UIHeroCellSmall.ToggleLevel = ToggleLevel
UIHeroCellSmall.ToggleRank = ToggleRank
UIHeroCellSmall.SetStarActive = SetStarActive
UIHeroCellSmall.SetCampActive = SetCampActive
UIHeroCellSmall.ShowStarProgress = ShowStarProgress
UIHeroCellSmall.SetMask = SetMask
UIHeroCellSmall.SetSelected = SetSelected
UIHeroCellSmall.GetSelected = GetSelected
UIHeroCellSmall.SetAllImageGrey = SetAllImageGrey
return UIHeroCellSmall
