﻿local GMPageStyle = require("UI.UIGMPanel.Configs.GMPageStyle")
local GMPageConfig = require("UI.UIGMPanel.Configs.GMPageConfig")
local Localization = CS.GameEntry.Localization
local reloadGame = function(showServerList)
  if showServerList then
    CS.UnityEngine.PlayerPrefs.SetInt("RELOAD_DEBUG_SHOW_SERVER_LIST", 1)
  end
  CS.ApplicationLaunch.Instance:ReloadGame()
end
local reconnectGame = function()
  CS.GameEntry.Network:SyncPingPong(0)
  CS.GameEntry.Network:Disconnect()
  CS.ApplicationLaunch.Instance:DisconnectRetry()
end
local config = GMPageConfig.New("GameDaddy")
config.style = GMPageStyle.PageTemplate.Vertical
config.order = 5000
config.label = "\230\184\184\230\136\143\229\184\184\231\148\168"
config.icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_zhbd_google_icon.png"
local _getBaseInfo = function()
  local sb = StringBuilder.New()
  sb:AppendFormatLine("[\232\174\190\229\164\135ID]\n%s", CS.GameEntry.Device:GetDeviceUid())
  local uid = LuaEntry.Player:GetUid()
  if string.IsNullOrEmpty(uid) then
    return sb:ToString()
  end
  sb:AppendLine()
  sb:AppendFormatLine([[
[UID]
%s]], uid)
  sb:AppendLine()
  sb:AppendFormatLine([[
[Name]
%s]], LuaEntry.Player:GetName())
  sb:AppendLine()
  sb:AppendFormatLine("[\229\142\159\230\156\141]\n%s", LuaEntry.Player:GetSourceServerId())
  sb:AppendLine()
  sb:AppendFormatLine("[\231\153\187\229\189\149\230\156\141]\n%s", LuaEntry.Player:GetSelfServerId())
  local allianceId = LuaEntry.Player:GetAllianceUid()
  if not string.IsNullOrEmpty(allianceId) then
    sb:AppendLine()
    sb:AppendFormatLine("[\232\129\148\231\155\159ID]\n%s", allianceId)
    sb:AppendLine()
    sb:AppendFormatLine("[\232\129\148\231\155\159\229\144\141\231\167\176]\n%s", LuaEntry.Player:GetFullAllianceName())
  end
  return sb:ToString()
end
config:Add({
  name = "\230\159\165\231\156\139\229\159\186\231\161\128\228\191\161\230\129\175",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/cfm_common_anniu_jilu.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = function()
    local str = _getBaseInfo()
    UIUtil.ShowDetail(str, nil, nil, true, true)
  end,
  onClicked = function()
    UIUtil.ShowTips("\229\183\178\229\164\141\229\136\182\229\136\176\229\137\170\232\180\180\230\157\191")
    CommonUtil.CopyTextToClipboard(_getBaseInfo())
  end,
  btnName = "\229\164\141\229\136\182"
})
config:Add({
  name = "\233\135\141\229\144\175\230\184\184\230\136\143",
  icon = "Assets/Main/Sprites/ItemIcons/mjc_icon_yiminjuan.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    GMUtils.Close()
    UIUtil.ShowMessage("\228\189\160\231\161\174\229\174\154\232\166\129\231\170\129\231\160\180\228\186\186\231\177\187\233\129\147\229\190\183\229\186\149\231\186\191\239\188\140\229\188\186\229\136\182\233\135\141\229\144\175\230\184\184\230\136\143\228\185\136\239\188\159", 2, "\231\170\129\231\160\180!", "\228\191\157\229\174\136\231\130\185", function()
      UIUtil.ShowTips("\229\145\181\229\145\181\239\188\140\231\156\159\230\184\163!")
      TimerManager:GetInstance():DelayInvoke(function()
        reloadGame(true)
      end, 0.5)
    end, function()
      UIUtil.ShowTips("\229\145\181\229\145\181\239\188\140\233\135\141\232\189\189\232\135\170\229\138\168\231\153\187\229\189\149\229\142\187\228\186\134!")
      TimerManager:GetInstance():DelayInvoke(function()
        reloadGame(false)
      end, 0.5)
    end, nil)
  end,
  btnName = "\232\181\176\228\189\160"
})
config:Add({
  name = "\230\150\173\231\186\191\233\135\141\232\191\158",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/Common_wifi_bg.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    GMUtils.Close()
    reconnectGame()
  end,
  btnName = "\"kale\""
})
config:Add({
  name = "\229\136\135\230\141\162\232\175\173\232\168\128",
  icon = "Assets/Main/Sprites/UI/UILWPlayerInfo/settting_icon_language.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    UIManager:GetInstance():OpenWindow(UIWindowNames.UISettingLanguage, {anim = true, hideTop = true})
    GMUtils.Close()
  end,
  btnName = "\230\137\147\229\188\128"
})
config:Add({
  name = "\230\152\190\231\164\186\229\164\154\232\175\173\232\168\128key",
  icon = "Assets/Main/Sprites/UI/UILWPlayerInfo/settting_icon_language.png",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("\229\139\190\233\128\137\229\144\142\230\152\190\231\164\186\229\164\154\232\175\173\232\168\128\231\154\132\229\156\176\230\150\185\229\176\134\230\152\190\231\164\186key")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return Localization.ShowKey
  end,
  set = function(val)
    Localization.ShowKey = val
  end
})
config:Add({
  name = "\230\137\139\229\138\168\230\137\147\229\188\128\230\142\167\229\136\182\229\143\176",
  icon = "Assets/Main/Sprites/ItemIcons/item_uav_equip_1308.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    DataCenter.LWDevConsoleManager:OpenWindow()
    GMUtils.Close()
  end,
  btnName = "\230\137\147\229\188\128"
})
config:Add({
  name = "\230\152\190\231\164\186\229\144\132\231\167\141ID",
  icon = "Assets/Main/Sprites/ActivityIcons/lrb_chunjiehuodong_xianshidiaoluo_yeqian.png",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("\229\139\190\233\128\137\229\144\142\229\143\175\228\187\165\229\156\168\239\188\154")
    sb:AppendLine("\232\139\177\233\155\132\231\149\140\233\157\162\227\128\129\232\131\140\229\140\133\231\149\140\233\157\162\227\128\129\229\187\186\231\173\145\229\141\135\231\186\167\231\149\140\233\157\162\227\128\129\230\138\128\232\131\189\231\160\148\231\169\182\231\149\140\233\157\162")
    sb:AppendLine("\230\159\165\231\156\139\229\136\176\229\175\185\229\186\148\231\154\132ID")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return GMUtils.GetBool(GMConst.DebugDisplayGameID, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.DebugDisplayGameID, val)
  end
})
config:Add({
  name = "\229\147\170\233\135\140\228\184\141\228\188\154\231\130\185\229\147\170\233\135\140",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("\229\139\190\233\128\137\229\144\142\239\188\140\233\131\168\229\136\134\229\138\159\232\131\189\231\154\132\231\130\185\229\135\187\232\161\140\228\184\186\228\188\154\229\156\168Warning\233\162\145\233\129\147\230\137\147\229\141\176\232\176\131\232\175\149\228\191\161\230\129\175")
    sb:AppendLine("\231\155\174\229\137\141\229\183\178\230\148\175\230\140\129\239\188\154")
    sb:AppendLine("1\227\128\129\229\164\167\228\184\150\231\149\140\231\130\185\229\135\187\229\144\132\231\167\141\229\156\176\229\155\190\231\130\185")
    sb:AppendLine("2\227\128\129\229\164\167\228\184\150\231\149\140\231\130\185\229\135\187\229\144\132\231\167\141\232\161\140\229\134\155")
    sb:AppendLine("3\227\128\129\231\130\185\229\135\187UI\229\146\140collider\228\188\154\230\137\147\229\141\176gameObject.name")
    sb:AppendLine("\229\143\175\228\187\165\229\156\168Console\228\184\173\230\144\156\231\180\162\229\133\179\233\148\174\232\175\141ccc")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return GMUtils.GetBool(GMConst.DebugClickLogWarning, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.DebugClickLogWarning, val)
  end,
  icon = "Assets/Main/Sprites/UI/UIBuildBubble/mjc_zhujiemian_qipao_s2_dianhuo.png"
})
config:Add({
  name = "\230\137\147\229\141\176\230\156\141\229\138\161\229\153\168\230\182\136\230\129\175",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_liaotianyouhua_jianpan_icon.png",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("[\229\137\141\231\171\175\230\181\139\232\175\149\231\148\168]")
    sb:AppendLine("\230\191\128\230\180\187\229\144\142\229\176\134\229\156\168warning\233\162\145\233\129\147\230\137\147\229\141\176\229\137\141\231\171\175\230\148\182\227\128\129\229\143\145\231\154\132\229\141\143\232\174\174\232\175\166\230\131\133\239\188\129")
    sb:AppendLine("")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return GMUtils.GetBool(GMConst.DebugLogProtocolMsg, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.DebugLogProtocolMsg, val)
    UIUtil.ShowTips(val and "\230\137\147\229\141\176\230\156\141\229\138\161\229\153\168\230\182\136\230\129\175" or "\228\184\141\230\137\147\229\141\176\230\156\141\229\138\161\229\153\168\230\182\136\230\129\175")
  end
})
config:Add({
  name = "\230\137\147\229\141\176\229\174\140\230\149\180\229\143\145\233\128\129\230\182\136\230\129\175",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_wangzhuozhan_zontongguanli_icon6.png",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("[QA\231\148\168]")
    sb:AppendLine("\230\191\128\230\180\187\229\144\142\229\176\134\229\156\168log\233\162\145\233\129\147\230\137\147\229\141\176\229\174\140\230\149\180\231\154\132\229\143\145\233\128\129\230\182\136\230\129\175\239\188\129\229\133\179\233\148\174\232\175\141[Msg Send]")
    sb:AppendLine("")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return GMUtils.GetBool(GMConst.DebugSendMsg, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.DebugSendMsg, val)
    UIUtil.ShowTips(val and "\229\188\128\229\167\139\230\137\147\229\141\176\229\174\140\230\149\180\229\143\145\233\128\129\230\182\136\230\129\175" or "\229\129\156\230\173\162\230\137\147\229\141\176\229\174\140\230\149\180\229\143\145\233\128\129\230\182\136\230\129\175")
  end
})
config:Add({
  name = "\228\184\141\232\166\129\229\134\141\230\146\173\229\137\167\230\131\133\229\175\185\232\175\157\228\186\134",
  icon = "Assets/Main/Sprites/UI/UIActivity/cfm_huodong_gerenjunbei_baoxiang_qipao.png",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("[\229\137\141\231\171\175\230\181\139\232\175\149\231\148\168]")
    sb:AppendLine("\230\136\145\229\183\178\231\187\143\229\142\140\229\128\166\228\186\134\231\130\185\231\130\185\231\130\185\239\188\129")
    sb:AppendLine("")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return Setting:GetBool("DEBUG_JUMP_ALL_PLOT", false)
  end,
  set = function(val)
    Setting:SetBool("DEBUG_JUMP_ALL_PLOT", val)
    UIUtil.ShowTips(val and "\230\129\173\229\150\156\228\189\160\228\184\141\231\148\168\229\134\141\231\130\185\231\130\185\231\130\185\228\186\134\239\188\129" or "\230\131\179\231\130\185\228\189\160\229\176\177\231\130\185\229\144\167~")
  end
})
config:Add({
  name = "\232\131\189\229\191\171\231\130\185\228\185\136[0.5 ~ 5.0]",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/Common_icon_time.png",
  style = GMPageStyle.ItemTemplate.InputRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("\231\167\141\228\184\128\230\163\181\230\160\145\230\156\128\229\165\189\231\154\132\230\151\182\233\151\180\230\152\175\229\156\168\229\141\129\229\185\180\229\137\141\239\188\140")
    sb:AppendLine("\229\133\182\230\172\161\230\152\175\229\156\168\228\184\139\228\184\128\228\184\170\230\164\141\230\160\145\232\138\130\227\128\130")
    sb:AppendLine("\230\136\145\229\184\140\230\156\155\229\191\171\231\130\185\232\191\135\228\184\139\228\184\128\228\184\170\230\164\141\230\160\145\232\138\130\239\188\129")
    sb:AppendLine("\233\130\163\229\176\177\229\191\171\230\157\165\232\176\131\230\136\145\229\144\167~")
    sb:AppendLine("\232\176\131\232\138\130\232\140\131\229\155\180\239\188\154[0.5 ~ 5.0]")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return Time.timeScale
  end,
  set = function(val)
    Time.timeScale = val
    UIUtil.ShowTips(string.format("TimeScale\232\174\190\231\189\174\228\184\186:%s", Time.timeScale))
  end,
  min = 0.5,
  max = 5.0,
  contentType = 3
})
config:Add({
  name = "\230\136\170\229\155\190\229\185\182\228\184\148\228\191\157\229\173\152\229\136\176\231\155\184\229\134\140",
  icon = "Assets/Main/Sprites/ItemIcons/mjc_icon_yiminjuan.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    local nowTime = os.time()
    local fileName = string.format("ScreenShot%s.jpg", nowTime)
    local filePath = CS.UnityEngine.Application.persistentDataPath .. "/" .. fileName
    CS.UnityEngine.ScreenCapture.CaptureScreenshot(fileName)
    TimerManager:GetInstance():DelayInvoke(function()
      CS.SDKManager.SaveToAlbum(filePath, fileName)
    end, 0.5)
  end,
  btnName = "\230\136\170\229\155\190"
})
config:Add({
  name = "\230\159\165\231\156\139\229\136\134\229\140\133\228\191\161\230\129\175",
  icon = "Assets/Main/Sprites/ItemIcons/icon_building_103509000.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    local sb = StringBuilder.New()
    local requiredPackages = CS.ResourcePackageManager.GetRequiredPackagesDebug()
    if requiredPackages ~= nil and requiredPackages.Length > 0 then
      sb:AppendLine("\230\156\141\229\138\161\229\153\168\232\166\129\230\177\130\228\184\139\232\189\189\231\154\132\229\136\134\229\140\133ID:")
      local packageIds = {}
      for i = 0, requiredPackages.Length - 1 do
        table.insert(packageIds, requiredPackages[i])
      end
      sb:AppendLine(table.concat(packageIds, ", "))
      sb:AppendLine("\n\229\144\132\229\136\134\229\140\133\228\184\139\232\189\189\231\138\182\230\128\129:")
      for i = 0, requiredPackages.Length - 1 do
        local packageId = requiredPackages[i]
        local isDownloaded = CS.ResourcePackageManager.IsPackageDownloaded(packageId)
        sb:AppendLine(string.format("\229\136\134\229\140\133ID: %d, \229\183\178\228\184\139\232\189\189: %s", packageId, tostring(isDownloaded)))
      end
    else
      sb:AppendLine("\230\156\170\232\142\183\229\143\150\229\136\176\230\156\141\229\138\161\229\153\168\228\184\139\229\143\145\231\154\132\229\136\134\229\140\133\228\191\161\230\129\175")
    end
    local serverRequireData = sb:ToString()
    local param = {}
    param.title = "\229\136\134\229\140\133"
    param.activityRulesStr = serverRequireData
    UIManager:GetInstance():OpenWindow(UIWindowNames.UIActivityDetailPopup, {anim = true}, param)
  end,
  btnName = "\229\177\149\231\164\186"
})
config:Add({
  name = "\231\167\187\233\153\164\230\137\128\230\156\137 Settings\239\188\136PlayerPres\239\188\137",
  icon = "Assets/Main/Sprites/ItemIcons/wxy_icon_shangjinlieren_zidan.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    CS.GameEntry.Setting:RemoveAllSettings()
  end,
  btnName = "\230\139\156\230\139\156\228\186\134\230\130\168\228\187\172\229\134\133\239\188\129"
})
config:Add({
  name = "\231\167\187\233\153\164\230\140\135\229\174\154 Settings\239\188\136PlayerPres\239\188\137",
  icon = "Assets/Main/Sprites/ItemIcons/wxy_icon_shangjinlieren_zidan.png",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  tips = nil,
  get = function()
    return ""
  end,
  set = function(val)
  end,
  onClicked = function(val)
    if not string.IsNullOrEmpty(val) then
      CS.GameEntry.Setting:RemoveSetting(val)
    end
  end,
  btnName = "\230\139\156\230\139\156\228\186\134\230\130\168\229\134\133\239\188\129"
})
config:Add({
  name = "\231\167\187\233\153\164\230\140\135\229\174\154 Settings\239\188\136PlayerPres\239\188\137\229\184\166\228\184\138\232\135\170\229\183\177\231\154\132Uid",
  icon = "Assets/Main/Sprites/ItemIcons/wxy_icon_shangjinlieren_zidan.png",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  tips = nil,
  get = function()
    return ""
  end,
  set = function(val)
  end,
  onClicked = function(val)
    if not string.IsNullOrEmpty(val) then
      CS.GameEntry.Setting:RemoveSetting(LuaEntry.Player:GetUid() .. val)
      CS.GameEntry.Setting:RemoveSetting(val .. LuaEntry.Player:GetUid())
    end
  end,
  btnName = "\230\139\156\230\139\156\228\186\134\230\130\168\229\134\133\239\188\129"
})
config:Add()
return config
