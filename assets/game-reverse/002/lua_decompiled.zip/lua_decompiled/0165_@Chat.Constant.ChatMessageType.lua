﻿ChatMessageType = {
  COMMON = 0,
  SYSTEM = 1,
  FESTIVAL = 2
}
