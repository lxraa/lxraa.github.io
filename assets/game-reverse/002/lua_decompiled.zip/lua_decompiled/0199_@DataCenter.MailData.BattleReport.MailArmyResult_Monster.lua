﻿local Localization = CS.GameEntry.Localization
local MailArmyResultBase = require("DataCenter.MailData.BattleReport.MailArmyResultBase")
local MailArmyResult_Monster = BaseClass("MailArmyResult_Monster", MailArmyResultBase)

function MailArmyResult_Monster:InitData(armyResult)
  MailArmyResultBase.InitData(self, armyResult)
  local armyResultByType = self:GetArmyResultByType(armyResult)
  self._monsterId = armyResultByType.monsterId or 0
  local armyResultBase = armyResultByType.base
  self._pointId = armyResultBase.pointId
  local armyObj = armyResultBase.armyObj or {}
  self._armyObj = self:InitCombatUnitData(armyObj)
  local afterArmyObj = armyResultBase.afterArmyObj or {}
  self._afterArmyObj = self:InitCombatUnitData(afterArmyObj)
  self:CheckArmyObj()
  self:InitDestroyValue(armyResultBase)
  self:InitDamagePercentInfo(armyResultBase)
end

function MailArmyResult_Monster:GetName()
  local monsterId = self._monsterId
  if self._unitType == BattleType.Explore then
    local template = DataCenter.DetectEventTemplateManager:GetDetectEventTemplate(tostring(monsterId))
    if template ~= nil then
      return Localization:GetString(template.name, template.nameValue)
    end
  elseif self._unitType == BattleType.PUZZLE_BOSS then
    local name = GetTableData(LuaEntry.Player:GetABTestTableName(TableName.Monster), monsterId, "name")
    local strMonsterName = Localization:GetString(name)
    return strMonsterName
  else
    local level = GetTableData(LuaEntry.Player:GetABTestTableName(TableName.Monster), monsterId, "level")
    local name = GetTableData(LuaEntry.Player:GetABTestTableName(TableName.Monster), monsterId, "name")
    local strMonsterName = Localization:GetString(name)
    return Localization:GetString("310128", level, strMonsterName)
  end
end

function MailArmyResult_Monster:GetName_ForShare()
  local param = {type = "dialog"}
  local monsterId = self._monsterId
  if self._unitType == BattleType.Explore then
    local template = DataCenter.DetectEventTemplateManager:GetDetectEventTemplate(tostring(monsterId))
    if template ~= nil then
      local name = template.name
      local nameValue = template.nameValue
      param.name = name
      param.eventId = nameValue
    end
  elseif self._unitType == BattleType.PUZZLE_BOSS then
    local name = GetTableData(LuaEntry.Player:GetABTestTableName(TableName.Monster), monsterId, "name")
    param.name = name
  else
    local name = GetTableData(LuaEntry.Player:GetABTestTableName(TableName.Monster), monsterId, "name")
    param.level = GetTableData(LuaEntry.Player:GetABTestTableName(TableName.Monster), monsterId, "level")
    param.name = name
  end
  return param
end

function MailArmyResult_Monster:GetInfo()
  return {
    monsterId = self._monsterId
  }
end

function MailArmyResult_Monster:GetPointId()
  return self._pointId
end

return MailArmyResult_Monster
