﻿local GetHDRIntensity = BaseClass("GetHDRIntensity", UIBaseComponent)
local base = UIBaseComponent
local UnityOutline = typeof(CS.GetHDRIntensity)
local OnCreate = function(self)
  base.OnCreate(self)
  self.GetHDRIntensity = self.gameObject:GetComponent(UnityOutline)
end
local OnDestroy = function(self)
  self.GetHDRIntensity = nil
  base.OnDestroy(self)
end
local Init = function(self, mat)
  self.GetHDRIntensity:Init(mat)
end
GetHDRIntensity.OnCreate = OnCreate
GetHDRIntensity.OnDestroy = OnDestroy
GetHDRIntensity.Init = Init
return GetHDRIntensity
