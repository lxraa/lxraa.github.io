﻿local SFSBaseMessage = BaseClass("SFSBaseMessage")
local NewEmpty = function(msgType)
  return msgType.New(true)
end
local NewMessage = function(msgType, ...)
  return msgType.New(false, ...)
end
local __init = function(self, isEmpty, ...)
  if not isEmpty then
    self.sfsObj = SFSObject.New()
    self:OnCreate(...)
  end
end
local OnCreate = function(self)
end
local HandleMessage = function(self, t)
end
local OnDestroy = function(self)
end
local ToBinary = function(self)
  return self.sfsObj:ToBinary()
end
local __delete = function(self)
  self.sfsObj = nil
  self:OnDestroy()
end
SFSBaseMessage.__init = __init
SFSBaseMessage.NewEmpty = NewEmpty
SFSBaseMessage.NewMessage = NewMessage
SFSBaseMessage.OnCreate = OnCreate
SFSBaseMessage.HandleMessage = HandleMessage
SFSBaseMessage.ToBinary = ToBinary
SFSBaseMessage.OnDestroy = OnDestroy
SFSBaseMessage.__delete = __delete
return SFSBaseMessage
