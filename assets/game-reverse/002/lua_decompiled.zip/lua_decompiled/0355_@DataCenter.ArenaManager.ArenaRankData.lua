﻿local ArenaRankData = BaseClass("ArenaRankData")
local __init = function(self)
  self.type = 1
  self.name = ""
  self.uid = ""
  self.serverId = ""
  self.abbr = ""
  self.pic = ""
  self.picVer = ""
  self.headFrame = ""
  self.careerType = 0
  self.careerLv = 0
  self.power = 0
  self.triggerUid = ""
  self.addScore = 0
  self.armyId = 0
  self.rank = -1
  self.score = 0
  self.army = ""
  self.uuid = 0
end
local __delete = function(self)
  self.name = nil
  self.uid = nil
  self.serverId = nil
  self.abbr = nil
  self.pic = nil
  self.picVer = nil
  self.headFrame = nil
  self.careerType = nil
  self.careerLv = nil
  self.power = nil
  self.rank = nil
  self.score = nil
  self.army = nil
  self.uuid = nil
end
local ParseData = function(self, message)
  if message == nil then
    return
  end
  if message.type then
    self.type = message.type
  end
  if message.uuid then
    self.uuid = message.uuid
  end
  if message.army then
    self.army = PBController.ParsePb1(message.army, "protobuf.ArmyUnitInfo")
  end
  if message.armyId then
    self.armyId = message.armyId
  end
  if message.triggerUid then
    self.triggerUid = message.triggerUid
  end
  if message.result then
    self.addScore = message.result
  end
  if message.userObj then
    message = message.userObj
    if message.army then
      self.army = PBController.ParsePb1(message.army, "protobuf.ArmyUnitInfo")
    end
  end
  if message.name then
    self.name = message.name
  end
  if message.uid then
    self.uid = message.uid
  end
  if message.serverId then
    self.serverId = message.serverId
  end
  if message.abbr then
    self.abbr = message.abbr
  end
  if message.pic then
    self.pic = message.pic
  end
  if message.picver then
    self.picVer = message.picver
  end
  if message.headFrame then
    self.headFrame = message.headFrame
  end
  if message.careerType then
    self.careerType = message.careerType
  end
  if message.careerLevel then
    self.careerLv = message.careerLevel
  end
  if message.power then
    self.power = message.power
  elseif self.type == 0 then
    self.power = DataCenter.ArenaManager:GetRobotPower()
  end
  if message.rank then
    self.rank = message.rank
  end
  if message.score then
    self.score = message.score
  else
    local defaultScore = LuaEntry.DataConfig:TryGetNum("arena", "k1")
    self.score = defaultScore
  end
end
ArenaRankData.__init = __init
ArenaRankData.__delete = __delete
ArenaRankData.ParseData = ParseData
return ArenaRankData
