﻿local AllianceInviteMemberData = BaseClass("AllianceInviteMemberData")
local __init = function(self)
  self.level = 0
  self.pic = ""
  self.picVer = 0
  self.uid = ""
  self.name = ""
  self.invite = false
  self.power = 0
end
local __delete = function(self)
  self.level = nil
  self.pic = nil
  self.picVer = nil
  self.uid = nil
  self.name = nil
  self.invite = nil
  self.power = nil
end
local ParseData = function(self, message)
  if message == nil then
    return
  end
  if message.level ~= nil then
    self.level = message.level
  end
  if message.pic ~= nil then
    self.pic = message.pic
  end
  if message.picVer ~= nil then
    self.picVer = message.picVer
  end
  if message.uid ~= nil then
    self.uid = message.uid
  end
  if message.name ~= nil then
    self.name = message.name
  end
  if message.invite ~= nil then
    self.invite = message.invite
  end
  if message.power ~= nil then
    self.power = message.power
  end
end
AllianceInviteMemberData.__init = __init
AllianceInviteMemberData.__delete = __delete
AllianceInviteMemberData.ParseData = ParseData
return AllianceInviteMemberData
