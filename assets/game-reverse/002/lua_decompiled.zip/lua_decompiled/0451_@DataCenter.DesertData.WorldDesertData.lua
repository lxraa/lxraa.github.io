﻿local WorldDesertData = BaseClass("WorldDesertData")
local __init = function(self)
  self.uuid = 0
  self.desertId = 0
  self.pointId = 0
  self.allianceId = ""
  self.ownerUid = ""
  self.protectTime = 0
  self.giveUpTime = 0
  self.desert_type = 0
  self.resSpeed = 0
  self.level = 0
  self.desert_res_type_table = {}
  self.force = 0
  self.mineId = 0
  self.serverId = 0
end
local __delete = function(self)
  self.uuid = nil
  self.desertId = nil
  self.pointId = nil
  self.allianceId = nil
  self.ownerUid = nil
  self.protectTime = nil
  self.giveUpTime = nil
  self.desert_type = nil
  self.resSpeed = nil
  self.level = nil
  self.force = nil
  self.serverId = 0
end
local ParseData = function(self, message)
  if message == nil then
    return
  end
  if message.uuid ~= nil then
    self.uuid = message.uuid
  end
  if message.desId ~= nil then
    self.desertId = message.desId
  end
  if message.oriDesId ~= nil then
    self.oriDesertId = message.oriDesId
  end
  if message.pId ~= nil then
    self.pointId = message.pId
  end
  if message.uid ~= nil then
    self.ownerUid = message.uid
  end
  if message.aId ~= nil then
    self.allianceId = message.aId
  end
  if message.pTime ~= nil then
    self.protectTime = message.pTime
    self.protectEndTime = self.protectTime
  end
  if message.gUTime ~= nil then
    self.giveUpTime = message.gUTime
    self.giveUpEndTime = self.giveUpTime
  end
  if message.serverId ~= nil then
    self.serverId = message.serverId
  end
  if message.mineId ~= nil then
    self.mineId = message.mineId
  end
  self.desert_type = GetTableData(TableName.Desert, self.desertId, "desert_type")
  self.desert_res_type_table = {}
  if self.desertId ~= 0 then
    local resStr = GetTableData(TableName.Desert, self.desertId, "desert_res")
    local strArr = string.split(resStr, "|")
    if 0 < #strArr then
      for i = 1, #strArr do
        local arr = string.split(strArr[i], ";")
        if 2 <= #arr then
          local resType = tonumber(arr[1])
          local speed = tonumber(arr[2])
          if speed ~= nil then
            self.resSpeed = speed * 60
            self.desert_res_type_table[resType] = speed * 60
          end
        end
      end
    end
    self.level = GetTableData(TableName.Desert, self.desertId, "desert_level")
    self.force = GetTableData(TableName.Desert, self.desertId, "force")
  end
end
local SetOwnerUid = function(self, ownerUid)
  self.ownerUid = ownerUid
end
local SetGiveUpTime = function(self, giveUptime)
  self.giveUpTime = giveUptime
end
WorldDesertData.__init = __init
WorldDesertData.__delete = __delete
WorldDesertData.ParseData = ParseData
WorldDesertData.SetOwnerUid = SetOwnerUid
WorldDesertData.SetGiveUpTime = SetGiveUpTime
return WorldDesertData
