﻿local AllianceDonateRankData = BaseClass("AllianceDonateRankData")
local __init = function(self)
  self.name = ""
  self.uid = ""
  self.donation = 0
  self.alliance_honor = 0
  self.pic = ""
  self.picVer = 0
  self.rank = 0
end
local __delete = function(self)
  self.name = nil
  self.uid = nil
  self.donation = nil
  self.alliance_honor = nil
  self.pic = nil
  self.picVer = nil
end
local ParseData = function(self, message)
  if message == nil then
    return
  end
  if message.name ~= nil then
    self.name = message.name
  end
  if message.uid ~= nil then
    self.uid = message.uid
  end
  if message.donation ~= nil then
    self.donation = message.donation
  end
  if message.alliance_honor ~= nil then
    self.alliance_honor = message.alliance_honor
  end
  if message.pic ~= nil then
    self.pic = message.pic
  end
  if message.picVer ~= nil then
    self.picVer = message.picVer
  end
end
local SetRank = function(self, rank)
  self.rank = rank
end
AllianceDonateRankData.__init = __init
AllianceDonateRankData.__delete = __delete
AllianceDonateRankData.ParseData = ParseData
AllianceDonateRankData.SetRank = SetRank
return AllianceDonateRankData
