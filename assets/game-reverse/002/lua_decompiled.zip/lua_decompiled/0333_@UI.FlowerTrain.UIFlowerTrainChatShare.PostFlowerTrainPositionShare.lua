﻿local IChatItem = require("UI.UIChatNew.Component.ChatItem.IChatItem")
local PostFlowerTrainPositionShare = BaseClass("PostFlowerTrainPositionShare", IChatItem)
local base = IChatItem
local rapidjson = require("rapidjson")

function PostFlowerTrainPositionShare:OnCreate()
  base.OnCreate(self)
  self:ComponentDefine()
  self:AddUIListener(EventId.GetNewUserInfoSucc, self.RefreshUserInfo)
end

function PostFlowerTrainPositionShare:OnDestroy()
  self:RemoveUIListener(EventId.GetNewUserInfoSucc, self.RefreshUserInfo)
  self:ComponentDestroy()
  base.OnDestroy(self)
end

function PostFlowerTrainPositionShare:ComponentDefine()
  self.title = self:AddComponent(UITextMeshProUGUIEx, "title")
  self.qualityBg = self:AddComponent(UIRawImage, "qualityBg")
  self.name = self:AddComponent(UITextMeshProUGUIEx, "name")
  self.level = self:AddComponent(UITextMeshProUGUIEx, "level")
  self.power = self:AddComponent(UITextMeshProUGUIEx, "power")
  self.position = self:AddComponent(UITextMeshProUGUIEx, "position")
  self.head = self:AddComponent(UICommonHead, "DriverHead")
  self.btn = self:AddComponent(UIButton, "bg")
  self.btn:SetOnClick(function()
    self:OnClick()
  end)
  self.icon = self:AddComponent(UIRawImage, "RawImage")
end

function PostFlowerTrainPositionShare:ComponentDestroy()
  self.data = nil
  self.chatData = nil
end

function PostFlowerTrainPositionShare:UpdateItem(chatData)
  self._chatData = chatData
  self.seqId = chatData:getSeqId()
  self:RefreshView(chatData)
end

function PostFlowerTrainPositionShare:RefreshView(chatData)
  local data = rapidjson.decode(chatData.attachmentId) or {}
  self.data = data
  self.chatData = chatData
  self:RefreshUserInfo(data.uid)
  self:RefreshIcon()
  self.title:SetLocalText("2025halloween_chat_share_desc2")
  self.position:SetText(data.posStr)
end

function PostFlowerTrainPositionShare:RefreshIcon()
  local goodsId = self.data.goodsId
  if goodsId == nil then
    return
  end
  local lv = self.data.lv or 1
  local showData = FlowerTrainUtils.GetFlowerTrainDisplayMetaByGoodsId(goodsId, lv)
  if showData == nil then
    return
  end
  local iconPath = showData.pic3
  self.icon:LoadSprite(iconPath)
end

function PostFlowerTrainPositionShare:RefreshUserInfo(uid)
  if self.data == nil then
    return
  end
  if uid ~= self.data.uid then
    return
  end
  local user = UIUtil.GetPlayerInfoShowByUid(uid)
  if user == nil then
    return
  end
  local showName = DataCenter.PlayerInfoDataManager:GetRemarkOrRealName(user.uid, user.name)
  user.frameBg = user.headBg
  self.head:ParseHeadInfo(user)
  self.head:SetEnableClickShowInfo(true, true)
  self.name:SetText(UIUtil.FormatAllianceAndName(user.alAbbr, showName))
  self.level:SetText("Lv." .. (user.level or 0))
  self.power:SetText(string.GetFormattedSeparatorNum(user.power))
end

function PostFlowerTrainPositionShare:OnClick()
  if self.data.serverId then
    if not SceneUtils.CheckCanGotoWorld() then
      return
    end
    local marchUuid = self.data.marchUuid
    local worldId = self.data.worldId
    local serverId = self.data.serverId
    if marchUuid and type(marchUuid) == "number" and 0 < marchUuid then
      SFSNetwork.SendMessage(MsgDefines.GetMarchPos, serverId, worldId, marchUuid, NewMarchType.FLOWER_TRAIN)
    end
  end
end

return PostFlowerTrainPositionShare
