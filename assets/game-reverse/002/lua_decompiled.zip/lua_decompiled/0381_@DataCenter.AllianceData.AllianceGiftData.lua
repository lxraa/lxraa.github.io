﻿local AllianceGiftData = BaseClass("AllianceGiftData")
local __init = function(self)
  self.uuid = ""
  self.userName = ""
  self.groupId = ""
  self.name = ""
  self.createTime = 0
  self.expirationTime = 0
  self.reward = {}
  self.receiveState = 0
  self.receiveTime = 0
  self.rewardType = 1
  self.fromMsg = {}
  self.fromUid = ""
end
local __delete = function(self)
  self.uuid = nil
  self.userName = nil
  self.groupId = nil
  self.name = nil
  self.createTime = nil
  self.expirationTime = nil
  self.reward = nil
  self.receiveState = nil
  self.receiveTime = nil
  self.rewardType = nil
  self.fromMsg = nil
  self.fromUid = nil
end
local ParseData = function(self, message)
  if message == nil then
    return
  end
  if message.uuid ~= nil then
    self.uuid = message.uuid
  end
  if message.userName ~= nil then
    self.userName = message.userName
  end
  if message.groupId ~= nil then
    self.groupId = message.groupId
  end
  if message.createTime ~= nil then
    self.createTime = message.createTime
  end
  if message.expirationTime ~= nil then
    self.expirationTime = message.expirationTime
  end
  if message.name ~= nil then
    self.name = message.name
  end
  if message.receiveState ~= nil then
    self.receiveState = message.receiveState
  end
  if message.receiveTime then
    self.receiveTime = message.receiveTime
  end
  if message.type ~= nil then
    self.rewardType = message.type
  end
  if message.fromMsg ~= nil then
    self.fromMsg = message.fromMsg
  end
  if message.reward ~= nil then
    self.reward = message.reward
  end
  if message.keyExp ~= nil then
    self.keyExp = message.keyExp
  end
  if message.eachExp ~= nil then
    self.eachExp = message.eachExp
  end
  if message.fromUid ~= nil then
    self.fromUid = message.fromUid
  end
end
AllianceGiftData.__init = __init
AllianceGiftData.__delete = __delete
AllianceGiftData.ParseData = ParseData
return AllianceGiftData
