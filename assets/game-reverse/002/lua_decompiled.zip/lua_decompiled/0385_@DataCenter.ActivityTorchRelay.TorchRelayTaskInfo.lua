﻿local TorchRelayTaskInfo = BaseClass("TorchRelayTaskInfo")
local __init = function(self)
  self.id = 0
  self.num = 0
  self.startTime = 0
  self.time = 0
  self.state = 0
  self.reward = {}
end
local __delete = function(self)
  self.id = nil
  self.num = nil
  self.startTime = nil
  self.time = nil
  self.state = nil
  self.reward = nil
  self.config = nil
end
local UpdateInfo = function(self, message)
  if message == nil then
    return
  end
  if message.id ~= nil then
    self.id = tonumber(message.id)
  end
  if message.num ~= nil then
    self.num = message.num
  end
  if message.startTime ~= nil then
    self.startTime = message.startTime
  end
  if message.time ~= nil then
    self.time = message.time
  end
  if message.state ~= nil then
    self.state = message.state
  end
  if message.reward ~= nil then
    self.reward = message.reward
  end
  self.config = DataCenter.ActivityTaskTemplateManager:GetActTaskTemplate(self.id)
end
local SpawnMilestonesReward = function(self, mainConfig)
  local list = {}
  local rewardServerData = {}
  local str = string.split(mainConfig.game_task_score, ";")
  local type = tonumber(str[2])
  local id = tonumber(str[1])
  rewardServerData.type = type
  local itemData = {}
  itemData.id = id
  itemData.num = self.config.score
  rewardServerData.value = itemData
  table.insert(list, rewardServerData)
  self.reward = list
end
TorchRelayTaskInfo.__init = __init
TorchRelayTaskInfo.__delete = __delete
TorchRelayTaskInfo.UpdateInfo = UpdateInfo
TorchRelayTaskInfo.SpawnMilestonesReward = SpawnMilestonesReward
return TorchRelayTaskInfo
