﻿local Messenger = require("Framework.Common.Messenger")
local UpdateManager = BaseClass("UpdateManager", Singleton)
local UpdateMsgName = "Update"
local SecondUpdateMsgName = "SecondUpdate"
local LateUpdateMsgName = "LateUpdate"
local __init = function(self)
  self.ui_message_center = nil
  self.__update_handle = nil
  self.passTime = 1
  self.__lateUpdate_handle = nil
end
local UpdateHandle = function(self)
  self.ui_message_center:Broadcast(UpdateMsgName)
  self.passTime = self.passTime - Time.unscaledDeltaTime
  if self.passTime <= 0 then
    self.ui_message_center:Broadcast(SecondUpdateMsgName)
    self.passTime = 1
  end
end
local LateUpdateHandle = function(self)
  self.ui_message_center:Broadcast(LateUpdateMsgName)
end
local Startup = function(self)
  self:Dispose()
  self.__update_handle = UpdateBeat:CreateListener(UpdateHandle, UpdateManager:GetInstance())
  UpdateBeat:AddListener(self.__update_handle)
  self.__lateUpdate_handle = LateUpdateBeat:CreateListener(LateUpdateHandle, UpdateManager:GetInstance())
  LateUpdateBeat:AddListener(self.__lateUpdate_handle)
  self.ui_message_center = Messenger.New()
end
local Dispose = function(self)
  if self.__update_handle ~= nil then
    UpdateBeat:RemoveListener(self.__update_handle)
    self.__update_handle = nil
  end
  if self.__lateUpdate_handle ~= nil then
    LateUpdateBeat:RemoveListener(self.__lateUpdate_handle)
    self.__lateUpdate_handle = nil
  end
end
local Cleanup = function(self)
end
local AddUpdate = function(self, e_listener)
  self.ui_message_center:AddListener(UpdateMsgName, e_listener)
end
local RemoveUpdate = function(self, e_listener)
  self.ui_message_center:RemoveListener(UpdateMsgName, e_listener)
end
local AddSecondUpdate = function(self, e_listener)
  self.ui_message_center:AddListener(SecondUpdateMsgName, e_listener)
end
local RemoveSecondUpdate = function(self, e_listener)
  self.ui_message_center:RemoveListener(SecondUpdateMsgName, e_listener)
end

function UpdateManager:AddLateUpdate(e_listener)
  self.ui_message_center:AddListener(LateUpdateMsgName, e_listener)
end

function UpdateManager:RemoveLateUpdate(e_listener)
  self.ui_message_center:RemoveListener(LateUpdateMsgName, e_listener)
end

local __delete = function(self)
  self:Cleanup()
  self.ui_message_center = nil
end
UpdateManager.__init = __init
UpdateManager.Startup = Startup
UpdateManager.Dispose = Dispose
UpdateManager.Cleanup = Cleanup
UpdateManager.AddUpdate = AddUpdate
UpdateManager.RemoveUpdate = RemoveUpdate
UpdateManager.AddSecondUpdate = AddSecondUpdate
UpdateManager.RemoveSecondUpdate = RemoveSecondUpdate
UpdateManager.__delete = __delete
return UpdateManager
