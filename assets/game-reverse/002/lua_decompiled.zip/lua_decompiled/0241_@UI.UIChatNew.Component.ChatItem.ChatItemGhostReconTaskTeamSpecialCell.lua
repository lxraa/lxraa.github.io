﻿local ChatItemGhostReconTaskTeamSpecialCell = BaseClass("ChatItemGhostReconTaskTeamSpecialCell", UIBaseContainer)
local base = UIBaseContainer
local UIHeroCellSmall = require("UI.UIHero2.Common.UIHeroCellSmall")
local OnCreate = function(self)
  base.OnCreate(self)
  self:ComponentDefine()
  self:DataDefine()
end
local OnDestroy = function(self)
  self:ComponentDestroy()
  self:DataDestroy()
  base.OnDestroy(self)
end
local OnEnable = function(self)
  base.OnEnable(self)
end
local OnDisable = function(self)
  base.OnDisable(self)
end
local ComponentDefine = function(self)
  self.bg = self:AddComponent(UIImage, "")
  self.heroItem = self:AddComponent(UIHeroCellSmall, "UIHeroCellSmall")
  self.numText = self:AddComponent(UIText, "NumText")
end
local ComponentDestroy = function(self)
end
local DataDefine = function(self)
end
local DataDestroy = function(self)
end
local OnAddListener = function(self)
end
local OnRemoveListener = function(self)
end
local SetData = function(self, num, superCondition)
  self.heroItem:InitWithConfigId(superCondition.heroId, nil, superCondition.level, superCondition.star)
  self.numText:SetText(num .. "/" .. superCondition.num)
end
local SetBgColor = function(self, r, g, b, a)
  self.bg:SetColorRGBA255(r, g, b, a)
end
ChatItemGhostReconTaskTeamSpecialCell.OnCreate = OnCreate
ChatItemGhostReconTaskTeamSpecialCell.OnDestroy = OnDestroy
ChatItemGhostReconTaskTeamSpecialCell.OnEnable = OnEnable
ChatItemGhostReconTaskTeamSpecialCell.OnDisable = OnDisable
ChatItemGhostReconTaskTeamSpecialCell.ComponentDefine = ComponentDefine
ChatItemGhostReconTaskTeamSpecialCell.ComponentDestroy = ComponentDestroy
ChatItemGhostReconTaskTeamSpecialCell.DataDefine = DataDefine
ChatItemGhostReconTaskTeamSpecialCell.DataDestroy = DataDestroy
ChatItemGhostReconTaskTeamSpecialCell.OnAddListener = OnAddListener
ChatItemGhostReconTaskTeamSpecialCell.OnRemoveListener = OnRemoveListener
ChatItemGhostReconTaskTeamSpecialCell.SetData = SetData
ChatItemGhostReconTaskTeamSpecialCell.SetBgColor = SetBgColor
return ChatItemGhostReconTaskTeamSpecialCell
