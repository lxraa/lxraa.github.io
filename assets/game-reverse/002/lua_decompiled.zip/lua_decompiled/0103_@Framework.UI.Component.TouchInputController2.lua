﻿local TouchInputController2 = BaseClass("TouchInputController2", UIBaseContainer)
local base = UIBaseContainer
local CSTouchInputController2 = typeof(CS.BitBenderGames.TouchInputController2)
local OnCreate = function(self, ...)
  base.OnCreate(self)
  self.unity_touch_input_controller2 = self.gameObject:GetComponent(CSTouchInputController2)
  self.unity_touch_input_controller2:ClearAllEvent()
end
local OnDestroy = function(self)
  self.unity_touch_input_controller2:ClearAllEvent()
  self.unity_touch_input_controller2 = nil
  base.OnDestroy(self)
end
local OnDragStart = function(self, OnDragStart)
  self.unity_touch_input_controller2:SetOnDragStart(OnDragStart)
end
local OnDragUpdate = function(self, OnDragUpdate)
  self.unity_touch_input_controller2:SetOnDragUpdate(OnDragUpdate)
end
local OnDragStop = function(self, OnDragStop)
  self.unity_touch_input_controller2:SetOnDragStop(OnDragStop)
end
local OnPinchStart = function(self, OnPinchStart)
  self.unity_touch_input_controller2:SetOnPinchStart(OnPinchStart)
end
local OnPinchUpdate = function(self, OnPinchUpdate)
  self.unity_touch_input_controller2:SetOnPinchUpdate(OnPinchUpdate)
end
local OnPinchStop = function(self, OnPinchStop)
  self.unity_touch_input_controller2:SetOnPinchStop(OnPinchStop)
end
local OnInputClick = function(self, OnInputClick)
  self.unity_touch_input_controller2:SetOnInputClick(OnInputClick)
end
local RestartDrag = function(self)
  self.unity_touch_input_controller2:RestartDrag()
end
local GetIsDragging = function(self)
  return self.unity_touch_input_controller2.isDragging
end
local GetIsPinching = function(self)
  return self.unity_touch_input_controller2.isPinching
end
TouchInputController2.OnCreate = OnCreate
TouchInputController2.OnDestroy = OnDestroy
TouchInputController2.OnDragUpdate = OnDragUpdate
TouchInputController2.OnDragStart = OnDragStart
TouchInputController2.OnDragStop = OnDragStop
TouchInputController2.OnPinchStart = OnPinchStart
TouchInputController2.OnPinchUpdate = OnPinchUpdate
TouchInputController2.OnPinchStop = OnPinchStop
TouchInputController2.OnInputClick = OnInputClick
TouchInputController2.RestartDrag = RestartDrag
TouchInputController2.GetIsDragging = GetIsDragging
TouchInputController2.GetIsPinching = GetIsPinching
return TouchInputController2
