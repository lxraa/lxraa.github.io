﻿local BattlefieldConfig = {}
BattleFieldType = {
  Default = 0,
  MIN = 1,
  Desert = 1,
  WinterStorm = 2,
  EpidemicZone = 3,
  NewBattleTypeStart = 4,
  DsbDuel = 4,
  MAX = 4
}
BattleFieldTableKey = {
  MAP = "map_skin_id",
  ENTITY = "entity_table",
  P_SKILL = "personal_skills",
  T_SKILL = "team_skills",
  PARAM = "special_paras",
  P_POINT_ID = "personal_point_id",
  P_POINT_TYPE = "personal_point_type",
  STAR = "star",
  REWARD = "reward",
  GUIDE = "guide_group",
  RULES = "rules_group",
  TIME_CTRL = "time_controller",
  SIM = "battlefield_sim_group",
  UPDATE = "update_group",
  PING = "ping",
  BATTLEFIELD_TYPE = "type",
  MULTIPLE_ASSISTANCE = "multiple_garrison"
}
BattleFieldBuildType = {
  Normal = 1,
  POWER = 2,
  DEFENCE = 3,
  BUFF = 4,
  RES = 5,
  SCORE = 6
}
BattleFieldObjActType = {
  IDLE = "idle",
  FIX = "fix",
  AIM = "aim",
  ATK = "attack",
  DEAD = "dead",
  BORN = "born",
  CHARGE = "charge"
}
BattlefieldEnterCheckType = {
  MIN = 1,
  AllianceIsValid = 1,
  BattlefieldMemberFull = 2,
  YouAreLowBeMember = 3,
  InBlackRect = 4,
  MAX = 4
}
BattlefieldTipsVertical = {
  Auto = 0,
  Up = 1,
  Down = 2
}
BattlefieldBaseConfig = {}
BattlefieldBaseConfig[BattleFieldType.Desert] = {
  MapBaseName = "DragonWarDesert",
  UIName = UIWindowNames.LWMainDesertUI,
  BlockRangeLua = "Util.DragonBlockRange",
  WorldPrefabPath = "Assets/Main/Prefabs/World/BF_Desert",
  ScenePath = "Assets/Main/Scenes/BF_Desert",
  HeadUILuaPath = "Scene.WorldBuildHeadUI.WorldDragonBuildUI",
  BattlefieldSize = {200, 200},
  BattlefieldMgrGetter = function()
    return DataCenter.ActDragonManager
  end,
  BattlefieldTemplateMgrGetter = function()
    return DataCenter.DragonBuildTemplateManager
  end
}
BattlefieldBaseConfig[BattleFieldType.WinterStorm] = {
  MapBaseName = "DragonWarWinterStorm",
  UIName = UIWindowNames.LWMainWinterStormUI,
  BlockRangeLua = "Util.WinterStormBlockRange",
  WorldPrefabPath = "Assets/Main/Prefabs/World/BF_Winter",
  ScenePath = "Assets/Main/Scenes/BF_Winter",
  HeadUILuaPath = "Scene.WorldBuildHeadUI.WorldWinterStormBuildUI",
  BattlefieldSize = {70, 70},
  BattlefieldMgrGetter = function()
    return DataCenter.ActWinterStormManager
  end,
  BattlefieldTemplateMgrGetter = function()
    return DataCenter.WinterStormTemplateManager
  end
}
BattlefieldBaseConfig[BattleFieldType.EpidemicZone] = {
  MapBaseName = "BattleFiledEpidemic",
  UIName = UIWindowNames.LWMainEpidemicZoneUI,
  BlockRangeLua = "Util.EpidemicZoneBlockRange",
  WorldPrefabPath = "Assets/Main/Prefabs/World/BF_Epidemic",
  ScenePath = "Assets/Main/Scenes/BF_Epidemic",
  BattlefieldSize = {148, 250},
  MiniMapPrefab = "Assets/Main/Prefabs/UI/BF_Epidemic/Battle/BattleMiniMapEpidemic.prefab",
  HeadUILuaPath = "Scene.WorldBuildHeadUI.WorldEpidemicBuildUI",
  MiniMapLua = "UI.LWMainEpidemicZoneUI.Component.LWMainEpidemicZoneMiniMap",
  BattlefieldMgrGetter = function()
    return DataCenter.ActEpidemicZoneManager
  end,
  BattlefieldTemplateMgrGetter = function()
    return DataCenter.EpidemicBuildTemplateMgr
  end
}
BattlefieldBaseConfig[BattleFieldType.DsbDuel] = {
  MapBaseName = "BattleFiledDsbDuel",
  UIName = UIWindowNames.UIBattlefieldDsbDuelMainView,
  BlockRangeLua = "Util.DsbDuelBlockRange",
  WorldPrefabPath = "Assets/Main/Prefabs/World/BF_Dsb_Duel",
  ScenePath = "Assets/Main/Scenes/BF_Dsb_Duel",
  BattlefieldSize = {200, 200},
  MiniMapPrefab = "Assets/Main/Prefabs/UI/BF_Dsb_Duel/Battlefield/BattleMiniMapDsb.prefab",
  HeadUILuaPath = "Scene.WorldBuildHeadUI.WorldDsbBuildUI",
  MiniMapLua = "UI.DsbDuelBattlefield.MiniMap.UIBattlefieldMiniMapDsb",
  BattlefieldMgrGetter = function()
    return DataCenter.BattlefieldDsbDuelManager
  end,
  BattlefieldTemplateMgrGetter = function()
    return DataCenter.BattlefieldDsbDuelTemplateManager
  end
}
local _battlefieldUINames

function BattlefieldConfig.IsBattlefieldMainUI(uiName)
  if not uiName then
    return false
  end
  if not _battlefieldUINames then
    _battlefieldUINames = {}
    for k, v in pairs(BattlefieldBaseConfig) do
      _battlefieldUINames[v.UIName] = true
    end
  end
  return _battlefieldUINames[uiName]
end

return BattlefieldConfig
