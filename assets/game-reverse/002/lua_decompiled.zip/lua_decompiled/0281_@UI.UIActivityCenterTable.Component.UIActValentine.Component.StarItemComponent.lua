﻿local StarItemComponent = BaseClass("StarItemComponent", UIBaseContainer)
local base = UIBaseContainer
local Localization = CS.GameEntry.Localization
local light_path = "Star_light1"
local OnCreate = function(self)
  base.OnCreate(self)
  self:ComponentDefine()
  self:DataDefine()
end
local OnDestroy = function(self)
  self:DataDestroy()
  self:ComponentDestroy()
  base.OnDestroy(self)
end
local OnEnable = function(self)
  base.OnEnable(self)
end
local OnDisable = function(self)
  base.OnDisable(self)
end
local ComponentDefine = function(self)
  self.lightObj = self:AddComponent(UIBaseContainer, light_path)
  self.lightSimpleAni = self:AddComponent(UISimpleAnimation, light_path)
end
local ComponentDestroy = function(self)
end
local DataDefine = function(self)
end
local DataDestroy = function(self)
end
local OnAddListener = function(self)
  base.OnAddListener(self)
end
local OnRemoveListener = function(self)
  base.OnRemoveListener(self)
end

function StarItemComponent:ReInit(isLight)
  self.lightObj:SetActive(isLight)
end

function StarItemComponent:PlayLightAni()
  self.lightSimpleAni:Rewind("Play")
  self.lightSimpleAni:Play("Play")
end

StarItemComponent.OnCreate = OnCreate
StarItemComponent.OnDestroy = OnDestroy
StarItemComponent.OnEnable = OnEnable
StarItemComponent.OnDisable = OnDisable
StarItemComponent.ComponentDefine = ComponentDefine
StarItemComponent.ComponentDestroy = ComponentDestroy
StarItemComponent.DataDefine = DataDefine
StarItemComponent.DataDestroy = DataDestroy
StarItemComponent.OnAddListener = OnAddListener
StarItemComponent.OnRemoveListener = OnRemoveListener
return StarItemComponent
