﻿SendStateType = {
  OK = 0,
  PENDING = 1,
  FAILED = 2
}
