﻿local LWArmyTemplate = BaseClass("LWArmyTemplate")
local __init = function(self)
  self.id = 0
end
local __delete = function(self)
  self.id = nil
end
local InitData = function(self, row)
  if row == nil then
    return
  end
  self.id = row:getValue("id")
  self.army_icon = row:getValue("army_icon")
  self.name = row:getValue("name")
  self.rec_uav_power = tonumber(row:getValue("rec_uav_power")) or 0
  self.rec_equip_power = tonumber(row:getValue("rec_equip_power")) or 0
  self.rec_sci_power = tonumber(row:getValue("rec_sci_power")) or 0
  self.rec_honor_power = tonumber(row:getValue("rec_honor_power")) or 0
  self.replace_icon = row:getValue("replace_icon") or ""
  local pve_power = row:getValue("pve_power")
  if not string.IsNullOrEmpty(pve_power) then
    self.pve_power = string.string2array_num_oneSep(pve_power, "|")
  end
  self.line_up = {}
  for i = 1, 6 do
    local heroParam = string.format("hero%d", i)
    local soldierParam = string.format("hero%d_soldier", i)
    local heroStr = row:getValue(heroParam)
    local soldierStr = row:getValue(soldierParam)
    if not string.IsNullOrEmpty(heroStr) then
      local heroData, soldierData
      local heroArr = string.split_ss_array(heroStr, "|")
      heroData = {
        metaId = tonumber(heroArr[1]),
        level = tonumber(heroArr[2]),
        skillStar = tonumber(heroArr[3]),
        skillLevel = tonumber(heroArr[4]),
        rank = tonumber(heroArr[5] or 0) or 0
      }
      if not string.IsNullOrEmpty(soldierStr) then
        local soldierArr = string.split_ss_array(soldierStr, "|")
        soldierData = {
          metaId = tonumber(soldierArr[1]),
          num = tonumber(soldierArr[2])
        }
      end
      self.line_up[i] = {heroData = heroData, soldierData = soldierData}
    end
  end
end
LWArmyTemplate.__init = __init
LWArmyTemplate.__delete = __delete
LWArmyTemplate.InitData = InitData
return LWArmyTemplate
