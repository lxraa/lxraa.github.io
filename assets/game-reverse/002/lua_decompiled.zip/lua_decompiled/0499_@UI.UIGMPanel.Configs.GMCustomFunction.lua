﻿local GMPageStyle = require("UI.UIGMPanel.Configs.GMPageStyle")
local GMPageConfig = require("UI.UIGMPanel.Configs.GMPageConfig")
local config = GMPageConfig.New("CustomFunction")
config.style = GMPageStyle.PageTemplate.Vertical
config.order = 1
config.label = "\232\135\170\229\174\154\228\185\137"
config.icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/Common_icon_march_dig.png"
config:Add({
  name = "\230\137\147\229\188\128UI\239\188\154\nS5\231\129\171\232\189\166\228\184\187\231\149\140\233\157\162",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  icon = "Assets/Main/SeasonRes/S5/Sprites/HighSpeedRailway/LXYS5_Jingjin_Icon1_banner.png",
  tips = function()
  end,
  onClicked = function()
    GMUtils.Close()
    RailwayUtil.TryOpenHSRMain()
  end,
  btnName = "\230\137\147\229\188\128"
})
config:Add({
  name = "\230\137\147\229\188\128UI\239\188\154\nS5\230\138\162\231\129\171\232\189\166UI",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  icon = "Assets/Main/SeasonRes/S5/Sprites/HighSpeedRailway/LXYS5_Jingjin_Icon1_banner.png",
  tips = function()
  end,
  onClicked = function()
    GMUtils.Close()
    RailwayUtil.TryOpenHSRRob()
  end,
  btnName = "\230\137\147\229\188\128"
})
config:Add({
  name = "\230\137\147\229\188\128UI\239\188\154\nS5\231\129\171\232\189\166\228\184\170\228\186\186\229\142\134\229\143\178\229\136\151\232\161\168UI",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  icon = "Assets/Main/SeasonRes/S5/Sprites/HighSpeedRailway/LXYS5_Jingjin_Icon1_banner.png",
  tips = function()
  end,
  onClicked = function()
    GMUtils.Close()
    UIManager:GetInstance():OpenWindow(UIWindowNames.UIHSRPersonalHistoryList, {anim = true})
  end,
  btnName = "\230\137\147\229\188\128"
})
config:Add({
  name = "\232\183\179\232\189\172\232\135\179S5\231\129\171\232\189\166",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  icon = "Assets/Main/SeasonRes/S5/Sprites/HighSpeedRailway/LXYS5_Jingjin_Icon1_banner.png",
  tips = function()
  end,
  onClicked = function()
    GMUtils.Close()
    RailwayUtil.JumpToHSR()
  end,
  btnName = "\232\181\176\228\189\160"
})
config:Add({
  name = "S5\231\129\171\232\189\166\233\135\141\231\189\174\229\136\176\230\140\135\229\174\154\228\189\141\231\189\174\n\228\190\139\229\166\1303.5\232\161\168\231\164\186\231\172\1723\231\171\153\229\146\140\231\172\1724\231\171\153\231\154\132\228\184\173\231\130\185",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  icon = "Assets/Main/SeasonRes/S5/Sprites/HighSpeedRailway/LXYS5_Jingjin_Icon1_banner.png",
  get = function()
    return 1
  end,
  set = function(val)
  end,
  onClicked = function(val)
    local debugTime = (val - 1) * 1000000 / DataCenter.HSRDataManager:GetHSRSpeed()
    local hsrData = DataCenter.HSRDataManager:GetHSRData()
    if hsrData then
      hsrData:DebugSetStartTime(UITimeManager:GetInstance():GetServerTime() - debugTime)
      GMUtils.Close()
      RailwayUtil.JumpToHSR()
    else
      UIUtil.ShowTips("\230\147\141\228\189\156\229\164\177\232\180\165\239\188\129\229\189\147\229\137\141\230\178\161\230\156\137\231\129\171\232\189\166\230\149\176\230\141\174")
    end
  end,
  btnName = "Go",
  contentType = 3,
  min = 1,
  max = 11
})
config:Add({
  name = "S5\231\129\171\232\189\166\233\135\141\231\189\174\229\167\139\229\143\145\230\150\185\229\144\145\n0123\229\136\134\229\136\171\228\187\163\232\161\168\228\184\156\232\165\191\229\141\151\229\140\151",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  icon = "Assets/Main/SeasonRes/S5/Sprites/HighSpeedRailway/LXYS5_Jingjin_Icon1_banner.png",
  get = function()
    return 3
  end,
  set = function(val)
  end,
  onClicked = function(val)
    local hsrData = DataCenter.HSRDataManager:GetHSRData()
    if hsrData then
      hsrData:DebugSetStartDirection(toInt(val))
      UIUtil.ShowTips("\230\147\141\228\189\156\230\136\144\229\138\159\239\188\129")
    else
      UIUtil.ShowTips("\230\147\141\228\189\156\229\164\177\232\180\165\239\188\129\229\189\147\229\137\141\230\178\161\230\156\137\231\129\171\232\189\166\230\149\176\230\141\174")
    end
  end,
  btnName = "\231\161\174\232\174\164",
  contentType = 3,
  min = 0,
  max = 3
})
return config
