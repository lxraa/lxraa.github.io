﻿local UIScrollRect = BaseClass("UIScrollRect", UIBaseContainer)
local base = UIBaseContainer
local UnityScrollRect = typeof(CS.UnityEngine.UI.ScrollRect)
local OnCreate = function(self, ...)
  base.OnCreate(self)
  self.unity_uiscrollRect = self.gameObject:GetComponent(UnityScrollRect)
end
local GetScrollRect = function(self)
  return self.unity_uiscrollRect
end
local OnDestroy = function(self)
  pcall(function()
    self.unity_uiscrollRect.onValueChanged:Clear()
  end)
  self.unity_uiscrollRect = nil
  base.OnDestroy(self)
end
local OnBeginDrag = function(self, eventData)
  self.unity_uiscrollRect:OnBeginDrag(eventData)
end
local OnEndDrag = function(self, eventData)
  self.unity_uiscrollRect:OnEndDrag(eventData)
end
local OnDrag = function(self, eventData)
  self.unity_uiscrollRect:OnDrag(eventData)
end
local SetScrollEndDrag = function(self)
  self.unity_uiscrollRect:ScrollRect_EndDrag()
end
local SetEnable = function(self, value)
  self.unity_uiscrollRect.enabled = value
end
local StopMovement = function(self)
  self.unity_uiscrollRect:StopMovement()
end
local AddValueChangeListener = function(self, callback)
  self.unity_uiscrollRect.onValueChanged:AddListener(callback)
end
local RemoveAllListeners = function(self)
  self.unity_uiscrollRect.onValueChanged:RemoveAllListeners()
end
local SetHorizontalNormalizedPosition = function(self, data)
  if type(data) == "number" and CommonUtil and CommonUtil.IsArabicAutoMirrorOpen() then
    data = 1 - data
  end
  self.unity_uiscrollRect:SetHorizontalNormalizedPosition(data)
end
local GetHorizontalNormalizedPosition = function(self)
  return self.unity_uiscrollRect:GetHorizontalNormalizedPosition()
end
local SetVerticalNormalizedPosition = function(self, value)
  self.unity_uiscrollRect.verticalNormalizedPosition = value
end
local GetVerticalNormalizedPosition = function(self)
  return self.unity_uiscrollRect.verticalNormalizedPosition
end
local AnimNormalizedPos = function(self, vector2, duration)
  if not IsNull(self.unity_uiscrollRect) then
    self.unity_uiscrollRect:DONormalizedPos(vector2, duration)
  end
end
local AnimHorizontalNormalizedPos = function(self, endPos, duration)
  if not IsNull(self.unity_uiscrollRect) then
    self.unity_uiscrollRect:DOHorizontalNormalizedPos(endPos, duration)
  end
end
local AnimVerticalNormalizedPos = function(self, endPos, duration)
  if not IsNull(self.unity_uiscrollRect) then
    self.unity_uiscrollRect:DOVerticalNormalizedPos(endPos, duration)
  end
end
UIScrollRect.SetScrollEndDrag = SetScrollEndDrag
UIScrollRect.OnCreate = OnCreate
UIScrollRect.OnDestroy = OnDestroy
UIScrollRect.OnBeginDrag = OnBeginDrag
UIScrollRect.OnEndDrag = OnEndDrag
UIScrollRect.OnDrag = OnDrag
UIScrollRect.SetEnable = SetEnable
UIScrollRect.StopMovement = StopMovement
UIScrollRect.AddValueChangeListener = AddValueChangeListener
UIScrollRect.RemoveAllListeners = RemoveAllListeners
UIScrollRect.SetHorizontalNormalizedPosition = SetHorizontalNormalizedPosition
UIScrollRect.GetHorizontalNormalizedPosition = GetHorizontalNormalizedPosition
UIScrollRect.GetScrollRect = GetScrollRect
UIScrollRect.SetVerticalNormalizedPosition = SetVerticalNormalizedPosition
UIScrollRect.GetVerticalNormalizedPosition = GetVerticalNormalizedPosition
UIScrollRect.AnimNormalizedPos = AnimNormalizedPos
UIScrollRect.AnimHorizontalNormalizedPos = AnimHorizontalNormalizedPos
UIScrollRect.AnimVerticalNormalizedPos = AnimVerticalNormalizedPos
return UIScrollRect
