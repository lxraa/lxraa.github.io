﻿local base = UIBaseContainer
local UIAsyncProxy = BaseClass("UIAsyncProxy", base)

function UIAsyncProxy:SetActiveAsync(isActive, luaClassOrPath, prefabPath, parent, callback, callback_param, var_arg)
  if isActive then
    if self.__asyncComponent == nil then
      self.__asyncComponent = self:LoadComponentAsync(luaClassOrPath, prefabPath, parent, callback, callback_param, var_arg)
    end
    if self.__asyncComponent ~= nil then
      self.__asyncComponent:SetActive(true)
    end
  elseif self.__asyncComponent then
    self:RemoveAsyncComponent(self.__asyncComponent)
    self.__asyncComponent = nil
  end
end

return UIAsyncProxy
