﻿local AllianceTaskData = BaseClass("AllianceTaskData")
local __init = function(self)
  self.taskId = 0
  self.curProg = 0
  self.startTime = 0
  self.endTime = 0
  self.finishTime = 0
  self.rewards = {}
  self.rewardRank = 5
  self.state = 0
end
local __delete = function(self)
  self.taskId = nil
  self.curProg = nil
  self.startTime = nil
  self.endTime = nil
  self.finishTime = nil
  self.rewards = nil
  self.rewardRank = nil
  self.state = nil
end
local ParseData = function(self, message)
  if message.taskId then
    self.taskId = message.taskId
  end
  if message.num then
    self.curProg = message.num
  end
  if message.startTime then
    self.startTime = message.startTime
  end
  if message.endTime then
    self.endTime = message.endTime
  end
  if message.finishTime then
    self.finishTime = message.finishTime
  end
  if message.rewardArr then
    self.rewards = message.rewardArr
  end
  if message.rewardRank then
    self.rewardRank = message.rewardRank
  end
  if message.state then
    self.state = message.state
  end
end
local SetTaskClaimed = function(self)
  self.state = 2
  self.finishTime = UITimeManager:GetInstance():GetServerTime()
end
local GetTaskStatus = function(self)
  if self.finishTime and self.finishTime > 0 then
    local finishFlag = self.state == 0 and 5 or 3
    return finishFlag, self.finishTime
  else
    local serverTime = UITimeManager:GetInstance():GetServerTime()
    if serverTime < self.startTime then
      return 1, self.startTime
    elseif serverTime > self.endTime then
      return 4, self.endTime
    else
      return 2, self.endTime
    end
  end
end
local CheckIfCanClaim = function(self)
  local tempStatus = self:GetTaskStatus()
  if tempStatus == 3 and self.state == 1 then
    return true
  end
  return false
end
AllianceTaskData.__init = __init
AllianceTaskData.__delete = __delete
AllianceTaskData.ParseData = ParseData
AllianceTaskData.SetTaskClaimed = SetTaskClaimed
AllianceTaskData.GetTaskStatus = GetTaskStatus
AllianceTaskData.CheckIfCanClaim = CheckIfCanClaim
return AllianceTaskData
