﻿local base = require("UI.UIChatNew.Component.ChatItem.IChatItem")
local content_path = "Content"
local u_i_player_head_path = "Content/UIPlayerHead"
local u_i_player_head_receiver_path = "Content/UIPlayerHead_Receiver"
local player_name_text_path = "Content/PlayerNameText"
local player_name_text_receiver_path = "Content/PlayerNameText_Receiver"
local des_text_path = "Content/DesText"
local icon_path = "Content/Icon"
local num_path = "Content/Num"
local black_mask_path = "Content/BlackMask"
local btn_path = "Content/Btn"
local bg_path = "Content/bgContent/bg"
local diwen_path = "Content/bgContent/diwenContent/diwen"
local line1_path = "Content/bgContent/lineContent/line1"
local line2_path = "Content/bgContent/lineContent/line2"
local line3_path = "Content/bgContent/lineContent/line3"
local line4_path = "Content/bgContent/lineContent/line4"
local gift_bg_path = "Content/bgContent/giftBg"
local arrow_bg_path = "Content/bgContent/arrowBg"
local head_bg1_path = "Content/bgContent/headBg1"
local head_bg2_path = "Content/bgContent/headBg2"
local txt_content_bg_path = "Content/bgContent/txtContentBg"
local translate_content_path = "Content/translateContent"
local translating_path = "Content/translateContent/Translating"
local translate_finish_img_path = "Content/translateContent/TranslateFinishImg"
local translate_btn_path = "Content/translateContent/TranslateBtn"
local translate_refresh_btn_path = "Content/translateContent/TranslateRefreshBtn"
local translating_text_path = "Content/translateContent/Translating/TranslatingText"
local ChatGiftGiving = BaseClass("ChatGiftGiving", base)
local Localization = CS.GameEntry.Localization
local rapidjson = require("rapidjson")
local sin15d = 0.2588
local cos15d = 0.9659
local itemMinH = 334
local itemWidth = 752
local translateBtnH = 50
local txtMinH = 42
local txtContentMinH = 92
local txtContentDiffItemH = 242

function ChatGiftGiving:OnCreate()
  base.OnCreate(self)
  self:ComponentDefine()
end

function ChatGiftGiving:OnDestroy()
  self:ComponentDestroy()
  base.OnDestroy(self)
end

function ChatGiftGiving:ComponentDefine()
  self.content = self:AddComponent(UIRawImage, content_path)
  self.u_i_player_head = self:AddComponent(UICommonHead, u_i_player_head_path)
  self.u_i_player_head_receiver = self:AddComponent(UICommonHead, u_i_player_head_receiver_path)
  self.player_name_text = self:AddComponent(UITextMeshProUGUIEx, player_name_text_path)
  self.player_name_text_receiver = self:AddComponent(UITextMeshProUGUIEx, player_name_text_receiver_path)
  self.des_text = self:AddComponent(UIText, des_text_path)
  self.icon = self:AddComponent(UIImage, icon_path)
  self.num = self:AddComponent(UITextMeshProUGUIEx, num_path)
  self.black_mask = self:AddComponent(UIImage, black_mask_path)
  self.btn = self:AddComponent(UIButton, btn_path)
  self.bg = self:AddComponent(UIImage, bg_path)
  self.diwen = self:AddComponent(UIImage, diwen_path)
  self.line1 = self:AddComponent(UIImage, line1_path)
  self.line2 = self:AddComponent(UIImage, line2_path)
  self.line3 = self:AddComponent(UIImage, line3_path)
  self.line4 = self:AddComponent(UIImage, line4_path)
  self.gift_bg = self:AddComponent(UIImage, gift_bg_path)
  self.arrow_bg = self:AddComponent(UIImage, arrow_bg_path)
  self.head_bg1 = self:AddComponent(UIImage, head_bg1_path)
  self.head_bg2 = self:AddComponent(UIImage, head_bg2_path)
  self.txt_content_bg = self:AddComponent(UIImage, txt_content_bg_path)
  self.translate_content = self:AddComponent(UIBaseContainer, translate_content_path)
  self.translating = self:AddComponent(UIImage, translating_path)
  self.translating_text = self:AddComponent(UIText, translating_text_path)
  self.translating_text:SetLocalText("120039")
  self.translate_finish_img = self:AddComponent(UIImage, translate_finish_img_path)
  self.translate_btn = self:AddComponent(UIButton, translate_btn_path)
  self.translate_refresh_btn = self:AddComponent(UIButton, translate_refresh_btn_path)
  self.translate_btn:SetOnClick(function()
    self:TranslateMsg()
  end)
  self.translate_refresh_btn:SetOnClick(function()
    self:TranslateMsgThenChangeType()
  end)
  ChatInterface.SetEmojiTextProperty(self.des_text, true)
end

function ChatGiftGiving:ComponentDestroy()
  self.content = nil
  self.u_i_player_head = nil
  self.u_i_player_head_receiver = nil
  self.player_name_text = nil
  self.player_name_text_receiver = nil
  self.des_text = nil
  self.icon = nil
  self.num = nil
  self.black_mask = nil
  self.btn = nil
  self.bg = nil
  self.diwen = nil
  self.line1 = nil
  self.line2 = nil
  self.line3 = nil
  self.line4 = nil
  self.gift_bg = nil
  self.arrow_bg = nil
  self.head_bg1 = nil
  self.head_bg2 = nil
  self.txt_content_bg = nil
  self.translate_content = nil
  self.translating = nil
  self.translating_text = nil
  self.translate_finish_img = nil
  self.translate_btn = nil
  self.translate_refresh_btn = nil
end

function ChatGiftGiving:UpdateItem(chatData, index)
  self._chatData = chatData
  local customJsonParam = self._chatData.extra and self._chatData.extra.customJsonParam
  if customJsonParam == nil then
    return
  end
  local extraJson
  if type(self._chatData.extra.customJsonParam) == "string" then
    extraJson = rapidjson.decode(self._chatData.extra.customJsonParam)
  elseif type(self._chatData.extra.customJsonParam) == "table" then
    extraJson = self._chatData.extra.customJsonParam
  else
    return
  end
  local template = DataCenter.ItemTemplateManager:GetItemTemplate(extraJson.itemId)
  if template == nil then
    return
  end
  local goods = DataCenter.GiftSystemManager:GetGiftGoods(template.id)
  local targetInfo = extraJson.targetInfo or {}
  local senderInfo = extraJson.senderInfo or {}
  local sendNum = extraJson.num
  local giftName = Localization:GetString(template.name)
  local sendPlayerName = extraJson.sendName
  self.icon:LoadSprite(GiftSystemConst.GetIconPath(goods.icon_mid))
  self.icon:SetNativeSize()
  self:SetTxtShowAndBgPicContent(template.quality, extraJson)
  self.num:SetText("x" .. sendNum)
  senderInfo.isActiveAnonymity = extraJson.isAnonymous == 1
  local abbr = not string.IsNullOrEmpty(senderInfo.abbr) and "[" .. tostring(senderInfo.abbr) .. "]" or ""
  local senderName = abbr .. tostring(senderInfo.name)
  if extraJson.isAnonymous == 1 then
    senderName = Localization:GetString("390810")
  end
  self.u_i_player_head:ParseHeadInfo(senderInfo)
  self.u_i_player_head:SetEnableClickShowInfo(extraJson.isAnonymous ~= 1, true)
  self.player_name_text:SetText(senderName)
  self.u_i_player_head_receiver:ParseHeadInfo(targetInfo)
  self.u_i_player_head_receiver:SetEnableClickShowInfo(true, true)
  local abbr_receiver = not string.IsNullOrEmpty(targetInfo.abbr) and "[" .. tostring(targetInfo.abbr) .. "]" or ""
  self.player_name_text_receiver:SetText(abbr_receiver .. tostring(targetInfo.name))
  self.black_mask:SetActive(ChatInterface.GetChatTheme() == ChatUIThemeConfig.ChatMode.Night)
  if goods.ep_gift == 1 then
    local id = extraJson.chatGiftUuid or self._chatData.seqId
    DataCenter.GiftSystemManager:TryPlayAnim(id, goods.id)
  elseif next(goods.group_id) then
    local index = 0
    for i, v in ipairs(goods.group_id) do
      if sendNum >= tonumber(v) then
        index = i
      end
    end
    local effect = goods.group_effect[index]
    if not string.IsNullOrEmpty(effect) then
      local id = extraJson.chatGiftUuid or self._chatData.seqId
      DataCenter.GiftSystemManager:TryPlayAnim(id, goods.id, index)
    end
  end
end

function ChatGiftGiving:SetTxtShowAndBgPicContent(quality, extraJson)
  local bg, gift_bg, txt_bg, head_bg, arrow, line = GiftSystemConst.GetGiftPostQualityPic(quality)
  self.bg:LoadSprite(bg)
  self.gift_bg:LoadSprite(gift_bg)
  self.txt_content_bg:LoadSprite(txt_bg)
  self.head_bg1:LoadSprite(head_bg)
  self.head_bg2:LoadSprite(head_bg)
  self.arrow_bg:LoadSprite(arrow)
  self.line1:LoadSprite(line)
  self.line2:LoadSprite(line)
  self.line3:LoadSprite(line)
  self.line4:LoadSprite(line)
  local isTranslateBtnShow = false
  if extraJson.isAnonymous ~= 1 then
    if not string.IsNullOrEmpty(extraJson.context) then
      isTranslateBtnShow = true
      local showTxt = extraJson.context
      if self._chatData:GetTranslateState() == TranslateStateType.TranslationCompleted then
        showTxt = self._chatData:getTranslationMsg()
      end
      self.des_text:SetText(showTxt)
    else
      self.des_text:SetLocalText("gift_msg_default_des")
    end
  else
    self.des_text:SetLocalText("gift_msg_default_des")
  end
  if isTranslateBtnShow then
    self.translate_content:SetActive(true)
    self:UpdateTranslateBtnState(self._chatData:IsTranslating(), self._chatData:GetTranslateState() == TranslateStateType.TranslationCompleted)
  else
    self.translate_content:SetActive(false)
  end
  CS.UnityEngine.UI.LayoutRebuilder.ForceRebuildLayoutImmediate(self.des_text.transform)
  local txtContX, txtContY = self.des_text:GetSizeDeltaXY()
  local curtranslateBtnH = isTranslateBtnShow and translateBtnH or 0
  local txtContentH = txtContY + curtranslateBtnH
  local itemTargetH = 0
  if txtContentH < txtContentMinH then
    itemTargetH = itemMinH
  else
    itemTargetH = txtContentH + txtContentDiffItemH
  end
  self:SetSizeDeltaXY(itemWidth, itemTargetH)
end

function ChatGiftGiving:TranslateMsg()
  if self._chatData:IsTranslating() then
    return
  end
  local _translationMsg = self._chatData:getTranslationMsg()
  if self._chatData.translatedLang == ChatInterface.GetChatTranslateLanguageAbbr() and not string.IsNullOrEmpty(_translationMsg) and self._chatData:GetCanRefreshTranslate() == 1 then
    return
  end
  self._chatData:setTranslateState(1)
  if string.IsNullOrEmpty(_translationMsg) or self._chatData.translatedLang ~= ChatInterface.GetChatTranslateLanguageAbbr() then
    EventManager:GetInstance():Broadcast(ChatEventEnum.CHAT_TRANSLATE, self._chatData)
  elseif self._chatData:GetCanRefreshTranslate() ~= 1 then
    self:TranslateMsgThenChangeType()
  else
    self._chatData:setTranslateState(0)
  end
  self:UpdateTranslateBtnState(self._chatData:IsTranslating(), self._chatData:GetTranslateState() == 2)
end

function ChatGiftGiving:TranslateMsgThenChangeType()
  self._chatData:setTranslateState(1)
  local transType = self._chatData:GetTranslateType()
  if transType == nil then
    transType = 1
  elseif transType == 0 then
    transType = 1
  elseif transType == 1 then
    transType = 0
  end
  self._chatData:SetTranslateType(transType)
  EventManager:GetInstance():Broadcast(ChatEventEnum.CHAT_TRANSLATE, self._chatData)
end

function ChatGiftGiving:UpdateTranslateBtnState(isTranslating, hasTranslated)
  if self.translate_btn == nil then
    return
  end
  self.translating:SetActive(isTranslating and not hasTranslated)
  self.translate_btn:SetActive(not isTranslating and not hasTranslated)
  self.translate_finish_img:SetActive(hasTranslated and self._chatData:GetCanRefreshTranslate() == 1)
  self.translate_refresh_btn:SetActive(hasTranslated and self._chatData:GetCanRefreshTranslate() ~= 1)
end

function ChatGiftGiving:ResetTranslatePart()
  if self.translate_btn == nil then
    return
  end
  self.translate_btn:SetActive(false)
  self.translate_refresh_btn:SetActive(false)
  self.translate_finish_img:SetActive(false)
  self.translating:SetActive(false)
end

return ChatGiftGiving
