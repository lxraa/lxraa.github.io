﻿local DefenceWallData = BaseClass("DefenceWallData")
local __init = function(self)
  self.durability = 0
  self.morale = 0
  self.lastMoraleTime = 0
  self.protectEndTime = 0
  self.lastGoldRecoverDurabilityTime = 0
end
local __delete = function(self)
  self.durability = nil
  self.morale = nil
  self.lastMoraleTime = nil
  self.protectEndTime = nil
  self.lastGoldRecoverDurabilityTime = nil
end
local ParseData = function(self, message)
  if message == nil then
    return
  end
  if message.durability ~= nil then
    self:SetCurDurability(message.durability)
  end
  if message.morale ~= nil then
    self.morale = message.morale
  end
  if message.lastMoraleTime ~= nil then
    self.lastMoraleTime = message.lastMoraleTime
  end
  if message.protectEndTime ~= nil then
    self.protectEndTime = message.protectEndTime
  end
  if message.lastGoldRecoverDurabilityTime ~= nil then
    self.lastGoldRecoverDurabilityTime = message.lastGoldRecoverDurabilityTime
  end
  if message.lastDurabilityTime ~= nil then
    self.lastDurabilityTime = message.lastDurabilityTime
  end
  if message.fireEndTime ~= nil then
    self.fireEndTime = message.fireEndTime
  end
end
local SetCurDurability = function(self, data)
  self.durability = data
end
local SetColdDownTime = function(self, data)
  self.lastGoldRecoverDurabilityTime = data
end
DefenceWallData.__init = __init
DefenceWallData.__delete = __delete
DefenceWallData.ParseData = ParseData
DefenceWallData.SetCurDurability = SetCurDurability
DefenceWallData.SetColdDownTime = SetColdDownTime
return DefenceWallData
