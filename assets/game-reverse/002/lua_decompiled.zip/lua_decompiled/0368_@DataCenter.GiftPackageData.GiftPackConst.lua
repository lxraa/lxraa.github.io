﻿GiftPackType = {
  Unknown = -1,
  BuyDiamond = 1,
  PromotionPay = 3,
  MonthCard = 5,
  WeekCard = 6,
  HeroMonthCard = 8,
  MonopolyLandPackage = 32,
  PromotionDiamond = 998,
  CreditPackage = 999,
  RefundBrickPackage = 10003
}
