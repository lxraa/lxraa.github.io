﻿local PathUtil = {}
local GetFileNameWithoutExtension = function(filepath)
  local filename
  local i = filepath:findlast("[/\\]")
  if i then
    filename = filepath:sub(i + 1)
  else
    filename = filepath
  end
  i = filename:findlast(".", true)
  if i then
    return filename:sub(1, i - 1)
  else
    return filename
  end
end
PathUtil.GetFileNameWithoutExtension = GetFileNameWithoutExtension
return ConstClass("PathUtil", PathUtil)
