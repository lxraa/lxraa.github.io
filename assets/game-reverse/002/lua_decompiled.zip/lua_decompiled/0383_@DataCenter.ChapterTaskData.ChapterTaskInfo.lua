﻿local ChapterTaskInfo = BaseClass("ChapterTaskInfo")
local __init = function(self)
  self.id = 0
  self.num = 0
  self.state = 0
  self.rewardList = {}
  self.listType = 0
  self.taskReward = false
end
local __delete = function(self)
  self.id = nil
  self.num = nil
  self.state = nil
  self.rewardList = nil
  self.listType = nil
  self.taskReward = nil
end
local UpdateInfo = function(self, message)
  if message == nil then
    return
  end
  if message.id ~= nil then
    self.id = message.id
  end
  if message.num ~= nil then
    self.num = message.num
  end
  if message.state ~= nil then
    self.state = message.state
  end
  if message.reward ~= nil then
    self.rewardList = DataCenter.RewardManager:ReturnRewardParamForView(message.reward)
  end
  local template = DataCenter.QuestTemplateManager:GetQuestTemplate(self.id)
  if template then
    self.listType = template.list == "" and 1 or tonumber(template.list)
  end
end
local SetTaskRewardState = function(self)
  self.taskReward = true
end
ChapterTaskInfo.__init = __init
ChapterTaskInfo.__delete = __delete
ChapterTaskInfo.UpdateInfo = UpdateInfo
ChapterTaskInfo.SetTaskRewardState = SetTaskRewardState
return ChapterTaskInfo
