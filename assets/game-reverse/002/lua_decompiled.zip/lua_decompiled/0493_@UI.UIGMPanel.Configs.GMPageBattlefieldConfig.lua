﻿local GMPageStyle = require("UI.UIGMPanel.Configs.GMPageStyle")
local CSGMSwitch = CS.GMSwitch
local GMPageConfig = require("UI.UIGMPanel.Configs.GMPageConfig")
local config = GMPageConfig.New("Battlefield")
config.style = GMPageStyle.PageTemplate.Vertical
config.order = 1500
config.label = "\230\136\152\229\156\186"
config.icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_zhanbao_duikangicon.png"
config:Add({
  name = "\232\190\147\229\135\186\232\175\166\230\131\133",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/cfm_common_anniu_jilu.png",
  tips = function()
    UIUtil.ShowTips("\232\174\169\230\136\145\231\158\133\231\158\133\228\189\160\230\152\175\228\184\170\229\149\165~")
  end,
  onClicked = function()
    local sb = StringBuilder.New()
    sb:AppendLine("BattleFieldUtils:")
    sb:AppendLine(BattleFieldUtil.Description())
    sb:AppendLine()
    sb:AppendLine("Dsb:")
    sb:AppendLine(BattlefieldDsbDuelUtils.Description())
    UIUtil.ShowDetail(sb:ToString(), "\230\136\152\229\156\186\228\191\161\230\129\175", nil, true, true)
  end,
  btnName = "\231\158\133\231\158\133"
})
config:Add({
  name = "\230\181\139\232\175\149\229\138\160\232\189\189\230\136\152\229\156\186",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/common_cfm_anniu_fanhui.png",
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("\231\130\185\229\135\187\229\144\142\230\151\160\232\132\145\232\191\155\229\133\165\230\136\152\229\156\186\239\188\136\230\151\160\232\174\186\230\152\175\229\144\166\229\173\152\229\156\168\230\136\152\229\156\186\239\188\137")
    sb:AppendLine("\229\165\189\231\178\151\230\154\180\229\147\166\239\188\129")
    sb:AppendLine("\228\189\134\230\152\175\228\186\186\229\174\182\229\165\189\229\150\156\230\172\162~>_<")
    sb:AppendLine("")
    sb:AppendLine("\230\136\152\229\156\186\231\188\150\229\143\183\239\188\154")
    sb:AppendLine("1\239\188\154\230\178\153\230\188\160")
    sb:AppendLine("2\239\188\154\229\134\172\230\151\165")
    sb:AppendLine("3\239\188\154\229\179\161\232\176\183")
    sb:AppendLine("4\239\188\154\230\178\153\230\188\160\229\164\167\228\185\177\230\150\151")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return BattleFieldType.DsbDuel
  end,
  set = function(val)
  end,
  onClicked = function(val)
    BattleFieldUtil.DebugEnterBattlefield(val)
  end,
  btnName = "\230\136\145\232\191\155",
  contentType = 2,
  min = 1,
  max = 4
})
config:Add({
  name = "GM\231\155\180\230\142\165\232\191\155\229\133\165\230\136\152\229\156\186",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_saijikaifa_xuyaokangxing_icon.png",
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("\231\130\185\229\135\187\229\144\142\230\151\160\232\132\145\232\191\155\229\133\165\229\164\167\228\185\177\230\150\151")
    sb:AppendLine("\229\165\189\231\178\151\230\154\180\229\147\166\239\188\129")
    sb:AppendLine("\228\189\134\230\152\175\228\186\186\229\174\182\229\165\189\229\150\156\230\172\162~>_<")
    sb:AppendLine("")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return 4
  end,
  set = function(val)
  end,
  onClicked = function(val)
    GMUtils.Close()
    BattleFieldUtil.GMEnterBattlefield(4)
  end,
  btnName = "\230\136\145\232\191\155",
  contentType = 2,
  min = 1,
  max = 4
})
config:Add({
  name = "\230\137\147\229\188\128\230\136\152\228\186\137\228\184\173\229\191\131",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_zhanbao_duikangicon.png",
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("\230\136\152\228\186\137\228\184\173\229\191\131\229\164\170tm\233\154\190\230\137\190\228\186\134...")
    sb:AppendLine(">_<")
    sb:AppendLine("")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  onClicked = function()
    GMUtils.Close()
    UIManager:GetInstance():OpenWindow(UIWindowNames.UIRaceEntrance)
  end,
  btnName = "\230\137\147\229\188\128"
})
config:Add({
  name = "\230\178\153\230\188\160S0\231\187\147\231\174\151\230\181\139\232\175\149",
  icon = "Assets/Main/Sprites/ActivityIcons/zyf_shamofengbao_huodong_icon.png",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  get = function()
    return "3,10|1,5"
  end,
  set = function(val)
  end,
  onClicked = function(params)
    DataCenter.ActDragonManager.TEST_PARAM = params
    UIManager:GetInstance():DestroyWindow(UIWindowNames.UIGMPanel, {anim = true})
    DataCenter.ActDragonManager:Test()
  end,
  contentType = 0,
  btnName = "\231\161\174\229\174\154!"
})
config:Add({
  name = "\230\150\176\232\161\128\230\157\161\230\181\139\232\175\149",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_zhanbao_duikangicon.png",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  get = function()
    return "6000,4000"
  end,
  set = function(val)
  end,
  onClicked = function(params)
    local theWorld = CS.SceneManager.World
    if theWorld == nil or not CS.SceneManager:IsInWorld() then
      UIUtil.ShowTips("\230\178\161\229\156\168\229\164\167\228\184\150\231\149\140\229\145\162\239\188\129\229\133\136\229\142\187\229\164\167\228\184\150\231\149\140\229\144\167\239\188\129")
      return
    end
    local nums = string.string2array_i_oneSep(params, ",")
    local buildingInfo = CS.SceneManager.World:GetPointInfo(LuaEntry.Player:GetMainWorldPos())
    if buildingInfo == nil then
      UIUtil.ShowTips("\230\178\161\230\137\190\229\136\176\232\135\170\229\183\177\228\184\187\229\159\142\229\149\138\239\188\129\229\133\136\230\137\190\230\137\190\229\156\168\229\147\170\229\145\162\239\188\159")
      return
    end
    GMUtils.Close()
    TimerManager:GetInstance():DelayInvoke(function()
      local serverId = LuaEntry.Player:GetCurServerId()
      local pointId = LuaEntry.Player:GetMainWorldPos()
      local startBlood = nums[1] or 6000
      local targetBlood = nums[2] or 4000
      local maxBlood = 8000
      local itemId = BuildingTypes.FUN_BUILD_MAIN
      local buildTemplate = DataCenter.BuildTemplateManager:GetBuildingDesTemplate(itemId)
      if buildTemplate ~= nil then
        BuildBloodManager:GetInstance():ShowOneBloodEffect(serverId, buildingInfo.uuid, pointId, startBlood, targetBlood, maxBlood, buildTemplate.tileX, buildTemplate.tileY, itemId, true)
      end
    end, 0.5)
  end,
  btnName = "\230\137\147\229\188\128"
})
config:Add({
  name = "\229\191\171\233\128\159\230\137\147\229\188\128UI",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_zhanbao_duikangicon.png",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  get = function()
    return UIWindowNames.UIWinterStormMatching
  end,
  set = function(val)
  end,
  onClicked = function(params)
    GMUtils.Close()
    DevUtils.OpenWindow(params)
  end,
  btnName = "\230\137\147\229\188\128"
})
config:Add()
config:Add()
config:Add()
config:Add()
config:Add()
config:Add()
return config
