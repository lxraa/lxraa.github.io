﻿local GMPageStyle = require("UI.UIGMPanel.Configs.GMPageStyle")
local GMPageConfig = require("UI.UIGMPanel.Configs.GMPageConfig")
local CrazyRockSettleData = require("DataCenter.ActCrazyRockDataManager.Data.CrazyRockSettleData")
local config = GMPageConfig.New("ActivityDebug")
config.style = GMPageStyle.PageTemplate.Vertical
config.order = 500
config.label = "\230\180\187\229\138\168"
config.icon = "Assets/Main/Sprites/UI/UIMain/LWMainUI/mjc_huodong_huizong.png"
config:Add({
  name = "[\231\150\175\231\139\130\230\145\135\230\187\154]\230\184\184\231\142\169\230\140\135\229\174\154\230\173\140\230\155\178",
  icon = "Assets/Main/Sprites/ItemIcons/lyt_2025yinyuejie_chengbaopifu.png",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  get = function()
    return 1
  end,
  set = function(val)
  end,
  onClicked = function(val)
    local isEditor = true
    UIManager:GetInstance():OpenWindow(UIWindowNames.CrazyRockGame, nil, val, isEditor)
  end,
  contentType = 0,
  btnName = "\230\145\135\230\187\154"
})
config:Add({
  name = "\231\150\175\231\139\130\230\145\135\230\187\154\231\187\147\231\174\151\231\149\140\233\157\162",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_goumaijilu_anniu.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    local settleData = CrazyRockSettleData.New()
    UIManager:GetInstance():OpenWindow(UIWindowNames.UIActCrazyRockGameSettlement, {anim = true}, settleData)
  end,
  btnName = "\231\161\174\229\174\154"
})
config:Add({
  name = "\230\137\147\229\188\128\228\184\128\228\184\170\229\141\135\229\143\152\229\174\157\231\174\177",
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_goumaijilu_anniu.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    local data = {
      initQuality = 2,
      uid = "testbox001",
      origin = 1,
      progress = {
        4,
        6,
        6,
        6,
        6
      },
      state = 0,
      uuid = "testbox001",
      group = 1,
      quality = 4
    }
    local msg = {
      data = {data}
    }
    UIManager:GetInstance():DestroyWindow(UIWindowNames.UIGMPanel, {anim = true})
    DataCenter.UpgradeTreasureBoxManager:OnReceiveUpgradeTreasureBoxInfo(msg)
  end,
  btnName = "\231\161\174\229\174\154"
})
config:Add({
  name = "\232\129\148\231\155\159\229\175\185\229\134\179\232\129\148\232\181\155\230\174\181\228\189\141\229\177\149\231\164\186",
  icon = "Assets/Main/Sprites/UI/UIMain/LWMainUI/lrb_vsjin_icon.png",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("0: \229\185\179")
    sb:AppendLine("1: \229\141\135")
    sb:AppendLine("-1: \233\153\141")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return 0
  end,
  set = function(val)
  end,
  onClicked = function(params)
    local state = toInt(params)
    local last = SegmentType.Gold
    local cur = SegmentType.Gold
    if 0 < state then
      last = SegmentType.Silver
    elseif state < 0 then
      last = SegmentType.Diamond
    end
    DataCenter.LeagueMatchManager:OnRecvMyMatchInfoResp({
      duelInfo = {
        group = "2_1_1",
        rankType = cur,
        position = 0,
        roundResult = ""
      },
      lastDuelInfo = {
        group = "1_1_1",
        rankType = last,
        position = 2,
        roundResult = ""
      }
    })
    UIManager:GetInstance():DestroyWindow(UIWindowNames.UIGMPanel, {anim = true})
    UIManager:GetInstance():OpenWindow(UIWindowNames.UIAllyDuelLeagueGradeStatePop, {anim = false})
  end,
  btnName = "\231\161\174\229\174\154"
})
return config
