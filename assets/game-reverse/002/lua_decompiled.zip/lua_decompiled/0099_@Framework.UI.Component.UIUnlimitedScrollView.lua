﻿local UIUnlimitedScrollView = BaseClass("UnlimitedScrollView", UIBaseContainer)
local base = UIBaseContainer
local UnityUnlimitedScrollView = typeof(CS.GameKit.Base.UnlimitedScrollView)
local OnCreate = function(self)
  base.OnCreate(self)
  self.unity_unlimited_scroll_view = self.gameObject:GetComponent(UnityUnlimitedScrollView)
end
local ClearItemWraps = function(self)
  self.unity_unlimited_scroll_view:Clear()
end
local AddItemWrap = function(self, prefab, userdata)
  self.unity_unlimited_scroll_view:AddItemWrap(prefab, userdata)
end
local InsertItemWrap = function(self, index, prefab, userdata)
  self.unity_unlimited_scroll_view:InsertItemWrap(index, prefab, userdata)
end
local RemoveItemWrap = function(self, userdata)
  self.unity_unlimited_scroll_view:RemoveItemWrap(userdata)
end
local SetOnItemMoveIn = function(self, callback)
  self.unity_unlimited_scroll_view.OnItemMoveIn = callback
end
local SetOnItemMoveOut = function(self, callback)
  self.unity_unlimited_scroll_view.OnItemMoveOut = callback
end
local OnDestroy = function(self)
  self.unity_unlimited_scroll_view.OnItemMoveIn = nil
  self.unity_unlimited_scroll_view.OnItemMoveOut = nil
  self.unity_unlimited_scroll_view = nil
  base.OnDestroy(self)
end
UIUnlimitedScrollView.OnCreate = OnCreate
UIUnlimitedScrollView.ClearItemWraps = ClearItemWraps
UIUnlimitedScrollView.AddItemWrap = AddItemWrap
UIUnlimitedScrollView.InsertItemWrap = InsertItemWrap
UIUnlimitedScrollView.RemoveItemWrap = RemoveItemWrap
UIUnlimitedScrollView.SetOnItemMoveIn = SetOnItemMoveIn
UIUnlimitedScrollView.SetOnItemMoveOut = SetOnItemMoveOut
UIUnlimitedScrollView.OnDestroy = OnDestroy
return UIUnlimitedScrollView
