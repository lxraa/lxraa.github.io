﻿local UIExtraEffect = BaseClass("UIExtraEffect", UIBaseContainer)
local base = UIBaseContainer
local Localization = CS.GameEntry.Localization
local this_path = ""
local desc_path = "Desc"
local icon_path = "Icon"
local info_path = "Info"
local tip_path = "Tip"
local tip_close_path = "TipClose"
local tip_bg_path = "Tip/TipBg"
local reason_text_bg_path = "Tip/TipBg/ReasonTextBg"
local reason_left_text_path = "Tip/TipBg/ReasonTextBg/ReasonLeftText"
local reason_right_text_path = "Tip/TipBg/ReasonTextBg/ReasonLeftText/ReasonRightText"
local tip_text_bg_path = "Tip/TipBg/TipTextBg"
local tip_text_path = "Tip/TipBg/TipTextBg/TipText"
local station_btn_path = "Tip/TipBg/StationBtn"
local station_btn_text_path = "Tip/TipBg/StationBtn/StationBtnText"
local glow_path = "Glow"
local OnCreate = function(self)
  base.OnCreate(self)
  self:DataDefine()
  self:ComponentDefine()
end
local OnDestroy = function(self)
  self:ComponentDestroy()
  self:DataDestroy()
  base.OnDestroy(self)
end
local ComponentDefine = function(self)
  self.desc_text = self:AddComponent(UITweenNumberText, desc_path)
  self.icon_image = self:AddComponent(UIImage, icon_path)
  self.info_btn = self:AddComponent(UIButton, this_path)
  self.info_btn:SetOnClick(function()
    self:ShowTip(true)
  end)
  self.tip_anim = self:AddComponent(UIAnimator, tip_path)
  self.tip_close_btn = self:AddComponent(UIButton, tip_close_path)
  self.tip_close_btn:SetOnClick(function()
    self:ShowTip(false)
  end)
  self.tip_bg_go = self:AddComponent(UIBaseContainer, tip_bg_path)
  self.reason_text_bg = self:AddComponent(UIBaseContainer, reason_text_bg_path)
  self.reason_left_text = self:AddComponent(UIText, reason_left_text_path)
  self.reason_right_text = self:AddComponent(UIText, reason_right_text_path)
  self.tip_text_bg = self:AddComponent(UIBaseContainer, tip_text_bg_path)
  self.tip_text = self:AddComponent(UIText, tip_text_path)
  self.station_btn = self:AddComponent(UIButton, station_btn_path)
  self.station_btn:SetOnClick(function()
    self:OnStationBtnClick()
  end)
  self.station_image = self:AddComponent(UIImage, station_btn_path)
  self.station_btn_text = self:AddComponent(UIText, station_btn_text_path)
  self.station_btn_text:SetLocalText(110003)
  self.glow_go = self:AddComponent(UIBaseContainer, glow_path)
end
local ComponentDestroy = function(self)
  self.desc_text = nil
  self.icon_image = nil
  self.info_btn = nil
  self.tip_anim = nil
  self.tip_close_btn = nil
  self.tip_bg_go = nil
  self.reason_text_bg = nil
  self.reason_left_text = nil
  self.reason_right_text = nil
  self.tip_text_bg = nil
  self.tip_text = nil
  self.station_btn = nil
  self.station_image = nil
  self.station_btn_text = nil
  self.glow_go = nil
end
local DataDefine = function(self)
  self.effectType = nil
  self.stationId = nil
  self.view = nil
  self.showingTip = false
  self.val = 0
end
local DataDestroy = function(self)
  self.effectType = nil
  self.stationId = nil
  self.view = nil
  self.showingTip = nil
  self.val = nil
end
local OnAddListener = function(self)
  base.OnAddListener(self)
end
local OnRemoveListener = function(self)
  base.OnRemoveListener(self)
end
local OnEnable = function(self)
  base.OnEnable(self)
end
local OnDisable = function(self)
  base.OnDisable(self)
end
local SetData = function(self, effectType, view, closeFunc)
  if effectType == nil then
    self.gameObject:SetActive(false)
    return
  end
  DataCenter.HeroStationManager:ReCalcSkillAddition()
  local enabled = DataCenter.HeroStationManager:Enabled()
  local skillId = DataCenter.HeroStationManager:GetSkillIdByEffectType(effectType)
  local prefix, suffix = DataCenter.HeroStationManager:GetSkillEffectAffix(skillId)
  local tip = ""
  local val
  if enabled then
    val = Mathf.Round(DataCenter.HeroStationManager:GetSkillEffectValue(skillId))
    if effectType == HeroStationEffectType.GlobalMoney then
      tip = Localization:GetString("162101", val) .. "\n" .. Localization:GetString("162117")
    elseif effectType == HeroStationEffectType.StorageLimit then
      tip = Localization:GetString("162105", val) .. "\n" .. Localization:GetString("162117")
    elseif effectType == HeroStationEffectType.TradeCenterMoney then
    elseif effectType == HeroStationEffectType.HeroExp then
    end
  else
    val = math.floor(DataCenter.HeroStationManager:GetGameEffect(effectType))
    tip = Localization:GetString("162111")
  end
  self.val = val
  self.effectType = effectType
  self.view = view
  self.closeFunc = closeFunc
  self.stationId = DataCenter.HeroStationManager:GetStationIdBySkillId(skillId)
  self.icon_image:LoadSprite(DataCenter.HeroStationManager:GetSkillIcon(skillId))
  self.icon_image:SetNativeSize()
  self.tip_text:SetText(tip)
  self.gameObject:SetActive(true)
  self.glow_go:SetActive(false)
  self.station_btn:SetActive(enabled)
  self.tip_anim:SetActive(false)
  self.tip_close_btn:SetActive(false)
  self.showingTip = false
  local effect
  if effectType == HeroStationEffectType.GlobalMoney then
    effect = EffectDefine.GLOBAL_MONEY_EXTRA_PERCENT
  elseif effectType == HeroStationEffectType.StorageLimit then
    effect = EffectDefine.STORAGE_MAX_EXTRA
  elseif effectType == HeroStationEffectType.HeroExp then
    effect = EffectDefine.GLOBAL_HERO_EXP_EXTRA_PERCENT
  elseif effectType == HeroStationEffectType.TroopLimit then
    effect = EffectDefine.TROOP_LIMIT_EXTRA
  end
  if effect and LuaEntry.Effect.reasonEffectValues[effect] then
    local descStrList = {}
    local valueList = {}
    for reasonType, value in pairs(LuaEntry.Effect.reasonEffectValues[effect]) do
      local descStr = Localization:GetString(CommonUtil.GetEffectReasonDesc(reasonType))
      local v = prefix .. math.floor(value) .. suffix
      table.insert(descStrList, descStr)
      table.insert(valueList, v)
    end
    self.reason_left_text:SetText(string.join(descStrList, "\n"))
    self.reason_right_text:SetText(string.join(valueList, "\n"))
    self.reason_text_bg:SetActive(true)
  else
    self.reason_text_bg:SetActive(false)
  end
  self.desc_text:SetAffix(prefix, suffix)
  local oldVal = DataCenter.HeroStationManager:GetExtraEffectOldValByViewName(self.view.transform.name)
  if oldVal == nil or oldVal == val then
    self.desc_text:SetNum(val)
  else
    self.desc_text:FromNumTweenToNum(oldVal, val, 2)
    self.glow_go:SetActive(true)
  end
  DataCenter.HeroStationManager:SetExtraEffectOldValByViewName(self.view.transform.name, val)
end
local SetTip = function(self, tipText)
  self.tip_text:SetText(tipText)
end
local OnStationBtnClick = function(self)
  self:ShowTip(false)
  if self.stationId ~= nil then
    local stationId = self.stationId
    if self.closeFunc ~= nil then
      self.closeFunc(self.view)
    elseif self.view ~= nil then
      self.view.ctrl:CloseSelf()
    end
    UIUtil.OpenHeroStationByStationId(stationId)
  end
end
local ShowTip = function(self, show)
  if show == self.showingTip then
    return
  end
  if self.tip_text:GetText() == "" then
    return
  end
  self.showingTip = show
  local animName = show and "CommonPopup_movein" or "CommonPopup_moveout"
  self.tip_anim:SetActive(true)
  self.tip_anim:Play(animName, 0, 0)
  self.tip_close_btn:SetActive(show)
  self.station_image:SetRaycastTarget(show)
  TimerManager:GetInstance():DelayInvoke(function()
    CS.UnityEngine.UI.LayoutRebuilder.ForceRebuildLayoutImmediate(self.tip_bg_go.transform)
  end, 0.05)
end
UIExtraEffect.OnCreate = OnCreate
UIExtraEffect.OnDestroy = OnDestroy
UIExtraEffect.ComponentDefine = ComponentDefine
UIExtraEffect.ComponentDestroy = ComponentDestroy
UIExtraEffect.DataDefine = DataDefine
UIExtraEffect.DataDestroy = DataDestroy
UIExtraEffect.OnAddListener = OnAddListener
UIExtraEffect.OnRemoveListener = OnRemoveListener
UIExtraEffect.OnEnable = OnEnable
UIExtraEffect.OnDisable = OnDisable
UIExtraEffect.SetData = SetData
UIExtraEffect.SetTip = SetTip
UIExtraEffect.OnStationBtnClick = OnStationBtnClick
UIExtraEffect.ShowTip = ShowTip
return UIExtraEffect
