﻿local AllianceTaskTemplate = BaseClass("AllianceTaskTemplate")
local __init = function(self)
  self.id = 0
  self.taskId = 0
  self.unlock_time = 0
  self.name = ""
  self.desc = ""
  self.param = 0
  self.jump = 0
  self.func = 0
  self.type = 0
  self.funcIcon = ""
  self.funcName = ""
  self.funcDesc = ""
  self.param2 = ""
  self.quest_pic = ""
  self.icon = ""
end
local __delete = function(self)
  self.id = nil
  self.taskId = nil
  self.unlock_time = nil
  self.name = nil
  self.desc = nil
  self.param = nil
  self.jump = nil
  self.type = nil
  self.func = nil
  self.funcIcon = nil
  self.funcName = nil
  self.funcDesc = nil
  self.param2 = nil
  self.quest_pic = nil
  self.icon = nil
end
local InitData = function(self, row)
  if row == nil then
    return
  end
  self.id = tonumber(row:getValue("id"))
  self.taskId = self.id
  self.unlock_time = tonumber(row:getValue("unlock_time")) or 0
  self.name = row:getValue("name") or ""
  self.desc = row:getValue("description") or ""
  self.param = tonumber(row:getValue("para")) or 99
  self.jump = tonumber(row:getValue("jump")) or 0
  self.type = tonumber(row:getValue("type")) or 0
  self.func = tonumber(row:getValue("function")) or 0
  self.funcIcon = row:getValue("funcIcon") or ""
  self.funcName = row:getValue("funcName") or ""
  self.funcDesc = row:getValue("funcDesc") or ""
  self.param2 = row:getValue("para2") or ""
  self.quest_pic = row:getValue("quest_pic") or ""
  self.season_group = row:getIntValue("season_group", 0)
  self.icon = row:getValue("icon") or ""
end
AllianceTaskTemplate.__init = __init
AllianceTaskTemplate.__delete = __delete
AllianceTaskTemplate.InitData = InitData
return AllianceTaskTemplate
