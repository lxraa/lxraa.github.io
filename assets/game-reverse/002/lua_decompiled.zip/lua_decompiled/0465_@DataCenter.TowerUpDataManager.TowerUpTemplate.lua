﻿local base = require("DataCenter.TowerUpDataManager.TowerUpBaseTemplate")
local TowerUpTemplate = BaseClass("TowerUpTemplate", base)
local __init = function(self)
end
local __delete = function(self)
end
local InitData = function(self, row)
  base.InitData(self, row)
end
TowerUpTemplate.__init = __init
TowerUpTemplate.__delete = __delete
TowerUpTemplate.InitData = InitData
return TowerUpTemplate
