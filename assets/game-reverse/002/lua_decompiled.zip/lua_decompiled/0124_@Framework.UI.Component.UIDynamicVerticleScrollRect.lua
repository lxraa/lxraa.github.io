﻿local UIDynamicVerticleScrollRect = BaseClass("UIDynamicVerticleScrollRect", UIBaseContainer)
local base = UIBaseContainer
local UnityScrollRect = typeof(CS.DynamicVerticalScrollRect)
local OnCreate = function(self, ...)
  base.OnCreate(self)
  self.unity_UIDynamicVerticleScrollRect = self.gameObject:GetComponent(UnityScrollRect)
  self.__onInstantiateItemCallbacks = {}
  self.__onDisplayItemCallbacks = {}
  self.__onClearItemCallbacks = {}
end
local GetScrollRect = function(self)
  return self.unity_UIDynamicVerticleScrollRect
end
local OnDestroy = function(self)
  for _, callback in ipairs(self.__onInstantiateItemCallbacks) do
    self.unity_UIDynamicVerticleScrollRect:onInstantiateItem("-", callback)
  end
  self.__onInstantiateItemCallbacks = nil
  for _, callback in ipairs(self.__onDisplayItemCallbacks) do
    self.unity_UIDynamicVerticleScrollRect:onDisplayItem("-", callback)
  end
  self.__onDisplayItemCallbacks = nil
  for _, callback in ipairs(self.__onClearItemCallbacks) do
    self.unity_UIDynamicVerticleScrollRect:onClearItem("-", callback)
  end
  self.__onClearItemCallbacks = nil
  self.unity_UIDynamicVerticleScrollRect:Clear()
  self.unity_UIDynamicVerticleScrollRect = nil
  base.OnDestroy(self)
end
local SetEnable = function(self, value)
  self.unity_UIDynamicVerticleScrollRect.enabled = value
end
local SetDatas = function(self, prefabIdxs)
  self.unity_UIDynamicVerticleScrollRect:SetDatas(prefabIdxs)
end
local SetPaddingXY = function(self, paddingX, paddingY)
  self.unity_UIDynamicVerticleScrollRect.padding = Vector2(paddingX, paddingY)
end
local SetMarginXY = function(self, marginX, marginY)
  self.unity_UIDynamicVerticleScrollRect.margin = Vector2(marginX, marginY)
end
local SetItemSizeXY = function(self, itemSizeX, itemSizeY)
  self.unity_UIDynamicVerticleScrollRect.itemSize = Vector2(itemSizeX, itemSizeY)
end
local Clear = function(self)
  self.unity_UIDynamicVerticleScrollRect:Clear()
end
local FindItemByDataIdx = function(self, dataIdx)
  return self.unity_UIDynamicVerticleScrollRect:FindItemByDataIdx(dataIdx)
end
local GetScrollOffsetOfDataIdx = function(self, dataIdx, additionOffset)
  return self.unity_UIDynamicVerticleScrollRect:GetScrollOffsetOfDataIdx(dataIdx, additionOffset)
end
local SetScrollOffset = function(self, offset)
  self.unity_UIDynamicVerticleScrollRect:SetScrollOffset(offset)
end
local AddInstantiateItemListener = function(self, callback)
  self.unity_UIDynamicVerticleScrollRect:onInstantiateItem("+", callback)
  table.insert(self.__onInstantiateItemCallbacks, callback)
end
local AddDisplayItemListener = function(self, callback)
  self.unity_UIDynamicVerticleScrollRect:onDisplayItem("+", callback)
  table.insert(self.__onDisplayItemCallbacks, callback)
end
local AddClearItemListener = function(self, callback)
  self.unity_UIDynamicVerticleScrollRect:onClearItem("+", callback)
  table.insert(self.__onClearItemCallbacks, callback)
end
local RemoveInstantiateItemListener = function(self, callback)
  self.unity_UIDynamicVerticleScrollRect:onInstantiateItem("-", callback)
  table.removebyvalue(self.__onInstantiateItemCallbacks, callback)
end
local RemoveDisplayItemListener = function(self, callback)
  self.unity_UIDynamicVerticleScrollRect:onDisplayItem("-", callback)
  table.removebyvalue(self.__onDisplayItemCallbacks, callback)
end
local RemoveClearItemListener = function(self, callback)
  self.unity_UIDynamicVerticleScrollRect:onClearItem("-", callback)
  table.removebyvalue(self.__onClearItemCallbacks, callback)
end
local SetMovementType = function(self, movementType)
  self.unity_UIDynamicVerticleScrollRect.movementType = movementType
end
local UpdateItems = function(self)
  self.unity_UIDynamicVerticleScrollRect:UpdateItems()
end
UIDynamicVerticleScrollRect.OnCreate = OnCreate
UIDynamicVerticleScrollRect.OnDestroy = OnDestroy
UIDynamicVerticleScrollRect.SetEnable = SetEnable
UIDynamicVerticleScrollRect.SetDatas = SetDatas
UIDynamicVerticleScrollRect.SetPaddingXY = SetPaddingXY
UIDynamicVerticleScrollRect.SetMarginXY = SetMarginXY
UIDynamicVerticleScrollRect.SetItemSizeXY = SetItemSizeXY
UIDynamicVerticleScrollRect.Clear = Clear
UIDynamicVerticleScrollRect.FindItemByDataIdx = FindItemByDataIdx
UIDynamicVerticleScrollRect.GetScrollOffsetOfDataIdx = GetScrollOffsetOfDataIdx
UIDynamicVerticleScrollRect.SetScrollOffset = SetScrollOffset
UIDynamicVerticleScrollRect.AddInstantiateItemListener = AddInstantiateItemListener
UIDynamicVerticleScrollRect.AddDisplayItemListener = AddDisplayItemListener
UIDynamicVerticleScrollRect.AddClearItemListener = AddClearItemListener
UIDynamicVerticleScrollRect.RemoveInstantiateItemListener = RemoveInstantiateItemListener
UIDynamicVerticleScrollRect.RemoveDisplayItemListener = RemoveDisplayItemListener
UIDynamicVerticleScrollRect.RemoveClearItemListener = RemoveClearItemListener
UIDynamicVerticleScrollRect.GetScrollRect = GetScrollRect
UIDynamicVerticleScrollRect.SetMovementType = SetMovementType
UIDynamicVerticleScrollRect.UpdateItems = UpdateItems
return UIDynamicVerticleScrollRect
