﻿local BirthPointTemplate = BaseClass("BirthPointTemplate")
local __init = function(self)
  self.id = 0
  self.x = 0
  self.y = 0
end
local __delete = function(self)
  self.id = nil
  self.x = nil
  self.y = nil
end
local InitData = function(self, row)
  if row == nil then
    return
  end
  self.id = row:getValue("id")
  self.x = row:getValue("X")
  self.y = row:getValue("Y")
end
BirthPointTemplate.__init = __init
BirthPointTemplate.__delete = __delete
BirthPointTemplate.InitData = InitData
return BirthPointTemplate
