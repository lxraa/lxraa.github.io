﻿EGameQualityConfig_V1 = {}
EGameQualityConfig_V1[1] = {
  Basic = EGameFeatureQuality.Low,
  Shadow = EGameFeatureQuality.Low,
  AA = EGameFeatureQuality.Low,
  Material = EGameFeatureQuality.Low,
  PostProcess = EGameFeatureQuality.Low,
  Terrain = EGameFeatureQuality.Low,
  Particle = EGameFeatureQuality.Low,
  Animation = EGameFeatureQuality.Low,
  Logic = EGameFeatureQuality.Low
}
EGameQualityConfig_V1[2] = {
  Basic = EGameFeatureQuality.Low,
  Shadow = EGameFeatureQuality.Low,
  AA = EGameFeatureQuality.Low,
  Material = EGameFeatureQuality.Low,
  PostProcess = EGameFeatureQuality.Low,
  Terrain = EGameFeatureQuality.Low,
  Particle = EGameFeatureQuality.Low,
  Animation = EGameFeatureQuality.Low,
  Logic = EGameFeatureQuality.Low
}
EGameQualityConfig_V1[3] = {
  Basic = EGameFeatureQuality.Mid,
  Shadow = EGameFeatureQuality.High,
  AA = EGameFeatureQuality.Low,
  Material = EGameFeatureQuality.Mid,
  PostProcess = EGameFeatureQuality.Mid,
  Terrain = EGameFeatureQuality.Mid,
  Particle = EGameFeatureQuality.Mid,
  Animation = EGameFeatureQuality.Mid,
  Logic = EGameFeatureQuality.Mid
}
EGameQualityConfig_V1[4] = {
  Basic = EGameFeatureQuality.Mid,
  Shadow = EGameFeatureQuality.High,
  AA = EGameFeatureQuality.Low,
  Material = EGameFeatureQuality.Mid,
  PostProcess = EGameFeatureQuality.Mid,
  Terrain = EGameFeatureQuality.Mid,
  Particle = EGameFeatureQuality.Mid,
  Animation = EGameFeatureQuality.Mid,
  Logic = EGameFeatureQuality.Mid
}
EGameQualityConfig_V1[5] = {
  Basic = EGameFeatureQuality.Mid,
  Shadow = EGameFeatureQuality.High,
  AA = EGameFeatureQuality.Low,
  Material = EGameFeatureQuality.Mid,
  PostProcess = EGameFeatureQuality.Mid,
  Terrain = EGameFeatureQuality.Mid,
  Particle = EGameFeatureQuality.Mid,
  Animation = EGameFeatureQuality.Mid,
  Logic = EGameFeatureQuality.Mid
}
EGameQualityConfig_V1[6] = {
  Basic = EGameFeatureQuality.High,
  Shadow = EGameFeatureQuality.High,
  AA = EGameFeatureQuality.High,
  Material = EGameFeatureQuality.High,
  PostProcess = EGameFeatureQuality.High,
  Terrain = EGameFeatureQuality.High,
  Particle = EGameFeatureQuality.High,
  Animation = EGameFeatureQuality.High,
  Logic = EGameFeatureQuality.High
}
EGameQualityConfig_V1[7] = {
  Basic = EGameFeatureQuality.High,
  Shadow = EGameFeatureQuality.High,
  AA = EGameFeatureQuality.High,
  Material = EGameFeatureQuality.High,
  PostProcess = EGameFeatureQuality.High,
  Terrain = EGameFeatureQuality.High,
  Particle = EGameFeatureQuality.High,
  Animation = EGameFeatureQuality.High,
  Logic = EGameFeatureQuality.High
}
EGameQualityConfig_V1.Default = EGameQualityConfig_V1[4]
EGameQualityConfig_V1.Low = 2
EGameQualityConfig_V1.Mid = 4
EGameQualityConfig_V1.High = 6
EGameQualityConfig_V1.DefaultLevel = 4
EGameDeviceQualityConfig_V1 = {}
EGameDeviceQualityConfig_V1[EDeviceLevel.Unknown] = {
  [EGameQuality.Low] = 2,
  [EGameQuality.Mid] = 4,
  [EGameQuality.High] = 6,
  [EGameQuality.Default] = 4
}
EGameDeviceQualityConfig_V1[EDeviceLevel.UltraLow] = {
  [EGameQuality.Low] = 2,
  [EGameQuality.Mid] = 4,
  [EGameQuality.High] = 6,
  [EGameQuality.Default] = 4
}
EGameDeviceQualityConfig_V1[EDeviceLevel.Low] = {
  [EGameQuality.Low] = 2,
  [EGameQuality.Mid] = 4,
  [EGameQuality.High] = 6,
  [EGameQuality.Default] = 4
}
EGameDeviceQualityConfig_V1[EDeviceLevel.MidLow] = {
  [EGameQuality.Low] = 2,
  [EGameQuality.Mid] = 4,
  [EGameQuality.High] = 6,
  [EGameQuality.Default] = 4
}
EGameDeviceQualityConfig_V1[EDeviceLevel.Mid] = {
  [EGameQuality.Low] = 2,
  [EGameQuality.Mid] = 4,
  [EGameQuality.High] = 6,
  [EGameQuality.Default] = 4
}
EGameDeviceQualityConfig_V1[EDeviceLevel.MidHigh] = {
  [EGameQuality.Low] = 2,
  [EGameQuality.Mid] = 4,
  [EGameQuality.High] = 6,
  [EGameQuality.Default] = 4
}
EGameDeviceQualityConfig_V1[EDeviceLevel.High] = {
  [EGameQuality.Low] = 2,
  [EGameQuality.Mid] = 4,
  [EGameQuality.High] = 6,
  [EGameQuality.Default] = 6
}
EGameDeviceQualityConfig_V1[EDeviceLevel.UltraHigh] = {
  [EGameQuality.Low] = 2,
  [EGameQuality.Mid] = 4,
  [EGameQuality.High] = 6,
  [EGameQuality.Default] = 6
}
