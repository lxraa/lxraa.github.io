﻿local GridInfinityScrollView = BaseClass("GridInfinityScrollView", UIBaseComponent)
local base = UIBaseComponent
local UnityScrollView = typeof(CS.GridInfinityScrollView)
local OnCreate = function(self)
  base.OnCreate(self)
  self.content = self.gameObject:GetComponent(UnityScrollView)
end
local OnDestroy = function(self)
  self.content:Dispose()
  self.content = nil
  base.OnDestroy(self)
end
local Init = function(self, action1, action2, action3, obj)
  self.content:Init(action1, action2, action3, obj)
end
local SetMaxCount = function(self, maxCount)
  if maxCount and 0 < maxCount then
    self.content.MaxCount = maxCount
  end
end
local Dispose = function(self)
  self.content:Dispose()
end
local SetItemCount = function(self, itemCount)
  self.content:SetItemCount(itemCount)
end
local LaterItemByIndex = function(self, index, time, itemCount)
  self.content:LaterItemByIndex(index, time, itemCount)
end
local Remark = function(self, itemCount)
  self.content:SetItemCount(itemCount)
end
local ForceUpdate = function(self)
  self.content:ForceUpdate()
end
local MoveItemByIndex = function(self, index, delay)
  self.content:MoveItemByIndex(index, delay)
end
local GetRenderItemSizeY = function(self)
  return self.content:GetRenderItemSizeY()
end
local RefreshMaskSize = function(self)
  return self.content:RefreshMaskSize()
end
GridInfinityScrollView.OnCreate = OnCreate
GridInfinityScrollView.OnDestroy = OnDestroy
GridInfinityScrollView.Init = Init
GridInfinityScrollView.Dispose = Dispose
GridInfinityScrollView.LaterItemByIndex = LaterItemByIndex
GridInfinityScrollView.ForceUpdate = ForceUpdate
GridInfinityScrollView.SetItemCount = SetItemCount
GridInfinityScrollView.Remark = Remark
GridInfinityScrollView.MoveItemByIndex = MoveItemByIndex
GridInfinityScrollView.GetRenderItemSizeY = GetRenderItemSizeY
GridInfinityScrollView.RefreshMaskSize = RefreshMaskSize
GridInfinityScrollView.SetMaxCount = SetMaxCount
return GridInfinityScrollView
