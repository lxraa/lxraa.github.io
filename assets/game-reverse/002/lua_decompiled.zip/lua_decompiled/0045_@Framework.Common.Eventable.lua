﻿CEventable = BaseClass("CEventable")

function CEventable:__init()
  self._register_events = {}
end

function CEventable:__delete()
  for k, v in pairs(self._register_events) do
    EventManager:GetInstance():RemoveListener2(k, v, self)
  end
  self._register_events = {}
end

function CEventable:RegisterEvent(id, func)
  local v = self._register_events[id]
  if v ~= nil then
    return
  end
  EventManager:GetInstance():AddListenerWithSelf(id, func, self)
  self._register_events[id] = func
end

function CEventable:UnregisterEvent(id)
  local v = self._register_events[id]
  if v == nil then
    return
  end
  EventManager:GetInstance():RemoveListener2(id, v, self)
  self._register_events[id] = nil
end
