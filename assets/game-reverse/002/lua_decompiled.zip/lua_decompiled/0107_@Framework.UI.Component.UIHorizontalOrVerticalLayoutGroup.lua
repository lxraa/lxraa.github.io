﻿local UIHorizontalOrVerticalLayoutGroup = BaseClass("UIHorizontalOrVerticalLayoutGroup", UIBaseContainer)
local base = UIBaseContainer
local UnityHorizontalOrVerticalLayoutGroup = typeof(CS.UnityEngine.UI.HorizontalOrVerticalLayoutGroup)
local OnCreate = function(self, ...)
  base.OnCreate(self)
  self.unity_horizontalOrVerticalLayoutGroup = self.gameObject:GetComponent(UnityHorizontalOrVerticalLayoutGroup)
end
local OnDestroy = function(self)
  self.unity_horizontalOrVerticalLayoutGroup = nil
  base.OnDestroy(self)
end
local GetPadding = function(self)
  return self.unity_horizontalOrVerticalLayoutGroup.padding
end
local GetSpacing = function(self)
  return self.unity_horizontalOrVerticalLayoutGroup.spacing
end
local SetSpacing = function(self, value)
  self.unity_horizontalOrVerticalLayoutGroup.spacing = value
end
local SetPaddingLeft = function(self, value)
  self.unity_horizontalOrVerticalLayoutGroup.padding.left = value
end
local SetPaddingRight = function(self, value)
  self.unity_horizontalOrVerticalLayoutGroup.padding.right = value
end
local SetPaddingTop = function(self, value)
  self.unity_horizontalOrVerticalLayoutGroup.padding.top = value
end
local SetPaddingBottom = function(self, value)
  self.unity_horizontalOrVerticalLayoutGroup.padding.bottom = value
end

function UIHorizontalOrVerticalLayoutGroup:ChildControlHeight(value)
  self.unity_horizontalOrVerticalLayoutGroup.childControlHeight = value
end

function UIHorizontalOrVerticalLayoutGroup:ChildControlWidth(value)
  self.unity_horizontalOrVerticalLayoutGroup.childControlWidth = value
end

UIHorizontalOrVerticalLayoutGroup.OnCreate = OnCreate
UIHorizontalOrVerticalLayoutGroup.OnDestroy = OnDestroy
UIHorizontalOrVerticalLayoutGroup.GetPadding = GetPadding
UIHorizontalOrVerticalLayoutGroup.GetSpacing = GetSpacing
UIHorizontalOrVerticalLayoutGroup.SetSpacing = SetSpacing
UIHorizontalOrVerticalLayoutGroup.SetPaddingLeft = SetPaddingLeft
UIHorizontalOrVerticalLayoutGroup.SetPaddingRight = SetPaddingRight
UIHorizontalOrVerticalLayoutGroup.SetPaddingTop = SetPaddingTop
UIHorizontalOrVerticalLayoutGroup.SetPaddingBottom = SetPaddingBottom
return UIHorizontalOrVerticalLayoutGroup
