﻿local UIGradient = BaseClass("UIGradient", UIBaseComponent)
local base = UIBaseComponent
local UnityGradient = typeof(CS.UnityEngine.UI.Gradient)
local OnCreate = function(self)
  base.OnCreate(self)
  self.unity_gradient = self.gameObject:GetComponent(UnityGradient)
end
local OnDestroy = function(self)
  self.unity_gradient = nil
  base.OnDestroy(self)
end
local SetOffset = function(self, offset)
  if not IsNull(self.unity_gradient) then
    self.unity_gradient.Offset = offset
  end
end
local Enable = function(self, value)
  if not IsNull(self.unity_gradient) then
    self.unity_gradient.enabled = value
  end
end
UIGradient.OnCreate = OnCreate
UIGradient.OnDestroy = OnDestroy
UIGradient.SetOffset = SetOffset
UIGradient.Enable = Enable
return UIGradient
