﻿local UnitAttrInfo = BaseClass("UnitAttrInfo")
local ArmyAttrInfo = require("DataCenter.MailData.BattleReport.UnitAttrInfo.ArmyAttrInfo")

function UnitAttrInfo:InitData(unitAttrInfo)
  self.uuid = unitAttrInfo.uuid
  self.atkInfoList = {}
  local atkList = unitAttrInfo.atkInfo
  for _, v in pairs(atkList) do
    local oneData = ArmyAttrInfo.New()
    oneData:InitData(v)
    if oneData.reason ~= nil then
      self.atkInfoList[oneData.reason] = oneData
    end
  end
  self.defInfoList = {}
  local defList = unitAttrInfo.defInfo
  for _, v in pairs(defList) do
    local oneData = ArmyAttrInfo.New()
    oneData:InitData(v)
    if oneData.reason ~= nil then
      self.defInfoList[oneData.reason] = oneData
    end
  end
end

function UnitAttrInfo:GetAtkAttrByType(reason)
  if self.atkInfoList[reason] ~= nil then
    return self.atkInfoList[reason].value
  end
  return 0
end

function UnitAttrInfo:GetDefAttrByType(reason)
  if self.defInfoList[reason] ~= nil then
    return self.defInfoList[reason].value
  end
  return 0
end

return UnitAttrInfo
