﻿local AllianceMarkData = BaseClass("AllianceMarkData")
local Localization = CS.GameEntry.Localization
local __init = function(self)
  self.uid = 0
  self.userName = ""
  self.allianceId = ""
  self.type = 0
  self.pos = 0
  self.server = 0
  self.worldId = 0
  self.name = ""
  self.createTime = 0
  self.translateMsg = ""
  self.translateLanguage = ""
  self.isTranslating = false
  self.tanslateFinish = 0
  self.TranslateManager = nil
  self.startTime = 0
end
local __delete = function(self)
  self:Destroy()
end
local Destroy = function(self)
  self.uid = nil
  self.userName = nil
  self.allianceId = nil
  self.type = nil
  self.pos = nil
  self.server = nil
  self.name = nil
  self.createTime = nil
  self.pointInfo = nil
end
local ParseData = function(self, msg)
  if not msg then
    return
  end
  if msg.uid then
    self.uid = msg.uid
  end
  if msg.userName then
    self.userName = msg.userName
  end
  if msg.allianceId then
    self.allianceId = msg.allianceId
  end
  if msg.markType then
    self.type = msg.markType
  end
  if msg.point then
    self.pos = msg.point
  end
  if msg.serverId then
    self.server = msg.serverId
  end
  if msg.worldId then
    self.worldId = msg.worldId
  end
  if msg.markName then
    self.name = msg.markName
  end
  if msg.markTime then
    self.createTime = msg.markTime
  end
  if msg.allianceName then
    self.allianceName = msg.allianceName
  end
  if msg.allianceAbbr then
    self.allianceAbbr = msg.allianceAbbr
  end
  if msg.startTime then
    self.startTime = msg.startTime
  end
  if msg.notice then
    self.notice = msg.notice
  end
  if msg.pointInfo then
    self.pointInfo = msg.pointInfo
  end
end
local IsSelfAlliance = function(self)
  local selfAllianceId = LuaEntry.Player.allianceId
  return self.allianceId == selfAllianceId
end
local GetPrefabPath = function(self)
  if self:IsSelfAlliance() then
    return self.type == MarkType.Alliance_OtherServerRally and UIAssets.S5AllianceOtherServerRallyMark or UIAssets.AllianceWorldRallyMark
  else
    return UIAssets.OtherAllianceWorldRallyMark
  end
end
local SetTranslationMsg = function(self, translateMsg)
  self.translateMsg = translateMsg
end
local GetTranslationMsg = function(self)
  return self.translateMsg
end
local SetIsTranslating = function(self, translatingFlag)
  self.isTranslating = translatingFlag
end
local GetIsTranslating = function(self)
  return self.isTranslating
end
local SetTranslateLanguage = function(self, language)
  self.language = language
end
local SetTranslateFinishState = function(self, state)
  self.tanslateFinish = state
end
local GetTranslateFinishState = function(self)
  return self.tanslateFinish
end
local DoTranslate = function(self)
  self.TranslateManager:Translate(self, self.TranslateManager.TranslateEnum.AllianceMark)
end
local GetMessage = function(self)
  if self.type == 100 then
    return Localization:GetString(self.name)
  else
    return self.name
  end
end
local GetLanguageName = function(self)
  return self.language
end
local SetLanguageName = function(self, language)
  self.language = language
end
local SetTranslateHandler = function(self, translateHandler)
  self.TranslateManager = translateHandler
end

function AllianceMarkData:GetPointIndex()
  return self.pos // 10
end

AllianceMarkData.__init = __init
AllianceMarkData.__delete = __delete
AllianceMarkData.Destroy = Destroy
AllianceMarkData.ParseData = ParseData
AllianceMarkData.IsSelfAlliance = IsSelfAlliance
AllianceMarkData.GetPrefabPath = GetPrefabPath
AllianceMarkData.SetTranslationMsg = SetTranslationMsg
AllianceMarkData.GetTranslationMsg = GetTranslationMsg
AllianceMarkData.SetIsTranslating = SetIsTranslating
AllianceMarkData.GetIsTranslating = GetIsTranslating
AllianceMarkData.SetTranslateLanguage = SetTranslateLanguage
AllianceMarkData.DoTranslate = DoTranslate
AllianceMarkData.SetTranslateFinishState = SetTranslateFinishState
AllianceMarkData.GetTranslateFinishState = GetTranslateFinishState
AllianceMarkData.GetMessage = GetMessage
AllianceMarkData.GetLanguageName = GetLanguageName
AllianceMarkData.SetLanguageName = SetLanguageName
AllianceMarkData.SetTranslateHandler = SetTranslateHandler
return AllianceMarkData
