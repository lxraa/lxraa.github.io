﻿local ActivityEventRankRewardInfo = BaseClass("ActivityEventRankRewardInfo")
local __init = function(self)
  self.actId = ""
  self.rankRwdMap = {}
  self.rankIdMap = {}
end
local __delete = function(self)
  self.actId = nil
  self.rankRwdMap = nil
  self.rankIdMap = nil
end
local ParseData = function(self, message)
  if message == nil then
    return
  end
  if message.actId ~= nil then
    self.actId = message.actId
  end
  if message.rewardArr ~= nil and message.levelArr ~= nil and message.reward ~= nil then
    local tmpRwdVec = string.split(message.rewardArr, "|")
    local tmpRankVec = string.split(message.levelArr, "|")
    local rewardList = message.reward
    if table.length(rewardList) == #tmpRankVec and #tmpRankVec == #tmpRwdVec then
      self.rankRwdMap = {}
      self.rankIdMap = {}
      for i = 1, table.length(rewardList) do
        local rewardArr = DataCenter.RewardManager:ReturnRewardParamForView(rewardList[i])
        local key = tonumber(tmpRankVec[i])
        local rewardId = tmpRwdVec[i]
        self.rankRwdMap[key] = rewardArr
        self.rankIdMap[key] = rewardId
      end
    end
  end
end
ActivityEventRankRewardInfo.__init = __init
ActivityEventRankRewardInfo.__delete = __delete
ActivityEventRankRewardInfo.ParseData = ParseData
return ActivityEventRankRewardInfo
