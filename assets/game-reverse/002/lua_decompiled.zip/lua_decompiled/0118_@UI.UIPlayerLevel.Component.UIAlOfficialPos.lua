﻿local UIAlOfficialPos = BaseClass("UIAlOfficialPos", UIBaseContainer)
local base = UIBaseContainer
local root_path = "Root"
local name_path = "Root/Name"
local level_path = "Root/Level"
local OnCreate = function(self)
  base.OnCreate(self)
  self:DataDefine()
  self:ComponentDefine()
end
local OnDestroy = function(self)
  self:ComponentDestroy()
  self:DataDestroy()
  base.OnDestroy(self)
end
local ComponentDefine = function(self)
  self.root_image = self:AddComponent(UIImage, root_path)
  self.name_text = self:AddComponent(UIText, name_path)
end
local ComponentDestroy = function(self)
  self.root_image = nil
  self.name_text = nil
end
local DataDefine = function(self)
  self.active = true
end
local DataDestroy = function(self)
  self.active = nil
end
local OnAddListener = function(self)
  base.OnAddListener(self)
end
local OnRemoveListener = function(self)
  base.OnRemoveListener(self)
end
local OnEnable = function(self)
  base.OnEnable(self)
end
local OnDisable = function(self)
  base.OnDisable(self)
end
local SetData = function(self, chatUserInfo)
  local officialPos = DataCenter.AllianceMemberDataManager:GetOfficialPosByUid(chatUserInfo.uid)
  if officialPos then
    self:SetActive(true)
    self.name_text:SetLocalText(AllianceOfficialPosConf[officialPos].name)
    self.active = true
  else
    self:SetActive(false)
    self.active = false
  end
end
local IsActive = function(self)
  return self.active
end
UIAlOfficialPos.OnCreate = OnCreate
UIAlOfficialPos.OnDestroy = OnDestroy
UIAlOfficialPos.ComponentDefine = ComponentDefine
UIAlOfficialPos.ComponentDestroy = ComponentDestroy
UIAlOfficialPos.DataDefine = DataDefine
UIAlOfficialPos.DataDestroy = DataDestroy
UIAlOfficialPos.OnAddListener = OnAddListener
UIAlOfficialPos.OnRemoveListener = OnRemoveListener
UIAlOfficialPos.OnEnable = OnEnable
UIAlOfficialPos.OnDisable = OnDisable
UIAlOfficialPos.SetData = SetData
UIAlOfficialPos.IsActive = IsActive
return UIAlOfficialPos
