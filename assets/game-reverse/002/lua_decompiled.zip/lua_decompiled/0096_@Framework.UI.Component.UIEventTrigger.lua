﻿local UIEventTrigger = BaseClass("UIEventTrigger", UIBaseContainer)
local base = UIBaseContainer
local CSUIEventTrigger = typeof(CS.UIEventTrigger)
local OnCreate = function(self, ...)
  base.OnCreate(self)
  self.unity_event_trigger = self.gameObject:GetComponent(CSUIEventTrigger)
end
local OnDestroy = function(self)
  self.unity_event_trigger.onDrag = nil
  self.unity_event_trigger.onBeginDrag = nil
  self.unity_event_trigger.onEndDrag = nil
  self.unity_event_trigger.onPointerDown = nil
  self.unity_event_trigger.onPointerUp = nil
  self.unity_event_trigger.onPointerEnter = nil
  self.unity_event_trigger.onPointerExit = nil
  self.unity_event_trigger.onPointerClick = nil
  self.unity_event_trigger.onLongPress = nil
  self.unity_event_trigger = nil
  base.OnDestroy(self)
end
local OnDrag = function(self, onDrag)
  self.unity_event_trigger.onDrag = onDrag
end
local OnBeginDrag = function(self, onBeginDrag)
  self.unity_event_trigger.onBeginDrag = onBeginDrag
end
local OnEndDrag = function(self, onEndDrag)
  self.unity_event_trigger.onEndDrag = onEndDrag
end
local OnPointerDown = function(self, onPointerDown)
  self.unity_event_trigger.onPointerDown = onPointerDown
end
local OnPointerUp = function(self, onPointerUp)
  self.unity_event_trigger.onPointerUp = onPointerUp
end
local OnPointerEnter = function(self, onPointerEnter)
  self.unity_event_trigger.onPointerEnter = onPointerEnter
end
local OnPointerExit = function(self, onPointerExit)
  self.unity_event_trigger.onPointerExit = onPointerExit
end
local OnPointerClick = function(self, onPointerClick)
  self.unity_event_trigger.onPointerClick = onPointerClick
end
local onLongPress = function(self, onLongPress)
  self.unity_event_trigger.onLongPress = onLongPress
end
UIEventTrigger.OnCreate = OnCreate
UIEventTrigger.OnDestroy = OnDestroy
UIEventTrigger.OnDrag = OnDrag
UIEventTrigger.OnBeginDrag = OnBeginDrag
UIEventTrigger.OnEndDrag = OnEndDrag
UIEventTrigger.OnPointerDown = OnPointerDown
UIEventTrigger.OnPointerUp = OnPointerUp
UIEventTrigger.OnPointerEnter = OnPointerEnter
UIEventTrigger.OnPointerExit = OnPointerExit
UIEventTrigger.OnPointerClick = OnPointerClick
UIEventTrigger.onLongPress = onLongPress
return UIEventTrigger
