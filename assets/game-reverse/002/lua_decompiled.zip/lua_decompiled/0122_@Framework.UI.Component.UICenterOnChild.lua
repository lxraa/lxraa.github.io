﻿local UICenterOnChild = BaseClass("UICenterOnChild", UIBaseComponent)
local base = UIBaseComponent
local CenterOnChild = typeof(CS.CenterOnChild)
local OnCreate = function(self)
  base.OnCreate(self)
  self.CenterOnChild = self.gameObject:GetComponent(CenterOnChild)
end
local OnDestroy = function(self)
  self.CenterOnChild = nil
  base.OnDestroy(self)
end
local Reset = function(self)
  self.CenterOnChild:Reset()
end
UICenterOnChild.OnCreate = OnCreate
UICenterOnChild.OnDestroy = OnDestroy
UICenterOnChild.Reset = Reset
return UICenterOnChild
