﻿local RadarImage = BaseClass("RadarImage", UIBaseComponent)
local base = UIBaseComponent
local UnityImage = typeof(CS.RadarImage)
local OnCreate = function(self)
  base.OnCreate(self)
  self.unity_image = self.gameObject:GetComponent(UnityImage)
end
local SetDemensions = function(self, demensions)
  self.unity_image:SetDemensions(demensions)
end
local SetValues = function(self, values)
  self.unity_image:SetValues(values)
end
local OnDestroy = function(self)
  self.unity_image = nil
  base.OnDestroy(self)
end
RadarImage.OnCreate = OnCreate
RadarImage.SetDemensions = SetDemensions
RadarImage.SetValues = SetValues
RadarImage.OnDestroy = OnDestroy
return RadarImage
