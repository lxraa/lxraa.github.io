﻿local LittleRedConst = {}
LittleRedConst.NameActEpidemicMain = "EpidemicMain"
LittleRedConst.NameActEpidemicMainApply = "EpidemicMainApply"
LittleRedConst.NameActEpidemicMainFight = "EpidemicMainFight"
LittleRedConst.NameActEpidemicMainArbiterNotSet = "EpidemicMainArbiterNotSet"
LittleRedConst.NameActEpidemicMainCommanderNotSet = "EpidemicMainCommanderNotSet"
LittleRedConst.NameActEpidemicOther = "EpidemicOther"
LittleRedConst.NameActEpidemicMainContact = "EpidemicMainContact"
LittleRedConst.NameActEpidemicMainLordSkill = "ActEpidemicMainLordSkill"
return ConstClass("LittleRedConst", LittleRedConst)
