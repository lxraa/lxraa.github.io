﻿local GMPageStyle = require("UI.UIGMPanel.Configs.GMPageStyle")
local GMPageConfig = require("UI.UIGMPanel.Configs.GMPageConfig")
local config = GMPageConfig.New("OtherDebug")
config.style = GMPageStyle.PageTemplate.Vertical
config.order = 10
config.label = "\229\133\182\228\187\150"
config.icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/mjc_S3_shijie_lvhua.png"
config:Add({
  name = "\230\137\147\229\141\176\232\189\166\229\186\147\228\189\156\231\148\168\229\143\183\232\174\161\231\174\151\232\191\135\231\168\139",
  icon = "Assets/Main/Sprites/UI/UIBuildBtns/uibuild_btn_tank.png",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  get = function()
    return GMUtils.GetBool(GMConst.ShowParkEffectNumberLog, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.ShowParkEffectNumberLog, val)
    UIUtil.ShowTips(val and "\229\188\128\229\144\175" or "\229\133\179\233\151\173")
  end
})
config:Add({
  name = "\231\130\185\231\169\186\229\156\176\230\137\147\229\188\128\230\142\167\229\136\182\229\143\176",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  icon = "Assets/Main/Sprites/UI/UIDecoration/base_effect_pifu1.png",
  tips = function()
    local sb = StringBuilder.New()
    sb:AppendLine("\229\156\168\229\134\133\229\159\142\228\184\173\231\130\185\229\135\187\231\169\186\229\156\176\228\184\128\231\153\190\230\172\161\229\144\142\229\143\175\228\187\165\230\137\147\229\188\128\230\142\167\229\136\182\229\143\176\227\128\130")
    sb:AppendLine("\233\156\128\232\166\129\229\156\1682\231\167\146\229\134\133\231\130\185\229\174\140\229\147\166~")
    sb:AppendLine("\226\153\170\226\153\169\226\153\170\226\153\169")
    UIUtil.ShowDetail(sb:ToString(), nil, nil, true, true)
  end,
  get = function()
    return GMUtils.GetBool(GMConst.DebugClickEmptyRunCmd, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.DebugClickEmptyRunCmd, val)
    UIUtil.ShowTips(val and "\231\130\185\229\135\187\231\169\186\229\156\176\229\143\175\228\187\165\229\144\175\229\138\168\230\142\167\229\136\182\229\143\176" or "\231\130\185\229\135\187\231\169\186\229\156\176\229\176\134\228\184\141\229\134\141\229\144\175\229\138\168\230\142\167\229\136\182\229\143\176")
  end
})
config:Add({
  name = "\229\164\150\231\189\145\230\160\185\230\141\174\230\136\152\230\138\165id\230\137\147\229\188\128\230\140\135\229\174\154\230\136\152\230\138\165",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  icon = "Assets/Main/Sprites/ItemIcons/icon_kelongxinpian_1.png",
  get = function()
    return 1
  end,
  set = function(val)
  end,
  onClicked = function(val)
    BattleReportUtil.ShowBattleReport(val)
  end,
  contentType = 0,
  btnName = "\229\188\128\229\167\139\230\136\152\230\150\151"
})
config:Add({
  name = "\229\134\133\231\189\145\230\160\185\230\141\174\230\136\152\230\138\165id\230\137\147\229\188\128\230\140\135\229\174\154\230\136\152\230\138\165",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  get = function()
    return 1
  end,
  set = function(val)
  end,
  onClicked = function(val)
    BattleReportUtil.ShowLocalBattleReport(val)
  end,
  contentType = 0,
  btnName = "\229\188\128\229\167\139\230\136\152\230\150\151",
  icon = "Assets/Main/Sprites/ItemIcons/icon_kelongxinpian_1.png"
})
config:Add({
  name = "\230\160\185\230\141\174id\232\191\155\229\133\165PVE\229\133\179\229\141\161",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  get = function()
    return 101
  end,
  set = function(val)
  end,
  onClicked = function(val)
    DataCenter.LWBattleManager:JumpLevel(val)
    UIManager:GetInstance():DestroyWindow(UIWindowNames.UIGMPanel)
  end,
  contentType = 0,
  btnName = "\232\191\155\229\133\165\229\133\179\229\141\161",
  icon = "Assets/Main/Sprites/UI/UIPveLoading/UIPveLoading_img01.png"
})
config:Add({
  name = "\230\160\185\230\141\174mailUid\230\146\173\230\148\190\230\136\152\230\150\151\229\189\149\229\131\143",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  get = function()
    return 1
  end,
  set = function(val)
  end,
  onClicked = function(val)
    DataCenter.LWBattleManager:PlayReplay(val, PVEEnterType.GM)
  end,
  contentType = 0,
  btnName = "\230\146\173\230\148\190\229\189\149\229\131\143",
  icon = "Assets/Main/Sprites/UI/UIFirstPay/cfm_shouchong_bofang.png"
})
config:Add({
  name = "\233\135\141\230\146\173\228\184\138\228\184\128\230\172\161\230\146\173\230\148\190\231\154\132\229\189\149\229\131\143",
  icon = "Assets/Main/ActivityRes/2025EasterMod/Sprites/UI/LWUIActEasterEggChat/lrb_FHJ_shuaxin_icon.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    DataCenter.LWBattleManager:PlayLastReplay()
  end,
  btnName = "\233\135\141\230\146\173\229\189\149\229\131\143"
})
config:Add({
  name = "\230\137\147\229\188\128\233\156\135\229\138\168\232\176\131\232\175\149\231\149\140\233\157\162",
  icon = "Assets/Main/Sprites/ItemIcons/mjc_icon_yiminjuan.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    UIManager:GetInstance():OpenWindow(UIWindowNames.UIGMVibratorPanel, {anim = true})
  end,
  btnName = "\229\188\128\233\156\135"
})
config:Add({
  name = "\232\183\145\233\133\183\229\188\128\229\144\175\230\151\165\229\191\151\232\190\147\229\135\186",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_liaotianyouhua_jianpan_icon.png",
  get = function()
    return GMUtils.GetBool(GMConst.SurfingLogOutput, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.SurfingLogOutput, val)
  end
})
config:Add({
  name = "\229\156\168\233\155\183\232\190\190\231\149\140\233\157\162\230\146\173\230\148\190\230\137\171\229\133\137\229\138\168\231\148\187",
  icon = "Assets/Main/Sprites/UI/UIMain/LWMainUI/cfm_zhujiemian_anniu_zuo_5.png",
  style = GMPageStyle.ItemTemplate.ButtonRenderer,
  tips = nil,
  onClicked = function()
    UIManager:GetInstance():DestroyWindow(UIWindowNames.UIGMPanel, {anim = true})
    EventManager:GetInstance():Broadcast(EventId.GMPanelPlayDetectEventAni)
  end,
  btnName = "\230\146\173\230\148\190\230\137\171\229\133\137\229\138\168\231\148\187"
})
config:Add({
  name = "\229\156\168\233\155\183\232\190\190\231\149\140\233\157\162\230\146\173\230\148\190\230\172\161\230\149\176\229\162\158\229\138\160\231\137\185\230\149\136",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  get = function()
    return 1
  end,
  set = function(val)
  end,
  onClicked = function(val)
    local newValue = tonumber(val) or 1
    UIManager:GetInstance():DestroyWindow(UIWindowNames.UIGMPanel, {anim = true})
    EventManager:GetInstance():Broadcast(EventId.DetectEventRewardGet, newValue)
  end,
  contentType = 0,
  btnName = "\230\146\173\230\148\190\231\137\185\230\149\136",
  icon = "Assets/Main/Sprites/UI/UIMain/LWMainUI/cfm_zhujiemian_anniu_zuo_5.png"
})
config:Add({
  name = "\230\137\147\229\188\128\228\184\138\230\150\176\231\149\140\233\157\162",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_liaotianyouhua_jianpan_icon.png",
  get = function()
    return 10007
  end,
  set = function(val)
  end,
  onClicked = function(val)
    local weekCardList = DataCenter.WeekCardManager:GetWeekCardList()
    if weekCardList == nil then
      return
    end
    if not val then
      return
    end
    for i, v in ipairs(weekCardList) do
      if v and v.id == tonumber(val) then
        UIManager:GetInstance():OpenWindow(UIWindowNames.UIWeekCardShowNew, {anim = true}, v)
        break
      end
    end
  end,
  btnName = "\232\138\157\233\186\187\229\188\128\233\151\168"
})
config:Add({
  name = "\229\188\128\229\144\175\230\150\176\231\154\132PVE\232\163\133\233\165\176\231\137\169\230\152\190\231\164\186",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  icon = "Assets/Main/Sprites/UI/UIPveLoading/UIPveLoading_img01.png",
  get = function()
    return GMUtils.GetBool(GMConst.NewPVEDecorationShowMethod, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.NewPVEDecorationShowMethod, val)
  end
})
config:Add({
  name = "\229\128\141\229\162\158\233\151\168\232\175\166\231\187\134\230\151\165\229\191\151",
  style = GMPageStyle.ItemTemplate.ToggleRenderer,
  icon = "Assets/Main/Sprites/UI/UIPveLoading/UIPveLoading_img01.png",
  get = function()
    return GMUtils.GetBool(GMConst.ParkourDetailLog, false)
  end,
  set = function(val)
    GMUtils.SetBool(GMConst.ParkourDetailLog, val)
  end
})
config:Add({
  name = "\229\143\145\233\128\129\228\184\128\228\184\170event",
  style = GMPageStyle.ItemTemplate.InputButtonRenderer,
  icon = "Assets/Main/Sprites/UI/LWCommon/Sprite/zyf_liaotianyouhua_jianpan_icon.png",
  get = function()
    return 2218
  end,
  set = function(val)
  end,
  onClicked = function(val)
    EventManager:GetInstance():Broadcast(val)
  end,
  btnName = "\229\143\145\229\176\132\239\188\129"
})
return config
