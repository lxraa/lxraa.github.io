﻿local UIBaseCtrl = BaseClass("UIBaseCtrl")
return UIBaseCtrl
