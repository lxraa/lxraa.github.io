﻿local AllianceRankData = BaseClass("AllianceRankData")
local __init = function(self)
  self.uid = ""
  self.name = ""
  self.allianceAbbr = ""
  self.allianceName = ""
  self.power = 0
  self.kill = 0
  self.rank = 0
  self.type = RankType.None
  self.icon = ""
  self.country = DefaultNation
  self.score = 0
end
local __delete = function(self)
  self.uid = nil
  self.name = nil
  self.allianceAbbr = nil
  self.allianceName = nil
  self.power = nil
  self.kill = nil
  self.rank = nil
  self.type = nil
  self.icon = nil
  self.country = nil
  self.score = nil
end
local ParseData = function(self, message, type)
  self.type = type
  if message == nil then
    return
  end
  if message.uid ~= nil then
    self.uid = message.uid
  end
  if message.leader ~= nil then
    self.name = message.leader
  end
  if message.abbr ~= nil then
    self.allianceAbbr = message.abbr
    self.abbr = message.abbr
  end
  if message.alliancename ~= nil then
    self.allianceName = message.alliancename
  end
  if message.fightpower ~= nil then
    self.power = message.fightpower
  end
  if message.armyKill ~= nil then
    self.kill = message.armyKill
  end
  if message.icon ~= nil then
    self.icon = message.icon
  end
  if message.country then
    self.country = message.country
  end
  if message.srcServer then
    self.srcServer = message.srcServer
  end
  if not self.srcServer then
    self.srcServer = message.serverId
  end
  if message.score then
    self.score = message.score
  end
end
local SetRank = function(self, rank)
  self.rank = rank
end
local GetCountryFlagTemplate = function(self)
  local country = string.IsNullOrEmpty(self.country) and DefaultNation or self.country
  return DataCenter.NationTemplateManager:GetNationTemplate(country)
end
AllianceRankData.__init = __init
AllianceRankData.__delete = __delete
AllianceRankData.ParseData = ParseData
AllianceRankData.SetRank = SetRank
AllianceRankData.GetCountryFlagTemplate = GetCountryFlagTemplate
return AllianceRankData
