﻿local LWHeroRankStar = BaseClass("LWHeroRankStar", UIBaseContainer)
local base = UIBaseContainer

function LWHeroRankStar:OnCreate()
  base.OnCreate(self)
  self:ComponentDefine()
  self:DataDefine()
end

function LWHeroRankStar:OnDestroy()
  self:ComponentDestroy()
  self:DataDestroy()
  base.OnDestroy(self)
end

function LWHeroRankStar:OnEnable()
  base.OnEnable(self)
end

function LWHeroRankStar:OnDisable()
  base.OnDisable(self)
end

function LWHeroRankStar:ComponentDefine()
  self.starMap = {}
  for i = 1, 5 do
    local star = self:AddComponent(UIImage, "Star" .. i)
    local data = {}
    data.root = star
    self.starMap[i] = data
  end
end

function LWHeroRankStar:ComponentDestroy()
end

function LWHeroRankStar:DataDefine()
end

function LWHeroRankStar:DataDestroy()
end

function LWHeroRankStar:ShowRank(rank, maxRank)
  rank = rank or 1
  local starNum = (maxRank - 1) / 5
  for i = 1, 5 do
    if i <= starNum then
      self.starMap[i].root:SetActive(true)
      local rankGroup = math.floor((rank - 1) / 5) + 1
      local innerRank = (rank - 1) % 5
      if i < rankGroup then
        self.starMap[i].root:LoadSprite("Assets/Main/Sprites/UI/UILWHeroDetail/cfm_biandui_xingxing_5")
      elseif i == rankGroup and 0 < innerRank then
        self.starMap[i].root:LoadSprite("Assets/Main/Sprites/UI/UILWHeroDetail/cfm_biandui_xingxing_" .. innerRank)
      else
        self.starMap[i].root:LoadSprite("Assets/Main/Sprites/UI/LWCommon/Sprite/lyp_yingxiongxing_01.png")
      end
    else
      self.starMap[i].root:SetActive(false)
    end
  end
end

return LWHeroRankStar
