﻿local IChatItemPost = require("UI.UIChatNewV2.Component.ChatItem.IChatItemPost")
local ChatItemPost_GiftGiving = BaseClass("ChatGiftGivingPrivate", IChatItemPost)
local base = IChatItemPost
local Localization = CS.GameEntry.Localization
local rapidjson = require("rapidjson")
local RootPath = "Assets/Main/Sprites/UI/LWUIGiftSystem/"
local bg_path = "Bg"
local send_btn_path = "SendBtn"
local texts_path = "Texts"
local title_path = "Texts/Title"
local desc_path = "Texts/Desc"
local icon_path = "Icon"
local num_path = "Icon/Num"
local bg_bottom_path = "BgContent/BgBottom"
local bg_pattern_path = "BgContent/BgPattern"
local bg_start_path = "BgContent/BgStart"
local bg_frame_path = "BgContent/BgFrame"
local ChatConfig = {
  Right = {
    Width = 486,
    Icon = 356,
    Text = 20,
    TextWidth = 336,
    StartPosX = 314
  },
  Left = {
    Width = 511,
    Icon = 12,
    Text = 160,
    TextWidth = 238,
    StartPosX = 178
  }
}
local ItemMinHeight = 164
local TxtWithItemDiffH = 26

function ChatItemPost_GiftGiving:OnCreate()
  base.OnCreate(self)
  self:ComponentDefine()
end

function ChatItemPost_GiftGiving:ComponentDefine()
  self.root = self:AddComponent(UIBaseContainer, "")
  self.bg = self:AddComponent(UIImage, bg_path)
  self.send_btn = self:AddComponent(UIButton, send_btn_path)
  self.texts = self:AddComponent(UIBaseContainer, texts_path)
  self.title = self:AddComponent(UITextMeshProUGUIEx, title_path)
  self.desc = self:AddComponent(UIText, desc_path)
  self.icon = self:AddComponent(UIImage, icon_path)
  self.num = self:AddComponent(UITextMeshProUGUIEx, num_path)
  self.bg_bottom = self:AddComponent(UIImage, bg_bottom_path)
  self.bg_pattern = self:AddComponent(UIImage, bg_pattern_path)
  self.bg_start = self:AddComponent(UIImage, bg_start_path)
  self.bg_frame = self:AddComponent(UIImage, bg_frame_path)
  self.send_btn:SetOnClick(BindCallback(self, self.OnSendBtnClick))
  ChatInterface.SetEmojiTextProperty(self.desc, true)
end

function ChatItemPost_GiftGiving:OnSendBtnClick()
  if self.sendUid == nil then
    return
  end
  if UIManager:GetInstance():IsWindowOpen(UIWindowNames.LWUIGiftOperation) then
    UIManager:GetInstance():DestroyWindow(UIWindowNames.LWUIGiftOperation)
  end
  DataCenter.GiftSystemManager:OpenOperationView({
    windowType = GiftSystemConst.WindowType.Send,
    targetUid = self.sendUid
  })
end

function ChatItemPost_GiftGiving:OnLoaded()
  local _chatdata = self:ChatData()
  if _chatdata == nil then
    return
  end
  self._chatData = _chatdata
  local isMyChat = self._chatData:isMyChat()
  local config = isMyChat and ChatConfig.Right or ChatConfig.Left
  self.texts:SetSizeDeltaX(config.TextWidth)
  self.texts:SetAnchoredPositionXY(config.Text, -16)
  self.icon:SetAnchoredPositionXY(config.Icon, -78)
  self.root:SetSizeDeltaX(config.Width)
  self.send_btn:SetActive(not isMyChat)
  self.bg_start:SetAnchoredPositionXY(config.StartPosX, 0)
  local bgScaleX = isMyChat and -1 or 1
  self.bg_bottom:SetLocalScaleXYZ(bgScaleX, 1, 1)
  self.bg_start:SetLocalScaleXYZ(-1 * bgScaleX, 1, 1)
  local customJsonParam = self._chatData.extra and self._chatData.extra.customJsonParam
  if customJsonParam == nil then
    return
  end
  local extraJson
  if type(self._chatData.extra.customJsonParam) == "string" then
    extraJson = rapidjson.decode(self._chatData.extra.customJsonParam)
  elseif type(self._chatData.extra.customJsonParam) == "table" then
    extraJson = self._chatData.extra.customJsonParam
  else
    return
  end
  self.sendUid = extraJson.sendUid
  self.targetInfo = extraJson.targetInfo or {}
  local template = DataCenter.ItemTemplateManager:GetItemTemplate(extraJson.itemId)
  if template == nil then
    return
  end
  local goods = DataCenter.GiftSystemManager:GetGiftGoods(template.id)
  local sendNum = extraJson.num
  local giftName = Localization:GetString(template.name)
  local sendPlayerName = extraJson.sendName
  if self._chatData.group == ChatGroupType.GROUP_CUSTOM then
    if string.IsNullOrEmpty(extraJson.context) then
      if extraJson.isFollow then
        self.desc:SetLocalText("moment_follow_gift_des")
      else
        self.desc:SetLocalText("gift_msg_default_des")
      end
    else
      local showTxt = extraJson.context
      if self._chatData:GetTranslateState() == TranslateStateType.TranslationCompleted then
        showTxt = self._chatData:getTranslationMsg()
      end
      self.desc:SetText(showTxt)
    end
  elseif extraJson.isAnonymous ~= 1 then
    self.desc:SetLocalText("gift_sent_msg_des1", sendNum, sendPlayerName, giftName)
  else
    self.desc:SetLocalText("gift_sent_msg_des2", sendNum, giftName)
  end
  CS.UnityEngine.UI.LayoutRebuilder.ForceRebuildLayoutImmediate(self.texts.transform)
  local txtContX, txtContY = self.texts:GetSizeDeltaXY()
  local itemHeight = txtContY + TxtWithItemDiffH
  itemHeight = math.max(itemHeight, ItemMinHeight)
  self.root:SetSizeDeltaY(itemHeight)
  self.icon:LoadSprite(GiftSystemConst.GetIconPath(goods.icon_mid))
  local pic1Path, pic2Path = GiftSystemConst.GetChatQualityPicPrivate(template.quality)
  self.bg:LoadSprite(RootPath .. "zyf_liwufenxiang_di1")
  self.bg_bottom:LoadSprite(pic1Path)
  self.bg_pattern:LoadSprite(RootPath .. "zyf_liwufenxiang_diwen")
  self.bg_start:LoadSprite(pic2Path)
  self.bg_frame:LoadSprite(RootPath .. "zyf_liwufenxiang_di2")
  self.num:SetText("x" .. sendNum)
  if goods.ep_gift == 1 then
    local id = extraJson.chatGiftUuid or self._chatData.seqId
    DataCenter.GiftSystemManager:TryPlayAnim(id, goods.id)
  elseif next(goods.group_id) then
    local index = 0
    for i, v in ipairs(goods.group_id) do
      if sendNum >= tonumber(v) then
        index = i
      end
    end
    local effect = goods.group_effect[index]
    if not string.IsNullOrEmpty(effect) then
      local id = extraJson.chatGiftUuid or self._chatData.seqId
      DataCenter.GiftSystemManager:TryPlayAnim(id, goods.id, index)
    end
  end
end

function ChatItemPost_GiftGiving:OnRecycle()
end

return ChatItemPost_GiftGiving
