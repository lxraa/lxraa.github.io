﻿local HorizontalInfinityScrollView = BaseClass("HorizontalInfinityScrollView", UIBaseComponent)
local base = UIBaseComponent
local UnityScrollView = typeof(CS.HorizontalInfinityScrollView)
local OnCreate = function(self)
  base.OnCreate(self)
  self.content = self.gameObject:GetComponent(UnityScrollView)
end
local OnDestroy = function(self)
  self.content:Dispose()
  self.content = nil
  base.OnDestroy(self)
end
local Init = function(self, action1, action2, action3, obj)
  self.content:Init(action1, action2, action3, obj)
end
local SetItemCount = function(self, itemCount_)
  self.content:SetItemCount(itemCount_)
  self.content:ForceUpdate()
end
local ForceUpdate = function(self)
  self.content:ForceUpdate()
end
local MoveItemByIndex = function(self, index, delay)
  self.content:MoveItemByIndex(index, delay)
end
local CenterItemByIndex = function(self, index, delay)
end
HorizontalInfinityScrollView.OnCreate = OnCreate
HorizontalInfinityScrollView.OnDestroy = OnDestroy
HorizontalInfinityScrollView.Init = Init
HorizontalInfinityScrollView.SetItemCount = SetItemCount
HorizontalInfinityScrollView.ForceUpdate = ForceUpdate
HorizontalInfinityScrollView.MoveItemByIndex = MoveItemByIndex
return HorizontalInfinityScrollView
