﻿local SimpleCombatUnit = require("DataCenter.MailData.BattleReport.CombatUnitData.SimpleCombatUnit")
local ArmyCombatUnit = require("DataCenter.MailData.BattleReport.CombatUnitData.ArmyCombatUnit")
local UnitBase = require("DataCenter.MailData.BattleReport.CombatUnitData.UnitBase")
local CombineCombatUnit = BaseClass("CombineCombatUnit", UnitBase)

function CombineCombatUnit:InitData(combineCombatUnit)
  self._allMemberSoldiers = nil
  self._allMemberHeros = nil
  local simpleCombatUnit = combineCombatUnit.simpleCombatUnit or {}
  self._simpleCombatUnit = SimpleCombatUnit.New()
  self._simpleCombatUnit:InitData(simpleCombatUnit)
  self._memberUnit = {}
  local membersData = combineCombatUnit.members or {}
  self:InitMembers(membersData)
end

function CombineCombatUnit:GetSimpleCombatUnit()
  return self._simpleCombatUnit
end

function CombineCombatUnit:InitMembers(members)
  for _, armyCombatUnit in pairs(members) do
    local armyCombat = ArmyCombatUnit.New()
    armyCombat:InitData(armyCombatUnit)
    local userId = armyCombat:GetUserId()
    self._memberUnit[#self._memberUnit + 1] = armyCombat
  end
end

function CombineCombatUnit:GetArmyCombatByUserIdAndMarchId(userid, marchid)
  for _, armyCombat in pairs(self._memberUnit) do
    local userId = armyCombat:GetUserId()
    local marchId = armyCombat:GetMarchId()
    if userid == userId and marchid == marchId then
      return armyCombat
    end
  end
  return nil
end

function CombineCombatUnit:GetAllMembers()
  return self._memberUnit
end

function CombineCombatUnit:GetAttTotalCnt(attId, isMySelf)
  local totalCnt = 0
  local _selfUid = LuaEntry.Player.uid
  for _, memberInfo in pairs(self._memberUnit) do
    if isMySelf then
      local tmpUserId = memberInfo:GetUserId()
      if tmpUserId == _selfUid then
        totalCnt = totalCnt + memberInfo:GetAttTotalCnt(attId)
      end
    else
      totalCnt = totalCnt + memberInfo:GetAttTotalCnt(attId)
    end
  end
  return totalCnt
end

function CombineCombatUnit:GetPlayerHeroes(userId)
  local _selfUid = LuaEntry.Player.uid
  local allHeroes = {}
  local exist = false
  for _, memberInfo in pairs(self._memberUnit) do
    local tmpUserId = memberInfo:GetUserId()
    if tmpUserId == userId and exist == false then
      exist = true
      local heroes = memberInfo:GetPlayerHeroes()
      table.merge(allHeroes, heroes)
    end
  end
  return allHeroes
end

function CombineCombatUnit:GetHeroSpecialSkillList()
  local skillList = {}
  for _, memberInfo in pairs(self._memberUnit) do
    local heroSkillList = memberInfo:GetHeroSpecialSkillList()
    table.insertto(skillList, heroSkillList)
  end
  return skillList
end

function CombineCombatUnit:GetHealth()
  local member = self:GetAllMembers()
  local totalCnt = 0
  for _, item in pairs(member) do
    totalCnt = totalCnt + item:GetHealth()
  end
  return totalCnt
end

function CombineCombatUnit:GetAllMembersUuid(unitType)
  local list = {}
  local member = self:GetAllMembers()
  local totalCnt = 0
  for _, item in pairs(member) do
    totalCnt = totalCnt + 1
    local uuid = item:GetMarchId()
    if uuid ~= nil and uuid ~= "" then
      table.insert(list, uuid)
    end
  end
  if unitType == BattleType.Turret then
    totalCnt = totalCnt + 1
    local uuid = self._simpleCombatUnit:GetMarchId()
    if uuid ~= nil and uuid ~= "" then
      table.insert(list, uuid)
    end
  end
  if totalCnt <= 0 then
    local uuid = self._simpleCombatUnit:GetMarchId()
    if uuid ~= nil and uuid ~= "" then
      table.insert(list, uuid)
    end
  end
  return list
end

function CombineCombatUnit:GetArmyUuidByUid(targetUid, unitType)
  local member = self:GetAllMembers()
  local totalCnt = 0
  for _, item in pairs(member) do
    totalCnt = totalCnt + 1
    local uid = item:GetUserId()
    local uuid = item:GetMarchId()
    if uid == targetUid then
      return uuid
    end
  end
  if unitType == BattleType.Turret then
    local uid = self._simpleCombatUnit:GetUid()
    local uuid = self._simpleCombatUnit:GetMarchId()
    if uid == targetUid then
      return uuid
    end
  end
  if totalCnt <= 0 then
    local uid = self._simpleCombatUnit:GetUid()
    local uuid = self._simpleCombatUnit:GetMarchId()
    if uid == targetUid then
      return uuid
    end
  end
  return 0
end

function CombineCombatUnit:GetBuffIdListByEffectId(effectId, marchId)
  local buffList = {}
  local member = self:GetAllMembers()
  for _, item in pairs(member) do
    local uuid = item:GetMarchId()
    if uuid == marchId then
      return item:GetBuffIdListByEffectId(effectId, marchId)
    end
  end
  return buffList
end

return CombineCombatUnit
