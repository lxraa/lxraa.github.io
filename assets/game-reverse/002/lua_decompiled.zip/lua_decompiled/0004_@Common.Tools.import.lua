﻿function import(moduleName, currentModuleName)
  local currentModuleNameParts
  
  local moduleFullName = moduleName
  local offset = 1
  while true do
    if string.byte(moduleName, offset) ~= 46 then
      moduleFullName = string.sub(moduleName, offset)
      if currentModuleNameParts and 0 < #currentModuleNameParts then
        moduleFullName = table.concat(currentModuleNameParts, ".") .. "." .. moduleFullName
      end
      break
    end
    offset = offset + 1
    if not currentModuleNameParts then
      if not currentModuleName then
        local n, v = debug.getlocal(3, 1)
        currentModuleName = v
      end
      currentModuleNameParts = string.split(currentModuleName, ".")
    end
    table.remove(currentModuleNameParts, #currentModuleNameParts)
  end
  return require(moduleFullName)
end

function reimport(name)
  local package = package
  package.loaded[name] = nil
  package.preload[name] = nil
  return require(name)
end

function reloadModule(name)
  local package = package
  local oldModule = package.loaded[name]
  package.loaded[name] = nil
  oldModule = oldModule or {}
  local newModule = require(name)
  for k, v in pairs(newModule) do
    oldModule[k] = v
  end
  package.loaded[name] = oldModule
  return oldModule
end

function unloadModule(name)
  package.loaded[name] = nil
  _G[name] = nil
end
