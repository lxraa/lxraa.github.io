"""
配置管理模块
"""
import json
import os
from pathlib import Path
from typing import Dict, Any


class Config:
    """配置管理类"""
    
    DEFAULT_CONFIG = {
        "last_locale": "",
        "last_csv_dir": "",
        "last_locale_dir": "",
        "window_size": [1200, 800],
        "window_position": None,
        "recent_files": [],
        "max_recent_files": 10,
        "localization_rules": {},
        "search_settings": {
            "fuzzy_threshold": 0.6,
            "max_results": 50,
            "enable_cache": True
        }
    }
    
    def __init__(self, config_file: str = "csv_viewer_config.json"):
        self.config_file = config_file
        self.config: Dict[str, Any] = self.DEFAULT_CONFIG.copy()
        self.load()
    
    def load(self):
        """加载配置文件"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    self.config.update(loaded_config)
            except Exception as e:
                print(f"加载配置文件失败: {e}")
    
    def save(self):
        """保存配置文件"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存配置文件失败: {e}")
    
    def get(self, key: str, default=None):
        """获取配置项"""
        return self.config.get(key, default)
    
    def set(self, key: str, value):
        """设置配置项"""
        self.config[key] = value
        self.save()
    
    def add_recent_file(self, file_path: str):
        """添加最近打开的文件"""
        recent = self.config.get("recent_files", [])
        if file_path in recent:
            recent.remove(file_path)
        recent.insert(0, file_path)
        recent = recent[:self.config.get("max_recent_files", 10)]
        self.set("recent_files", recent)
    
    def get_localization_rule(self, csv_name: str) -> Dict:
        """获取CSV的本地化规则"""
        rules = self.config.get("localization_rules", {})
        return rules.get(csv_name, {})
    
    def set_localization_rule(self, csv_name: str, rule: Dict):
        """设置CSV的本地化规则"""
        rules = self.config.get("localization_rules", {})
        rules[csv_name] = rule
        self.set("localization_rules", rules)

