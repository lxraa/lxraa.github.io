"""
CSV管理模块
负责加载、解析、本地化CSV文件
"""
import csv
import re
from pathlib import Path
from typing import List, Dict, Optional, Set, Tuple
import chardet
import pandas as pd


class CSVManager:
    """CSV管理器"""
    
    def __init__(self, locale_manager=None):
        self.locale_manager = locale_manager
        self.current_file: Optional[str] = None
        self.df: Optional[pd.DataFrame] = None
        self.original_df: Optional[pd.DataFrame] = None  # 保存原始数据
        self.headers: List[str] = []
        self.localizable_columns: Set[str] = set()
        self.localized_columns: Set[str] = set()  # 已本地化的列
    
    def load_csv(self, csv_path: str) -> bool:
        """
        加载CSV文件
        
        Args:
            csv_path: CSV文件路径
            
        Returns:
            是否加载成功
        """
        try:
            # 检测文件编码
            encoding = self._detect_encoding(csv_path)
            
            # 使用pandas读取CSV
            self.df = pd.read_csv(csv_path, encoding=encoding, keep_default_na=False)
            self.original_df = self.df.copy()
            self.current_file = csv_path
            self.headers = list(self.df.columns)
            self.localized_columns.clear()
            self.localizable_columns.clear()
            
            return True
        except Exception as e:
            print(f"加载CSV文件失败: {e}")
            return False
    
    def _detect_encoding(self, file_path: str) -> str:
        """
        检测文件编码
        
        Args:
            file_path: 文件路径
            
        Returns:
            编码名称
        """
        try:
            with open(file_path, 'rb') as f:
                raw_data = f.read(10000)  # 读取前10KB
                result = chardet.detect(raw_data)
                encoding = result['encoding']
                
                # 常见编码映射
                encoding_map = {
                    'GB2312': 'gbk',
                    'GB18030': 'gbk',
                    'ascii': 'utf-8'
                }
                
                return encoding_map.get(encoding, encoding or 'utf-8')
        except:
            return 'utf-8'
    
    def detect_localizable_columns(self) -> Set[str]:
        """
        自动检测可本地化的列
        
        Returns:
            可本地化的列名集合
        """
        if self.df is None or self.locale_manager is None:
            return set()
        
        self.localizable_columns.clear()
        
        # 检测策略
        for col in self.headers:
            col_lower = col.lower()
            
            # 策略1: 列名包含特定关键词
            keywords = ['name', 'desc', 'title', 'text', 'tip', 'label', 
                       'message', 'content', 'info', 'detail']
            if any(keyword in col_lower for keyword in keywords):
                # 检查该列是否有本地化key
                if self._column_has_locale_keys(col):
                    self.localizable_columns.add(col)
                    continue
            
            # 策略2: 检查列内容是否包含本地化key
            if self._column_has_locale_keys(col):
                self.localizable_columns.add(col)
        
        return self.localizable_columns
    
    def _column_has_locale_keys(self, column: str, sample_size: int = 10) -> bool:
        """
        检查列是否包含本地化key
        
        Args:
            column: 列名
            sample_size: 采样数量
            
        Returns:
            是否包含本地化key
        """
        if self.df is None or self.locale_manager is None:
            return False
        
        # 采样检查
        sample = self.df[column].head(sample_size)
        match_count = 0
        
        for value in sample:
            if pd.isna(value) or value == '':
                continue
            
            value_str = str(value)
            
            # 检查是否是本地化key
            if self.locale_manager.is_localized_key(value_str):
                match_count += 1
            # 检查是否包含本地化key（用分隔符分隔的情况）
            elif self._contains_locale_key(value_str):
                match_count += 1
        
        # 如果超过30%的样本包含本地化key，认为该列可本地化
        return match_count >= len(sample) * 0.3
    
    def _contains_locale_key(self, text: str) -> bool:
        """
        检查文本中是否包含本地化key
        
        Args:
            text: 待检查的文本
            
        Returns:
            是否包含本地化key
        """
        if self.locale_manager is None:
            return False
        
        # 常见的分隔符
        separators = ['|', ',', ';', '\n']
        
        for sep in separators:
            if sep in text:
                parts = text.split(sep)
                for part in parts:
                    part = part.strip()
                    if self.locale_manager.is_localized_key(part):
                        return True
        
        return False
    
    def localize_column(self, column: str, keep_original: bool = False) -> bool:
        """
        本地化指定列
        
        Args:
            column: 列名
            keep_original: 是否保留原始列
            
        Returns:
            是否成功
        """
        if self.df is None or self.locale_manager is None:
            return False
        
        if column not in self.headers:
            return False
        
        try:
            # 如果需要保留原始列
            if keep_original and column not in self.localized_columns:
                original_col = f"{column}_original"
                self.df[original_col] = self.df[column]
            
            # 本地化该列
            self.df[column] = self.df[column].apply(
                lambda x: self._localize_value(x)
            )
            
            self.localized_columns.add(column)
            return True
        except Exception as e:
            print(f"本地化列 {column} 失败: {e}")
            return False
    
    def _localize_value(self, value) -> str:
        """
        本地化单个值
        
        Args:
            value: 原始值
            
        Returns:
            本地化后的值
        """
        if pd.isna(value) or value == '':
            return ''
        
        value_str = str(value)
        
        # 1. 直接查找
        localized = self.locale_manager.get_value(value_str)
        if localized:
            return localized
        
        # 2. 处理分隔符分隔的多个key
        separators = ['|', ',', ';', '\n']
        for sep in separators:
            if sep in value_str:
                parts = value_str.split(sep)
                localized_parts = []
                for part in parts:
                    part = part.strip()
                    loc = self.locale_manager.get_value(part)
                    localized_parts.append(loc if loc else part)
                return sep.join(localized_parts)
        
        # 3. 处理复杂格式（如 "520002;7;2|revival_plan_phasename01;7;6"）
        # 尝试提取可能的本地化key
        pattern = r'\b[a-z_][a-z0-9_]*\b'
        matches = re.findall(pattern, value_str, re.IGNORECASE)
        
        result = value_str
        for match in matches:
            loc = self.locale_manager.get_value(match)
            if loc:
                result = result.replace(match, f"[{loc}]")
        
        return result
    
    def localize_columns(self, columns: List[str], keep_original: bool = False) -> bool:
        """
        本地化多个列
        
        Args:
            columns: 列名列表
            keep_original: 是否保留原始列
            
        Returns:
            是否全部成功
        """
        success = True
        for col in columns:
            if not self.localize_column(col, keep_original):
                success = False
        return success
    
    def reset_localization(self):
        """重置本地化，恢复原始数据"""
        if self.original_df is not None:
            self.df = self.original_df.copy()
            self.localized_columns.clear()
    
    def export_csv(self, output_path: str, encoding: str = 'utf-8-sig') -> bool:
        """
        导出CSV文件
        
        Args:
            output_path: 输出路径
            encoding: 编码格式
            
        Returns:
            是否成功
        """
        if self.df is None:
            return False
        
        try:
            self.df.to_csv(output_path, index=False, encoding=encoding)
            return True
        except Exception as e:
            print(f"导出CSV失败: {e}")
            return False
    
    def export_excel(self, output_path: str) -> bool:
        """
        导出为Excel文件
        
        Args:
            output_path: 输出路径
            
        Returns:
            是否成功
        """
        if self.df is None:
            return False
        
        try:
            self.df.to_excel(output_path, index=False, engine='openpyxl')
            return True
        except Exception as e:
            print(f"导出Excel失败: {e}")
            return False
    
    def get_preview_data(self, max_rows: int = 100) -> pd.DataFrame:
        """
        获取预览数据
        
        Args:
            max_rows: 最大行数
            
        Returns:
            预览数据
        """
        if self.df is None:
            return pd.DataFrame()
        
        return self.df.head(max_rows)
    
    def get_stats(self) -> Dict:
        """
        获取统计信息
        
        Returns:
            统计信息字典
        """
        if self.df is None:
            return {}
        
        return {
            "file_name": Path(self.current_file).name if self.current_file else "",
            "total_rows": len(self.df),
            "total_columns": len(self.headers),
            "localizable_columns": len(self.localizable_columns),
            "localized_columns": len(self.localized_columns),
            "columns": self.headers
        }

