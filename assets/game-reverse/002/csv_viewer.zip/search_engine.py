"""
搜索引擎模块
负责在所有CSV文件中搜索指定的文本
"""
import os
import re
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import pandas as pd
from dataclasses import dataclass


@dataclass
class SearchResult:
    """搜索结果"""
    file_path: str
    file_name: str
    row_index: int
    column_name: str
    original_value: str
    localized_value: str
    match_type: str  # 'exact', 'partial', 'index', 'value'
    score: float
    
    def __repr__(self):
        return f"SearchResult({self.file_name}, row={self.row_index}, col={self.column_name}, score={self.score:.2f})"


class SearchEngine:
    """搜索引擎"""
    
    def __init__(self, csv_dir: str, locale_manager=None):
        self.csv_dir = csv_dir
        self.locale_manager = locale_manager
        self.csv_files: List[str] = []
        self.index_cache: Dict[str, Dict] = {}  # 文件索引缓存
        self.cache_enabled = True
    
    def scan_csv_files(self) -> List[str]:
        """
        扫描CSV目录，获取所有CSV文件
        
        Returns:
            CSV文件路径列表
        """
        self.csv_files.clear()
        
        if not os.path.exists(self.csv_dir):
            return []
        
        for file in Path(self.csv_dir).glob("*.csv"):
            self.csv_files.append(str(file))
        
        return self.csv_files
    
    def build_index(self, force_rebuild: bool = False):
        """
        构建搜索索引
        
        Args:
            force_rebuild: 是否强制重建
        """
        if not force_rebuild and self.index_cache:
            return
        
        self.index_cache.clear()
        
        for csv_file in self.csv_files:
            try:
                self._index_file(csv_file)
            except Exception as e:
                print(f"索引文件 {csv_file} 失败: {e}")
    
    def _index_file(self, csv_file: str):
        """
        索引单个文件
        
        Args:
            csv_file: CSV文件路径
        """
        try:
            # 读取CSV（索引所有行，不限制数量）
            df = pd.read_csv(csv_file, encoding='utf-8', keep_default_na=False)
        except:
            try:
                df = pd.read_csv(csv_file, encoding='gbk', keep_default_na=False)
            except:
                return
        
        file_index = {
            'headers': list(df.columns),
            'content': {}
        }
        
        # 索引每个单元格
        for col in df.columns:
            for idx, value in enumerate(df[col]):
                if pd.isna(value) or value == '':
                    continue
                
                value_str = str(value).lower()
                
                if value_str not in file_index['content']:
                    file_index['content'][value_str] = []
                
                file_index['content'][value_str].append({
                    'row': idx,
                    'column': col,
                    'original': str(value)
                })
        
        self.index_cache[csv_file] = file_index
    
    def search(self, query: str, max_results: int = 50) -> List[SearchResult]:
        """
        搜索文本
        
        Args:
            query: 查询文本
            max_results: 最大结果数
            
        Returns:
            搜索结果列表
        """
        if not self.csv_files:
            self.scan_csv_files()
        
        if not self.index_cache and self.cache_enabled:
            self.build_index()
        
        results = []
        
        # 策略1: 直接搜索原始文本
        results.extend(self._search_direct(query))
        
        # 策略2: 如果有本地化管理器，尝试 value -> index -> CSV
        if self.locale_manager:
            results.extend(self._search_value_to_index(query))
            
            # 策略3: 尝试 index -> value -> CSV
            results.extend(self._search_index_to_value(query))
        
        # 去重和排序
        results = self._deduplicate_results(results)
        results.sort(key=lambda x: x.score, reverse=True)
        
        return results[:max_results]
    
    def _search_direct(self, query: str) -> List[SearchResult]:
        """
        直接搜索（在CSV中查找包含query的单元格）
        
        Args:
            query: 查询文本
            
        Returns:
            搜索结果列表
        """
        results = []
        query_lower = query.lower()
        
        for csv_file in self.csv_files:
            try:
                # 使用索引搜索
                if csv_file in self.index_cache:
                    file_index = self.index_cache[csv_file]
                    
                    # 精确匹配
                    if query_lower in file_index['content']:
                        for match in file_index['content'][query_lower]:
                            results.append(SearchResult(
                                file_path=csv_file,
                                file_name=Path(csv_file).name,
                                row_index=match['row'],
                                column_name=match['column'],
                                original_value=match['original'],
                                localized_value=self._localize_value(match['original']),
                                match_type='exact',
                                score=1.0
                            ))
                    
                    # 部分匹配
                    for value, matches in file_index['content'].items():
                        if query_lower in value and query_lower != value:
                            # 改进的评分算法
                            # 1. 基础分：匹配长度比例
                            base_score = len(query_lower) / len(value)
                            
                            # 2. 位置加成：开头匹配得分更高
                            if value.startswith(query_lower):
                                position_bonus = 0.3
                            elif value.find(query_lower) <= 3:  # 前3个字符内
                                position_bonus = 0.2
                            else:
                                position_bonus = 0.0
                            
                            # 3. 完整词加成：如果是完整的词（前后有分隔符或边界）
                            word_bonus = 0.0
                            query_pos = value.find(query_lower)
                            if query_pos >= 0:
                                # 检查前后是否是词边界
                                before_ok = (query_pos == 0 or not value[query_pos-1].isalnum())
                                after_ok = (query_pos + len(query_lower) >= len(value) or 
                                           not value[query_pos + len(query_lower)].isalnum())
                                if before_ok and after_ok:
                                    word_bonus = 0.2
                            
                            # 最终得分
                            score = base_score + position_bonus + word_bonus
                            
                            if score >= 0.3:  # 至少匹配30%
                                for match in matches:
                                    results.append(SearchResult(
                                        file_path=csv_file,
                                        file_name=Path(csv_file).name,
                                        row_index=match['row'],
                                        column_name=match['column'],
                                        original_value=match['original'],
                                        localized_value=self._localize_value(match['original']),
                                        match_type='partial',
                                        score=score * 0.7  # 部分匹配降低权重
                                    ))
                else:
                    # 如果没有索引，直接读取文件搜索
                    results.extend(self._search_file_direct(csv_file, query))
            
            except Exception as e:
                print(f"搜索文件 {csv_file} 失败: {e}")
        
        return results
    
    def _search_file_direct(self, csv_file: str, query: str) -> List[SearchResult]:
        """
        直接在文件中搜索（不使用索引）
        
        Args:
            csv_file: CSV文件路径
            query: 查询文本
            
        Returns:
            搜索结果列表
        """
        results = []
        query_lower = query.lower()
        
        try:
            df = pd.read_csv(csv_file, encoding='utf-8', keep_default_na=False)
        except:
            try:
                df = pd.read_csv(csv_file, encoding='gbk', keep_default_na=False)
            except:
                return results
        
        for col in df.columns:
            for idx, value in enumerate(df[col]):
                if pd.isna(value) or value == '':
                    continue
                
                value_str = str(value)
                value_lower = value_str.lower()
                
                if query_lower == value_lower:
                    results.append(SearchResult(
                        file_path=csv_file,
                        file_name=Path(csv_file).name,
                        row_index=idx,
                        column_name=col,
                        original_value=value_str,
                        localized_value=self._localize_value(value_str),
                        match_type='exact',
                        score=1.0
                    ))
                elif query_lower in value_lower:
                    score = len(query_lower) / len(value_lower)
                    if score >= 0.3:
                        results.append(SearchResult(
                            file_path=csv_file,
                            file_name=Path(csv_file).name,
                            row_index=idx,
                            column_name=col,
                            original_value=value_str,
                            localized_value=self._localize_value(value_str),
                            match_type='partial',
                            score=score * 0.8
                        ))
        
        return results
    
    def _search_value_to_index(self, query: str) -> List[SearchResult]:
        """
        Value -> Index -> CSV 搜索
        把query当作本地化后的文本，找到对应的index，再搜索CSV
        
        Args:
            query: 查询文本
            
        Returns:
            搜索结果列表
        """
        if not self.locale_manager:
            return []
        
        results = []
        
        # 查找对应的index
        index_matches = self.locale_manager.find_indexes_fuzzy(query, threshold=0.5)
        
        for index, locale_score in index_matches:
            # 在CSV中搜索这个index
            direct_results = self._search_direct(index)
            
            for result in direct_results:
                # 更新匹配类型和分数
                result.match_type = 'value'
                # 提高通过本地化找到的结果的权重
                # 如果本地化匹配度很高（>0.9），给予更高的权重
                if locale_score >= 0.9:
                    result.score = locale_score * result.score * 1.2  # 提高权重
                else:
                    result.score = locale_score * result.score * 1.0
                results.append(result)
        
        return results
    
    def _search_index_to_value(self, query: str) -> List[SearchResult]:
        """
        Index -> Value -> CSV 搜索
        把query当作index，找到对应的value，再搜索CSV
        
        Args:
            query: 查询文本
            
        Returns:
            搜索结果列表
        """
        if not self.locale_manager:
            return []
        
        results = []
        
        # 查找对应的value
        value = self.locale_manager.get_value(query)
        
        if value:
            # 在CSV中搜索这个value
            direct_results = self._search_direct(value)
            
            for result in direct_results:
                # 更新匹配类型和分数
                result.match_type = 'index'
                result.score = result.score * 0.95
                results.append(result)
        
        return results
    
    def _localize_value(self, value: str) -> str:
        """
        本地化值
        
        Args:
            value: 原始值
            
        Returns:
            本地化后的值
        """
        if not self.locale_manager:
            return value
        
        localized = self.locale_manager.get_value(value)
        return localized if localized else value
    
    def _deduplicate_results(self, results: List[SearchResult]) -> List[SearchResult]:
        """
        去重搜索结果
        
        Args:
            results: 搜索结果列表
            
        Returns:
            去重后的结果列表
        """
        seen = set()
        unique_results = []
        
        for result in results:
            key = (result.file_path, result.row_index, result.column_name)
            if key not in seen:
                seen.add(key)
                unique_results.append(result)
            else:
                # 如果已存在，保留得分更高的
                for i, existing in enumerate(unique_results):
                    if (existing.file_path == result.file_path and 
                        existing.row_index == result.row_index and 
                        existing.column_name == result.column_name):
                        if result.score > existing.score:
                            unique_results[i] = result
                        break
        
        return unique_results
    
    def get_stats(self) -> Dict:
        """
        获取统计信息
        
        Returns:
            统计信息字典
        """
        return {
            "total_files": len(self.csv_files),
            "indexed_files": len(self.index_cache),
            "cache_enabled": self.cache_enabled
        }

