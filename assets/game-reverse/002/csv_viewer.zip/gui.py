"""
GUI主界面模块
使用tkinter实现图形用户界面
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from pathlib import Path
import threading
from typing import Optional, List
import pandas as pd

# 兼容打包后的导入
try:
    from .config import Config
    from .locale_manager import LocaleManager
    from .csv_manager import CSVManager
    from .search_engine import SearchEngine, SearchResult
except ImportError:
    from config import Config
    from locale_manager import LocaleManager
    from csv_manager import CSVManager
    from search_engine import SearchEngine, SearchResult


class CSVViewerGUI:
    """CSV查看器GUI主窗口"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("CSV数据表查看器 - Last War")
        
        # 配置和管理器
        self.config = Config()
        self.locale_manager = LocaleManager()
        self.csv_manager = CSVManager(self.locale_manager)
        self.search_engine = None
        
        # 状态变量
        self.current_locale_file = tk.StringVar(value="未选择")
        self.current_csv_file = tk.StringVar(value="未打开")
        self.status_text = tk.StringVar(value="就绪")
        
        # 设置窗口大小和位置
        window_size = self.config.get("window_size", [1200, 800])
        self.root.geometry(f"{window_size[0]}x{window_size[1]}")
        
        # 设置样式
        self.setup_styles()
        
        # 创建界面
        self.create_widgets()
        
        # 绑定关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # 加载上次的本地化文件
        last_locale = self.config.get("last_locale")
        if last_locale and Path(last_locale).exists():
            self.load_locale_file(last_locale)
    
    def setup_styles(self):
        """设置界面样式"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # 配置颜色
        style.configure('Title.TLabel', font=('Microsoft YaHei UI', 12, 'bold'))
        style.configure('Info.TLabel', font=('Microsoft YaHei UI', 9))
        style.configure('Status.TLabel', font=('Microsoft YaHei UI', 9), foreground='#666')
        
        # 按钮样式
        style.configure('Primary.TButton', font=('Microsoft YaHei UI', 10))
        style.configure('Success.TButton', font=('Microsoft YaHei UI', 10), foreground='#28a745')
        
        # Treeview样式
        style.configure('Treeview', font=('Microsoft YaHei UI', 9), rowheight=25)
        style.configure('Treeview.Heading', font=('Microsoft YaHei UI', 10, 'bold'))
    
    def create_widgets(self):
        """创建界面组件"""
        # 主容器
        main_container = ttk.Frame(self.root, padding="10")
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # 顶部工具栏
        self.create_toolbar(main_container)
        
        # 创建Notebook（标签页）
        self.notebook = ttk.Notebook(main_container)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        # 标签页1: CSV查看器
        self.create_csv_viewer_tab()
        
        # 标签页2: 搜索功能
        self.create_search_tab()
        
        # 标签页3: 设置
        self.create_settings_tab()
        
        # 底部状态栏
        self.create_statusbar(main_container)
    
    def create_toolbar(self, parent):
        """创建顶部工具栏"""
        toolbar = ttk.Frame(parent)
        toolbar.pack(fill=tk.X, pady=(0, 10))
        
        # 左侧：本地化文件选择
        left_frame = ttk.Frame(toolbar)
        left_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        ttk.Label(left_frame, text="当前语言:", style='Info.TLabel').pack(side=tk.LEFT, padx=(0, 5))
        ttk.Label(left_frame, textvariable=self.current_locale_file, 
                 style='Title.TLabel', foreground='#007bff').pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Button(left_frame, text="选择本地化文件", 
                  command=self.select_locale_file, style='Primary.TButton').pack(side=tk.LEFT, padx=5)
        
        # 右侧：当前CSV文件
        right_frame = ttk.Frame(toolbar)
        right_frame.pack(side=tk.RIGHT)
        
        ttk.Label(right_frame, text="当前文件:", style='Info.TLabel').pack(side=tk.LEFT, padx=(0, 5))
        ttk.Label(right_frame, textvariable=self.current_csv_file, 
                 style='Info.TLabel', foreground='#28a745').pack(side=tk.LEFT)
    
    def create_csv_viewer_tab(self):
        """创建CSV查看器标签页"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="📊 CSV查看器")
        
        # 顶部控制面板
        control_panel = ttk.LabelFrame(tab, text="文件操作", padding="10")
        control_panel.pack(fill=tk.X, padx=10, pady=10)
        
        # 第一行：文件操作
        row1 = ttk.Frame(control_panel)
        row1.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(row1, text="📂 打开CSV", command=self.open_csv_file, 
                  width=15).pack(side=tk.LEFT, padx=5)
        ttk.Button(row1, text="🔄 重新加载", command=self.reload_csv, 
                  width=15).pack(side=tk.LEFT, padx=5)
        ttk.Button(row1, text="📏 自适应列宽", command=self.auto_fit_columns, 
                  width=15).pack(side=tk.LEFT, padx=5)
        ttk.Button(row1, text="💾 导出CSV", command=self.export_csv, 
                  width=15).pack(side=tk.LEFT, padx=5)
        ttk.Button(row1, text="📑 导出Excel", command=self.export_excel, 
                  width=15).pack(side=tk.LEFT, padx=5)
        
        # 第二行：本地化操作
        row2 = ttk.Frame(control_panel)
        row2.pack(fill=tk.X)
        
        ttk.Label(row2, text="本地化操作:", style='Info.TLabel').pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(row2, text="✅ 本地化选中列", command=self.localize_selected, 
                  width=20, style='Success.TButton').pack(side=tk.LEFT, padx=5)
        ttk.Button(row2, text="↩️ 重置本地化", command=self.reset_localization, 
                  width=15).pack(side=tk.LEFT, padx=5)
        
        # 中间：列选择
        columns_frame = ttk.LabelFrame(tab, text="选择要本地化的列（勾选后点击'本地化选中列'）", padding="10")
        columns_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        # 创建滚动区域
        columns_scroll_frame = ttk.Frame(columns_frame)
        columns_scroll_frame.pack(fill=tk.BOTH, expand=True)
        
        self.columns_canvas = tk.Canvas(columns_scroll_frame, height=80)
        scrollbar = ttk.Scrollbar(columns_scroll_frame, orient="horizontal", command=self.columns_canvas.xview)
        self.columns_inner_frame = ttk.Frame(self.columns_canvas)
        
        self.columns_canvas.create_window((0, 0), window=self.columns_inner_frame, anchor="nw")
        self.columns_canvas.configure(xscrollcommand=scrollbar.set)
        
        self.columns_canvas.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.column_checkboxes = {}
        
        # 底部：数据表格
        table_frame = ttk.LabelFrame(tab, text="数据预览", padding="10")
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        # 创建Treeview
        tree_scroll_y = ttk.Scrollbar(table_frame, orient=tk.VERTICAL)
        tree_scroll_x = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL)
        
        self.csv_tree = ttk.Treeview(table_frame, 
                                     yscrollcommand=tree_scroll_y.set,
                                     xscrollcommand=tree_scroll_x.set,
                                     selectmode='browse')
        
        tree_scroll_y.config(command=self.csv_tree.yview)
        tree_scroll_x.config(command=self.csv_tree.xview)
        
        tree_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        tree_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.csv_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 绑定双击事件
        self.csv_tree.bind('<Double-1>', self.on_cell_double_click)
    
    def create_search_tab(self):
        """创建搜索标签页"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="🔍 搜索表格")
        
        # 顶部搜索框
        search_panel = ttk.LabelFrame(tab, text="搜索", padding="10")
        search_panel.pack(fill=tk.X, padx=10, pady=10)
        
        # 搜索输入
        input_frame = ttk.Frame(search_panel)
        input_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(input_frame, text="搜索内容:", style='Info.TLabel').pack(side=tk.LEFT, padx=(0, 10))
        self.search_entry = ttk.Entry(input_frame, font=('Microsoft YaHei UI', 11))
        self.search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        self.search_entry.bind('<Return>', lambda e: self.perform_search())
        
        ttk.Button(input_frame, text="🔍 搜索", command=self.perform_search, 
                  width=15, style='Primary.TButton').pack(side=tk.LEFT, padx=5)
        ttk.Button(input_frame, text="清空", command=self.clear_search, 
                  width=10).pack(side=tk.LEFT)
        
        # 搜索选项
        options_frame = ttk.Frame(search_panel)
        options_frame.pack(fill=tk.X)
        
        ttk.Label(options_frame, text="提示: 可以搜索前端显示的文案、本地化key或CSV中的任何内容", 
                 style='Status.TLabel', foreground='#666').pack(side=tk.LEFT)
        
        # 搜索结果
        results_frame = ttk.LabelFrame(tab, text="搜索结果", padding="10")
        results_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        # 结果列表
        result_scroll_y = ttk.Scrollbar(results_frame, orient=tk.VERTICAL)
        result_scroll_x = ttk.Scrollbar(results_frame, orient=tk.HORIZONTAL)
        
        self.search_tree = ttk.Treeview(results_frame,
                                       columns=('file', 'row', 'column', 'original', 'localized', 'score'),
                                       yscrollcommand=result_scroll_y.set,
                                       xscrollcommand=result_scroll_x.set,
                                       selectmode='browse')
        
        # 设置列
        self.search_tree.heading('#0', text='匹配类型')
        self.search_tree.heading('file', text='文件名')
        self.search_tree.heading('row', text='行号')
        self.search_tree.heading('column', text='列名')
        self.search_tree.heading('original', text='原始值')
        self.search_tree.heading('localized', text='本地化值')
        self.search_tree.heading('score', text='相关度')
        
        self.search_tree.column('#0', width=100, minwidth=80)
        self.search_tree.column('file', width=250, minwidth=150)
        self.search_tree.column('row', width=80, minwidth=60)
        self.search_tree.column('column', width=150, minwidth=100)
        self.search_tree.column('original', width=300, minwidth=150)
        self.search_tree.column('localized', width=300, minwidth=150)
        self.search_tree.column('score', width=100, minwidth=80)
        
        result_scroll_y.config(command=self.search_tree.yview)
        result_scroll_x.config(command=self.search_tree.xview)
        
        result_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        result_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        self.search_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 绑定双击事件
        self.search_tree.bind('<Double-1>', self.on_search_result_double_click)
        
        # 右键菜单
        self.search_context_menu = tk.Menu(self.search_tree, tearoff=0)
        self.search_context_menu.add_command(label="打开此文件", command=self.open_search_result_file)
        self.search_context_menu.add_command(label="复制文件路径", command=self.copy_file_path)
        self.search_tree.bind('<Button-3>', self.show_search_context_menu)
    
    def create_settings_tab(self):
        """创建设置标签页"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="⚙️ 设置")
        
        # CSV目录设置
        csv_dir_frame = ttk.LabelFrame(tab, text="CSV文件目录", padding="10")
        csv_dir_frame.pack(fill=tk.X, padx=10, pady=10)
        
        dir_input_frame = ttk.Frame(csv_dir_frame)
        dir_input_frame.pack(fill=tk.X)
        
        self.csv_dir_var = tk.StringVar(value=self.config.get("last_csv_dir", ""))
        ttk.Entry(dir_input_frame, textvariable=self.csv_dir_var, 
                 font=('Microsoft YaHei UI', 10)).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        ttk.Button(dir_input_frame, text="浏览", 
                  command=self.select_csv_directory).pack(side=tk.LEFT, padx=5)
        ttk.Button(dir_input_frame, text="扫描CSV文件", 
                  command=self.scan_csv_files).pack(side=tk.LEFT)
        
        # 本地化目录设置
        locale_dir_frame = ttk.LabelFrame(tab, text="本地化文件目录", padding="10")
        locale_dir_frame.pack(fill=tk.X, padx=10, pady=10)
        
        locale_input_frame = ttk.Frame(locale_dir_frame)
        locale_input_frame.pack(fill=tk.X)
        
        self.locale_dir_var = tk.StringVar(value=self.config.get("last_locale_dir", ""))
        ttk.Entry(locale_input_frame, textvariable=self.locale_dir_var, 
                 font=('Microsoft YaHei UI', 10)).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        ttk.Button(locale_input_frame, text="浏览", 
                  command=self.select_locale_directory).pack(side=tk.LEFT)
        
        # 搜索设置
        search_settings_frame = ttk.LabelFrame(tab, text="搜索设置", padding="10")
        search_settings_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(search_settings_frame, text="最大搜索结果数:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.max_results_var = tk.IntVar(value=self.config.get("search_settings", {}).get("max_results", 50))
        ttk.Spinbox(search_settings_frame, from_=10, to=200, textvariable=self.max_results_var, 
                   width=10).grid(row=0, column=1, sticky=tk.W, padx=10)
        
        ttk.Label(search_settings_frame, text="模糊匹配阈值:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.fuzzy_threshold_var = tk.DoubleVar(value=self.config.get("search_settings", {}).get("fuzzy_threshold", 0.6))
        ttk.Scale(search_settings_frame, from_=0.1, to=1.0, variable=self.fuzzy_threshold_var, 
                 orient=tk.HORIZONTAL, length=200).grid(row=1, column=1, sticky=tk.W, padx=10)
        ttk.Label(search_settings_frame, textvariable=self.fuzzy_threshold_var).grid(row=1, column=2, sticky=tk.W)
        
        # 保存按钮
        ttk.Button(tab, text="💾 保存设置", command=self.save_settings, 
                  style='Primary.TButton').pack(pady=20)
        
        # 统计信息
        stats_frame = ttk.LabelFrame(tab, text="统计信息", padding="10")
        stats_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.stats_text = scrolledtext.ScrolledText(stats_frame, height=10, 
                                                    font=('Consolas', 10), state='disabled')
        self.stats_text.pack(fill=tk.BOTH, expand=True)
        
        ttk.Button(stats_frame, text="🔄 刷新统计", command=self.update_stats).pack(pady=5)
    
    def create_statusbar(self, parent):
        """创建底部状态栏"""
        statusbar = ttk.Frame(parent)
        statusbar.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Label(statusbar, textvariable=self.status_text, 
                 style='Status.TLabel').pack(side=tk.LEFT)
        
        # 版本信息
        ttk.Label(statusbar, text="v1.0.0", 
                 style='Status.TLabel').pack(side=tk.RIGHT)
    
    # ========== 事件处理函数 ==========
    
    def select_locale_file(self):
        """选择本地化文件"""
        initial_dir = self.config.get("last_locale_dir", "")
        if not initial_dir or not Path(initial_dir).exists():
            initial_dir = str(Path.cwd())
        
        file_path = filedialog.askopenfilename(
            title="选择本地化文件",
            initialdir=initial_dir,
            filetypes=[("JSON文件", "*.json"), ("所有文件", "*.*")]
        )
        
        if file_path:
            self.load_locale_file(file_path)
    
    def load_locale_file(self, file_path: str):
        """加载本地化文件"""
        self.set_status("正在加载本地化文件...")
        
        if self.locale_manager.load_locale(file_path):
            locale_name = Path(file_path).stem
            self.current_locale_file.set(locale_name)
            self.config.set("last_locale", file_path)
            self.config.set("last_locale_dir", str(Path(file_path).parent))
            
            stats = self.locale_manager.get_stats()
            self.set_status(f"✅ 已加载 {locale_name} ({stats['total_keys']} 条)")
            
            # 初始化搜索引擎
            csv_dir = self.config.get("last_csv_dir", "")
            if csv_dir:
                self.search_engine = SearchEngine(csv_dir, self.locale_manager)
            
            messagebox.showinfo("成功", f"已加载本地化文件: {locale_name}\n共 {stats['total_keys']} 条记录")
        else:
            messagebox.showerror("错误", "加载本地化文件失败")
            self.set_status("❌ 加载本地化文件失败")
    
    def open_csv_file(self):
        """打开CSV文件"""
        if not self.locale_manager.current_locale:
            messagebox.showwarning("警告", "请先选择本地化文件")
            return
        
        initial_dir = self.config.get("last_csv_dir", "")
        if not initial_dir or not Path(initial_dir).exists():
            initial_dir = str(Path.cwd())
        
        file_path = filedialog.askopenfilename(
            title="选择CSV文件",
            initialdir=initial_dir,
            filetypes=[("CSV文件", "*.csv"), ("所有文件", "*.*")]
        )
        
        if file_path:
            self.load_csv_file(file_path)
    
    def load_csv_file(self, file_path: str):
        """加载CSV文件"""
        self.set_status("正在加载CSV文件...")
        
        if self.csv_manager.load_csv(file_path):
            file_name = Path(file_path).name
            self.current_csv_file.set(file_name)
            self.config.set("last_csv_dir", str(Path(file_path).parent))
            self.config.add_recent_file(file_path)
            
            # 更新界面
            self.update_csv_display()
            self.update_column_checkboxes()
            
            stats = self.csv_manager.get_stats()
            self.set_status(f"✅ 已加载 {file_name} ({stats['total_rows']} 行 × {stats['total_columns']} 列)")
        else:
            messagebox.showerror("错误", "加载CSV文件失败")
            self.set_status("❌ 加载CSV文件失败")
    
    def update_csv_display(self):
        """更新CSV显示"""
        # 清空现有数据
        self.csv_tree.delete(*self.csv_tree.get_children())
        
        if self.csv_manager.df is None:
            return
        
        # 设置列
        columns = list(self.csv_manager.df.columns)
        self.csv_tree['columns'] = columns
        self.csv_tree.heading('#0', text='行号')
        self.csv_tree.column('#0', width=80, minwidth=50)
        
        # 插入数据（最多显示100行）
        preview_df = self.csv_manager.get_preview_data(100)
        
        # 计算每列的合适宽度
        for col in columns:
            self.csv_tree.heading(col, text=col)
            
            # 计算列宽：基于列名和内容
            # 列名宽度
            header_width = len(str(col)) * 10 + 20
            
            # 内容宽度（取前10行的最大值）
            max_content_width = 0
            for value in preview_df[col].head(10):
                if not pd.isna(value):
                    content_len = len(str(value))
                    max_content_width = max(max_content_width, content_len)
            
            content_width = max_content_width * 8 + 20
            
            # 取较大值，但设置最小值和最大值
            col_width = max(header_width, content_width)
            col_width = max(120, min(col_width, 400))  # 最小120，最大400
            
            self.csv_tree.column(col, width=col_width, minwidth=80)
        
        # 插入数据
        for idx, row in preview_df.iterrows():
            values = [str(v) if not pd.isna(v) else '' for v in row]
            self.csv_tree.insert('', tk.END, text=str(idx + 1), values=values)
    
    def update_column_checkboxes(self):
        """更新列选择复选框"""
        # 清空现有复选框
        for widget in self.columns_inner_frame.winfo_children():
            widget.destroy()
        self.column_checkboxes.clear()
        
        if self.csv_manager.df is None or len(self.csv_manager.headers) == 0:
            ttk.Label(self.columns_inner_frame, text="请先打开CSV文件", 
                     foreground='#999').pack(side=tk.LEFT, padx=5)
            return
        
        # 显示所有列，让用户自己选择
        # 默认不勾选任何列
        for col in self.csv_manager.headers:
            var = tk.BooleanVar(value=False)
            cb = ttk.Checkbutton(self.columns_inner_frame, text=col, variable=var)
            cb.pack(side=tk.LEFT, padx=10)
            self.column_checkboxes[col] = var
        
        # 更新canvas滚动区域
        self.columns_inner_frame.update_idletasks()
        self.columns_canvas.configure(scrollregion=self.columns_canvas.bbox("all"))
    
    
    def localize_selected(self):
        """本地化选中的列"""
        if self.csv_manager.df is None:
            messagebox.showwarning("警告", "请先打开CSV文件")
            return
        
        # 获取选中的列
        selected_columns = [col for col, var in self.column_checkboxes.items() if var.get()]
        
        if not selected_columns:
            messagebox.showwarning("警告", "请至少选择一列")
            return
        
        self.set_status(f"正在本地化 {len(selected_columns)} 列...")
        
        # 在后台线程中执行本地化
        def localize_task():
            success = self.csv_manager.localize_columns(selected_columns, keep_original=False)
            
            # 在主线程中更新UI
            self.root.after(0, lambda: self.on_localize_complete(success, selected_columns))
        
        threading.Thread(target=localize_task, daemon=True).start()
    
    def on_localize_complete(self, success: bool, columns: List[str]):
        """本地化完成回调"""
        if success:
            self.update_csv_display()
            self.set_status(f"✅ 已本地化 {len(columns)} 列: {', '.join(columns)}")
            messagebox.showinfo("成功", f"已本地化 {len(columns)} 列")
        else:
            self.set_status("❌ 本地化失败")
            messagebox.showerror("错误", "本地化失败")
    
    def reset_localization(self):
        """重置本地化"""
        if self.csv_manager.df is None:
            return
        
        self.csv_manager.reset_localization()
        self.update_csv_display()
        self.set_status("✅ 已重置本地化")
    
    def reload_csv(self):
        """重新加载CSV"""
        if self.csv_manager.current_file:
            self.load_csv_file(self.csv_manager.current_file)
    
    def auto_fit_columns(self):
        """自适应列宽"""
        if self.csv_manager.df is None:
            messagebox.showwarning("警告", "请先打开CSV文件")
            return
        
        self.set_status("正在调整列宽...")
        
        # 重新计算并设置列宽
        columns = list(self.csv_manager.df.columns)
        preview_df = self.csv_manager.get_preview_data(100)
        
        for col in columns:
            # 计算列宽：基于列名和内容
            header_width = len(str(col)) * 10 + 20
            
            # 内容宽度（取所有显示行的最大值）
            max_content_width = 0
            for value in preview_df[col]:
                if not pd.isna(value):
                    content_len = len(str(value))
                    max_content_width = max(max_content_width, content_len)
            
            content_width = max_content_width * 8 + 20
            
            # 取较大值，但设置最小值和最大值
            col_width = max(header_width, content_width)
            col_width = max(120, min(col_width, 500))  # 最小120，最大500
            
            self.csv_tree.column(col, width=col_width)
        
        self.set_status("✅ 列宽已自适应调整")
    
    def export_csv(self):
        """导出CSV"""
        if self.csv_manager.df is None:
            messagebox.showwarning("警告", "没有可导出的数据")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="导出CSV",
            defaultextension=".csv",
            filetypes=[("CSV文件", "*.csv"), ("所有文件", "*.*")]
        )
        
        if file_path:
            if self.csv_manager.export_csv(file_path):
                messagebox.showinfo("成功", f"已导出到: {file_path}")
                self.set_status(f"✅ 已导出: {Path(file_path).name}")
            else:
                messagebox.showerror("错误", "导出失败")
    
    def export_excel(self):
        """导出Excel"""
        if self.csv_manager.df is None:
            messagebox.showwarning("警告", "没有可导出的数据")
            return
        
        file_path = filedialog.asksaveasfilename(
            title="导出Excel",
            defaultextension=".xlsx",
            filetypes=[("Excel文件", "*.xlsx"), ("所有文件", "*.*")]
        )
        
        if file_path:
            if self.csv_manager.export_excel(file_path):
                messagebox.showinfo("成功", f"已导出到: {file_path}")
                self.set_status(f"✅ 已导出: {Path(file_path).name}")
            else:
                messagebox.showerror("错误", "导出失败")
    
    def perform_search(self):
        """执行搜索"""
        query = self.search_entry.get().strip()
        
        if not query:
            messagebox.showwarning("警告", "请输入搜索内容")
            return
        
        if not self.locale_manager.current_locale:
            messagebox.showwarning("警告", "请先选择本地化文件")
            return
        
        csv_dir = self.csv_dir_var.get()
        if not csv_dir or not Path(csv_dir).exists():
            messagebox.showwarning("警告", "请先设置CSV文件目录")
            self.notebook.select(2)  # 切换到设置页
            return
        
        # 初始化搜索引擎
        if not self.search_engine:
            print("[DEBUG] 初始化搜索引擎...")
            self.search_engine = SearchEngine(csv_dir, self.locale_manager)
            self.search_engine.scan_csv_files()
            print(f"[DEBUG] 扫描到 {len(self.search_engine.csv_files)} 个CSV文件")
        
        self.set_status(f"正在搜索: {query}...")
        print(f"[DEBUG] 开始搜索: {query}")
        
        # 在后台线程中执行搜索
        def search_task():
            try:
                results = self.search_engine.search(query, max_results=self.max_results_var.get())
                print(f"[DEBUG] 搜索完成，找到 {len(results)} 个结果")
                self.root.after(0, lambda: self.display_search_results(results, query))
            except Exception as e:
                print(f"[ERROR] 搜索失败: {e}")
                import traceback
                traceback.print_exc()
                self.root.after(0, lambda: messagebox.showerror("搜索错误", f"搜索时出现错误:\n{str(e)}"))
        
        threading.Thread(target=search_task, daemon=True).start()
    
    def display_search_results(self, results: List[SearchResult], query: str):
        """显示搜索结果"""
        # 清空现有结果
        self.search_tree.delete(*self.search_tree.get_children())
        
        if not results:
            self.set_status(f"未找到匹配 '{query}' 的结果")
            messagebox.showinfo("搜索完成", "未找到匹配的结果")
            return
        
        # 插入结果
        match_type_icons = {
            'exact': '🎯',
            'partial': '📍',
            'value': '💬',
            'index': '🔑'
        }
        
        for result in results:
            icon = match_type_icons.get(result.match_type, '📄')
            self.search_tree.insert('', tk.END, 
                                   text=f"{icon} {result.match_type}",
                                   values=(
                                       result.file_name,
                                       result.row_index + 1,
                                       result.column_name,
                                       result.original_value[:50],
                                       result.localized_value[:50],
                                       f"{result.score:.2f}"
                                   ),
                                   tags=(result.file_path,))
        
        self.set_status(f"✅ 找到 {len(results)} 个匹配 '{query}' 的结果")
    
    def clear_search(self):
        """清空搜索"""
        self.search_entry.delete(0, tk.END)
        self.search_tree.delete(*self.search_tree.get_children())
        self.set_status("就绪")
    
    def on_search_result_double_click(self, event):
        """双击搜索结果"""
        self.open_search_result_file()
    
    def open_search_result_file(self):
        """打开搜索结果对应的文件"""
        selection = self.search_tree.selection()
        if not selection:
            return
        
        item = self.search_tree.item(selection[0])
        file_path = item['tags'][0]
        
        self.load_csv_file(file_path)
        self.notebook.select(0)  # 切换到CSV查看器页
    
    def show_search_context_menu(self, event):
        """显示搜索结果右键菜单"""
        item = self.search_tree.identify_row(event.y)
        if item:
            self.search_tree.selection_set(item)
            self.search_context_menu.post(event.x_root, event.y_root)
    
    def copy_file_path(self):
        """复制文件路径"""
        selection = self.search_tree.selection()
        if not selection:
            return
        
        item = self.search_tree.item(selection[0])
        file_path = item['tags'][0]
        
        self.root.clipboard_clear()
        self.root.clipboard_append(file_path)
        self.set_status(f"✅ 已复制路径: {file_path}")
    
    def on_cell_double_click(self, event):
        """双击单元格显示完整内容"""
        item = self.csv_tree.selection()
        if not item:
            return
        
        column = self.csv_tree.identify_column(event.x)
        if column == '#0':
            return
        
        col_index = int(column.replace('#', '')) - 1
        col_name = self.csv_tree['columns'][col_index]
        
        values = self.csv_tree.item(item[0])['values']
        if col_index < len(values):
            content = values[col_index]
            
            # 创建对话框显示完整内容
            dialog = tk.Toplevel(self.root)
            dialog.title(f"单元格内容 - {col_name}")
            dialog.geometry("600x400")
            
            text = scrolledtext.ScrolledText(dialog, wrap=tk.WORD, font=('Microsoft YaHei UI', 10))
            text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            text.insert(1.0, content)
            text.config(state='disabled')
            
            ttk.Button(dialog, text="关闭", command=dialog.destroy).pack(pady=5)
    
    def select_csv_directory(self):
        """选择CSV目录"""
        directory = filedialog.askdirectory(title="选择CSV文件目录")
        if directory:
            self.csv_dir_var.set(directory)
            self.config.set("last_csv_dir", directory)
    
    def select_locale_directory(self):
        """选择本地化目录"""
        directory = filedialog.askdirectory(title="选择本地化文件目录")
        if directory:
            self.locale_dir_var.set(directory)
            self.config.set("last_locale_dir", directory)
    
    def scan_csv_files(self):
        """扫描CSV文件"""
        csv_dir = self.csv_dir_var.get()
        if not csv_dir or not Path(csv_dir).exists():
            messagebox.showwarning("警告", "请先选择有效的CSV目录")
            return
        
        if not self.search_engine:
            self.search_engine = SearchEngine(csv_dir, self.locale_manager)
        
        self.set_status("正在扫描CSV文件...")
        files = self.search_engine.scan_csv_files()
        
        self.set_status(f"✅ 扫描完成，找到 {len(files)} 个CSV文件")
        messagebox.showinfo("扫描完成", f"找到 {len(files)} 个CSV文件")
    
    def save_settings(self):
        """保存设置"""
        self.config.set("last_csv_dir", self.csv_dir_var.get())
        self.config.set("last_locale_dir", self.locale_dir_var.get())
        
        search_settings = {
            "max_results": self.max_results_var.get(),
            "fuzzy_threshold": self.fuzzy_threshold_var.get()
        }
        self.config.set("search_settings", search_settings)
        
        messagebox.showinfo("成功", "设置已保存")
        self.set_status("✅ 设置已保存")
    
    def update_stats(self):
        """更新统计信息"""
        stats_lines = []
        
        # 本地化统计
        if self.locale_manager.current_locale:
            locale_stats = self.locale_manager.get_stats()
            stats_lines.append("=== 本地化统计 ===")
            stats_lines.append(f"当前语言: {self.locale_manager.current_locale}")
            stats_lines.append(f"总键值对数: {locale_stats['total_keys']}")
            stats_lines.append(f"唯一值数量: {locale_stats['total_values']}")
            stats_lines.append(f"索引词数量: {locale_stats['total_partial_words']}")
            stats_lines.append("")
        
        # CSV统计
        if self.csv_manager.current_file:
            csv_stats = self.csv_manager.get_stats()
            stats_lines.append("=== 当前CSV统计 ===")
            stats_lines.append(f"文件名: {csv_stats['file_name']}")
            stats_lines.append(f"总行数: {csv_stats['total_rows']}")
            stats_lines.append(f"总列数: {csv_stats['total_columns']}")
            stats_lines.append(f"可本地化列: {csv_stats['localizable_columns']}")
            stats_lines.append(f"已本地化列: {csv_stats['localized_columns']}")
            stats_lines.append("")
        
        # 搜索引擎统计
        if self.search_engine:
            search_stats = self.search_engine.get_stats()
            stats_lines.append("=== 搜索引擎统计 ===")
            stats_lines.append(f"CSV文件总数: {search_stats['total_files']}")
            stats_lines.append(f"已索引文件: {search_stats['indexed_files']}")
            stats_lines.append(f"缓存状态: {'启用' if search_stats['cache_enabled'] else '禁用'}")
        
        # 更新显示
        self.stats_text.config(state='normal')
        self.stats_text.delete(1.0, tk.END)
        self.stats_text.insert(1.0, '\n'.join(stats_lines))
        self.stats_text.config(state='disabled')
    
    def set_status(self, text: str):
        """设置状态栏文本"""
        self.status_text.set(text)
        self.root.update_idletasks()
    
    def on_closing(self):
        """窗口关闭事件"""
        # 保存窗口大小
        self.config.set("window_size", [self.root.winfo_width(), self.root.winfo_height()])
        self.root.destroy()
    
    def run(self):
        """运行GUI"""
        self.root.mainloop()


def main():
    """主函数"""
    app = CSVViewerGUI()
    app.run()


if __name__ == '__main__':
    main()

