"""
本地化管理模块
负责加载和管理本地化文件，提供正向和反向查询功能
"""
import json
import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional


class LocaleManager:
    """本地化管理器"""
    
    def __init__(self):
        self.locale_data: Dict[str, str] = {}  # index -> value
        self.reverse_index: Dict[str, List[str]] = {}  # value -> [indexes]
        self.partial_index: Dict[str, List[str]] = {}  # 部分匹配索引
        self.current_locale: Optional[str] = None
        self.locale_file_path: Optional[str] = None
    
    def load_locale(self, locale_file_path: str) -> bool:
        """
        加载本地化文件
        
        Args:
            locale_file_path: 本地化JSON文件路径
            
        Returns:
            是否加载成功
        """
        try:
            with open(locale_file_path, 'r', encoding='utf-8') as f:
                self.locale_data = json.load(f)
            
            self.locale_file_path = locale_file_path
            self.current_locale = Path(locale_file_path).stem
            
            # 构建反向索引
            self._build_reverse_index()
            
            return True
        except Exception as e:
            print(f"加载本地化文件失败: {e}")
            return False
    
    def _build_reverse_index(self):
        """构建反向索引，用于快速搜索"""
        self.reverse_index.clear()
        self.partial_index.clear()
        
        for index, value in self.locale_data.items():
            # 完整匹配索引
            if value not in self.reverse_index:
                self.reverse_index[value] = []
            self.reverse_index[value].append(index)
            
            # 部分匹配索引（分词）
            # 去除标点符号后分词
            words = self._tokenize(value)
            for word in words:
                if len(word) >= 2:  # 只索引长度>=2的词
                    if word not in self.partial_index:
                        self.partial_index[word] = []
                    if index not in self.partial_index[word]:
                        self.partial_index[word].append(index)
    
    def _tokenize(self, text: str) -> List[str]:
        """
        简单的分词函数
        
        Args:
            text: 待分词的文本
            
        Returns:
            词列表
        """
        # 移除标点符号
        text = re.sub(r'[^\w\s]', ' ', text)
        # 分割成词
        words = text.split()
        
        # 对于中文，也尝试提取连续的字符组合
        chinese_chars = re.findall(r'[\u4e00-\u9fff]+', text)
        for chars in chinese_chars:
            # 提取2-4字的组合
            for length in [2, 3, 4]:
                for i in range(len(chars) - length + 1):
                    words.append(chars[i:i+length])
        
        return list(set(words))
    
    def get_value(self, index: str) -> Optional[str]:
        """
        根据index获取本地化文本
        
        Args:
            index: 本地化key
            
        Returns:
            本地化后的文本，如果不存在返回None
        """
        return self.locale_data.get(index)
    
    def find_indexes_exact(self, value: str) -> List[str]:
        """
        根据value精确查找index
        
        Args:
            value: 本地化后的文本
            
        Returns:
            匹配的index列表
        """
        return self.reverse_index.get(value, [])
    
    def find_indexes_fuzzy(self, query: str, threshold: float = 0.6) -> List[Tuple[str, float]]:
        """
        根据query模糊查找index
        
        Args:
            query: 查询文本
            threshold: 相似度阈值 (0-1)
            
        Returns:
            [(index, score), ...] 按相似度排序
        """
        results = []
        query_lower = query.lower()
        
        # 1. 精确匹配
        exact_matches = self.find_indexes_exact(query)
        for index in exact_matches:
            results.append((index, 1.0))
        
        # 2. 包含匹配（改进的评分算法）
        for value, indexes in self.reverse_index.items():
            value_lower = value.lower()
            if query_lower in value_lower and query not in value:
                # 基础分：匹配长度比例
                base_score = len(query) / len(value)
                
                # 位置加成：开头匹配得分更高
                if value_lower.startswith(query_lower):
                    position_bonus = 0.2
                elif value_lower.find(query_lower) <= 2:
                    position_bonus = 0.1
                else:
                    position_bonus = 0.0
                
                # 完整词加成
                word_bonus = 0.0
                query_pos = value_lower.find(query_lower)
                if query_pos >= 0:
                    # 检查是否是完整的词
                    before_ok = (query_pos == 0 or value_lower[query_pos-1] in '：:，,。.！!？?、 ')
                    after_ok = (query_pos + len(query_lower) >= len(value_lower) or 
                               value_lower[query_pos + len(query_lower)] in '：:，,。.！!？?、 ')
                    if before_ok and after_ok:
                        word_bonus = 0.3  # 完整词匹配给予更高加成
                
                score = min(1.0, base_score + position_bonus + word_bonus)
                
                if score >= threshold:
                    for index in indexes:
                        if (index, 1.0) not in results:
                            results.append((index, score))
        
        # 3. 部分词匹配
        query_words = self._tokenize(query)
        for word in query_words:
            if word in self.partial_index:
                for index in self.partial_index[word]:
                    # 检查是否已经添加
                    if not any(idx == index for idx, _ in results):
                        value = self.locale_data.get(index, "")
                        score = len(word) / max(len(query), len(value))
                        if score >= threshold * 0.5:  # 降低部分匹配的阈值
                            results.append((index, score * 0.8))  # 降低部分匹配的得分
        
        # 按得分排序
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results
    
    def is_localized_key(self, text: str) -> bool:
        """
        判断一个字符串是否是本地化key
        
        Args:
            text: 待判断的文本
            
        Returns:
            是否是本地化key
        """
        return text in self.locale_data
    
    def get_stats(self) -> Dict[str, int]:
        """
        获取统计信息
        
        Returns:
            统计信息字典
        """
        return {
            "total_keys": len(self.locale_data),
            "total_values": len(self.reverse_index),
            "total_partial_words": len(self.partial_index)
        }
    
    def search_by_text(self, text: str) -> List[Tuple[str, str, float]]:
        """
        根据文本搜索，返回匹配的 (index, value, score)
        
        Args:
            text: 搜索文本
            
        Returns:
            [(index, value, score), ...] 按相似度排序
        """
        results = []
        
        # 1. 尝试作为index搜索
        if text in self.locale_data:
            results.append((text, self.locale_data[text], 1.0))
        
        # 2. 尝试作为value搜索
        fuzzy_results = self.find_indexes_fuzzy(text)
        for index, score in fuzzy_results:
            value = self.locale_data.get(index, "")
            if (index, value, 1.0) not in results:
                results.append((index, value, score))
        
        return results

