"""
CSV Viewer 主程序入口
"""
import sys
import os
from pathlib import Path

# 确定应用程序路径
if getattr(sys, 'frozen', False):
    # 打包后的环境：exe所在目录
    application_path = Path(sys.executable).parent
    # PyInstaller 会将所有模块打包到 _MEIPASS 临时目录
    if hasattr(sys, '_MEIPASS'):
        sys.path.insert(0, sys._MEIPASS)
    sys.path.insert(0, str(application_path))
else:
    # 开发环境：添加项目根目录
    current_dir = Path(__file__).parent
    project_root = current_dir.parent.parent
    sys.path.insert(0, str(project_root))
    sys.path.insert(0, str(current_dir))

# 导入主函数
try:
    if getattr(sys, 'frozen', False):
        # 打包环境：直接导入
        import gui
        main = gui.main
    else:
        # 开发环境：使用完整路径
        from src.csv_viewer.gui import main
except ImportError as e:
    print("="*50)
    print(f"CRITICAL ERROR: {e}")
    print(f"Current sys.path: {sys.path}")
    if hasattr(sys, '_MEIPASS'):
        print(f"MEIPASS content ({sys._MEIPASS}):")
        try:
            for f in os.listdir(sys._MEIPASS):
                print(f"  - {f}")
        except Exception as list_err:
            print(f"  Cannot list MEIPASS: {list_err}")
    print("="*50)
    input("Press Enter to exit...") # 暂停以便用户看到错误
    raise

if __name__ == '__main__':
    main()

