"""
CSV Viewer - 游戏数据表查看和本地化工具

为策划人员提供友好的GUI界面，用于查看和管理游戏配置表。
"""

__version__ = "1.0.0"
__author__ = "AI Assistant"

