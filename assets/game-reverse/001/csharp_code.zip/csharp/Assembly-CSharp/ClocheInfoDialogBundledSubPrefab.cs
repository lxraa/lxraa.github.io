﻿using System;
using Il2CppDummyDll;
using UnityEngine;

// Token: 0x0200000B RID: 11
[Token(Token = "0x200000B")]
public class ClocheInfoDialogBundledSubPrefab : MonoBehaviour
{
	// Token: 0x0600001B RID: 27 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x600001B")]
	[Address(RVA = "0x1246CD8", Offset = "0x1246CD8", VA = "0x1246CD8")]
	public void LoadClocheSprites()
	{
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x600001C")]
	[Address(RVA = "0x1246DB8", Offset = "0x1246DB8", VA = "0x1246DB8")]
	public ClocheInfoDialogBundledSubPrefab()
	{
	}

	// Token: 0x04000022 RID: 34
	[Token(Token = "0x4000022")]
	[FieldOffset(Offset = "0x18")]
	public GameObject[] clocheFlags;

	// Token: 0x04000023 RID: 35
	[Token(Token = "0x4000023")]
	[FieldOffset(Offset = "0x20")]
	public GameObject[] clocheParticles;

	// Token: 0x04000024 RID: 36
	[Token(Token = "0x4000024")]
	[FieldOffset(Offset = "0x28")]
	public SpriteRenderer[] clocheSpriteRenderers;
}
