﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace Google.Impl
{
	// Token: 0x0200262A RID: 9770
	[Token(Token = "0x200262A")]
	public class SignInHelperObject : MonoBehaviour
	{
		// Token: 0x17002824 RID: 10276
		// (get) Token: 0x06013102 RID: 78082 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002824")]
		internal static SignInHelperObject Instance
		{
			[Token(Token = "0x6013102")]
			[Address(RVA = "0x24C89A4", Offset = "0x24C89A4", VA = "0x24C89A4")]
			get
			{
				return null;
			}
		}

		// Token: 0x06013103 RID: 78083 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013103")]
		[Address(RVA = "0x24C8AE0", Offset = "0x24C8AE0", VA = "0x24C8AE0")]
		public SignInHelperObject()
		{
		}

		// Token: 0x0400F01E RID: 61470
		[Token(Token = "0x400F01E")]
		[FieldOffset(Offset = "0x0")]
		private static SignInHelperObject instance;
	}
}
