﻿using System;
using Il2CppDummyDll;

// Token: 0x02000004 RID: 4
[Token(Token = "0x2000004")]
public static class Packer
{
	// Token: 0x0600000E RID: 14 RVA: 0x00002088 File Offset: 0x00000288
	[Token(Token = "0x600000E")]
	[Address(RVA = "0x12464AC", Offset = "0x12464AC", VA = "0x12464AC")]
	public static float ToFloat(float x, float y, float z)
	{
		return 0f;
	}

	// Token: 0x0600000F RID: 15 RVA: 0x000020A0 File Offset: 0x000002A0
	[Token(Token = "0x600000F")]
	[Address(RVA = "0x12466B4", Offset = "0x12466B4", VA = "0x12466B4")]
	public static float ToFloat(float x, float y)
	{
		return 0f;
	}
}
