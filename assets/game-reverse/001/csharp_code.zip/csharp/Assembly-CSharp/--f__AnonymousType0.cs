﻿using System;
using System.Diagnostics;
using Il2CppDummyDll;

// Token: 0x02000002 RID: 2
[Token(Token = "0x2000002")]
internal sealed class <>f__AnonymousType0<<card>j__TPar, <index>j__TPar>
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	[Token(Token = "0x17000001")]
	public <card>j__TPar card
	{
		[Token(Token = "0x6000001")]
		get
		{
			return null;
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000002 RID: 2 RVA: 0x00002050 File Offset: 0x00000250
	[Token(Token = "0x17000002")]
	public <index>j__TPar index
	{
		[Token(Token = "0x6000002")]
		get
		{
			return null;
		}
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x6000003")]
	[DebuggerHidden]
	public <>f__AnonymousType0(<card>j__TPar card, <index>j__TPar index)
	{
	}

	// Token: 0x06000004 RID: 4 RVA: 0x00002058 File Offset: 0x00000258
	[Token(Token = "0x6000004")]
	[DebuggerHidden]
	public override bool Equals(object value)
	{
		return default(bool);
	}

	// Token: 0x06000005 RID: 5 RVA: 0x00002070 File Offset: 0x00000270
	[Token(Token = "0x6000005")]
	[DebuggerHidden]
	public override int GetHashCode()
	{
		return 0;
	}

	// Token: 0x06000006 RID: 6 RVA: 0x00002050 File Offset: 0x00000250
	[Token(Token = "0x6000006")]
	[DebuggerHidden]
	public override string ToString()
	{
		return null;
	}

	// Token: 0x04000001 RID: 1
	[Token(Token = "0x4000001")]
	[FieldOffset(Offset = "0x0")]
	private readonly <card>j__TPar <card>i__Field;

	// Token: 0x04000002 RID: 2
	[Token(Token = "0x4000002")]
	[FieldOffset(Offset = "0x0")]
	private readonly <index>j__TPar <index>i__Field;
}
