﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x02002687 RID: 9863
	[Token(Token = "0x2002687")]
	public class UIDissolve : UIEffectBase
	{
		// Token: 0x1700284B RID: 10315
		// (get) Token: 0x0601325C RID: 78428 RVA: 0x0007B540 File Offset: 0x00079740
		[Token(Token = "0x1700284B")]
		public override AdditionalCanvasShaderChannels requiredChannels
		{
			[Token(Token = "0x601325C")]
			[Address(RVA = "0x24DC34C", Offset = "0x24DC34C", VA = "0x24DC34C", Slot = "19")]
			get
			{
				return AdditionalCanvasShaderChannels.None;
			}
		}

		// Token: 0x1700284C RID: 10316
		// (get) Token: 0x0601325D RID: 78429 RVA: 0x0007B558 File Offset: 0x00079758
		// (set) Token: 0x0601325E RID: 78430 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700284C")]
		[Obsolete("Use effectFactor instead (UnityUpgradable) -> effectFactor")]
		public float location
		{
			[Token(Token = "0x601325D")]
			[Address(RVA = "0x24DC368", Offset = "0x24DC368", VA = "0x24DC368")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x601325E")]
			[Address(RVA = "0x24DC370", Offset = "0x24DC370", VA = "0x24DC370")]
			set
			{
			}
		}

		// Token: 0x1700284D RID: 10317
		// (get) Token: 0x0601325F RID: 78431 RVA: 0x0007B570 File Offset: 0x00079770
		// (set) Token: 0x06013260 RID: 78432 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700284D")]
		public float effectFactor
		{
			[Token(Token = "0x601325F")]
			[Address(RVA = "0x24DC438", Offset = "0x24DC438", VA = "0x24DC438")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013260")]
			[Address(RVA = "0x24DC440", Offset = "0x24DC440", VA = "0x24DC440")]
			set
			{
			}
		}

		// Token: 0x1700284E RID: 10318
		// (get) Token: 0x06013261 RID: 78433 RVA: 0x0007B588 File Offset: 0x00079788
		// (set) Token: 0x06013262 RID: 78434 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700284E")]
		public float width
		{
			[Token(Token = "0x6013261")]
			[Address(RVA = "0x24DC508", Offset = "0x24DC508", VA = "0x24DC508")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013262")]
			[Address(RVA = "0x24DC510", Offset = "0x24DC510", VA = "0x24DC510")]
			set
			{
			}
		}

		// Token: 0x1700284F RID: 10319
		// (get) Token: 0x06013263 RID: 78435 RVA: 0x0007B5A0 File Offset: 0x000797A0
		// (set) Token: 0x06013264 RID: 78436 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700284F")]
		public float softness
		{
			[Token(Token = "0x6013263")]
			[Address(RVA = "0x24DC5D8", Offset = "0x24DC5D8", VA = "0x24DC5D8")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013264")]
			[Address(RVA = "0x24DC5E0", Offset = "0x24DC5E0", VA = "0x24DC5E0")]
			set
			{
			}
		}

		// Token: 0x17002850 RID: 10320
		// (get) Token: 0x06013265 RID: 78437 RVA: 0x0007B5B8 File Offset: 0x000797B8
		// (set) Token: 0x06013266 RID: 78438 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002850")]
		public Color color
		{
			[Token(Token = "0x6013265")]
			[Address(RVA = "0x24DC6A8", Offset = "0x24DC6A8", VA = "0x24DC6A8")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x6013266")]
			[Address(RVA = "0x24DC6B4", Offset = "0x24DC6B4", VA = "0x24DC6B4")]
			set
			{
			}
		}

		// Token: 0x17002851 RID: 10321
		// (get) Token: 0x06013267 RID: 78439 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06013268 RID: 78440 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002851")]
		public Texture noiseTexture
		{
			[Token(Token = "0x6013267")]
			[Address(RVA = "0x24DC714", Offset = "0x24DC714", VA = "0x24DC714")]
			get
			{
				return null;
			}
			[Token(Token = "0x6013268")]
			[Address(RVA = "0x24DC78C", Offset = "0x24DC78C", VA = "0x24DC78C")]
			set
			{
			}
		}

		// Token: 0x17002852 RID: 10322
		// (get) Token: 0x06013269 RID: 78441 RVA: 0x0007B5D0 File Offset: 0x000797D0
		// (set) Token: 0x0601326A RID: 78442 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002852")]
		public EffectArea effectArea
		{
			[Token(Token = "0x6013269")]
			[Address(RVA = "0x24DC86C", Offset = "0x24DC86C", VA = "0x24DC86C")]
			get
			{
				return EffectArea.RectTransform;
			}
			[Token(Token = "0x601326A")]
			[Address(RVA = "0x24DC874", Offset = "0x24DC874", VA = "0x24DC874")]
			set
			{
			}
		}

		// Token: 0x17002853 RID: 10323
		// (get) Token: 0x0601326B RID: 78443 RVA: 0x0007B5E8 File Offset: 0x000797E8
		// (set) Token: 0x0601326C RID: 78444 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002853")]
		public bool keepAspectRatio
		{
			[Token(Token = "0x601326B")]
			[Address(RVA = "0x24DC898", Offset = "0x24DC898", VA = "0x24DC898")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x601326C")]
			[Address(RVA = "0x24DC8A0", Offset = "0x24DC8A0", VA = "0x24DC8A0")]
			set
			{
			}
		}

		// Token: 0x17002854 RID: 10324
		// (get) Token: 0x0601326D RID: 78445 RVA: 0x0007B600 File Offset: 0x00079800
		[Token(Token = "0x17002854")]
		public ColorMode colorMode
		{
			[Token(Token = "0x601326D")]
			[Address(RVA = "0x24DC8C8", Offset = "0x24DC8C8", VA = "0x24DC8C8")]
			get
			{
				return ColorMode.Multiply;
			}
		}

		// Token: 0x17002855 RID: 10325
		// (get) Token: 0x0601326E RID: 78446 RVA: 0x0007B618 File Offset: 0x00079818
		// (set) Token: 0x0601326F RID: 78447 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002855")]
		[Obsolete("Use Play/Stop method instead")]
		public bool play
		{
			[Token(Token = "0x601326E")]
			[Address(RVA = "0x24DC8D0", Offset = "0x24DC8D0", VA = "0x24DC8D0")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x601326F")]
			[Address(RVA = "0x24DC964", Offset = "0x24DC964", VA = "0x24DC964")]
			set
			{
			}
		}

		// Token: 0x17002856 RID: 10326
		// (get) Token: 0x06013270 RID: 78448 RVA: 0x0007B630 File Offset: 0x00079830
		// (set) Token: 0x06013271 RID: 78449 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002856")]
		[Obsolete]
		public bool loop
		{
			[Token(Token = "0x6013270")]
			[Address(RVA = "0x24DC988", Offset = "0x24DC988", VA = "0x24DC988")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6013271")]
			[Address(RVA = "0x24DC9A4", Offset = "0x24DC9A4", VA = "0x24DC9A4")]
			set
			{
			}
		}

		// Token: 0x17002857 RID: 10327
		// (get) Token: 0x06013272 RID: 78450 RVA: 0x0007B648 File Offset: 0x00079848
		// (set) Token: 0x06013273 RID: 78451 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002857")]
		public float duration
		{
			[Token(Token = "0x6013272")]
			[Address(RVA = "0x24DC9C8", Offset = "0x24DC9C8", VA = "0x24DC9C8")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013273")]
			[Address(RVA = "0x24DC9E4", Offset = "0x24DC9E4", VA = "0x24DC9E4")]
			set
			{
			}
		}

		// Token: 0x17002858 RID: 10328
		// (get) Token: 0x06013274 RID: 78452 RVA: 0x0007B660 File Offset: 0x00079860
		// (set) Token: 0x06013275 RID: 78453 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002858")]
		[Obsolete]
		public float loopDelay
		{
			[Token(Token = "0x6013274")]
			[Address(RVA = "0x24DCA18", Offset = "0x24DCA18", VA = "0x24DCA18")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013275")]
			[Address(RVA = "0x24DCA34", Offset = "0x24DCA34", VA = "0x24DCA34")]
			set
			{
			}
		}

		// Token: 0x17002859 RID: 10329
		// (get) Token: 0x06013276 RID: 78454 RVA: 0x0007B678 File Offset: 0x00079878
		// (set) Token: 0x06013277 RID: 78455 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002859")]
		public AnimatorUpdateMode updateMode
		{
			[Token(Token = "0x6013276")]
			[Address(RVA = "0x24DCA64", Offset = "0x24DCA64", VA = "0x24DCA64")]
			get
			{
				return AnimatorUpdateMode.Normal;
			}
			[Token(Token = "0x6013277")]
			[Address(RVA = "0x24DCA80", Offset = "0x24DCA80", VA = "0x24DCA80")]
			set
			{
			}
		}

		// Token: 0x1700285A RID: 10330
		// (get) Token: 0x06013278 RID: 78456 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700285A")]
		public override ParameterTexture ptex
		{
			[Token(Token = "0x6013278")]
			[Address(RVA = "0x24DCAA0", Offset = "0x24DCAA0", VA = "0x24DCAA0", Slot = "31")]
			get
			{
				return null;
			}
		}

		// Token: 0x06013279 RID: 78457 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013279")]
		[Address(RVA = "0x24DCAF8", Offset = "0x24DCAF8", VA = "0x24DCAF8", Slot = "32")]
		public override void ModifyMaterial()
		{
		}

		// Token: 0x0601327A RID: 78458 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601327A")]
		[Address(RVA = "0x24DCD7C", Offset = "0x24DCD7C", VA = "0x24DCD7C", Slot = "24")]
		public override void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x0601327B RID: 78459 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601327B")]
		[Address(RVA = "0x24DD130", Offset = "0x24DD130", VA = "0x24DD130", Slot = "33")]
		protected override void SetDirty()
		{
		}

		// Token: 0x0601327C RID: 78460 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601327C")]
		[Address(RVA = "0x24DD2CC", Offset = "0x24DD2CC", VA = "0x24DD2CC")]
		public void Play()
		{
		}

		// Token: 0x0601327D RID: 78461 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601327D")]
		[Address(RVA = "0x24DD2EC", Offset = "0x24DD2EC", VA = "0x24DD2EC")]
		public void Stop()
		{
		}

		// Token: 0x0601327E RID: 78462 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601327E")]
		[Address(RVA = "0x24DD308", Offset = "0x24DD308", VA = "0x24DD308", Slot = "5")]
		protected override void OnEnable()
		{
		}

		// Token: 0x0601327F RID: 78463 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601327F")]
		[Address(RVA = "0x24DD3AC", Offset = "0x24DD3AC", VA = "0x24DD3AC", Slot = "7")]
		protected override void OnDisable()
		{
		}

		// Token: 0x1700285B RID: 10331
		// (get) Token: 0x06013280 RID: 78464 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700285B")]
		private EffectPlayer _player
		{
			[Token(Token = "0x6013280")]
			[Address(RVA = "0x24DC8EC", Offset = "0x24DC8EC", VA = "0x24DC8EC")]
			get
			{
				return null;
			}
		}

		// Token: 0x06013281 RID: 78465 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013281")]
		[Address(RVA = "0x24DD448", Offset = "0x24DD448", VA = "0x24DD448")]
		public UIDissolve()
		{
		}

		// Token: 0x06013283 RID: 78467 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013283")]
		[Address(RVA = "0x24DD570", Offset = "0x24DD570", VA = "0x24DD570")]
		private Material <ModifyMaterial>b__58_0()
		{
			return null;
		}

		// Token: 0x06013284 RID: 78468 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013284")]
		[Address(RVA = "0x24DD664", Offset = "0x24DD664", VA = "0x24DD664")]
		private void <OnEnable>b__63_0(float f)
		{
		}

		// Token: 0x0400F15B RID: 61787
		[Token(Token = "0x400F15B")]
		public const string shaderName = "UI/Hidden/UI-Effect-Dissolve";

		// Token: 0x0400F15C RID: 61788
		[Token(Token = "0x400F15C")]
		[FieldOffset(Offset = "0x0")]
		private static readonly ParameterTexture _ptex;

		// Token: 0x0400F15D RID: 61789
		[Token(Token = "0x400F15D")]
		[FieldOffset(Offset = "0x6C")]
		[FormerlySerializedAs("m_Location")]
		[SerializeField]
		private float m_EffectFactor;

		// Token: 0x0400F15E RID: 61790
		[Token(Token = "0x400F15E")]
		[FieldOffset(Offset = "0x70")]
		[SerializeField]
		private float m_Width;

		// Token: 0x0400F15F RID: 61791
		[Token(Token = "0x400F15F")]
		[FieldOffset(Offset = "0x74")]
		[SerializeField]
		private float m_Softness;

		// Token: 0x0400F160 RID: 61792
		[Token(Token = "0x400F160")]
		[FieldOffset(Offset = "0x78")]
		[SerializeField]
		private Color m_Color;

		// Token: 0x0400F161 RID: 61793
		[Token(Token = "0x400F161")]
		[FieldOffset(Offset = "0x88")]
		[SerializeField]
		private ColorMode m_ColorMode;

		// Token: 0x0400F162 RID: 61794
		[Token(Token = "0x400F162")]
		[FieldOffset(Offset = "0x90")]
		[SerializeField]
		private Texture m_NoiseTexture;

		// Token: 0x0400F163 RID: 61795
		[Token(Token = "0x400F163")]
		[FieldOffset(Offset = "0x98")]
		[SerializeField]
		protected EffectArea m_EffectArea;

		// Token: 0x0400F164 RID: 61796
		[Token(Token = "0x400F164")]
		[FieldOffset(Offset = "0x9C")]
		[SerializeField]
		private bool m_KeepAspectRatio;

		// Token: 0x0400F165 RID: 61797
		[Token(Token = "0x400F165")]
		[FieldOffset(Offset = "0xA0")]
		[SerializeField]
		private EffectPlayer m_Player;

		// Token: 0x0400F166 RID: 61798
		[Token(Token = "0x400F166")]
		[FieldOffset(Offset = "0xA8")]
		[Obsolete]
		[SerializeField]
		private float m_Duration;

		// Token: 0x0400F167 RID: 61799
		[Token(Token = "0x400F167")]
		[FieldOffset(Offset = "0xAC")]
		[Obsolete]
		[SerializeField]
		private AnimatorUpdateMode m_UpdateMode;

		// Token: 0x0400F168 RID: 61800
		[Token(Token = "0x400F168")]
		[FieldOffset(Offset = "0xB0")]
		private MaterialCache _materialCache;
	}
}
