﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x02002689 RID: 9865
	[Token(Token = "0x2002689")]
	[DisallowMultipleComponent]
	public class UIGradient : BaseMeshEffect
	{
		// Token: 0x1700285E RID: 10334
		// (get) Token: 0x0601328B RID: 78475 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700285E")]
		public Graphic targetGraphic
		{
			[Token(Token = "0x601328B")]
			[Address(RVA = "0x24DD838", Offset = "0x24DD838", VA = "0x24DD838")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700285F RID: 10335
		// (get) Token: 0x0601328C RID: 78476 RVA: 0x0007B6C0 File Offset: 0x000798C0
		// (set) Token: 0x0601328D RID: 78477 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700285F")]
		public UIGradient.Direction direction
		{
			[Token(Token = "0x601328C")]
			[Address(RVA = "0x24DD85C", Offset = "0x24DD85C", VA = "0x24DD85C")]
			get
			{
				return UIGradient.Direction.Horizontal;
			}
			[Token(Token = "0x601328D")]
			[Address(RVA = "0x24DD864", Offset = "0x24DD864", VA = "0x24DD864")]
			set
			{
			}
		}

		// Token: 0x17002860 RID: 10336
		// (get) Token: 0x0601328E RID: 78478 RVA: 0x0007B6D8 File Offset: 0x000798D8
		// (set) Token: 0x0601328F RID: 78479 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002860")]
		public Color color1
		{
			[Token(Token = "0x601328E")]
			[Address(RVA = "0x24DD888", Offset = "0x24DD888", VA = "0x24DD888")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x601328F")]
			[Address(RVA = "0x24DD894", Offset = "0x24DD894", VA = "0x24DD894")]
			set
			{
			}
		}

		// Token: 0x17002861 RID: 10337
		// (get) Token: 0x06013290 RID: 78480 RVA: 0x0007B6F0 File Offset: 0x000798F0
		// (set) Token: 0x06013291 RID: 78481 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002861")]
		public Color color2
		{
			[Token(Token = "0x6013290")]
			[Address(RVA = "0x24DD8F4", Offset = "0x24DD8F4", VA = "0x24DD8F4")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x6013291")]
			[Address(RVA = "0x24DD900", Offset = "0x24DD900", VA = "0x24DD900")]
			set
			{
			}
		}

		// Token: 0x17002862 RID: 10338
		// (get) Token: 0x06013292 RID: 78482 RVA: 0x0007B708 File Offset: 0x00079908
		// (set) Token: 0x06013293 RID: 78483 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002862")]
		public Color color3
		{
			[Token(Token = "0x6013292")]
			[Address(RVA = "0x24DD960", Offset = "0x24DD960", VA = "0x24DD960")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x6013293")]
			[Address(RVA = "0x24DD96C", Offset = "0x24DD96C", VA = "0x24DD96C")]
			set
			{
			}
		}

		// Token: 0x17002863 RID: 10339
		// (get) Token: 0x06013294 RID: 78484 RVA: 0x0007B720 File Offset: 0x00079920
		// (set) Token: 0x06013295 RID: 78485 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002863")]
		public Color color4
		{
			[Token(Token = "0x6013294")]
			[Address(RVA = "0x24DD9CC", Offset = "0x24DD9CC", VA = "0x24DD9CC")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x6013295")]
			[Address(RVA = "0x24DD9D8", Offset = "0x24DD9D8", VA = "0x24DD9D8")]
			set
			{
			}
		}

		// Token: 0x17002864 RID: 10340
		// (get) Token: 0x06013296 RID: 78486 RVA: 0x0007B738 File Offset: 0x00079938
		// (set) Token: 0x06013297 RID: 78487 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002864")]
		public float rotation
		{
			[Token(Token = "0x6013296")]
			[Address(RVA = "0x24DDA38", Offset = "0x24DDA38", VA = "0x24DDA38")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013297")]
			[Address(RVA = "0x24DDA64", Offset = "0x24DDA64", VA = "0x24DDA64")]
			set
			{
			}
		}

		// Token: 0x17002865 RID: 10341
		// (get) Token: 0x06013298 RID: 78488 RVA: 0x0007B750 File Offset: 0x00079950
		// (set) Token: 0x06013299 RID: 78489 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002865")]
		public float offset
		{
			[Token(Token = "0x6013298")]
			[Address(RVA = "0x24DDB1C", Offset = "0x24DDB1C", VA = "0x24DDB1C")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013299")]
			[Address(RVA = "0x24DDB24", Offset = "0x24DDB24", VA = "0x24DDB24")]
			set
			{
			}
		}

		// Token: 0x17002866 RID: 10342
		// (get) Token: 0x0601329A RID: 78490 RVA: 0x0007B768 File Offset: 0x00079968
		// (set) Token: 0x0601329B RID: 78491 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002866")]
		public Vector2 offset2
		{
			[Token(Token = "0x601329A")]
			[Address(RVA = "0x24DDB48", Offset = "0x24DDB48", VA = "0x24DDB48")]
			get
			{
				return default(Vector2);
			}
			[Token(Token = "0x601329B")]
			[Address(RVA = "0x24DDB50", Offset = "0x24DDB50", VA = "0x24DDB50")]
			set
			{
			}
		}

		// Token: 0x17002867 RID: 10343
		// (get) Token: 0x0601329C RID: 78492 RVA: 0x0007B780 File Offset: 0x00079980
		// (set) Token: 0x0601329D RID: 78493 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002867")]
		public UIGradient.GradientStyle gradientStyle
		{
			[Token(Token = "0x601329C")]
			[Address(RVA = "0x24DDB80", Offset = "0x24DDB80", VA = "0x24DDB80")]
			get
			{
				return UIGradient.GradientStyle.Rect;
			}
			[Token(Token = "0x601329D")]
			[Address(RVA = "0x24DDB88", Offset = "0x24DDB88", VA = "0x24DDB88")]
			set
			{
			}
		}

		// Token: 0x17002868 RID: 10344
		// (get) Token: 0x0601329E RID: 78494 RVA: 0x0007B798 File Offset: 0x00079998
		// (set) Token: 0x0601329F RID: 78495 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002868")]
		public ColorSpace colorSpace
		{
			[Token(Token = "0x601329E")]
			[Address(RVA = "0x24DDBAC", Offset = "0x24DDBAC", VA = "0x24DDBAC")]
			get
			{
				return ColorSpace.Gamma;
			}
			[Token(Token = "0x601329F")]
			[Address(RVA = "0x24DDBB4", Offset = "0x24DDBB4", VA = "0x24DDBB4")]
			set
			{
			}
		}

		// Token: 0x17002869 RID: 10345
		// (get) Token: 0x060132A0 RID: 78496 RVA: 0x0007B7B0 File Offset: 0x000799B0
		// (set) Token: 0x060132A1 RID: 78497 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002869")]
		public bool ignoreAspectRatio
		{
			[Token(Token = "0x60132A0")]
			[Address(RVA = "0x24DDBD8", Offset = "0x24DDBD8", VA = "0x24DDBD8")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x60132A1")]
			[Address(RVA = "0x24DDBE0", Offset = "0x24DDBE0", VA = "0x24DDBE0")]
			set
			{
			}
		}

		// Token: 0x060132A2 RID: 78498 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132A2")]
		[Address(RVA = "0x24DDC08", Offset = "0x24DDC08", VA = "0x24DDC08", Slot = "24")]
		public override void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x060132A3 RID: 78499 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132A3")]
		[Address(RVA = "0x24DE694", Offset = "0x24DE694", VA = "0x24DE694")]
		public UIGradient()
		{
		}

		// Token: 0x0400F16B RID: 61803
		[Token(Token = "0x400F16B")]
		[FieldOffset(Offset = "0x58")]
		[SerializeField]
		private UIGradient.Direction m_Direction;

		// Token: 0x0400F16C RID: 61804
		[Token(Token = "0x400F16C")]
		[FieldOffset(Offset = "0x5C")]
		[SerializeField]
		private Color m_Color1;

		// Token: 0x0400F16D RID: 61805
		[Token(Token = "0x400F16D")]
		[FieldOffset(Offset = "0x6C")]
		[SerializeField]
		private Color m_Color2;

		// Token: 0x0400F16E RID: 61806
		[Token(Token = "0x400F16E")]
		[FieldOffset(Offset = "0x7C")]
		[SerializeField]
		private Color m_Color3;

		// Token: 0x0400F16F RID: 61807
		[Token(Token = "0x400F16F")]
		[FieldOffset(Offset = "0x8C")]
		[SerializeField]
		private Color m_Color4;

		// Token: 0x0400F170 RID: 61808
		[Token(Token = "0x400F170")]
		[FieldOffset(Offset = "0x9C")]
		[SerializeField]
		private float m_Rotation;

		// Token: 0x0400F171 RID: 61809
		[Token(Token = "0x400F171")]
		[FieldOffset(Offset = "0xA0")]
		[SerializeField]
		private float m_Offset1;

		// Token: 0x0400F172 RID: 61810
		[Token(Token = "0x400F172")]
		[FieldOffset(Offset = "0xA4")]
		[SerializeField]
		private float m_Offset2;

		// Token: 0x0400F173 RID: 61811
		[Token(Token = "0x400F173")]
		[FieldOffset(Offset = "0xA8")]
		[SerializeField]
		private UIGradient.GradientStyle m_GradientStyle;

		// Token: 0x0400F174 RID: 61812
		[Token(Token = "0x400F174")]
		[FieldOffset(Offset = "0xAC")]
		[SerializeField]
		private ColorSpace m_ColorSpace;

		// Token: 0x0400F175 RID: 61813
		[Token(Token = "0x400F175")]
		[FieldOffset(Offset = "0xB0")]
		[SerializeField]
		private bool m_IgnoreAspectRatio;

		// Token: 0x0400F176 RID: 61814
		[Token(Token = "0x400F176")]
		[FieldOffset(Offset = "0x0")]
		private static readonly Vector2[] s_SplitedCharacterPosition;

		// Token: 0x0200268A RID: 9866
		[Token(Token = "0x200268A")]
		public enum Direction
		{
			// Token: 0x0400F178 RID: 61816
			[Token(Token = "0x400F178")]
			Horizontal,
			// Token: 0x0400F179 RID: 61817
			[Token(Token = "0x400F179")]
			Vertical,
			// Token: 0x0400F17A RID: 61818
			[Token(Token = "0x400F17A")]
			Angle,
			// Token: 0x0400F17B RID: 61819
			[Token(Token = "0x400F17B")]
			Diagonal
		}

		// Token: 0x0200268B RID: 9867
		[Token(Token = "0x200268B")]
		public enum GradientStyle
		{
			// Token: 0x0400F17D RID: 61821
			[Token(Token = "0x400F17D")]
			Rect,
			// Token: 0x0400F17E RID: 61822
			[Token(Token = "0x400F17E")]
			Fit,
			// Token: 0x0400F17F RID: 61823
			[Token(Token = "0x400F17F")]
			Split
		}

		// Token: 0x0200268C RID: 9868
		[Token(Token = "0x200268C")]
		private struct Matrix2x3
		{
			// Token: 0x060132A5 RID: 78501 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60132A5")]
			[Address(RVA = "0x24DE560", Offset = "0x24DE560", VA = "0x24DE560")]
			public Matrix2x3(Rect rect, float cos, float sin)
			{
			}

			// Token: 0x060132A6 RID: 78502 RVA: 0x0007B7C8 File Offset: 0x000799C8
			[Token(Token = "0x60132A6")]
			[Address(RVA = "0x24DE664", Offset = "0x24DE664", VA = "0x24DE664")]
			public static Vector2 operator *(UIGradient.Matrix2x3 m, Vector2 v)
			{
				return default(Vector2);
			}

			// Token: 0x0400F180 RID: 61824
			[Token(Token = "0x400F180")]
			[FieldOffset(Offset = "0x0")]
			public float m00;

			// Token: 0x0400F181 RID: 61825
			[Token(Token = "0x400F181")]
			[FieldOffset(Offset = "0x4")]
			public float m01;

			// Token: 0x0400F182 RID: 61826
			[Token(Token = "0x400F182")]
			[FieldOffset(Offset = "0x8")]
			public float m02;

			// Token: 0x0400F183 RID: 61827
			[Token(Token = "0x400F183")]
			[FieldOffset(Offset = "0xC")]
			public float m10;

			// Token: 0x0400F184 RID: 61828
			[Token(Token = "0x400F184")]
			[FieldOffset(Offset = "0x10")]
			public float m11;

			// Token: 0x0400F185 RID: 61829
			[Token(Token = "0x400F185")]
			[FieldOffset(Offset = "0x14")]
			public float m12;
		}
	}
}
