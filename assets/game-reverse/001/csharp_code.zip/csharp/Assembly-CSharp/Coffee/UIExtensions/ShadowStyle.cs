﻿using System;
using Il2CppDummyDll;

namespace Coffee.UIExtensions
{
	// Token: 0x02002686 RID: 9862
	[Token(Token = "0x2002686")]
	public enum ShadowStyle
	{
		// Token: 0x0400F156 RID: 61782
		[Token(Token = "0x400F156")]
		None,
		// Token: 0x0400F157 RID: 61783
		[Token(Token = "0x400F157")]
		Shadow,
		// Token: 0x0400F158 RID: 61784
		[Token(Token = "0x400F158")]
		Outline,
		// Token: 0x0400F159 RID: 61785
		[Token(Token = "0x400F159")]
		Outline8,
		// Token: 0x0400F15A RID: 61786
		[Token(Token = "0x400F15A")]
		Shadow3
	}
}
