﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x02002688 RID: 9864
	[Token(Token = "0x2002688")]
	[DisallowMultipleComponent]
	public class UIFlip : BaseMeshEffect
	{
		// Token: 0x1700285C RID: 10332
		// (get) Token: 0x06013285 RID: 78469 RVA: 0x0007B690 File Offset: 0x00079890
		// (set) Token: 0x06013286 RID: 78470 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700285C")]
		public bool horizontal
		{
			[Token(Token = "0x6013285")]
			[Address(RVA = "0x24DD668", Offset = "0x24DD668", VA = "0x24DD668")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6013286")]
			[Address(RVA = "0x24DD670", Offset = "0x24DD670", VA = "0x24DD670")]
			set
			{
			}
		}

		// Token: 0x1700285D RID: 10333
		// (get) Token: 0x06013287 RID: 78471 RVA: 0x0007B6A8 File Offset: 0x000798A8
		// (set) Token: 0x06013288 RID: 78472 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700285D")]
		public bool vertical
		{
			[Token(Token = "0x6013287")]
			[Address(RVA = "0x24DD688", Offset = "0x24DD688", VA = "0x24DD688")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6013288")]
			[Address(RVA = "0x24DD690", Offset = "0x24DD690", VA = "0x24DD690")]
			set
			{
			}
		}

		// Token: 0x06013289 RID: 78473 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013289")]
		[Address(RVA = "0x24DD6A8", Offset = "0x24DD6A8", VA = "0x24DD6A8", Slot = "24")]
		public override void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x0601328A RID: 78474 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601328A")]
		[Address(RVA = "0x24DD7E4", Offset = "0x24DD7E4", VA = "0x24DD7E4")]
		public UIFlip()
		{
		}

		// Token: 0x0400F169 RID: 61801
		[Token(Token = "0x400F169")]
		[FieldOffset(Offset = "0x58")]
		[SerializeField]
		private bool m_Horizontal;

		// Token: 0x0400F16A RID: 61802
		[Token(Token = "0x400F16A")]
		[FieldOffset(Offset = "0x59")]
		[SerializeField]
		private bool m_Veritical;
	}
}
