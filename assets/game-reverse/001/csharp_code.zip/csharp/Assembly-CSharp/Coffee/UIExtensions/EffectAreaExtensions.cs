﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x02002685 RID: 9861
	[Token(Token = "0x2002685")]
	public static class EffectAreaExtensions
	{
		// Token: 0x06013258 RID: 78424 RVA: 0x0007B528 File Offset: 0x00079728
		[Token(Token = "0x6013258")]
		[Address(RVA = "0x24DBCA0", Offset = "0x24DBCA0", VA = "0x24DBCA0")]
		public static Rect GetEffectArea(EffectArea area, VertexHelper vh, Rect rectangle, float aspectRatio = -1f)
		{
			return default(Rect);
		}

		// Token: 0x06013259 RID: 78425 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013259")]
		[Address(RVA = "0x24DBEAC", Offset = "0x24DBEAC", VA = "0x24DBEAC")]
		public static void GetPositionFactor(EffectArea area, int index, Rect rect, Vector2 position, bool isText, bool isTMPro, out float x, out float y)
		{
		}

		// Token: 0x0601325A RID: 78426 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601325A")]
		[Address(RVA = "0x24DC06C", Offset = "0x24DC06C", VA = "0x24DC06C")]
		public static void GetNormalizedFactor(EffectArea area, int index, Matrix2x3 matrix, Vector2 position, bool isText, out Vector2 nomalizedPos)
		{
		}

		// Token: 0x0400F153 RID: 61779
		[Token(Token = "0x400F153")]
		[FieldOffset(Offset = "0x0")]
		private static readonly Rect rectForCharacter;

		// Token: 0x0400F154 RID: 61780
		[Token(Token = "0x400F154")]
		[FieldOffset(Offset = "0x10")]
		private static readonly Vector2[] splitedCharacterPosition;
	}
}
