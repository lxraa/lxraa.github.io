﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace Coffee.UIExtensions
{
	// Token: 0x0200269A RID: 9882
	[Token(Token = "0x200269A")]
	[Serializable]
	public class ParameterTexture
	{
		// Token: 0x0601330A RID: 78602 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601330A")]
		[Address(RVA = "0x16C8800", Offset = "0x16C8800", VA = "0x16C8800")]
		public ParameterTexture(int channels, int instanceLimit, string propertyName)
		{
		}

		// Token: 0x0601330B RID: 78603 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601330B")]
		[Address(RVA = "0x16C96F0", Offset = "0x16C96F0", VA = "0x16C96F0")]
		public void Register(IParameterTexture target)
		{
		}

		// Token: 0x0601330C RID: 78604 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601330C")]
		[Address(RVA = "0x16C9B6C", Offset = "0x16C9B6C", VA = "0x16C9B6C")]
		public void Unregister(IParameterTexture target)
		{
		}

		// Token: 0x0601330D RID: 78605 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601330D")]
		[Address(RVA = "0x16C9D04", Offset = "0x16C9D04", VA = "0x16C9D04")]
		public void SetData(IParameterTexture target, int channelId, byte value)
		{
		}

		// Token: 0x0601330E RID: 78606 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601330E")]
		[Address(RVA = "0x16C8650", Offset = "0x16C8650", VA = "0x16C8650")]
		public void SetData(IParameterTexture target, int channelId, float value)
		{
		}

		// Token: 0x0601330F RID: 78607 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601330F")]
		[Address(RVA = "0x16C85B0", Offset = "0x16C85B0", VA = "0x16C85B0")]
		public void RegisterMaterial(Material mat)
		{
		}

		// Token: 0x06013310 RID: 78608 RVA: 0x0007BA50 File Offset: 0x00079C50
		[Token(Token = "0x6013310")]
		[Address(RVA = "0x16C8064", Offset = "0x16C8064", VA = "0x16C8064")]
		public float GetNormalizedIndex(IParameterTexture target)
		{
			return 0f;
		}

		// Token: 0x06013311 RID: 78609 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013311")]
		[Address(RVA = "0x16C984C", Offset = "0x16C984C", VA = "0x16C984C")]
		private void Initialize()
		{
		}

		// Token: 0x06013312 RID: 78610 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013312")]
		[Address(RVA = "0x16C9E64", Offset = "0x16C9E64", VA = "0x16C9E64")]
		private void UpdateParameterTexture()
		{
		}

		// Token: 0x0400F1C7 RID: 61895
		[Token(Token = "0x400F1C7")]
		[FieldOffset(Offset = "0x10")]
		private Texture2D _texture;

		// Token: 0x0400F1C8 RID: 61896
		[Token(Token = "0x400F1C8")]
		[FieldOffset(Offset = "0x18")]
		private bool _needUpload;

		// Token: 0x0400F1C9 RID: 61897
		[Token(Token = "0x400F1C9")]
		[FieldOffset(Offset = "0x1C")]
		private int _propertyId;

		// Token: 0x0400F1CA RID: 61898
		[Token(Token = "0x400F1CA")]
		[FieldOffset(Offset = "0x20")]
		private readonly string _propertyName;

		// Token: 0x0400F1CB RID: 61899
		[Token(Token = "0x400F1CB")]
		[FieldOffset(Offset = "0x28")]
		private readonly int _channels;

		// Token: 0x0400F1CC RID: 61900
		[Token(Token = "0x400F1CC")]
		[FieldOffset(Offset = "0x2C")]
		private readonly int _instanceLimit;

		// Token: 0x0400F1CD RID: 61901
		[Token(Token = "0x400F1CD")]
		[FieldOffset(Offset = "0x30")]
		private readonly byte[] _data;

		// Token: 0x0400F1CE RID: 61902
		[Token(Token = "0x400F1CE")]
		[FieldOffset(Offset = "0x38")]
		private readonly Stack<int> _stack;

		// Token: 0x0400F1CF RID: 61903
		[Token(Token = "0x400F1CF")]
		[FieldOffset(Offset = "0x0")]
		private static List<Action> updates;

		// Token: 0x0200269B RID: 9883
		[Token(Token = "0x200269B")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06013314 RID: 78612 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013314")]
			[Address(RVA = "0x16C9F7C", Offset = "0x16C9F7C", VA = "0x16C9F7C")]
			public <>c()
			{
			}

			// Token: 0x06013315 RID: 78613 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013315")]
			[Address(RVA = "0x16C9F84", Offset = "0x16C9F84", VA = "0x16C9F84")]
			internal void <Initialize>b__16_0()
			{
			}

			// Token: 0x0400F1D0 RID: 61904
			[Token(Token = "0x400F1D0")]
			[FieldOffset(Offset = "0x0")]
			public static readonly ParameterTexture.<>c <>9;

			// Token: 0x0400F1D1 RID: 61905
			[Token(Token = "0x400F1D1")]
			[FieldOffset(Offset = "0x8")]
			public static Canvas.WillRenderCanvases <>9__16_0;
		}
	}
}
