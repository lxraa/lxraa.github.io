﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using Royal.Infrastructure.Utils.Text;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x02002683 RID: 9859
	[Token(Token = "0x2002683")]
	[ExecuteInEditMode]
	public abstract class BaseMeshEffect : UIBehaviour, IMeshModifier
	{
		// Token: 0x17002841 RID: 10305
		// (get) Token: 0x06013241 RID: 78401 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002841")]
		public Graphic graphic
		{
			[Token(Token = "0x6013241")]
			[Address(RVA = "0x24D9BC8", Offset = "0x24D9BC8", VA = "0x24D9BC8")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002842 RID: 10306
		// (get) Token: 0x06013242 RID: 78402 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002842")]
		public CanvasRenderer canvasRenderer
		{
			[Token(Token = "0x6013242")]
			[Address(RVA = "0x24D9BEC", Offset = "0x24D9BEC", VA = "0x24D9BEC")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002843 RID: 10307
		// (get) Token: 0x06013243 RID: 78403 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002843")]
		public TMP_Text textMeshPro
		{
			[Token(Token = "0x6013243")]
			[Address(RVA = "0x24D9C10", Offset = "0x24D9C10", VA = "0x24D9C10")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002844 RID: 10308
		// (get) Token: 0x06013244 RID: 78404 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002844")]
		public RectTransform rectTransform
		{
			[Token(Token = "0x6013244")]
			[Address(RVA = "0x24D9C34", Offset = "0x24D9C34", VA = "0x24D9C34")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002845 RID: 10309
		// (get) Token: 0x06013245 RID: 78405 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002845")]
		public TextProOnACurve textOnACurve
		{
			[Token(Token = "0x6013245")]
			[Address(RVA = "0x24D9C58", Offset = "0x24D9C58", VA = "0x24D9C58")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002846 RID: 10310
		// (get) Token: 0x06013246 RID: 78406 RVA: 0x0007B4E0 File Offset: 0x000796E0
		[Token(Token = "0x17002846")]
		public virtual AdditionalCanvasShaderChannels requiredChannels
		{
			[Token(Token = "0x6013246")]
			[Address(RVA = "0x24D9C7C", Offset = "0x24D9C7C", VA = "0x24D9C7C", Slot = "19")]
			get
			{
				return AdditionalCanvasShaderChannels.None;
			}
		}

		// Token: 0x17002847 RID: 10311
		// (get) Token: 0x06013247 RID: 78407 RVA: 0x0007B4F8 File Offset: 0x000796F8
		[Token(Token = "0x17002847")]
		public bool isTMPro
		{
			[Token(Token = "0x6013247")]
			[Address(RVA = "0x24D9C84", Offset = "0x24D9C84", VA = "0x24D9C84")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17002848 RID: 10312
		// (get) Token: 0x06013248 RID: 78408 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06013249 RID: 78409 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002848")]
		public virtual Material material
		{
			[Token(Token = "0x6013248")]
			[Address(RVA = "0x24D9CF8", Offset = "0x24D9CF8", VA = "0x24D9CF8", Slot = "20")]
			get
			{
				return null;
			}
			[Token(Token = "0x6013249")]
			[Address(RVA = "0x24D9E00", Offset = "0x24D9E00", VA = "0x24D9E00", Slot = "21")]
			set
			{
			}
		}

		// Token: 0x17002849 RID: 10313
		// (get) Token: 0x0601324A RID: 78410 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002849")]
		public virtual Material[] materials
		{
			[Token(Token = "0x601324A")]
			[Address(RVA = "0x24D9F18", Offset = "0x24D9F18", VA = "0x24D9F18", Slot = "22")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601324B RID: 78411 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601324B")]
		[Address(RVA = "0x24DA124", Offset = "0x24DA124", VA = "0x24DA124", Slot = "23")]
		public virtual void ModifyMesh(Mesh mesh)
		{
		}

		// Token: 0x0601324C RID: 78412 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601324C")]
		[Address(RVA = "0x24DA128", Offset = "0x24DA128", VA = "0x24DA128", Slot = "24")]
		public virtual void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x0601324D RID: 78413 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601324D")]
		[Address(RVA = "0x24DA12C", Offset = "0x24DA12C", VA = "0x24DA12C", Slot = "25")]
		public virtual void SetVerticesDirty()
		{
		}

		// Token: 0x1700284A RID: 10314
		// (get) Token: 0x0601324E RID: 78414 RVA: 0x0007B510 File Offset: 0x00079710
		[Token(Token = "0x1700284A")]
		protected virtual bool isLegacyMeshModifier
		{
			[Token(Token = "0x601324E")]
			[Address(RVA = "0x24DA6AC", Offset = "0x24DA6AC", VA = "0x24DA6AC", Slot = "26")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x0601324F RID: 78415 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601324F")]
		[Address(RVA = "0x24DA6B4", Offset = "0x24DA6B4", VA = "0x24DA6B4", Slot = "27")]
		protected virtual void Initialize()
		{
		}

		// Token: 0x06013250 RID: 78416 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013250")]
		[Address(RVA = "0x24DA824", Offset = "0x24DA824", VA = "0x24DA824", Slot = "5")]
		protected override void OnEnable()
		{
		}

		// Token: 0x06013251 RID: 78417 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013251")]
		[Address(RVA = "0x24DAB4C", Offset = "0x24DAB4C", VA = "0x24DAB4C", Slot = "7")]
		protected override void OnDisable()
		{
		}

		// Token: 0x06013252 RID: 78418 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013252")]
		[Address(RVA = "0x24DAC2C", Offset = "0x24DAC2C", VA = "0x24DAC2C", Slot = "28")]
		protected virtual void LateUpdate()
		{
		}

		// Token: 0x06013253 RID: 78419 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013253")]
		[Address(RVA = "0x24DAD40", Offset = "0x24DAD40", VA = "0x24DAD40", Slot = "13")]
		protected override void OnDidApplyAnimationProperties()
		{
		}

		// Token: 0x06013254 RID: 78420 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013254")]
		[Address(RVA = "0x24DAD50", Offset = "0x24DAD50", VA = "0x24DAD50")]
		private void OnTextChanged(UnityEngine.Object obj)
		{
		}

		// Token: 0x06013255 RID: 78421 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013255")]
		[Address(RVA = "0x24DB4C4", Offset = "0x24DB4C4", VA = "0x24DB4C4")]
		private void FillVertexHelper(VertexHelper vh, Mesh mesh)
		{
		}

		// Token: 0x06013256 RID: 78422 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013256")]
		[Address(RVA = "0x24DB8D4", Offset = "0x24DB8D4", VA = "0x24DB8D4")]
		protected BaseMeshEffect()
		{
		}

		// Token: 0x0400F13C RID: 61756
		[Token(Token = "0x400F13C")]
		[FieldOffset(Offset = "0x0")]
		private static readonly List<Vector2> s_Uv0;

		// Token: 0x0400F13D RID: 61757
		[Token(Token = "0x400F13D")]
		[FieldOffset(Offset = "0x8")]
		private static readonly List<Vector2> s_Uv1;

		// Token: 0x0400F13E RID: 61758
		[Token(Token = "0x400F13E")]
		[FieldOffset(Offset = "0x10")]
		private static readonly List<Vector3> s_Vertices;

		// Token: 0x0400F13F RID: 61759
		[Token(Token = "0x400F13F")]
		[FieldOffset(Offset = "0x18")]
		private static readonly List<int> s_Indices;

		// Token: 0x0400F140 RID: 61760
		[Token(Token = "0x400F140")]
		[FieldOffset(Offset = "0x20")]
		private static readonly List<Vector3> s_Normals;

		// Token: 0x0400F141 RID: 61761
		[Token(Token = "0x400F141")]
		[FieldOffset(Offset = "0x28")]
		private static readonly List<Vector4> s_Tangents;

		// Token: 0x0400F142 RID: 61762
		[Token(Token = "0x400F142")]
		[FieldOffset(Offset = "0x30")]
		private static readonly List<Color32> s_Colors;

		// Token: 0x0400F143 RID: 61763
		[Token(Token = "0x400F143")]
		[FieldOffset(Offset = "0x38")]
		private static readonly VertexHelper s_VertexHelper;

		// Token: 0x0400F144 RID: 61764
		[Token(Token = "0x400F144")]
		[FieldOffset(Offset = "0x40")]
		private static readonly List<TMP_SubMeshUI> s_SubMeshUIs;

		// Token: 0x0400F145 RID: 61765
		[Token(Token = "0x400F145")]
		[FieldOffset(Offset = "0x48")]
		private static readonly List<Mesh> s_Meshes;

		// Token: 0x0400F146 RID: 61766
		[Token(Token = "0x400F146")]
		[FieldOffset(Offset = "0x50")]
		private static readonly Material[] s_EmptyMaterials;

		// Token: 0x0400F147 RID: 61767
		[Token(Token = "0x400F147")]
		[FieldOffset(Offset = "0x18")]
		private bool _initialized;

		// Token: 0x0400F148 RID: 61768
		[Token(Token = "0x400F148")]
		[FieldOffset(Offset = "0x20")]
		private CanvasRenderer _canvasRenderer;

		// Token: 0x0400F149 RID: 61769
		[Token(Token = "0x400F149")]
		[FieldOffset(Offset = "0x28")]
		private RectTransform _rectTransform;

		// Token: 0x0400F14A RID: 61770
		[Token(Token = "0x400F14A")]
		[FieldOffset(Offset = "0x30")]
		private Graphic _graphic;

		// Token: 0x0400F14B RID: 61771
		[Token(Token = "0x400F14B")]
		[FieldOffset(Offset = "0x38")]
		private Material[] _materials;

		// Token: 0x0400F14C RID: 61772
		[Token(Token = "0x400F14C")]
		[FieldOffset(Offset = "0x40")]
		private bool _isTextMeshProActive;

		// Token: 0x0400F14D RID: 61773
		[Token(Token = "0x400F14D")]
		[FieldOffset(Offset = "0x48")]
		private TMP_Text _textMeshPro;

		// Token: 0x0400F14E RID: 61774
		[Token(Token = "0x400F14E")]
		[FieldOffset(Offset = "0x50")]
		private TextProOnACurve _textOnACurve;
	}
}
