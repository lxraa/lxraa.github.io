﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x0200269E RID: 9886
	[Token(Token = "0x200269E")]
	[ExecuteInEditMode]
	[RequireComponent(typeof(Graphic))]
	[DisallowMultipleComponent]
	public class UIEffect : UIEffectBase
	{
		// Token: 0x1700288A RID: 10378
		// (get) Token: 0x06013322 RID: 78626 RVA: 0x0007BA80 File Offset: 0x00079C80
		// (set) Token: 0x06013323 RID: 78627 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700288A")]
		[Obsolete("Use effectFactor instead (UnityUpgradable) -> effectFactor")]
		public float toneLevel
		{
			[Token(Token = "0x6013322")]
			[Address(RVA = "0x16CA2AC", Offset = "0x16CA2AC", VA = "0x16CA2AC")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013323")]
			[Address(RVA = "0x16CA2B4", Offset = "0x16CA2B4", VA = "0x16CA2B4")]
			set
			{
			}
		}

		// Token: 0x1700288B RID: 10379
		// (get) Token: 0x06013324 RID: 78628 RVA: 0x0007BA98 File Offset: 0x00079C98
		// (set) Token: 0x06013325 RID: 78629 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700288B")]
		public float effectFactor
		{
			[Token(Token = "0x6013324")]
			[Address(RVA = "0x16CA2DC", Offset = "0x16CA2DC", VA = "0x16CA2DC")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013325")]
			[Address(RVA = "0x16CA2E4", Offset = "0x16CA2E4", VA = "0x16CA2E4")]
			set
			{
			}
		}

		// Token: 0x1700288C RID: 10380
		// (get) Token: 0x06013326 RID: 78630 RVA: 0x0007BAB0 File Offset: 0x00079CB0
		// (set) Token: 0x06013327 RID: 78631 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700288C")]
		public float colorFactor
		{
			[Token(Token = "0x6013326")]
			[Address(RVA = "0x16CA30C", Offset = "0x16CA30C", VA = "0x16CA30C")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013327")]
			[Address(RVA = "0x16CA314", Offset = "0x16CA314", VA = "0x16CA314")]
			set
			{
			}
		}

		// Token: 0x1700288D RID: 10381
		// (get) Token: 0x06013328 RID: 78632 RVA: 0x0007BAC8 File Offset: 0x00079CC8
		// (set) Token: 0x06013329 RID: 78633 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700288D")]
		[Obsolete("Use blurFactor instead (UnityUpgradable) -> blurFactor")]
		public float blur
		{
			[Token(Token = "0x6013328")]
			[Address(RVA = "0x16CA33C", Offset = "0x16CA33C", VA = "0x16CA33C")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013329")]
			[Address(RVA = "0x16CA344", Offset = "0x16CA344", VA = "0x16CA344")]
			set
			{
			}
		}

		// Token: 0x1700288E RID: 10382
		// (get) Token: 0x0601332A RID: 78634 RVA: 0x0007BAE0 File Offset: 0x00079CE0
		// (set) Token: 0x0601332B RID: 78635 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700288E")]
		[Obsolete("Use effectFactor instead (UnityUpgradable) -> effectFactor")]
		public float blurFactor
		{
			[Token(Token = "0x601332A")]
			[Address(RVA = "0x16CA36C", Offset = "0x16CA36C", VA = "0x16CA36C")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x601332B")]
			[Address(RVA = "0x16CA374", Offset = "0x16CA374", VA = "0x16CA374")]
			set
			{
			}
		}

		// Token: 0x1700288F RID: 10383
		// (get) Token: 0x0601332C RID: 78636 RVA: 0x0007BAF8 File Offset: 0x00079CF8
		[Token(Token = "0x1700288F")]
		[Obsolete("Use effectMode instead (UnityUpgradable) -> effectMode")]
		public EffectMode toneMode
		{
			[Token(Token = "0x601332C")]
			[Address(RVA = "0x16CA39C", Offset = "0x16CA39C", VA = "0x16CA39C")]
			get
			{
				return EffectMode.None;
			}
		}

		// Token: 0x17002890 RID: 10384
		// (get) Token: 0x0601332D RID: 78637 RVA: 0x0007BB10 File Offset: 0x00079D10
		[Token(Token = "0x17002890")]
		public EffectMode effectMode
		{
			[Token(Token = "0x601332D")]
			[Address(RVA = "0x16CA3A4", Offset = "0x16CA3A4", VA = "0x16CA3A4")]
			get
			{
				return EffectMode.None;
			}
		}

		// Token: 0x17002891 RID: 10385
		// (get) Token: 0x0601332E RID: 78638 RVA: 0x0007BB28 File Offset: 0x00079D28
		[Token(Token = "0x17002891")]
		public ColorMode colorMode
		{
			[Token(Token = "0x601332E")]
			[Address(RVA = "0x16CA3AC", Offset = "0x16CA3AC", VA = "0x16CA3AC")]
			get
			{
				return ColorMode.Multiply;
			}
		}

		// Token: 0x17002892 RID: 10386
		// (get) Token: 0x0601332F RID: 78639 RVA: 0x0007BB40 File Offset: 0x00079D40
		[Token(Token = "0x17002892")]
		public BlurMode blurMode
		{
			[Token(Token = "0x601332F")]
			[Address(RVA = "0x16CA3B4", Offset = "0x16CA3B4", VA = "0x16CA3B4")]
			get
			{
				return BlurMode.None;
			}
		}

		// Token: 0x17002893 RID: 10387
		// (get) Token: 0x06013330 RID: 78640 RVA: 0x0007BB58 File Offset: 0x00079D58
		// (set) Token: 0x06013331 RID: 78641 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002893")]
		public Color effectColor
		{
			[Token(Token = "0x6013330")]
			[Address(RVA = "0x16CA3BC", Offset = "0x16CA3BC", VA = "0x16CA3BC")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x6013331")]
			[Address(RVA = "0x16CA3E4", Offset = "0x16CA3E4", VA = "0x16CA3E4")]
			set
			{
			}
		}

		// Token: 0x17002894 RID: 10388
		// (get) Token: 0x06013332 RID: 78642 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002894")]
		public override ParameterTexture ptex
		{
			[Token(Token = "0x6013332")]
			[Address(RVA = "0x16CA454", Offset = "0x16CA454", VA = "0x16CA454", Slot = "31")]
			get
			{
				return null;
			}
		}

		// Token: 0x06013333 RID: 78643 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013333")]
		[Address(RVA = "0x16CA4AC", Offset = "0x16CA4AC", VA = "0x16CA4AC", Slot = "24")]
		public override void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x06013334 RID: 78644 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013334")]
		[Address(RVA = "0x16CADE4", Offset = "0x16CADE4", VA = "0x16CADE4", Slot = "33")]
		protected override void SetDirty()
		{
		}

		// Token: 0x06013335 RID: 78645 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013335")]
		[Address(RVA = "0x16CAC04", Offset = "0x16CAC04", VA = "0x16CAC04")]
		private static void GetBounds(List<UIVertex> verts, int start, int count, ref Rect posBounds, ref Rect uvBounds, bool global)
		{
		}

		// Token: 0x06013336 RID: 78646 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013336")]
		[Address(RVA = "0x16CAF08", Offset = "0x16CAF08", VA = "0x16CAF08")]
		public UIEffect()
		{
		}

		// Token: 0x0400F1DD RID: 61917
		[Token(Token = "0x400F1DD")]
		public const string shaderName = "UI/Hidden/UI-Effect";

		// Token: 0x0400F1DE RID: 61918
		[Token(Token = "0x400F1DE")]
		[FieldOffset(Offset = "0x0")]
		private static readonly ParameterTexture _ptex;

		// Token: 0x0400F1DF RID: 61919
		[Token(Token = "0x400F1DF")]
		[FieldOffset(Offset = "0x6C")]
		[SerializeField]
		[FormerlySerializedAs("m_ToneLevel")]
		private float m_EffectFactor;

		// Token: 0x0400F1E0 RID: 61920
		[Token(Token = "0x400F1E0")]
		[FieldOffset(Offset = "0x70")]
		[SerializeField]
		private float m_ColorFactor;

		// Token: 0x0400F1E1 RID: 61921
		[Token(Token = "0x400F1E1")]
		[FieldOffset(Offset = "0x74")]
		[SerializeField]
		[FormerlySerializedAs("m_Blur")]
		private float m_BlurFactor;

		// Token: 0x0400F1E2 RID: 61922
		[Token(Token = "0x400F1E2")]
		[FieldOffset(Offset = "0x78")]
		[SerializeField]
		[FormerlySerializedAs("m_ToneMode")]
		private EffectMode m_EffectMode;

		// Token: 0x0400F1E3 RID: 61923
		[Token(Token = "0x400F1E3")]
		[FieldOffset(Offset = "0x7C")]
		[SerializeField]
		private ColorMode m_ColorMode;

		// Token: 0x0400F1E4 RID: 61924
		[Token(Token = "0x400F1E4")]
		[FieldOffset(Offset = "0x80")]
		[SerializeField]
		private BlurMode m_BlurMode;

		// Token: 0x0400F1E5 RID: 61925
		[Token(Token = "0x400F1E5")]
		[FieldOffset(Offset = "0x84")]
		[SerializeField]
		private bool m_AdvancedBlur;

		// Token: 0x0400F1E6 RID: 61926
		[Token(Token = "0x400F1E6")]
		[FieldOffset(Offset = "0x88")]
		[SerializeField]
		[Obsolete]
		private float m_ShadowBlur;

		// Token: 0x0400F1E7 RID: 61927
		[Token(Token = "0x400F1E7")]
		[FieldOffset(Offset = "0x8C")]
		[SerializeField]
		[Obsolete]
		private ShadowStyle m_ShadowStyle;

		// Token: 0x0400F1E8 RID: 61928
		[Token(Token = "0x400F1E8")]
		[FieldOffset(Offset = "0x90")]
		[SerializeField]
		[Obsolete]
		private Color m_ShadowColor;

		// Token: 0x0400F1E9 RID: 61929
		[Token(Token = "0x400F1E9")]
		[FieldOffset(Offset = "0xA0")]
		[Obsolete]
		[SerializeField]
		private Vector2 m_EffectDistance;

		// Token: 0x0400F1EA RID: 61930
		[Token(Token = "0x400F1EA")]
		[FieldOffset(Offset = "0xA8")]
		[Obsolete]
		[SerializeField]
		private bool m_UseGraphicAlpha;

		// Token: 0x0400F1EB RID: 61931
		[Token(Token = "0x400F1EB")]
		[FieldOffset(Offset = "0xAC")]
		[Obsolete]
		[SerializeField]
		private Color m_EffectColor;

		// Token: 0x0400F1EC RID: 61932
		[Token(Token = "0x400F1EC")]
		[FieldOffset(Offset = "0xC0")]
		[Obsolete]
		[SerializeField]
		private List<UIShadow.AdditionalShadow> m_AdditionalShadows;
	}
}
