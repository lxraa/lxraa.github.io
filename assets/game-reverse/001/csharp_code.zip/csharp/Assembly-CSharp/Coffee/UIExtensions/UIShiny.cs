﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x0200268F RID: 9871
	[Token(Token = "0x200268F")]
	public class UIShiny : UIEffectBase
	{
		// Token: 0x17002870 RID: 10352
		// (get) Token: 0x060132BC RID: 78524 RVA: 0x0007B870 File Offset: 0x00079A70
		[Token(Token = "0x17002870")]
		public override AdditionalCanvasShaderChannels requiredChannels
		{
			[Token(Token = "0x60132BC")]
			[Address(RVA = "0x16C6D94", Offset = "0x16C6D94", VA = "0x16C6D94", Slot = "19")]
			get
			{
				return AdditionalCanvasShaderChannels.None;
			}
		}

		// Token: 0x17002871 RID: 10353
		// (get) Token: 0x060132BD RID: 78525 RVA: 0x0007B888 File Offset: 0x00079A88
		// (set) Token: 0x060132BE RID: 78526 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002871")]
		[Obsolete("Use effectFactor instead (UnityUpgradable) -> effectFactor")]
		public float location
		{
			[Token(Token = "0x60132BD")]
			[Address(RVA = "0x16C6DB4", Offset = "0x16C6DB4", VA = "0x16C6DB4")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132BE")]
			[Address(RVA = "0x16C6DBC", Offset = "0x16C6DBC", VA = "0x16C6DBC")]
			set
			{
			}
		}

		// Token: 0x17002872 RID: 10354
		// (get) Token: 0x060132BF RID: 78527 RVA: 0x0007B8A0 File Offset: 0x00079AA0
		// (set) Token: 0x060132C0 RID: 78528 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002872")]
		public float effectFactor
		{
			[Token(Token = "0x60132BF")]
			[Address(RVA = "0x16C6E84", Offset = "0x16C6E84", VA = "0x16C6E84")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132C0")]
			[Address(RVA = "0x16C6E8C", Offset = "0x16C6E8C", VA = "0x16C6E8C")]
			set
			{
			}
		}

		// Token: 0x17002873 RID: 10355
		// (get) Token: 0x060132C1 RID: 78529 RVA: 0x0007B8B8 File Offset: 0x00079AB8
		// (set) Token: 0x060132C2 RID: 78530 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002873")]
		public float width
		{
			[Token(Token = "0x60132C1")]
			[Address(RVA = "0x16C6F54", Offset = "0x16C6F54", VA = "0x16C6F54")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132C2")]
			[Address(RVA = "0x16C6F5C", Offset = "0x16C6F5C", VA = "0x16C6F5C")]
			set
			{
			}
		}

		// Token: 0x17002874 RID: 10356
		// (get) Token: 0x060132C3 RID: 78531 RVA: 0x0007B8D0 File Offset: 0x00079AD0
		// (set) Token: 0x060132C4 RID: 78532 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002874")]
		public float softness
		{
			[Token(Token = "0x60132C3")]
			[Address(RVA = "0x16C7024", Offset = "0x16C7024", VA = "0x16C7024")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132C4")]
			[Address(RVA = "0x16C702C", Offset = "0x16C702C", VA = "0x16C702C")]
			set
			{
			}
		}

		// Token: 0x17002875 RID: 10357
		// (get) Token: 0x060132C5 RID: 78533 RVA: 0x0007B8E8 File Offset: 0x00079AE8
		// (set) Token: 0x060132C6 RID: 78534 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002875")]
		[Obsolete("Use brightness instead (UnityUpgradable) -> brightness")]
		public float alpha
		{
			[Token(Token = "0x60132C5")]
			[Address(RVA = "0x16C70F8", Offset = "0x16C70F8", VA = "0x16C70F8")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132C6")]
			[Address(RVA = "0x16C7100", Offset = "0x16C7100", VA = "0x16C7100")]
			set
			{
			}
		}

		// Token: 0x17002876 RID: 10358
		// (get) Token: 0x060132C7 RID: 78535 RVA: 0x0007B900 File Offset: 0x00079B00
		// (set) Token: 0x060132C8 RID: 78536 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002876")]
		public float brightness
		{
			[Token(Token = "0x60132C7")]
			[Address(RVA = "0x16C71C8", Offset = "0x16C71C8", VA = "0x16C71C8")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132C8")]
			[Address(RVA = "0x16C71D0", Offset = "0x16C71D0", VA = "0x16C71D0")]
			set
			{
			}
		}

		// Token: 0x17002877 RID: 10359
		// (get) Token: 0x060132C9 RID: 78537 RVA: 0x0007B918 File Offset: 0x00079B18
		// (set) Token: 0x060132CA RID: 78538 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002877")]
		[Obsolete("Use gloss instead (UnityUpgradable) -> gloss")]
		public float highlight
		{
			[Token(Token = "0x60132C9")]
			[Address(RVA = "0x16C7298", Offset = "0x16C7298", VA = "0x16C7298")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132CA")]
			[Address(RVA = "0x16C72A0", Offset = "0x16C72A0", VA = "0x16C72A0")]
			set
			{
			}
		}

		// Token: 0x17002878 RID: 10360
		// (get) Token: 0x060132CB RID: 78539 RVA: 0x0007B930 File Offset: 0x00079B30
		// (set) Token: 0x060132CC RID: 78540 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002878")]
		public float gloss
		{
			[Token(Token = "0x60132CB")]
			[Address(RVA = "0x16C7368", Offset = "0x16C7368", VA = "0x16C7368")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132CC")]
			[Address(RVA = "0x16C7370", Offset = "0x16C7370", VA = "0x16C7370")]
			set
			{
			}
		}

		// Token: 0x17002879 RID: 10361
		// (get) Token: 0x060132CD RID: 78541 RVA: 0x0007B948 File Offset: 0x00079B48
		// (set) Token: 0x060132CE RID: 78542 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002879")]
		public float rotation
		{
			[Token(Token = "0x60132CD")]
			[Address(RVA = "0x16C7438", Offset = "0x16C7438", VA = "0x16C7438")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132CE")]
			[Address(RVA = "0x16C7440", Offset = "0x16C7440", VA = "0x16C7440")]
			set
			{
			}
		}

		// Token: 0x1700287A RID: 10362
		// (get) Token: 0x060132CF RID: 78543 RVA: 0x0007B960 File Offset: 0x00079B60
		// (set) Token: 0x060132D0 RID: 78544 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700287A")]
		public EffectArea effectArea
		{
			[Token(Token = "0x60132CF")]
			[Address(RVA = "0x16C74FC", Offset = "0x16C74FC", VA = "0x16C74FC")]
			get
			{
				return EffectArea.RectTransform;
			}
			[Token(Token = "0x60132D0")]
			[Address(RVA = "0x16C7504", Offset = "0x16C7504", VA = "0x16C7504")]
			set
			{
			}
		}

		// Token: 0x1700287B RID: 10363
		// (get) Token: 0x060132D1 RID: 78545 RVA: 0x0007B978 File Offset: 0x00079B78
		// (set) Token: 0x060132D2 RID: 78546 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700287B")]
		[Obsolete("Use Play/Stop method instead")]
		public bool play
		{
			[Token(Token = "0x60132D1")]
			[Address(RVA = "0x16C7528", Offset = "0x16C7528", VA = "0x16C7528")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x60132D2")]
			[Address(RVA = "0x16C75C4", Offset = "0x16C75C4", VA = "0x16C75C4")]
			set
			{
			}
		}

		// Token: 0x1700287C RID: 10364
		// (get) Token: 0x060132D3 RID: 78547 RVA: 0x0007B990 File Offset: 0x00079B90
		// (set) Token: 0x060132D4 RID: 78548 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700287C")]
		[Obsolete]
		public bool loop
		{
			[Token(Token = "0x60132D3")]
			[Address(RVA = "0x16C75E8", Offset = "0x16C75E8", VA = "0x16C75E8")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x60132D4")]
			[Address(RVA = "0x16C7604", Offset = "0x16C7604", VA = "0x16C7604")]
			set
			{
			}
		}

		// Token: 0x1700287D RID: 10365
		// (get) Token: 0x060132D5 RID: 78549 RVA: 0x0007B9A8 File Offset: 0x00079BA8
		// (set) Token: 0x060132D6 RID: 78550 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700287D")]
		public float duration
		{
			[Token(Token = "0x60132D5")]
			[Address(RVA = "0x16C7628", Offset = "0x16C7628", VA = "0x16C7628")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132D6")]
			[Address(RVA = "0x16C7644", Offset = "0x16C7644", VA = "0x16C7644")]
			set
			{
			}
		}

		// Token: 0x1700287E RID: 10366
		// (get) Token: 0x060132D7 RID: 78551 RVA: 0x0007B9C0 File Offset: 0x00079BC0
		// (set) Token: 0x060132D8 RID: 78552 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700287E")]
		[Obsolete]
		public float loopDelay
		{
			[Token(Token = "0x60132D7")]
			[Address(RVA = "0x16C7678", Offset = "0x16C7678", VA = "0x16C7678")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132D8")]
			[Address(RVA = "0x16C7694", Offset = "0x16C7694", VA = "0x16C7694")]
			set
			{
			}
		}

		// Token: 0x1700287F RID: 10367
		// (get) Token: 0x060132D9 RID: 78553 RVA: 0x0007B9D8 File Offset: 0x00079BD8
		// (set) Token: 0x060132DA RID: 78554 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700287F")]
		public AnimatorUpdateMode updateMode
		{
			[Token(Token = "0x60132D9")]
			[Address(RVA = "0x16C76C4", Offset = "0x16C76C4", VA = "0x16C76C4")]
			get
			{
				return AnimatorUpdateMode.Normal;
			}
			[Token(Token = "0x60132DA")]
			[Address(RVA = "0x16C76E0", Offset = "0x16C76E0", VA = "0x16C76E0")]
			set
			{
			}
		}

		// Token: 0x17002880 RID: 10368
		// (get) Token: 0x060132DB RID: 78555 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002880")]
		public override ParameterTexture ptex
		{
			[Token(Token = "0x60132DB")]
			[Address(RVA = "0x16C7700", Offset = "0x16C7700", VA = "0x16C7700", Slot = "31")]
			get
			{
				return null;
			}
		}

		// Token: 0x060132DC RID: 78556 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132DC")]
		[Address(RVA = "0x16C7758", Offset = "0x16C7758", VA = "0x16C7758", Slot = "5")]
		protected override void OnEnable()
		{
		}

		// Token: 0x060132DD RID: 78557 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132DD")]
		[Address(RVA = "0x16C7AD4", Offset = "0x16C7AD4", VA = "0x16C7AD4", Slot = "7")]
		protected override void OnDisable()
		{
		}

		// Token: 0x060132DE RID: 78558 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132DE")]
		[Address(RVA = "0x16C7C4C", Offset = "0x16C7C4C", VA = "0x16C7C4C", Slot = "24")]
		public override void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x060132DF RID: 78559 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132DF")]
		[Address(RVA = "0x16C8224", Offset = "0x16C8224", VA = "0x16C8224")]
		public void Play()
		{
		}

		// Token: 0x060132E0 RID: 78560 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132E0")]
		[Address(RVA = "0x16C8264", Offset = "0x16C8264", VA = "0x16C8264")]
		public void Stop()
		{
		}

		// Token: 0x060132E1 RID: 78561 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132E1")]
		[Address(RVA = "0x16C8288", Offset = "0x16C8288", VA = "0x16C8288", Slot = "33")]
		protected override void SetDirty()
		{
		}

		// Token: 0x17002881 RID: 10369
		// (get) Token: 0x060132E2 RID: 78562 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002881")]
		private EffectPlayer _player
		{
			[Token(Token = "0x60132E2")]
			[Address(RVA = "0x16C7544", Offset = "0x16C7544", VA = "0x16C7544")]
			get
			{
				return null;
			}
		}

		// Token: 0x060132E3 RID: 78563 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132E3")]
		[Address(RVA = "0x16C8698", Offset = "0x16C8698", VA = "0x16C8698")]
		public UIShiny()
		{
		}

		// Token: 0x060132E5 RID: 78565 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132E5")]
		[Address(RVA = "0x16C8974", Offset = "0x16C8974", VA = "0x16C8974")]
		private void <OnEnable>b__64_0(float f)
		{
		}

		// Token: 0x0400F195 RID: 61845
		[Token(Token = "0x400F195")]
		public const string shaderName = "UI/Hidden/UI-Effect-Shiny";

		// Token: 0x0400F196 RID: 61846
		[Token(Token = "0x400F196")]
		[FieldOffset(Offset = "0x0")]
		private static readonly ParameterTexture _ptex;

		// Token: 0x0400F197 RID: 61847
		[Token(Token = "0x400F197")]
		[FieldOffset(Offset = "0x6C")]
		[SerializeField]
		[FormerlySerializedAs("m_Location")]
		private float m_EffectFactor;

		// Token: 0x0400F198 RID: 61848
		[Token(Token = "0x400F198")]
		[FieldOffset(Offset = "0x70")]
		[SerializeField]
		private float m_Width;

		// Token: 0x0400F199 RID: 61849
		[Token(Token = "0x400F199")]
		[FieldOffset(Offset = "0x74")]
		[SerializeField]
		private float m_Rotation;

		// Token: 0x0400F19A RID: 61850
		[Token(Token = "0x400F19A")]
		[FieldOffset(Offset = "0x78")]
		[SerializeField]
		private float m_Softness;

		// Token: 0x0400F19B RID: 61851
		[Token(Token = "0x400F19B")]
		[FieldOffset(Offset = "0x7C")]
		[SerializeField]
		[FormerlySerializedAs("m_Alpha")]
		private float m_Brightness;

		// Token: 0x0400F19C RID: 61852
		[Token(Token = "0x400F19C")]
		[FieldOffset(Offset = "0x80")]
		[SerializeField]
		[FormerlySerializedAs("m_Highlight")]
		private float m_Gloss;

		// Token: 0x0400F19D RID: 61853
		[Token(Token = "0x400F19D")]
		[FieldOffset(Offset = "0x84")]
		[SerializeField]
		protected EffectArea m_EffectArea;

		// Token: 0x0400F19E RID: 61854
		[Token(Token = "0x400F19E")]
		[FieldOffset(Offset = "0x88")]
		[SerializeField]
		private EffectPlayer m_Player;

		// Token: 0x0400F19F RID: 61855
		[Token(Token = "0x400F19F")]
		[FieldOffset(Offset = "0x90")]
		[SerializeField]
		[Obsolete]
		private bool m_Play;

		// Token: 0x0400F1A0 RID: 61856
		[Token(Token = "0x400F1A0")]
		[FieldOffset(Offset = "0x91")]
		[Obsolete]
		[SerializeField]
		private bool m_Loop;

		// Token: 0x0400F1A1 RID: 61857
		[Token(Token = "0x400F1A1")]
		[FieldOffset(Offset = "0x94")]
		[Obsolete]
		[SerializeField]
		private float m_Duration;

		// Token: 0x0400F1A2 RID: 61858
		[Token(Token = "0x400F1A2")]
		[FieldOffset(Offset = "0x98")]
		[SerializeField]
		[Obsolete]
		private float m_LoopDelay;

		// Token: 0x0400F1A3 RID: 61859
		[Token(Token = "0x400F1A3")]
		[FieldOffset(Offset = "0x9C")]
		[Obsolete]
		[SerializeField]
		private AnimatorUpdateMode m_UpdateMode;

		// Token: 0x0400F1A4 RID: 61860
		[Token(Token = "0x400F1A4")]
		[FieldOffset(Offset = "0xA0")]
		private float _lastRotation;
	}
}
