﻿using System;
using Il2CppDummyDll;

namespace Coffee.UIExtensions
{
	// Token: 0x0200269C RID: 9884
	[Token(Token = "0x200269C")]
	public enum EffectMode
	{
		// Token: 0x0400F1D3 RID: 61907
		[Token(Token = "0x400F1D3")]
		None,
		// Token: 0x0400F1D4 RID: 61908
		[Token(Token = "0x400F1D4")]
		Grayscale,
		// Token: 0x0400F1D5 RID: 61909
		[Token(Token = "0x400F1D5")]
		Sepia,
		// Token: 0x0400F1D6 RID: 61910
		[Token(Token = "0x400F1D6")]
		Nega,
		// Token: 0x0400F1D7 RID: 61911
		[Token(Token = "0x400F1D7")]
		Pixel
	}
}
