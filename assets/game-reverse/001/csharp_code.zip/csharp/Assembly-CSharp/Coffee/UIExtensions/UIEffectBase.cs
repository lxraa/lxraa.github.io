﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x0200269D RID: 9885
	[Token(Token = "0x200269D")]
	[DisallowMultipleComponent]
	public abstract class UIEffectBase : BaseMeshEffect, IParameterTexture
	{
		// Token: 0x17002886 RID: 10374
		// (get) Token: 0x06013316 RID: 78614 RVA: 0x0007BA68 File Offset: 0x00079C68
		// (set) Token: 0x06013317 RID: 78615 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002886")]
		public int parameterIndex
		{
			[Token(Token = "0x6013316")]
			[Address(RVA = "0x16CA04C", Offset = "0x16CA04C", VA = "0x16CA04C", Slot = "29")]
			get
			{
				return 0;
			}
			[Token(Token = "0x6013317")]
			[Address(RVA = "0x16CA054", Offset = "0x16CA054", VA = "0x16CA054", Slot = "30")]
			set
			{
			}
		}

		// Token: 0x17002887 RID: 10375
		// (get) Token: 0x06013318 RID: 78616 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002887")]
		public virtual ParameterTexture ptex
		{
			[Token(Token = "0x6013318")]
			[Address(RVA = "0x16CA05C", Offset = "0x16CA05C", VA = "0x16CA05C", Slot = "31")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002888 RID: 10376
		// (get) Token: 0x06013319 RID: 78617 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002888")]
		public Graphic targetGraphic
		{
			[Token(Token = "0x6013319")]
			[Address(RVA = "0x16C8680", Offset = "0x16C8680", VA = "0x16C8680")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002889 RID: 10377
		// (get) Token: 0x0601331A RID: 78618 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002889")]
		public Material effectMaterial
		{
			[Token(Token = "0x601331A")]
			[Address(RVA = "0x16CA064", Offset = "0x16CA064", VA = "0x16CA064")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601331B RID: 78619 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601331B")]
		[Address(RVA = "0x16CA06C", Offset = "0x16CA06C", VA = "0x16CA06C", Slot = "32")]
		public virtual void ModifyMaterial()
		{
		}

		// Token: 0x0601331C RID: 78620 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601331C")]
		[Address(RVA = "0x16C77F4", Offset = "0x16C77F4", VA = "0x16C77F4", Slot = "5")]
		protected override void OnEnable()
		{
		}

		// Token: 0x0601331D RID: 78621 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601331D")]
		[Address(RVA = "0x16C7AF8", Offset = "0x16C7AF8", VA = "0x16C7AF8", Slot = "7")]
		protected override void OnDisable()
		{
		}

		// Token: 0x0601331E RID: 78622 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601331E")]
		[Address(RVA = "0x16CA0C0", Offset = "0x16CA0C0", VA = "0x16CA0C0", Slot = "33")]
		protected virtual void SetDirty()
		{
		}

		// Token: 0x0601331F RID: 78623 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601331F")]
		[Address(RVA = "0x16CA0D0", Offset = "0x16CA0D0", VA = "0x16CA0D0", Slot = "13")]
		protected override void OnDidApplyAnimationProperties()
		{
		}

		// Token: 0x06013320 RID: 78624 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013320")]
		[Address(RVA = "0x16C8708", Offset = "0x16C8708", VA = "0x16C8708")]
		protected UIEffectBase()
		{
		}

		// Token: 0x0400F1D8 RID: 61912
		[Token(Token = "0x400F1D8")]
		[FieldOffset(Offset = "0x0")]
		protected static readonly Vector2[] splitedCharacterPosition;

		// Token: 0x0400F1D9 RID: 61913
		[Token(Token = "0x400F1D9")]
		[FieldOffset(Offset = "0x8")]
		protected static readonly List<UIVertex> tempVerts;

		// Token: 0x0400F1DA RID: 61914
		[Token(Token = "0x400F1DA")]
		[FieldOffset(Offset = "0x58")]
		[SerializeField]
		private int m_Version;

		// Token: 0x0400F1DB RID: 61915
		[Token(Token = "0x400F1DB")]
		[FieldOffset(Offset = "0x60")]
		[SerializeField]
		protected Material m_EffectMaterial;

		// Token: 0x0400F1DC RID: 61916
		[Token(Token = "0x400F1DC")]
		[FieldOffset(Offset = "0x68")]
		private int <parameterIndex>k__BackingField;
	}
}
