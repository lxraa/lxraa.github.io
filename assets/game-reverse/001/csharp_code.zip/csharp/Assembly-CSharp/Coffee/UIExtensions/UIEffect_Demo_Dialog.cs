﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace Coffee.UIExtensions
{
	// Token: 0x02002691 RID: 9873
	[Token(Token = "0x2002691")]
	public class UIEffect_Demo_Dialog : MonoBehaviour
	{
		// Token: 0x060132ED RID: 78573 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132ED")]
		[Address(RVA = "0x16C8FCC", Offset = "0x16C8FCC", VA = "0x16C8FCC")]
		public void Open()
		{
		}

		// Token: 0x060132EE RID: 78574 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132EE")]
		[Address(RVA = "0x16C8FF0", Offset = "0x16C8FF0", VA = "0x16C8FF0")]
		public void Close()
		{
		}

		// Token: 0x060132EF RID: 78575 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132EF")]
		[Address(RVA = "0x16C9044", Offset = "0x16C9044", VA = "0x16C9044")]
		public void Closed()
		{
		}

		// Token: 0x060132F0 RID: 78576 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132F0")]
		[Address(RVA = "0x16C9068", Offset = "0x16C9068", VA = "0x16C9068")]
		public UIEffect_Demo_Dialog()
		{
		}

		// Token: 0x0400F1A6 RID: 61862
		[Token(Token = "0x400F1A6")]
		[FieldOffset(Offset = "0x18")]
		[SerializeField]
		private Animator m_Animator;
	}
}
