﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace Coffee.UIExtensions
{
	// Token: 0x02002696 RID: 9878
	[Token(Token = "0x2002696")]
	public class MaterialCache
	{
		// Token: 0x17002882 RID: 10370
		// (get) Token: 0x060132FA RID: 78586 RVA: 0x0007B9F0 File Offset: 0x00079BF0
		// (set) Token: 0x060132FB RID: 78587 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002882")]
		public ulong hash
		{
			[Token(Token = "0x60132FA")]
			[Address(RVA = "0x16C9264", Offset = "0x16C9264", VA = "0x16C9264")]
			get
			{
				return 0UL;
			}
			[Token(Token = "0x60132FB")]
			[Address(RVA = "0x16C926C", Offset = "0x16C926C", VA = "0x16C926C")]
			private set
			{
			}
		}

		// Token: 0x17002883 RID: 10371
		// (get) Token: 0x060132FC RID: 78588 RVA: 0x0007BA08 File Offset: 0x00079C08
		// (set) Token: 0x060132FD RID: 78589 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002883")]
		public int referenceCount
		{
			[Token(Token = "0x60132FC")]
			[Address(RVA = "0x16C9274", Offset = "0x16C9274", VA = "0x16C9274")]
			get
			{
				return 0;
			}
			[Token(Token = "0x60132FD")]
			[Address(RVA = "0x16C927C", Offset = "0x16C927C", VA = "0x16C927C")]
			private set
			{
			}
		}

		// Token: 0x17002884 RID: 10372
		// (get) Token: 0x060132FE RID: 78590 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x060132FF RID: 78591 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002884")]
		public Material material
		{
			[Token(Token = "0x60132FE")]
			[Address(RVA = "0x16C9284", Offset = "0x16C9284", VA = "0x16C9284")]
			get
			{
				return null;
			}
			[Token(Token = "0x60132FF")]
			[Address(RVA = "0x16C928C", Offset = "0x16C928C", VA = "0x16C928C")]
			private set
			{
			}
		}

		// Token: 0x06013300 RID: 78592 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013300")]
		[Address(RVA = "0x16C9294", Offset = "0x16C9294", VA = "0x16C9294")]
		public static MaterialCache Register(ulong hash, Texture texture, Func<Material> onCreateMaterial)
		{
			return null;
		}

		// Token: 0x06013301 RID: 78593 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013301")]
		[Address(RVA = "0x16C9550", Offset = "0x16C9550", VA = "0x16C9550")]
		public static void Unregister(MaterialCache cache)
		{
		}

		// Token: 0x06013302 RID: 78594 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013302")]
		[Address(RVA = "0x16C9548", Offset = "0x16C9548", VA = "0x16C9548")]
		public MaterialCache()
		{
		}

		// Token: 0x0400F1BB RID: 61883
		[Token(Token = "0x400F1BB")]
		[FieldOffset(Offset = "0x10")]
		private ulong <hash>k__BackingField;

		// Token: 0x0400F1BC RID: 61884
		[Token(Token = "0x400F1BC")]
		[FieldOffset(Offset = "0x18")]
		private int <referenceCount>k__BackingField;

		// Token: 0x0400F1BD RID: 61885
		[Token(Token = "0x400F1BD")]
		[FieldOffset(Offset = "0x20")]
		private Texture <texture>k__BackingField;

		// Token: 0x0400F1BE RID: 61886
		[Token(Token = "0x400F1BE")]
		[FieldOffset(Offset = "0x28")]
		private Material <material>k__BackingField;

		// Token: 0x0400F1BF RID: 61887
		[Token(Token = "0x400F1BF")]
		[FieldOffset(Offset = "0x0")]
		public static List<MaterialCache> materialCaches;

		// Token: 0x02002697 RID: 9879
		[Token(Token = "0x2002697")]
		private sealed class <>c__DisplayClass17_0
		{
			// Token: 0x06013304 RID: 78596 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013304")]
			[Address(RVA = "0x16C9540", Offset = "0x16C9540", VA = "0x16C9540")]
			public <>c__DisplayClass17_0()
			{
			}

			// Token: 0x06013305 RID: 78597 RVA: 0x0007BA20 File Offset: 0x00079C20
			[Token(Token = "0x6013305")]
			[Address(RVA = "0x16C969C", Offset = "0x16C969C", VA = "0x16C969C")]
			internal bool <Register>b__0(MaterialCache x)
			{
				return default(bool);
			}

			// Token: 0x0400F1C0 RID: 61888
			[Token(Token = "0x400F1C0")]
			[FieldOffset(Offset = "0x10")]
			public ulong hash;
		}
	}
}
