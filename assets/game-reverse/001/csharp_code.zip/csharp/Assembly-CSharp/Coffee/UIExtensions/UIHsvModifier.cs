﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x020026A2 RID: 9890
	[Token(Token = "0x20026A2")]
	public class UIHsvModifier : UIEffectBase
	{
		// Token: 0x170028AD RID: 10413
		// (get) Token: 0x06013370 RID: 78704 RVA: 0x0007BD50 File Offset: 0x00079F50
		// (set) Token: 0x06013371 RID: 78705 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028AD")]
		public Color targetColor
		{
			[Token(Token = "0x6013370")]
			[Address(RVA = "0x16CC144", Offset = "0x16CC144", VA = "0x16CC144")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x6013371")]
			[Address(RVA = "0x16CC150", Offset = "0x16CC150", VA = "0x16CC150")]
			set
			{
			}
		}

		// Token: 0x170028AE RID: 10414
		// (get) Token: 0x06013372 RID: 78706 RVA: 0x0007BD68 File Offset: 0x00079F68
		// (set) Token: 0x06013373 RID: 78707 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028AE")]
		public float range
		{
			[Token(Token = "0x6013372")]
			[Address(RVA = "0x16CC1B0", Offset = "0x16CC1B0", VA = "0x16CC1B0")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013373")]
			[Address(RVA = "0x16CC1B8", Offset = "0x16CC1B8", VA = "0x16CC1B8")]
			set
			{
			}
		}

		// Token: 0x170028AF RID: 10415
		// (get) Token: 0x06013374 RID: 78708 RVA: 0x0007BD80 File Offset: 0x00079F80
		// (set) Token: 0x06013375 RID: 78709 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028AF")]
		public float saturation
		{
			[Token(Token = "0x6013374")]
			[Address(RVA = "0x16CC280", Offset = "0x16CC280", VA = "0x16CC280")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013375")]
			[Address(RVA = "0x16CC288", Offset = "0x16CC288", VA = "0x16CC288")]
			set
			{
			}
		}

		// Token: 0x170028B0 RID: 10416
		// (get) Token: 0x06013376 RID: 78710 RVA: 0x0007BD98 File Offset: 0x00079F98
		// (set) Token: 0x06013377 RID: 78711 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028B0")]
		public float value
		{
			[Token(Token = "0x6013376")]
			[Address(RVA = "0x16CC350", Offset = "0x16CC350", VA = "0x16CC350")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013377")]
			[Address(RVA = "0x16CC358", Offset = "0x16CC358", VA = "0x16CC358")]
			set
			{
			}
		}

		// Token: 0x170028B1 RID: 10417
		// (get) Token: 0x06013378 RID: 78712 RVA: 0x0007BDB0 File Offset: 0x00079FB0
		// (set) Token: 0x06013379 RID: 78713 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028B1")]
		public float hue
		{
			[Token(Token = "0x6013378")]
			[Address(RVA = "0x16CC420", Offset = "0x16CC420", VA = "0x16CC420")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013379")]
			[Address(RVA = "0x16CC428", Offset = "0x16CC428", VA = "0x16CC428")]
			set
			{
			}
		}

		// Token: 0x170028B2 RID: 10418
		// (get) Token: 0x0601337A RID: 78714 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170028B2")]
		public override ParameterTexture ptex
		{
			[Token(Token = "0x601337A")]
			[Address(RVA = "0x16CC4F0", Offset = "0x16CC4F0", VA = "0x16CC4F0", Slot = "31")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601337B RID: 78715 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601337B")]
		[Address(RVA = "0x16CC548", Offset = "0x16CC548", VA = "0x16CC548", Slot = "24")]
		public override void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x0601337C RID: 78716 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601337C")]
		[Address(RVA = "0x16CC654", Offset = "0x16CC654", VA = "0x16CC654", Slot = "33")]
		protected override void SetDirty()
		{
		}

		// Token: 0x0601337D RID: 78717 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601337D")]
		[Address(RVA = "0x16CC92C", Offset = "0x16CC92C", VA = "0x16CC92C")]
		public UIHsvModifier()
		{
		}

		// Token: 0x0400F20D RID: 61965
		[Token(Token = "0x400F20D")]
		public const string shaderName = "UI/Hidden/UI-Effect-HSV";

		// Token: 0x0400F20E RID: 61966
		[Token(Token = "0x400F20E")]
		[FieldOffset(Offset = "0x0")]
		private static readonly ParameterTexture _ptex;

		// Token: 0x0400F20F RID: 61967
		[Token(Token = "0x400F20F")]
		[FieldOffset(Offset = "0x6C")]
		[SerializeField]
		private Color m_TargetColor;

		// Token: 0x0400F210 RID: 61968
		[Token(Token = "0x400F210")]
		[FieldOffset(Offset = "0x7C")]
		[SerializeField]
		private float m_Range;

		// Token: 0x0400F211 RID: 61969
		[Token(Token = "0x400F211")]
		[FieldOffset(Offset = "0x80")]
		[SerializeField]
		private float m_Hue;

		// Token: 0x0400F212 RID: 61970
		[Token(Token = "0x400F212")]
		[FieldOffset(Offset = "0x84")]
		[SerializeField]
		private float m_Saturation;

		// Token: 0x0400F213 RID: 61971
		[Token(Token = "0x400F213")]
		[FieldOffset(Offset = "0x88")]
		[SerializeField]
		private float m_Value;
	}
}
