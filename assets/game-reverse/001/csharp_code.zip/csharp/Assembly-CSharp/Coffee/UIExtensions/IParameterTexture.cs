﻿using System;
using Il2CppDummyDll;

namespace Coffee.UIExtensions
{
	// Token: 0x02002699 RID: 9881
	[Token(Token = "0x2002699")]
	public interface IParameterTexture
	{
		// Token: 0x17002885 RID: 10373
		// (get) Token: 0x06013308 RID: 78600
		// (set) Token: 0x06013309 RID: 78601
		[Token(Token = "0x17002885")]
		int parameterIndex { [Token(Token = "0x6013308")] get; [Token(Token = "0x6013309")] set; }
	}
}
