﻿using System;
using Il2CppDummyDll;

namespace Coffee.UIExtensions
{
	// Token: 0x02002684 RID: 9860
	[Token(Token = "0x2002684")]
	public enum EffectArea
	{
		// Token: 0x0400F150 RID: 61776
		[Token(Token = "0x400F150")]
		RectTransform,
		// Token: 0x0400F151 RID: 61777
		[Token(Token = "0x400F151")]
		Fit,
		// Token: 0x0400F152 RID: 61778
		[Token(Token = "0x400F152")]
		Character
	}
}
