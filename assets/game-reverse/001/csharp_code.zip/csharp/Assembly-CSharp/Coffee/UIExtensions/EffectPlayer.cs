﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Il2CppDummyDll;
using UnityEngine;

namespace Coffee.UIExtensions
{
	// Token: 0x02002694 RID: 9876
	[Token(Token = "0x2002694")]
	[Serializable]
	public class EffectPlayer
	{
		// Token: 0x060132F1 RID: 78577 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132F1")]
		[Address(RVA = "0x16C7880", Offset = "0x16C7880", VA = "0x16C7880")]
		public void OnEnable([Optional] Action<float> callback)
		{
		}

		// Token: 0x060132F2 RID: 78578 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132F2")]
		[Address(RVA = "0x16C7B78", Offset = "0x16C7B78", VA = "0x16C7B78")]
		public void OnDisable()
		{
		}

		// Token: 0x060132F3 RID: 78579 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132F3")]
		[Address(RVA = "0x16C8248", Offset = "0x16C8248", VA = "0x16C8248")]
		public void Play([Optional] Action<float> callback)
		{
		}

		// Token: 0x060132F4 RID: 78580 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132F4")]
		[Address(RVA = "0x16C8280", Offset = "0x16C8280", VA = "0x16C8280")]
		public void Stop()
		{
		}

		// Token: 0x060132F5 RID: 78581 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132F5")]
		[Address(RVA = "0x16C9070", Offset = "0x16C9070", VA = "0x16C9070")]
		private void OnWillRenderCanvases()
		{
		}

		// Token: 0x060132F6 RID: 78582 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132F6")]
		[Address(RVA = "0x16C8688", Offset = "0x16C8688", VA = "0x16C8688")]
		public EffectPlayer()
		{
		}

		// Token: 0x0400F1B1 RID: 61873
		[Token(Token = "0x400F1B1")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		public bool play;

		// Token: 0x0400F1B2 RID: 61874
		[Token(Token = "0x400F1B2")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x11")]
		public bool loop;

		// Token: 0x0400F1B3 RID: 61875
		[Token(Token = "0x400F1B3")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x14")]
		public float duration;

		// Token: 0x0400F1B4 RID: 61876
		[Token(Token = "0x400F1B4")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		public float loopDelay;

		// Token: 0x0400F1B5 RID: 61877
		[Token(Token = "0x400F1B5")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x1C")]
		public AnimatorUpdateMode updateMode;

		// Token: 0x0400F1B6 RID: 61878
		[Token(Token = "0x400F1B6")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private static List<Action> s_UpdateActions;

		// Token: 0x0400F1B7 RID: 61879
		[Token(Token = "0x400F1B7")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		private float _time;

		// Token: 0x0400F1B8 RID: 61880
		[Token(Token = "0x400F1B8")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		private Action<float> _callback;

		// Token: 0x02002695 RID: 9877
		[Token(Token = "0x2002695")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x060132F8 RID: 78584 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60132F8")]
			[Address(RVA = "0x16C9194", Offset = "0x16C9194", VA = "0x16C9194")]
			public <>c()
			{
			}

			// Token: 0x060132F9 RID: 78585 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60132F9")]
			[Address(RVA = "0x16C919C", Offset = "0x16C919C", VA = "0x16C919C")]
			internal void <OnEnable>b__6_0()
			{
			}

			// Token: 0x0400F1B9 RID: 61881
			[Token(Token = "0x400F1B9")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
			public static readonly EffectPlayer.<>c <>9;

			// Token: 0x0400F1BA RID: 61882
			[Token(Token = "0x400F1BA")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
			public static Canvas.WillRenderCanvases <>9__6_0;
		}
	}
}
