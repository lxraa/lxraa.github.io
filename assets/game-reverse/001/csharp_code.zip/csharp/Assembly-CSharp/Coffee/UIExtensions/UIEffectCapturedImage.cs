﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x0200269F RID: 9887
	[Token(Token = "0x200269F")]
	public class UIEffectCapturedImage : RawImage
	{
		// Token: 0x17002895 RID: 10389
		// (get) Token: 0x06013338 RID: 78648 RVA: 0x0007BB70 File Offset: 0x00079D70
		// (set) Token: 0x06013339 RID: 78649 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002895")]
		[Obsolete("Use effectFactor instead (UnityUpgradable) -> effectFactor")]
		public float toneLevel
		{
			[Token(Token = "0x6013338")]
			[Address(RVA = "0x16CB08C", Offset = "0x16CB08C", VA = "0x16CB08C")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013339")]
			[Address(RVA = "0x16CB094", Offset = "0x16CB094", VA = "0x16CB094")]
			set
			{
			}
		}

		// Token: 0x17002896 RID: 10390
		// (get) Token: 0x0601333A RID: 78650 RVA: 0x0007BB88 File Offset: 0x00079D88
		// (set) Token: 0x0601333B RID: 78651 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002896")]
		public float effectFactor
		{
			[Token(Token = "0x601333A")]
			[Address(RVA = "0x16CB0B0", Offset = "0x16CB0B0", VA = "0x16CB0B0")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x601333B")]
			[Address(RVA = "0x16CB0B8", Offset = "0x16CB0B8", VA = "0x16CB0B8")]
			set
			{
			}
		}

		// Token: 0x17002897 RID: 10391
		// (get) Token: 0x0601333C RID: 78652 RVA: 0x0007BBA0 File Offset: 0x00079DA0
		// (set) Token: 0x0601333D RID: 78653 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002897")]
		public float colorFactor
		{
			[Token(Token = "0x601333C")]
			[Address(RVA = "0x16CB0D4", Offset = "0x16CB0D4", VA = "0x16CB0D4")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x601333D")]
			[Address(RVA = "0x16CB0DC", Offset = "0x16CB0DC", VA = "0x16CB0DC")]
			set
			{
			}
		}

		// Token: 0x17002898 RID: 10392
		// (get) Token: 0x0601333E RID: 78654 RVA: 0x0007BBB8 File Offset: 0x00079DB8
		// (set) Token: 0x0601333F RID: 78655 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002898")]
		[Obsolete("Use blurFactor instead (UnityUpgradable) -> blurFactor")]
		public float blur
		{
			[Token(Token = "0x601333E")]
			[Address(RVA = "0x16CB0F8", Offset = "0x16CB0F8", VA = "0x16CB0F8")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x601333F")]
			[Address(RVA = "0x16CB100", Offset = "0x16CB100", VA = "0x16CB100")]
			set
			{
			}
		}

		// Token: 0x17002899 RID: 10393
		// (get) Token: 0x06013340 RID: 78656 RVA: 0x0007BBD0 File Offset: 0x00079DD0
		// (set) Token: 0x06013341 RID: 78657 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002899")]
		public float blurFactor
		{
			[Token(Token = "0x6013340")]
			[Address(RVA = "0x16CB11C", Offset = "0x16CB11C", VA = "0x16CB11C")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013341")]
			[Address(RVA = "0x16CB124", Offset = "0x16CB124", VA = "0x16CB124")]
			set
			{
			}
		}

		// Token: 0x1700289A RID: 10394
		// (get) Token: 0x06013342 RID: 78658 RVA: 0x0007BBE8 File Offset: 0x00079DE8
		[Token(Token = "0x1700289A")]
		[Obsolete("Use effectMode instead (UnityUpgradable) -> effectMode")]
		public EffectMode toneMode
		{
			[Token(Token = "0x6013342")]
			[Address(RVA = "0x16CB140", Offset = "0x16CB140", VA = "0x16CB140")]
			get
			{
				return EffectMode.None;
			}
		}

		// Token: 0x1700289B RID: 10395
		// (get) Token: 0x06013343 RID: 78659 RVA: 0x0007BC00 File Offset: 0x00079E00
		[Token(Token = "0x1700289B")]
		public EffectMode effectMode
		{
			[Token(Token = "0x6013343")]
			[Address(RVA = "0x16CB148", Offset = "0x16CB148", VA = "0x16CB148")]
			get
			{
				return EffectMode.None;
			}
		}

		// Token: 0x1700289C RID: 10396
		// (get) Token: 0x06013344 RID: 78660 RVA: 0x0007BC18 File Offset: 0x00079E18
		[Token(Token = "0x1700289C")]
		public ColorMode colorMode
		{
			[Token(Token = "0x6013344")]
			[Address(RVA = "0x16CB150", Offset = "0x16CB150", VA = "0x16CB150")]
			get
			{
				return ColorMode.Multiply;
			}
		}

		// Token: 0x1700289D RID: 10397
		// (get) Token: 0x06013345 RID: 78661 RVA: 0x0007BC30 File Offset: 0x00079E30
		[Token(Token = "0x1700289D")]
		public BlurMode blurMode
		{
			[Token(Token = "0x6013345")]
			[Address(RVA = "0x16CB158", Offset = "0x16CB158", VA = "0x16CB158")]
			get
			{
				return BlurMode.None;
			}
		}

		// Token: 0x1700289E RID: 10398
		// (get) Token: 0x06013346 RID: 78662 RVA: 0x0007BC48 File Offset: 0x00079E48
		// (set) Token: 0x06013347 RID: 78663 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700289E")]
		public Color effectColor
		{
			[Token(Token = "0x6013346")]
			[Address(RVA = "0x16CB160", Offset = "0x16CB160", VA = "0x16CB160")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x6013347")]
			[Address(RVA = "0x16CB174", Offset = "0x16CB174", VA = "0x16CB174")]
			set
			{
			}
		}

		// Token: 0x1700289F RID: 10399
		// (get) Token: 0x06013348 RID: 78664 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700289F")]
		public virtual Material effectMaterial
		{
			[Token(Token = "0x6013348")]
			[Address(RVA = "0x16CB188", Offset = "0x16CB188", VA = "0x16CB188", Slot = "61")]
			get
			{
				return null;
			}
		}

		// Token: 0x170028A0 RID: 10400
		// (get) Token: 0x06013349 RID: 78665 RVA: 0x0007BC60 File Offset: 0x00079E60
		// (set) Token: 0x0601334A RID: 78666 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028A0")]
		public UIEffectCapturedImage.DesamplingRate desamplingRate
		{
			[Token(Token = "0x6013349")]
			[Address(RVA = "0x16CB190", Offset = "0x16CB190", VA = "0x16CB190")]
			get
			{
				return UIEffectCapturedImage.DesamplingRate.None;
			}
			[Token(Token = "0x601334A")]
			[Address(RVA = "0x16CB198", Offset = "0x16CB198", VA = "0x16CB198")]
			set
			{
			}
		}

		// Token: 0x170028A1 RID: 10401
		// (get) Token: 0x0601334B RID: 78667 RVA: 0x0007BC78 File Offset: 0x00079E78
		// (set) Token: 0x0601334C RID: 78668 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028A1")]
		public UIEffectCapturedImage.DesamplingRate reductionRate
		{
			[Token(Token = "0x601334B")]
			[Address(RVA = "0x16CB1A0", Offset = "0x16CB1A0", VA = "0x16CB1A0")]
			get
			{
				return UIEffectCapturedImage.DesamplingRate.None;
			}
			[Token(Token = "0x601334C")]
			[Address(RVA = "0x16CB1A8", Offset = "0x16CB1A8", VA = "0x16CB1A8")]
			set
			{
			}
		}

		// Token: 0x170028A2 RID: 10402
		// (get) Token: 0x0601334D RID: 78669 RVA: 0x0007BC90 File Offset: 0x00079E90
		// (set) Token: 0x0601334E RID: 78670 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028A2")]
		public FilterMode filterMode
		{
			[Token(Token = "0x601334D")]
			[Address(RVA = "0x16CB1B0", Offset = "0x16CB1B0", VA = "0x16CB1B0")]
			get
			{
				return FilterMode.Point;
			}
			[Token(Token = "0x601334E")]
			[Address(RVA = "0x16CB1B8", Offset = "0x16CB1B8", VA = "0x16CB1B8")]
			set
			{
			}
		}

		// Token: 0x170028A3 RID: 10403
		// (get) Token: 0x0601334F RID: 78671 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170028A3")]
		public RenderTexture capturedTexture
		{
			[Token(Token = "0x601334F")]
			[Address(RVA = "0x16CB1C0", Offset = "0x16CB1C0", VA = "0x16CB1C0")]
			get
			{
				return null;
			}
		}

		// Token: 0x170028A4 RID: 10404
		// (get) Token: 0x06013350 RID: 78672 RVA: 0x0007BCA8 File Offset: 0x00079EA8
		// (set) Token: 0x06013351 RID: 78673 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028A4")]
		[Obsolete("Use blurIterations instead (UnityUpgradable) -> blurIterations")]
		public int iterations
		{
			[Token(Token = "0x6013350")]
			[Address(RVA = "0x16CB1C8", Offset = "0x16CB1C8", VA = "0x16CB1C8")]
			get
			{
				return 0;
			}
			[Token(Token = "0x6013351")]
			[Address(RVA = "0x16CB1D0", Offset = "0x16CB1D0", VA = "0x16CB1D0")]
			set
			{
			}
		}

		// Token: 0x170028A5 RID: 10405
		// (get) Token: 0x06013352 RID: 78674 RVA: 0x0007BCC0 File Offset: 0x00079EC0
		// (set) Token: 0x06013353 RID: 78675 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028A5")]
		public int blurIterations
		{
			[Token(Token = "0x6013352")]
			[Address(RVA = "0x16CB1D8", Offset = "0x16CB1D8", VA = "0x16CB1D8")]
			get
			{
				return 0;
			}
			[Token(Token = "0x6013353")]
			[Address(RVA = "0x16CB1E0", Offset = "0x16CB1E0", VA = "0x16CB1E0")]
			set
			{
			}
		}

		// Token: 0x170028A6 RID: 10406
		// (get) Token: 0x06013354 RID: 78676 RVA: 0x0007BCD8 File Offset: 0x00079ED8
		// (set) Token: 0x06013355 RID: 78677 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028A6")]
		[Obsolete("Use fitToScreen instead (UnityUpgradable) -> fitToScreen")]
		public bool keepCanvasSize
		{
			[Token(Token = "0x6013354")]
			[Address(RVA = "0x16CB1E8", Offset = "0x16CB1E8", VA = "0x16CB1E8")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6013355")]
			[Address(RVA = "0x16CB1F0", Offset = "0x16CB1F0", VA = "0x16CB1F0")]
			set
			{
			}
		}

		// Token: 0x170028A7 RID: 10407
		// (get) Token: 0x06013356 RID: 78678 RVA: 0x0007BCF0 File Offset: 0x00079EF0
		// (set) Token: 0x06013357 RID: 78679 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028A7")]
		public bool fitToScreen
		{
			[Token(Token = "0x6013356")]
			[Address(RVA = "0x16CB1FC", Offset = "0x16CB1FC", VA = "0x16CB1FC")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6013357")]
			[Address(RVA = "0x16CB204", Offset = "0x16CB204", VA = "0x16CB204")]
			set
			{
			}
		}

		// Token: 0x170028A8 RID: 10408
		// (get) Token: 0x06013358 RID: 78680 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170028A8")]
		[Obsolete]
		public RenderTexture targetTexture
		{
			[Token(Token = "0x6013358")]
			[Address(RVA = "0x16CB210", Offset = "0x16CB210", VA = "0x16CB210")]
			get
			{
				return null;
			}
		}

		// Token: 0x170028A9 RID: 10409
		// (get) Token: 0x06013359 RID: 78681 RVA: 0x0007BD08 File Offset: 0x00079F08
		// (set) Token: 0x0601335A RID: 78682 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028A9")]
		public bool captureOnEnable
		{
			[Token(Token = "0x6013359")]
			[Address(RVA = "0x16CB218", Offset = "0x16CB218", VA = "0x16CB218")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x601335A")]
			[Address(RVA = "0x16CB220", Offset = "0x16CB220", VA = "0x16CB220")]
			set
			{
			}
		}

		// Token: 0x170028AA RID: 10410
		// (get) Token: 0x0601335B RID: 78683 RVA: 0x0007BD20 File Offset: 0x00079F20
		// (set) Token: 0x0601335C RID: 78684 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028AA")]
		public bool immediateCapturing
		{
			[Token(Token = "0x601335B")]
			[Address(RVA = "0x16CB22C", Offset = "0x16CB22C", VA = "0x16CB22C")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x601335C")]
			[Address(RVA = "0x16CB234", Offset = "0x16CB234", VA = "0x16CB234")]
			set
			{
			}
		}

		// Token: 0x0601335D RID: 78685 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601335D")]
		[Address(RVA = "0x16CB240", Offset = "0x16CB240", VA = "0x16CB240", Slot = "5")]
		protected override void OnEnable()
		{
		}

		// Token: 0x0601335E RID: 78686 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601335E")]
		[Address(RVA = "0x16CB278", Offset = "0x16CB278", VA = "0x16CB278", Slot = "7")]
		protected override void OnDisable()
		{
		}

		// Token: 0x0601335F RID: 78687 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601335F")]
		[Address(RVA = "0x16CB378", Offset = "0x16CB378", VA = "0x16CB378", Slot = "8")]
		protected override void OnDestroy()
		{
		}

		// Token: 0x06013360 RID: 78688 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013360")]
		[Address(RVA = "0x16CB3CC", Offset = "0x16CB3CC", VA = "0x16CB3CC", Slot = "43")]
		protected override void OnPopulateMesh(VertexHelper vh)
		{
		}

		// Token: 0x06013361 RID: 78689 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013361")]
		[Address(RVA = "0x16CB720", Offset = "0x16CB720", VA = "0x16CB720")]
		public void GetDesamplingSize(UIEffectCapturedImage.DesamplingRate rate, out int w, out int h)
		{
		}

		// Token: 0x06013362 RID: 78690 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013362")]
		[Address(RVA = "0x16C8A9C", Offset = "0x16C8A9C", VA = "0x16C8A9C")]
		public void Capture()
		{
		}

		// Token: 0x06013363 RID: 78691 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013363")]
		[Address(RVA = "0x16CB8F4", Offset = "0x16CB8F4", VA = "0x16CB8F4")]
		private void SetupCommandBuffer()
		{
		}

		// Token: 0x06013364 RID: 78692 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013364")]
		[Address(RVA = "0x16CB3A8", Offset = "0x16CB3A8", VA = "0x16CB3A8")]
		public void Release()
		{
		}

		// Token: 0x06013365 RID: 78693 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013365")]
		[Address(RVA = "0x16CB2C4", Offset = "0x16CB2C4", VA = "0x16CB2C4")]
		private void _Release(bool releaseRT)
		{
		}

		// Token: 0x06013366 RID: 78694 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013366")]
		[Address(RVA = "0x16CB844", Offset = "0x16CB844", VA = "0x16CB844")]
		private void _Release(ref RenderTexture obj)
		{
		}

		// Token: 0x06013367 RID: 78695 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013367")]
		[Address(RVA = "0x16CBF68", Offset = "0x16CBF68", VA = "0x16CBF68")]
		private IEnumerator _CoUpdateTextureOnNextFrame()
		{
			return null;
		}

		// Token: 0x06013368 RID: 78696 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013368")]
		[Address(RVA = "0x16CBECC", Offset = "0x16CBECC", VA = "0x16CBECC")]
		private void UpdateTexture()
		{
		}

		// Token: 0x06013369 RID: 78697 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013369")]
		[Address(RVA = "0x16CC004", Offset = "0x16CC004", VA = "0x16CC004")]
		public UIEffectCapturedImage()
		{
		}

		// Token: 0x0400F1ED RID: 61933
		[Token(Token = "0x400F1ED")]
		public const string shaderName = "UI/Hidden/UI-EffectCapture";

		// Token: 0x0400F1EE RID: 61934
		[Token(Token = "0x400F1EE")]
		[FieldOffset(Offset = "0xE8")]
		[FormerlySerializedAs("m_ToneLevel")]
		[SerializeField]
		private float m_EffectFactor;

		// Token: 0x0400F1EF RID: 61935
		[Token(Token = "0x400F1EF")]
		[FieldOffset(Offset = "0xEC")]
		[SerializeField]
		private float m_ColorFactor;

		// Token: 0x0400F1F0 RID: 61936
		[Token(Token = "0x400F1F0")]
		[FieldOffset(Offset = "0xF0")]
		[FormerlySerializedAs("m_Blur")]
		[SerializeField]
		private float m_BlurFactor;

		// Token: 0x0400F1F1 RID: 61937
		[Token(Token = "0x400F1F1")]
		[FieldOffset(Offset = "0xF4")]
		[SerializeField]
		[FormerlySerializedAs("m_ToneMode")]
		private EffectMode m_EffectMode;

		// Token: 0x0400F1F2 RID: 61938
		[Token(Token = "0x400F1F2")]
		[FieldOffset(Offset = "0xF8")]
		[SerializeField]
		private ColorMode m_ColorMode;

		// Token: 0x0400F1F3 RID: 61939
		[Token(Token = "0x400F1F3")]
		[FieldOffset(Offset = "0xFC")]
		[SerializeField]
		private BlurMode m_BlurMode;

		// Token: 0x0400F1F4 RID: 61940
		[Token(Token = "0x400F1F4")]
		[FieldOffset(Offset = "0x100")]
		[SerializeField]
		private Color m_EffectColor;

		// Token: 0x0400F1F5 RID: 61941
		[Token(Token = "0x400F1F5")]
		[FieldOffset(Offset = "0x110")]
		[SerializeField]
		private UIEffectCapturedImage.DesamplingRate m_DesamplingRate;

		// Token: 0x0400F1F6 RID: 61942
		[Token(Token = "0x400F1F6")]
		[FieldOffset(Offset = "0x114")]
		[SerializeField]
		private UIEffectCapturedImage.DesamplingRate m_ReductionRate;

		// Token: 0x0400F1F7 RID: 61943
		[Token(Token = "0x400F1F7")]
		[FieldOffset(Offset = "0x118")]
		[SerializeField]
		private FilterMode m_FilterMode;

		// Token: 0x0400F1F8 RID: 61944
		[Token(Token = "0x400F1F8")]
		[FieldOffset(Offset = "0x120")]
		[SerializeField]
		private Material m_EffectMaterial;

		// Token: 0x0400F1F9 RID: 61945
		[Token(Token = "0x400F1F9")]
		[FieldOffset(Offset = "0x128")]
		[SerializeField]
		[FormerlySerializedAs("m_Iterations")]
		private int m_BlurIterations;

		// Token: 0x0400F1FA RID: 61946
		[Token(Token = "0x400F1FA")]
		[FieldOffset(Offset = "0x12C")]
		[SerializeField]
		[FormerlySerializedAs("m_KeepCanvasSize")]
		private bool m_FitToScreen;

		// Token: 0x0400F1FB RID: 61947
		[Token(Token = "0x400F1FB")]
		[FieldOffset(Offset = "0x12D")]
		[SerializeField]
		private bool m_CaptureOnEnable;

		// Token: 0x0400F1FC RID: 61948
		[Token(Token = "0x400F1FC")]
		[FieldOffset(Offset = "0x12E")]
		[SerializeField]
		private bool m_ImmediateCapturing;

		// Token: 0x0400F1FD RID: 61949
		[Token(Token = "0x400F1FD")]
		[FieldOffset(Offset = "0x130")]
		private RenderTexture _rt;

		// Token: 0x0400F1FE RID: 61950
		[Token(Token = "0x400F1FE")]
		[FieldOffset(Offset = "0x0")]
		private static int s_CopyId;

		// Token: 0x0400F1FF RID: 61951
		[Token(Token = "0x400F1FF")]
		[FieldOffset(Offset = "0x4")]
		private static int s_EffectId1;

		// Token: 0x0400F200 RID: 61952
		[Token(Token = "0x400F200")]
		[FieldOffset(Offset = "0x8")]
		private static int s_EffectId2;

		// Token: 0x0400F201 RID: 61953
		[Token(Token = "0x400F201")]
		[FieldOffset(Offset = "0xC")]
		private static int s_EffectFactorId;

		// Token: 0x0400F202 RID: 61954
		[Token(Token = "0x400F202")]
		[FieldOffset(Offset = "0x10")]
		private static int s_ColorFactorId;

		// Token: 0x0400F203 RID: 61955
		[Token(Token = "0x400F203")]
		[FieldOffset(Offset = "0x18")]
		private static CommandBuffer s_CommandBuffer;

		// Token: 0x020026A0 RID: 9888
		[Token(Token = "0x20026A0")]
		public enum DesamplingRate
		{
			// Token: 0x0400F205 RID: 61957
			[Token(Token = "0x400F205")]
			None,
			// Token: 0x0400F206 RID: 61958
			[Token(Token = "0x400F206")]
			x1,
			// Token: 0x0400F207 RID: 61959
			[Token(Token = "0x400F207")]
			x2,
			// Token: 0x0400F208 RID: 61960
			[Token(Token = "0x400F208")]
			x4 = 4,
			// Token: 0x0400F209 RID: 61961
			[Token(Token = "0x400F209")]
			x8 = 8
		}

		// Token: 0x020026A1 RID: 9889
		[Token(Token = "0x20026A1")]
		private sealed class <_CoUpdateTextureOnNextFrame>d__95 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x0601336A RID: 78698 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601336A")]
			[Address(RVA = "0x16CBFDC", Offset = "0x16CBFDC", VA = "0x16CBFDC")]
			[DebuggerHidden]
			public <_CoUpdateTextureOnNextFrame>d__95(int <>1__state)
			{
			}

			// Token: 0x0601336B RID: 78699 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601336B")]
			[Address(RVA = "0x16CC048", Offset = "0x16CC048", VA = "0x16CC048", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x0601336C RID: 78700 RVA: 0x0007BD38 File Offset: 0x00079F38
			[Token(Token = "0x601336C")]
			[Address(RVA = "0x16CC04C", Offset = "0x16CC04C", VA = "0x16CC04C", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x170028AB RID: 10411
			// (get) Token: 0x0601336D RID: 78701 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170028AB")]
			private object Current
			{
				[Token(Token = "0x601336D")]
				[Address(RVA = "0x16CC0F4", Offset = "0x16CC0F4", VA = "0x16CC0F4", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0601336E RID: 78702 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601336E")]
			[Address(RVA = "0x16CC0FC", Offset = "0x16CC0FC", VA = "0x16CC0FC", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x170028AC RID: 10412
			// (get) Token: 0x0601336F RID: 78703 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170028AC")]
			private object Current
			{
				[Token(Token = "0x601336F")]
				[Address(RVA = "0x16CC13C", Offset = "0x16CC13C", VA = "0x16CC13C", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400F20A RID: 61962
			[Token(Token = "0x400F20A")]
			[FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400F20B RID: 61963
			[Token(Token = "0x400F20B")]
			[FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400F20C RID: 61964
			[Token(Token = "0x400F20C")]
			[FieldOffset(Offset = "0x20")]
			public UIEffectCapturedImage <>4__this;
		}
	}
}
