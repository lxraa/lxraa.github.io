﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x0200268D RID: 9869
	[Token(Token = "0x200268D")]
	public class UIShadow : BaseMeshEffect
	{
		// Token: 0x1700286A RID: 10346
		// (get) Token: 0x060132A7 RID: 78503 RVA: 0x0007B7E0 File Offset: 0x000799E0
		// (set) Token: 0x060132A8 RID: 78504 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700286A")]
		public Color effectColor
		{
			[Token(Token = "0x60132A7")]
			[Address(RVA = "0x24DE884", Offset = "0x24DE884", VA = "0x24DE884")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x60132A8")]
			[Address(RVA = "0x24DE890", Offset = "0x24DE890", VA = "0x24DE890")]
			set
			{
			}
		}

		// Token: 0x1700286B RID: 10347
		// (get) Token: 0x060132A9 RID: 78505 RVA: 0x0007B7F8 File Offset: 0x000799F8
		// (set) Token: 0x060132AA RID: 78506 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700286B")]
		public Vector2 effectDistance
		{
			[Token(Token = "0x60132A9")]
			[Address(RVA = "0x24DE974", Offset = "0x24DE974", VA = "0x24DE974")]
			get
			{
				return default(Vector2);
			}
			[Token(Token = "0x60132AA")]
			[Address(RVA = "0x24DE97C", Offset = "0x24DE97C", VA = "0x24DE97C")]
			set
			{
			}
		}

		// Token: 0x1700286C RID: 10348
		// (get) Token: 0x060132AB RID: 78507 RVA: 0x0007B810 File Offset: 0x00079A10
		// (set) Token: 0x060132AC RID: 78508 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700286C")]
		public bool useGraphicAlpha
		{
			[Token(Token = "0x60132AB")]
			[Address(RVA = "0x24DEA90", Offset = "0x24DEA90", VA = "0x24DEA90")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x60132AC")]
			[Address(RVA = "0x24DEA98", Offset = "0x24DEA98", VA = "0x24DEA98")]
			set
			{
			}
		}

		// Token: 0x1700286D RID: 10349
		// (get) Token: 0x060132AD RID: 78509 RVA: 0x0007B828 File Offset: 0x00079A28
		// (set) Token: 0x060132AE RID: 78510 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700286D")]
		[Obsolete("Use blurFactor instead (UnityUpgradable) -> blurFactor")]
		public float blur
		{
			[Token(Token = "0x60132AD")]
			[Address(RVA = "0x24DEB60", Offset = "0x24DEB60", VA = "0x24DEB60")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132AE")]
			[Address(RVA = "0x24DEB68", Offset = "0x24DEB68", VA = "0x24DEB68")]
			set
			{
			}
		}

		// Token: 0x1700286E RID: 10350
		// (get) Token: 0x060132AF RID: 78511 RVA: 0x0007B840 File Offset: 0x00079A40
		// (set) Token: 0x060132B0 RID: 78512 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700286E")]
		public float blurFactor
		{
			[Token(Token = "0x60132AF")]
			[Address(RVA = "0x24DEC34", Offset = "0x24DEC34", VA = "0x24DEC34")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x60132B0")]
			[Address(RVA = "0x24DEC3C", Offset = "0x24DEC3C", VA = "0x24DEC3C")]
			set
			{
			}
		}

		// Token: 0x1700286F RID: 10351
		// (get) Token: 0x060132B1 RID: 78513 RVA: 0x0007B858 File Offset: 0x00079A58
		// (set) Token: 0x060132B2 RID: 78514 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700286F")]
		public ShadowStyle style
		{
			[Token(Token = "0x60132B1")]
			[Address(RVA = "0x24DEC58", Offset = "0x24DEC58", VA = "0x24DEC58")]
			get
			{
				return ShadowStyle.None;
			}
			[Token(Token = "0x60132B2")]
			[Address(RVA = "0x24DEC60", Offset = "0x24DEC60", VA = "0x24DEC60")]
			set
			{
			}
		}

		// Token: 0x060132B3 RID: 78515 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132B3")]
		[Address(RVA = "0x24DEC68", Offset = "0x24DEC68", VA = "0x24DEC68", Slot = "5")]
		protected override void OnEnable()
		{
		}

		// Token: 0x060132B4 RID: 78516 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132B4")]
		[Address(RVA = "0x24DEC6C", Offset = "0x24DEC6C", VA = "0x24DEC6C", Slot = "7")]
		protected override void OnDisable()
		{
		}

		// Token: 0x060132B5 RID: 78517 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132B5")]
		[Address(RVA = "0x24DEC70", Offset = "0x24DEC70", VA = "0x24DEC70", Slot = "24")]
		public override void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x060132B6 RID: 78518 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132B6")]
		[Address(RVA = "0x24DF104", Offset = "0x24DF104", VA = "0x24DF104")]
		private void _ApplyShadow(List<UIVertex> verts, Color color, ref int start, ref int end, Vector2 effectDistance, ShadowStyle style, bool useGraphicAlpha)
		{
		}

		// Token: 0x060132B7 RID: 78519 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132B7")]
		[Address(RVA = "0x24DF4AC", Offset = "0x24DF4AC", VA = "0x24DF4AC")]
		private void _ApplyShadowZeroAlloc(List<UIVertex> verts, Color color, ref int start, ref int end, float x, float y, bool useGraphicAlpha)
		{
		}

		// Token: 0x060132B8 RID: 78520 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132B8")]
		[Address(RVA = "0x24DEB84", Offset = "0x24DEB84", VA = "0x24DEB84")]
		private void _SetDirty()
		{
		}

		// Token: 0x060132B9 RID: 78521 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132B9")]
		[Address(RVA = "0x24DFB20", Offset = "0x24DFB20", VA = "0x24DFB20")]
		public UIShadow()
		{
		}

		// Token: 0x0400F186 RID: 61830
		[Token(Token = "0x400F186")]
		[FieldOffset(Offset = "0x58")]
		[FormerlySerializedAs("m_Blur")]
		[SerializeField]
		private float m_BlurFactor;

		// Token: 0x0400F187 RID: 61831
		[Token(Token = "0x400F187")]
		[FieldOffset(Offset = "0x5C")]
		[SerializeField]
		private ShadowStyle m_Style;

		// Token: 0x0400F188 RID: 61832
		[Token(Token = "0x400F188")]
		[FieldOffset(Offset = "0x60")]
		[Obsolete]
		[SerializeField]
		private List<UIShadow.AdditionalShadow> m_AdditionalShadows;

		// Token: 0x0400F189 RID: 61833
		[Token(Token = "0x400F189")]
		[FieldOffset(Offset = "0x68")]
		[SerializeField]
		private Color m_EffectColor;

		// Token: 0x0400F18A RID: 61834
		[Token(Token = "0x400F18A")]
		[FieldOffset(Offset = "0x78")]
		[SerializeField]
		private Vector2 m_EffectDistance;

		// Token: 0x0400F18B RID: 61835
		[Token(Token = "0x400F18B")]
		[FieldOffset(Offset = "0x80")]
		[SerializeField]
		private bool m_UseGraphicAlpha;

		// Token: 0x0400F18C RID: 61836
		[Token(Token = "0x400F18C")]
		private const float kMaxEffectDistance = 600f;

		// Token: 0x0400F18D RID: 61837
		[Token(Token = "0x400F18D")]
		[FieldOffset(Offset = "0x84")]
		private int _graphicVertexCount;

		// Token: 0x0400F18E RID: 61838
		[Token(Token = "0x400F18E")]
		[FieldOffset(Offset = "0x0")]
		private static readonly List<UIShadow> tmpShadows;

		// Token: 0x0400F18F RID: 61839
		[Token(Token = "0x400F18F")]
		[FieldOffset(Offset = "0x8")]
		private static readonly List<UIVertex> s_Verts;

		// Token: 0x0200268E RID: 9870
		[Token(Token = "0x200268E")]
		[Obsolete]
		[Serializable]
		public class AdditionalShadow
		{
			// Token: 0x060132BB RID: 78523 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60132BB")]
			[Address(RVA = "0x16C6D60", Offset = "0x16C6D60", VA = "0x16C6D60")]
			public AdditionalShadow()
			{
			}

			// Token: 0x0400F190 RID: 61840
			[Token(Token = "0x400F190")]
			[FieldOffset(Offset = "0x10")]
			[FormerlySerializedAs("shadowBlur")]
			public float blur;

			// Token: 0x0400F191 RID: 61841
			[Token(Token = "0x400F191")]
			[FieldOffset(Offset = "0x14")]
			[FormerlySerializedAs("shadowMode")]
			public ShadowStyle style;

			// Token: 0x0400F192 RID: 61842
			[Token(Token = "0x400F192")]
			[FieldOffset(Offset = "0x18")]
			[FormerlySerializedAs("shadowColor")]
			public Color effectColor;

			// Token: 0x0400F193 RID: 61843
			[Token(Token = "0x400F193")]
			[FieldOffset(Offset = "0x28")]
			public Vector2 effectDistance;

			// Token: 0x0400F194 RID: 61844
			[Token(Token = "0x400F194")]
			[FieldOffset(Offset = "0x30")]
			public bool useGraphicAlpha;
		}
	}
}
