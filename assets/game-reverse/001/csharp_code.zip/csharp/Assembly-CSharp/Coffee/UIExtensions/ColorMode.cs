﻿using System;
using Il2CppDummyDll;

namespace Coffee.UIExtensions
{
	// Token: 0x02002693 RID: 9875
	[Token(Token = "0x2002693")]
	public enum ColorMode
	{
		// Token: 0x0400F1AD RID: 61869
		[Token(Token = "0x400F1AD")]
		Multiply,
		// Token: 0x0400F1AE RID: 61870
		[Token(Token = "0x400F1AE")]
		Fill,
		// Token: 0x0400F1AF RID: 61871
		[Token(Token = "0x400F1AF")]
		Add,
		// Token: 0x0400F1B0 RID: 61872
		[Token(Token = "0x400F1B0")]
		Subtract
	}
}
