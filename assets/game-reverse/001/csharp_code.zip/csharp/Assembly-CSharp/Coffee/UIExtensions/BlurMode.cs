﻿using System;
using Il2CppDummyDll;

namespace Coffee.UIExtensions
{
	// Token: 0x02002692 RID: 9874
	[Token(Token = "0x2002692")]
	public enum BlurMode
	{
		// Token: 0x0400F1A8 RID: 61864
		[Token(Token = "0x400F1A8")]
		None,
		// Token: 0x0400F1A9 RID: 61865
		[Token(Token = "0x400F1A9")]
		FastBlur,
		// Token: 0x0400F1AA RID: 61866
		[Token(Token = "0x400F1AA")]
		MediumBlur,
		// Token: 0x0400F1AB RID: 61867
		[Token(Token = "0x400F1AB")]
		DetailBlur
	}
}
