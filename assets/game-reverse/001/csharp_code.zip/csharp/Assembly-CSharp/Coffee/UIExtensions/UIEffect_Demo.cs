﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x02002690 RID: 9872
	[Token(Token = "0x2002690")]
	public class UIEffect_Demo : MonoBehaviour
	{
		// Token: 0x060132E6 RID: 78566 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132E6")]
		[Address(RVA = "0x16C8978", Offset = "0x16C8978", VA = "0x16C8978")]
		private void Start()
		{
		}

		// Token: 0x060132E7 RID: 78567 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132E7")]
		[Address(RVA = "0x16C89FC", Offset = "0x16C89FC", VA = "0x16C89FC")]
		public void SetTimeScale(float scale)
		{
		}

		// Token: 0x060132E8 RID: 78568 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132E8")]
		[Address(RVA = "0x16C8A04", Offset = "0x16C8A04", VA = "0x16C8A04")]
		public void Open(Animator anim)
		{
		}

		// Token: 0x060132E9 RID: 78569 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132E9")]
		[Address(RVA = "0x16C8E88", Offset = "0x16C8E88", VA = "0x16C8E88")]
		public void Close(Animator anim)
		{
		}

		// Token: 0x060132EA RID: 78570 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132EA")]
		[Address(RVA = "0x16C8EDC", Offset = "0x16C8EDC", VA = "0x16C8EDC")]
		public void Capture(Animator anim)
		{
		}

		// Token: 0x060132EB RID: 78571 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132EB")]
		[Address(RVA = "0x16C8F58", Offset = "0x16C8F58", VA = "0x16C8F58")]
		public void SetCanvasOverlay(bool isOverlay)
		{
		}

		// Token: 0x060132EC RID: 78572 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60132EC")]
		[Address(RVA = "0x16C8FC4", Offset = "0x16C8FC4", VA = "0x16C8FC4")]
		public UIEffect_Demo()
		{
		}

		// Token: 0x0400F1A5 RID: 61861
		[Token(Token = "0x400F1A5")]
		[FieldOffset(Offset = "0x18")]
		[SerializeField]
		private RectMask2D mask;
	}
}
