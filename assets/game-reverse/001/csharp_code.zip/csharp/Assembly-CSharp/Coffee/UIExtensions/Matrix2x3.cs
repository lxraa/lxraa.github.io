﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace Coffee.UIExtensions
{
	// Token: 0x02002698 RID: 9880
	[Token(Token = "0x2002698")]
	public struct Matrix2x3
	{
		// Token: 0x06013306 RID: 78598 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013306")]
		[Address(RVA = "0x16C8120", Offset = "0x16C8120", VA = "0x16C8120")]
		public Matrix2x3(Rect rect, float cos, float sin)
		{
		}

		// Token: 0x06013307 RID: 78599 RVA: 0x0007BA38 File Offset: 0x00079C38
		[Token(Token = "0x6013307")]
		[Address(RVA = "0x16C96C0", Offset = "0x16C96C0", VA = "0x16C96C0")]
		public static Vector2 operator *(Matrix2x3 m, Vector2 v)
		{
			return default(Vector2);
		}

		// Token: 0x0400F1C1 RID: 61889
		[Token(Token = "0x400F1C1")]
		[FieldOffset(Offset = "0x0")]
		public float m00;

		// Token: 0x0400F1C2 RID: 61890
		[Token(Token = "0x400F1C2")]
		[FieldOffset(Offset = "0x4")]
		public float m01;

		// Token: 0x0400F1C3 RID: 61891
		[Token(Token = "0x400F1C3")]
		[FieldOffset(Offset = "0x8")]
		public float m02;

		// Token: 0x0400F1C4 RID: 61892
		[Token(Token = "0x400F1C4")]
		[FieldOffset(Offset = "0xC")]
		public float m10;

		// Token: 0x0400F1C5 RID: 61893
		[Token(Token = "0x400F1C5")]
		[FieldOffset(Offset = "0x10")]
		public float m11;

		// Token: 0x0400F1C6 RID: 61894
		[Token(Token = "0x400F1C6")]
		[FieldOffset(Offset = "0x14")]
		public float m12;
	}
}
