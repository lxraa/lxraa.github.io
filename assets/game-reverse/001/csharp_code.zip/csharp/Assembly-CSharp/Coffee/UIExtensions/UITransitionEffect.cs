﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace Coffee.UIExtensions
{
	// Token: 0x020026A3 RID: 9891
	[Token(Token = "0x20026A3")]
	public class UITransitionEffect : UIEffectBase
	{
		// Token: 0x170028B3 RID: 10419
		// (get) Token: 0x0601337F RID: 78719 RVA: 0x0007BDC8 File Offset: 0x00079FC8
		// (set) Token: 0x06013380 RID: 78720 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028B3")]
		public float effectFactor
		{
			[Token(Token = "0x601337F")]
			[Address(RVA = "0x16CCA38", Offset = "0x16CCA38", VA = "0x16CCA38")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013380")]
			[Address(RVA = "0x16CCA40", Offset = "0x16CCA40", VA = "0x16CCA40")]
			set
			{
			}
		}

		// Token: 0x170028B4 RID: 10420
		// (get) Token: 0x06013381 RID: 78721 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06013382 RID: 78722 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028B4")]
		public Texture transitionTexture
		{
			[Token(Token = "0x6013381")]
			[Address(RVA = "0x16CCB08", Offset = "0x16CCB08", VA = "0x16CCB08")]
			get
			{
				return null;
			}
			[Token(Token = "0x6013382")]
			[Address(RVA = "0x16CCB10", Offset = "0x16CCB10", VA = "0x16CCB10")]
			set
			{
			}
		}

		// Token: 0x170028B5 RID: 10421
		// (get) Token: 0x06013383 RID: 78723 RVA: 0x0007BDE0 File Offset: 0x00079FE0
		[Token(Token = "0x170028B5")]
		public UITransitionEffect.EffectMode effectMode
		{
			[Token(Token = "0x6013383")]
			[Address(RVA = "0x16CCBEC", Offset = "0x16CCBEC", VA = "0x16CCBEC")]
			get
			{
				return (UITransitionEffect.EffectMode)0;
			}
		}

		// Token: 0x170028B6 RID: 10422
		// (get) Token: 0x06013384 RID: 78724 RVA: 0x0007BDF8 File Offset: 0x00079FF8
		// (set) Token: 0x06013385 RID: 78725 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028B6")]
		public bool keepAspectRatio
		{
			[Token(Token = "0x6013384")]
			[Address(RVA = "0x16CCBF4", Offset = "0x16CCBF4", VA = "0x16CCBF4")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6013385")]
			[Address(RVA = "0x16CCBFC", Offset = "0x16CCBFC", VA = "0x16CCBFC")]
			set
			{
			}
		}

		// Token: 0x170028B7 RID: 10423
		// (get) Token: 0x06013386 RID: 78726 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170028B7")]
		public override ParameterTexture ptex
		{
			[Token(Token = "0x6013386")]
			[Address(RVA = "0x16CCC40", Offset = "0x16CCC40", VA = "0x16CCC40", Slot = "31")]
			get
			{
				return null;
			}
		}

		// Token: 0x170028B8 RID: 10424
		// (get) Token: 0x06013387 RID: 78727 RVA: 0x0007BE10 File Offset: 0x0007A010
		// (set) Token: 0x06013388 RID: 78728 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028B8")]
		public float dissolveWidth
		{
			[Token(Token = "0x6013387")]
			[Address(RVA = "0x16CCC98", Offset = "0x16CCC98", VA = "0x16CCC98")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6013388")]
			[Address(RVA = "0x16CCCA0", Offset = "0x16CCCA0", VA = "0x16CCCA0")]
			set
			{
			}
		}

		// Token: 0x170028B9 RID: 10425
		// (get) Token: 0x06013389 RID: 78729 RVA: 0x0007BE28 File Offset: 0x0007A028
		// (set) Token: 0x0601338A RID: 78730 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028B9")]
		public float dissolveSoftness
		{
			[Token(Token = "0x6013389")]
			[Address(RVA = "0x16CCD68", Offset = "0x16CCD68", VA = "0x16CCD68")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x601338A")]
			[Address(RVA = "0x16CCD70", Offset = "0x16CCD70", VA = "0x16CCD70")]
			set
			{
			}
		}

		// Token: 0x170028BA RID: 10426
		// (get) Token: 0x0601338B RID: 78731 RVA: 0x0007BE40 File Offset: 0x0007A040
		// (set) Token: 0x0601338C RID: 78732 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028BA")]
		public Color dissolveColor
		{
			[Token(Token = "0x601338B")]
			[Address(RVA = "0x16CCE38", Offset = "0x16CCE38", VA = "0x16CCE38")]
			get
			{
				return default(Color);
			}
			[Token(Token = "0x601338C")]
			[Address(RVA = "0x16CCE44", Offset = "0x16CCE44", VA = "0x16CCE44")]
			set
			{
			}
		}

		// Token: 0x170028BB RID: 10427
		// (get) Token: 0x0601338D RID: 78733 RVA: 0x0007BE58 File Offset: 0x0007A058
		// (set) Token: 0x0601338E RID: 78734 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028BB")]
		public float duration
		{
			[Token(Token = "0x601338D")]
			[Address(RVA = "0x16CCEA4", Offset = "0x16CCEA4", VA = "0x16CCEA4")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x601338E")]
			[Address(RVA = "0x16CCF40", Offset = "0x16CCF40", VA = "0x16CCF40")]
			set
			{
			}
		}

		// Token: 0x170028BC RID: 10428
		// (get) Token: 0x0601338F RID: 78735 RVA: 0x0007BE70 File Offset: 0x0007A070
		// (set) Token: 0x06013390 RID: 78736 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028BC")]
		public bool passRayOnHidden
		{
			[Token(Token = "0x601338F")]
			[Address(RVA = "0x16CCF74", Offset = "0x16CCF74", VA = "0x16CCF74")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6013390")]
			[Address(RVA = "0x16CCF7C", Offset = "0x16CCF7C", VA = "0x16CCF7C")]
			set
			{
			}
		}

		// Token: 0x170028BD RID: 10429
		// (get) Token: 0x06013391 RID: 78737 RVA: 0x0007BE88 File Offset: 0x0007A088
		// (set) Token: 0x06013392 RID: 78738 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170028BD")]
		public AnimatorUpdateMode updateMode
		{
			[Token(Token = "0x6013391")]
			[Address(RVA = "0x16CCF88", Offset = "0x16CCF88", VA = "0x16CCF88")]
			get
			{
				return AnimatorUpdateMode.Normal;
			}
			[Token(Token = "0x6013392")]
			[Address(RVA = "0x16CCFA4", Offset = "0x16CCFA4", VA = "0x16CCFA4")]
			set
			{
			}
		}

		// Token: 0x06013393 RID: 78739 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013393")]
		[Address(RVA = "0x16CCFC4", Offset = "0x16CCFC4", VA = "0x16CCFC4")]
		public void Show()
		{
		}

		// Token: 0x06013394 RID: 78740 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013394")]
		[Address(RVA = "0x16CD078", Offset = "0x16CD078", VA = "0x16CD078")]
		public void Hide()
		{
		}

		// Token: 0x06013395 RID: 78741 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013395")]
		[Address(RVA = "0x16CD12C", Offset = "0x16CD12C", VA = "0x16CD12C", Slot = "32")]
		public override void ModifyMaterial()
		{
		}

		// Token: 0x06013396 RID: 78742 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013396")]
		[Address(RVA = "0x16CD3A0", Offset = "0x16CD3A0", VA = "0x16CD3A0", Slot = "24")]
		public override void ModifyMesh(VertexHelper vh)
		{
		}

		// Token: 0x06013397 RID: 78743 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013397")]
		[Address(RVA = "0x16CD6E0", Offset = "0x16CD6E0", VA = "0x16CD6E0", Slot = "5")]
		protected override void OnEnable()
		{
		}

		// Token: 0x06013398 RID: 78744 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013398")]
		[Address(RVA = "0x16CD71C", Offset = "0x16CD71C", VA = "0x16CD71C", Slot = "7")]
		protected override void OnDisable()
		{
		}

		// Token: 0x06013399 RID: 78745 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013399")]
		[Address(RVA = "0x16CD7AC", Offset = "0x16CD7AC", VA = "0x16CD7AC", Slot = "33")]
		protected override void SetDirty()
		{
		}

		// Token: 0x170028BE RID: 10430
		// (get) Token: 0x0601339A RID: 78746 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170028BE")]
		private EffectPlayer _player
		{
			[Token(Token = "0x601339A")]
			[Address(RVA = "0x16CCEC0", Offset = "0x16CCEC0", VA = "0x16CCEC0")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601339B RID: 78747 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601339B")]
		[Address(RVA = "0x16CDA3C", Offset = "0x16CDA3C", VA = "0x16CDA3C")]
		public UITransitionEffect()
		{
		}

		// Token: 0x0601339D RID: 78749 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601339D")]
		[Address(RVA = "0x16CDB50", Offset = "0x16CDB50", VA = "0x16CDB50")]
		private void <Show>b__44_0(float f)
		{
		}

		// Token: 0x0601339E RID: 78750 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601339E")]
		[Address(RVA = "0x16CDB54", Offset = "0x16CDB54", VA = "0x16CDB54")]
		private void <Hide>b__45_0(float f)
		{
		}

		// Token: 0x0601339F RID: 78751 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601339F")]
		[Address(RVA = "0x16CDB60", Offset = "0x16CDB60", VA = "0x16CDB60")]
		private Material <ModifyMaterial>b__46_0()
		{
			return null;
		}

		// Token: 0x0400F214 RID: 61972
		[Token(Token = "0x400F214")]
		public const string shaderName = "UI/Hidden/UI-Effect-Transition";

		// Token: 0x0400F215 RID: 61973
		[Token(Token = "0x400F215")]
		[FieldOffset(Offset = "0x0")]
		private static readonly ParameterTexture _ptex;

		// Token: 0x0400F216 RID: 61974
		[Token(Token = "0x400F216")]
		[FieldOffset(Offset = "0x6C")]
		[SerializeField]
		private UITransitionEffect.EffectMode m_EffectMode;

		// Token: 0x0400F217 RID: 61975
		[Token(Token = "0x400F217")]
		[FieldOffset(Offset = "0x70")]
		[SerializeField]
		private float m_EffectFactor;

		// Token: 0x0400F218 RID: 61976
		[Token(Token = "0x400F218")]
		[FieldOffset(Offset = "0x78")]
		[SerializeField]
		private Texture m_TransitionTexture;

		// Token: 0x0400F219 RID: 61977
		[Token(Token = "0x400F219")]
		[FieldOffset(Offset = "0x80")]
		[SerializeField]
		private EffectArea m_EffectArea;

		// Token: 0x0400F21A RID: 61978
		[Token(Token = "0x400F21A")]
		[FieldOffset(Offset = "0x84")]
		[SerializeField]
		private bool m_KeepAspectRatio;

		// Token: 0x0400F21B RID: 61979
		[Token(Token = "0x400F21B")]
		[FieldOffset(Offset = "0x88")]
		[SerializeField]
		private float m_DissolveWidth;

		// Token: 0x0400F21C RID: 61980
		[Token(Token = "0x400F21C")]
		[FieldOffset(Offset = "0x8C")]
		[SerializeField]
		private float m_DissolveSoftness;

		// Token: 0x0400F21D RID: 61981
		[Token(Token = "0x400F21D")]
		[FieldOffset(Offset = "0x90")]
		[SerializeField]
		private Color m_DissolveColor;

		// Token: 0x0400F21E RID: 61982
		[Token(Token = "0x400F21E")]
		[FieldOffset(Offset = "0xA0")]
		[SerializeField]
		private bool m_PassRayOnHidden;

		// Token: 0x0400F21F RID: 61983
		[Token(Token = "0x400F21F")]
		[FieldOffset(Offset = "0xA8")]
		[SerializeField]
		private EffectPlayer m_Player;

		// Token: 0x0400F220 RID: 61984
		[Token(Token = "0x400F220")]
		[FieldOffset(Offset = "0xB0")]
		private MaterialCache _materialCache;

		// Token: 0x020026A4 RID: 9892
		[Token(Token = "0x20026A4")]
		public enum EffectMode
		{
			// Token: 0x0400F222 RID: 61986
			[Token(Token = "0x400F222")]
			Fade = 1,
			// Token: 0x0400F223 RID: 61987
			[Token(Token = "0x400F223")]
			Cutoff,
			// Token: 0x0400F224 RID: 61988
			[Token(Token = "0x400F224")]
			Dissolve
		}
	}
}
