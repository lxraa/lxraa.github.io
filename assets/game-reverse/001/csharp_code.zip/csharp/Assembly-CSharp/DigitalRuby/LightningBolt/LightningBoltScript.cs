﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace DigitalRuby.LightningBolt
{
	// Token: 0x020025C9 RID: 9673
	[Token(Token = "0x20025C9")]
	[RequireComponent(typeof(LineRenderer))]
	public class LightningBoltScript : MonoBehaviour
	{
		// Token: 0x06012EC5 RID: 77509 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC5")]
		[Address(RVA = "0x2450484", Offset = "0x2450484", VA = "0x2450484")]
		private void GetPerpendicularVector(ref Vector3 directionNormalized, out Vector3 side)
		{
		}

		// Token: 0x06012EC6 RID: 77510 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC6")]
		[Address(RVA = "0x2450670", Offset = "0x2450670", VA = "0x2450670")]
		private void GenerateLightningBolt(Vector3 start, Vector3 end, int generation, int totalGenerations, float offsetAmount)
		{
		}

		// Token: 0x06012EC7 RID: 77511 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC7")]
		[Address(RVA = "0x2450B44", Offset = "0x2450B44", VA = "0x2450B44")]
		public void RandomVector(ref Vector3 start, ref Vector3 end, float offsetAmount, out Vector3 result)
		{
		}

		// Token: 0x06012EC8 RID: 77512 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC8")]
		[Address(RVA = "0x2450D3C", Offset = "0x2450D3C", VA = "0x2450D3C")]
		private void SelectOffsetFromAnimationMode()
		{
		}

		// Token: 0x06012EC9 RID: 77513 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC9")]
		[Address(RVA = "0x2450E94", Offset = "0x2450E94", VA = "0x2450E94")]
		private void UpdateLineRenderer()
		{
		}

		// Token: 0x06012ECA RID: 77514 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ECA")]
		[Address(RVA = "0x2451000", Offset = "0x2451000", VA = "0x2451000")]
		private void Start()
		{
		}

		// Token: 0x06012ECB RID: 77515 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ECB")]
		[Address(RVA = "0x2451230", Offset = "0x2451230", VA = "0x2451230")]
		private void Update()
		{
		}

		// Token: 0x06012ECC RID: 77516 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ECC")]
		[Address(RVA = "0x245132C", Offset = "0x245132C", VA = "0x245132C")]
		public void Trigger()
		{
		}

		// Token: 0x06012ECD RID: 77517 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ECD")]
		[Address(RVA = "0x24510FC", Offset = "0x24510FC", VA = "0x24510FC")]
		public void UpdateFromMaterialChange()
		{
		}

		// Token: 0x06012ECE RID: 77518 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ECE")]
		[Address(RVA = "0x245149C", Offset = "0x245149C", VA = "0x245149C")]
		public LightningBoltScript()
		{
		}

		// Token: 0x0400EECB RID: 61131
		[Token(Token = "0x400EECB")]
		[FieldOffset(Offset = "0x18")]
		public GameObject StartObject;

		// Token: 0x0400EECC RID: 61132
		[Token(Token = "0x400EECC")]
		[FieldOffset(Offset = "0x20")]
		public Vector3 StartPosition;

		// Token: 0x0400EECD RID: 61133
		[Token(Token = "0x400EECD")]
		[FieldOffset(Offset = "0x30")]
		public GameObject EndObject;

		// Token: 0x0400EECE RID: 61134
		[Token(Token = "0x400EECE")]
		[FieldOffset(Offset = "0x38")]
		public Vector3 EndPosition;

		// Token: 0x0400EECF RID: 61135
		[Token(Token = "0x400EECF")]
		[FieldOffset(Offset = "0x44")]
		public int Generations;

		// Token: 0x0400EED0 RID: 61136
		[Token(Token = "0x400EED0")]
		[FieldOffset(Offset = "0x48")]
		public float Duration;

		// Token: 0x0400EED1 RID: 61137
		[Token(Token = "0x400EED1")]
		[FieldOffset(Offset = "0x4C")]
		private float timer;

		// Token: 0x0400EED2 RID: 61138
		[Token(Token = "0x400EED2")]
		[FieldOffset(Offset = "0x50")]
		public float ChaosFactor;

		// Token: 0x0400EED3 RID: 61139
		[Token(Token = "0x400EED3")]
		[FieldOffset(Offset = "0x54")]
		public bool ManualMode;

		// Token: 0x0400EED4 RID: 61140
		[Token(Token = "0x400EED4")]
		[FieldOffset(Offset = "0x58")]
		public int Rows;

		// Token: 0x0400EED5 RID: 61141
		[Token(Token = "0x400EED5")]
		[FieldOffset(Offset = "0x5C")]
		public int Columns;

		// Token: 0x0400EED6 RID: 61142
		[Token(Token = "0x400EED6")]
		[FieldOffset(Offset = "0x60")]
		public LightningBoltAnimationMode AnimationMode;

		// Token: 0x0400EED7 RID: 61143
		[Token(Token = "0x400EED7")]
		[FieldOffset(Offset = "0x68")]
		[NonSerialized]
		public System.Random RandomGenerator;

		// Token: 0x0400EED8 RID: 61144
		[Token(Token = "0x400EED8")]
		[FieldOffset(Offset = "0x70")]
		private LineRenderer lineRenderer;

		// Token: 0x0400EED9 RID: 61145
		[Token(Token = "0x400EED9")]
		[FieldOffset(Offset = "0x78")]
		private List<KeyValuePair<Vector3, Vector3>> segments;

		// Token: 0x0400EEDA RID: 61146
		[Token(Token = "0x400EEDA")]
		[FieldOffset(Offset = "0x80")]
		private int startIndex;

		// Token: 0x0400EEDB RID: 61147
		[Token(Token = "0x400EEDB")]
		[FieldOffset(Offset = "0x84")]
		private Vector2 size;

		// Token: 0x0400EEDC RID: 61148
		[Token(Token = "0x400EEDC")]
		[FieldOffset(Offset = "0x90")]
		private Vector2[] offsets;

		// Token: 0x0400EEDD RID: 61149
		[Token(Token = "0x400EEDD")]
		[FieldOffset(Offset = "0x98")]
		private int animationOffsetIndex;

		// Token: 0x0400EEDE RID: 61150
		[Token(Token = "0x400EEDE")]
		[FieldOffset(Offset = "0x9C")]
		private int animationPingPongDirection;

		// Token: 0x0400EEDF RID: 61151
		[Token(Token = "0x400EEDF")]
		[FieldOffset(Offset = "0xA0")]
		private bool orthographic;

		// Token: 0x0400EEE0 RID: 61152
		[Token(Token = "0x400EEE0")]
		[FieldOffset(Offset = "0xA1")]
		public bool didStart;
	}
}
