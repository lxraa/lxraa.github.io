﻿using System;
using Il2CppDummyDll;

namespace DigitalRuby.LightningBolt
{
	// Token: 0x020025C8 RID: 9672
	[Token(Token = "0x20025C8")]
	public enum LightningBoltAnimationMode
	{
		// Token: 0x0400EEC7 RID: 61127
		[Token(Token = "0x400EEC7")]
		None,
		// Token: 0x0400EEC8 RID: 61128
		[Token(Token = "0x400EEC8")]
		Random,
		// Token: 0x0400EEC9 RID: 61129
		[Token(Token = "0x400EEC9")]
		Loop,
		// Token: 0x0400EECA RID: 61130
		[Token(Token = "0x400EECA")]
		PingPong
	}
}
