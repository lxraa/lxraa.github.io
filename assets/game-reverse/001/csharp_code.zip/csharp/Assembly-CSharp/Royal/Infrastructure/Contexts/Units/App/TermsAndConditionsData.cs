﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025BC RID: 9660
	[Token(Token = "0x20025BC")]
	public class TermsAndConditionsData
	{
		// Token: 0x06012E55 RID: 77397 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E55")]
		[Address(RVA = "0x244A30C", Offset = "0x244A30C", VA = "0x244A30C")]
		public TermsAndConditionsData()
		{
		}

		// Token: 0x0400EE85 RID: 61061
		[Token(Token = "0x400EE85")]
		[FieldOffset(Offset = "0x10")]
		public string button_text;

		// Token: 0x0400EE86 RID: 61062
		[Token(Token = "0x400EE86")]
		[FieldOffset(Offset = "0x18")]
		public string body;

		// Token: 0x0400EE87 RID: 61063
		[Token(Token = "0x400EE87")]
		[FieldOffset(Offset = "0x20")]
		public string title;

		// Token: 0x0400EE88 RID: 61064
		[Token(Token = "0x400EE88")]
		[FieldOffset(Offset = "0x28")]
		public string terms_text;

		// Token: 0x0400EE89 RID: 61065
		[Token(Token = "0x400EE89")]
		[FieldOffset(Offset = "0x30")]
		public string privacy_text;
	}
}
