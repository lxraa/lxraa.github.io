﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002368 RID: 9064
	[Token(Token = "0x2002368")]
	public struct ClientSettings : IFlatbufferObject
	{
		// Token: 0x17001F55 RID: 8021
		// (get) Token: 0x06010DA8 RID: 69032 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F55")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010DA8")]
			[Address(RVA = "0x214AD44", Offset = "0x214AD44", VA = "0x214AD44", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010DA9 RID: 69033 RVA: 0x00061A58 File Offset: 0x0005FC58
		[Token(Token = "0x6010DA9")]
		[Address(RVA = "0x214AD4C", Offset = "0x214AD4C", VA = "0x214AD4C")]
		public static ClientSettings GetRootAsClientSettings(ByteBuffer _bb)
		{
			return default(ClientSettings);
		}

		// Token: 0x06010DAA RID: 69034 RVA: 0x00061A70 File Offset: 0x0005FC70
		[Token(Token = "0x6010DAA")]
		[Address(RVA = "0x214AD58", Offset = "0x214AD58", VA = "0x214AD58")]
		public static ClientSettings GetRootAsClientSettings(ByteBuffer _bb, ClientSettings obj)
		{
			return default(ClientSettings);
		}

		// Token: 0x06010DAB RID: 69035 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DAB")]
		[Address(RVA = "0x214AE08", Offset = "0x214AE08", VA = "0x214AE08", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010DAC RID: 69036 RVA: 0x00061A88 File Offset: 0x0005FC88
		[Token(Token = "0x6010DAC")]
		[Address(RVA = "0x214ADD0", Offset = "0x214ADD0", VA = "0x214ADD0")]
		public ClientSettings __assign(int _i, ByteBuffer _bb)
		{
			return default(ClientSettings);
		}

		// Token: 0x17001F56 RID: 8022
		// (get) Token: 0x06010DAD RID: 69037 RVA: 0x00061AA0 File Offset: 0x0005FCA0
		[Token(Token = "0x17001F56")]
		public bool DeprecatedNetworkMetricsEnabled
		{
			[Token(Token = "0x6010DAD")]
			[Address(RVA = "0x214AE18", Offset = "0x214AE18", VA = "0x214AE18")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F57 RID: 8023
		// (get) Token: 0x06010DAE RID: 69038 RVA: 0x00061AB8 File Offset: 0x0005FCB8
		[Token(Token = "0x17001F57")]
		public bool HttpClientEnabledCustomDevice
		{
			[Token(Token = "0x6010DAE")]
			[Address(RVA = "0x214AE60", Offset = "0x214AE60", VA = "0x214AE60")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F58 RID: 8024
		// (get) Token: 0x06010DAF RID: 69039 RVA: 0x00061AD0 File Offset: 0x0005FCD0
		[Token(Token = "0x17001F58")]
		public bool HttpClientEnabledLowEndDevice
		{
			[Token(Token = "0x6010DAF")]
			[Address(RVA = "0x214AEA8", Offset = "0x214AEA8", VA = "0x214AEA8")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F59 RID: 8025
		// (get) Token: 0x06010DB0 RID: 69040 RVA: 0x00061AE8 File Offset: 0x0005FCE8
		[Token(Token = "0x17001F59")]
		public bool CommandsWebclientEnabled
		{
			[Token(Token = "0x6010DB0")]
			[Address(RVA = "0x214AEF0", Offset = "0x214AEF0", VA = "0x214AEF0")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F5A RID: 8026
		// (get) Token: 0x06010DB1 RID: 69041 RVA: 0x00061B00 File Offset: 0x0005FD00
		[Token(Token = "0x17001F5A")]
		public bool MaintenanceWebclientEnabled
		{
			[Token(Token = "0x6010DB1")]
			[Address(RVA = "0x214AF38", Offset = "0x214AF38", VA = "0x214AF38")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F5B RID: 8027
		// (get) Token: 0x06010DB2 RID: 69042 RVA: 0x00061B18 File Offset: 0x0005FD18
		[Token(Token = "0x17001F5B")]
		public bool SplashRemoteLevelWebclientEnabled
		{
			[Token(Token = "0x6010DB2")]
			[Address(RVA = "0x214AF80", Offset = "0x214AF80", VA = "0x214AF80")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F5C RID: 8028
		// (get) Token: 0x06010DB3 RID: 69043 RVA: 0x00061B30 File Offset: 0x0005FD30
		[Token(Token = "0x17001F5C")]
		public bool FileDownloaderSingleThreadEnabled
		{
			[Token(Token = "0x6010DB3")]
			[Address(RVA = "0x214AFC8", Offset = "0x214AFC8", VA = "0x214AFC8")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F5D RID: 8029
		// (get) Token: 0x06010DB4 RID: 69044 RVA: 0x00061B48 File Offset: 0x0005FD48
		[Token(Token = "0x17001F5D")]
		public bool BestHttpCacheEnabled
		{
			[Token(Token = "0x6010DB4")]
			[Address(RVA = "0x214B010", Offset = "0x214B010", VA = "0x214B010")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F5E RID: 8030
		// (get) Token: 0x06010DB5 RID: 69045 RVA: 0x00061B60 File Offset: 0x0005FD60
		[Token(Token = "0x17001F5E")]
		public bool DownloadSchedulingDisabled
		{
			[Token(Token = "0x6010DB5")]
			[Address(RVA = "0x214B058", Offset = "0x214B058", VA = "0x214B058")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F5F RID: 8031
		// (get) Token: 0x06010DB6 RID: 69046 RVA: 0x00061B78 File Offset: 0x0005FD78
		[Token(Token = "0x17001F5F")]
		public bool UnityWebRequestEnabled
		{
			[Token(Token = "0x6010DB6")]
			[Address(RVA = "0x214B0A0", Offset = "0x214B0A0", VA = "0x214B0A0")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F60 RID: 8032
		// (get) Token: 0x06010DB7 RID: 69047 RVA: 0x00061B90 File Offset: 0x0005FD90
		[Token(Token = "0x17001F60")]
		public bool LogUploadInThreadEnabled
		{
			[Token(Token = "0x6010DB7")]
			[Address(RVA = "0x214B0E8", Offset = "0x214B0E8", VA = "0x214B0E8")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F61 RID: 8033
		// (get) Token: 0x06010DB8 RID: 69048 RVA: 0x00061BA8 File Offset: 0x0005FDA8
		[Token(Token = "0x17001F61")]
		public bool MuteDetectionEnabled
		{
			[Token(Token = "0x6010DB8")]
			[Address(RVA = "0x214B130", Offset = "0x214B130", VA = "0x214B130")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F62 RID: 8034
		// (get) Token: 0x06010DB9 RID: 69049 RVA: 0x00061BC0 File Offset: 0x0005FDC0
		[Token(Token = "0x17001F62")]
		public bool IosUnityWebRequestEnabled
		{
			[Token(Token = "0x6010DB9")]
			[Address(RVA = "0x214B178", Offset = "0x214B178", VA = "0x214B178")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F63 RID: 8035
		// (get) Token: 0x06010DBA RID: 69050 RVA: 0x00061BD8 File Offset: 0x0005FDD8
		[Token(Token = "0x17001F63")]
		public bool LevelStartEndImprovementsEnabled
		{
			[Token(Token = "0x6010DBA")]
			[Address(RVA = "0x214B1C0", Offset = "0x214B1C0", VA = "0x214B1C0")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F64 RID: 8036
		// (get) Token: 0x06010DBB RID: 69051 RVA: 0x00061BF0 File Offset: 0x0005FDF0
		[Token(Token = "0x17001F64")]
		public bool RefreshRateFixEnabled
		{
			[Token(Token = "0x6010DBB")]
			[Address(RVA = "0x214B208", Offset = "0x214B208", VA = "0x214B208")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F65 RID: 8037
		// (get) Token: 0x06010DBC RID: 69052 RVA: 0x00061C08 File Offset: 0x0005FE08
		[Token(Token = "0x17001F65")]
		public int TermsAndConditionsVersion
		{
			[Token(Token = "0x6010DBC")]
			[Address(RVA = "0x214B250", Offset = "0x214B250", VA = "0x214B250")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F66 RID: 8038
		// (get) Token: 0x06010DBD RID: 69053 RVA: 0x00061C20 File Offset: 0x0005FE20
		[Token(Token = "0x17001F66")]
		public bool AppCheckEnabled
		{
			[Token(Token = "0x6010DBD")]
			[Address(RVA = "0x214B294", Offset = "0x214B294", VA = "0x214B294")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F67 RID: 8039
		// (get) Token: 0x06010DBE RID: 69054 RVA: 0x00061C38 File Offset: 0x0005FE38
		[Token(Token = "0x17001F67")]
		public sbyte SendFullKeyValueVersion
		{
			[Token(Token = "0x6010DBE")]
			[Address(RVA = "0x214B2DC", Offset = "0x214B2DC", VA = "0x214B2DC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F68 RID: 8040
		// (get) Token: 0x06010DBF RID: 69055 RVA: 0x00061C50 File Offset: 0x0005FE50
		[Token(Token = "0x17001F68")]
		public bool AnalyticsBlockDisabled
		{
			[Token(Token = "0x6010DBF")]
			[Address(RVA = "0x214B320", Offset = "0x214B320", VA = "0x214B320")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F69 RID: 8041
		// (get) Token: 0x06010DC0 RID: 69056 RVA: 0x00061C68 File Offset: 0x0005FE68
		[Token(Token = "0x17001F69")]
		public bool ConcurrentDlrUpdateScoreLogEnabled
		{
			[Token(Token = "0x6010DC0")]
			[Address(RVA = "0x214B368", Offset = "0x214B368", VA = "0x214B368")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F6A RID: 8042
		// (get) Token: 0x06010DC1 RID: 69057 RVA: 0x00061C80 File Offset: 0x0005FE80
		[Token(Token = "0x17001F6A")]
		public sbyte NetworkMetricsEnabledFlag
		{
			[Token(Token = "0x6010DC1")]
			[Address(RVA = "0x214B3B0", Offset = "0x214B3B0", VA = "0x214B3B0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F6B RID: 8043
		// (get) Token: 0x06010DC2 RID: 69058 RVA: 0x00061C98 File Offset: 0x0005FE98
		[Token(Token = "0x17001F6B")]
		public bool RequestResponseLoggingEnabled
		{
			[Token(Token = "0x6010DC2")]
			[Address(RVA = "0x214B3F4", Offset = "0x214B3F4", VA = "0x214B3F4")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06010DC3 RID: 69059 RVA: 0x00061CB0 File Offset: 0x0005FEB0
		[Token(Token = "0x6010DC3")]
		[Address(RVA = "0x214B43C", Offset = "0x214B43C", VA = "0x214B43C")]
		public static Offset<ClientSettings> CreateClientSettings(FlatBufferBuilder builder, bool deprecated_network_metrics_enabled = false, bool http_client_enabled_custom_device = false, bool http_client_enabled_low_end_device = false, bool commands_webclient_enabled = false, bool maintenance_webclient_enabled = false, bool splash_remote_level_webclient_enabled = false, bool file_downloader_single_thread_enabled = false, bool best_http_cache_enabled = false, bool download_scheduling_disabled = false, bool unity_web_request_enabled = false, bool log_upload_in_thread_enabled = false, bool mute_detection_enabled = false, bool ios_unity_web_request_enabled = false, bool level_start_end_improvements_enabled = false, bool refresh_rate_fix_enabled = false, int terms_and_conditions_version = 0, bool app_check_enabled = false, sbyte send_full_key_value_version = 0, bool analytics_block_disabled = false, bool concurrent_dlr_update_score_log_enabled = false, sbyte network_metrics_enabled_flag = 0, bool request_response_logging_enabled = false)
		{
			return default(Offset<ClientSettings>);
		}

		// Token: 0x06010DC4 RID: 69060 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DC4")]
		[Address(RVA = "0x214B960", Offset = "0x214B960", VA = "0x214B960")]
		public static void StartClientSettings(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010DC5 RID: 69061 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DC5")]
		[Address(RVA = "0x214B8D4", Offset = "0x214B8D4", VA = "0x214B8D4")]
		public static void AddDeprecatedNetworkMetricsEnabled(FlatBufferBuilder builder, bool deprecatedNetworkMetricsEnabled)
		{
		}

		// Token: 0x06010DC6 RID: 69062 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DC6")]
		[Address(RVA = "0x214B8B4", Offset = "0x214B8B4", VA = "0x214B8B4")]
		public static void AddHttpClientEnabledCustomDevice(FlatBufferBuilder builder, bool httpClientEnabledCustomDevice)
		{
		}

		// Token: 0x06010DC7 RID: 69063 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DC7")]
		[Address(RVA = "0x214B894", Offset = "0x214B894", VA = "0x214B894")]
		public static void AddHttpClientEnabledLowEndDevice(FlatBufferBuilder builder, bool httpClientEnabledLowEndDevice)
		{
		}

		// Token: 0x06010DC8 RID: 69064 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DC8")]
		[Address(RVA = "0x214B874", Offset = "0x214B874", VA = "0x214B874")]
		public static void AddCommandsWebclientEnabled(FlatBufferBuilder builder, bool commandsWebclientEnabled)
		{
		}

		// Token: 0x06010DC9 RID: 69065 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DC9")]
		[Address(RVA = "0x214B854", Offset = "0x214B854", VA = "0x214B854")]
		public static void AddMaintenanceWebclientEnabled(FlatBufferBuilder builder, bool maintenanceWebclientEnabled)
		{
		}

		// Token: 0x06010DCA RID: 69066 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DCA")]
		[Address(RVA = "0x214B834", Offset = "0x214B834", VA = "0x214B834")]
		public static void AddSplashRemoteLevelWebclientEnabled(FlatBufferBuilder builder, bool splashRemoteLevelWebclientEnabled)
		{
		}

		// Token: 0x06010DCB RID: 69067 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DCB")]
		[Address(RVA = "0x214B814", Offset = "0x214B814", VA = "0x214B814")]
		public static void AddFileDownloaderSingleThreadEnabled(FlatBufferBuilder builder, bool fileDownloaderSingleThreadEnabled)
		{
		}

		// Token: 0x06010DCC RID: 69068 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DCC")]
		[Address(RVA = "0x214B7F4", Offset = "0x214B7F4", VA = "0x214B7F4")]
		public static void AddBestHttpCacheEnabled(FlatBufferBuilder builder, bool bestHttpCacheEnabled)
		{
		}

		// Token: 0x06010DCD RID: 69069 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DCD")]
		[Address(RVA = "0x214B7D4", Offset = "0x214B7D4", VA = "0x214B7D4")]
		public static void AddDownloadSchedulingDisabled(FlatBufferBuilder builder, bool downloadSchedulingDisabled)
		{
		}

		// Token: 0x06010DCE RID: 69070 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DCE")]
		[Address(RVA = "0x214B7B4", Offset = "0x214B7B4", VA = "0x214B7B4")]
		public static void AddUnityWebRequestEnabled(FlatBufferBuilder builder, bool unityWebRequestEnabled)
		{
		}

		// Token: 0x06010DCF RID: 69071 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DCF")]
		[Address(RVA = "0x214B794", Offset = "0x214B794", VA = "0x214B794")]
		public static void AddLogUploadInThreadEnabled(FlatBufferBuilder builder, bool logUploadInThreadEnabled)
		{
		}

		// Token: 0x06010DD0 RID: 69072 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD0")]
		[Address(RVA = "0x214B774", Offset = "0x214B774", VA = "0x214B774")]
		public static void AddMuteDetectionEnabled(FlatBufferBuilder builder, bool muteDetectionEnabled)
		{
		}

		// Token: 0x06010DD1 RID: 69073 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD1")]
		[Address(RVA = "0x214B754", Offset = "0x214B754", VA = "0x214B754")]
		public static void AddIosUnityWebRequestEnabled(FlatBufferBuilder builder, bool iosUnityWebRequestEnabled)
		{
		}

		// Token: 0x06010DD2 RID: 69074 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD2")]
		[Address(RVA = "0x214B734", Offset = "0x214B734", VA = "0x214B734")]
		public static void AddLevelStartEndImprovementsEnabled(FlatBufferBuilder builder, bool levelStartEndImprovementsEnabled)
		{
		}

		// Token: 0x06010DD3 RID: 69075 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD3")]
		[Address(RVA = "0x214B714", Offset = "0x214B714", VA = "0x214B714")]
		public static void AddRefreshRateFixEnabled(FlatBufferBuilder builder, bool refreshRateFixEnabled)
		{
		}

		// Token: 0x06010DD4 RID: 69076 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD4")]
		[Address(RVA = "0x214B634", Offset = "0x214B634", VA = "0x214B634")]
		public static void AddTermsAndConditionsVersion(FlatBufferBuilder builder, int termsAndConditionsVersion)
		{
		}

		// Token: 0x06010DD5 RID: 69077 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD5")]
		[Address(RVA = "0x214B6F4", Offset = "0x214B6F4", VA = "0x214B6F4")]
		public static void AddAppCheckEnabled(FlatBufferBuilder builder, bool appCheckEnabled)
		{
		}

		// Token: 0x06010DD6 RID: 69078 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD6")]
		[Address(RVA = "0x214B6D4", Offset = "0x214B6D4", VA = "0x214B6D4")]
		public static void AddSendFullKeyValueVersion(FlatBufferBuilder builder, sbyte sendFullKeyValueVersion)
		{
		}

		// Token: 0x06010DD7 RID: 69079 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD7")]
		[Address(RVA = "0x214B6B4", Offset = "0x214B6B4", VA = "0x214B6B4")]
		public static void AddAnalyticsBlockDisabled(FlatBufferBuilder builder, bool analyticsBlockDisabled)
		{
		}

		// Token: 0x06010DD8 RID: 69080 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD8")]
		[Address(RVA = "0x214B694", Offset = "0x214B694", VA = "0x214B694")]
		public static void AddConcurrentDlrUpdateScoreLogEnabled(FlatBufferBuilder builder, bool concurrentDlrUpdateScoreLogEnabled)
		{
		}

		// Token: 0x06010DD9 RID: 69081 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DD9")]
		[Address(RVA = "0x214B674", Offset = "0x214B674", VA = "0x214B674")]
		public static void AddNetworkMetricsEnabledFlag(FlatBufferBuilder builder, sbyte networkMetricsEnabledFlag)
		{
		}

		// Token: 0x06010DDA RID: 69082 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DDA")]
		[Address(RVA = "0x214B654", Offset = "0x214B654", VA = "0x214B654")]
		public static void AddRequestResponseLoggingEnabled(FlatBufferBuilder builder, bool requestResponseLoggingEnabled)
		{
		}

		// Token: 0x06010DDB RID: 69083 RVA: 0x00061CC8 File Offset: 0x0005FEC8
		[Token(Token = "0x6010DDB")]
		[Address(RVA = "0x214B8F4", Offset = "0x214B8F4", VA = "0x214B8F4")]
		public static Offset<ClientSettings> EndClientSettings(FlatBufferBuilder builder)
		{
			return default(Offset<ClientSettings>);
		}

		// Token: 0x06010DDC RID: 69084 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DDC")]
		[Address(RVA = "0x214B978", Offset = "0x214B978", VA = "0x214B978")]
		public static void FinishClientSettingsBuffer(FlatBufferBuilder builder, Offset<ClientSettings> offset)
		{
		}

		// Token: 0x06010DDD RID: 69085 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DDD")]
		[Address(RVA = "0x214B98C", Offset = "0x214B98C", VA = "0x214B98C")]
		public static void FinishSizePrefixedClientSettingsBuffer(FlatBufferBuilder builder, Offset<ClientSettings> offset)
		{
		}

		// Token: 0x0400E66E RID: 58990
		[Token(Token = "0x400E66E")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
