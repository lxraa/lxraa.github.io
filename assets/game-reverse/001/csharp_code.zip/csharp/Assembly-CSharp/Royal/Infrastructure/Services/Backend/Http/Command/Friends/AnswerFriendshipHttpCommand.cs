﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Friends
{
	// Token: 0x02002566 RID: 9574
	[Token(Token = "0x2002566")]
	public class AnswerFriendshipHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002798 RID: 10136
		// (get) Token: 0x06012B5A RID: 76634 RVA: 0x00078FA8 File Offset: 0x000771A8
		[Token(Token = "0x17002798")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B5A")]
			[Address(RVA = "0x1ED17F0", Offset = "0x1ED17F0", VA = "0x1ED17F0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002799 RID: 10137
		// (get) Token: 0x06012B5B RID: 76635 RVA: 0x00078FC0 File Offset: 0x000771C0
		[Token(Token = "0x17002799")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B5B")]
			[Address(RVA = "0x1ED17F8", Offset = "0x1ED17F8", VA = "0x1ED17F8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B5C RID: 76636 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B5C")]
		[Address(RVA = "0x1ED1800", Offset = "0x1ED1800", VA = "0x1ED1800")]
		public AnswerFriendshipHttpCommand(long userId, bool isApproved, Action<bool> onCompleted)
		{
		}

		// Token: 0x06012B5D RID: 76637 RVA: 0x00078FD8 File Offset: 0x000771D8
		[Token(Token = "0x6012B5D")]
		[Address(RVA = "0x1ED184C", Offset = "0x1ED184C", VA = "0x1ED184C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B5E RID: 76638 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B5E")]
		[Address(RVA = "0x1ED1870", Offset = "0x1ED1870", VA = "0x1ED1870", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B5F RID: 76639 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B5F")]
		[Address(RVA = "0x1ED1AA0", Offset = "0x1ED1AA0", VA = "0x1ED1AA0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBCD RID: 60365
		[Token(Token = "0x400EBCD")]
		[FieldOffset(Offset = "0x18")]
		private readonly long userId;

		// Token: 0x0400EBCE RID: 60366
		[Token(Token = "0x400EBCE")]
		[FieldOffset(Offset = "0x20")]
		private readonly bool isApproved;

		// Token: 0x0400EBCF RID: 60367
		[Token(Token = "0x400EBCF")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action<bool> onCompleted;
	}
}
