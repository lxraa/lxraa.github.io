﻿using System;
using System.Collections.Generic;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Infrastructure.Services.Storage.Tables;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x0200251F RID: 9503
	[Token(Token = "0x200251F")]
	public class UpdateCardCollectionHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026EC RID: 9964
		// (get) Token: 0x0601293E RID: 76094 RVA: 0x00077808 File Offset: 0x00075A08
		[Token(Token = "0x170026EC")]
		public override RequestType RequestType
		{
			[Token(Token = "0x601293E")]
			[Address(RVA = "0x1CF2934", Offset = "0x1CF2934", VA = "0x1CF2934", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026ED RID: 9965
		// (get) Token: 0x0601293F RID: 76095 RVA: 0x00077820 File Offset: 0x00075A20
		[Token(Token = "0x170026ED")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x601293F")]
			[Address(RVA = "0x1CF293C", Offset = "0x1CF293C", VA = "0x1CF293C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012940 RID: 76096 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012940")]
		[Address(RVA = "0x1CF2944", Offset = "0x1CF2944", VA = "0x1CF2944")]
		public UpdateCardCollectionHttpCommand(List<CardCollectionSet> sets, int tokens, int wildCards)
		{
		}

		// Token: 0x06012941 RID: 76097 RVA: 0x00077838 File Offset: 0x00075A38
		[Token(Token = "0x6012941")]
		[Address(RVA = "0x1CF298C", Offset = "0x1CF298C", VA = "0x1CF298C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012942 RID: 76098 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012942")]
		[Address(RVA = "0x1CF2E98", Offset = "0x1CF2E98", VA = "0x1CF2E98", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012943 RID: 76099 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012943")]
		[Address(RVA = "0x1CF2F50", Offset = "0x1CF2F50", VA = "0x1CF2F50", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB02 RID: 60162
		[Token(Token = "0x400EB02")]
		[FieldOffset(Offset = "0x18")]
		private readonly List<CardCollectionSet> sets;

		// Token: 0x0400EB03 RID: 60163
		[Token(Token = "0x400EB03")]
		[FieldOffset(Offset = "0x20")]
		private readonly int tokens;

		// Token: 0x0400EB04 RID: 60164
		[Token(Token = "0x400EB04")]
		[FieldOffset(Offset = "0x24")]
		private readonly int wildCards;
	}
}
