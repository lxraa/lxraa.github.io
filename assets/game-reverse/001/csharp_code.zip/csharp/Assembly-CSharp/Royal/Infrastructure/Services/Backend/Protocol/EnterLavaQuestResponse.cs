﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A0 RID: 9120
	[Token(Token = "0x20023A0")]
	public struct EnterLavaQuestResponse : IFlatbufferObject
	{
		// Token: 0x1700203C RID: 8252
		// (get) Token: 0x060110F2 RID: 69874 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700203C")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60110F2")]
			[Address(RVA = "0x1F9CBE0", Offset = "0x1F9CBE0", VA = "0x1F9CBE0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110F3 RID: 69875 RVA: 0x00064530 File Offset: 0x00062730
		[Token(Token = "0x60110F3")]
		[Address(RVA = "0x1F9CBE8", Offset = "0x1F9CBE8", VA = "0x1F9CBE8")]
		public static EnterLavaQuestResponse GetRootAsEnterLavaQuestResponse(ByteBuffer _bb)
		{
			return default(EnterLavaQuestResponse);
		}

		// Token: 0x060110F4 RID: 69876 RVA: 0x00064548 File Offset: 0x00062748
		[Token(Token = "0x60110F4")]
		[Address(RVA = "0x1F9CBF4", Offset = "0x1F9CBF4", VA = "0x1F9CBF4")]
		public static EnterLavaQuestResponse GetRootAsEnterLavaQuestResponse(ByteBuffer _bb, EnterLavaQuestResponse obj)
		{
			return default(EnterLavaQuestResponse);
		}

		// Token: 0x060110F5 RID: 69877 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110F5")]
		[Address(RVA = "0x1F9CCA4", Offset = "0x1F9CCA4", VA = "0x1F9CCA4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060110F6 RID: 69878 RVA: 0x00064560 File Offset: 0x00062760
		[Token(Token = "0x60110F6")]
		[Address(RVA = "0x1F9CC6C", Offset = "0x1F9CC6C", VA = "0x1F9CC6C")]
		public EnterLavaQuestResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterLavaQuestResponse);
		}

		// Token: 0x1700203D RID: 8253
		// (get) Token: 0x060110F7 RID: 69879 RVA: 0x00064578 File Offset: 0x00062778
		[Token(Token = "0x1700203D")]
		public int ServerEventId
		{
			[Token(Token = "0x60110F7")]
			[Address(RVA = "0x1F9CCB4", Offset = "0x1F9CCB4", VA = "0x1F9CCB4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700203E RID: 8254
		// (get) Token: 0x060110F8 RID: 69880 RVA: 0x00064590 File Offset: 0x00062790
		[Token(Token = "0x1700203E")]
		public LavaQuestUserGroupInfo? LavaQuestUserGroupInfo
		{
			[Token(Token = "0x60110F8")]
			[Address(RVA = "0x1F9CCF8", Offset = "0x1F9CCF8", VA = "0x1F9CCF8")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110F9 RID: 69881 RVA: 0x000645A8 File Offset: 0x000627A8
		[Token(Token = "0x60110F9")]
		[Address(RVA = "0x1F9CDB8", Offset = "0x1F9CDB8", VA = "0x1F9CDB8")]
		public static Offset<EnterLavaQuestResponse> CreateEnterLavaQuestResponse(FlatBufferBuilder builder, int server_event_id = 0, [Optional] Offset<LavaQuestUserGroupInfo> lava_quest_user_group_infoOffset)
		{
			return default(Offset<EnterLavaQuestResponse>);
		}

		// Token: 0x060110FA RID: 69882 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110FA")]
		[Address(RVA = "0x1F9CEBC", Offset = "0x1F9CEBC", VA = "0x1F9CEBC")]
		public static void StartEnterLavaQuestResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060110FB RID: 69883 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110FB")]
		[Address(RVA = "0x1F9CE30", Offset = "0x1F9CE30", VA = "0x1F9CE30")]
		public static void AddServerEventId(FlatBufferBuilder builder, int serverEventId)
		{
		}

		// Token: 0x060110FC RID: 69884 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110FC")]
		[Address(RVA = "0x1F9CE10", Offset = "0x1F9CE10", VA = "0x1F9CE10")]
		public static void AddLavaQuestUserGroupInfo(FlatBufferBuilder builder, Offset<LavaQuestUserGroupInfo> lavaQuestUserGroupInfoOffset)
		{
		}

		// Token: 0x060110FD RID: 69885 RVA: 0x000645C0 File Offset: 0x000627C0
		[Token(Token = "0x60110FD")]
		[Address(RVA = "0x1F9CE50", Offset = "0x1F9CE50", VA = "0x1F9CE50")]
		public static Offset<EnterLavaQuestResponse> EndEnterLavaQuestResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterLavaQuestResponse>);
		}

		// Token: 0x0400E6C9 RID: 59081
		[Token(Token = "0x400E6C9")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
