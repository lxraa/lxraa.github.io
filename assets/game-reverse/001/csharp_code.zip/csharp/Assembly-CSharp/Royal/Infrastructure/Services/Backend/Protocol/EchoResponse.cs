﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002398 RID: 9112
	[Token(Token = "0x2002398")]
	public struct EchoResponse : IFlatbufferObject
	{
		// Token: 0x17002025 RID: 8229
		// (get) Token: 0x060110A1 RID: 69793 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002025")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60110A1")]
			[Address(RVA = "0x1F9B8F8", Offset = "0x1F9B8F8", VA = "0x1F9B8F8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110A2 RID: 69794 RVA: 0x000640E0 File Offset: 0x000622E0
		[Token(Token = "0x60110A2")]
		[Address(RVA = "0x1F9B900", Offset = "0x1F9B900", VA = "0x1F9B900")]
		public static EchoResponse GetRootAsEchoResponse(ByteBuffer _bb)
		{
			return default(EchoResponse);
		}

		// Token: 0x060110A3 RID: 69795 RVA: 0x000640F8 File Offset: 0x000622F8
		[Token(Token = "0x60110A3")]
		[Address(RVA = "0x1F9B90C", Offset = "0x1F9B90C", VA = "0x1F9B90C")]
		public static EchoResponse GetRootAsEchoResponse(ByteBuffer _bb, EchoResponse obj)
		{
			return default(EchoResponse);
		}

		// Token: 0x060110A4 RID: 69796 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110A4")]
		[Address(RVA = "0x1F9B9BC", Offset = "0x1F9B9BC", VA = "0x1F9B9BC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060110A5 RID: 69797 RVA: 0x00064110 File Offset: 0x00062310
		[Token(Token = "0x60110A5")]
		[Address(RVA = "0x1F9B984", Offset = "0x1F9B984", VA = "0x1F9B984")]
		public EchoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EchoResponse);
		}

		// Token: 0x060110A6 RID: 69798 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110A6")]
		[Address(RVA = "0x1F9B9CC", Offset = "0x1F9B9CC", VA = "0x1F9B9CC")]
		public static void StartEchoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060110A7 RID: 69799 RVA: 0x00064128 File Offset: 0x00062328
		[Token(Token = "0x60110A7")]
		[Address(RVA = "0x1F9B9E4", Offset = "0x1F9B9E4", VA = "0x1F9B9E4")]
		public static Offset<EchoResponse> EndEchoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EchoResponse>);
		}

		// Token: 0x0400E6B9 RID: 59065
		[Token(Token = "0x400E6B9")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
