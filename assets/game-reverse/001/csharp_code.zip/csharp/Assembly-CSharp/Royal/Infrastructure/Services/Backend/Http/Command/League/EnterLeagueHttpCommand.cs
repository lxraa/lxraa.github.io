﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.League
{
	// Token: 0x0200255F RID: 9567
	[Token(Token = "0x200255F")]
	public class EnterLeagueHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002784 RID: 10116
		// (get) Token: 0x06012B23 RID: 76579 RVA: 0x00078D20 File Offset: 0x00076F20
		[Token(Token = "0x17002784")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B23")]
			[Address(RVA = "0x1ECFB34", Offset = "0x1ECFB34", VA = "0x1ECFB34", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002785 RID: 10117
		// (get) Token: 0x06012B24 RID: 76580 RVA: 0x00078D38 File Offset: 0x00076F38
		[Token(Token = "0x17002785")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B24")]
			[Address(RVA = "0x1ECFB3C", Offset = "0x1ECFB3C", VA = "0x1ECFB3C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002786 RID: 10118
		// (get) Token: 0x06012B25 RID: 76581 RVA: 0x00078D50 File Offset: 0x00076F50
		// (set) Token: 0x06012B26 RID: 76582 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002786")]
		public EnterLeagueResponse Response
		{
			[Token(Token = "0x6012B25")]
			[Address(RVA = "0x1ECFB44", Offset = "0x1ECFB44", VA = "0x1ECFB44")]
			get
			{
				return default(EnterLeagueResponse);
			}
			[Token(Token = "0x6012B26")]
			[Address(RVA = "0x1ECFB50", Offset = "0x1ECFB50", VA = "0x1ECFB50")]
			set
			{
			}
		}

		// Token: 0x06012B27 RID: 76583 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B27")]
		[Address(RVA = "0x1ECFB60", Offset = "0x1ECFB60", VA = "0x1ECFB60")]
		public EnterLeagueHttpCommand(string userName)
		{
		}

		// Token: 0x06012B28 RID: 76584 RVA: 0x00078D68 File Offset: 0x00076F68
		[Token(Token = "0x6012B28")]
		[Address(RVA = "0x1ECFB90", Offset = "0x1ECFB90", VA = "0x1ECFB90", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B29 RID: 76585 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B29")]
		[Address(RVA = "0x1ECFCA4", Offset = "0x1ECFCA4", VA = "0x1ECFCA4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B2A RID: 76586 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B2A")]
		[Address(RVA = "0x1ED03D0", Offset = "0x1ED03D0", VA = "0x1ED03D0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012B2B RID: 76587 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B2B")]
		[Address(RVA = "0x1ED023C", Offset = "0x1ED023C", VA = "0x1ED023C")]
		private static void UpdateSections()
		{
		}

		// Token: 0x0400EBBA RID: 60346
		[Token(Token = "0x400EBBA")]
		[FieldOffset(Offset = "0x18")]
		private EnterLeagueResponse <Response>k__BackingField;

		// Token: 0x0400EBBB RID: 60347
		[Token(Token = "0x400EBBB")]
		[FieldOffset(Offset = "0x28")]
		private readonly string userName;
	}
}
