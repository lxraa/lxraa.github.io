﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D3 RID: 9171
	[Token(Token = "0x20023D3")]
	public struct GetFacebookAppsecretProofResponse : IFlatbufferObject
	{
		// Token: 0x170020F3 RID: 8435
		// (get) Token: 0x060113AA RID: 70570 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020F3")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60113AA")]
			[Address(RVA = "0x1CAFB40", Offset = "0x1CAFB40", VA = "0x1CAFB40", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060113AB RID: 70571 RVA: 0x00066990 File Offset: 0x00064B90
		[Token(Token = "0x60113AB")]
		[Address(RVA = "0x1CAFB48", Offset = "0x1CAFB48", VA = "0x1CAFB48")]
		public static GetFacebookAppsecretProofResponse GetRootAsGetFacebookAppsecretProofResponse(ByteBuffer _bb)
		{
			return default(GetFacebookAppsecretProofResponse);
		}

		// Token: 0x060113AC RID: 70572 RVA: 0x000669A8 File Offset: 0x00064BA8
		[Token(Token = "0x60113AC")]
		[Address(RVA = "0x1CAFB54", Offset = "0x1CAFB54", VA = "0x1CAFB54")]
		public static GetFacebookAppsecretProofResponse GetRootAsGetFacebookAppsecretProofResponse(ByteBuffer _bb, GetFacebookAppsecretProofResponse obj)
		{
			return default(GetFacebookAppsecretProofResponse);
		}

		// Token: 0x060113AD RID: 70573 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113AD")]
		[Address(RVA = "0x1CAFC04", Offset = "0x1CAFC04", VA = "0x1CAFC04", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060113AE RID: 70574 RVA: 0x000669C0 File Offset: 0x00064BC0
		[Token(Token = "0x60113AE")]
		[Address(RVA = "0x1CAFBCC", Offset = "0x1CAFBCC", VA = "0x1CAFBCC")]
		public GetFacebookAppsecretProofResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetFacebookAppsecretProofResponse);
		}

		// Token: 0x060113AF RID: 70575 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113AF")]
		[Address(RVA = "0x1CAFC14", Offset = "0x1CAFC14", VA = "0x1CAFC14")]
		public static void StartGetFacebookAppsecretProofResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060113B0 RID: 70576 RVA: 0x000669D8 File Offset: 0x00064BD8
		[Token(Token = "0x60113B0")]
		[Address(RVA = "0x1CAFC2C", Offset = "0x1CAFC2C", VA = "0x1CAFC2C")]
		public static Offset<GetFacebookAppsecretProofResponse> EndGetFacebookAppsecretProofResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetFacebookAppsecretProofResponse>);
		}

		// Token: 0x0400E743 RID: 59203
		[Token(Token = "0x400E743")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
