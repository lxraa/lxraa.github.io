﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200238A RID: 9098
	[Token(Token = "0x200238A")]
	public struct DragonNestPartnerScoreUpdateInfo : IFlatbufferObject
	{
		// Token: 0x17001FF2 RID: 8178
		// (get) Token: 0x06010FD6 RID: 69590 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FF2")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010FD6")]
			[Address(RVA = "0x1F9889C", Offset = "0x1F9889C", VA = "0x1F9889C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FD7 RID: 69591 RVA: 0x00063690 File Offset: 0x00061890
		[Token(Token = "0x6010FD7")]
		[Address(RVA = "0x1F988A4", Offset = "0x1F988A4", VA = "0x1F988A4")]
		public static DragonNestPartnerScoreUpdateInfo GetRootAsDragonNestPartnerScoreUpdateInfo(ByteBuffer _bb)
		{
			return default(DragonNestPartnerScoreUpdateInfo);
		}

		// Token: 0x06010FD8 RID: 69592 RVA: 0x000636A8 File Offset: 0x000618A8
		[Token(Token = "0x6010FD8")]
		[Address(RVA = "0x1F988B0", Offset = "0x1F988B0", VA = "0x1F988B0")]
		public static DragonNestPartnerScoreUpdateInfo GetRootAsDragonNestPartnerScoreUpdateInfo(ByteBuffer _bb, DragonNestPartnerScoreUpdateInfo obj)
		{
			return default(DragonNestPartnerScoreUpdateInfo);
		}

		// Token: 0x06010FD9 RID: 69593 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FD9")]
		[Address(RVA = "0x1F98960", Offset = "0x1F98960", VA = "0x1F98960", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010FDA RID: 69594 RVA: 0x000636C0 File Offset: 0x000618C0
		[Token(Token = "0x6010FDA")]
		[Address(RVA = "0x1F98928", Offset = "0x1F98928", VA = "0x1F98928")]
		public DragonNestPartnerScoreUpdateInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestPartnerScoreUpdateInfo);
		}

		// Token: 0x17001FF3 RID: 8179
		// (get) Token: 0x06010FDB RID: 69595 RVA: 0x000636D8 File Offset: 0x000618D8
		[Token(Token = "0x17001FF3")]
		public long PartnerUserId
		{
			[Token(Token = "0x6010FDB")]
			[Address(RVA = "0x1F98970", Offset = "0x1F98970", VA = "0x1F98970")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FF4 RID: 8180
		// (get) Token: 0x06010FDC RID: 69596 RVA: 0x000636F0 File Offset: 0x000618F0
		[Token(Token = "0x17001FF4")]
		public int PartnerScore
		{
			[Token(Token = "0x6010FDC")]
			[Address(RVA = "0x1F989B8", Offset = "0x1F989B8", VA = "0x1F989B8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010FDD RID: 69597 RVA: 0x00063708 File Offset: 0x00061908
		[Token(Token = "0x6010FDD")]
		[Address(RVA = "0x1F989FC", Offset = "0x1F989FC", VA = "0x1F989FC")]
		public static Offset<DragonNestPartnerScoreUpdateInfo> CreateDragonNestPartnerScoreUpdateInfo(FlatBufferBuilder builder, long partner_user_id = 0L, int partner_score = 0)
		{
			return default(Offset<DragonNestPartnerScoreUpdateInfo>);
		}

		// Token: 0x06010FDE RID: 69598 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FDE")]
		[Address(RVA = "0x1F98B00", Offset = "0x1F98B00", VA = "0x1F98B00")]
		public static void StartDragonNestPartnerScoreUpdateInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010FDF RID: 69599 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FDF")]
		[Address(RVA = "0x1F98A54", Offset = "0x1F98A54", VA = "0x1F98A54")]
		public static void AddPartnerUserId(FlatBufferBuilder builder, long partnerUserId)
		{
		}

		// Token: 0x06010FE0 RID: 69600 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FE0")]
		[Address(RVA = "0x1F98A74", Offset = "0x1F98A74", VA = "0x1F98A74")]
		public static void AddPartnerScore(FlatBufferBuilder builder, int partnerScore)
		{
		}

		// Token: 0x06010FE1 RID: 69601 RVA: 0x00063720 File Offset: 0x00061920
		[Token(Token = "0x6010FE1")]
		[Address(RVA = "0x1F98A94", Offset = "0x1F98A94", VA = "0x1F98A94")]
		public static Offset<DragonNestPartnerScoreUpdateInfo> EndDragonNestPartnerScoreUpdateInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestPartnerScoreUpdateInfo>);
		}

		// Token: 0x0400E6A3 RID: 59043
		[Token(Token = "0x400E6A3")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
