﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200239D RID: 9117
	[Token(Token = "0x200239D")]
	public struct EnterDailyLightningRushResponse : IFlatbufferObject
	{
		// Token: 0x17002034 RID: 8244
		// (get) Token: 0x060110D6 RID: 69846 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002034")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60110D6")]
			[Address(RVA = "0x1F9C514", Offset = "0x1F9C514", VA = "0x1F9C514", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110D7 RID: 69847 RVA: 0x000643B0 File Offset: 0x000625B0
		[Token(Token = "0x60110D7")]
		[Address(RVA = "0x1F9C51C", Offset = "0x1F9C51C", VA = "0x1F9C51C")]
		public static EnterDailyLightningRushResponse GetRootAsEnterDailyLightningRushResponse(ByteBuffer _bb)
		{
			return default(EnterDailyLightningRushResponse);
		}

		// Token: 0x060110D8 RID: 69848 RVA: 0x000643C8 File Offset: 0x000625C8
		[Token(Token = "0x60110D8")]
		[Address(RVA = "0x1F9C528", Offset = "0x1F9C528", VA = "0x1F9C528")]
		public static EnterDailyLightningRushResponse GetRootAsEnterDailyLightningRushResponse(ByteBuffer _bb, EnterDailyLightningRushResponse obj)
		{
			return default(EnterDailyLightningRushResponse);
		}

		// Token: 0x060110D9 RID: 69849 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110D9")]
		[Address(RVA = "0x1F9C5D8", Offset = "0x1F9C5D8", VA = "0x1F9C5D8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060110DA RID: 69850 RVA: 0x000643E0 File Offset: 0x000625E0
		[Token(Token = "0x60110DA")]
		[Address(RVA = "0x1F9C5A0", Offset = "0x1F9C5A0", VA = "0x1F9C5A0")]
		public EnterDailyLightningRushResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterDailyLightningRushResponse);
		}

		// Token: 0x17002035 RID: 8245
		// (get) Token: 0x060110DB RID: 69851 RVA: 0x000643F8 File Offset: 0x000625F8
		[Token(Token = "0x17002035")]
		public EnterDailyLightningRushFailReason FailReason
		{
			[Token(Token = "0x60110DB")]
			[Address(RVA = "0x1F9C5E8", Offset = "0x1F9C5E8", VA = "0x1F9C5E8")]
			get
			{
				return EnterDailyLightningRushFailReason.None;
			}
		}

		// Token: 0x17002036 RID: 8246
		// (get) Token: 0x060110DC RID: 69852 RVA: 0x00064410 File Offset: 0x00062610
		[Token(Token = "0x17002036")]
		public DailyLightningRushInfo? DailyLightningRushInfo
		{
			[Token(Token = "0x60110DC")]
			[Address(RVA = "0x1F9C62C", Offset = "0x1F9C62C", VA = "0x1F9C62C")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002037 RID: 8247
		// (get) Token: 0x060110DD RID: 69853 RVA: 0x00064428 File Offset: 0x00062628
		[Token(Token = "0x17002037")]
		public DailyLightningRushGroupInfo? DailyLightningRushGroupInfo
		{
			[Token(Token = "0x60110DD")]
			[Address(RVA = "0x1F9C6E4", Offset = "0x1F9C6E4", VA = "0x1F9C6E4")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002038 RID: 8248
		// (get) Token: 0x060110DE RID: 69854 RVA: 0x00064440 File Offset: 0x00062640
		[Token(Token = "0x17002038")]
		public bool HasEntered3StepGroup
		{
			[Token(Token = "0x60110DE")]
			[Address(RVA = "0x1F9C79C", Offset = "0x1F9C79C", VA = "0x1F9C79C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x060110DF RID: 69855 RVA: 0x00064458 File Offset: 0x00062658
		[Token(Token = "0x60110DF")]
		[Address(RVA = "0x1F9C7E4", Offset = "0x1F9C7E4", VA = "0x1F9C7E4")]
		public static Offset<EnterDailyLightningRushResponse> CreateEnterDailyLightningRushResponse(FlatBufferBuilder builder, EnterDailyLightningRushFailReason fail_reason = EnterDailyLightningRushFailReason.None, [Optional] Offset<DailyLightningRushInfo> daily_lightning_rush_infoOffset, [Optional] Offset<DailyLightningRushGroupInfo> daily_lightning_rush_group_infoOffset, bool has_entered_3_step_group = false)
		{
			return default(Offset<EnterDailyLightningRushResponse>);
		}

		// Token: 0x060110E0 RID: 69856 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110E0")]
		[Address(RVA = "0x1F9C950", Offset = "0x1F9C950", VA = "0x1F9C950")]
		public static void StartEnterDailyLightningRushResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060110E1 RID: 69857 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110E1")]
		[Address(RVA = "0x1F9C8C4", Offset = "0x1F9C8C4", VA = "0x1F9C8C4")]
		public static void AddFailReason(FlatBufferBuilder builder, EnterDailyLightningRushFailReason failReason)
		{
		}

		// Token: 0x060110E2 RID: 69858 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110E2")]
		[Address(RVA = "0x1F9C884", Offset = "0x1F9C884", VA = "0x1F9C884")]
		public static void AddDailyLightningRushInfo(FlatBufferBuilder builder, Offset<DailyLightningRushInfo> dailyLightningRushInfoOffset)
		{
		}

		// Token: 0x060110E3 RID: 69859 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110E3")]
		[Address(RVA = "0x1F9C864", Offset = "0x1F9C864", VA = "0x1F9C864")]
		public static void AddDailyLightningRushGroupInfo(FlatBufferBuilder builder, Offset<DailyLightningRushGroupInfo> dailyLightningRushGroupInfoOffset)
		{
		}

		// Token: 0x060110E4 RID: 69860 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110E4")]
		[Address(RVA = "0x1F9C8A4", Offset = "0x1F9C8A4", VA = "0x1F9C8A4")]
		public static void AddHasEntered3StepGroup(FlatBufferBuilder builder, bool hasEntered3StepGroup)
		{
		}

		// Token: 0x060110E5 RID: 69861 RVA: 0x00064470 File Offset: 0x00062670
		[Token(Token = "0x60110E5")]
		[Address(RVA = "0x1F9C8E4", Offset = "0x1F9C8E4", VA = "0x1F9C8E4")]
		public static Offset<EnterDailyLightningRushResponse> EndEnterDailyLightningRushResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterDailyLightningRushResponse>);
		}

		// Token: 0x0400E6C2 RID: 59074
		[Token(Token = "0x400E6C2")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
