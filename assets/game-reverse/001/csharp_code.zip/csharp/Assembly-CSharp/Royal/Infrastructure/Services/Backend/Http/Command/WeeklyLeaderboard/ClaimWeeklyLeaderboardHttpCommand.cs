﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.WeeklyLeaderboard
{
	// Token: 0x02002525 RID: 9509
	[Token(Token = "0x2002525")]
	public class ClaimWeeklyLeaderboardHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026FA RID: 9978
		// (get) Token: 0x06012988 RID: 76168 RVA: 0x000779E8 File Offset: 0x00075BE8
		[Token(Token = "0x170026FA")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012988")]
			[Address(RVA = "0x1CF8918", Offset = "0x1CF8918", VA = "0x1CF8918", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026FB RID: 9979
		// (get) Token: 0x06012989 RID: 76169 RVA: 0x00077A00 File Offset: 0x00075C00
		[Token(Token = "0x170026FB")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012989")]
			[Address(RVA = "0x1CF8920", Offset = "0x1CF8920", VA = "0x1CF8920", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x0601298A RID: 76170 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601298A")]
		[Address(RVA = "0x1CF8928", Offset = "0x1CF8928", VA = "0x1CF8928")]
		public ClaimWeeklyLeaderboardHttpCommand(int eventId)
		{
		}

		// Token: 0x0601298B RID: 76171 RVA: 0x00077A18 File Offset: 0x00075C18
		[Token(Token = "0x601298B")]
		[Address(RVA = "0x1CF8950", Offset = "0x1CF8950", VA = "0x1CF8950", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x0601298C RID: 76172 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601298C")]
		[Address(RVA = "0x1CF8970", Offset = "0x1CF8970", VA = "0x1CF8970", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x0601298D RID: 76173 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601298D")]
		[Address(RVA = "0x1CF8A6C", Offset = "0x1CF8A6C", VA = "0x1CF8A6C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB18 RID: 60184
		[Token(Token = "0x400EB18")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;
	}
}
