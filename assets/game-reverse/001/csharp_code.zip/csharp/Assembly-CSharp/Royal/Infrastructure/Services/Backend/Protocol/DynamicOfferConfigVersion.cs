﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002393 RID: 9107
	[Token(Token = "0x2002393")]
	public struct DynamicOfferConfigVersion : IFlatbufferObject
	{
		// Token: 0x17002010 RID: 8208
		// (get) Token: 0x0601104E RID: 69710 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002010")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601104E")]
			[Address(RVA = "0x1F9A628", Offset = "0x1F9A628", VA = "0x1F9A628", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601104F RID: 69711 RVA: 0x00063CD8 File Offset: 0x00061ED8
		[Token(Token = "0x601104F")]
		[Address(RVA = "0x1F9A630", Offset = "0x1F9A630", VA = "0x1F9A630")]
		public static DynamicOfferConfigVersion GetRootAsDynamicOfferConfigVersion(ByteBuffer _bb)
		{
			return default(DynamicOfferConfigVersion);
		}

		// Token: 0x06011050 RID: 69712 RVA: 0x00063CF0 File Offset: 0x00061EF0
		[Token(Token = "0x6011050")]
		[Address(RVA = "0x1F9A63C", Offset = "0x1F9A63C", VA = "0x1F9A63C")]
		public static DynamicOfferConfigVersion GetRootAsDynamicOfferConfigVersion(ByteBuffer _bb, DynamicOfferConfigVersion obj)
		{
			return default(DynamicOfferConfigVersion);
		}

		// Token: 0x06011051 RID: 69713 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011051")]
		[Address(RVA = "0x1F9A6EC", Offset = "0x1F9A6EC", VA = "0x1F9A6EC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011052 RID: 69714 RVA: 0x00063D08 File Offset: 0x00061F08
		[Token(Token = "0x6011052")]
		[Address(RVA = "0x1F9A6B4", Offset = "0x1F9A6B4", VA = "0x1F9A6B4")]
		public DynamicOfferConfigVersion __assign(int _i, ByteBuffer _bb)
		{
			return default(DynamicOfferConfigVersion);
		}

		// Token: 0x17002011 RID: 8209
		// (get) Token: 0x06011053 RID: 69715 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002011")]
		public string MetaAssetName
		{
			[Token(Token = "0x6011053")]
			[Address(RVA = "0x1F9A6FC", Offset = "0x1F9A6FC", VA = "0x1F9A6FC")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011054 RID: 69716 RVA: 0x00063D20 File Offset: 0x00061F20
		[Token(Token = "0x6011054")]
		[Address(RVA = "0x1F9A738", Offset = "0x1F9A738", VA = "0x1F9A738")]
		public ArraySegment<byte>? GetMetaAssetNameBytes()
		{
			return null;
		}

		// Token: 0x06011055 RID: 69717 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011055")]
		[Address(RVA = "0x1F9A770", Offset = "0x1F9A770", VA = "0x1F9A770")]
		public byte[] GetMetaAssetNameArray()
		{
			return null;
		}

		// Token: 0x17002012 RID: 8210
		// (get) Token: 0x06011056 RID: 69718 RVA: 0x00063D38 File Offset: 0x00061F38
		[Token(Token = "0x17002012")]
		public short ConfigVersion
		{
			[Token(Token = "0x6011056")]
			[Address(RVA = "0x1F9A7BC", Offset = "0x1F9A7BC", VA = "0x1F9A7BC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011057 RID: 69719 RVA: 0x00063D50 File Offset: 0x00061F50
		[Token(Token = "0x6011057")]
		[Address(RVA = "0x1F9A800", Offset = "0x1F9A800", VA = "0x1F9A800")]
		public static Offset<DynamicOfferConfigVersion> CreateDynamicOfferConfigVersion(FlatBufferBuilder builder, [Optional] StringOffset meta_asset_nameOffset, short config_version = 0)
		{
			return default(Offset<DynamicOfferConfigVersion>);
		}

		// Token: 0x06011058 RID: 69720 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011058")]
		[Address(RVA = "0x1F9A904", Offset = "0x1F9A904", VA = "0x1F9A904")]
		public static void StartDynamicOfferConfigVersion(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011059 RID: 69721 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011059")]
		[Address(RVA = "0x1F9A858", Offset = "0x1F9A858", VA = "0x1F9A858")]
		public static void AddMetaAssetName(FlatBufferBuilder builder, StringOffset metaAssetNameOffset)
		{
		}

		// Token: 0x0601105A RID: 69722 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601105A")]
		[Address(RVA = "0x1F9A878", Offset = "0x1F9A878", VA = "0x1F9A878")]
		public static void AddConfigVersion(FlatBufferBuilder builder, short configVersion)
		{
		}

		// Token: 0x0601105B RID: 69723 RVA: 0x00063D68 File Offset: 0x00061F68
		[Token(Token = "0x601105B")]
		[Address(RVA = "0x1F9A898", Offset = "0x1F9A898", VA = "0x1F9A898")]
		public static Offset<DynamicOfferConfigVersion> EndDynamicOfferConfigVersion(FlatBufferBuilder builder)
		{
			return default(Offset<DynamicOfferConfigVersion>);
		}

		// Token: 0x0400E6B4 RID: 59060
		[Token(Token = "0x400E6B4")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
