﻿using System;
using Il2CppDummyDll;
using UnityEngine.Networking;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002584 RID: 9604
	[Token(Token = "0x2002584")]
	public class FileDownloader : IFileDownloader
	{
		// Token: 0x170027CE RID: 10190
		// (get) Token: 0x06012C40 RID: 76864 RVA: 0x00079770 File Offset: 0x00077970
		// (set) Token: 0x06012C41 RID: 76865 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027CE")]
		public bool IsDownloading
		{
			[Token(Token = "0x6012C40")]
			[Address(RVA = "0x1EDAAE4", Offset = "0x1EDAAE4", VA = "0x1EDAAE4", Slot = "4")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012C41")]
			[Address(RVA = "0x1EDAAEC", Offset = "0x1EDAAEC", VA = "0x1EDAAEC")]
			private set
			{
			}
		}

		// Token: 0x06012C42 RID: 76866 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C42")]
		[Address(RVA = "0x1EDAAF8", Offset = "0x1EDAAF8", VA = "0x1EDAAF8", Slot = "5")]
		public void Download(string fileName, string url, string saveDirectory, Action<bool, string> onSaveComplete, bool isTexture)
		{
		}

		// Token: 0x06012C43 RID: 76867 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C43")]
		[Address(RVA = "0x1EDB144", Offset = "0x1EDB144", VA = "0x1EDB144", Slot = "6")]
		public void UnityWebRequestManualUpdate()
		{
		}

		// Token: 0x06012C44 RID: 76868 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C44")]
		[Address(RVA = "0x1EDB8D0", Offset = "0x1EDB8D0", VA = "0x1EDB8D0")]
		private void HandleException(string fileName, string url, Exception ex)
		{
		}

		// Token: 0x06012C45 RID: 76869 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C45")]
		[Address(RVA = "0x1EDAF6C", Offset = "0x1EDAF6C", VA = "0x1EDAF6C")]
		private void StartDownload(Action<bool, string> onSaveComplete)
		{
		}

		// Token: 0x06012C46 RID: 76870 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C46")]
		[Address(RVA = "0x1EDAF40", Offset = "0x1EDAF40", VA = "0x1EDAF40")]
		private void DownloadCompleted(bool success, string eTag)
		{
		}

		// Token: 0x06012C47 RID: 76871 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C47")]
		[Address(RVA = "0x1EDBC80", Offset = "0x1EDBC80", VA = "0x1EDBC80")]
		public FileDownloader()
		{
		}

		// Token: 0x0400EC40 RID: 60480
		[Token(Token = "0x400EC40")]
		private const string TempPrefix = "temp_";

		// Token: 0x0400EC41 RID: 60481
		[Token(Token = "0x400EC41")]
		[FieldOffset(Offset = "0x10")]
		private Action<bool, string> onComplete;

		// Token: 0x0400EC42 RID: 60482
		[Token(Token = "0x400EC42")]
		[FieldOffset(Offset = "0x18")]
		private bool <IsDownloading>k__BackingField;

		// Token: 0x0400EC43 RID: 60483
		[Token(Token = "0x400EC43")]
		[FieldOffset(Offset = "0x20")]
		private string currentFile;

		// Token: 0x0400EC44 RID: 60484
		[Token(Token = "0x400EC44")]
		[FieldOffset(Offset = "0x28")]
		private string currentUrl;

		// Token: 0x0400EC45 RID: 60485
		[Token(Token = "0x400EC45")]
		[FieldOffset(Offset = "0x30")]
		private string tempDownloadPath;

		// Token: 0x0400EC46 RID: 60486
		[Token(Token = "0x400EC46")]
		[FieldOffset(Offset = "0x38")]
		private bool isDownloadSuccess;

		// Token: 0x0400EC47 RID: 60487
		[Token(Token = "0x400EC47")]
		[FieldOffset(Offset = "0x40")]
		private readonly TimeSpan httpRequestTimeout;

		// Token: 0x0400EC48 RID: 60488
		[Token(Token = "0x400EC48")]
		[FieldOffset(Offset = "0x48")]
		private UnityWebRequest webRequest;
	}
}
