﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002369 RID: 9065
	[Token(Token = "0x2002369")]
	public struct ConfigVersions : IFlatbufferObject
	{
		// Token: 0x17001F6C RID: 8044
		// (get) Token: 0x06010DDE RID: 69086 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F6C")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010DDE")]
			[Address(RVA = "0x214B9A0", Offset = "0x214B9A0", VA = "0x214B9A0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010DDF RID: 69087 RVA: 0x00061CE0 File Offset: 0x0005FEE0
		[Token(Token = "0x6010DDF")]
		[Address(RVA = "0x214B9A8", Offset = "0x214B9A8", VA = "0x214B9A8")]
		public static ConfigVersions GetRootAsConfigVersions(ByteBuffer _bb)
		{
			return default(ConfigVersions);
		}

		// Token: 0x06010DE0 RID: 69088 RVA: 0x00061CF8 File Offset: 0x0005FEF8
		[Token(Token = "0x6010DE0")]
		[Address(RVA = "0x214B9B4", Offset = "0x214B9B4", VA = "0x214B9B4")]
		public static ConfigVersions GetRootAsConfigVersions(ByteBuffer _bb, ConfigVersions obj)
		{
			return default(ConfigVersions);
		}

		// Token: 0x06010DE1 RID: 69089 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DE1")]
		[Address(RVA = "0x214BA64", Offset = "0x214BA64", VA = "0x214BA64", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010DE2 RID: 69090 RVA: 0x00061D10 File Offset: 0x0005FF10
		[Token(Token = "0x6010DE2")]
		[Address(RVA = "0x214BA2C", Offset = "0x214BA2C", VA = "0x214BA2C")]
		public ConfigVersions __assign(int _i, ByteBuffer _bb)
		{
			return default(ConfigVersions);
		}

		// Token: 0x17001F6D RID: 8045
		// (get) Token: 0x06010DE3 RID: 69091 RVA: 0x00061D28 File Offset: 0x0005FF28
		[Token(Token = "0x17001F6D")]
		public short DynamicOfferConfigVersion
		{
			[Token(Token = "0x6010DE3")]
			[Address(RVA = "0x214BA74", Offset = "0x214BA74", VA = "0x214BA74")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F6E RID: 8046
		// (get) Token: 0x06010DE4 RID: 69092 RVA: 0x00061D40 File Offset: 0x0005FF40
		[Token(Token = "0x17001F6E")]
		public short DynamicOfferUserSegmentVersion
		{
			[Token(Token = "0x6010DE4")]
			[Address(RVA = "0x214BAB8", Offset = "0x214BAB8", VA = "0x214BAB8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F6F RID: 8047
		// (get) Token: 0x06010DE5 RID: 69093 RVA: 0x00061D58 File Offset: 0x0005FF58
		[Token(Token = "0x17001F6F")]
		public int LavaQuestConfigVersion
		{
			[Token(Token = "0x6010DE5")]
			[Address(RVA = "0x214BAFC", Offset = "0x214BAFC", VA = "0x214BAFC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010DE6 RID: 69094 RVA: 0x00061D70 File Offset: 0x0005FF70
		[Token(Token = "0x6010DE6")]
		[Address(RVA = "0x214BB40", Offset = "0x214BB40", VA = "0x214BB40")]
		public DynamicOfferConfigVersion? DynamicOfferConfigVersionList(int j)
		{
			return null;
		}

		// Token: 0x17001F70 RID: 8048
		// (get) Token: 0x06010DE7 RID: 69095 RVA: 0x00061D88 File Offset: 0x0005FF88
		[Token(Token = "0x17001F70")]
		public int DynamicOfferConfigVersionListLength
		{
			[Token(Token = "0x6010DE7")]
			[Address(RVA = "0x214BC18", Offset = "0x214BC18", VA = "0x214BC18")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010DE8 RID: 69096 RVA: 0x00061DA0 File Offset: 0x0005FFA0
		[Token(Token = "0x6010DE8")]
		[Address(RVA = "0x214BC4C", Offset = "0x214BC4C", VA = "0x214BC4C")]
		public static Offset<ConfigVersions> CreateConfigVersions(FlatBufferBuilder builder, short dynamic_offer_config_version = 0, short dynamic_offer_user_segment_version = 0, int lava_quest_config_version = 0, [Optional] VectorOffset dynamic_offer_config_version_listOffset)
		{
			return default(Offset<ConfigVersions>);
		}

		// Token: 0x06010DE9 RID: 69097 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DE9")]
		[Address(RVA = "0x214BDB8", Offset = "0x214BDB8", VA = "0x214BDB8")]
		public static void StartConfigVersions(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010DEA RID: 69098 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DEA")]
		[Address(RVA = "0x214BD2C", Offset = "0x214BD2C", VA = "0x214BD2C")]
		public static void AddDynamicOfferConfigVersion(FlatBufferBuilder builder, short dynamicOfferConfigVersion)
		{
		}

		// Token: 0x06010DEB RID: 69099 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DEB")]
		[Address(RVA = "0x214BD0C", Offset = "0x214BD0C", VA = "0x214BD0C")]
		public static void AddDynamicOfferUserSegmentVersion(FlatBufferBuilder builder, short dynamicOfferUserSegmentVersion)
		{
		}

		// Token: 0x06010DEC RID: 69100 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DEC")]
		[Address(RVA = "0x214BCEC", Offset = "0x214BCEC", VA = "0x214BCEC")]
		public static void AddLavaQuestConfigVersion(FlatBufferBuilder builder, int lavaQuestConfigVersion)
		{
		}

		// Token: 0x06010DED RID: 69101 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DED")]
		[Address(RVA = "0x214BCCC", Offset = "0x214BCCC", VA = "0x214BCCC")]
		public static void AddDynamicOfferConfigVersionList(FlatBufferBuilder builder, VectorOffset dynamicOfferConfigVersionListOffset)
		{
		}

		// Token: 0x06010DEE RID: 69102 RVA: 0x00061DB8 File Offset: 0x0005FFB8
		[Token(Token = "0x6010DEE")]
		[Address(RVA = "0x214BDD0", Offset = "0x214BDD0", VA = "0x214BDD0")]
		public static VectorOffset CreateDynamicOfferConfigVersionListVector(FlatBufferBuilder builder, Offset<DynamicOfferConfigVersion>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010DEF RID: 69103 RVA: 0x00061DD0 File Offset: 0x0005FFD0
		[Token(Token = "0x6010DEF")]
		[Address(RVA = "0x214BE78", Offset = "0x214BE78", VA = "0x214BE78")]
		public static VectorOffset CreateDynamicOfferConfigVersionListVectorBlock(FlatBufferBuilder builder, Offset<DynamicOfferConfigVersion>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010DF0 RID: 69104 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DF0")]
		[Address(RVA = "0x214BF00", Offset = "0x214BF00", VA = "0x214BF00")]
		public static void StartDynamicOfferConfigVersionListVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010DF1 RID: 69105 RVA: 0x00061DE8 File Offset: 0x0005FFE8
		[Token(Token = "0x6010DF1")]
		[Address(RVA = "0x214BD4C", Offset = "0x214BD4C", VA = "0x214BD4C")]
		public static Offset<ConfigVersions> EndConfigVersions(FlatBufferBuilder builder)
		{
			return default(Offset<ConfigVersions>);
		}

		// Token: 0x0400E66F RID: 58991
		[Token(Token = "0x400E66F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
