﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023E1 RID: 9185
	[Token(Token = "0x20023E1")]
	public struct GetLeagueInfoResponse : IFlatbufferObject
	{
		// Token: 0x17002118 RID: 8472
		// (get) Token: 0x06011464 RID: 70756 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002118")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011464")]
			[Address(RVA = "0x1CB295C", Offset = "0x1CB295C", VA = "0x1CB295C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011465 RID: 70757 RVA: 0x000673E0 File Offset: 0x000655E0
		[Token(Token = "0x6011465")]
		[Address(RVA = "0x1CB2964", Offset = "0x1CB2964", VA = "0x1CB2964")]
		public static GetLeagueInfoResponse GetRootAsGetLeagueInfoResponse(ByteBuffer _bb)
		{
			return default(GetLeagueInfoResponse);
		}

		// Token: 0x06011466 RID: 70758 RVA: 0x000673F8 File Offset: 0x000655F8
		[Token(Token = "0x6011466")]
		[Address(RVA = "0x1CB2970", Offset = "0x1CB2970", VA = "0x1CB2970")]
		public static GetLeagueInfoResponse GetRootAsGetLeagueInfoResponse(ByteBuffer _bb, GetLeagueInfoResponse obj)
		{
			return default(GetLeagueInfoResponse);
		}

		// Token: 0x06011467 RID: 70759 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011467")]
		[Address(RVA = "0x1CB2A20", Offset = "0x1CB2A20", VA = "0x1CB2A20", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011468 RID: 70760 RVA: 0x00067410 File Offset: 0x00065610
		[Token(Token = "0x6011468")]
		[Address(RVA = "0x1CB29E8", Offset = "0x1CB29E8", VA = "0x1CB29E8")]
		public GetLeagueInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetLeagueInfoResponse);
		}

		// Token: 0x17002119 RID: 8473
		// (get) Token: 0x06011469 RID: 70761 RVA: 0x00067428 File Offset: 0x00065628
		[Token(Token = "0x17002119")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6011469")]
			[Address(RVA = "0x1CB2A30", Offset = "0x1CB2A30", VA = "0x1CB2A30")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x0601146A RID: 70762 RVA: 0x00067440 File Offset: 0x00065640
		[Token(Token = "0x601146A")]
		[Address(RVA = "0x1CB2A74", Offset = "0x1CB2A74", VA = "0x1CB2A74")]
		public LeagueMember? Members(int j)
		{
			return null;
		}

		// Token: 0x1700211A RID: 8474
		// (get) Token: 0x0601146B RID: 70763 RVA: 0x00067458 File Offset: 0x00065658
		[Token(Token = "0x1700211A")]
		public int MembersLength
		{
			[Token(Token = "0x601146B")]
			[Address(RVA = "0x1CB2B4C", Offset = "0x1CB2B4C", VA = "0x1CB2B4C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700211B RID: 8475
		// (get) Token: 0x0601146C RID: 70764 RVA: 0x00067470 File Offset: 0x00065670
		[Token(Token = "0x1700211B")]
		public LeagueConfig? DepreciatedLeagueConfig
		{
			[Token(Token = "0x601146C")]
			[Address(RVA = "0x1CB2B80", Offset = "0x1CB2B80", VA = "0x1CB2B80")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700211C RID: 8476
		// (get) Token: 0x0601146D RID: 70765 RVA: 0x00067488 File Offset: 0x00065688
		[Token(Token = "0x1700211C")]
		public LeagueConfig? Config
		{
			[Token(Token = "0x601146D")]
			[Address(RVA = "0x1CB2C40", Offset = "0x1CB2C40", VA = "0x1CB2C40")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700211D RID: 8477
		// (get) Token: 0x0601146E RID: 70766 RVA: 0x000674A0 File Offset: 0x000656A0
		[Token(Token = "0x1700211D")]
		public long RemainingTime
		{
			[Token(Token = "0x601146E")]
			[Address(RVA = "0x1CB2D00", Offset = "0x1CB2D00", VA = "0x1CB2D00")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x0601146F RID: 70767 RVA: 0x000674B8 File Offset: 0x000656B8
		[Token(Token = "0x601146F")]
		[Address(RVA = "0x1CB2D48", Offset = "0x1CB2D48", VA = "0x1CB2D48")]
		public static Offset<GetLeagueInfoResponse> CreateGetLeagueInfoResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, [Optional] VectorOffset membersOffset, [Optional] Offset<LeagueConfig> depreciated_league_configOffset, [Optional] Offset<LeagueConfig> configOffset, long remaining_time = 0L)
		{
			return default(Offset<GetLeagueInfoResponse>);
		}

		// Token: 0x06011470 RID: 70768 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011470")]
		[Address(RVA = "0x1CB2EEC", Offset = "0x1CB2EEC", VA = "0x1CB2EEC")]
		public static void StartGetLeagueInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011471 RID: 70769 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011471")]
		[Address(RVA = "0x1CB2E60", Offset = "0x1CB2E60", VA = "0x1CB2E60")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06011472 RID: 70770 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011472")]
		[Address(RVA = "0x1CB2E40", Offset = "0x1CB2E40", VA = "0x1CB2E40")]
		public static void AddMembers(FlatBufferBuilder builder, VectorOffset membersOffset)
		{
		}

		// Token: 0x06011473 RID: 70771 RVA: 0x000674D0 File Offset: 0x000656D0
		[Token(Token = "0x6011473")]
		[Address(RVA = "0x1CB2F04", Offset = "0x1CB2F04", VA = "0x1CB2F04")]
		public static VectorOffset CreateMembersVector(FlatBufferBuilder builder, Offset<LeagueMember>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011474 RID: 70772 RVA: 0x000674E8 File Offset: 0x000656E8
		[Token(Token = "0x6011474")]
		[Address(RVA = "0x1CB2FAC", Offset = "0x1CB2FAC", VA = "0x1CB2FAC")]
		public static VectorOffset CreateMembersVectorBlock(FlatBufferBuilder builder, Offset<LeagueMember>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011475 RID: 70773 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011475")]
		[Address(RVA = "0x1CB3034", Offset = "0x1CB3034", VA = "0x1CB3034")]
		public static void StartMembersVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011476 RID: 70774 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011476")]
		[Address(RVA = "0x1CB2E20", Offset = "0x1CB2E20", VA = "0x1CB2E20")]
		public static void AddDepreciatedLeagueConfig(FlatBufferBuilder builder, Offset<LeagueConfig> depreciatedLeagueConfigOffset)
		{
		}

		// Token: 0x06011477 RID: 70775 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011477")]
		[Address(RVA = "0x1CB2E00", Offset = "0x1CB2E00", VA = "0x1CB2E00")]
		public static void AddConfig(FlatBufferBuilder builder, Offset<LeagueConfig> configOffset)
		{
		}

		// Token: 0x06011478 RID: 70776 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011478")]
		[Address(RVA = "0x1CB2DE0", Offset = "0x1CB2DE0", VA = "0x1CB2DE0")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06011479 RID: 70777 RVA: 0x00067500 File Offset: 0x00065700
		[Token(Token = "0x6011479")]
		[Address(RVA = "0x1CB2E80", Offset = "0x1CB2E80", VA = "0x1CB2E80")]
		public static Offset<GetLeagueInfoResponse> EndGetLeagueInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetLeagueInfoResponse>);
		}

		// Token: 0x0400E751 RID: 59217
		[Token(Token = "0x400E751")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
