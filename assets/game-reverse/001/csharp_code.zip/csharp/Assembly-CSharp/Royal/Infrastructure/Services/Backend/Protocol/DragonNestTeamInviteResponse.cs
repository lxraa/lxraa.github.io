﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200238E RID: 9102
	[Token(Token = "0x200238E")]
	public struct DragonNestTeamInviteResponse : IFlatbufferObject
	{
		// Token: 0x17001FFD RID: 8189
		// (get) Token: 0x06011004 RID: 69636 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FFD")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011004")]
			[Address(RVA = "0x1F99250", Offset = "0x1F99250", VA = "0x1F99250", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011005 RID: 69637 RVA: 0x00063918 File Offset: 0x00061B18
		[Token(Token = "0x6011005")]
		[Address(RVA = "0x1F99258", Offset = "0x1F99258", VA = "0x1F99258")]
		public static DragonNestTeamInviteResponse GetRootAsDragonNestTeamInviteResponse(ByteBuffer _bb)
		{
			return default(DragonNestTeamInviteResponse);
		}

		// Token: 0x06011006 RID: 69638 RVA: 0x00063930 File Offset: 0x00061B30
		[Token(Token = "0x6011006")]
		[Address(RVA = "0x1F99264", Offset = "0x1F99264", VA = "0x1F99264")]
		public static DragonNestTeamInviteResponse GetRootAsDragonNestTeamInviteResponse(ByteBuffer _bb, DragonNestTeamInviteResponse obj)
		{
			return default(DragonNestTeamInviteResponse);
		}

		// Token: 0x06011007 RID: 69639 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011007")]
		[Address(RVA = "0x1F99314", Offset = "0x1F99314", VA = "0x1F99314", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011008 RID: 69640 RVA: 0x00063948 File Offset: 0x00061B48
		[Token(Token = "0x6011008")]
		[Address(RVA = "0x1F992DC", Offset = "0x1F992DC", VA = "0x1F992DC")]
		public DragonNestTeamInviteResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestTeamInviteResponse);
		}

		// Token: 0x17001FFE RID: 8190
		// (get) Token: 0x06011009 RID: 69641 RVA: 0x00063960 File Offset: 0x00061B60
		[Token(Token = "0x17001FFE")]
		public UserInfo? UserInfo
		{
			[Token(Token = "0x6011009")]
			[Address(RVA = "0x1F99324", Offset = "0x1F99324", VA = "0x1F99324")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FFF RID: 8191
		// (get) Token: 0x0601100A RID: 69642 RVA: 0x00063978 File Offset: 0x00061B78
		[Token(Token = "0x17001FFF")]
		public ChatProfile? ChatProfile
		{
			[Token(Token = "0x601100A")]
			[Address(RVA = "0x1F993E4", Offset = "0x1F993E4", VA = "0x1F993E4")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002000 RID: 8192
		// (get) Token: 0x0601100B RID: 69643 RVA: 0x00063990 File Offset: 0x00061B90
		[Token(Token = "0x17002000")]
		public long InviteDate
		{
			[Token(Token = "0x601100B")]
			[Address(RVA = "0x1F994A4", Offset = "0x1F994A4", VA = "0x1F994A4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x0601100C RID: 69644 RVA: 0x000639A8 File Offset: 0x00061BA8
		[Token(Token = "0x601100C")]
		[Address(RVA = "0x1F994EC", Offset = "0x1F994EC", VA = "0x1F994EC")]
		public static Offset<DragonNestTeamInviteResponse> CreateDragonNestTeamInviteResponse(FlatBufferBuilder builder, [Optional] Offset<UserInfo> user_infoOffset, [Optional] Offset<ChatProfile> chat_profileOffset, long invite_date = 0L)
		{
			return default(Offset<DragonNestTeamInviteResponse>);
		}

		// Token: 0x0601100D RID: 69645 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601100D")]
		[Address(RVA = "0x1F99628", Offset = "0x1F99628", VA = "0x1F99628")]
		public static void StartDragonNestTeamInviteResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601100E RID: 69646 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601100E")]
		[Address(RVA = "0x1F9959C", Offset = "0x1F9959C", VA = "0x1F9959C")]
		public static void AddUserInfo(FlatBufferBuilder builder, Offset<UserInfo> userInfoOffset)
		{
		}

		// Token: 0x0601100F RID: 69647 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601100F")]
		[Address(RVA = "0x1F9957C", Offset = "0x1F9957C", VA = "0x1F9957C")]
		public static void AddChatProfile(FlatBufferBuilder builder, Offset<ChatProfile> chatProfileOffset)
		{
		}

		// Token: 0x06011010 RID: 69648 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011010")]
		[Address(RVA = "0x1F9955C", Offset = "0x1F9955C", VA = "0x1F9955C")]
		public static void AddInviteDate(FlatBufferBuilder builder, long inviteDate)
		{
		}

		// Token: 0x06011011 RID: 69649 RVA: 0x000639C0 File Offset: 0x00061BC0
		[Token(Token = "0x6011011")]
		[Address(RVA = "0x1F995BC", Offset = "0x1F995BC", VA = "0x1F995BC")]
		public static Offset<DragonNestTeamInviteResponse> EndDragonNestTeamInviteResponse(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestTeamInviteResponse>);
		}

		// Token: 0x0400E6A7 RID: 59047
		[Token(Token = "0x400E6A7")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
