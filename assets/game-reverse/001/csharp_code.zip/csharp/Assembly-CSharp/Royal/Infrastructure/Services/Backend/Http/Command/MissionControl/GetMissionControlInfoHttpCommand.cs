﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.MissionControl
{
	// Token: 0x02002558 RID: 9560
	[Token(Token = "0x2002558")]
	public class GetMissionControlInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002771 RID: 10097
		// (get) Token: 0x06012AED RID: 76525 RVA: 0x00078A80 File Offset: 0x00076C80
		[Token(Token = "0x17002771")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AED")]
			[Address(RVA = "0x1ECE5A4", Offset = "0x1ECE5A4", VA = "0x1ECE5A4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002772 RID: 10098
		// (get) Token: 0x06012AEE RID: 76526 RVA: 0x00078A98 File Offset: 0x00076C98
		[Token(Token = "0x17002772")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AEE")]
			[Address(RVA = "0x1ECE5AC", Offset = "0x1ECE5AC", VA = "0x1ECE5AC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AEF RID: 76527 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AEF")]
		[Address(RVA = "0x1ECE5B4", Offset = "0x1ECE5B4", VA = "0x1ECE5B4")]
		public GetMissionControlInfoHttpCommand(int eventId)
		{
		}

		// Token: 0x06012AF0 RID: 76528 RVA: 0x00078AB0 File Offset: 0x00076CB0
		[Token(Token = "0x6012AF0")]
		[Address(RVA = "0x1ECE5E4", Offset = "0x1ECE5E4", VA = "0x1ECE5E4", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012AF1 RID: 76529 RVA: 0x00078AC8 File Offset: 0x00076CC8
		[Token(Token = "0x6012AF1")]
		[Address(RVA = "0x1ECE6A4", Offset = "0x1ECE6A4", VA = "0x1ECE6A4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AF2 RID: 76530 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AF2")]
		[Address(RVA = "0x1ECE6C4", Offset = "0x1ECE6C4", VA = "0x1ECE6C4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AF3 RID: 76531 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AF3")]
		[Address(RVA = "0x1ECE79C", Offset = "0x1ECE79C", VA = "0x1ECE79C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBAF RID: 60335
		[Token(Token = "0x400EBAF")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;
	}
}
