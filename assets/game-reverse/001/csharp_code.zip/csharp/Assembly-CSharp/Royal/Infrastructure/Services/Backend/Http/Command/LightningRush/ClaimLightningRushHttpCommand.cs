﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.LightningRush
{
	// Token: 0x0200255A RID: 9562
	[Token(Token = "0x200255A")]
	public class ClaimLightningRushHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002775 RID: 10101
		// (get) Token: 0x06012AFB RID: 76539 RVA: 0x00078B40 File Offset: 0x00076D40
		[Token(Token = "0x17002775")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AFB")]
			[Address(RVA = "0x1ECE99C", Offset = "0x1ECE99C", VA = "0x1ECE99C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002776 RID: 10102
		// (get) Token: 0x06012AFC RID: 76540 RVA: 0x00078B58 File Offset: 0x00076D58
		[Token(Token = "0x17002776")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AFC")]
			[Address(RVA = "0x1ECE9A4", Offset = "0x1ECE9A4", VA = "0x1ECE9A4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AFD RID: 76541 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AFD")]
		[Address(RVA = "0x1ECE9AC", Offset = "0x1ECE9AC", VA = "0x1ECE9AC")]
		public ClaimLightningRushHttpCommand(long group)
		{
		}

		// Token: 0x17002777 RID: 10103
		// (get) Token: 0x06012AFE RID: 76542 RVA: 0x00078B70 File Offset: 0x00076D70
		// (set) Token: 0x06012AFF RID: 76543 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002777")]
		public ClaimLightningRushResponse Response
		{
			[Token(Token = "0x6012AFE")]
			[Address(RVA = "0x1ECE9D4", Offset = "0x1ECE9D4", VA = "0x1ECE9D4")]
			get
			{
				return default(ClaimLightningRushResponse);
			}
			[Token(Token = "0x6012AFF")]
			[Address(RVA = "0x1ECE9E0", Offset = "0x1ECE9E0", VA = "0x1ECE9E0")]
			set
			{
			}
		}

		// Token: 0x06012B00 RID: 76544 RVA: 0x00078B88 File Offset: 0x00076D88
		[Token(Token = "0x6012B00")]
		[Address(RVA = "0x1ECE9F0", Offset = "0x1ECE9F0", VA = "0x1ECE9F0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B01 RID: 76545 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B01")]
		[Address(RVA = "0x1ECEB08", Offset = "0x1ECEB08", VA = "0x1ECEB08", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B02 RID: 76546 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B02")]
		[Address(RVA = "0x1ECED20", Offset = "0x1ECED20", VA = "0x1ECED20", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBB1 RID: 60337
		[Token(Token = "0x400EBB1")]
		[FieldOffset(Offset = "0x18")]
		private long groupId;

		// Token: 0x0400EBB2 RID: 60338
		[Token(Token = "0x400EBB2")]
		[FieldOffset(Offset = "0x20")]
		private ClaimLightningRushResponse <Response>k__BackingField;
	}
}
