﻿using System;
using Il2CppDummyDll;
using Royal.Player.Context.Data.Session;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002590 RID: 9616
	[Token(Token = "0x2002590")]
	public class BatteryUsageAnalyticsHelper
	{
		// Token: 0x170027D8 RID: 10200
		// (get) Token: 0x06012D3C RID: 77116 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170027D8")]
		private static AnalyticsManager AnalyticsManager
		{
			[Token(Token = "0x6012D3C")]
			[Address(RVA = "0x243A20C", Offset = "0x243A20C", VA = "0x243A20C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06012D3D RID: 77117 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D3D")]
		[Address(RVA = "0x243A2C0", Offset = "0x243A2C0", VA = "0x243A2C0")]
		public void Start(bool reset = true)
		{
		}

		// Token: 0x06012D3E RID: 77118 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D3E")]
		[Address(RVA = "0x243A30C", Offset = "0x243A30C", VA = "0x243A30C")]
		public void ManualUpdate()
		{
		}

		// Token: 0x06012D3F RID: 77119 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D3F")]
		[Address(RVA = "0x243A438", Offset = "0x243A438", VA = "0x243A438")]
		public void LevelStartOrReload(UserActiveLevelData levelData)
		{
		}

		// Token: 0x06012D40 RID: 77120 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D40")]
		[Address(RVA = "0x243A460", Offset = "0x243A460", VA = "0x243A460")]
		public BatteryUsageAnalyticsHelper()
		{
		}

		// Token: 0x0400ECB4 RID: 60596
		[Token(Token = "0x400ECB4")]
		private const int RequiredMinutesToSendBatteryEvt = 30;

		// Token: 0x0400ECB5 RID: 60597
		[Token(Token = "0x400ECB5")]
		private const int RequiredMinutesToCheckBattery = 1;

		// Token: 0x0400ECB6 RID: 60598
		[Token(Token = "0x400ECB6")]
		[FieldOffset(Offset = "0x10")]
		private float lastBatteryEventSentTime;

		// Token: 0x0400ECB7 RID: 60599
		[Token(Token = "0x400ECB7")]
		[FieldOffset(Offset = "0x14")]
		private float lastBatteryStatusCheckTime;

		// Token: 0x0400ECB8 RID: 60600
		[Token(Token = "0x400ECB8")]
		[FieldOffset(Offset = "0x18")]
		private float batteryAtStart;

		// Token: 0x0400ECB9 RID: 60601
		[Token(Token = "0x400ECB9")]
		[FieldOffset(Offset = "0x1C")]
		private int levelStartCount;

		// Token: 0x0400ECBA RID: 60602
		[Token(Token = "0x400ECBA")]
		[FieldOffset(Offset = "0x20")]
		private int levelStartCountLowPower;

		// Token: 0x0400ECBB RID: 60603
		[Token(Token = "0x400ECBB")]
		[FieldOffset(Offset = "0x24")]
		private int evtCount;

		// Token: 0x0400ECBC RID: 60604
		[Token(Token = "0x400ECBC")]
		[FieldOffset(Offset = "0x0")]
		private static AnalyticsManager ManagerInstance;
	}
}
