﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using Royal.Infrastructure.UiComponents.Dialog;
using Royal.Infrastructure.Utils.Counters;

namespace Royal.Infrastructure.Contexts.Units.App.BackButton
{
	// Token: 0x020025C6 RID: 9670
	[Token(Token = "0x20025C6")]
	public class BackButtonListener
	{
		// Token: 0x06012EBB RID: 77499 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EBB")]
		[Address(RVA = "0x244FF28", Offset = "0x244FF28", VA = "0x244FF28")]
		public BackButtonListener()
		{
		}

		// Token: 0x06012EBC RID: 77500 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EBC")]
		[Address(RVA = "0x244FFF0", Offset = "0x244FFF0", VA = "0x244FFF0")]
		public void Bind()
		{
		}

		// Token: 0x06012EBD RID: 77501 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EBD")]
		[Address(RVA = "0x2450160", Offset = "0x2450160", VA = "0x2450160")]
		public void ManualUpdate()
		{
		}

		// Token: 0x06012EBE RID: 77502 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EBE")]
		[Address(RVA = "0x24501A4", Offset = "0x24501A4", VA = "0x24501A4")]
		private void PressBack()
		{
		}

		// Token: 0x06012EBF RID: 77503 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EBF")]
		[Address(RVA = "0x24502B8", Offset = "0x24502B8", VA = "0x24502B8")]
		public void AddBackable(IBackable backable)
		{
		}

		// Token: 0x06012EC0 RID: 77504 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC0")]
		[Address(RVA = "0x24503A0", Offset = "0x24503A0", VA = "0x24503A0")]
		public void RemoveBackable(IBackable backable)
		{
		}

		// Token: 0x06012EC1 RID: 77505 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC1")]
		[Address(RVA = "0x2450430", Offset = "0x2450430", VA = "0x2450430")]
		public void Reset()
		{
		}

		// Token: 0x06012EC2 RID: 77506 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC2")]
		[Address(RVA = "0x245044C", Offset = "0x245044C", VA = "0x245044C")]
		public void Enable()
		{
		}

		// Token: 0x06012EC3 RID: 77507 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EC3")]
		[Address(RVA = "0x2450468", Offset = "0x2450468", VA = "0x2450468")]
		public void Disable()
		{
		}

		// Token: 0x0400EEC3 RID: 61123
		[Token(Token = "0x400EEC3")]
		[FieldOffset(Offset = "0x10")]
		private readonly EnableCounter enableCounter;

		// Token: 0x0400EEC4 RID: 61124
		[Token(Token = "0x400EEC4")]
		[FieldOffset(Offset = "0x18")]
		private readonly List<IBackable> backables;

		// Token: 0x0400EEC5 RID: 61125
		[Token(Token = "0x400EEC5")]
		[FieldOffset(Offset = "0x20")]
		private DialogManager dialogManager;
	}
}
