﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200233C RID: 9020
	[Token(Token = "0x200233C")]
	public struct ArcheryArenaRefreshInfo : IFlatbufferObject
	{
		// Token: 0x17001EBD RID: 7869
		// (get) Token: 0x06010B5F RID: 68447 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EBD")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B5F")]
			[Address(RVA = "0x21426F8", Offset = "0x21426F8", VA = "0x21426F8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B60 RID: 68448 RVA: 0x0005FCD0 File Offset: 0x0005DED0
		[Token(Token = "0x6010B60")]
		[Address(RVA = "0x2142700", Offset = "0x2142700", VA = "0x2142700")]
		public static ArcheryArenaRefreshInfo GetRootAsArcheryArenaRefreshInfo(ByteBuffer _bb)
		{
			return default(ArcheryArenaRefreshInfo);
		}

		// Token: 0x06010B61 RID: 68449 RVA: 0x0005FCE8 File Offset: 0x0005DEE8
		[Token(Token = "0x6010B61")]
		[Address(RVA = "0x214270C", Offset = "0x214270C", VA = "0x214270C")]
		public static ArcheryArenaRefreshInfo GetRootAsArcheryArenaRefreshInfo(ByteBuffer _bb, ArcheryArenaRefreshInfo obj)
		{
			return default(ArcheryArenaRefreshInfo);
		}

		// Token: 0x06010B62 RID: 68450 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B62")]
		[Address(RVA = "0x21427BC", Offset = "0x21427BC", VA = "0x21427BC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B63 RID: 68451 RVA: 0x0005FD00 File Offset: 0x0005DF00
		[Token(Token = "0x6010B63")]
		[Address(RVA = "0x2142784", Offset = "0x2142784", VA = "0x2142784")]
		public ArcheryArenaRefreshInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(ArcheryArenaRefreshInfo);
		}

		// Token: 0x17001EBE RID: 7870
		// (get) Token: 0x06010B64 RID: 68452 RVA: 0x0005FD18 File Offset: 0x0005DF18
		[Token(Token = "0x17001EBE")]
		public ArcheryArenaInfo? ArcheryArenaInfo
		{
			[Token(Token = "0x6010B64")]
			[Address(RVA = "0x21427CC", Offset = "0x21427CC", VA = "0x21427CC")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001EBF RID: 7871
		// (get) Token: 0x06010B65 RID: 68453 RVA: 0x0005FD30 File Offset: 0x0005DF30
		[Token(Token = "0x17001EBF")]
		public long ArcheryArenaGroupId
		{
			[Token(Token = "0x6010B65")]
			[Address(RVA = "0x2142884", Offset = "0x2142884", VA = "0x2142884")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001EC0 RID: 7872
		// (get) Token: 0x06010B66 RID: 68454 RVA: 0x0005FD48 File Offset: 0x0005DF48
		[Token(Token = "0x17001EC0")]
		public int ArcheryArenaRank
		{
			[Token(Token = "0x6010B66")]
			[Address(RVA = "0x21428CC", Offset = "0x21428CC", VA = "0x21428CC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010B67 RID: 68455 RVA: 0x0005FD60 File Offset: 0x0005DF60
		[Token(Token = "0x6010B67")]
		[Address(RVA = "0x2142910", Offset = "0x2142910", VA = "0x2142910")]
		public static Offset<ArcheryArenaRefreshInfo> CreateArcheryArenaRefreshInfo(FlatBufferBuilder builder, [Optional] Offset<ArcheryArenaInfo> archery_arena_infoOffset, long archery_arena_group_id = 0L, int archery_arena_rank = 0)
		{
			return default(Offset<ArcheryArenaRefreshInfo>);
		}

		// Token: 0x06010B68 RID: 68456 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B68")]
		[Address(RVA = "0x2142A4C", Offset = "0x2142A4C", VA = "0x2142A4C")]
		public static void StartArcheryArenaRefreshInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B69 RID: 68457 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B69")]
		[Address(RVA = "0x21429C0", Offset = "0x21429C0", VA = "0x21429C0")]
		public static void AddArcheryArenaInfo(FlatBufferBuilder builder, Offset<ArcheryArenaInfo> archeryArenaInfoOffset)
		{
		}

		// Token: 0x06010B6A RID: 68458 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B6A")]
		[Address(RVA = "0x2142980", Offset = "0x2142980", VA = "0x2142980")]
		public static void AddArcheryArenaGroupId(FlatBufferBuilder builder, long archeryArenaGroupId)
		{
		}

		// Token: 0x06010B6B RID: 68459 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B6B")]
		[Address(RVA = "0x21429A0", Offset = "0x21429A0", VA = "0x21429A0")]
		public static void AddArcheryArenaRank(FlatBufferBuilder builder, int archeryArenaRank)
		{
		}

		// Token: 0x06010B6C RID: 68460 RVA: 0x0005FD78 File Offset: 0x0005DF78
		[Token(Token = "0x6010B6C")]
		[Address(RVA = "0x21429E0", Offset = "0x21429E0", VA = "0x21429E0")]
		public static Offset<ArcheryArenaRefreshInfo> EndArcheryArenaRefreshInfo(FlatBufferBuilder builder)
		{
			return default(Offset<ArcheryArenaRefreshInfo>);
		}

		// Token: 0x0400E61D RID: 58909
		[Token(Token = "0x400E61D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
