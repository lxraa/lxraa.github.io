﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002520 RID: 9504
	[Token(Token = "0x2002520")]
	public class UpdatePGSHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026EE RID: 9966
		// (get) Token: 0x06012944 RID: 76100 RVA: 0x00077850 File Offset: 0x00075A50
		[Token(Token = "0x170026EE")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012944")]
			[Address(RVA = "0x1CF2FF4", Offset = "0x1CF2FF4", VA = "0x1CF2FF4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026EF RID: 9967
		// (get) Token: 0x06012945 RID: 76101 RVA: 0x00077868 File Offset: 0x00075A68
		[Token(Token = "0x170026EF")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012945")]
			[Address(RVA = "0x1CF2FFC", Offset = "0x1CF2FFC", VA = "0x1CF2FFC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026F0 RID: 9968
		// (get) Token: 0x06012946 RID: 76102 RVA: 0x00077880 File Offset: 0x00075A80
		// (set) Token: 0x06012947 RID: 76103 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026F0")]
		private UpdatePGSResponse Response
		{
			[Token(Token = "0x6012946")]
			[Address(RVA = "0x1CF3004", Offset = "0x1CF3004", VA = "0x1CF3004")]
			get
			{
				return default(UpdatePGSResponse);
			}
			[Token(Token = "0x6012947")]
			[Address(RVA = "0x1CF3010", Offset = "0x1CF3010", VA = "0x1CF3010")]
			set
			{
			}
		}

		// Token: 0x06012948 RID: 76104 RVA: 0x00077898 File Offset: 0x00075A98
		[Token(Token = "0x6012948")]
		[Address(RVA = "0x1CF3020", Offset = "0x1CF3020", VA = "0x1CF3020", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012949 RID: 76105 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012949")]
		[Address(RVA = "0x1CF30C4", Offset = "0x1CF30C4", VA = "0x1CF30C4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x0601294A RID: 76106 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601294A")]
		[Address(RVA = "0x1CF3290", Offset = "0x1CF3290", VA = "0x1CF3290", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0601294B RID: 76107 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601294B")]
		[Address(RVA = "0x1CF3294", Offset = "0x1CF3294", VA = "0x1CF3294")]
		public UpdatePGSHttpCommand()
		{
		}

		// Token: 0x0400EB05 RID: 60165
		[Token(Token = "0x400EB05")]
		[FieldOffset(Offset = "0x18")]
		private UpdatePGSResponse <Response>k__BackingField;
	}
}
