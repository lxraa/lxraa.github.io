﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using Royal.Infrastructure.Contexts;
using Royal.Scenes.Start.Context.Units.Scene;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002586 RID: 9606
	[Token(Token = "0x2002586")]
	public class FileDownloadManager : IContextBehaviour, IContextUnit
	{
		// Token: 0x06012C49 RID: 76873 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C49")]
		[Address(RVA = "0x1EDBCF0", Offset = "0x1EDBCF0", VA = "0x1EDBCF0")]
		public FileDownloadManager()
		{
		}

		// Token: 0x170027CF RID: 10191
		// (get) Token: 0x06012C4A RID: 76874 RVA: 0x00079788 File Offset: 0x00077988
		[Token(Token = "0x170027CF")]
		public int Id
		{
			[Token(Token = "0x6012C4A")]
			[Address(RVA = "0x1EDBEAC", Offset = "0x1EDBEAC", VA = "0x1EDBEAC", Slot = "5")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06012C4B RID: 76875 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C4B")]
		[Address(RVA = "0x1EDBEB4", Offset = "0x1EDBEB4", VA = "0x1EDBEB4", Slot = "6")]
		public void Bind()
		{
		}

		// Token: 0x06012C4C RID: 76876 RVA: 0x000797A0 File Offset: 0x000779A0
		[Token(Token = "0x6012C4C")]
		[Address(RVA = "0x1EDBF30", Offset = "0x1EDBF30", VA = "0x1EDBF30")]
		private bool TryGetAvailableFileDownloader(out IFileDownloader fileDownloader)
		{
			return default(bool);
		}

		// Token: 0x06012C4D RID: 76877 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C4D")]
		[Address(RVA = "0x1EDB094", Offset = "0x1EDB094", VA = "0x1EDB094")]
		public void AddUnityWebRequestFileDownloader(IFileDownloader fileDownloader)
		{
		}

		// Token: 0x06012C4E RID: 76878 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C4E")]
		[Address(RVA = "0x1EDB644", Offset = "0x1EDB644", VA = "0x1EDB644")]
		public void RemoveUnityWebRequestFileDownloader(IFileDownloader fileDownloader)
		{
		}

		// Token: 0x06012C4F RID: 76879 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C4F")]
		[Address(RVA = "0x1EDC068", Offset = "0x1EDC068", VA = "0x1EDC068", Slot = "4")]
		public void ManualUpdate()
		{
		}

		// Token: 0x06012C50 RID: 76880 RVA: 0x000797B8 File Offset: 0x000779B8
		[Token(Token = "0x6012C50")]
		[Address(RVA = "0x1EDC304", Offset = "0x1EDC304", VA = "0x1EDC304")]
		private SceneType GetCurrentSceneType()
		{
			return SceneType.None;
		}

		// Token: 0x06012C51 RID: 76881 RVA: 0x000797D0 File Offset: 0x000779D0
		[Token(Token = "0x6012C51")]
		[Address(RVA = "0x1ED69D4", Offset = "0x1ED69D4", VA = "0x1ED69D4")]
		public int Download(string fileName, string url, string saveDirectory, Action onAddedToQueue, Action onDownloadStarted, Action<bool, string> onSaveComplete, FileDownloadSettings settings, bool isTexture = false)
		{
			return 0;
		}

		// Token: 0x06012C52 RID: 76882 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C52")]
		[Address(RVA = "0x1EDC64C", Offset = "0x1EDC64C", VA = "0x1EDC64C")]
		public List<FileDownloadInformation> GetDownloadQueue()
		{
			return null;
		}

		// Token: 0x06012C53 RID: 76883 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C53")]
		[Address(RVA = "0x1ED6C88", Offset = "0x1ED6C88", VA = "0x1ED6C88")]
		public void PrioritizeDownload(int downloadId)
		{
		}

		// Token: 0x06012C54 RID: 76884 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C54")]
		[Address(RVA = "0x1EDC358", Offset = "0x1EDC358", VA = "0x1EDC358")]
		private void AddToQueue(FileDownloadInformation downloadInformation, Action onAddedToQueue)
		{
		}

		// Token: 0x0400EC51 RID: 60497
		[Token(Token = "0x400EC51")]
		private const int DefaultDownloaderCount = 1;

		// Token: 0x0400EC52 RID: 60498
		[Token(Token = "0x400EC52")]
		private const int MaxDownloaderCount = 2;

		// Token: 0x0400EC53 RID: 60499
		[Token(Token = "0x400EC53")]
		private const int QueueCountThreshold = 20;

		// Token: 0x0400EC54 RID: 60500
		[Token(Token = "0x400EC54")]
		[FieldOffset(Offset = "0x0")]
		private static int DownloadItemId;

		// Token: 0x0400EC55 RID: 60501
		[Token(Token = "0x400EC55")]
		[FieldOffset(Offset = "0x10")]
		private readonly LinkedList<FileDownloadInformation> downloadQueue;

		// Token: 0x0400EC56 RID: 60502
		[Token(Token = "0x400EC56")]
		[FieldOffset(Offset = "0x18")]
		private readonly List<IFileDownloader> fileDownloaders;

		// Token: 0x0400EC57 RID: 60503
		[Token(Token = "0x400EC57")]
		[FieldOffset(Offset = "0x20")]
		private readonly List<IFileDownloader> unityWebRequestDownloaders;

		// Token: 0x0400EC58 RID: 60504
		[Token(Token = "0x400EC58")]
		[FieldOffset(Offset = "0x28")]
		private SceneChangeManager sceneChangeManager;
	}
}
