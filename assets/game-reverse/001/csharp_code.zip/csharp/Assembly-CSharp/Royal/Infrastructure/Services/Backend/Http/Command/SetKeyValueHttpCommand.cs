﻿using System;
using System.Collections.Generic;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x0200251D RID: 9501
	[Token(Token = "0x200251D")]
	public class SetKeyValueHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026E6 RID: 9958
		// (get) Token: 0x0601292D RID: 76077 RVA: 0x00077748 File Offset: 0x00075948
		[Token(Token = "0x170026E6")]
		public override RequestType RequestType
		{
			[Token(Token = "0x601292D")]
			[Address(RVA = "0x1CF10D0", Offset = "0x1CF10D0", VA = "0x1CF10D0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026E7 RID: 9959
		// (get) Token: 0x0601292E RID: 76078 RVA: 0x00077760 File Offset: 0x00075960
		[Token(Token = "0x170026E7")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x601292E")]
			[Address(RVA = "0x1CF10D8", Offset = "0x1CF10D8", VA = "0x1CF10D8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026E8 RID: 9960
		// (get) Token: 0x0601292F RID: 76079 RVA: 0x00077778 File Offset: 0x00075978
		// (set) Token: 0x06012930 RID: 76080 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026E8")]
		public SetKeyValueResponse Response
		{
			[Token(Token = "0x601292F")]
			[Address(RVA = "0x1CF10E0", Offset = "0x1CF10E0", VA = "0x1CF10E0")]
			get
			{
				return default(SetKeyValueResponse);
			}
			[Token(Token = "0x6012930")]
			[Address(RVA = "0x1CF10EC", Offset = "0x1CF10EC", VA = "0x1CF10EC")]
			set
			{
			}
		}

		// Token: 0x06012931 RID: 76081 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012931")]
		[Address(RVA = "0x1CF10FC", Offset = "0x1CF10FC", VA = "0x1CF10FC")]
		public SetKeyValueHttpCommand(string[] keys, long[] values, List<ValueTuple<ByteArrayKeyType, string>> byteArrayKeyValues, string origin)
		{
		}

		// Token: 0x06012932 RID: 76082 RVA: 0x00077790 File Offset: 0x00075990
		[Token(Token = "0x6012932")]
		[Address(RVA = "0x1CF1318", Offset = "0x1CF1318", VA = "0x1CF1318", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012933 RID: 76083 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012933")]
		[Address(RVA = "0x1CF1CA4", Offset = "0x1CF1CA4", VA = "0x1CF1CA4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012934 RID: 76084 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012934")]
		[Address(RVA = "0x1CF2094", Offset = "0x1CF2094", VA = "0x1CF2094")]
		private void SetKeySyncedStatus(string key)
		{
		}

		// Token: 0x06012935 RID: 76085 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012935")]
		[Address(RVA = "0x1CF20D8", Offset = "0x1CF20D8", VA = "0x1CF20D8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EAF1 RID: 60145
		[Token(Token = "0x400EAF1")]
		[FieldOffset(Offset = "0x18")]
		private SetKeyValueResponse <Response>k__BackingField;

		// Token: 0x0400EAF2 RID: 60146
		[Token(Token = "0x400EAF2")]
		[FieldOffset(Offset = "0x28")]
		private readonly string[] keys;

		// Token: 0x0400EAF3 RID: 60147
		[Token(Token = "0x400EAF3")]
		[FieldOffset(Offset = "0x30")]
		private readonly long[] values;

		// Token: 0x0400EAF4 RID: 60148
		[Token(Token = "0x400EAF4")]
		[FieldOffset(Offset = "0x38")]
		private readonly List<ValueTuple<ByteArrayKeyType, string>> byteArrayKeyValues;

		// Token: 0x0400EAF5 RID: 60149
		[Token(Token = "0x400EAF5")]
		[FieldOffset(Offset = "0x40")]
		private readonly string origin;

		// Token: 0x0400EAF6 RID: 60150
		[Token(Token = "0x400EAF6")]
		[FieldOffset(Offset = "0x48")]
		private readonly int commandId;

		// Token: 0x0400EAF7 RID: 60151
		[Token(Token = "0x400EAF7")]
		[FieldOffset(Offset = "0x0")]
		private static int CommandId;

		// Token: 0x0400EAF8 RID: 60152
		[Token(Token = "0x400EAF8")]
		[FieldOffset(Offset = "0x50")]
		private string keysInProgress;

		// Token: 0x0400EAF9 RID: 60153
		[Token(Token = "0x400EAF9")]
		[FieldOffset(Offset = "0x58")]
		private string valuesInProgress;
	}
}
