﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Il2CppDummyDll;
using Royal.Infrastructure.Contexts;
using Royal.Infrastructure.Services.Storage.Tables;
using Royal.Scenes.Home.Context;
using UnityEngine;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x0200257D RID: 9597
	[Token(Token = "0x200257D")]
	public class AreaDownloadManager : IContextUnit
	{
		// Token: 0x1400009E RID: 158
		// (add) Token: 0x06012BFA RID: 76794 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012BFB RID: 76795 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1400009E")]
		public event Action<int> OnAssetBundleDownloaded
		{
			[Token(Token = "0x6012BFA")]
			[Address(RVA = "0x1ED7B34", Offset = "0x1ED7B34", VA = "0x1ED7B34")]
			add
			{
			}
			[Token(Token = "0x6012BFB")]
			[Address(RVA = "0x1ED7BE4", Offset = "0x1ED7BE4", VA = "0x1ED7BE4")]
			remove
			{
			}
		}

		// Token: 0x170027C6 RID: 10182
		// (get) Token: 0x06012BFC RID: 76796 RVA: 0x000796B0 File Offset: 0x000778B0
		[Token(Token = "0x170027C6")]
		public int Id
		{
			[Token(Token = "0x6012BFC")]
			[Address(RVA = "0x1ED7C94", Offset = "0x1ED7C94", VA = "0x1ED7C94", Slot = "4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06012BFD RID: 76797 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BFD")]
		[Address(RVA = "0x1ED7C9C", Offset = "0x1ED7C9C", VA = "0x1ED7C9C", Slot = "5")]
		public void Bind()
		{
		}

		// Token: 0x06012BFE RID: 76798 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BFE")]
		[Address(RVA = "0x1ED7E54", Offset = "0x1ED7E54", VA = "0x1ED7E54")]
		private void OnFirstActivate()
		{
		}

		// Token: 0x06012BFF RID: 76799 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BFF")]
		[Address(RVA = "0x1ED8514", Offset = "0x1ED8514", VA = "0x1ED8514")]
		public void CheckDownloadableAreas()
		{
		}

		// Token: 0x06012C00 RID: 76800 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C00")]
		[Address(RVA = "0x1ED87E8", Offset = "0x1ED87E8", VA = "0x1ED87E8")]
		public void OnUserAreaDataUpdated()
		{
		}

		// Token: 0x06012C01 RID: 76801 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C01")]
		[Address(RVA = "0x1ED7DB4", Offset = "0x1ED7DB4", VA = "0x1ED7DB4")]
		private void CopyAreasFromStreamingAssets()
		{
		}

		// Token: 0x06012C02 RID: 76802 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C02")]
		[Address(RVA = "0x1ED8518", Offset = "0x1ED8518", VA = "0x1ED8518")]
		private void StartDownloadingAreas()
		{
		}

		// Token: 0x06012C03 RID: 76803 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C03")]
		[Address(RVA = "0x1ED8098", Offset = "0x1ED8098", VA = "0x1ED8098")]
		private void DeleteUnusedAreaBundles()
		{
		}

		// Token: 0x06012C04 RID: 76804 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C04")]
		[Address(RVA = "0x1ED88F4", Offset = "0x1ED88F4", VA = "0x1ED88F4")]
		public void DownloadRequiredArea(int areaId, Action<bool> onAreaDownloadComplete)
		{
		}

		// Token: 0x06012C05 RID: 76805 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C05")]
		[Address(RVA = "0x1ED8854", Offset = "0x1ED8854", VA = "0x1ED8854")]
		private void DownloadArea(int areaId)
		{
		}

		// Token: 0x06012C06 RID: 76806 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C06")]
		[Address(RVA = "0x1ED8D54", Offset = "0x1ED8D54", VA = "0x1ED8D54")]
		private void DownloadRequiredNowArea(int areaId, AreaDownloader areaDownloader)
		{
		}

		// Token: 0x06012C07 RID: 76807 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C07")]
		[Address(RVA = "0x1ED8B34", Offset = "0x1ED8B34", VA = "0x1ED8B34")]
		private void DownloadUserRequiredAreaWithTimeout(int areaId, AreaDownloader areaDownloader)
		{
		}

		// Token: 0x06012C08 RID: 76808 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C08")]
		[Address(RVA = "0x1ED8A64", Offset = "0x1ED8A64", VA = "0x1ED8A64")]
		private AreaDownloader GetAreaDownloader(int areaId)
		{
			return null;
		}

		// Token: 0x06012C09 RID: 76809 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C09")]
		[Address(RVA = "0x1ED6E08", Offset = "0x1ED6E08", VA = "0x1ED6E08")]
		public void AreaAndExtraFilesSaved(bool success, AreaDownloader areaDownloader)
		{
		}

		// Token: 0x06012C0A RID: 76810 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C0A")]
		[Address(RVA = "0x1ED7EF4", Offset = "0x1ED7EF4", VA = "0x1ED7EF4")]
		public void EnableAreaDownloadTriggers(bool checkNextFocus = true, bool checkNextHomeActivate = true)
		{
		}

		// Token: 0x06012C0B RID: 76811 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C0B")]
		[Address(RVA = "0x1ED9094", Offset = "0x1ED9094", VA = "0x1ED9094")]
		private void OnAreaDownloadTriggerActivated()
		{
		}

		// Token: 0x06012C0C RID: 76812 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C0C")]
		[Address(RVA = "0x1ED8F88", Offset = "0x1ED8F88", VA = "0x1ED8F88")]
		private void StartRequiredAreaTimeoutCoroutine(AreaDownloader areaDownloader)
		{
		}

		// Token: 0x06012C0D RID: 76813 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C0D")]
		[Address(RVA = "0x1ED9018", Offset = "0x1ED9018", VA = "0x1ED9018")]
		private void StopTimeoutCoroutine()
		{
		}

		// Token: 0x06012C0E RID: 76814 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C0E")]
		[Address(RVA = "0x1ED91F8", Offset = "0x1ED91F8", VA = "0x1ED91F8")]
		private IEnumerator RequiredAreaDownloadTimeout(AreaDownloader areaDownloader)
		{
			return null;
		}

		// Token: 0x06012C0F RID: 76815 RVA: 0x000796C8 File Offset: 0x000778C8
		[Token(Token = "0x6012C0F")]
		[Address(RVA = "0x1ED92B0", Offset = "0x1ED92B0", VA = "0x1ED92B0")]
		public static bool IsAreaAndExtraBundleExistInFileSystem(int areaId)
		{
			return default(bool);
		}

		// Token: 0x06012C10 RID: 76816 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C10")]
		[Address(RVA = "0x1ED9304", Offset = "0x1ED9304", VA = "0x1ED9304")]
		public static string GetPersistentBundlePath(string bundleName)
		{
			return null;
		}

		// Token: 0x06012C11 RID: 76817 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C11")]
		[Address(RVA = "0x1ED88A0", Offset = "0x1ED88A0", VA = "0x1ED88A0")]
		public static string GetAreaBundleName(int areaId)
		{
			return null;
		}

		// Token: 0x06012C12 RID: 76818 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C12")]
		[Address(RVA = "0x1ED9358", Offset = "0x1ED9358", VA = "0x1ED9358")]
		public static string GetExtraBundleName(int areaId)
		{
			return null;
		}

		// Token: 0x06012C13 RID: 76819 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C13")]
		[Address(RVA = "0x1ED93AC", Offset = "0x1ED93AC", VA = "0x1ED93AC")]
		public List<AreaDownloader> GetAreaDownloaders()
		{
			return null;
		}

		// Token: 0x06012C14 RID: 76820 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C14")]
		[Address(RVA = "0x1ED95BC", Offset = "0x1ED95BC", VA = "0x1ED95BC")]
		public AreaDownloadManager()
		{
		}

		// Token: 0x0400EC25 RID: 60453
		[Token(Token = "0x400EC25")]
		private const int StartDownloadMinLevel = 10;

		// Token: 0x0400EC27 RID: 60455
		[Token(Token = "0x400EC27")]
		[FieldOffset(Offset = "0x18")]
		private readonly Dictionary<int, AreaDownloader> areaDownloaders;

		// Token: 0x0400EC28 RID: 60456
		[Token(Token = "0x400EC28")]
		[FieldOffset(Offset = "0x20")]
		private bool areaDownloadDelayed;

		// Token: 0x0400EC29 RID: 60457
		[Token(Token = "0x400EC29")]
		[FieldOffset(Offset = "0x28")]
		private Coroutine timeoutCoroutine;

		// Token: 0x0400EC2A RID: 60458
		[Token(Token = "0x400EC2A")]
		private const int AreaDownloadUpperThreshold = 5;

		// Token: 0x0400EC2B RID: 60459
		[Token(Token = "0x400EC2B")]
		private const int AreaDeleteLowerThreshold = 2;

		// Token: 0x0400EC2C RID: 60460
		[Token(Token = "0x400EC2C")]
		private const int FirstDownloadableAreaId = 4;

		// Token: 0x0400EC2D RID: 60461
		[Token(Token = "0x400EC2D")]
		[FieldOffset(Offset = "0x30")]
		private HomeContext homeContext;

		// Token: 0x0200257E RID: 9598
		[Token(Token = "0x200257E")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06012C16 RID: 76822 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012C16")]
			[Address(RVA = "0x1ED96B4", Offset = "0x1ED96B4", VA = "0x1ED96B4")]
			public <>c()
			{
			}

			// Token: 0x06012C17 RID: 76823 RVA: 0x000796E0 File Offset: 0x000778E0
			[Token(Token = "0x6012C17")]
			[Address(RVA = "0x1ED96BC", Offset = "0x1ED96BC", VA = "0x1ED96BC")]
			internal int <DeleteUnusedAreaBundles>b__19_0(UserRegisterTableItem x)
			{
				return 0;
			}

			// Token: 0x0400EC2E RID: 60462
			[Token(Token = "0x400EC2E")]
			[FieldOffset(Offset = "0x0")]
			public static readonly AreaDownloadManager.<>c <>9;

			// Token: 0x0400EC2F RID: 60463
			[Token(Token = "0x400EC2F")]
			[FieldOffset(Offset = "0x8")]
			public static Func<UserRegisterTableItem, int> <>9__19_0;
		}

		// Token: 0x0200257F RID: 9599
		[Token(Token = "0x200257F")]
		private sealed class <RequiredAreaDownloadTimeout>d__30 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012C18 RID: 76824 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012C18")]
			[Address(RVA = "0x1ED9288", Offset = "0x1ED9288", VA = "0x1ED9288")]
			[DebuggerHidden]
			public <RequiredAreaDownloadTimeout>d__30(int <>1__state)
			{
			}

			// Token: 0x06012C19 RID: 76825 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012C19")]
			[Address(RVA = "0x1ED96C4", Offset = "0x1ED96C4", VA = "0x1ED96C4", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012C1A RID: 76826 RVA: 0x000796F8 File Offset: 0x000778F8
			[Token(Token = "0x6012C1A")]
			[Address(RVA = "0x1ED96C8", Offset = "0x1ED96C8", VA = "0x1ED96C8", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x170027C7 RID: 10183
			// (get) Token: 0x06012C1B RID: 76827 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170027C7")]
			private object Current
			{
				[Token(Token = "0x6012C1B")]
				[Address(RVA = "0x1ED98B4", Offset = "0x1ED98B4", VA = "0x1ED98B4", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012C1C RID: 76828 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012C1C")]
			[Address(RVA = "0x1ED98BC", Offset = "0x1ED98BC", VA = "0x1ED98BC", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x170027C8 RID: 10184
			// (get) Token: 0x06012C1D RID: 76829 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170027C8")]
			private object Current
			{
				[Token(Token = "0x6012C1D")]
				[Address(RVA = "0x1ED98FC", Offset = "0x1ED98FC", VA = "0x1ED98FC", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EC30 RID: 60464
			[Token(Token = "0x400EC30")]
			[FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EC31 RID: 60465
			[Token(Token = "0x400EC31")]
			[FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EC32 RID: 60466
			[Token(Token = "0x400EC32")]
			[FieldOffset(Offset = "0x20")]
			public AreaDownloader areaDownloader;

			// Token: 0x0400EC33 RID: 60467
			[Token(Token = "0x400EC33")]
			[FieldOffset(Offset = "0x28")]
			public AreaDownloadManager <>4__this;
		}
	}
}
