﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200233A RID: 9018
	[Token(Token = "0x200233A")]
	public struct ArcheryArenaGroupInfo : IFlatbufferObject
	{
		// Token: 0x17001EB5 RID: 7861
		// (get) Token: 0x06010B3D RID: 68413 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EB5")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B3D")]
			[Address(RVA = "0x2141E4C", Offset = "0x2141E4C", VA = "0x2141E4C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B3E RID: 68414 RVA: 0x0005FB08 File Offset: 0x0005DD08
		[Token(Token = "0x6010B3E")]
		[Address(RVA = "0x2141E54", Offset = "0x2141E54", VA = "0x2141E54")]
		public static ArcheryArenaGroupInfo GetRootAsArcheryArenaGroupInfo(ByteBuffer _bb)
		{
			return default(ArcheryArenaGroupInfo);
		}

		// Token: 0x06010B3F RID: 68415 RVA: 0x0005FB20 File Offset: 0x0005DD20
		[Token(Token = "0x6010B3F")]
		[Address(RVA = "0x2141E60", Offset = "0x2141E60", VA = "0x2141E60")]
		public static ArcheryArenaGroupInfo GetRootAsArcheryArenaGroupInfo(ByteBuffer _bb, ArcheryArenaGroupInfo obj)
		{
			return default(ArcheryArenaGroupInfo);
		}

		// Token: 0x06010B40 RID: 68416 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B40")]
		[Address(RVA = "0x2141F10", Offset = "0x2141F10", VA = "0x2141F10", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B41 RID: 68417 RVA: 0x0005FB38 File Offset: 0x0005DD38
		[Token(Token = "0x6010B41")]
		[Address(RVA = "0x2141ED8", Offset = "0x2141ED8", VA = "0x2141ED8")]
		public ArcheryArenaGroupInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(ArcheryArenaGroupInfo);
		}

		// Token: 0x17001EB6 RID: 7862
		// (get) Token: 0x06010B42 RID: 68418 RVA: 0x0005FB50 File Offset: 0x0005DD50
		[Token(Token = "0x17001EB6")]
		public long GroupId
		{
			[Token(Token = "0x6010B42")]
			[Address(RVA = "0x2141F20", Offset = "0x2141F20", VA = "0x2141F20")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010B43 RID: 68419 RVA: 0x0005FB68 File Offset: 0x0005DD68
		[Token(Token = "0x6010B43")]
		[Address(RVA = "0x2141F68", Offset = "0x2141F68", VA = "0x2141F68")]
		public ArcheryArenaUser? Users(int j)
		{
			return null;
		}

		// Token: 0x17001EB7 RID: 7863
		// (get) Token: 0x06010B44 RID: 68420 RVA: 0x0005FB80 File Offset: 0x0005DD80
		[Token(Token = "0x17001EB7")]
		public int UsersLength
		{
			[Token(Token = "0x6010B44")]
			[Address(RVA = "0x2142070", Offset = "0x2142070", VA = "0x2142070")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010B45 RID: 68421 RVA: 0x0005FB98 File Offset: 0x0005DD98
		[Token(Token = "0x6010B45")]
		[Address(RVA = "0x21420A4", Offset = "0x21420A4", VA = "0x21420A4")]
		public static Offset<ArcheryArenaGroupInfo> CreateArcheryArenaGroupInfo(FlatBufferBuilder builder, long group_id = 0L, [Optional] VectorOffset usersOffset)
		{
			return default(Offset<ArcheryArenaGroupInfo>);
		}

		// Token: 0x06010B46 RID: 68422 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B46")]
		[Address(RVA = "0x21421A8", Offset = "0x21421A8", VA = "0x21421A8")]
		public static void StartArcheryArenaGroupInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B47 RID: 68423 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B47")]
		[Address(RVA = "0x21420FC", Offset = "0x21420FC", VA = "0x21420FC")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06010B48 RID: 68424 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B48")]
		[Address(RVA = "0x214211C", Offset = "0x214211C", VA = "0x214211C")]
		public static void AddUsers(FlatBufferBuilder builder, VectorOffset usersOffset)
		{
		}

		// Token: 0x06010B49 RID: 68425 RVA: 0x0005FBB0 File Offset: 0x0005DDB0
		[Token(Token = "0x6010B49")]
		[Address(RVA = "0x21421C0", Offset = "0x21421C0", VA = "0x21421C0")]
		public static VectorOffset CreateUsersVector(FlatBufferBuilder builder, Offset<ArcheryArenaUser>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010B4A RID: 68426 RVA: 0x0005FBC8 File Offset: 0x0005DDC8
		[Token(Token = "0x6010B4A")]
		[Address(RVA = "0x2142268", Offset = "0x2142268", VA = "0x2142268")]
		public static VectorOffset CreateUsersVectorBlock(FlatBufferBuilder builder, Offset<ArcheryArenaUser>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010B4B RID: 68427 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B4B")]
		[Address(RVA = "0x21422F0", Offset = "0x21422F0", VA = "0x21422F0")]
		public static void StartUsersVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010B4C RID: 68428 RVA: 0x0005FBE0 File Offset: 0x0005DDE0
		[Token(Token = "0x6010B4C")]
		[Address(RVA = "0x214213C", Offset = "0x214213C", VA = "0x214213C")]
		public static Offset<ArcheryArenaGroupInfo> EndArcheryArenaGroupInfo(FlatBufferBuilder builder)
		{
			return default(Offset<ArcheryArenaGroupInfo>);
		}

		// Token: 0x0400E61B RID: 58907
		[Token(Token = "0x400E61B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
