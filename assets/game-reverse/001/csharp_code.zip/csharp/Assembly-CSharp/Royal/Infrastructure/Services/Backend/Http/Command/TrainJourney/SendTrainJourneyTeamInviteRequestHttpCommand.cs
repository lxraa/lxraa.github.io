﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TrainJourney
{
	// Token: 0x02002532 RID: 9522
	[Token(Token = "0x2002532")]
	public class SendTrainJourneyTeamInviteRequestHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002718 RID: 10008
		// (get) Token: 0x060129E2 RID: 76258 RVA: 0x00077E50 File Offset: 0x00076050
		[Token(Token = "0x17002718")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129E2")]
			[Address(RVA = "0x1CFBD6C", Offset = "0x1CFBD6C", VA = "0x1CFBD6C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002719 RID: 10009
		// (get) Token: 0x060129E3 RID: 76259 RVA: 0x00077E68 File Offset: 0x00076068
		[Token(Token = "0x17002719")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129E3")]
			[Address(RVA = "0x1CFBD74", Offset = "0x1CFBD74", VA = "0x1CFBD74", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060129E4 RID: 76260 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129E4")]
		[Address(RVA = "0x1CFBD7C", Offset = "0x1CFBD7C", VA = "0x1CFBD7C")]
		public SendTrainJourneyTeamInviteRequestHttpCommand(long id, string userName, UserProfileSetting userProfileSetting)
		{
		}

		// Token: 0x060129E5 RID: 76261 RVA: 0x00077E80 File Offset: 0x00076080
		[Token(Token = "0x60129E5")]
		[Address(RVA = "0x1CFBDD0", Offset = "0x1CFBDD0", VA = "0x1CFBDD0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129E6 RID: 76262 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129E6")]
		[Address(RVA = "0x1CFBE78", Offset = "0x1CFBE78", VA = "0x1CFBE78", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129E7 RID: 76263 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129E7")]
		[Address(RVA = "0x1CFC054", Offset = "0x1CFC054", VA = "0x1CFC054", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB35 RID: 60213
		[Token(Token = "0x400EB35")]
		[FieldOffset(Offset = "0x18")]
		private readonly long teamId;

		// Token: 0x0400EB36 RID: 60214
		[Token(Token = "0x400EB36")]
		[FieldOffset(Offset = "0x20")]
		private readonly string name;

		// Token: 0x0400EB37 RID: 60215
		[Token(Token = "0x400EB37")]
		[FieldOffset(Offset = "0x28")]
		private readonly UserProfileSetting setting;
	}
}
