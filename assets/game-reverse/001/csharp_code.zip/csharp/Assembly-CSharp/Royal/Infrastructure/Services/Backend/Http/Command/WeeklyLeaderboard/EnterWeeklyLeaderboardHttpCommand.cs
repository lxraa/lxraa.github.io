﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.WeeklyLeaderboard
{
	// Token: 0x02002526 RID: 9510
	[Token(Token = "0x2002526")]
	public class EnterWeeklyLeaderboardHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026FC RID: 9980
		// (get) Token: 0x0601298E RID: 76174 RVA: 0x00077A30 File Offset: 0x00075C30
		[Token(Token = "0x170026FC")]
		public override RequestType RequestType
		{
			[Token(Token = "0x601298E")]
			[Address(RVA = "0x1CF8A70", Offset = "0x1CF8A70", VA = "0x1CF8A70", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026FD RID: 9981
		// (get) Token: 0x0601298F RID: 76175 RVA: 0x00077A48 File Offset: 0x00075C48
		[Token(Token = "0x170026FD")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x601298F")]
			[Address(RVA = "0x1CF8A78", Offset = "0x1CF8A78", VA = "0x1CF8A78", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012990 RID: 76176 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012990")]
		[Address(RVA = "0x1CF8A80", Offset = "0x1CF8A80", VA = "0x1CF8A80")]
		public EnterWeeklyLeaderboardHttpCommand(bool isFacebookConnected)
		{
		}

		// Token: 0x06012991 RID: 76177 RVA: 0x00077A60 File Offset: 0x00075C60
		[Token(Token = "0x6012991")]
		[Address(RVA = "0x1CF8AB0", Offset = "0x1CF8AB0", VA = "0x1CF8AB0", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012992 RID: 76178 RVA: 0x00077A78 File Offset: 0x00075C78
		[Token(Token = "0x6012992")]
		[Address(RVA = "0x1CF8B70", Offset = "0x1CF8B70", VA = "0x1CF8B70", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012993 RID: 76179 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012993")]
		[Address(RVA = "0x1CF8C88", Offset = "0x1CF8C88", VA = "0x1CF8C88", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012994 RID: 76180 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012994")]
		[Address(RVA = "0x1CF8F3C", Offset = "0x1CF8F3C", VA = "0x1CF8F3C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB19 RID: 60185
		[Token(Token = "0x400EB19")]
		[FieldOffset(Offset = "0x13")]
		private readonly bool isFacebookConnected;
	}
}
