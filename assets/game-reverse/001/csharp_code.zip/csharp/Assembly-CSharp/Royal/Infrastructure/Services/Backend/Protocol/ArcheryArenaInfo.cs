﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200233B RID: 9019
	[Token(Token = "0x200233B")]
	public struct ArcheryArenaInfo : IFlatbufferObject
	{
		// Token: 0x17001EB8 RID: 7864
		// (get) Token: 0x06010B4D RID: 68429 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EB8")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B4D")]
			[Address(RVA = "0x2142310", Offset = "0x2142310", VA = "0x2142310", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B4E RID: 68430 RVA: 0x0005FBF8 File Offset: 0x0005DDF8
		[Token(Token = "0x6010B4E")]
		[Address(RVA = "0x2142318", Offset = "0x2142318", VA = "0x2142318")]
		public static ArcheryArenaInfo GetRootAsArcheryArenaInfo(ByteBuffer _bb)
		{
			return default(ArcheryArenaInfo);
		}

		// Token: 0x06010B4F RID: 68431 RVA: 0x0005FC10 File Offset: 0x0005DE10
		[Token(Token = "0x6010B4F")]
		[Address(RVA = "0x2142324", Offset = "0x2142324", VA = "0x2142324")]
		public static ArcheryArenaInfo GetRootAsArcheryArenaInfo(ByteBuffer _bb, ArcheryArenaInfo obj)
		{
			return default(ArcheryArenaInfo);
		}

		// Token: 0x06010B50 RID: 68432 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B50")]
		[Address(RVA = "0x21423D4", Offset = "0x21423D4", VA = "0x21423D4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B51 RID: 68433 RVA: 0x0005FC28 File Offset: 0x0005DE28
		[Token(Token = "0x6010B51")]
		[Address(RVA = "0x214239C", Offset = "0x214239C", VA = "0x214239C")]
		public ArcheryArenaInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(ArcheryArenaInfo);
		}

		// Token: 0x17001EB9 RID: 7865
		// (get) Token: 0x06010B52 RID: 68434 RVA: 0x0005FC40 File Offset: 0x0005DE40
		[Token(Token = "0x17001EB9")]
		public int EventId
		{
			[Token(Token = "0x6010B52")]
			[Address(RVA = "0x21423E4", Offset = "0x21423E4", VA = "0x21423E4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EBA RID: 7866
		// (get) Token: 0x06010B53 RID: 68435 RVA: 0x0005FC58 File Offset: 0x0005DE58
		[Token(Token = "0x17001EBA")]
		public long RemainingTime
		{
			[Token(Token = "0x6010B53")]
			[Address(RVA = "0x2142428", Offset = "0x2142428", VA = "0x2142428")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001EBB RID: 7867
		// (get) Token: 0x06010B54 RID: 68436 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EBB")]
		public string Config
		{
			[Token(Token = "0x6010B54")]
			[Address(RVA = "0x2142470", Offset = "0x2142470", VA = "0x2142470")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B55 RID: 68437 RVA: 0x0005FC70 File Offset: 0x0005DE70
		[Token(Token = "0x6010B55")]
		[Address(RVA = "0x21424AC", Offset = "0x21424AC", VA = "0x21424AC")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06010B56 RID: 68438 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010B56")]
		[Address(RVA = "0x21424E4", Offset = "0x21424E4", VA = "0x21424E4")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x17001EBC RID: 7868
		// (get) Token: 0x06010B57 RID: 68439 RVA: 0x0005FC88 File Offset: 0x0005DE88
		[Token(Token = "0x17001EBC")]
		public int ConfigVersion
		{
			[Token(Token = "0x6010B57")]
			[Address(RVA = "0x2142530", Offset = "0x2142530", VA = "0x2142530")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010B58 RID: 68440 RVA: 0x0005FCA0 File Offset: 0x0005DEA0
		[Token(Token = "0x6010B58")]
		[Address(RVA = "0x2142574", Offset = "0x2142574", VA = "0x2142574")]
		public static Offset<ArcheryArenaInfo> CreateArcheryArenaInfo(FlatBufferBuilder builder, int event_id = 0, long remaining_time = 0L, [Optional] StringOffset configOffset, int config_version = 0)
		{
			return default(Offset<ArcheryArenaInfo>);
		}

		// Token: 0x06010B59 RID: 68441 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B59")]
		[Address(RVA = "0x21426E0", Offset = "0x21426E0", VA = "0x21426E0")]
		public static void StartArcheryArenaInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B5A RID: 68442 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B5A")]
		[Address(RVA = "0x2142654", Offset = "0x2142654", VA = "0x2142654")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x06010B5B RID: 68443 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B5B")]
		[Address(RVA = "0x21425F4", Offset = "0x21425F4", VA = "0x21425F4")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010B5C RID: 68444 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B5C")]
		[Address(RVA = "0x2142634", Offset = "0x2142634", VA = "0x2142634")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06010B5D RID: 68445 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B5D")]
		[Address(RVA = "0x2142614", Offset = "0x2142614", VA = "0x2142614")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06010B5E RID: 68446 RVA: 0x0005FCB8 File Offset: 0x0005DEB8
		[Token(Token = "0x6010B5E")]
		[Address(RVA = "0x2142674", Offset = "0x2142674", VA = "0x2142674")]
		public static Offset<ArcheryArenaInfo> EndArcheryArenaInfo(FlatBufferBuilder builder)
		{
			return default(Offset<ArcheryArenaInfo>);
		}

		// Token: 0x0400E61C RID: 58908
		[Token(Token = "0x400E61C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
