﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002388 RID: 9096
	[Token(Token = "0x2002388")]
	public struct DragonNestInvitationUserInfo : IFlatbufferObject
	{
		// Token: 0x17001FEC RID: 8172
		// (get) Token: 0x06010FBE RID: 69566 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FEC")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010FBE")]
			[Address(RVA = "0x1F98218", Offset = "0x1F98218", VA = "0x1F98218", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FBF RID: 69567 RVA: 0x00063540 File Offset: 0x00061740
		[Token(Token = "0x6010FBF")]
		[Address(RVA = "0x1F98220", Offset = "0x1F98220", VA = "0x1F98220")]
		public static DragonNestInvitationUserInfo GetRootAsDragonNestInvitationUserInfo(ByteBuffer _bb)
		{
			return default(DragonNestInvitationUserInfo);
		}

		// Token: 0x06010FC0 RID: 69568 RVA: 0x00063558 File Offset: 0x00061758
		[Token(Token = "0x6010FC0")]
		[Address(RVA = "0x1F9822C", Offset = "0x1F9822C", VA = "0x1F9822C")]
		public static DragonNestInvitationUserInfo GetRootAsDragonNestInvitationUserInfo(ByteBuffer _bb, DragonNestInvitationUserInfo obj)
		{
			return default(DragonNestInvitationUserInfo);
		}

		// Token: 0x06010FC1 RID: 69569 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FC1")]
		[Address(RVA = "0x1F982DC", Offset = "0x1F982DC", VA = "0x1F982DC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010FC2 RID: 69570 RVA: 0x00063570 File Offset: 0x00061770
		[Token(Token = "0x6010FC2")]
		[Address(RVA = "0x1F982A4", Offset = "0x1F982A4", VA = "0x1F982A4")]
		public DragonNestInvitationUserInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestInvitationUserInfo);
		}

		// Token: 0x17001FED RID: 8173
		// (get) Token: 0x06010FC3 RID: 69571 RVA: 0x00063588 File Offset: 0x00061788
		[Token(Token = "0x17001FED")]
		public DragonNestUser? ProfileData
		{
			[Token(Token = "0x6010FC3")]
			[Address(RVA = "0x1F982EC", Offset = "0x1F982EC", VA = "0x1F982EC")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FEE RID: 8174
		// (get) Token: 0x06010FC4 RID: 69572 RVA: 0x000635A0 File Offset: 0x000617A0
		[Token(Token = "0x17001FEE")]
		public CoopEventInvitationStatus InvitationStatus
		{
			[Token(Token = "0x6010FC4")]
			[Address(RVA = "0x1F983A4", Offset = "0x1F983A4", VA = "0x1F983A4")]
			get
			{
				return CoopEventInvitationStatus.Requested;
			}
		}

		// Token: 0x06010FC5 RID: 69573 RVA: 0x000635B8 File Offset: 0x000617B8
		[Token(Token = "0x6010FC5")]
		[Address(RVA = "0x1F983E8", Offset = "0x1F983E8", VA = "0x1F983E8")]
		public static Offset<DragonNestInvitationUserInfo> CreateDragonNestInvitationUserInfo(FlatBufferBuilder builder, [Optional] Offset<DragonNestUser> profile_dataOffset, CoopEventInvitationStatus invitation_status = CoopEventInvitationStatus.Requested)
		{
			return default(Offset<DragonNestInvitationUserInfo>);
		}

		// Token: 0x06010FC6 RID: 69574 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FC6")]
		[Address(RVA = "0x1F984EC", Offset = "0x1F984EC", VA = "0x1F984EC")]
		public static void StartDragonNestInvitationUserInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010FC7 RID: 69575 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FC7")]
		[Address(RVA = "0x1F98440", Offset = "0x1F98440", VA = "0x1F98440")]
		public static void AddProfileData(FlatBufferBuilder builder, Offset<DragonNestUser> profileDataOffset)
		{
		}

		// Token: 0x06010FC8 RID: 69576 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FC8")]
		[Address(RVA = "0x1F98460", Offset = "0x1F98460", VA = "0x1F98460")]
		public static void AddInvitationStatus(FlatBufferBuilder builder, CoopEventInvitationStatus invitationStatus)
		{
		}

		// Token: 0x06010FC9 RID: 69577 RVA: 0x000635D0 File Offset: 0x000617D0
		[Token(Token = "0x6010FC9")]
		[Address(RVA = "0x1F98480", Offset = "0x1F98480", VA = "0x1F98480")]
		public static Offset<DragonNestInvitationUserInfo> EndDragonNestInvitationUserInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestInvitationUserInfo>);
		}

		// Token: 0x0400E6A1 RID: 59041
		[Token(Token = "0x400E6A1")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
