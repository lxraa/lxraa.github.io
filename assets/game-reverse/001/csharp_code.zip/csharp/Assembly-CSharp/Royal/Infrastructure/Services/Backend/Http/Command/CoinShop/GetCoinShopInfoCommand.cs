﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.CoinShop
{
	// Token: 0x02002575 RID: 9589
	[Token(Token = "0x2002575")]
	public class GetCoinShopInfoCommand : BaseHttpCommand
	{
		// Token: 0x170027B4 RID: 10164
		// (get) Token: 0x06012BAF RID: 76719 RVA: 0x000793B0 File Offset: 0x000775B0
		[Token(Token = "0x170027B4")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012BAF")]
			[Address(RVA = "0x1ED49BC", Offset = "0x1ED49BC", VA = "0x1ED49BC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027B5 RID: 10165
		// (get) Token: 0x06012BB0 RID: 76720 RVA: 0x000793C8 File Offset: 0x000775C8
		[Token(Token = "0x170027B5")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012BB0")]
			[Address(RVA = "0x1ED49C4", Offset = "0x1ED49C4", VA = "0x1ED49C4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012BB1 RID: 76721 RVA: 0x000793E0 File Offset: 0x000775E0
		[Token(Token = "0x6012BB1")]
		[Address(RVA = "0x1ED49CC", Offset = "0x1ED49CC", VA = "0x1ED49CC", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BB2 RID: 76722 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BB2")]
		[Address(RVA = "0x1ED49F4", Offset = "0x1ED49F4", VA = "0x1ED49F4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BB3 RID: 76723 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BB3")]
		[Address(RVA = "0x1ED4B28", Offset = "0x1ED4B28", VA = "0x1ED4B28", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012BB4 RID: 76724 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BB4")]
		[Address(RVA = "0x1ED4BA0", Offset = "0x1ED4BA0", VA = "0x1ED4BA0")]
		public GetCoinShopInfoCommand()
		{
		}
	}
}
