﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.ArcheryArena
{
	// Token: 0x02002577 RID: 9591
	[Token(Token = "0x2002577")]
	public class EnterArcheryArenaHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027B8 RID: 10168
		// (get) Token: 0x06012BBC RID: 76732 RVA: 0x00079458 File Offset: 0x00077658
		[Token(Token = "0x170027B8")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012BBC")]
			[Address(RVA = "0x1ED4E30", Offset = "0x1ED4E30", VA = "0x1ED4E30", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027B9 RID: 10169
		// (get) Token: 0x06012BBD RID: 76733 RVA: 0x00079470 File Offset: 0x00077670
		[Token(Token = "0x170027B9")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012BBD")]
			[Address(RVA = "0x1ED4E38", Offset = "0x1ED4E38", VA = "0x1ED4E38", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170027BA RID: 10170
		// (get) Token: 0x06012BBE RID: 76734 RVA: 0x00079488 File Offset: 0x00077688
		// (set) Token: 0x06012BBF RID: 76735 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027BA")]
		private EnterArcheryArenaResponse Response
		{
			[Token(Token = "0x6012BBE")]
			[Address(RVA = "0x1ED4E40", Offset = "0x1ED4E40", VA = "0x1ED4E40")]
			get
			{
				return default(EnterArcheryArenaResponse);
			}
			[Token(Token = "0x6012BBF")]
			[Address(RVA = "0x1ED4E4C", Offset = "0x1ED4E4C", VA = "0x1ED4E4C")]
			set
			{
			}
		}

		// Token: 0x06012BC0 RID: 76736 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BC0")]
		[Address(RVA = "0x1ED4E5C", Offset = "0x1ED4E5C", VA = "0x1ED4E5C")]
		public EnterArcheryArenaHttpCommand(int level, int score, int configVersion)
		{
		}

		// Token: 0x06012BC1 RID: 76737 RVA: 0x000794A0 File Offset: 0x000776A0
		[Token(Token = "0x6012BC1")]
		[Address(RVA = "0x1ED4E98", Offset = "0x1ED4E98", VA = "0x1ED4E98", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BC2 RID: 76738 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BC2")]
		[Address(RVA = "0x1ED4FF4", Offset = "0x1ED4FF4", VA = "0x1ED4FF4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BC3 RID: 76739 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BC3")]
		[Address(RVA = "0x1ED52D4", Offset = "0x1ED52D4", VA = "0x1ED52D4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EC02 RID: 60418
		[Token(Token = "0x400EC02")]
		[FieldOffset(Offset = "0x18")]
		private EnterArcheryArenaResponse <Response>k__BackingField;

		// Token: 0x0400EC03 RID: 60419
		[Token(Token = "0x400EC03")]
		[FieldOffset(Offset = "0x28")]
		private readonly int level;

		// Token: 0x0400EC04 RID: 60420
		[Token(Token = "0x400EC04")]
		[FieldOffset(Offset = "0x2C")]
		private readonly int score;

		// Token: 0x0400EC05 RID: 60421
		[Token(Token = "0x400EC05")]
		[FieldOffset(Offset = "0x30")]
		private readonly int configVersion;
	}
}
