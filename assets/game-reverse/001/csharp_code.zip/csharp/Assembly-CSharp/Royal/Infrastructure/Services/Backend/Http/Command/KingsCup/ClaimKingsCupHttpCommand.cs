﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.KingsCup
{
	// Token: 0x02002564 RID: 9572
	[Token(Token = "0x2002564")]
	public class ClaimKingsCupHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002792 RID: 10130
		// (get) Token: 0x06012B4A RID: 76618 RVA: 0x00078EE8 File Offset: 0x000770E8
		[Token(Token = "0x17002792")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B4A")]
			[Address(RVA = "0x1ED12A8", Offset = "0x1ED12A8", VA = "0x1ED12A8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002793 RID: 10131
		// (get) Token: 0x06012B4B RID: 76619 RVA: 0x00078F00 File Offset: 0x00077100
		[Token(Token = "0x17002793")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B4B")]
			[Address(RVA = "0x1ED12B0", Offset = "0x1ED12B0", VA = "0x1ED12B0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002794 RID: 10132
		// (get) Token: 0x06012B4C RID: 76620 RVA: 0x00078F18 File Offset: 0x00077118
		// (set) Token: 0x06012B4D RID: 76621 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002794")]
		public ClaimKingsCupRewardResponse Response
		{
			[Token(Token = "0x6012B4C")]
			[Address(RVA = "0x1ED12B8", Offset = "0x1ED12B8", VA = "0x1ED12B8")]
			get
			{
				return default(ClaimKingsCupRewardResponse);
			}
			[Token(Token = "0x6012B4D")]
			[Address(RVA = "0x1ED12C4", Offset = "0x1ED12C4", VA = "0x1ED12C4")]
			set
			{
			}
		}

		// Token: 0x06012B4E RID: 76622 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B4E")]
		[Address(RVA = "0x1ED12D4", Offset = "0x1ED12D4", VA = "0x1ED12D4")]
		public ClaimKingsCupHttpCommand(long groupId)
		{
		}

		// Token: 0x06012B4F RID: 76623 RVA: 0x00078F30 File Offset: 0x00077130
		[Token(Token = "0x6012B4F")]
		[Address(RVA = "0x1ED12FC", Offset = "0x1ED12FC", VA = "0x1ED12FC", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B50 RID: 76624 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B50")]
		[Address(RVA = "0x1ED1320", Offset = "0x1ED1320", VA = "0x1ED1320", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B51 RID: 76625 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B51")]
		[Address(RVA = "0x1ED1538", Offset = "0x1ED1538", VA = "0x1ED1538", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBCA RID: 60362
		[Token(Token = "0x400EBCA")]
		[FieldOffset(Offset = "0x18")]
		private ClaimKingsCupRewardResponse <Response>k__BackingField;

		// Token: 0x0400EBCB RID: 60363
		[Token(Token = "0x400EBCB")]
		[FieldOffset(Offset = "0x28")]
		private readonly long groupId;
	}
}
