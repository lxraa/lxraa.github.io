﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002365 RID: 9061
	[Token(Token = "0x2002365")]
	public struct ClaimTeamBattleRewardResponse : IFlatbufferObject
	{
		// Token: 0x17001F4D RID: 8013
		// (get) Token: 0x06010D87 RID: 68999 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F4D")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D87")]
			[Address(RVA = "0x214A600", Offset = "0x214A600", VA = "0x214A600", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D88 RID: 69000 RVA: 0x00061890 File Offset: 0x0005FA90
		[Token(Token = "0x6010D88")]
		[Address(RVA = "0x214A608", Offset = "0x214A608", VA = "0x214A608")]
		public static ClaimTeamBattleRewardResponse GetRootAsClaimTeamBattleRewardResponse(ByteBuffer _bb)
		{
			return default(ClaimTeamBattleRewardResponse);
		}

		// Token: 0x06010D89 RID: 69001 RVA: 0x000618A8 File Offset: 0x0005FAA8
		[Token(Token = "0x6010D89")]
		[Address(RVA = "0x214A614", Offset = "0x214A614", VA = "0x214A614")]
		public static ClaimTeamBattleRewardResponse GetRootAsClaimTeamBattleRewardResponse(ByteBuffer _bb, ClaimTeamBattleRewardResponse obj)
		{
			return default(ClaimTeamBattleRewardResponse);
		}

		// Token: 0x06010D8A RID: 69002 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D8A")]
		[Address(RVA = "0x214A6C4", Offset = "0x214A6C4", VA = "0x214A6C4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D8B RID: 69003 RVA: 0x000618C0 File Offset: 0x0005FAC0
		[Token(Token = "0x6010D8B")]
		[Address(RVA = "0x214A68C", Offset = "0x214A68C", VA = "0x214A68C")]
		public ClaimTeamBattleRewardResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimTeamBattleRewardResponse);
		}

		// Token: 0x17001F4E RID: 8014
		// (get) Token: 0x06010D8C RID: 69004 RVA: 0x000618D8 File Offset: 0x0005FAD8
		[Token(Token = "0x17001F4E")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010D8C")]
			[Address(RVA = "0x214A6D4", Offset = "0x214A6D4", VA = "0x214A6D4")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001F4F RID: 8015
		// (get) Token: 0x06010D8D RID: 69005 RVA: 0x000618F0 File Offset: 0x0005FAF0
		[Token(Token = "0x17001F4F")]
		public UserProgress? DeprecatedUserProgress
		{
			[Token(Token = "0x6010D8D")]
			[Address(RVA = "0x214A718", Offset = "0x214A718", VA = "0x214A718")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F50 RID: 8016
		// (get) Token: 0x06010D8E RID: 69006 RVA: 0x00061908 File Offset: 0x0005FB08
		[Token(Token = "0x17001F50")]
		public int Rank
		{
			[Token(Token = "0x6010D8E")]
			[Address(RVA = "0x214A7D8", Offset = "0x214A7D8", VA = "0x214A7D8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F51 RID: 8017
		// (get) Token: 0x06010D8F RID: 69007 RVA: 0x00061920 File Offset: 0x0005FB20
		[Token(Token = "0x17001F51")]
		public long RemainingTime
		{
			[Token(Token = "0x6010D8F")]
			[Address(RVA = "0x214A81C", Offset = "0x214A81C", VA = "0x214A81C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010D90 RID: 69008 RVA: 0x00061938 File Offset: 0x0005FB38
		[Token(Token = "0x6010D90")]
		[Address(RVA = "0x214A864", Offset = "0x214A864", VA = "0x214A864")]
		public static Offset<ClaimTeamBattleRewardResponse> CreateClaimTeamBattleRewardResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, [Optional] Offset<UserProgress> deprecated_user_progressOffset, int rank = 0, long remaining_time = 0L)
		{
			return default(Offset<ClaimTeamBattleRewardResponse>);
		}

		// Token: 0x06010D91 RID: 69009 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D91")]
		[Address(RVA = "0x214A9D0", Offset = "0x214A9D0", VA = "0x214A9D0")]
		public static void StartClaimTeamBattleRewardResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D92 RID: 69010 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D92")]
		[Address(RVA = "0x214A944", Offset = "0x214A944", VA = "0x214A944")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010D93 RID: 69011 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D93")]
		[Address(RVA = "0x214A924", Offset = "0x214A924", VA = "0x214A924")]
		public static void AddDeprecatedUserProgress(FlatBufferBuilder builder, Offset<UserProgress> deprecatedUserProgressOffset)
		{
		}

		// Token: 0x06010D94 RID: 69012 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D94")]
		[Address(RVA = "0x214A904", Offset = "0x214A904", VA = "0x214A904")]
		public static void AddRank(FlatBufferBuilder builder, int rank)
		{
		}

		// Token: 0x06010D95 RID: 69013 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D95")]
		[Address(RVA = "0x214A8E4", Offset = "0x214A8E4", VA = "0x214A8E4")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010D96 RID: 69014 RVA: 0x00061950 File Offset: 0x0005FB50
		[Token(Token = "0x6010D96")]
		[Address(RVA = "0x214A964", Offset = "0x214A964", VA = "0x214A964")]
		public static Offset<ClaimTeamBattleRewardResponse> EndClaimTeamBattleRewardResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimTeamBattleRewardResponse>);
		}

		// Token: 0x0400E66B RID: 58987
		[Token(Token = "0x400E66B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
