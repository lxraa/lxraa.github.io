﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023CF RID: 9167
	[Token(Token = "0x20023CF")]
	public struct GetDragonNestSuggestionsAndInvitationsResponse : IFlatbufferObject
	{
		// Token: 0x170020E2 RID: 8418
		// (get) Token: 0x0601135B RID: 70491 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020E2")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601135B")]
			[Address(RVA = "0x1CAE24C", Offset = "0x1CAE24C", VA = "0x1CAE24C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601135C RID: 70492 RVA: 0x00066540 File Offset: 0x00064740
		[Token(Token = "0x601135C")]
		[Address(RVA = "0x1CAE254", Offset = "0x1CAE254", VA = "0x1CAE254")]
		public static GetDragonNestSuggestionsAndInvitationsResponse GetRootAsGetDragonNestSuggestionsAndInvitationsResponse(ByteBuffer _bb)
		{
			return default(GetDragonNestSuggestionsAndInvitationsResponse);
		}

		// Token: 0x0601135D RID: 70493 RVA: 0x00066558 File Offset: 0x00064758
		[Token(Token = "0x601135D")]
		[Address(RVA = "0x1CAE260", Offset = "0x1CAE260", VA = "0x1CAE260")]
		public static GetDragonNestSuggestionsAndInvitationsResponse GetRootAsGetDragonNestSuggestionsAndInvitationsResponse(ByteBuffer _bb, GetDragonNestSuggestionsAndInvitationsResponse obj)
		{
			return default(GetDragonNestSuggestionsAndInvitationsResponse);
		}

		// Token: 0x0601135E RID: 70494 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601135E")]
		[Address(RVA = "0x1CAE310", Offset = "0x1CAE310", VA = "0x1CAE310", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601135F RID: 70495 RVA: 0x00066570 File Offset: 0x00064770
		[Token(Token = "0x601135F")]
		[Address(RVA = "0x1CAE2D8", Offset = "0x1CAE2D8", VA = "0x1CAE2D8")]
		public GetDragonNestSuggestionsAndInvitationsResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetDragonNestSuggestionsAndInvitationsResponse);
		}

		// Token: 0x06011360 RID: 70496 RVA: 0x00066588 File Offset: 0x00064788
		[Token(Token = "0x6011360")]
		[Address(RVA = "0x1CAE320", Offset = "0x1CAE320", VA = "0x1CAE320")]
		public DragonNestInvitationUserInfo? Invitations(int j)
		{
			return null;
		}

		// Token: 0x170020E3 RID: 8419
		// (get) Token: 0x06011361 RID: 70497 RVA: 0x000665A0 File Offset: 0x000647A0
		[Token(Token = "0x170020E3")]
		public int InvitationsLength
		{
			[Token(Token = "0x6011361")]
			[Address(RVA = "0x1CAE3F8", Offset = "0x1CAE3F8", VA = "0x1CAE3F8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011362 RID: 70498 RVA: 0x000665B8 File Offset: 0x000647B8
		[Token(Token = "0x6011362")]
		[Address(RVA = "0x1CAE42C", Offset = "0x1CAE42C", VA = "0x1CAE42C")]
		public DragonNestFriendInfo? Friends(int j)
		{
			return null;
		}

		// Token: 0x170020E4 RID: 8420
		// (get) Token: 0x06011363 RID: 70499 RVA: 0x000665D0 File Offset: 0x000647D0
		[Token(Token = "0x170020E4")]
		public int FriendsLength
		{
			[Token(Token = "0x6011363")]
			[Address(RVA = "0x1CAE504", Offset = "0x1CAE504", VA = "0x1CAE504")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011364 RID: 70500 RVA: 0x000665E8 File Offset: 0x000647E8
		[Token(Token = "0x6011364")]
		[Address(RVA = "0x1CAE538", Offset = "0x1CAE538", VA = "0x1CAE538")]
		public DragonNestSuggestionInfo? Suggestions(int j)
		{
			return null;
		}

		// Token: 0x170020E5 RID: 8421
		// (get) Token: 0x06011365 RID: 70501 RVA: 0x00066600 File Offset: 0x00064800
		[Token(Token = "0x170020E5")]
		public int SuggestionsLength
		{
			[Token(Token = "0x6011365")]
			[Address(RVA = "0x1CAE610", Offset = "0x1CAE610", VA = "0x1CAE610")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011366 RID: 70502 RVA: 0x00066618 File Offset: 0x00064818
		[Token(Token = "0x6011366")]
		[Address(RVA = "0x1CAE644", Offset = "0x1CAE644", VA = "0x1CAE644")]
		public static Offset<GetDragonNestSuggestionsAndInvitationsResponse> CreateGetDragonNestSuggestionsAndInvitationsResponse(FlatBufferBuilder builder, [Optional] VectorOffset invitationsOffset, [Optional] VectorOffset friendsOffset, [Optional] VectorOffset suggestionsOffset)
		{
			return default(Offset<GetDragonNestSuggestionsAndInvitationsResponse>);
		}

		// Token: 0x06011367 RID: 70503 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011367")]
		[Address(RVA = "0x1CAE780", Offset = "0x1CAE780", VA = "0x1CAE780")]
		public static void StartGetDragonNestSuggestionsAndInvitationsResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011368 RID: 70504 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011368")]
		[Address(RVA = "0x1CAE6F4", Offset = "0x1CAE6F4", VA = "0x1CAE6F4")]
		public static void AddInvitations(FlatBufferBuilder builder, VectorOffset invitationsOffset)
		{
		}

		// Token: 0x06011369 RID: 70505 RVA: 0x00066630 File Offset: 0x00064830
		[Token(Token = "0x6011369")]
		[Address(RVA = "0x1CAE798", Offset = "0x1CAE798", VA = "0x1CAE798")]
		public static VectorOffset CreateInvitationsVector(FlatBufferBuilder builder, Offset<DragonNestInvitationUserInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601136A RID: 70506 RVA: 0x00066648 File Offset: 0x00064848
		[Token(Token = "0x601136A")]
		[Address(RVA = "0x1CAE840", Offset = "0x1CAE840", VA = "0x1CAE840")]
		public static VectorOffset CreateInvitationsVectorBlock(FlatBufferBuilder builder, Offset<DragonNestInvitationUserInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601136B RID: 70507 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601136B")]
		[Address(RVA = "0x1CAE8C8", Offset = "0x1CAE8C8", VA = "0x1CAE8C8")]
		public static void StartInvitationsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x0601136C RID: 70508 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601136C")]
		[Address(RVA = "0x1CAE6D4", Offset = "0x1CAE6D4", VA = "0x1CAE6D4")]
		public static void AddFriends(FlatBufferBuilder builder, VectorOffset friendsOffset)
		{
		}

		// Token: 0x0601136D RID: 70509 RVA: 0x00066660 File Offset: 0x00064860
		[Token(Token = "0x601136D")]
		[Address(RVA = "0x1CAE8E8", Offset = "0x1CAE8E8", VA = "0x1CAE8E8")]
		public static VectorOffset CreateFriendsVector(FlatBufferBuilder builder, Offset<DragonNestFriendInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601136E RID: 70510 RVA: 0x00066678 File Offset: 0x00064878
		[Token(Token = "0x601136E")]
		[Address(RVA = "0x1CAE990", Offset = "0x1CAE990", VA = "0x1CAE990")]
		public static VectorOffset CreateFriendsVectorBlock(FlatBufferBuilder builder, Offset<DragonNestFriendInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601136F RID: 70511 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601136F")]
		[Address(RVA = "0x1CAEA18", Offset = "0x1CAEA18", VA = "0x1CAEA18")]
		public static void StartFriendsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011370 RID: 70512 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011370")]
		[Address(RVA = "0x1CAE6B4", Offset = "0x1CAE6B4", VA = "0x1CAE6B4")]
		public static void AddSuggestions(FlatBufferBuilder builder, VectorOffset suggestionsOffset)
		{
		}

		// Token: 0x06011371 RID: 70513 RVA: 0x00066690 File Offset: 0x00064890
		[Token(Token = "0x6011371")]
		[Address(RVA = "0x1CAEA38", Offset = "0x1CAEA38", VA = "0x1CAEA38")]
		public static VectorOffset CreateSuggestionsVector(FlatBufferBuilder builder, Offset<DragonNestSuggestionInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011372 RID: 70514 RVA: 0x000666A8 File Offset: 0x000648A8
		[Token(Token = "0x6011372")]
		[Address(RVA = "0x1CAEAE0", Offset = "0x1CAEAE0", VA = "0x1CAEAE0")]
		public static VectorOffset CreateSuggestionsVectorBlock(FlatBufferBuilder builder, Offset<DragonNestSuggestionInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011373 RID: 70515 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011373")]
		[Address(RVA = "0x1CAEB68", Offset = "0x1CAEB68", VA = "0x1CAEB68")]
		public static void StartSuggestionsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011374 RID: 70516 RVA: 0x000666C0 File Offset: 0x000648C0
		[Token(Token = "0x6011374")]
		[Address(RVA = "0x1CAE714", Offset = "0x1CAE714", VA = "0x1CAE714")]
		public static Offset<GetDragonNestSuggestionsAndInvitationsResponse> EndGetDragonNestSuggestionsAndInvitationsResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetDragonNestSuggestionsAndInvitationsResponse>);
		}

		// Token: 0x0400E73F RID: 59199
		[Token(Token = "0x400E73F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
