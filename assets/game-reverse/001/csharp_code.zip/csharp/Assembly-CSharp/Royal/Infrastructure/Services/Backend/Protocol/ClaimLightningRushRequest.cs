﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200235E RID: 9054
	[Token(Token = "0x200235E")]
	public struct ClaimLightningRushRequest : IFlatbufferObject
	{
		// Token: 0x17001F36 RID: 7990
		// (get) Token: 0x06010D2C RID: 68908 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F36")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D2C")]
			[Address(RVA = "0x21491B4", Offset = "0x21491B4", VA = "0x21491B4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D2D RID: 68909 RVA: 0x000613E0 File Offset: 0x0005F5E0
		[Token(Token = "0x6010D2D")]
		[Address(RVA = "0x21491BC", Offset = "0x21491BC", VA = "0x21491BC")]
		public static ClaimLightningRushRequest GetRootAsClaimLightningRushRequest(ByteBuffer _bb)
		{
			return default(ClaimLightningRushRequest);
		}

		// Token: 0x06010D2E RID: 68910 RVA: 0x000613F8 File Offset: 0x0005F5F8
		[Token(Token = "0x6010D2E")]
		[Address(RVA = "0x21491C8", Offset = "0x21491C8", VA = "0x21491C8")]
		public static ClaimLightningRushRequest GetRootAsClaimLightningRushRequest(ByteBuffer _bb, ClaimLightningRushRequest obj)
		{
			return default(ClaimLightningRushRequest);
		}

		// Token: 0x06010D2F RID: 68911 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D2F")]
		[Address(RVA = "0x2149278", Offset = "0x2149278", VA = "0x2149278", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D30 RID: 68912 RVA: 0x00061410 File Offset: 0x0005F610
		[Token(Token = "0x6010D30")]
		[Address(RVA = "0x2149240", Offset = "0x2149240", VA = "0x2149240")]
		public ClaimLightningRushRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimLightningRushRequest);
		}

		// Token: 0x17001F37 RID: 7991
		// (get) Token: 0x06010D31 RID: 68913 RVA: 0x00061428 File Offset: 0x0005F628
		[Token(Token = "0x17001F37")]
		public long GroupId
		{
			[Token(Token = "0x6010D31")]
			[Address(RVA = "0x2149288", Offset = "0x2149288", VA = "0x2149288")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010D32 RID: 68914 RVA: 0x00061440 File Offset: 0x0005F640
		[Token(Token = "0x6010D32")]
		[Address(RVA = "0x21492D0", Offset = "0x21492D0", VA = "0x21492D0")]
		public static Offset<ClaimLightningRushRequest> CreateClaimLightningRushRequest(FlatBufferBuilder builder, long group_id = 0L)
		{
			return default(Offset<ClaimLightningRushRequest>);
		}

		// Token: 0x06010D33 RID: 68915 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D33")]
		[Address(RVA = "0x21493A4", Offset = "0x21493A4", VA = "0x21493A4")]
		public static void StartClaimLightningRushRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D34 RID: 68916 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D34")]
		[Address(RVA = "0x2149318", Offset = "0x2149318", VA = "0x2149318")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06010D35 RID: 68917 RVA: 0x00061458 File Offset: 0x0005F658
		[Token(Token = "0x6010D35")]
		[Address(RVA = "0x2149338", Offset = "0x2149338", VA = "0x2149338")]
		public static Offset<ClaimLightningRushRequest> EndClaimLightningRushRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimLightningRushRequest>);
		}

		// Token: 0x0400E664 RID: 58980
		[Token(Token = "0x400E664")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
