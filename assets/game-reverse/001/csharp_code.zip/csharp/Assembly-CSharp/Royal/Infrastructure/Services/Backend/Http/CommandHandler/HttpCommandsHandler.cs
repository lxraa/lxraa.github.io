﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.NetworkMetrics;
using UnityEngine.Networking;

namespace Royal.Infrastructure.Services.Backend.Http.CommandHandler
{
	// Token: 0x02002510 RID: 9488
	[Token(Token = "0x2002510")]
	public class HttpCommandsHandler
	{
		// Token: 0x1400009B RID: 155
		// (add) Token: 0x0601288F RID: 75919 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012890 RID: 75920 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1400009B")]
		public event Action<HttpCommandsHandler> OnRequestCompleted
		{
			[Token(Token = "0x601288F")]
			[Address(RVA = "0x1CE99D8", Offset = "0x1CE99D8", VA = "0x1CE99D8")]
			add
			{
			}
			[Token(Token = "0x6012890")]
			[Address(RVA = "0x1CE9A88", Offset = "0x1CE9A88", VA = "0x1CE9A88")]
			remove
			{
			}
		}

		// Token: 0x06012891 RID: 75921 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012891")]
		[Address(RVA = "0x1CE9B38", Offset = "0x1CE9B38", VA = "0x1CE9B38")]
		public HttpCommandsHandler(HttpCommands commands, BackendEndpointTypes endpointType, float timeOut = 12f)
		{
		}

		// Token: 0x06012892 RID: 75922 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012892")]
		[Address(RVA = "0x1CE9C6C", Offset = "0x1CE9C6C", VA = "0x1CE9C6C")]
		public void Send()
		{
		}

		// Token: 0x06012893 RID: 75923 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012893")]
		[Address(RVA = "0x1CE9EF0", Offset = "0x1CE9EF0", VA = "0x1CE9EF0")]
		private void SendOverWebRequest(byte[] data)
		{
		}

		// Token: 0x06012894 RID: 75924 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012894")]
		[Address(RVA = "0x1CEA0B0", Offset = "0x1CEA0B0", VA = "0x1CEA0B0")]
		public void UnityWebRequestManualUpdate()
		{
		}

		// Token: 0x06012895 RID: 75925 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012895")]
		[Address(RVA = "0x1CEA1B8", Offset = "0x1CEA1B8", VA = "0x1CEA1B8")]
		private void ClientRequestFinished(byte[] result)
		{
		}

		// Token: 0x06012896 RID: 75926 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012896")]
		[Address(RVA = "0x1CEA2EC", Offset = "0x1CEA2EC", VA = "0x1CEA2EC")]
		private void ClientRequestFailed(string reason, bool switchStrategy, bool isTimeout)
		{
		}

		// Token: 0x06012897 RID: 75927 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012897")]
		[Address(RVA = "0x1CEA488", Offset = "0x1CEA488", VA = "0x1CEA488")]
		private static void SwitchNetworkStrategy()
		{
		}

		// Token: 0x06012898 RID: 75928 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012898")]
		[Address(RVA = "0x1CEA564", Offset = "0x1CEA564", VA = "0x1CEA564")]
		private void MeasureResponseTime(HttpCommandsHandler httpCommandsHandler)
		{
		}

		// Token: 0x06012899 RID: 75929 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012899")]
		[Address(RVA = "0x1CEA43C", Offset = "0x1CEA43C", VA = "0x1CEA43C")]
		private void FinishCommands(byte[] data)
		{
		}

		// Token: 0x0601289A RID: 75930 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601289A")]
		[Address(RVA = "0x1CEA518", Offset = "0x1CEA518", VA = "0x1CEA518")]
		private void FailCommands(string failReason)
		{
		}

		// Token: 0x0601289B RID: 75931 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601289B")]
		[Address(RVA = "0x1CEA6B8", Offset = "0x1CEA6B8", VA = "0x1CEA6B8")]
		private void Cancel()
		{
		}

		// Token: 0x0601289C RID: 75932 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601289C")]
		[Address(RVA = "0x1CEA730", Offset = "0x1CEA730", VA = "0x1CEA730")]
		public void CheckForTimeout()
		{
		}

		// Token: 0x0400EAAA RID: 60074
		[Token(Token = "0x400EAAA")]
		[FieldOffset(Offset = "0x0")]
		private static short SwitchNetworkStrategyCounter;

		// Token: 0x0400EAAB RID: 60075
		[Token(Token = "0x400EAAB")]
		[FieldOffset(Offset = "0x10")]
		private readonly HttpCommandTimeout timeOut;

		// Token: 0x0400EAAC RID: 60076
		[Token(Token = "0x400EAAC")]
		[FieldOffset(Offset = "0x20")]
		private readonly Uri endPoint;

		// Token: 0x0400EAAD RID: 60077
		[Token(Token = "0x400EAAD")]
		[FieldOffset(Offset = "0x28")]
		private readonly HttpCommands commands;

		// Token: 0x0400EAAE RID: 60078
		[Token(Token = "0x400EAAE")]
		[FieldOffset(Offset = "0x30")]
		private readonly BackendEndpointTypes endpointType;

		// Token: 0x0400EAAF RID: 60079
		[Token(Token = "0x400EAAF")]
		[FieldOffset(Offset = "0x38")]
		private readonly NetworkMetricsManager networkMetricsManager;

		// Token: 0x0400EAB0 RID: 60080
		[Token(Token = "0x400EAB0")]
		[FieldOffset(Offset = "0x40")]
		private DateTime requestSendTime;

		// Token: 0x0400EAB1 RID: 60081
		[Token(Token = "0x400EAB1")]
		[FieldOffset(Offset = "0x48")]
		private long requestSendTimeInMs;

		// Token: 0x0400EAB2 RID: 60082
		[Token(Token = "0x400EAB2")]
		[FieldOffset(Offset = "0x50")]
		private bool isCancelled;

		// Token: 0x0400EAB3 RID: 60083
		[Token(Token = "0x400EAB3")]
		[FieldOffset(Offset = "0x51")]
		private bool connectionFinished;

		// Token: 0x0400EAB4 RID: 60084
		[Token(Token = "0x400EAB4")]
		[FieldOffset(Offset = "0x52")]
		private bool isHttpTimedOut;

		// Token: 0x0400EAB5 RID: 60085
		[Token(Token = "0x400EAB5")]
		[FieldOffset(Offset = "0x54")]
		private int requestFocusCount;

		// Token: 0x0400EAB6 RID: 60086
		[Token(Token = "0x400EAB6")]
		[FieldOffset(Offset = "0x58")]
		private UnityWebRequest webRequest;
	}
}
