﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x0200259B RID: 9627
	[Token(Token = "0x200259B")]
	public class MatchItemCountsJson
	{
		// Token: 0x06012D53 RID: 77139 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D53")]
		[Address(RVA = "0x243AA24", Offset = "0x243AA24", VA = "0x243AA24")]
		public MatchItemCountsJson()
		{
		}

		// Token: 0x0400ED1A RID: 60698
		[Token(Token = "0x400ED1A")]
		[FieldOffset(Offset = "0x10")]
		public int blue;

		// Token: 0x0400ED1B RID: 60699
		[Token(Token = "0x400ED1B")]
		[FieldOffset(Offset = "0x14")]
		public int green;

		// Token: 0x0400ED1C RID: 60700
		[Token(Token = "0x400ED1C")]
		[FieldOffset(Offset = "0x18")]
		public int red;

		// Token: 0x0400ED1D RID: 60701
		[Token(Token = "0x400ED1D")]
		[FieldOffset(Offset = "0x1C")]
		public int yellow;

		// Token: 0x0400ED1E RID: 60702
		[Token(Token = "0x400ED1E")]
		[FieldOffset(Offset = "0x20")]
		public int pink;
	}
}
