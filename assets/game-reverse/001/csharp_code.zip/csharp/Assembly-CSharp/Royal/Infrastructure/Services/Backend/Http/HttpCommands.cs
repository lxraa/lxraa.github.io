﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Http.Command;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http
{
	// Token: 0x02002507 RID: 9479
	[Token(Token = "0x2002507")]
	public class HttpCommands
	{
		// Token: 0x0601283A RID: 75834 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601283A")]
		[Address(RVA = "0x1F8B39C", Offset = "0x1F8B39C", VA = "0x1F8B39C")]
		public HttpCommands([Optional] Uri endpoint, bool syncRequired = false)
		{
		}

		// Token: 0x14000097 RID: 151
		// (add) Token: 0x0601283B RID: 75835 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x0601283C RID: 75836 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x14000097")]
		public event HttpCommands.ConnectionComplete OnComplete
		{
			[Token(Token = "0x601283B")]
			[Address(RVA = "0x1F8BCE8", Offset = "0x1F8BCE8", VA = "0x1F8BCE8")]
			add
			{
			}
			[Token(Token = "0x601283C")]
			[Address(RVA = "0x1F8E3E4", Offset = "0x1F8E3E4", VA = "0x1F8E3E4")]
			remove
			{
			}
		}

		// Token: 0x170026BB RID: 9915
		// (get) Token: 0x0601283D RID: 75837 RVA: 0x00077100 File Offset: 0x00075300
		// (set) Token: 0x0601283E RID: 75838 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026BB")]
		public bool SyncRequired
		{
			[Token(Token = "0x601283D")]
			[Address(RVA = "0x1F8E43C", Offset = "0x1F8E43C", VA = "0x1F8E43C")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x601283E")]
			[Address(RVA = "0x1F8E444", Offset = "0x1F8E444", VA = "0x1F8E444")]
			set
			{
			}
		}

		// Token: 0x170026BC RID: 9916
		// (get) Token: 0x0601283F RID: 75839 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012840 RID: 75840 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026BC")]
		public Uri Endpoint
		{
			[Token(Token = "0x601283F")]
			[Address(RVA = "0x1F8E450", Offset = "0x1F8E450", VA = "0x1F8E450")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012840")]
			[Address(RVA = "0x1F8E458", Offset = "0x1F8E458", VA = "0x1F8E458")]
			set
			{
			}
		}

		// Token: 0x170026BD RID: 9917
		// (get) Token: 0x06012841 RID: 75841 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012842 RID: 75842 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026BD")]
		public string EndpointName
		{
			[Token(Token = "0x6012841")]
			[Address(RVA = "0x1F8E460", Offset = "0x1F8E460", VA = "0x1F8E460")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012842")]
			[Address(RVA = "0x1F8E468", Offset = "0x1F8E468", VA = "0x1F8E468")]
			set
			{
			}
		}

		// Token: 0x170026BE RID: 9918
		// (get) Token: 0x06012843 RID: 75843 RVA: 0x00077118 File Offset: 0x00075318
		// (set) Token: 0x06012844 RID: 75844 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026BE")]
		public int PackageId
		{
			[Token(Token = "0x6012843")]
			[Address(RVA = "0x1F8E470", Offset = "0x1F8E470", VA = "0x1F8E470")]
			get
			{
				return 0;
			}
			[Token(Token = "0x6012844")]
			[Address(RVA = "0x1F8E478", Offset = "0x1F8E478", VA = "0x1F8E478")]
			private set
			{
			}
		}

		// Token: 0x06012845 RID: 75845 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012845")]
		[Address(RVA = "0x1F8BD98", Offset = "0x1F8BD98", VA = "0x1F8BD98")]
		public void Add(BaseHttpCommand httpCommand)
		{
		}

		// Token: 0x06012846 RID: 75846 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012846")]
		[Address(RVA = "0x1F8D564", Offset = "0x1F8D564", VA = "0x1F8D564")]
		public void Append(HttpCommands commandsToAppend)
		{
		}

		// Token: 0x06012847 RID: 75847 RVA: 0x00077130 File Offset: 0x00075330
		[Token(Token = "0x6012847")]
		[Address(RVA = "0x1F8E480", Offset = "0x1F8E480", VA = "0x1F8E480")]
		public bool HasRequestType(RequestType requestType)
		{
			return default(bool);
		}

		// Token: 0x06012848 RID: 75848 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012848")]
		[Address(RVA = "0x1F8E534", Offset = "0x1F8E534", VA = "0x1F8E534")]
		public byte[] PrepareRequests()
		{
			return null;
		}

		// Token: 0x06012849 RID: 75849 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012849")]
		[Address(RVA = "0x1F8ED18", Offset = "0x1F8ED18", VA = "0x1F8ED18")]
		public void Finish(byte[] data)
		{
		}

		// Token: 0x0601284A RID: 75850 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601284A")]
		[Address(RVA = "0x1F8FA14", Offset = "0x1F8FA14", VA = "0x1F8FA14")]
		public static void LogHttpRequestResponsePackage(object callerClass, int packageId, string endpointName, byte[] data, bool isRequest, [Optional] ResponsePackage responsePackage)
		{
		}

		// Token: 0x0601284B RID: 75851 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601284B")]
		[Address(RVA = "0x1F909EC", Offset = "0x1F909EC", VA = "0x1F909EC")]
		private static ResponseType[] IsExistingResponseTypesCauseSkip(object callerClass, ResponsePackage responsePackage)
		{
			return null;
		}

		// Token: 0x0601284C RID: 75852 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601284C")]
		[Address(RVA = "0x1F90054", Offset = "0x1F90054", VA = "0x1F90054")]
		private void Success(long serverTime)
		{
		}

		// Token: 0x0601284D RID: 75853 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601284D")]
		[Address(RVA = "0x1F90D28", Offset = "0x1F90D28", VA = "0x1F90D28")]
		private void SyncFail()
		{
		}

		// Token: 0x0601284E RID: 75854 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601284E")]
		[Address(RVA = "0x1F8F5A8", Offset = "0x1F8F5A8", VA = "0x1F8F5A8")]
		public void Fail(string failReason = "Finished")
		{
		}

		// Token: 0x0601284F RID: 75855 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601284F")]
		[Address(RVA = "0x1F913F8", Offset = "0x1F913F8", VA = "0x1F913F8")]
		public BaseHttpCommand FindCommandByType(ResponseType responseType)
		{
			return null;
		}

		// Token: 0x06012850 RID: 75856 RVA: 0x00077148 File Offset: 0x00075348
		[Token(Token = "0x6012850")]
		[Address(RVA = "0x1F913A0", Offset = "0x1F913A0", VA = "0x1F913A0")]
		private bool IsResponseTypeExist(ResponseType commandType, int index)
		{
			return default(bool);
		}

		// Token: 0x06012851 RID: 75857 RVA: 0x00077160 File Offset: 0x00075360
		[Token(Token = "0x6012851")]
		[Address(RVA = "0x1F8D4B4", Offset = "0x1F8D4B4", VA = "0x1F8D4B4")]
		public int Size()
		{
			return 0;
		}

		// Token: 0x06012852 RID: 75858 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012852")]
		[Address(RVA = "0x1F91570", Offset = "0x1F91570", VA = "0x1F91570")]
		public void ForceComplete()
		{
		}

		// Token: 0x06012853 RID: 75859 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012853")]
		[Address(RVA = "0x1F8D4FC", Offset = "0x1F8D4FC", VA = "0x1F8D4FC")]
		public string GetRequestTypesCommaSeparated()
		{
			return null;
		}

		// Token: 0x0400EA64 RID: 60004
		[Token(Token = "0x400EA64")]
		private const string RemovedCommandDelimiter = ",";

		// Token: 0x0400EA65 RID: 60005
		[Token(Token = "0x400EA65")]
		private const string Separator = ", ";

		// Token: 0x0400EA66 RID: 60006
		[Token(Token = "0x400EA66")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private static int PackageCounter;

		// Token: 0x0400EA67 RID: 60007
		[Token(Token = "0x400EA67")]
		private const string FailReasonFinished = "Finished";

		// Token: 0x0400EA68 RID: 60008
		[Token(Token = "0x400EA68")]
		public const string FailReasonCancelled = "Cancelled";

		// Token: 0x0400EA69 RID: 60009
		[Token(Token = "0x400EA69")]
		public const string FailReasonNoUserTokenProvided = "NoUserTokenProvided";

		// Token: 0x0400EA6A RID: 60010
		[Token(Token = "0x400EA6A")]
		private const string FailReasonServerTimeNotUpdated = "ServerTimeNotUpdated";

		// Token: 0x0400EA6B RID: 60011
		[Token(Token = "0x400EA6B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		private readonly List<HttpCommands.ConnectionComplete> list;

		// Token: 0x0400EA6C RID: 60012
		[Token(Token = "0x400EA6C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
		private static readonly long[] abTests;

		// Token: 0x0400EA6D RID: 60013
		[Token(Token = "0x400EA6D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		private bool <SyncRequired>k__BackingField;

		// Token: 0x0400EA6E RID: 60014
		[Token(Token = "0x400EA6E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		private Uri <Endpoint>k__BackingField;

		// Token: 0x0400EA6F RID: 60015
		[Token(Token = "0x400EA6F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		private string <EndpointName>k__BackingField;

		// Token: 0x0400EA70 RID: 60016
		[Token(Token = "0x400EA70")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
		private int <PackageId>k__BackingField;

		// Token: 0x0400EA71 RID: 60017
		[Token(Token = "0x400EA71")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x34")]
		private int requestFocus;

		// Token: 0x0400EA72 RID: 60018
		[Token(Token = "0x400EA72")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x38")]
		private long requestUserId;

		// Token: 0x0400EA73 RID: 60019
		[Token(Token = "0x400EA73")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x40")]
		private readonly FlatBufferBuilder requestBuilder;

		// Token: 0x0400EA74 RID: 60020
		[Token(Token = "0x400EA74")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x48")]
		private readonly List<RequestType> requestTypes;

		// Token: 0x0400EA75 RID: 60021
		[Token(Token = "0x400EA75")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x50")]
		private readonly List<BaseHttpCommand> commands;

		// Token: 0x0400EA76 RID: 60022
		[Token(Token = "0x400EA76")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x58")]
		private ResponsePackage response;

		// Token: 0x02002508 RID: 9480
		// (Invoke) Token: 0x06012856 RID: 75862
		[Token(Token = "0x2002508")]
		public delegate void ConnectionComplete(bool isSuccess, HttpCommands container);

		// Token: 0x02002509 RID: 9481
		[Token(Token = "0x2002509")]
		private sealed class <>c__DisplayClass42_0
		{
			// Token: 0x06012859 RID: 75865 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012859")]
			[Address(RVA = "0x1F90D20", Offset = "0x1F90D20", VA = "0x1F90D20")]
			public <>c__DisplayClass42_0()
			{
			}

			// Token: 0x0601285A RID: 75866 RVA: 0x00077178 File Offset: 0x00075378
			[Token(Token = "0x601285A")]
			[Address(RVA = "0x1F918E0", Offset = "0x1F918E0", VA = "0x1F918E0")]
			internal ResponseType <IsExistingResponseTypesCauseSkip>b__0(int i)
			{
				return ResponseType.NONE;
			}

			// Token: 0x0400EA77 RID: 60023
			[Token(Token = "0x400EA77")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public ResponsePackage responsePackage;
		}

		// Token: 0x0200250A RID: 9482
		[Token(Token = "0x200250A")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x0601285C RID: 75868 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601285C")]
			[Address(RVA = "0x1CE6748", Offset = "0x1CE6748", VA = "0x1CE6748")]
			public <>c()
			{
			}

			// Token: 0x0601285D RID: 75869 RVA: 0x00077190 File Offset: 0x00075390
			[Token(Token = "0x601285D")]
			[Address(RVA = "0x1CE6750", Offset = "0x1CE6750", VA = "0x1CE6750")]
			internal bool <IsExistingResponseTypesCauseSkip>b__42_1(ResponseType rt)
			{
				return default(bool);
			}

			// Token: 0x0400EA78 RID: 60024
			[Token(Token = "0x400EA78")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
			public static readonly HttpCommands.<>c <>9;

			// Token: 0x0400EA79 RID: 60025
			[Token(Token = "0x400EA79")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
			public static Func<ResponseType, bool> <>9__42_1;
		}
	}
}
