﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Logs;

namespace Royal.Infrastructure.Services.Analytics.Event
{
	// Token: 0x020025A6 RID: 9638
	[Token(Token = "0x20025A6")]
	public class EventSender
	{
		// Token: 0x06012D7C RID: 77180 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D7C")]
		[Address(RVA = "0x243D230", Offset = "0x243D230", VA = "0x243D230")]
		public EventSender()
		{
		}

		// Token: 0x06012D7D RID: 77181 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D7D")]
		[Address(RVA = "0x243D6A4", Offset = "0x243D6A4", VA = "0x243D6A4")]
		public void SendEvent(EventData data)
		{
		}

		// Token: 0x06012D7E RID: 77182 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D7E")]
		[Address(RVA = "0x243D74C", Offset = "0x243D74C", VA = "0x243D74C")]
		public void FocusChanged(bool focusIn, bool quit = false)
		{
		}

		// Token: 0x06012D7F RID: 77183 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D7F")]
		[Address(RVA = "0x243D850", Offset = "0x243D850", VA = "0x243D850")]
		public void ClearEvents()
		{
		}

		// Token: 0x06012D80 RID: 77184 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D80")]
		[Address(RVA = "0x243D964", Offset = "0x243D964", VA = "0x243D964")]
		public void AddKillEvent(string killEvent)
		{
		}

		// Token: 0x0400ED52 RID: 60754
		[Token(Token = "0x400ED52")]
		[FieldOffset(Offset = "0x10")]
		private readonly EventWriter eventWriter;

		// Token: 0x0400ED53 RID: 60755
		[Token(Token = "0x400ED53")]
		[FieldOffset(Offset = "0x18")]
		private readonly LogService logService;
	}
}
