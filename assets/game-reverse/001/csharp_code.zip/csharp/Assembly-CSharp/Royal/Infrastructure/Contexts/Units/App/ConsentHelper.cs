﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025C1 RID: 9665
	[Token(Token = "0x20025C1")]
	public class ConsentHelper
	{
		// Token: 0x170027FE RID: 10238
		// (get) Token: 0x06012E96 RID: 77462 RVA: 0x0007A3D0 File Offset: 0x000785D0
		// (set) Token: 0x06012E97 RID: 77463 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027FE")]
		public bool RequiresConsent
		{
			[Token(Token = "0x6012E96")]
			[Address(RVA = "0x244F348", Offset = "0x244F348", VA = "0x244F348")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E97")]
			[Address(RVA = "0x244F350", Offset = "0x244F350", VA = "0x244F350")]
			private set
			{
			}
		}

		// Token: 0x06012E98 RID: 77464 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E98")]
		[Address(RVA = "0x244D1A0", Offset = "0x244D1A0", VA = "0x244D1A0")]
		public void OnApplicationPause()
		{
		}

		// Token: 0x06012E99 RID: 77465 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E99")]
		[Address(RVA = "0x244D70C", Offset = "0x244D70C", VA = "0x244D70C")]
		public void OnApplicationResume()
		{
		}

		// Token: 0x06012E9A RID: 77466 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012E9A")]
		[Address(RVA = "0x244F44C", Offset = "0x244F44C", VA = "0x244F44C")]
		public IEnumerator WaitForConsent(Action onConsentGiven)
		{
			return null;
		}

		// Token: 0x06012E9B RID: 77467 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E9B")]
		[Address(RVA = "0x244F504", Offset = "0x244F504", VA = "0x244F504")]
		public void InitConsent(bool newInstall)
		{
		}

		// Token: 0x06012E9C RID: 77468 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E9C")]
		[Address(RVA = "0x2447AB8", Offset = "0x2447AB8", VA = "0x2447AB8")]
		public void GiveConsent(bool isShown = true)
		{
		}

		// Token: 0x06012E9D RID: 77469 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E9D")]
		[Address(RVA = "0x244F3D4", Offset = "0x244F3D4", VA = "0x244F3D4")]
		private void ShowConsent()
		{
		}

		// Token: 0x06012E9E RID: 77470 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E9E")]
		[Address(RVA = "0x244F35C", Offset = "0x244F35C", VA = "0x244F35C")]
		private void HideConsent()
		{
		}

		// Token: 0x06012E9F RID: 77471 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E9F")]
		[Address(RVA = "0x2447CC4", Offset = "0x2447CC4", VA = "0x2447CC4")]
		public void Start(VersionHelper versionHelper)
		{
		}

		// Token: 0x06012EA0 RID: 77472 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EA0")]
		[Address(RVA = "0x244DB70", Offset = "0x244DB70", VA = "0x244DB70")]
		public ConsentHelper()
		{
		}

		// Token: 0x0400EEAC RID: 61100
		[Token(Token = "0x400EEAC")]
		private const byte NotRequired = 0;

		// Token: 0x0400EEAD RID: 61101
		[Token(Token = "0x400EEAD")]
		public const byte RequiredNewInstall = 1;

		// Token: 0x0400EEAE RID: 61102
		[Token(Token = "0x400EEAE")]
		private const byte RequiredOther = 2;

		// Token: 0x0400EEAF RID: 61103
		[Token(Token = "0x400EEAF")]
		[FieldOffset(Offset = "0x10")]
		private bool reshowConsentOnResume;

		// Token: 0x0400EEB0 RID: 61104
		[Token(Token = "0x400EEB0")]
		[FieldOffset(Offset = "0x11")]
		private bool <RequiresConsent>k__BackingField;

		// Token: 0x020025C2 RID: 9666
		[Token(Token = "0x20025C2")]
		private sealed class <WaitForConsent>d__10 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012EA1 RID: 77473 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012EA1")]
			[Address(RVA = "0x244F4DC", Offset = "0x244F4DC", VA = "0x244F4DC")]
			[DebuggerHidden]
			public <WaitForConsent>d__10(int <>1__state)
			{
			}

			// Token: 0x06012EA2 RID: 77474 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012EA2")]
			[Address(RVA = "0x244F574", Offset = "0x244F574", VA = "0x244F574", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012EA3 RID: 77475 RVA: 0x0007A3E8 File Offset: 0x000785E8
			[Token(Token = "0x6012EA3")]
			[Address(RVA = "0x244F578", Offset = "0x244F578", VA = "0x244F578", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x170027FF RID: 10239
			// (get) Token: 0x06012EA4 RID: 77476 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170027FF")]
			private object Current
			{
				[Token(Token = "0x6012EA4")]
				[Address(RVA = "0x244F5E8", Offset = "0x244F5E8", VA = "0x244F5E8", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012EA5 RID: 77477 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012EA5")]
			[Address(RVA = "0x244F5F0", Offset = "0x244F5F0", VA = "0x244F5F0", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x17002800 RID: 10240
			// (get) Token: 0x06012EA6 RID: 77478 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x17002800")]
			private object Current
			{
				[Token(Token = "0x6012EA6")]
				[Address(RVA = "0x244F630", Offset = "0x244F630", VA = "0x244F630", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EEB1 RID: 61105
			[Token(Token = "0x400EEB1")]
			[FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EEB2 RID: 61106
			[Token(Token = "0x400EEB2")]
			[FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EEB3 RID: 61107
			[Token(Token = "0x400EEB3")]
			[FieldOffset(Offset = "0x20")]
			public ConsentHelper <>4__this;

			// Token: 0x0400EEB4 RID: 61108
			[Token(Token = "0x400EEB4")]
			[FieldOffset(Offset = "0x28")]
			public Action onConsentGiven;
		}

		// Token: 0x020025C3 RID: 9667
		[Token(Token = "0x20025C3")]
		private sealed class <>c__DisplayClass15_0
		{
			// Token: 0x06012EA7 RID: 77479 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012EA7")]
			[Address(RVA = "0x244F56C", Offset = "0x244F56C", VA = "0x244F56C")]
			public <>c__DisplayClass15_0()
			{
			}

			// Token: 0x06012EA8 RID: 77480 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012EA8")]
			[Address(RVA = "0x244F638", Offset = "0x244F638", VA = "0x244F638")]
			internal void <Start>b__0()
			{
			}

			// Token: 0x0400EEB5 RID: 61109
			[Token(Token = "0x400EEB5")]
			[FieldOffset(Offset = "0x10")]
			public int previousConsentState;

			// Token: 0x0400EEB6 RID: 61110
			[Token(Token = "0x400EEB6")]
			[FieldOffset(Offset = "0x14")]
			public bool firstStartAfterInstall;

			// Token: 0x0400EEB7 RID: 61111
			[Token(Token = "0x400EEB7")]
			[FieldOffset(Offset = "0x15")]
			public bool newInstall;
		}
	}
}
