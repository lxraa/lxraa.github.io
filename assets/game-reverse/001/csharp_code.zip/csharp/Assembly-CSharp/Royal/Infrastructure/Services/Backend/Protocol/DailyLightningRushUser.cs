﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002379 RID: 9081
	[Token(Token = "0x2002379")]
	public struct DailyLightningRushUser : IFlatbufferObject
	{
		// Token: 0x17001FAF RID: 8111
		// (get) Token: 0x06010ECA RID: 69322 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FAF")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010ECA")]
			[Address(RVA = "0x1F9466C", Offset = "0x1F9466C", VA = "0x1F9466C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010ECB RID: 69323 RVA: 0x00062898 File Offset: 0x00060A98
		[Token(Token = "0x6010ECB")]
		[Address(RVA = "0x1F94674", Offset = "0x1F94674", VA = "0x1F94674")]
		public static DailyLightningRushUser GetRootAsDailyLightningRushUser(ByteBuffer _bb)
		{
			return default(DailyLightningRushUser);
		}

		// Token: 0x06010ECC RID: 69324 RVA: 0x000628B0 File Offset: 0x00060AB0
		[Token(Token = "0x6010ECC")]
		[Address(RVA = "0x1F94680", Offset = "0x1F94680", VA = "0x1F94680")]
		public static DailyLightningRushUser GetRootAsDailyLightningRushUser(ByteBuffer _bb, DailyLightningRushUser obj)
		{
			return default(DailyLightningRushUser);
		}

		// Token: 0x06010ECD RID: 69325 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010ECD")]
		[Address(RVA = "0x1F946F8", Offset = "0x1F946F8", VA = "0x1F946F8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010ECE RID: 69326 RVA: 0x000628C8 File Offset: 0x00060AC8
		[Token(Token = "0x6010ECE")]
		[Address(RVA = "0x1F93ADC", Offset = "0x1F93ADC", VA = "0x1F93ADC")]
		public DailyLightningRushUser __assign(int _i, ByteBuffer _bb)
		{
			return default(DailyLightningRushUser);
		}

		// Token: 0x17001FB0 RID: 8112
		// (get) Token: 0x06010ECF RID: 69327 RVA: 0x000628E0 File Offset: 0x00060AE0
		[Token(Token = "0x17001FB0")]
		public long UserId
		{
			[Token(Token = "0x6010ECF")]
			[Address(RVA = "0x1F94708", Offset = "0x1F94708", VA = "0x1F94708")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FB1 RID: 8113
		// (get) Token: 0x06010ED0 RID: 69328 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FB1")]
		public string Name
		{
			[Token(Token = "0x6010ED0")]
			[Address(RVA = "0x1F94750", Offset = "0x1F94750", VA = "0x1F94750")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010ED1 RID: 69329 RVA: 0x000628F8 File Offset: 0x00060AF8
		[Token(Token = "0x6010ED1")]
		[Address(RVA = "0x1F9478C", Offset = "0x1F9478C", VA = "0x1F9478C")]
		public ArraySegment<byte>? GetNameBytes()
		{
			return null;
		}

		// Token: 0x06010ED2 RID: 69330 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010ED2")]
		[Address(RVA = "0x1F947C4", Offset = "0x1F947C4", VA = "0x1F947C4")]
		public byte[] GetNameArray()
		{
			return null;
		}

		// Token: 0x17001FB2 RID: 8114
		// (get) Token: 0x06010ED3 RID: 69331 RVA: 0x00062910 File Offset: 0x00060B10
		[Token(Token = "0x17001FB2")]
		public int Score
		{
			[Token(Token = "0x6010ED3")]
			[Address(RVA = "0x1F94810", Offset = "0x1F94810", VA = "0x1F94810")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FB3 RID: 8115
		// (get) Token: 0x06010ED4 RID: 69332 RVA: 0x00062928 File Offset: 0x00060B28
		[Token(Token = "0x17001FB3")]
		public long LastUpdateDate
		{
			[Token(Token = "0x6010ED4")]
			[Address(RVA = "0x1F94854", Offset = "0x1F94854", VA = "0x1F94854")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FB4 RID: 8116
		// (get) Token: 0x06010ED5 RID: 69333 RVA: 0x00062940 File Offset: 0x00060B40
		[Token(Token = "0x17001FB4")]
		public bool DeprecatedIsGold
		{
			[Token(Token = "0x6010ED5")]
			[Address(RVA = "0x1F9489C", Offset = "0x1F9489C", VA = "0x1F9489C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001FB5 RID: 8117
		// (get) Token: 0x06010ED6 RID: 69334 RVA: 0x00062958 File Offset: 0x00060B58
		[Token(Token = "0x17001FB5")]
		public ProfileSetting? ProfileSetting
		{
			[Token(Token = "0x6010ED6")]
			[Address(RVA = "0x1F948E4", Offset = "0x1F948E4", VA = "0x1F948E4")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010ED7 RID: 69335 RVA: 0x00062970 File Offset: 0x00060B70
		[Token(Token = "0x6010ED7")]
		[Address(RVA = "0x1F949A4", Offset = "0x1F949A4", VA = "0x1F949A4")]
		public static Offset<DailyLightningRushUser> CreateDailyLightningRushUser(FlatBufferBuilder builder, long user_id = 0L, [Optional] StringOffset nameOffset, int score = 0, long last_update_date = 0L, bool deprecated_is_gold = false, [Optional] Offset<ProfileSetting> profile_settingOffset)
		{
			return default(Offset<DailyLightningRushUser>);
		}

		// Token: 0x06010ED8 RID: 69336 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010ED8")]
		[Address(RVA = "0x1F94B78", Offset = "0x1F94B78", VA = "0x1F94B78")]
		public static void StartDailyLightningRushUser(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010ED9 RID: 69337 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010ED9")]
		[Address(RVA = "0x1F94A6C", Offset = "0x1F94A6C", VA = "0x1F94A6C")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010EDA RID: 69338 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EDA")]
		[Address(RVA = "0x1F94ACC", Offset = "0x1F94ACC", VA = "0x1F94ACC")]
		public static void AddName(FlatBufferBuilder builder, StringOffset nameOffset)
		{
		}

		// Token: 0x06010EDB RID: 69339 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EDB")]
		[Address(RVA = "0x1F94AAC", Offset = "0x1F94AAC", VA = "0x1F94AAC")]
		public static void AddScore(FlatBufferBuilder builder, int score)
		{
		}

		// Token: 0x06010EDC RID: 69340 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EDC")]
		[Address(RVA = "0x1F94A4C", Offset = "0x1F94A4C", VA = "0x1F94A4C")]
		public static void AddLastUpdateDate(FlatBufferBuilder builder, long lastUpdateDate)
		{
		}

		// Token: 0x06010EDD RID: 69341 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EDD")]
		[Address(RVA = "0x1F94AEC", Offset = "0x1F94AEC", VA = "0x1F94AEC")]
		public static void AddDeprecatedIsGold(FlatBufferBuilder builder, bool deprecatedIsGold)
		{
		}

		// Token: 0x06010EDE RID: 69342 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EDE")]
		[Address(RVA = "0x1F94A8C", Offset = "0x1F94A8C", VA = "0x1F94A8C")]
		public static void AddProfileSetting(FlatBufferBuilder builder, Offset<ProfileSetting> profileSettingOffset)
		{
		}

		// Token: 0x06010EDF RID: 69343 RVA: 0x00062988 File Offset: 0x00060B88
		[Token(Token = "0x6010EDF")]
		[Address(RVA = "0x1F94B0C", Offset = "0x1F94B0C", VA = "0x1F94B0C")]
		public static Offset<DailyLightningRushUser> EndDailyLightningRushUser(FlatBufferBuilder builder)
		{
			return default(Offset<DailyLightningRushUser>);
		}

		// Token: 0x0400E692 RID: 59026
		[Token(Token = "0x400E692")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
