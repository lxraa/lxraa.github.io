﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002518 RID: 9496
	[Token(Token = "0x2002518")]
	public class LeaderboardHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026D7 RID: 9943
		// (get) Token: 0x060128D9 RID: 75993 RVA: 0x00077568 File Offset: 0x00075768
		[Token(Token = "0x170026D7")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60128D9")]
			[Address(RVA = "0x1CEB828", Offset = "0x1CEB828", VA = "0x1CEB828", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026D8 RID: 9944
		// (get) Token: 0x060128DA RID: 75994 RVA: 0x00077580 File Offset: 0x00075780
		[Token(Token = "0x170026D8")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60128DA")]
			[Address(RVA = "0x1CEB830", Offset = "0x1CEB830", VA = "0x1CEB830", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026D9 RID: 9945
		// (get) Token: 0x060128DB RID: 75995 RVA: 0x00077598 File Offset: 0x00075798
		// (set) Token: 0x060128DC RID: 75996 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026D9")]
		private LeaderboardResponse Response
		{
			[Token(Token = "0x60128DB")]
			[Address(RVA = "0x1CEB838", Offset = "0x1CEB838", VA = "0x1CEB838")]
			get
			{
				return default(LeaderboardResponse);
			}
			[Token(Token = "0x60128DC")]
			[Address(RVA = "0x1CEB844", Offset = "0x1CEB844", VA = "0x1CEB844")]
			set
			{
			}
		}

		// Token: 0x060128DD RID: 75997 RVA: 0x000775B0 File Offset: 0x000757B0
		[Token(Token = "0x60128DD")]
		[Address(RVA = "0x1CEB854", Offset = "0x1CEB854", VA = "0x1CEB854", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060128DE RID: 75998 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128DE")]
		[Address(RVA = "0x1CEB88C", Offset = "0x1CEB88C", VA = "0x1CEB88C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060128DF RID: 75999 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128DF")]
		[Address(RVA = "0x1CEBA34", Offset = "0x1CEBA34", VA = "0x1CEBA34", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x060128E0 RID: 76000 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128E0")]
		[Address(RVA = "0x1CEBA38", Offset = "0x1CEBA38", VA = "0x1CEBA38")]
		public LeaderboardHttpCommand()
		{
		}

		// Token: 0x0400EAC8 RID: 60104
		[Token(Token = "0x400EAC8")]
		[FieldOffset(Offset = "0x18")]
		private LeaderboardResponse <Response>k__BackingField;
	}
}
