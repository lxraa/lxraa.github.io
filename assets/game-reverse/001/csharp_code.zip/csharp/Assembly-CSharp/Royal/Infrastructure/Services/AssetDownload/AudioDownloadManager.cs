﻿using System;
using System.Collections.Generic;
using System.IO;
using Il2CppDummyDll;
using Royal.Infrastructure.Contexts;
using UnityEngine;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002581 RID: 9601
	[Token(Token = "0x2002581")]
	public class AudioDownloadManager : IContextBehaviour, IContextUnit
	{
		// Token: 0x170027CB RID: 10187
		// (get) Token: 0x06012C2F RID: 76847 RVA: 0x00079740 File Offset: 0x00077940
		[Token(Token = "0x170027CB")]
		public int Id
		{
			[Token(Token = "0x6012C2F")]
			[Address(RVA = "0x1EDA160", Offset = "0x1EDA160", VA = "0x1EDA160", Slot = "5")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170027CC RID: 10188
		// (get) Token: 0x06012C30 RID: 76848 RVA: 0x00079758 File Offset: 0x00077958
		// (set) Token: 0x06012C31 RID: 76849 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027CC")]
		private bool IsDownloading
		{
			[Token(Token = "0x6012C30")]
			[Address(RVA = "0x1EDA168", Offset = "0x1EDA168", VA = "0x1EDA168")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012C31")]
			[Address(RVA = "0x1EDA170", Offset = "0x1EDA170", VA = "0x1EDA170")]
			set
			{
			}
		}

		// Token: 0x06012C32 RID: 76850 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C32")]
		[Address(RVA = "0x1EDA17C", Offset = "0x1EDA17C", VA = "0x1EDA17C", Slot = "6")]
		public void Bind()
		{
		}

		// Token: 0x06012C33 RID: 76851 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C33")]
		[Address(RVA = "0x1EDA1F8", Offset = "0x1EDA1F8", VA = "0x1EDA1F8")]
		private void DownloadMusics()
		{
		}

		// Token: 0x06012C34 RID: 76852 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C34")]
		[Address(RVA = "0x1EDA52C", Offset = "0x1EDA52C", VA = "0x1EDA52C", Slot = "4")]
		public void ManualUpdate()
		{
		}

		// Token: 0x06012C35 RID: 76853 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C35")]
		[Address(RVA = "0x1EDA530", Offset = "0x1EDA530", VA = "0x1EDA530")]
		private void DownloadMusic(string musicToDownload)
		{
		}

		// Token: 0x06012C36 RID: 76854 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C36")]
		[Address(RVA = "0x1EDA350", Offset = "0x1EDA350", VA = "0x1EDA350")]
		public string[] GetDownloadedMusicFileNames()
		{
			return null;
		}

		// Token: 0x06012C37 RID: 76855 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C37")]
		[Address(RVA = "0x1EDA538", Offset = "0x1EDA538", VA = "0x1EDA538")]
		private static string[] GetMusicFileNamesToDownload()
		{
			return null;
		}

		// Token: 0x06012C38 RID: 76856 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C38")]
		[Address(RVA = "0x1EDA590", Offset = "0x1EDA590", VA = "0x1EDA590")]
		public AudioClip LoadMusicFromFile(string musicName, AudioType audioType = AudioType.MPEG)
		{
			return null;
		}

		// Token: 0x06012C39 RID: 76857 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C39")]
		[Address(RVA = "0x1EDA954", Offset = "0x1EDA954", VA = "0x1EDA954")]
		public AudioDownloadManager()
		{
		}

		// Token: 0x0400EC3A RID: 60474
		[Token(Token = "0x400EC3A")]
		[FieldOffset(Offset = "0x10")]
		private readonly string musicsDirectory;

		// Token: 0x0400EC3B RID: 60475
		[Token(Token = "0x400EC3B")]
		[FieldOffset(Offset = "0x18")]
		private readonly Queue<string> musicsToDownload;

		// Token: 0x0400EC3C RID: 60476
		[Token(Token = "0x400EC3C")]
		[FieldOffset(Offset = "0x20")]
		private FileDownloadManager fileDownloadManager;

		// Token: 0x0400EC3D RID: 60477
		[Token(Token = "0x400EC3D")]
		[FieldOffset(Offset = "0x28")]
		private bool <IsDownloading>k__BackingField;

		// Token: 0x02002582 RID: 9602
		[Token(Token = "0x2002582")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06012C3B RID: 76859 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012C3B")]
			[Address(RVA = "0x1EDAABC", Offset = "0x1EDAABC", VA = "0x1EDAABC")]
			public <>c()
			{
			}

			// Token: 0x06012C3C RID: 76860 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012C3C")]
			[Address(RVA = "0x1EDAAC4", Offset = "0x1EDAAC4", VA = "0x1EDAAC4")]
			internal string <GetDownloadedMusicFileNames>b__13_0(FileInfo t)
			{
				return null;
			}

			// Token: 0x0400EC3E RID: 60478
			[Token(Token = "0x400EC3E")]
			[FieldOffset(Offset = "0x0")]
			public static readonly AudioDownloadManager.<>c <>9;

			// Token: 0x0400EC3F RID: 60479
			[Token(Token = "0x400EC3F")]
			[FieldOffset(Offset = "0x8")]
			public static Func<FileInfo, string> <>9__13_0;
		}
	}
}
