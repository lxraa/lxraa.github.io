﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002361 RID: 9057
	[Token(Token = "0x2002361")]
	public struct ClaimSkyRaceRewardResponse : IFlatbufferObject
	{
		// Token: 0x17001F3E RID: 7998
		// (get) Token: 0x06010D50 RID: 68944 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F3E")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D50")]
			[Address(RVA = "0x214995C", Offset = "0x214995C", VA = "0x214995C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D51 RID: 68945 RVA: 0x000615C0 File Offset: 0x0005F7C0
		[Token(Token = "0x6010D51")]
		[Address(RVA = "0x2149964", Offset = "0x2149964", VA = "0x2149964")]
		public static ClaimSkyRaceRewardResponse GetRootAsClaimSkyRaceRewardResponse(ByteBuffer _bb)
		{
			return default(ClaimSkyRaceRewardResponse);
		}

		// Token: 0x06010D52 RID: 68946 RVA: 0x000615D8 File Offset: 0x0005F7D8
		[Token(Token = "0x6010D52")]
		[Address(RVA = "0x2149970", Offset = "0x2149970", VA = "0x2149970")]
		public static ClaimSkyRaceRewardResponse GetRootAsClaimSkyRaceRewardResponse(ByteBuffer _bb, ClaimSkyRaceRewardResponse obj)
		{
			return default(ClaimSkyRaceRewardResponse);
		}

		// Token: 0x06010D53 RID: 68947 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D53")]
		[Address(RVA = "0x2149A20", Offset = "0x2149A20", VA = "0x2149A20", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D54 RID: 68948 RVA: 0x000615F0 File Offset: 0x0005F7F0
		[Token(Token = "0x6010D54")]
		[Address(RVA = "0x21499E8", Offset = "0x21499E8", VA = "0x21499E8")]
		public ClaimSkyRaceRewardResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimSkyRaceRewardResponse);
		}

		// Token: 0x17001F3F RID: 7999
		// (get) Token: 0x06010D55 RID: 68949 RVA: 0x00061608 File Offset: 0x0005F808
		[Token(Token = "0x17001F3F")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010D55")]
			[Address(RVA = "0x2149A30", Offset = "0x2149A30", VA = "0x2149A30")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001F40 RID: 8000
		// (get) Token: 0x06010D56 RID: 68950 RVA: 0x00061620 File Offset: 0x0005F820
		[Token(Token = "0x17001F40")]
		public UserProgress? DeprecatedUserProgress
		{
			[Token(Token = "0x6010D56")]
			[Address(RVA = "0x2149A74", Offset = "0x2149A74", VA = "0x2149A74")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F41 RID: 8001
		// (get) Token: 0x06010D57 RID: 68951 RVA: 0x00061638 File Offset: 0x0005F838
		[Token(Token = "0x17001F41")]
		public long RemainingTime
		{
			[Token(Token = "0x6010D57")]
			[Address(RVA = "0x2149B34", Offset = "0x2149B34", VA = "0x2149B34")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F42 RID: 8002
		// (get) Token: 0x06010D58 RID: 68952 RVA: 0x00061650 File Offset: 0x0005F850
		[Token(Token = "0x17001F42")]
		public UserEventStatus UserEventStatus
		{
			[Token(Token = "0x6010D58")]
			[Address(RVA = "0x2149B7C", Offset = "0x2149B7C", VA = "0x2149B7C")]
			get
			{
				return UserEventStatus.Continue;
			}
		}

		// Token: 0x17001F43 RID: 8003
		// (get) Token: 0x06010D59 RID: 68953 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F43")]
		public string Config
		{
			[Token(Token = "0x6010D59")]
			[Address(RVA = "0x2149BC0", Offset = "0x2149BC0", VA = "0x2149BC0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D5A RID: 68954 RVA: 0x00061668 File Offset: 0x0005F868
		[Token(Token = "0x6010D5A")]
		[Address(RVA = "0x2149BFC", Offset = "0x2149BFC", VA = "0x2149BFC")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06010D5B RID: 68955 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010D5B")]
		[Address(RVA = "0x2149C34", Offset = "0x2149C34", VA = "0x2149C34")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x17001F44 RID: 8004
		// (get) Token: 0x06010D5C RID: 68956 RVA: 0x00061680 File Offset: 0x0005F880
		[Token(Token = "0x17001F44")]
		public int ConfigVersion
		{
			[Token(Token = "0x6010D5C")]
			[Address(RVA = "0x2149C80", Offset = "0x2149C80", VA = "0x2149C80")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010D5D RID: 68957 RVA: 0x00061698 File Offset: 0x0005F898
		[Token(Token = "0x6010D5D")]
		[Address(RVA = "0x2149CC4", Offset = "0x2149CC4", VA = "0x2149CC4")]
		public static Offset<ClaimSkyRaceRewardResponse> CreateClaimSkyRaceRewardResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, [Optional] Offset<UserProgress> deprecated_user_progressOffset, long remaining_time = 0L, UserEventStatus user_event_status = UserEventStatus.Continue, [Optional] StringOffset configOffset, int config_version = 0)
		{
			return default(Offset<ClaimSkyRaceRewardResponse>);
		}

		// Token: 0x06010D5E RID: 68958 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D5E")]
		[Address(RVA = "0x2149E98", Offset = "0x2149E98", VA = "0x2149E98")]
		public static void StartClaimSkyRaceRewardResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D5F RID: 68959 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D5F")]
		[Address(RVA = "0x2149E0C", Offset = "0x2149E0C", VA = "0x2149E0C")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010D60 RID: 68960 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D60")]
		[Address(RVA = "0x2149DCC", Offset = "0x2149DCC", VA = "0x2149DCC")]
		public static void AddDeprecatedUserProgress(FlatBufferBuilder builder, Offset<UserProgress> deprecatedUserProgressOffset)
		{
		}

		// Token: 0x06010D61 RID: 68961 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D61")]
		[Address(RVA = "0x2149D6C", Offset = "0x2149D6C", VA = "0x2149D6C")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010D62 RID: 68962 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D62")]
		[Address(RVA = "0x2149DEC", Offset = "0x2149DEC", VA = "0x2149DEC")]
		public static void AddUserEventStatus(FlatBufferBuilder builder, UserEventStatus userEventStatus)
		{
		}

		// Token: 0x06010D63 RID: 68963 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D63")]
		[Address(RVA = "0x2149DAC", Offset = "0x2149DAC", VA = "0x2149DAC")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06010D64 RID: 68964 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D64")]
		[Address(RVA = "0x2149D8C", Offset = "0x2149D8C", VA = "0x2149D8C")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06010D65 RID: 68965 RVA: 0x000616B0 File Offset: 0x0005F8B0
		[Token(Token = "0x6010D65")]
		[Address(RVA = "0x2149E2C", Offset = "0x2149E2C", VA = "0x2149E2C")]
		public static Offset<ClaimSkyRaceRewardResponse> EndClaimSkyRaceRewardResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimSkyRaceRewardResponse>);
		}

		// Token: 0x0400E667 RID: 58983
		[Token(Token = "0x400E667")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
