﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023CD RID: 9165
	[Token(Token = "0x20023CD")]
	public struct GetDragonNestInfoResponse : IFlatbufferObject
	{
		// Token: 0x170020DD RID: 8413
		// (get) Token: 0x06011341 RID: 70465 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020DD")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011341")]
			[Address(RVA = "0x1CADB38", Offset = "0x1CADB38", VA = "0x1CADB38", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011342 RID: 70466 RVA: 0x000663C0 File Offset: 0x000645C0
		[Token(Token = "0x6011342")]
		[Address(RVA = "0x1CADB40", Offset = "0x1CADB40", VA = "0x1CADB40")]
		public static GetDragonNestInfoResponse GetRootAsGetDragonNestInfoResponse(ByteBuffer _bb)
		{
			return default(GetDragonNestInfoResponse);
		}

		// Token: 0x06011343 RID: 70467 RVA: 0x000663D8 File Offset: 0x000645D8
		[Token(Token = "0x6011343")]
		[Address(RVA = "0x1CADB4C", Offset = "0x1CADB4C", VA = "0x1CADB4C")]
		public static GetDragonNestInfoResponse GetRootAsGetDragonNestInfoResponse(ByteBuffer _bb, GetDragonNestInfoResponse obj)
		{
			return default(GetDragonNestInfoResponse);
		}

		// Token: 0x06011344 RID: 70468 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011344")]
		[Address(RVA = "0x1CADBFC", Offset = "0x1CADBFC", VA = "0x1CADBFC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011345 RID: 70469 RVA: 0x000663F0 File Offset: 0x000645F0
		[Token(Token = "0x6011345")]
		[Address(RVA = "0x1CADBC4", Offset = "0x1CADBC4", VA = "0x1CADBC4")]
		public GetDragonNestInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetDragonNestInfoResponse);
		}

		// Token: 0x06011346 RID: 70470 RVA: 0x00066408 File Offset: 0x00064608
		[Token(Token = "0x6011346")]
		[Address(RVA = "0x1CADC0C", Offset = "0x1CADC0C", VA = "0x1CADC0C")]
		public DragonNestGroupInfo? GroupInfoList(int j)
		{
			return null;
		}

		// Token: 0x170020DE RID: 8414
		// (get) Token: 0x06011347 RID: 70471 RVA: 0x00066420 File Offset: 0x00064620
		[Token(Token = "0x170020DE")]
		public int GroupInfoListLength
		{
			[Token(Token = "0x6011347")]
			[Address(RVA = "0x1CADCE4", Offset = "0x1CADCE4", VA = "0x1CADCE4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020DF RID: 8415
		// (get) Token: 0x06011348 RID: 70472 RVA: 0x00066438 File Offset: 0x00064638
		[Token(Token = "0x170020DF")]
		public DragonNestInfo? DragonNestInfo
		{
			[Token(Token = "0x6011348")]
			[Address(RVA = "0x1CADD18", Offset = "0x1CADD18", VA = "0x1CADD18")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011349 RID: 70473 RVA: 0x00066450 File Offset: 0x00064650
		[Token(Token = "0x6011349")]
		[Address(RVA = "0x1CADDD8", Offset = "0x1CADDD8", VA = "0x1CADDD8")]
		public static Offset<GetDragonNestInfoResponse> CreateGetDragonNestInfoResponse(FlatBufferBuilder builder, [Optional] VectorOffset group_info_listOffset, [Optional] Offset<DragonNestInfo> dragon_nest_infoOffset)
		{
			return default(Offset<GetDragonNestInfoResponse>);
		}

		// Token: 0x0601134A RID: 70474 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601134A")]
		[Address(RVA = "0x1CADEDC", Offset = "0x1CADEDC", VA = "0x1CADEDC")]
		public static void StartGetDragonNestInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601134B RID: 70475 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601134B")]
		[Address(RVA = "0x1CADE50", Offset = "0x1CADE50", VA = "0x1CADE50")]
		public static void AddGroupInfoList(FlatBufferBuilder builder, VectorOffset groupInfoListOffset)
		{
		}

		// Token: 0x0601134C RID: 70476 RVA: 0x00066468 File Offset: 0x00064668
		[Token(Token = "0x601134C")]
		[Address(RVA = "0x1CADEF4", Offset = "0x1CADEF4", VA = "0x1CADEF4")]
		public static VectorOffset CreateGroupInfoListVector(FlatBufferBuilder builder, Offset<DragonNestGroupInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601134D RID: 70477 RVA: 0x00066480 File Offset: 0x00064680
		[Token(Token = "0x601134D")]
		[Address(RVA = "0x1CADF9C", Offset = "0x1CADF9C", VA = "0x1CADF9C")]
		public static VectorOffset CreateGroupInfoListVectorBlock(FlatBufferBuilder builder, Offset<DragonNestGroupInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601134E RID: 70478 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601134E")]
		[Address(RVA = "0x1CAE024", Offset = "0x1CAE024", VA = "0x1CAE024")]
		public static void StartGroupInfoListVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x0601134F RID: 70479 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601134F")]
		[Address(RVA = "0x1CADE30", Offset = "0x1CADE30", VA = "0x1CADE30")]
		public static void AddDragonNestInfo(FlatBufferBuilder builder, Offset<DragonNestInfo> dragonNestInfoOffset)
		{
		}

		// Token: 0x06011350 RID: 70480 RVA: 0x00066498 File Offset: 0x00064698
		[Token(Token = "0x6011350")]
		[Address(RVA = "0x1CADE70", Offset = "0x1CADE70", VA = "0x1CADE70")]
		public static Offset<GetDragonNestInfoResponse> EndGetDragonNestInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetDragonNestInfoResponse>);
		}

		// Token: 0x0400E73D RID: 59197
		[Token(Token = "0x400E73D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
