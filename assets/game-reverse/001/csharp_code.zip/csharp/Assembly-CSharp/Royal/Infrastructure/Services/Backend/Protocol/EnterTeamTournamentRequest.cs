﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023AD RID: 9133
	[Token(Token = "0x20023AD")]
	public struct EnterTeamTournamentRequest : IFlatbufferObject
	{
		// Token: 0x1700206F RID: 8303
		// (get) Token: 0x060111A4 RID: 70052 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700206F")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60111A4")]
			[Address(RVA = "0x1F9F718", Offset = "0x1F9F718", VA = "0x1F9F718", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060111A5 RID: 70053 RVA: 0x00064E60 File Offset: 0x00063060
		[Token(Token = "0x60111A5")]
		[Address(RVA = "0x1F9F720", Offset = "0x1F9F720", VA = "0x1F9F720")]
		public static EnterTeamTournamentRequest GetRootAsEnterTeamTournamentRequest(ByteBuffer _bb)
		{
			return default(EnterTeamTournamentRequest);
		}

		// Token: 0x060111A6 RID: 70054 RVA: 0x00064E78 File Offset: 0x00063078
		[Token(Token = "0x60111A6")]
		[Address(RVA = "0x1F9F72C", Offset = "0x1F9F72C", VA = "0x1F9F72C")]
		public static EnterTeamTournamentRequest GetRootAsEnterTeamTournamentRequest(ByteBuffer _bb, EnterTeamTournamentRequest obj)
		{
			return default(EnterTeamTournamentRequest);
		}

		// Token: 0x060111A7 RID: 70055 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111A7")]
		[Address(RVA = "0x1F9F7DC", Offset = "0x1F9F7DC", VA = "0x1F9F7DC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060111A8 RID: 70056 RVA: 0x00064E90 File Offset: 0x00063090
		[Token(Token = "0x60111A8")]
		[Address(RVA = "0x1F9F7A4", Offset = "0x1F9F7A4", VA = "0x1F9F7A4")]
		public EnterTeamTournamentRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterTeamTournamentRequest);
		}

		// Token: 0x17002070 RID: 8304
		// (get) Token: 0x060111A9 RID: 70057 RVA: 0x00064EA8 File Offset: 0x000630A8
		[Token(Token = "0x17002070")]
		public long TeamId
		{
			[Token(Token = "0x60111A9")]
			[Address(RVA = "0x1F9F7EC", Offset = "0x1F9F7EC", VA = "0x1F9F7EC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17002071 RID: 8305
		// (get) Token: 0x060111AA RID: 70058 RVA: 0x00064EC0 File Offset: 0x000630C0
		[Token(Token = "0x17002071")]
		public int TotalScore
		{
			[Token(Token = "0x60111AA")]
			[Address(RVA = "0x1F9F834", Offset = "0x1F9F834", VA = "0x1F9F834")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002072 RID: 8306
		// (get) Token: 0x060111AB RID: 70059 RVA: 0x00064ED8 File Offset: 0x000630D8
		[Token(Token = "0x17002072")]
		public int Level
		{
			[Token(Token = "0x60111AB")]
			[Address(RVA = "0x1F9F878", Offset = "0x1F9F878", VA = "0x1F9F878")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002073 RID: 8307
		// (get) Token: 0x060111AC RID: 70060 RVA: 0x00064EF0 File Offset: 0x000630F0
		[Token(Token = "0x17002073")]
		public int EventId
		{
			[Token(Token = "0x60111AC")]
			[Address(RVA = "0x1F9F8BC", Offset = "0x1F9F8BC", VA = "0x1F9F8BC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060111AD RID: 70061 RVA: 0x00064F08 File Offset: 0x00063108
		[Token(Token = "0x60111AD")]
		[Address(RVA = "0x1F9F900", Offset = "0x1F9F900", VA = "0x1F9F900")]
		public static Offset<EnterTeamTournamentRequest> CreateEnterTeamTournamentRequest(FlatBufferBuilder builder, long team_id = 0L, int total_score = 0, int level = 0, int event_id = 0)
		{
			return default(Offset<EnterTeamTournamentRequest>);
		}

		// Token: 0x060111AE RID: 70062 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111AE")]
		[Address(RVA = "0x1F9FA6C", Offset = "0x1F9FA6C", VA = "0x1F9FA6C")]
		public static void StartEnterTeamTournamentRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060111AF RID: 70063 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111AF")]
		[Address(RVA = "0x1F9F980", Offset = "0x1F9F980", VA = "0x1F9F980")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x060111B0 RID: 70064 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111B0")]
		[Address(RVA = "0x1F9F9E0", Offset = "0x1F9F9E0", VA = "0x1F9F9E0")]
		public static void AddTotalScore(FlatBufferBuilder builder, int totalScore)
		{
		}

		// Token: 0x060111B1 RID: 70065 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111B1")]
		[Address(RVA = "0x1F9F9C0", Offset = "0x1F9F9C0", VA = "0x1F9F9C0")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x060111B2 RID: 70066 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111B2")]
		[Address(RVA = "0x1F9F9A0", Offset = "0x1F9F9A0", VA = "0x1F9F9A0")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x060111B3 RID: 70067 RVA: 0x00064F20 File Offset: 0x00063120
		[Token(Token = "0x60111B3")]
		[Address(RVA = "0x1F9FA00", Offset = "0x1F9FA00", VA = "0x1F9FA00")]
		public static Offset<EnterTeamTournamentRequest> EndEnterTeamTournamentRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterTeamTournamentRequest>);
		}

		// Token: 0x0400E6DF RID: 59103
		[Token(Token = "0x400E6DF")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
