﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B0 RID: 9136
	[Token(Token = "0x20023B0")]
	public struct EnterWeeklyLeaderboardResponse : IFlatbufferObject
	{
		// Token: 0x1700207C RID: 8316
		// (get) Token: 0x060111D2 RID: 70098 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700207C")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60111D2")]
			[Address(RVA = "0x1FA0168", Offset = "0x1FA0168", VA = "0x1FA0168", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060111D3 RID: 70099 RVA: 0x000650B8 File Offset: 0x000632B8
		[Token(Token = "0x60111D3")]
		[Address(RVA = "0x1FA0170", Offset = "0x1FA0170", VA = "0x1FA0170")]
		public static EnterWeeklyLeaderboardResponse GetRootAsEnterWeeklyLeaderboardResponse(ByteBuffer _bb)
		{
			return default(EnterWeeklyLeaderboardResponse);
		}

		// Token: 0x060111D4 RID: 70100 RVA: 0x000650D0 File Offset: 0x000632D0
		[Token(Token = "0x60111D4")]
		[Address(RVA = "0x1FA017C", Offset = "0x1FA017C", VA = "0x1FA017C")]
		public static EnterWeeklyLeaderboardResponse GetRootAsEnterWeeklyLeaderboardResponse(ByteBuffer _bb, EnterWeeklyLeaderboardResponse obj)
		{
			return default(EnterWeeklyLeaderboardResponse);
		}

		// Token: 0x060111D5 RID: 70101 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111D5")]
		[Address(RVA = "0x1FA022C", Offset = "0x1FA022C", VA = "0x1FA022C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060111D6 RID: 70102 RVA: 0x000650E8 File Offset: 0x000632E8
		[Token(Token = "0x60111D6")]
		[Address(RVA = "0x1FA01F4", Offset = "0x1FA01F4", VA = "0x1FA01F4")]
		public EnterWeeklyLeaderboardResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterWeeklyLeaderboardResponse);
		}

		// Token: 0x1700207D RID: 8317
		// (get) Token: 0x060111D7 RID: 70103 RVA: 0x00065100 File Offset: 0x00063300
		[Token(Token = "0x1700207D")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x60111D7")]
			[Address(RVA = "0x1FA023C", Offset = "0x1FA023C", VA = "0x1FA023C")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x1700207E RID: 8318
		// (get) Token: 0x060111D8 RID: 70104 RVA: 0x00065118 File Offset: 0x00063318
		[Token(Token = "0x1700207E")]
		public EnterEventFailReason FailReason
		{
			[Token(Token = "0x60111D8")]
			[Address(RVA = "0x1FA0280", Offset = "0x1FA0280", VA = "0x1FA0280")]
			get
			{
				return EnterEventFailReason.None;
			}
		}

		// Token: 0x060111D9 RID: 70105 RVA: 0x00065130 File Offset: 0x00063330
		[Token(Token = "0x60111D9")]
		[Address(RVA = "0x1FA02C4", Offset = "0x1FA02C4", VA = "0x1FA02C4")]
		public WeeklyLeaderboardUser? Users(int j)
		{
			return null;
		}

		// Token: 0x1700207F RID: 8319
		// (get) Token: 0x060111DA RID: 70106 RVA: 0x00065148 File Offset: 0x00063348
		[Token(Token = "0x1700207F")]
		public int UsersLength
		{
			[Token(Token = "0x60111DA")]
			[Address(RVA = "0x1FA039C", Offset = "0x1FA039C", VA = "0x1FA039C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002080 RID: 8320
		// (get) Token: 0x060111DB RID: 70107 RVA: 0x00065160 File Offset: 0x00063360
		[Token(Token = "0x17002080")]
		public int ServerEventId
		{
			[Token(Token = "0x60111DB")]
			[Address(RVA = "0x1FA03D0", Offset = "0x1FA03D0", VA = "0x1FA03D0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002081 RID: 8321
		// (get) Token: 0x060111DC RID: 70108 RVA: 0x00065178 File Offset: 0x00063378
		[Token(Token = "0x17002081")]
		public int Segment
		{
			[Token(Token = "0x60111DC")]
			[Address(RVA = "0x1FA0414", Offset = "0x1FA0414", VA = "0x1FA0414")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060111DD RID: 70109 RVA: 0x00065190 File Offset: 0x00063390
		[Token(Token = "0x60111DD")]
		[Address(RVA = "0x1FA0458", Offset = "0x1FA0458", VA = "0x1FA0458")]
		public static Offset<EnterWeeklyLeaderboardResponse> CreateEnterWeeklyLeaderboardResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, EnterEventFailReason fail_reason = EnterEventFailReason.None, [Optional] VectorOffset usersOffset, int server_event_id = 0, int segment = 0)
		{
			return default(Offset<EnterWeeklyLeaderboardResponse>);
		}

		// Token: 0x060111DE RID: 70110 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111DE")]
		[Address(RVA = "0x1FA05FC", Offset = "0x1FA05FC", VA = "0x1FA05FC")]
		public static void StartEnterWeeklyLeaderboardResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060111DF RID: 70111 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111DF")]
		[Address(RVA = "0x1FA0570", Offset = "0x1FA0570", VA = "0x1FA0570")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x060111E0 RID: 70112 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111E0")]
		[Address(RVA = "0x1FA0550", Offset = "0x1FA0550", VA = "0x1FA0550")]
		public static void AddFailReason(FlatBufferBuilder builder, EnterEventFailReason failReason)
		{
		}

		// Token: 0x060111E1 RID: 70113 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111E1")]
		[Address(RVA = "0x1FA0530", Offset = "0x1FA0530", VA = "0x1FA0530")]
		public static void AddUsers(FlatBufferBuilder builder, VectorOffset usersOffset)
		{
		}

		// Token: 0x060111E2 RID: 70114 RVA: 0x000651A8 File Offset: 0x000633A8
		[Token(Token = "0x60111E2")]
		[Address(RVA = "0x1FA0614", Offset = "0x1FA0614", VA = "0x1FA0614")]
		public static VectorOffset CreateUsersVector(FlatBufferBuilder builder, Offset<WeeklyLeaderboardUser>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060111E3 RID: 70115 RVA: 0x000651C0 File Offset: 0x000633C0
		[Token(Token = "0x60111E3")]
		[Address(RVA = "0x1FA06BC", Offset = "0x1FA06BC", VA = "0x1FA06BC")]
		public static VectorOffset CreateUsersVectorBlock(FlatBufferBuilder builder, Offset<WeeklyLeaderboardUser>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060111E4 RID: 70116 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111E4")]
		[Address(RVA = "0x1FA0744", Offset = "0x1FA0744", VA = "0x1FA0744")]
		public static void StartUsersVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x060111E5 RID: 70117 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111E5")]
		[Address(RVA = "0x1FA0510", Offset = "0x1FA0510", VA = "0x1FA0510")]
		public static void AddServerEventId(FlatBufferBuilder builder, int serverEventId)
		{
		}

		// Token: 0x060111E6 RID: 70118 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111E6")]
		[Address(RVA = "0x1FA04F0", Offset = "0x1FA04F0", VA = "0x1FA04F0")]
		public static void AddSegment(FlatBufferBuilder builder, int segment)
		{
		}

		// Token: 0x060111E7 RID: 70119 RVA: 0x000651D8 File Offset: 0x000633D8
		[Token(Token = "0x60111E7")]
		[Address(RVA = "0x1FA0590", Offset = "0x1FA0590", VA = "0x1FA0590")]
		public static Offset<EnterWeeklyLeaderboardResponse> EndEnterWeeklyLeaderboardResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterWeeklyLeaderboardResponse>);
		}

		// Token: 0x0400E6E2 RID: 59106
		[Token(Token = "0x400E6E2")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
