﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.DailyLightningRush
{
	// Token: 0x02002573 RID: 9587
	[Token(Token = "0x2002573")]
	public class GetDailyLightningRushInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027B0 RID: 10160
		// (get) Token: 0x06012BA3 RID: 76707 RVA: 0x00079320 File Offset: 0x00077520
		[Token(Token = "0x170027B0")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012BA3")]
			[Address(RVA = "0x1ED42C4", Offset = "0x1ED42C4", VA = "0x1ED42C4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027B1 RID: 10161
		// (get) Token: 0x06012BA4 RID: 76708 RVA: 0x00079338 File Offset: 0x00077538
		[Token(Token = "0x170027B1")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012BA4")]
			[Address(RVA = "0x1ED42CC", Offset = "0x1ED42CC", VA = "0x1ED42CC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012BA5 RID: 76709 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BA5")]
		[Address(RVA = "0x1ED42D4", Offset = "0x1ED42D4", VA = "0x1ED42D4")]
		public GetDailyLightningRushInfoHttpCommand(long groupId, int configVersion, LeaderboardInfoType infoType, int eventId, bool afterLevelWin = false)
		{
		}

		// Token: 0x06012BA6 RID: 76710 RVA: 0x00079350 File Offset: 0x00077550
		[Token(Token = "0x6012BA6")]
		[Address(RVA = "0x1ED43D0", Offset = "0x1ED43D0", VA = "0x1ED43D0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BA7 RID: 76711 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BA7")]
		[Address(RVA = "0x1ED44A8", Offset = "0x1ED44A8", VA = "0x1ED44A8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BA8 RID: 76712 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BA8")]
		[Address(RVA = "0x1ED47FC", Offset = "0x1ED47FC", VA = "0x1ED47FC", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBF9 RID: 60409
		[Token(Token = "0x400EBF9")]
		[FieldOffset(Offset = "0x18")]
		private readonly long groupId;

		// Token: 0x0400EBFA RID: 60410
		[Token(Token = "0x400EBFA")]
		[FieldOffset(Offset = "0x20")]
		private readonly int configVersion;

		// Token: 0x0400EBFB RID: 60411
		[Token(Token = "0x400EBFB")]
		[FieldOffset(Offset = "0x24")]
		private readonly LeaderboardInfoType infoType;

		// Token: 0x0400EBFC RID: 60412
		[Token(Token = "0x400EBFC")]
		[FieldOffset(Offset = "0x28")]
		private readonly int eventId;

		// Token: 0x0400EBFD RID: 60413
		[Token(Token = "0x400EBFD")]
		[FieldOffset(Offset = "0x2C")]
		private readonly bool afterLevelWin;
	}
}
