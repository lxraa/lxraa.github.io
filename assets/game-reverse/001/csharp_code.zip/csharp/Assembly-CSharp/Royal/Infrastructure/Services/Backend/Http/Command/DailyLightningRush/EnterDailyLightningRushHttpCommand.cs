﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.DailyLightningRush
{
	// Token: 0x02002572 RID: 9586
	[Token(Token = "0x2002572")]
	public class EnterDailyLightningRushHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027AE RID: 10158
		// (get) Token: 0x06012B9D RID: 76701 RVA: 0x000792D8 File Offset: 0x000774D8
		[Token(Token = "0x170027AE")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B9D")]
			[Address(RVA = "0x1ED3F3C", Offset = "0x1ED3F3C", VA = "0x1ED3F3C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027AF RID: 10159
		// (get) Token: 0x06012B9E RID: 76702 RVA: 0x000792F0 File Offset: 0x000774F0
		[Token(Token = "0x170027AF")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B9E")]
			[Address(RVA = "0x1ED3F44", Offset = "0x1ED3F44", VA = "0x1ED3F44", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B9F RID: 76703 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B9F")]
		[Address(RVA = "0x1ED3F4C", Offset = "0x1ED3F4C", VA = "0x1ED3F4C")]
		public EnterDailyLightningRushHttpCommand(int step, int configVersion, EventInteractionOrigin origin, bool shouldOpenPrelevel)
		{
		}

		// Token: 0x06012BA0 RID: 76704 RVA: 0x00079308 File Offset: 0x00077508
		[Token(Token = "0x6012BA0")]
		[Address(RVA = "0x1ED3F90", Offset = "0x1ED3F90", VA = "0x1ED3F90", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BA1 RID: 76705 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BA1")]
		[Address(RVA = "0x1ED4004", Offset = "0x1ED4004", VA = "0x1ED4004", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BA2 RID: 76706 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BA2")]
		[Address(RVA = "0x1ED42C0", Offset = "0x1ED42C0", VA = "0x1ED42C0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBF5 RID: 60405
		[Token(Token = "0x400EBF5")]
		[FieldOffset(Offset = "0x14")]
		private readonly int step;

		// Token: 0x0400EBF6 RID: 60406
		[Token(Token = "0x400EBF6")]
		[FieldOffset(Offset = "0x18")]
		private readonly int configVersion;

		// Token: 0x0400EBF7 RID: 60407
		[Token(Token = "0x400EBF7")]
		[FieldOffset(Offset = "0x1C")]
		private readonly EventInteractionOrigin origin;

		// Token: 0x0400EBF8 RID: 60408
		[Token(Token = "0x400EBF8")]
		[FieldOffset(Offset = "0x20")]
		private readonly bool shouldOpenPrelevel;
	}
}
