﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002349 RID: 9033
	[Token(Token = "0x2002349")]
	public struct BalloonRiseInfo : IFlatbufferObject
	{
		// Token: 0x17001EED RID: 7917
		// (get) Token: 0x06010C19 RID: 68633 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EED")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C19")]
			[Address(RVA = "0x21452D0", Offset = "0x21452D0", VA = "0x21452D0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C1A RID: 68634 RVA: 0x00060618 File Offset: 0x0005E818
		[Token(Token = "0x6010C1A")]
		[Address(RVA = "0x21452D8", Offset = "0x21452D8", VA = "0x21452D8")]
		public static BalloonRiseInfo GetRootAsBalloonRiseInfo(ByteBuffer _bb)
		{
			return default(BalloonRiseInfo);
		}

		// Token: 0x06010C1B RID: 68635 RVA: 0x00060630 File Offset: 0x0005E830
		[Token(Token = "0x6010C1B")]
		[Address(RVA = "0x21452E4", Offset = "0x21452E4", VA = "0x21452E4")]
		public static BalloonRiseInfo GetRootAsBalloonRiseInfo(ByteBuffer _bb, BalloonRiseInfo obj)
		{
			return default(BalloonRiseInfo);
		}

		// Token: 0x06010C1C RID: 68636 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C1C")]
		[Address(RVA = "0x2145394", Offset = "0x2145394", VA = "0x2145394", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C1D RID: 68637 RVA: 0x00060648 File Offset: 0x0005E848
		[Token(Token = "0x6010C1D")]
		[Address(RVA = "0x214535C", Offset = "0x214535C", VA = "0x214535C")]
		public BalloonRiseInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(BalloonRiseInfo);
		}

		// Token: 0x17001EEE RID: 7918
		// (get) Token: 0x06010C1E RID: 68638 RVA: 0x00060660 File Offset: 0x0005E860
		[Token(Token = "0x17001EEE")]
		public int ServerEventId
		{
			[Token(Token = "0x6010C1E")]
			[Address(RVA = "0x21453A4", Offset = "0x21453A4", VA = "0x21453A4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EEF RID: 7919
		// (get) Token: 0x06010C1F RID: 68639 RVA: 0x00060678 File Offset: 0x0005E878
		[Token(Token = "0x17001EEF")]
		public long RemainingTime
		{
			[Token(Token = "0x6010C1F")]
			[Address(RVA = "0x21453E8", Offset = "0x21453E8", VA = "0x21453E8")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001EF0 RID: 7920
		// (get) Token: 0x06010C20 RID: 68640 RVA: 0x00060690 File Offset: 0x0005E890
		[Token(Token = "0x17001EF0")]
		public int ConfigVersion
		{
			[Token(Token = "0x6010C20")]
			[Address(RVA = "0x2145430", Offset = "0x2145430", VA = "0x2145430")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EF1 RID: 7921
		// (get) Token: 0x06010C21 RID: 68641 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EF1")]
		public string Config
		{
			[Token(Token = "0x6010C21")]
			[Address(RVA = "0x2145474", Offset = "0x2145474", VA = "0x2145474")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C22 RID: 68642 RVA: 0x000606A8 File Offset: 0x0005E8A8
		[Token(Token = "0x6010C22")]
		[Address(RVA = "0x21454B0", Offset = "0x21454B0", VA = "0x21454B0")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06010C23 RID: 68643 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010C23")]
		[Address(RVA = "0x21454E8", Offset = "0x21454E8", VA = "0x21454E8")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x17001EF2 RID: 7922
		// (get) Token: 0x06010C24 RID: 68644 RVA: 0x000606C0 File Offset: 0x0005E8C0
		[Token(Token = "0x17001EF2")]
		public sbyte Priority
		{
			[Token(Token = "0x6010C24")]
			[Address(RVA = "0x2145534", Offset = "0x2145534", VA = "0x2145534")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010C25 RID: 68645 RVA: 0x000606D8 File Offset: 0x0005E8D8
		[Token(Token = "0x6010C25")]
		[Address(RVA = "0x2145578", Offset = "0x2145578", VA = "0x2145578")]
		public static Offset<BalloonRiseInfo> CreateBalloonRiseInfo(FlatBufferBuilder builder, int server_event_id = 0, long remaining_time = 0L, int config_version = 0, [Optional] StringOffset configOffset, sbyte priority = 0)
		{
			return default(Offset<BalloonRiseInfo>);
		}

		// Token: 0x06010C26 RID: 68646 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C26")]
		[Address(RVA = "0x214571C", Offset = "0x214571C", VA = "0x214571C")]
		public static void StartBalloonRiseInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C27 RID: 68647 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C27")]
		[Address(RVA = "0x2145670", Offset = "0x2145670", VA = "0x2145670")]
		public static void AddServerEventId(FlatBufferBuilder builder, int serverEventId)
		{
		}

		// Token: 0x06010C28 RID: 68648 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C28")]
		[Address(RVA = "0x2145610", Offset = "0x2145610", VA = "0x2145610")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010C29 RID: 68649 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C29")]
		[Address(RVA = "0x2145650", Offset = "0x2145650", VA = "0x2145650")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06010C2A RID: 68650 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C2A")]
		[Address(RVA = "0x2145630", Offset = "0x2145630", VA = "0x2145630")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06010C2B RID: 68651 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C2B")]
		[Address(RVA = "0x2145690", Offset = "0x2145690", VA = "0x2145690")]
		public static void AddPriority(FlatBufferBuilder builder, sbyte priority)
		{
		}

		// Token: 0x06010C2C RID: 68652 RVA: 0x000606F0 File Offset: 0x0005E8F0
		[Token(Token = "0x6010C2C")]
		[Address(RVA = "0x21456B0", Offset = "0x21456B0", VA = "0x21456B0")]
		public static Offset<BalloonRiseInfo> EndBalloonRiseInfo(FlatBufferBuilder builder)
		{
			return default(Offset<BalloonRiseInfo>);
		}

		// Token: 0x06010C2D RID: 68653 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C2D")]
		[Address(RVA = "0x2145734", Offset = "0x2145734", VA = "0x2145734")]
		public static void FinishBalloonRiseInfoBuffer(FlatBufferBuilder builder, Offset<BalloonRiseInfo> offset)
		{
		}

		// Token: 0x06010C2E RID: 68654 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C2E")]
		[Address(RVA = "0x2145748", Offset = "0x2145748", VA = "0x2145748")]
		public static void FinishSizePrefixedBalloonRiseInfoBuffer(FlatBufferBuilder builder, Offset<BalloonRiseInfo> offset)
		{
		}

		// Token: 0x0400E62D RID: 58925
		[Token(Token = "0x400E62D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
