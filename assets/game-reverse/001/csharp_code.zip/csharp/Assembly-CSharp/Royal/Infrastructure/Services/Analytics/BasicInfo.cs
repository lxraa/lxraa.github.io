﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002593 RID: 9619
	[Token(Token = "0x2002593")]
	public class BasicInfo
	{
		// Token: 0x06012D4B RID: 77131 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D4B")]
		[Address(RVA = "0x243A9E4", Offset = "0x243A9E4", VA = "0x243A9E4")]
		public BasicInfo()
		{
		}

		// Token: 0x0400ECC7 RID: 60615
		[Token(Token = "0x400ECC7")]
		[FieldOffset(Offset = "0x10")]
		public long event_time;

		// Token: 0x0400ECC8 RID: 60616
		[Token(Token = "0x400ECC8")]
		[FieldOffset(Offset = "0x18")]
		public long user_id;

		// Token: 0x0400ECC9 RID: 60617
		[Token(Token = "0x400ECC9")]
		[FieldOffset(Offset = "0x20")]
		public int is_payer;
	}
}
