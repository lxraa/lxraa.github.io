﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SpaceMission
{
	// Token: 0x0200253E RID: 9534
	[Token(Token = "0x200253E")]
	public class ClaimSpaceMissionHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002733 RID: 10035
		// (get) Token: 0x06012A30 RID: 76336 RVA: 0x000781F8 File Offset: 0x000763F8
		[Token(Token = "0x17002733")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A30")]
			[Address(RVA = "0x1CFEB14", Offset = "0x1CFEB14", VA = "0x1CFEB14", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002734 RID: 10036
		// (get) Token: 0x06012A31 RID: 76337 RVA: 0x00078210 File Offset: 0x00076410
		[Token(Token = "0x17002734")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A31")]
			[Address(RVA = "0x1CFEB1C", Offset = "0x1CFEB1C", VA = "0x1CFEB1C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A32 RID: 76338 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A32")]
		[Address(RVA = "0x1CFEB24", Offset = "0x1CFEB24", VA = "0x1CFEB24")]
		public ClaimSpaceMissionHttpCommand(long group, bool winner, EventInteractionOrigin interactionOrigin)
		{
		}

		// Token: 0x06012A33 RID: 76339 RVA: 0x00078228 File Offset: 0x00076428
		[Token(Token = "0x6012A33")]
		[Address(RVA = "0x1CFEB64", Offset = "0x1CFEB64", VA = "0x1CFEB64", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A34 RID: 76340 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A34")]
		[Address(RVA = "0x1CFEC80", Offset = "0x1CFEC80", VA = "0x1CFEC80", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A35 RID: 76341 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A35")]
		[Address(RVA = "0x1CFED04", Offset = "0x1CFED04", VA = "0x1CFED04", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB59 RID: 60249
		[Token(Token = "0x400EB59")]
		[FieldOffset(Offset = "0x18")]
		private readonly long groupId;

		// Token: 0x0400EB5A RID: 60250
		[Token(Token = "0x400EB5A")]
		[FieldOffset(Offset = "0x20")]
		private readonly bool isWinner;

		// Token: 0x0400EB5B RID: 60251
		[Token(Token = "0x400EB5B")]
		[FieldOffset(Offset = "0x24")]
		private readonly EventInteractionOrigin eventInteractionOrigin;
	}
}
