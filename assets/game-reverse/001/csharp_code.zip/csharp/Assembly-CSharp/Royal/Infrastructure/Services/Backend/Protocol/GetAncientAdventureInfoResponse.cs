﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C2 RID: 9154
	[Token(Token = "0x20023C2")]
	public struct GetAncientAdventureInfoResponse : IFlatbufferObject
	{
		// Token: 0x170020BE RID: 8382
		// (get) Token: 0x060112C2 RID: 70338 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020BE")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60112C2")]
			[Address(RVA = "0x1CABD24", Offset = "0x1CABD24", VA = "0x1CABD24", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112C3 RID: 70339 RVA: 0x00065CE8 File Offset: 0x00063EE8
		[Token(Token = "0x60112C3")]
		[Address(RVA = "0x1CABD2C", Offset = "0x1CABD2C", VA = "0x1CABD2C")]
		public static GetAncientAdventureInfoResponse GetRootAsGetAncientAdventureInfoResponse(ByteBuffer _bb)
		{
			return default(GetAncientAdventureInfoResponse);
		}

		// Token: 0x060112C4 RID: 70340 RVA: 0x00065D00 File Offset: 0x00063F00
		[Token(Token = "0x60112C4")]
		[Address(RVA = "0x1CABD38", Offset = "0x1CABD38", VA = "0x1CABD38")]
		public static GetAncientAdventureInfoResponse GetRootAsGetAncientAdventureInfoResponse(ByteBuffer _bb, GetAncientAdventureInfoResponse obj)
		{
			return default(GetAncientAdventureInfoResponse);
		}

		// Token: 0x060112C5 RID: 70341 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112C5")]
		[Address(RVA = "0x1CABDE8", Offset = "0x1CABDE8", VA = "0x1CABDE8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060112C6 RID: 70342 RVA: 0x00065D18 File Offset: 0x00063F18
		[Token(Token = "0x60112C6")]
		[Address(RVA = "0x1CABDB0", Offset = "0x1CABDB0", VA = "0x1CABDB0")]
		public GetAncientAdventureInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetAncientAdventureInfoResponse);
		}

		// Token: 0x170020BF RID: 8383
		// (get) Token: 0x060112C7 RID: 70343 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020BF")]
		public string AncientAdventureUserConfig
		{
			[Token(Token = "0x60112C7")]
			[Address(RVA = "0x1CABDF8", Offset = "0x1CABDF8", VA = "0x1CABDF8")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112C8 RID: 70344 RVA: 0x00065D30 File Offset: 0x00063F30
		[Token(Token = "0x60112C8")]
		[Address(RVA = "0x1CABE34", Offset = "0x1CABE34", VA = "0x1CABE34")]
		public ArraySegment<byte>? GetAncientAdventureUserConfigBytes()
		{
			return null;
		}

		// Token: 0x060112C9 RID: 70345 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60112C9")]
		[Address(RVA = "0x1CABE6C", Offset = "0x1CABE6C", VA = "0x1CABE6C")]
		public byte[] GetAncientAdventureUserConfigArray()
		{
			return null;
		}

		// Token: 0x060112CA RID: 70346 RVA: 0x00065D48 File Offset: 0x00063F48
		[Token(Token = "0x60112CA")]
		[Address(RVA = "0x1CABEB8", Offset = "0x1CABEB8", VA = "0x1CABEB8")]
		public static Offset<GetAncientAdventureInfoResponse> CreateGetAncientAdventureInfoResponse(FlatBufferBuilder builder, [Optional] StringOffset ancient_adventure_user_configOffset)
		{
			return default(Offset<GetAncientAdventureInfoResponse>);
		}

		// Token: 0x060112CB RID: 70347 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112CB")]
		[Address(RVA = "0x1CABF8C", Offset = "0x1CABF8C", VA = "0x1CABF8C")]
		public static void StartGetAncientAdventureInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060112CC RID: 70348 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112CC")]
		[Address(RVA = "0x1CABF00", Offset = "0x1CABF00", VA = "0x1CABF00")]
		public static void AddAncientAdventureUserConfig(FlatBufferBuilder builder, StringOffset ancientAdventureUserConfigOffset)
		{
		}

		// Token: 0x060112CD RID: 70349 RVA: 0x00065D60 File Offset: 0x00063F60
		[Token(Token = "0x60112CD")]
		[Address(RVA = "0x1CABF20", Offset = "0x1CABF20", VA = "0x1CABF20")]
		public static Offset<GetAncientAdventureInfoResponse> EndGetAncientAdventureInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetAncientAdventureInfoResponse>);
		}

		// Token: 0x0400E72F RID: 59183
		[Token(Token = "0x400E72F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
