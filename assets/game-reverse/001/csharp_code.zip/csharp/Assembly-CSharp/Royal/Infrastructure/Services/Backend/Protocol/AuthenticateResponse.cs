﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002346 RID: 9030
	[Token(Token = "0x2002346")]
	public struct AuthenticateResponse : IFlatbufferObject
	{
		// Token: 0x17001EE5 RID: 7909
		// (get) Token: 0x06010BEF RID: 68591 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EE5")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010BEF")]
			[Address(RVA = "0x2144858", Offset = "0x2144858", VA = "0x2144858", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BF0 RID: 68592 RVA: 0x000603F0 File Offset: 0x0005E5F0
		[Token(Token = "0x6010BF0")]
		[Address(RVA = "0x2144860", Offset = "0x2144860", VA = "0x2144860")]
		public static AuthenticateResponse GetRootAsAuthenticateResponse(ByteBuffer _bb)
		{
			return default(AuthenticateResponse);
		}

		// Token: 0x06010BF1 RID: 68593 RVA: 0x00060408 File Offset: 0x0005E608
		[Token(Token = "0x6010BF1")]
		[Address(RVA = "0x214486C", Offset = "0x214486C", VA = "0x214486C")]
		public static AuthenticateResponse GetRootAsAuthenticateResponse(ByteBuffer _bb, AuthenticateResponse obj)
		{
			return default(AuthenticateResponse);
		}

		// Token: 0x06010BF2 RID: 68594 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BF2")]
		[Address(RVA = "0x214491C", Offset = "0x214491C", VA = "0x214491C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010BF3 RID: 68595 RVA: 0x00060420 File Offset: 0x0005E620
		[Token(Token = "0x6010BF3")]
		[Address(RVA = "0x21448E4", Offset = "0x21448E4", VA = "0x21448E4")]
		public AuthenticateResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(AuthenticateResponse);
		}

		// Token: 0x17001EE6 RID: 7910
		// (get) Token: 0x06010BF4 RID: 68596 RVA: 0x00060438 File Offset: 0x0005E638
		[Token(Token = "0x17001EE6")]
		public TeamChatData? TeamChatData
		{
			[Token(Token = "0x6010BF4")]
			[Address(RVA = "0x214492C", Offset = "0x214492C", VA = "0x214492C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BF5 RID: 68597 RVA: 0x00060450 File Offset: 0x0005E650
		[Token(Token = "0x6010BF5")]
		[Address(RVA = "0x21449EC", Offset = "0x21449EC", VA = "0x21449EC")]
		public static Offset<AuthenticateResponse> CreateAuthenticateResponse(FlatBufferBuilder builder, [Optional] Offset<TeamChatData> team_chat_dataOffset)
		{
			return default(Offset<AuthenticateResponse>);
		}

		// Token: 0x06010BF6 RID: 68598 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BF6")]
		[Address(RVA = "0x2144AC0", Offset = "0x2144AC0", VA = "0x2144AC0")]
		public static void StartAuthenticateResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010BF7 RID: 68599 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BF7")]
		[Address(RVA = "0x2144A34", Offset = "0x2144A34", VA = "0x2144A34")]
		public static void AddTeamChatData(FlatBufferBuilder builder, Offset<TeamChatData> teamChatDataOffset)
		{
		}

		// Token: 0x06010BF8 RID: 68600 RVA: 0x00060468 File Offset: 0x0005E668
		[Token(Token = "0x6010BF8")]
		[Address(RVA = "0x2144A54", Offset = "0x2144A54", VA = "0x2144A54")]
		public static Offset<AuthenticateResponse> EndAuthenticateResponse(FlatBufferBuilder builder)
		{
			return default(Offset<AuthenticateResponse>);
		}

		// Token: 0x0400E62A RID: 58922
		[Token(Token = "0x400E62A")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
