﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C5 RID: 9157
	[Token(Token = "0x20023C5")]
	public struct GetBalloonRiseInfoRequest : IFlatbufferObject
	{
		// Token: 0x170020CA RID: 8394
		// (get) Token: 0x060112EE RID: 70382 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020CA")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60112EE")]
			[Address(RVA = "0x1CAC770", Offset = "0x1CAC770", VA = "0x1CAC770", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112EF RID: 70383 RVA: 0x00065F28 File Offset: 0x00064128
		[Token(Token = "0x60112EF")]
		[Address(RVA = "0x1CAC778", Offset = "0x1CAC778", VA = "0x1CAC778")]
		public static GetBalloonRiseInfoRequest GetRootAsGetBalloonRiseInfoRequest(ByteBuffer _bb)
		{
			return default(GetBalloonRiseInfoRequest);
		}

		// Token: 0x060112F0 RID: 70384 RVA: 0x00065F40 File Offset: 0x00064140
		[Token(Token = "0x60112F0")]
		[Address(RVA = "0x1CAC784", Offset = "0x1CAC784", VA = "0x1CAC784")]
		public static GetBalloonRiseInfoRequest GetRootAsGetBalloonRiseInfoRequest(ByteBuffer _bb, GetBalloonRiseInfoRequest obj)
		{
			return default(GetBalloonRiseInfoRequest);
		}

		// Token: 0x060112F1 RID: 70385 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112F1")]
		[Address(RVA = "0x1CAC834", Offset = "0x1CAC834", VA = "0x1CAC834", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060112F2 RID: 70386 RVA: 0x00065F58 File Offset: 0x00064158
		[Token(Token = "0x60112F2")]
		[Address(RVA = "0x1CAC7FC", Offset = "0x1CAC7FC", VA = "0x1CAC7FC")]
		public GetBalloonRiseInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetBalloonRiseInfoRequest);
		}

		// Token: 0x170020CB RID: 8395
		// (get) Token: 0x060112F3 RID: 70387 RVA: 0x00065F70 File Offset: 0x00064170
		[Token(Token = "0x170020CB")]
		public int EventId
		{
			[Token(Token = "0x60112F3")]
			[Address(RVA = "0x1CAC844", Offset = "0x1CAC844", VA = "0x1CAC844")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060112F4 RID: 70388 RVA: 0x00065F88 File Offset: 0x00064188
		[Token(Token = "0x60112F4")]
		[Address(RVA = "0x1CAC888", Offset = "0x1CAC888", VA = "0x1CAC888")]
		public static Offset<GetBalloonRiseInfoRequest> CreateGetBalloonRiseInfoRequest(FlatBufferBuilder builder, int event_id = 0)
		{
			return default(Offset<GetBalloonRiseInfoRequest>);
		}

		// Token: 0x060112F5 RID: 70389 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112F5")]
		[Address(RVA = "0x1CAC95C", Offset = "0x1CAC95C", VA = "0x1CAC95C")]
		public static void StartGetBalloonRiseInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060112F6 RID: 70390 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112F6")]
		[Address(RVA = "0x1CAC8D0", Offset = "0x1CAC8D0", VA = "0x1CAC8D0")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x060112F7 RID: 70391 RVA: 0x00065FA0 File Offset: 0x000641A0
		[Token(Token = "0x60112F7")]
		[Address(RVA = "0x1CAC8F0", Offset = "0x1CAC8F0", VA = "0x1CAC8F0")]
		public static Offset<GetBalloonRiseInfoRequest> EndGetBalloonRiseInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetBalloonRiseInfoRequest>);
		}

		// Token: 0x0400E732 RID: 59186
		[Token(Token = "0x400E732")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
