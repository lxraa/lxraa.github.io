﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.Contexts;
using Royal.Infrastructure.Contexts.Units.App;
using Royal.Infrastructure.Services.Login;
using Royal.Infrastructure.Services.Native;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http
{
	// Token: 0x0200250D RID: 9485
	[Token(Token = "0x200250D")]
	public class TimeHelper : IContextUnit
	{
		// Token: 0x170026BF RID: 9919
		// (get) Token: 0x06012866 RID: 75878 RVA: 0x000771A8 File Offset: 0x000753A8
		// (set) Token: 0x06012867 RID: 75879 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026BF")]
		public bool IsTimeValidatedByBackend
		{
			[Token(Token = "0x6012866")]
			[Address(RVA = "0x1CE6E40", Offset = "0x1CE6E40", VA = "0x1CE6E40")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012867")]
			[Address(RVA = "0x1CE6E48", Offset = "0x1CE6E48", VA = "0x1CE6E48")]
			private set
			{
			}
		}

		// Token: 0x170026C0 RID: 9920
		// (get) Token: 0x06012868 RID: 75880 RVA: 0x000771C0 File Offset: 0x000753C0
		// (set) Token: 0x06012869 RID: 75881 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026C0")]
		public bool IsOfflineClientTimeTakenBack
		{
			[Token(Token = "0x6012868")]
			[Address(RVA = "0x1CE6E54", Offset = "0x1CE6E54", VA = "0x1CE6E54")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012869")]
			[Address(RVA = "0x1CE6E5C", Offset = "0x1CE6E5C", VA = "0x1CE6E5C")]
			private set
			{
			}
		}

		// Token: 0x170026C1 RID: 9921
		// (get) Token: 0x0601286A RID: 75882 RVA: 0x000771D8 File Offset: 0x000753D8
		// (set) Token: 0x0601286B RID: 75883 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026C1")]
		public bool IsLifeHackDetected
		{
			[Token(Token = "0x601286A")]
			[Address(RVA = "0x1CE6E68", Offset = "0x1CE6E68", VA = "0x1CE6E68")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x601286B")]
			[Address(RVA = "0x1CE6E70", Offset = "0x1CE6E70", VA = "0x1CE6E70")]
			private set
			{
			}
		}

		// Token: 0x14000098 RID: 152
		// (add) Token: 0x0601286C RID: 75884 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x0601286D RID: 75885 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x14000098")]
		public event Action<HttpCommands> OnPingCommandBufferCreatedAppStart
		{
			[Token(Token = "0x601286C")]
			[Address(RVA = "0x1CE6E7C", Offset = "0x1CE6E7C", VA = "0x1CE6E7C")]
			add
			{
			}
			[Token(Token = "0x601286D")]
			[Address(RVA = "0x1CE6F2C", Offset = "0x1CE6F2C", VA = "0x1CE6F2C")]
			remove
			{
			}
		}

		// Token: 0x14000099 RID: 153
		// (add) Token: 0x0601286E RID: 75886 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x0601286F RID: 75887 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x14000099")]
		public event Action<HttpCommands> OnPingCommandBufferCreatedAppResume
		{
			[Token(Token = "0x601286E")]
			[Address(RVA = "0x1CE6FDC", Offset = "0x1CE6FDC", VA = "0x1CE6FDC")]
			add
			{
			}
			[Token(Token = "0x601286F")]
			[Address(RVA = "0x1CE708C", Offset = "0x1CE708C", VA = "0x1CE708C")]
			remove
			{
			}
		}

		// Token: 0x1400009A RID: 154
		// (add) Token: 0x06012870 RID: 75888 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012871 RID: 75889 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1400009A")]
		public event Action OnTimeValidatedByBackend
		{
			[Token(Token = "0x6012870")]
			[Address(RVA = "0x1CE713C", Offset = "0x1CE713C", VA = "0x1CE713C")]
			add
			{
			}
			[Token(Token = "0x6012871")]
			[Address(RVA = "0x1CE71D8", Offset = "0x1CE71D8", VA = "0x1CE71D8")]
			remove
			{
			}
		}

		// Token: 0x170026C2 RID: 9922
		// (get) Token: 0x06012872 RID: 75890 RVA: 0x000771F0 File Offset: 0x000753F0
		[Token(Token = "0x170026C2")]
		public int Id
		{
			[Token(Token = "0x6012872")]
			[Address(RVA = "0x1CE7274", Offset = "0x1CE7274", VA = "0x1CE7274", Slot = "4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06012873 RID: 75891 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012873")]
		[Address(RVA = "0x1CE727C", Offset = "0x1CE727C", VA = "0x1CE727C", Slot = "5")]
		public void Bind()
		{
		}

		// Token: 0x06012874 RID: 75892 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012874")]
		[Address(RVA = "0x1CE7670", Offset = "0x1CE7670", VA = "0x1CE7670")]
		private void OnAppStart()
		{
		}

		// Token: 0x06012875 RID: 75893 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012875")]
		[Address(RVA = "0x1CE7BE0", Offset = "0x1CE7BE0", VA = "0x1CE7BE0")]
		private void OnAppResume()
		{
		}

		// Token: 0x06012876 RID: 75894 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012876")]
		[Address(RVA = "0x1CE768C", Offset = "0x1CE768C", VA = "0x1CE768C")]
		private void CheckClientTime()
		{
		}

		// Token: 0x06012877 RID: 75895 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012877")]
		[Address(RVA = "0x1CE7BFC", Offset = "0x1CE7BFC", VA = "0x1CE7BFC")]
		private void OnAppPause()
		{
		}

		// Token: 0x06012878 RID: 75896 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012878")]
		[Address(RVA = "0x1CE81F4", Offset = "0x1CE81F4", VA = "0x1CE81F4")]
		public void ClearUserCaches()
		{
		}

		// Token: 0x06012879 RID: 75897 RVA: 0x00077208 File Offset: 0x00075408
		[Token(Token = "0x6012879")]
		[Address(RVA = "0x1CE81FC", Offset = "0x1CE81FC", VA = "0x1CE81FC")]
		public bool IsSendingPing()
		{
			return default(bool);
		}

		// Token: 0x0601287A RID: 75898 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601287A")]
		[Address(RVA = "0x1CE78AC", Offset = "0x1CE78AC", VA = "0x1CE78AC")]
		public void SendPing(TimeHelper.PingSendReason pingSendReason = TimeHelper.PingSendReason.Other)
		{
		}

		// Token: 0x0601287B RID: 75899 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601287B")]
		[Address(RVA = "0x1CE828C", Offset = "0x1CE828C", VA = "0x1CE828C")]
		private void PingResponseReached(bool isSuccess, HttpCommands container)
		{
		}

		// Token: 0x0601287C RID: 75900 RVA: 0x00077220 File Offset: 0x00075420
		[Token(Token = "0x601287C")]
		[Address(RVA = "0x1CE82E4", Offset = "0x1CE82E4", VA = "0x1CE82E4")]
		public bool UpdateTime(long serverTime)
		{
			return default(bool);
		}

		// Token: 0x0601287D RID: 75901 RVA: 0x00077238 File Offset: 0x00075438
		[Token(Token = "0x601287D")]
		[Address(RVA = "0x1CE8194", Offset = "0x1CE8194", VA = "0x1CE8194")]
		public long CurrentServerTimeInMs()
		{
			return 0L;
		}

		// Token: 0x0601287E RID: 75902 RVA: 0x00077250 File Offset: 0x00075450
		[Token(Token = "0x601287E")]
		[Address(RVA = "0x1CE8C78", Offset = "0x1CE8C78", VA = "0x1CE8C78")]
		public long GetServerClientTimeDiff()
		{
			return 0L;
		}

		// Token: 0x0601287F RID: 75903 RVA: 0x00077268 File Offset: 0x00075468
		[Token(Token = "0x601287F")]
		[Address(RVA = "0x1CE8C80", Offset = "0x1CE8C80", VA = "0x1CE8C80")]
		public long CurrentServerTimeInSeconds()
		{
			return 0L;
		}

		// Token: 0x06012880 RID: 75904 RVA: 0x00077280 File Offset: 0x00075480
		[Token(Token = "0x6012880")]
		[Address(RVA = "0x1CE8778", Offset = "0x1CE8778", VA = "0x1CE8778")]
		private bool IsThereLifeHack(long serverTime)
		{
			return default(bool);
		}

		// Token: 0x06012881 RID: 75905 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012881")]
		[Address(RVA = "0x1CE8DDC", Offset = "0x1CE8DDC", VA = "0x1CE8DDC")]
		private void LifeHackDetected()
		{
		}

		// Token: 0x06012882 RID: 75906 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012882")]
		[Address(RVA = "0x1CE8CAC", Offset = "0x1CE8CAC", VA = "0x1CE8CAC")]
		public void ResetLifeHackValues()
		{
		}

		// Token: 0x06012883 RID: 75907 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012883")]
		[Address(RVA = "0x1CE8F08", Offset = "0x1CE8F08", VA = "0x1CE8F08")]
		public void ShowLifeHackDialog()
		{
		}

		// Token: 0x06012884 RID: 75908 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012884")]
		[Address(RVA = "0x1CE8FEC", Offset = "0x1CE8FEC", VA = "0x1CE8FEC")]
		public void LifeHackControlEnabledByBackend(bool enabled)
		{
		}

		// Token: 0x06012885 RID: 75909 RVA: 0x00077298 File Offset: 0x00075498
		[Token(Token = "0x6012885")]
		[Address(RVA = "0x1CE9108", Offset = "0x1CE9108", VA = "0x1CE9108")]
		public bool IsLevelIncreased(int serverLevel, int serverLeagueLevel)
		{
			return default(bool);
		}

		// Token: 0x06012886 RID: 75910 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012886")]
		[Address(RVA = "0x1CE9254", Offset = "0x1CE9254", VA = "0x1CE9254")]
		public static string GetTimeZoneInNumberRepresentation()
		{
			return null;
		}

		// Token: 0x06012887 RID: 75911 RVA: 0x000772B0 File Offset: 0x000754B0
		[Token(Token = "0x6012887")]
		[Address(RVA = "0x1CE95EC", Offset = "0x1CE95EC", VA = "0x1CE95EC")]
		public DateTime GetServerTimeWithLocalTimeZone()
		{
			return default(DateTime);
		}

		// Token: 0x06012888 RID: 75912 RVA: 0x000772C8 File Offset: 0x000754C8
		[Token(Token = "0x6012888")]
		[Address(RVA = "0x1CE9820", Offset = "0x1CE9820", VA = "0x1CE9820")]
		public static bool HasServerTimeSetAtLeastOnce()
		{
			return default(bool);
		}

		// Token: 0x06012889 RID: 75913 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012889")]
		[Address(RVA = "0x1CE98F0", Offset = "0x1CE98F0", VA = "0x1CE98F0")]
		public void RecalculateAfterPause()
		{
		}

		// Token: 0x0601288A RID: 75914 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601288A")]
		[Address(RVA = "0x1CE98F4", Offset = "0x1CE98F4", VA = "0x1CE98F4")]
		public TimeHelper()
		{
		}

		// Token: 0x0400EA8E RID: 60046
		[Token(Token = "0x400EA8E")]
		private const int TimeBuffer = 60000;

		// Token: 0x0400EA8F RID: 60047
		[Token(Token = "0x400EA8F")]
		[FieldOffset(Offset = "0x10")]
		private bool <IsTimeValidatedByBackend>k__BackingField;

		// Token: 0x0400EA90 RID: 60048
		[Token(Token = "0x400EA90")]
		[FieldOffset(Offset = "0x11")]
		private bool <IsOfflineClientTimeTakenBack>k__BackingField;

		// Token: 0x0400EA91 RID: 60049
		[Token(Token = "0x400EA91")]
		[FieldOffset(Offset = "0x12")]
		private bool <IsLifeHackDetected>k__BackingField;

		// Token: 0x0400EA95 RID: 60053
		[Token(Token = "0x400EA95")]
		[FieldOffset(Offset = "0x30")]
		private BackendHttpService backendHttpService;

		// Token: 0x0400EA96 RID: 60054
		[Token(Token = "0x400EA96")]
		[FieldOffset(Offset = "0x38")]
		private LoginService loginService;

		// Token: 0x0400EA97 RID: 60055
		[Token(Token = "0x400EA97")]
		[FieldOffset(Offset = "0x40")]
		private NativeService nativeService;

		// Token: 0x0400EA98 RID: 60056
		[Token(Token = "0x400EA98")]
		[FieldOffset(Offset = "0x48")]
		private LifeHelper lifeHelper;

		// Token: 0x0400EA99 RID: 60057
		[Token(Token = "0x400EA99")]
		[FieldOffset(Offset = "0x50")]
		private SystemMessageManager smm;

		// Token: 0x0400EA9A RID: 60058
		[Token(Token = "0x400EA9A")]
		[FieldOffset(Offset = "0x58")]
		private long lastClientTime;

		// Token: 0x0400EA9B RID: 60059
		[Token(Token = "0x400EA9B")]
		[FieldOffset(Offset = "0x60")]
		private long serverClientTimeDiff;

		// Token: 0x0400EA9C RID: 60060
		[Token(Token = "0x400EA9C")]
		[FieldOffset(Offset = "0x68")]
		private int currentEarnedLifeCount;

		// Token: 0x0400EA9D RID: 60061
		[Token(Token = "0x400EA9D")]
		[FieldOffset(Offset = "0x70")]
		private long pingSendTime;

		// Token: 0x0400EA9E RID: 60062
		[Token(Token = "0x400EA9E")]
		[FieldOffset(Offset = "0x78")]
		private int lifeHackDetectedSyncId;

		// Token: 0x0400EA9F RID: 60063
		[Token(Token = "0x400EA9F")]
		[FieldOffset(Offset = "0x7C")]
		private int lifeHackDetectedLevel;

		// Token: 0x0400EAA0 RID: 60064
		[Token(Token = "0x400EAA0")]
		[FieldOffset(Offset = "0x80")]
		private FriendsManager friendsManager;

		// Token: 0x0400EAA1 RID: 60065
		[Token(Token = "0x400EAA1")]
		[FieldOffset(Offset = "0x88")]
		private AppManager appManager;

		// Token: 0x0400EAA2 RID: 60066
		[Token(Token = "0x400EAA2")]
		[FieldOffset(Offset = "0x0")]
		private static bool ShouldReadHasServerTimeSetAtLeastOnce;

		// Token: 0x0400EAA3 RID: 60067
		[Token(Token = "0x400EAA3")]
		[FieldOffset(Offset = "0x1")]
		private static bool HasServerTimeSetAtLeastOnceCache;

		// Token: 0x0200250E RID: 9486
		[Token(Token = "0x200250E")]
		public enum PingSendReason
		{
			// Token: 0x0400EAA5 RID: 60069
			[Token(Token = "0x400EAA5")]
			Other,
			// Token: 0x0400EAA6 RID: 60070
			[Token(Token = "0x400EAA6")]
			AppStart,
			// Token: 0x0400EAA7 RID: 60071
			[Token(Token = "0x400EAA7")]
			AppResume
		}

		// Token: 0x0200250F RID: 9487
		[Token(Token = "0x200250F")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x0601288D RID: 75917 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601288D")]
			[Address(RVA = "0x1CE99B8", Offset = "0x1CE99B8", VA = "0x1CE99B8")]
			public <>c()
			{
			}

			// Token: 0x0601288E RID: 75918 RVA: 0x000772E0 File Offset: 0x000754E0
			[Token(Token = "0x601288E")]
			[Address(RVA = "0x1CE99C0", Offset = "0x1CE99C0", VA = "0x1CE99C0")]
			internal DateTime <GetTimeZoneInNumberRepresentation>b__59_0(TimeZoneInfo.AdjustmentRule x)
			{
				return default(DateTime);
			}

			// Token: 0x0400EAA8 RID: 60072
			[Token(Token = "0x400EAA8")]
			[FieldOffset(Offset = "0x0")]
			public static readonly TimeHelper.<>c <>9;

			// Token: 0x0400EAA9 RID: 60073
			[Token(Token = "0x400EAA9")]
			[FieldOffset(Offset = "0x8")]
			public static Func<TimeZoneInfo.AdjustmentRule, DateTime> <>9__59_0;
		}
	}
}
