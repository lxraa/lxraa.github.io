﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002366 RID: 9062
	[Token(Token = "0x2002366")]
	public struct ClaimWeeklyLeaderboardRequest : IFlatbufferObject
	{
		// Token: 0x17001F52 RID: 8018
		// (get) Token: 0x06010D97 RID: 69015 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F52")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D97")]
			[Address(RVA = "0x214A9E8", Offset = "0x214A9E8", VA = "0x214A9E8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D98 RID: 69016 RVA: 0x00061968 File Offset: 0x0005FB68
		[Token(Token = "0x6010D98")]
		[Address(RVA = "0x214A9F0", Offset = "0x214A9F0", VA = "0x214A9F0")]
		public static ClaimWeeklyLeaderboardRequest GetRootAsClaimWeeklyLeaderboardRequest(ByteBuffer _bb)
		{
			return default(ClaimWeeklyLeaderboardRequest);
		}

		// Token: 0x06010D99 RID: 69017 RVA: 0x00061980 File Offset: 0x0005FB80
		[Token(Token = "0x6010D99")]
		[Address(RVA = "0x214A9FC", Offset = "0x214A9FC", VA = "0x214A9FC")]
		public static ClaimWeeklyLeaderboardRequest GetRootAsClaimWeeklyLeaderboardRequest(ByteBuffer _bb, ClaimWeeklyLeaderboardRequest obj)
		{
			return default(ClaimWeeklyLeaderboardRequest);
		}

		// Token: 0x06010D9A RID: 69018 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D9A")]
		[Address(RVA = "0x214AAAC", Offset = "0x214AAAC", VA = "0x214AAAC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D9B RID: 69019 RVA: 0x00061998 File Offset: 0x0005FB98
		[Token(Token = "0x6010D9B")]
		[Address(RVA = "0x214AA74", Offset = "0x214AA74", VA = "0x214AA74")]
		public ClaimWeeklyLeaderboardRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimWeeklyLeaderboardRequest);
		}

		// Token: 0x17001F53 RID: 8019
		// (get) Token: 0x06010D9C RID: 69020 RVA: 0x000619B0 File Offset: 0x0005FBB0
		[Token(Token = "0x17001F53")]
		public int UserEventId
		{
			[Token(Token = "0x6010D9C")]
			[Address(RVA = "0x214AABC", Offset = "0x214AABC", VA = "0x214AABC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010D9D RID: 69021 RVA: 0x000619C8 File Offset: 0x0005FBC8
		[Token(Token = "0x6010D9D")]
		[Address(RVA = "0x214AB00", Offset = "0x214AB00", VA = "0x214AB00")]
		public static Offset<ClaimWeeklyLeaderboardRequest> CreateClaimWeeklyLeaderboardRequest(FlatBufferBuilder builder, int user_event_id = 0)
		{
			return default(Offset<ClaimWeeklyLeaderboardRequest>);
		}

		// Token: 0x06010D9E RID: 69022 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D9E")]
		[Address(RVA = "0x214ABD4", Offset = "0x214ABD4", VA = "0x214ABD4")]
		public static void StartClaimWeeklyLeaderboardRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D9F RID: 69023 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D9F")]
		[Address(RVA = "0x214AB48", Offset = "0x214AB48", VA = "0x214AB48")]
		public static void AddUserEventId(FlatBufferBuilder builder, int userEventId)
		{
		}

		// Token: 0x06010DA0 RID: 69024 RVA: 0x000619E0 File Offset: 0x0005FBE0
		[Token(Token = "0x6010DA0")]
		[Address(RVA = "0x214AB68", Offset = "0x214AB68", VA = "0x214AB68")]
		public static Offset<ClaimWeeklyLeaderboardRequest> EndClaimWeeklyLeaderboardRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimWeeklyLeaderboardRequest>);
		}

		// Token: 0x0400E66C RID: 58988
		[Token(Token = "0x400E66C")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
