﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002382 RID: 9090
	[Token(Token = "0x2002382")]
	public struct DismissSuggestionRequest : IFlatbufferObject
	{
		// Token: 0x17001FD6 RID: 8150
		// (get) Token: 0x06010F6C RID: 69484 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FD6")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F6C")]
			[Address(RVA = "0x1F96F48", Offset = "0x1F96F48", VA = "0x1F96F48", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F6D RID: 69485 RVA: 0x000630F0 File Offset: 0x000612F0
		[Token(Token = "0x6010F6D")]
		[Address(RVA = "0x1F96F50", Offset = "0x1F96F50", VA = "0x1F96F50")]
		public static DismissSuggestionRequest GetRootAsDismissSuggestionRequest(ByteBuffer _bb)
		{
			return default(DismissSuggestionRequest);
		}

		// Token: 0x06010F6E RID: 69486 RVA: 0x00063108 File Offset: 0x00061308
		[Token(Token = "0x6010F6E")]
		[Address(RVA = "0x1F96F5C", Offset = "0x1F96F5C", VA = "0x1F96F5C")]
		public static DismissSuggestionRequest GetRootAsDismissSuggestionRequest(ByteBuffer _bb, DismissSuggestionRequest obj)
		{
			return default(DismissSuggestionRequest);
		}

		// Token: 0x06010F6F RID: 69487 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F6F")]
		[Address(RVA = "0x1F9700C", Offset = "0x1F9700C", VA = "0x1F9700C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F70 RID: 69488 RVA: 0x00063120 File Offset: 0x00061320
		[Token(Token = "0x6010F70")]
		[Address(RVA = "0x1F96FD4", Offset = "0x1F96FD4", VA = "0x1F96FD4")]
		public DismissSuggestionRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(DismissSuggestionRequest);
		}

		// Token: 0x17001FD7 RID: 8151
		// (get) Token: 0x06010F71 RID: 69489 RVA: 0x00063138 File Offset: 0x00061338
		[Token(Token = "0x17001FD7")]
		public long UserId
		{
			[Token(Token = "0x6010F71")]
			[Address(RVA = "0x1F9701C", Offset = "0x1F9701C", VA = "0x1F9701C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010F72 RID: 69490 RVA: 0x00063150 File Offset: 0x00061350
		[Token(Token = "0x6010F72")]
		[Address(RVA = "0x1F97064", Offset = "0x1F97064", VA = "0x1F97064")]
		public static Offset<DismissSuggestionRequest> CreateDismissSuggestionRequest(FlatBufferBuilder builder, long user_id = 0L)
		{
			return default(Offset<DismissSuggestionRequest>);
		}

		// Token: 0x06010F73 RID: 69491 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F73")]
		[Address(RVA = "0x1F97138", Offset = "0x1F97138", VA = "0x1F97138")]
		public static void StartDismissSuggestionRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F74 RID: 69492 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F74")]
		[Address(RVA = "0x1F970AC", Offset = "0x1F970AC", VA = "0x1F970AC")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010F75 RID: 69493 RVA: 0x00063168 File Offset: 0x00061368
		[Token(Token = "0x6010F75")]
		[Address(RVA = "0x1F970CC", Offset = "0x1F970CC", VA = "0x1F970CC")]
		public static Offset<DismissSuggestionRequest> EndDismissSuggestionRequest(FlatBufferBuilder builder)
		{
			return default(Offset<DismissSuggestionRequest>);
		}

		// Token: 0x0400E69B RID: 59035
		[Token(Token = "0x400E69B")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
