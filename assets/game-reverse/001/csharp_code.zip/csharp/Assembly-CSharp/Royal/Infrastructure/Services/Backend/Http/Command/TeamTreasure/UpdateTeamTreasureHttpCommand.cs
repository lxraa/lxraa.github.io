﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TeamTreasure
{
	// Token: 0x02002536 RID: 9526
	[Token(Token = "0x2002536")]
	public class UpdateTeamTreasureHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700271F RID: 10015
		// (get) Token: 0x060129F7 RID: 76279 RVA: 0x00077F40 File Offset: 0x00076140
		[Token(Token = "0x1700271F")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129F7")]
			[Address(RVA = "0x1CFC64C", Offset = "0x1CFC64C", VA = "0x1CFC64C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002720 RID: 10016
		// (get) Token: 0x060129F8 RID: 76280 RVA: 0x00077F58 File Offset: 0x00076158
		[Token(Token = "0x17002720")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129F8")]
			[Address(RVA = "0x1CFC654", Offset = "0x1CFC654", VA = "0x1CFC654", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060129F9 RID: 76281 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129F9")]
		[Address(RVA = "0x1CFC65C", Offset = "0x1CFC65C", VA = "0x1CFC65C")]
		public UpdateTeamTreasureHttpCommand(UpdateRequestModel updateRequestModel)
		{
		}

		// Token: 0x17002721 RID: 10017
		// (get) Token: 0x060129FA RID: 76282 RVA: 0x00077F70 File Offset: 0x00076170
		// (set) Token: 0x060129FB RID: 76283 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002721")]
		public UpdateTeamTreasureResponse Response
		{
			[Token(Token = "0x60129FA")]
			[Address(RVA = "0x1CFC68C", Offset = "0x1CFC68C", VA = "0x1CFC68C")]
			get
			{
				return default(UpdateTeamTreasureResponse);
			}
			[Token(Token = "0x60129FB")]
			[Address(RVA = "0x1CFC698", Offset = "0x1CFC698", VA = "0x1CFC698")]
			set
			{
			}
		}

		// Token: 0x060129FC RID: 76284 RVA: 0x00077F88 File Offset: 0x00076188
		[Token(Token = "0x60129FC")]
		[Address(RVA = "0x1CFC6A8", Offset = "0x1CFC6A8", VA = "0x1CFC6A8", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129FD RID: 76285 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129FD")]
		[Address(RVA = "0x1CFCA2C", Offset = "0x1CFCA2C", VA = "0x1CFCA2C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129FE RID: 76286 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129FE")]
		[Address(RVA = "0x1CFCCF0", Offset = "0x1CFCCF0", VA = "0x1CFCCF0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB42 RID: 60226
		[Token(Token = "0x400EB42")]
		[FieldOffset(Offset = "0x18")]
		private UpdateRequestModel requestModel;

		// Token: 0x0400EB43 RID: 60227
		[Token(Token = "0x400EB43")]
		[FieldOffset(Offset = "0x20")]
		private UpdateTeamTreasureResponse <Response>k__BackingField;
	}
}
