﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002385 RID: 9093
	[Token(Token = "0x2002385")]
	public struct DragonNestGroupInfo : IFlatbufferObject
	{
		// Token: 0x17001FDD RID: 8157
		// (get) Token: 0x06010F8C RID: 69516 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FDD")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F8C")]
			[Address(RVA = "0x1F97678", Offset = "0x1F97678", VA = "0x1F97678", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F8D RID: 69517 RVA: 0x000632B8 File Offset: 0x000614B8
		[Token(Token = "0x6010F8D")]
		[Address(RVA = "0x1F97680", Offset = "0x1F97680", VA = "0x1F97680")]
		public static DragonNestGroupInfo GetRootAsDragonNestGroupInfo(ByteBuffer _bb)
		{
			return default(DragonNestGroupInfo);
		}

		// Token: 0x06010F8E RID: 69518 RVA: 0x000632D0 File Offset: 0x000614D0
		[Token(Token = "0x6010F8E")]
		[Address(RVA = "0x1F9768C", Offset = "0x1F9768C", VA = "0x1F9768C")]
		public static DragonNestGroupInfo GetRootAsDragonNestGroupInfo(ByteBuffer _bb, DragonNestGroupInfo obj)
		{
			return default(DragonNestGroupInfo);
		}

		// Token: 0x06010F8F RID: 69519 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F8F")]
		[Address(RVA = "0x1F9773C", Offset = "0x1F9773C", VA = "0x1F9773C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F90 RID: 69520 RVA: 0x000632E8 File Offset: 0x000614E8
		[Token(Token = "0x6010F90")]
		[Address(RVA = "0x1F97704", Offset = "0x1F97704", VA = "0x1F97704")]
		public DragonNestGroupInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestGroupInfo);
		}

		// Token: 0x17001FDE RID: 8158
		// (get) Token: 0x06010F91 RID: 69521 RVA: 0x00063300 File Offset: 0x00061500
		[Token(Token = "0x17001FDE")]
		public DragonType DragonType
		{
			[Token(Token = "0x6010F91")]
			[Address(RVA = "0x1F9774C", Offset = "0x1F9774C", VA = "0x1F9774C")]
			get
			{
				return DragonType.None;
			}
		}

		// Token: 0x17001FDF RID: 8159
		// (get) Token: 0x06010F92 RID: 69522 RVA: 0x00063318 File Offset: 0x00061518
		[Token(Token = "0x17001FDF")]
		public DragonNestUser? PartnerUserProfile
		{
			[Token(Token = "0x6010F92")]
			[Address(RVA = "0x1F97790", Offset = "0x1F97790", VA = "0x1F97790")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FE0 RID: 8160
		// (get) Token: 0x06010F93 RID: 69523 RVA: 0x00063330 File Offset: 0x00061530
		[Token(Token = "0x17001FE0")]
		public int MyScore
		{
			[Token(Token = "0x6010F93")]
			[Address(RVA = "0x1F97848", Offset = "0x1F97848", VA = "0x1F97848")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FE1 RID: 8161
		// (get) Token: 0x06010F94 RID: 69524 RVA: 0x00063348 File Offset: 0x00061548
		[Token(Token = "0x17001FE1")]
		public int PartnerScore
		{
			[Token(Token = "0x6010F94")]
			[Address(RVA = "0x1F9788C", Offset = "0x1F9788C", VA = "0x1F9788C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010F95 RID: 69525 RVA: 0x00063360 File Offset: 0x00061560
		[Token(Token = "0x6010F95")]
		[Address(RVA = "0x1F978D0", Offset = "0x1F978D0", VA = "0x1F978D0")]
		public static Offset<DragonNestGroupInfo> CreateDragonNestGroupInfo(FlatBufferBuilder builder, DragonType dragon_type = DragonType.None, [Optional] Offset<DragonNestUser> partner_user_profileOffset, int my_score = 0, int partner_score = 0)
		{
			return default(Offset<DragonNestGroupInfo>);
		}

		// Token: 0x06010F96 RID: 69526 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F96")]
		[Address(RVA = "0x1F97A3C", Offset = "0x1F97A3C", VA = "0x1F97A3C")]
		public static void StartDragonNestGroupInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F97 RID: 69527 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F97")]
		[Address(RVA = "0x1F979B0", Offset = "0x1F979B0", VA = "0x1F979B0")]
		public static void AddDragonType(FlatBufferBuilder builder, DragonType dragonType)
		{
		}

		// Token: 0x06010F98 RID: 69528 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F98")]
		[Address(RVA = "0x1F97990", Offset = "0x1F97990", VA = "0x1F97990")]
		public static void AddPartnerUserProfile(FlatBufferBuilder builder, Offset<DragonNestUser> partnerUserProfileOffset)
		{
		}

		// Token: 0x06010F99 RID: 69529 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F99")]
		[Address(RVA = "0x1F97970", Offset = "0x1F97970", VA = "0x1F97970")]
		public static void AddMyScore(FlatBufferBuilder builder, int myScore)
		{
		}

		// Token: 0x06010F9A RID: 69530 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F9A")]
		[Address(RVA = "0x1F97950", Offset = "0x1F97950", VA = "0x1F97950")]
		public static void AddPartnerScore(FlatBufferBuilder builder, int partnerScore)
		{
		}

		// Token: 0x06010F9B RID: 69531 RVA: 0x00063378 File Offset: 0x00061578
		[Token(Token = "0x6010F9B")]
		[Address(RVA = "0x1F979D0", Offset = "0x1F979D0", VA = "0x1F979D0")]
		public static Offset<DragonNestGroupInfo> EndDragonNestGroupInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestGroupInfo>);
		}

		// Token: 0x0400E69E RID: 59038
		[Token(Token = "0x400E69E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
