﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Native;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002591 RID: 9617
	[Token(Token = "0x2002591")]
	public static class DeviceSoundInfoAnalyticsHelper
	{
		// Token: 0x170027D9 RID: 10201
		// (get) Token: 0x06012D41 RID: 77121 RVA: 0x00079950 File Offset: 0x00077B50
		[Token(Token = "0x170027D9")]
		private static bool MuteDetectionDisabledByBackend
		{
			[Token(Token = "0x6012D41")]
			[Address(RVA = "0x243A468", Offset = "0x243A468", VA = "0x243A468")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170027DA RID: 10202
		// (get) Token: 0x06012D42 RID: 77122 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170027DA")]
		private static NativeService NativeService
		{
			[Token(Token = "0x6012D42")]
			[Address(RVA = "0x243A4B0", Offset = "0x243A4B0", VA = "0x243A4B0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06012D43 RID: 77123 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D43")]
		[Address(RVA = "0x243A580", Offset = "0x243A580", VA = "0x243A580")]
		public static void TryGetMuteStateFromNativeAtSessionStart()
		{
		}

		// Token: 0x06012D44 RID: 77124 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D44")]
		[Address(RVA = "0x243A6F8", Offset = "0x243A6F8", VA = "0x243A6F8")]
		public static void UpdateMuteStateFromNative(int oldScene, int newScene)
		{
		}

		// Token: 0x06012D45 RID: 77125 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D45")]
		[Address(RVA = "0x243A600", Offset = "0x243A600", VA = "0x243A600")]
		private static void GetMuteStateFromNative()
		{
		}

		// Token: 0x06012D46 RID: 77126 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D46")]
		[Address(RVA = "0x243A7C0", Offset = "0x243A7C0", VA = "0x243A7C0")]
		public static void SetSoundState(bool state)
		{
		}

		// Token: 0x06012D47 RID: 77127 RVA: 0x00079968 File Offset: 0x00077B68
		[Token(Token = "0x6012D47")]
		[Address(RVA = "0x243A83C", Offset = "0x243A83C", VA = "0x243A83C")]
		public static int GetMuteState()
		{
			return 0;
		}

		// Token: 0x06012D48 RID: 77128 RVA: 0x00079980 File Offset: 0x00077B80
		[Token(Token = "0x6012D48")]
		[Address(RVA = "0x243A8AC", Offset = "0x243A8AC", VA = "0x243A8AC")]
		public static int GetMusicVolume()
		{
			return 0;
		}

		// Token: 0x06012D49 RID: 77129 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D49")]
		[Address(RVA = "0x243A908", Offset = "0x243A908", VA = "0x243A908")]
		public static void DisableMuteDetectionByBackend(bool settingsMuteDetectionDisabled)
		{
		}

		// Token: 0x0400ECBD RID: 60605
		[Token(Token = "0x400ECBD")]
		private const int MuteCheckSceneChangeLimit = 5;

		// Token: 0x0400ECBE RID: 60606
		[Token(Token = "0x400ECBE")]
		[FieldOffset(Offset = "0x0")]
		private static DeviceSoundInfoAnalyticsHelper.SoundState MuteState;

		// Token: 0x0400ECBF RID: 60607
		[Token(Token = "0x400ECBF")]
		[FieldOffset(Offset = "0x8")]
		private static NativeService NativeServiceInstance;

		// Token: 0x0400ECC0 RID: 60608
		[Token(Token = "0x400ECC0")]
		[FieldOffset(Offset = "0x10")]
		private static int MuteCheckSceneChangeCount;

		// Token: 0x0400ECC1 RID: 60609
		[Token(Token = "0x400ECC1")]
		[FieldOffset(Offset = "0x14")]
		private static bool WaitingIosResponseFromNative;

		// Token: 0x0400ECC2 RID: 60610
		[Token(Token = "0x400ECC2")]
		[FieldOffset(Offset = "0x15")]
		private static bool ShouldGetMuteStateForSessionStart;

		// Token: 0x02002592 RID: 9618
		[Token(Token = "0x2002592")]
		private enum SoundState
		{
			// Token: 0x0400ECC4 RID: 60612
			[Token(Token = "0x400ECC4")]
			Mute,
			// Token: 0x0400ECC5 RID: 60613
			[Token(Token = "0x400ECC5")]
			Unmute,
			// Token: 0x0400ECC6 RID: 60614
			[Token(Token = "0x400ECC6")]
			Unknown
		}
	}
}
