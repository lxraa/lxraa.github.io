﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200236C RID: 9068
	[Token(Token = "0x200236C")]
	public struct ConsumeSystemMessagesRequest : IFlatbufferObject
	{
		// Token: 0x17001F75 RID: 8053
		// (get) Token: 0x06010E0C RID: 69132 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F75")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010E0C")]
			[Address(RVA = "0x1F918EC", Offset = "0x1F918EC", VA = "0x1F918EC", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E0D RID: 69133 RVA: 0x00061F80 File Offset: 0x00060180
		[Token(Token = "0x6010E0D")]
		[Address(RVA = "0x1F918F4", Offset = "0x1F918F4", VA = "0x1F918F4")]
		public static ConsumeSystemMessagesRequest GetRootAsConsumeSystemMessagesRequest(ByteBuffer _bb)
		{
			return default(ConsumeSystemMessagesRequest);
		}

		// Token: 0x06010E0E RID: 69134 RVA: 0x00061F98 File Offset: 0x00060198
		[Token(Token = "0x6010E0E")]
		[Address(RVA = "0x1F91900", Offset = "0x1F91900", VA = "0x1F91900")]
		public static ConsumeSystemMessagesRequest GetRootAsConsumeSystemMessagesRequest(ByteBuffer _bb, ConsumeSystemMessagesRequest obj)
		{
			return default(ConsumeSystemMessagesRequest);
		}

		// Token: 0x06010E0F RID: 69135 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E0F")]
		[Address(RVA = "0x1F919B0", Offset = "0x1F919B0", VA = "0x1F919B0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010E10 RID: 69136 RVA: 0x00061FB0 File Offset: 0x000601B0
		[Token(Token = "0x6010E10")]
		[Address(RVA = "0x1F91978", Offset = "0x1F91978", VA = "0x1F91978")]
		public ConsumeSystemMessagesRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ConsumeSystemMessagesRequest);
		}

		// Token: 0x17001F76 RID: 8054
		// (get) Token: 0x06010E11 RID: 69137 RVA: 0x00061FC8 File Offset: 0x000601C8
		[Token(Token = "0x17001F76")]
		public int MessageId
		{
			[Token(Token = "0x6010E11")]
			[Address(RVA = "0x1F919C0", Offset = "0x1F919C0", VA = "0x1F919C0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010E12 RID: 69138 RVA: 0x00061FE0 File Offset: 0x000601E0
		[Token(Token = "0x6010E12")]
		[Address(RVA = "0x1F91A04", Offset = "0x1F91A04", VA = "0x1F91A04")]
		public static Offset<ConsumeSystemMessagesRequest> CreateConsumeSystemMessagesRequest(FlatBufferBuilder builder, int message_id = 0)
		{
			return default(Offset<ConsumeSystemMessagesRequest>);
		}

		// Token: 0x06010E13 RID: 69139 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E13")]
		[Address(RVA = "0x1F91AD8", Offset = "0x1F91AD8", VA = "0x1F91AD8")]
		public static void StartConsumeSystemMessagesRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010E14 RID: 69140 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E14")]
		[Address(RVA = "0x1F91A4C", Offset = "0x1F91A4C", VA = "0x1F91A4C")]
		public static void AddMessageId(FlatBufferBuilder builder, int messageId)
		{
		}

		// Token: 0x06010E15 RID: 69141 RVA: 0x00061FF8 File Offset: 0x000601F8
		[Token(Token = "0x6010E15")]
		[Address(RVA = "0x1F91A6C", Offset = "0x1F91A6C", VA = "0x1F91A6C")]
		public static Offset<ConsumeSystemMessagesRequest> EndConsumeSystemMessagesRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ConsumeSystemMessagesRequest>);
		}

		// Token: 0x0400E672 RID: 58994
		[Token(Token = "0x400E672")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
