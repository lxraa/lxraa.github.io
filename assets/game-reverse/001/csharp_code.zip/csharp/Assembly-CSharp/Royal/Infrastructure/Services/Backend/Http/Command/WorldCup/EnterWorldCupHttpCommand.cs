﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.WorldCup
{
	// Token: 0x02002522 RID: 9506
	[Token(Token = "0x2002522")]
	public class EnterWorldCupHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026F4 RID: 9972
		// (get) Token: 0x06012976 RID: 76150 RVA: 0x00077910 File Offset: 0x00075B10
		[Token(Token = "0x170026F4")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012976")]
			[Address(RVA = "0x1CF7958", Offset = "0x1CF7958", VA = "0x1CF7958", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026F5 RID: 9973
		// (get) Token: 0x06012977 RID: 76151 RVA: 0x00077928 File Offset: 0x00075B28
		[Token(Token = "0x170026F5")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012977")]
			[Address(RVA = "0x1CF7960", Offset = "0x1CF7960", VA = "0x1CF7960", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012978 RID: 76152 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012978")]
		[Address(RVA = "0x1CF7968", Offset = "0x1CF7968", VA = "0x1CF7968")]
		public EnterWorldCupHttpCommand(int eventId, WorldCupStage stage, string country)
		{
		}

		// Token: 0x06012979 RID: 76153 RVA: 0x00077940 File Offset: 0x00075B40
		[Token(Token = "0x6012979")]
		[Address(RVA = "0x1CF79B0", Offset = "0x1CF79B0", VA = "0x1CF79B0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x0601297A RID: 76154 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601297A")]
		[Address(RVA = "0x1CF7A9C", Offset = "0x1CF7A9C", VA = "0x1CF7A9C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x0601297B RID: 76155 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601297B")]
		[Address(RVA = "0x1CF7D7C", Offset = "0x1CF7D7C", VA = "0x1CF7D7C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB0E RID: 60174
		[Token(Token = "0x400EB0E")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;

		// Token: 0x0400EB0F RID: 60175
		[Token(Token = "0x400EB0F")]
		[FieldOffset(Offset = "0x18")]
		private readonly WorldCupStage stage;

		// Token: 0x0400EB10 RID: 60176
		[Token(Token = "0x400EB10")]
		[FieldOffset(Offset = "0x20")]
		private readonly string country;
	}
}
