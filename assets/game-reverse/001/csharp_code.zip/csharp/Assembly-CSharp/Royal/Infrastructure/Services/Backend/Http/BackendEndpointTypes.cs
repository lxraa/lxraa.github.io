﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Http
{
	// Token: 0x02002502 RID: 9474
	[Token(Token = "0x2002502")]
	public enum BackendEndpointTypes
	{
		// Token: 0x0400EA37 RID: 59959
		[Token(Token = "0x400EA37")]
		GameServerEndpoint,
		// Token: 0x0400EA38 RID: 59960
		[Token(Token = "0x400EA38")]
		PurchaseServerEndpoint,
		// Token: 0x0400EA39 RID: 59961
		[Token(Token = "0x400EA39")]
		StatsServerEndpoint,
		// Token: 0x0400EA3A RID: 59962
		[Token(Token = "0x400EA3A")]
		NotificationTagServerEndpoint,
		// Token: 0x0400EA3B RID: 59963
		[Token(Token = "0x400EA3B")]
		SocialServerEndpoint
	}
}
