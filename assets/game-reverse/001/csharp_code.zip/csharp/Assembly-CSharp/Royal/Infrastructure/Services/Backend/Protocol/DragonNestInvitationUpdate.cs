﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002387 RID: 9095
	[Token(Token = "0x2002387")]
	public struct DragonNestInvitationUpdate : IFlatbufferObject
	{
		// Token: 0x17001FE7 RID: 8167
		// (get) Token: 0x06010FAE RID: 69550 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FE7")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010FAE")]
			[Address(RVA = "0x1F97E3C", Offset = "0x1F97E3C", VA = "0x1F97E3C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FAF RID: 69551 RVA: 0x00063468 File Offset: 0x00061668
		[Token(Token = "0x6010FAF")]
		[Address(RVA = "0x1F97E44", Offset = "0x1F97E44", VA = "0x1F97E44")]
		public static DragonNestInvitationUpdate GetRootAsDragonNestInvitationUpdate(ByteBuffer _bb)
		{
			return default(DragonNestInvitationUpdate);
		}

		// Token: 0x06010FB0 RID: 69552 RVA: 0x00063480 File Offset: 0x00061680
		[Token(Token = "0x6010FB0")]
		[Address(RVA = "0x1F97E50", Offset = "0x1F97E50", VA = "0x1F97E50")]
		public static DragonNestInvitationUpdate GetRootAsDragonNestInvitationUpdate(ByteBuffer _bb, DragonNestInvitationUpdate obj)
		{
			return default(DragonNestInvitationUpdate);
		}

		// Token: 0x06010FB1 RID: 69553 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FB1")]
		[Address(RVA = "0x1F97F00", Offset = "0x1F97F00", VA = "0x1F97F00", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010FB2 RID: 69554 RVA: 0x00063498 File Offset: 0x00061698
		[Token(Token = "0x6010FB2")]
		[Address(RVA = "0x1F97EC8", Offset = "0x1F97EC8", VA = "0x1F97EC8")]
		public DragonNestInvitationUpdate __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestInvitationUpdate);
		}

		// Token: 0x17001FE8 RID: 8168
		// (get) Token: 0x06010FB3 RID: 69555 RVA: 0x000634B0 File Offset: 0x000616B0
		[Token(Token = "0x17001FE8")]
		public CoopEventInvitationStatus InvitationStatus
		{
			[Token(Token = "0x6010FB3")]
			[Address(RVA = "0x1F97F10", Offset = "0x1F97F10", VA = "0x1F97F10")]
			get
			{
				return CoopEventInvitationStatus.Requested;
			}
		}

		// Token: 0x17001FE9 RID: 8169
		// (get) Token: 0x06010FB4 RID: 69556 RVA: 0x000634C8 File Offset: 0x000616C8
		[Token(Token = "0x17001FE9")]
		public DragonNestUser? PartnerProfileData
		{
			[Token(Token = "0x6010FB4")]
			[Address(RVA = "0x1F97F54", Offset = "0x1F97F54", VA = "0x1F97F54")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FEA RID: 8170
		// (get) Token: 0x06010FB5 RID: 69557 RVA: 0x000634E0 File Offset: 0x000616E0
		[Token(Token = "0x17001FEA")]
		public DragonType DragonType
		{
			[Token(Token = "0x6010FB5")]
			[Address(RVA = "0x1F9800C", Offset = "0x1F9800C", VA = "0x1F9800C")]
			get
			{
				return DragonType.None;
			}
		}

		// Token: 0x17001FEB RID: 8171
		// (get) Token: 0x06010FB6 RID: 69558 RVA: 0x000634F8 File Offset: 0x000616F8
		[Token(Token = "0x17001FEB")]
		public sbyte DragonIndex
		{
			[Token(Token = "0x6010FB6")]
			[Address(RVA = "0x1F98050", Offset = "0x1F98050", VA = "0x1F98050")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010FB7 RID: 69559 RVA: 0x00063510 File Offset: 0x00061710
		[Token(Token = "0x6010FB7")]
		[Address(RVA = "0x1F98094", Offset = "0x1F98094", VA = "0x1F98094")]
		public static Offset<DragonNestInvitationUpdate> CreateDragonNestInvitationUpdate(FlatBufferBuilder builder, CoopEventInvitationStatus invitation_status = CoopEventInvitationStatus.Requested, [Optional] Offset<DragonNestUser> partner_profile_dataOffset, DragonType dragon_type = DragonType.None, sbyte dragon_index = 0)
		{
			return default(Offset<DragonNestInvitationUpdate>);
		}

		// Token: 0x06010FB8 RID: 69560 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FB8")]
		[Address(RVA = "0x1F98200", Offset = "0x1F98200", VA = "0x1F98200")]
		public static void StartDragonNestInvitationUpdate(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010FB9 RID: 69561 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FB9")]
		[Address(RVA = "0x1F98174", Offset = "0x1F98174", VA = "0x1F98174")]
		public static void AddInvitationStatus(FlatBufferBuilder builder, CoopEventInvitationStatus invitationStatus)
		{
		}

		// Token: 0x06010FBA RID: 69562 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FBA")]
		[Address(RVA = "0x1F98114", Offset = "0x1F98114", VA = "0x1F98114")]
		public static void AddPartnerProfileData(FlatBufferBuilder builder, Offset<DragonNestUser> partnerProfileDataOffset)
		{
		}

		// Token: 0x06010FBB RID: 69563 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FBB")]
		[Address(RVA = "0x1F98154", Offset = "0x1F98154", VA = "0x1F98154")]
		public static void AddDragonType(FlatBufferBuilder builder, DragonType dragonType)
		{
		}

		// Token: 0x06010FBC RID: 69564 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FBC")]
		[Address(RVA = "0x1F98134", Offset = "0x1F98134", VA = "0x1F98134")]
		public static void AddDragonIndex(FlatBufferBuilder builder, sbyte dragonIndex)
		{
		}

		// Token: 0x06010FBD RID: 69565 RVA: 0x00063528 File Offset: 0x00061728
		[Token(Token = "0x6010FBD")]
		[Address(RVA = "0x1F98194", Offset = "0x1F98194", VA = "0x1F98194")]
		public static Offset<DragonNestInvitationUpdate> EndDragonNestInvitationUpdate(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestInvitationUpdate>);
		}

		// Token: 0x0400E6A0 RID: 59040
		[Token(Token = "0x400E6A0")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
