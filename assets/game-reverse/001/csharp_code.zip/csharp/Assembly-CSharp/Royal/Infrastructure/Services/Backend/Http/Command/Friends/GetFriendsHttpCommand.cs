﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Friends
{
	// Token: 0x02002569 RID: 9577
	[Token(Token = "0x2002569")]
	public class GetFriendsHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700279C RID: 10140
		// (get) Token: 0x06012B66 RID: 76646 RVA: 0x00079038 File Offset: 0x00077238
		[Token(Token = "0x1700279C")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B66")]
			[Address(RVA = "0x1ED1EB4", Offset = "0x1ED1EB4", VA = "0x1ED1EB4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700279D RID: 10141
		// (get) Token: 0x06012B67 RID: 76647 RVA: 0x00079050 File Offset: 0x00077250
		[Token(Token = "0x1700279D")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B67")]
			[Address(RVA = "0x1ED1EBC", Offset = "0x1ED1EBC", VA = "0x1ED1EBC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B68 RID: 76648 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B68")]
		[Address(RVA = "0x1ED1EC4", Offset = "0x1ED1EC4", VA = "0x1ED1EC4")]
		public GetFriendsHttpCommand([Optional] Action onCompleted, bool getFriendSuggestions = false)
		{
		}

		// Token: 0x06012B69 RID: 76649 RVA: 0x00079068 File Offset: 0x00077268
		[Token(Token = "0x6012B69")]
		[Address(RVA = "0x1ED1F00", Offset = "0x1ED1F00", VA = "0x1ED1F00", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B6A RID: 76650 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B6A")]
		[Address(RVA = "0x1ED1F20", Offset = "0x1ED1F20", VA = "0x1ED1F20", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B6B RID: 76651 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B6B")]
		[Address(RVA = "0x1ED21AC", Offset = "0x1ED21AC", VA = "0x1ED21AC", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBDE RID: 60382
		[Token(Token = "0x400EBDE")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		private readonly Action onCompleted;

		// Token: 0x0400EBDF RID: 60383
		[Token(Token = "0x400EBDF")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		private readonly bool getFriendSuggestions;
	}
}
