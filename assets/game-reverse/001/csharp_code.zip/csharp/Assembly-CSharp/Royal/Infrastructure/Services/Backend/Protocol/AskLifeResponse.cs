﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002342 RID: 9026
	[Token(Token = "0x2002342")]
	public struct AskLifeResponse : IFlatbufferObject
	{
		// Token: 0x17001ED2 RID: 7890
		// (get) Token: 0x06010BA9 RID: 68521 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001ED2")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010BA9")]
			[Address(RVA = "0x2143848", Offset = "0x2143848", VA = "0x2143848", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BAA RID: 68522 RVA: 0x000600A8 File Offset: 0x0005E2A8
		[Token(Token = "0x6010BAA")]
		[Address(RVA = "0x2143850", Offset = "0x2143850", VA = "0x2143850")]
		public static AskLifeResponse GetRootAsAskLifeResponse(ByteBuffer _bb)
		{
			return default(AskLifeResponse);
		}

		// Token: 0x06010BAB RID: 68523 RVA: 0x000600C0 File Offset: 0x0005E2C0
		[Token(Token = "0x6010BAB")]
		[Address(RVA = "0x214385C", Offset = "0x214385C", VA = "0x214385C")]
		public static AskLifeResponse GetRootAsAskLifeResponse(ByteBuffer _bb, AskLifeResponse obj)
		{
			return default(AskLifeResponse);
		}

		// Token: 0x06010BAC RID: 68524 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BAC")]
		[Address(RVA = "0x214390C", Offset = "0x214390C", VA = "0x214390C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010BAD RID: 68525 RVA: 0x000600D8 File Offset: 0x0005E2D8
		[Token(Token = "0x6010BAD")]
		[Address(RVA = "0x21438D4", Offset = "0x21438D4", VA = "0x21438D4")]
		public AskLifeResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(AskLifeResponse);
		}

		// Token: 0x17001ED3 RID: 7891
		// (get) Token: 0x06010BAE RID: 68526 RVA: 0x000600F0 File Offset: 0x0005E2F0
		[Token(Token = "0x17001ED3")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010BAE")]
			[Address(RVA = "0x214391C", Offset = "0x214391C", VA = "0x214391C")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001ED4 RID: 7892
		// (get) Token: 0x06010BAF RID: 68527 RVA: 0x00060108 File Offset: 0x0005E308
		[Token(Token = "0x17001ED4")]
		public long RemainingTime
		{
			[Token(Token = "0x6010BAF")]
			[Address(RVA = "0x2143960", Offset = "0x2143960", VA = "0x2143960")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010BB0 RID: 68528 RVA: 0x00060120 File Offset: 0x0005E320
		[Token(Token = "0x6010BB0")]
		[Address(RVA = "0x21439A8", Offset = "0x21439A8", VA = "0x21439A8")]
		public static Offset<AskLifeResponse> CreateAskLifeResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, long remaining_time = 0L)
		{
			return default(Offset<AskLifeResponse>);
		}

		// Token: 0x06010BB1 RID: 68529 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BB1")]
		[Address(RVA = "0x2143AAC", Offset = "0x2143AAC", VA = "0x2143AAC")]
		public static void StartAskLifeResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010BB2 RID: 68530 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BB2")]
		[Address(RVA = "0x2143A20", Offset = "0x2143A20", VA = "0x2143A20")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010BB3 RID: 68531 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BB3")]
		[Address(RVA = "0x2143A00", Offset = "0x2143A00", VA = "0x2143A00")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010BB4 RID: 68532 RVA: 0x00060138 File Offset: 0x0005E338
		[Token(Token = "0x6010BB4")]
		[Address(RVA = "0x2143A40", Offset = "0x2143A40", VA = "0x2143A40")]
		public static Offset<AskLifeResponse> EndAskLifeResponse(FlatBufferBuilder builder)
		{
			return default(Offset<AskLifeResponse>);
		}

		// Token: 0x0400E626 RID: 58918
		[Token(Token = "0x400E626")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
