﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x0200251A RID: 9498
	[Token(Token = "0x200251A")]
	public class PurchaseInMaintenanceModeHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026DD RID: 9949
		// (get) Token: 0x06012912 RID: 76050 RVA: 0x00077628 File Offset: 0x00075828
		[Token(Token = "0x170026DD")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012912")]
			[Address(RVA = "0x1CF017C", Offset = "0x1CF017C", VA = "0x1CF017C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026DE RID: 9950
		// (get) Token: 0x06012913 RID: 76051 RVA: 0x00077640 File Offset: 0x00075840
		[Token(Token = "0x170026DE")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012913")]
			[Address(RVA = "0x1CF0184", Offset = "0x1CF0184", VA = "0x1CF0184", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026DF RID: 9951
		// (get) Token: 0x06012914 RID: 76052 RVA: 0x00077658 File Offset: 0x00075858
		// (set) Token: 0x06012915 RID: 76053 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026DF")]
		private PurchaseInMaintenanceModeResponse Response
		{
			[Token(Token = "0x6012914")]
			[Address(RVA = "0x1CF018C", Offset = "0x1CF018C", VA = "0x1CF018C")]
			get
			{
				return default(PurchaseInMaintenanceModeResponse);
			}
			[Token(Token = "0x6012915")]
			[Address(RVA = "0x1CF0198", Offset = "0x1CF0198", VA = "0x1CF0198")]
			set
			{
			}
		}

		// Token: 0x06012916 RID: 76054 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012916")]
		[Address(RVA = "0x1CF01A8", Offset = "0x1CF01A8", VA = "0x1CF01A8")]
		public PurchaseInMaintenanceModeHttpCommand(long maintenanceTimeMs)
		{
		}

		// Token: 0x06012917 RID: 76055 RVA: 0x00077670 File Offset: 0x00075870
		[Token(Token = "0x6012917")]
		[Address(RVA = "0x1CF01D0", Offset = "0x1CF01D0", VA = "0x1CF01D0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012918 RID: 76056 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012918")]
		[Address(RVA = "0x1CF02F8", Offset = "0x1CF02F8", VA = "0x1CF02F8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012919 RID: 76057 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012919")]
		[Address(RVA = "0x1CF03C8", Offset = "0x1CF03C8", VA = "0x1CF03C8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EAEA RID: 60138
		[Token(Token = "0x400EAEA")]
		[FieldOffset(Offset = "0x18")]
		private PurchaseInMaintenanceModeResponse <Response>k__BackingField;

		// Token: 0x0400EAEB RID: 60139
		[Token(Token = "0x400EAEB")]
		[FieldOffset(Offset = "0x28")]
		private readonly long maintenanceTimeMs;
	}
}
