﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002583 RID: 9603
	[Token(Token = "0x2002583")]
	public interface IFileDownloader
	{
		// Token: 0x170027CD RID: 10189
		// (get) Token: 0x06012C3D RID: 76861
		[Token(Token = "0x170027CD")]
		bool IsDownloading { [Token(Token = "0x6012C3D")] get; }

		// Token: 0x06012C3E RID: 76862
		[Token(Token = "0x6012C3E")]
		void Download(string fileName, string url, string saveDirectory, Action<bool, string> onSaveComplete, bool isTexture);

		// Token: 0x06012C3F RID: 76863
		[Token(Token = "0x6012C3F")]
		void UnityWebRequestManualUpdate();
	}
}
