﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SeasonalCardCollection
{
	// Token: 0x0200254E RID: 9550
	[Token(Token = "0x200254E")]
	public class SendSeasonalCardToFriendCommand : BaseHttpCommand
	{
		// Token: 0x1700275D RID: 10077
		// (get) Token: 0x06012AAE RID: 76462 RVA: 0x00078768 File Offset: 0x00076968
		[Token(Token = "0x1700275D")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AAE")]
			[Address(RVA = "0x1ECCBE4", Offset = "0x1ECCBE4", VA = "0x1ECCBE4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700275E RID: 10078
		// (get) Token: 0x06012AAF RID: 76463 RVA: 0x00078780 File Offset: 0x00076980
		[Token(Token = "0x1700275E")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AAF")]
			[Address(RVA = "0x1ECCBEC", Offset = "0x1ECCBEC", VA = "0x1ECCBEC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AB0 RID: 76464 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AB0")]
		[Address(RVA = "0x1ECCBF4", Offset = "0x1ECCBF4", VA = "0x1ECCBF4")]
		public SendSeasonalCardToFriendCommand(long friendId, int eventId, int setId, int cardId, UserProfileSetting profileSetting, Action<SeasonalCardCollectionCardOperationStatus, int, int, long, int, CardTransactionType> onComplete, int eventStage, CardTransactionType cardTransactionType)
		{
		}

		// Token: 0x06012AB1 RID: 76465 RVA: 0x00078798 File Offset: 0x00076998
		[Token(Token = "0x6012AB1")]
		[Address(RVA = "0x1ECCC78", Offset = "0x1ECCC78", VA = "0x1ECCC78", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AB2 RID: 76466 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AB2")]
		[Address(RVA = "0x1ECCF18", Offset = "0x1ECCF18", VA = "0x1ECCF18", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AB3 RID: 76467 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AB3")]
		[Address(RVA = "0x1ECD0B8", Offset = "0x1ECD0B8", VA = "0x1ECD0B8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB8E RID: 60302
		[Token(Token = "0x400EB8E")]
		[FieldOffset(Offset = "0x18")]
		private readonly long friendId;

		// Token: 0x0400EB8F RID: 60303
		[Token(Token = "0x400EB8F")]
		[FieldOffset(Offset = "0x20")]
		private readonly int eventId;

		// Token: 0x0400EB90 RID: 60304
		[Token(Token = "0x400EB90")]
		[FieldOffset(Offset = "0x24")]
		private readonly int setId;

		// Token: 0x0400EB91 RID: 60305
		[Token(Token = "0x400EB91")]
		[FieldOffset(Offset = "0x28")]
		private readonly int cardId;

		// Token: 0x0400EB92 RID: 60306
		[Token(Token = "0x400EB92")]
		[FieldOffset(Offset = "0x30")]
		private readonly UserProfileSetting profileSetting;

		// Token: 0x0400EB93 RID: 60307
		[Token(Token = "0x400EB93")]
		[FieldOffset(Offset = "0x50")]
		private readonly Action<SeasonalCardCollectionCardOperationStatus, int, int, long, int, CardTransactionType> onComplete;

		// Token: 0x0400EB94 RID: 60308
		[Token(Token = "0x400EB94")]
		[FieldOffset(Offset = "0x58")]
		private readonly int eventStage;

		// Token: 0x0400EB95 RID: 60309
		[Token(Token = "0x400EB95")]
		[FieldOffset(Offset = "0x5C")]
		private readonly CardTransactionType cardTransactionType;
	}
}
