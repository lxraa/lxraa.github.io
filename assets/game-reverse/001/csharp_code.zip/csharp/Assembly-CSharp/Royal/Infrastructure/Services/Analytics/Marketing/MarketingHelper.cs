﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Native.Purchase;
using Royal.Player.Context.Data.Session;

namespace Royal.Infrastructure.Services.Analytics.Marketing
{
	// Token: 0x020025A3 RID: 9635
	[Token(Token = "0x20025A3")]
	public class MarketingHelper
	{
		// Token: 0x06012D60 RID: 77152 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D60")]
		[Address(RVA = "0x243B48C", Offset = "0x243B48C", VA = "0x243B48C")]
		public MarketingHelper()
		{
		}

		// Token: 0x170027DB RID: 10203
		// (get) Token: 0x06012D61 RID: 77153 RVA: 0x00079998 File Offset: 0x00077B98
		[Token(Token = "0x170027DB")]
		private static int CurrentDay
		{
			[Token(Token = "0x6012D61")]
			[Address(RVA = "0x243B71C", Offset = "0x243B71C", VA = "0x243B71C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170027DC RID: 10204
		// (get) Token: 0x06012D62 RID: 77154 RVA: 0x000799B0 File Offset: 0x00077BB0
		[Token(Token = "0x170027DC")]
		private static long TimeSinceInstallTimeInMs
		{
			[Token(Token = "0x6012D62")]
			[Address(RVA = "0x243B748", Offset = "0x243B748", VA = "0x243B748")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06012D63 RID: 77155 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D63")]
		[Address(RVA = "0x243B7D8", Offset = "0x243B7D8", VA = "0x243B7D8")]
		public static void RequestAppTrackingAuthorization()
		{
		}

		// Token: 0x06012D64 RID: 77156 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D64")]
		[Address(RVA = "0x243B85C", Offset = "0x243B85C", VA = "0x243B85C")]
		public static void Initialize()
		{
		}

		// Token: 0x06012D65 RID: 77157 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D65")]
		[Address(RVA = "0x243B52C", Offset = "0x243B52C", VA = "0x243B52C")]
		public void UpdateUserData()
		{
		}

		// Token: 0x06012D66 RID: 77158 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D66")]
		[Address(RVA = "0x243B860", Offset = "0x243B860", VA = "0x243B860")]
		public void SendPurchaseEvent(PurchaseProduct purchaseProduct)
		{
		}

		// Token: 0x06012D67 RID: 77159 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D67")]
		[Address(RVA = "0x243BB68", Offset = "0x243BB68", VA = "0x243BB68")]
		private void SendExtraPurchaseEvents(string productId, int usdPrice)
		{
		}

		// Token: 0x06012D68 RID: 77160 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D68")]
		[Address(RVA = "0x243BEF0", Offset = "0x243BEF0", VA = "0x243BEF0")]
		public void SendLevelEndEvent(UserActiveLevelData levelData)
		{
		}

		// Token: 0x06012D69 RID: 77161 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D69")]
		[Address(RVA = "0x243C0E4", Offset = "0x243C0E4", VA = "0x243C0E4")]
		private void LevelEndEvent(int level)
		{
		}

		// Token: 0x06012D6A RID: 77162 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D6A")]
		[Address(RVA = "0x243BFC8", Offset = "0x243BFC8", VA = "0x243BFC8")]
		private void SendLevelAchievedEvent(int level)
		{
		}

		// Token: 0x06012D6B RID: 77163 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D6B")]
		[Address(RVA = "0x243B638", Offset = "0x243B638", VA = "0x243B638")]
		private static void SendSessionEvent()
		{
		}

		// Token: 0x06012D6C RID: 77164 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D6C")]
		[Address(RVA = "0x243C1E0", Offset = "0x243C1E0", VA = "0x243C1E0")]
		private void SendFirstDaySpendEvent(int newSpending)
		{
		}

		// Token: 0x06012D6D RID: 77165 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D6D")]
		[Address(RVA = "0x243C310", Offset = "0x243C310", VA = "0x243C310")]
		public static void SendShopOpenEvent()
		{
		}

		// Token: 0x06012D6E RID: 77166 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D6E")]
		[Address(RVA = "0x243C3AC", Offset = "0x243C3AC", VA = "0x243C3AC")]
		public static void RegisterPushNotification(string pushToken)
		{
		}

		// Token: 0x06012D6F RID: 77167 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D6F")]
		[Address(RVA = "0x243C3B0", Offset = "0x243C3B0", VA = "0x243C3B0")]
		public void SpendCoin(int newSpending)
		{
		}

		// Token: 0x0400ED33 RID: 60723
		[Token(Token = "0x400ED33")]
		[FieldOffset(Offset = "0x10")]
		private readonly bool shouldCheckForSpendingEvent;

		// Token: 0x0400ED34 RID: 60724
		[Token(Token = "0x400ED34")]
		[FieldOffset(Offset = "0x14")]
		private int spendAmount;

		// Token: 0x0400ED35 RID: 60725
		[Token(Token = "0x400ED35")]
		private const int OneDayInMs = 86400000;
	}
}
