﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TeamBattle
{
	// Token: 0x0200253B RID: 9531
	[Token(Token = "0x200253B")]
	public class GetTeamBattleInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700272B RID: 10027
		// (get) Token: 0x06012A1A RID: 76314 RVA: 0x000780F0 File Offset: 0x000762F0
		[Token(Token = "0x1700272B")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A1A")]
			[Address(RVA = "0x1CFE32C", Offset = "0x1CFE32C", VA = "0x1CFE32C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700272C RID: 10028
		// (get) Token: 0x06012A1B RID: 76315 RVA: 0x00078108 File Offset: 0x00076308
		[Token(Token = "0x1700272C")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A1B")]
			[Address(RVA = "0x1CFE334", Offset = "0x1CFE334", VA = "0x1CFE334", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700272D RID: 10029
		// (get) Token: 0x06012A1C RID: 76316 RVA: 0x00078120 File Offset: 0x00076320
		// (set) Token: 0x06012A1D RID: 76317 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700272D")]
		public GetTeamBattleInfoResponse Response
		{
			[Token(Token = "0x6012A1C")]
			[Address(RVA = "0x1CFE33C", Offset = "0x1CFE33C", VA = "0x1CFE33C")]
			get
			{
				return default(GetTeamBattleInfoResponse);
			}
			[Token(Token = "0x6012A1D")]
			[Address(RVA = "0x1CFE348", Offset = "0x1CFE348", VA = "0x1CFE348")]
			set
			{
			}
		}

		// Token: 0x06012A1E RID: 76318 RVA: 0x00078138 File Offset: 0x00076338
		[Token(Token = "0x6012A1E")]
		[Address(RVA = "0x1CFE358", Offset = "0x1CFE358", VA = "0x1CFE358", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A1F RID: 76319 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A1F")]
		[Address(RVA = "0x1CFE428", Offset = "0x1CFE428", VA = "0x1CFE428", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A20 RID: 76320 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A20")]
		[Address(RVA = "0x1CFE5A4", Offset = "0x1CFE5A4", VA = "0x1CFE5A4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012A21 RID: 76321 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A21")]
		[Address(RVA = "0x1CFE5A8", Offset = "0x1CFE5A8", VA = "0x1CFE5A8")]
		public GetTeamBattleInfoHttpCommand()
		{
		}

		// Token: 0x0400EB54 RID: 60244
		[Token(Token = "0x400EB54")]
		[FieldOffset(Offset = "0x18")]
		private GetTeamBattleInfoResponse <Response>k__BackingField;
	}
}
