﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200236A RID: 9066
	[Token(Token = "0x200236A")]
	public struct ConsumeLifeRequest : IFlatbufferObject
	{
		// Token: 0x17001F71 RID: 8049
		// (get) Token: 0x06010DF2 RID: 69106 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F71")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010DF2")]
			[Address(RVA = "0x214BF20", Offset = "0x214BF20", VA = "0x214BF20", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010DF3 RID: 69107 RVA: 0x00061E00 File Offset: 0x00060000
		[Token(Token = "0x6010DF3")]
		[Address(RVA = "0x214BF28", Offset = "0x214BF28", VA = "0x214BF28")]
		public static ConsumeLifeRequest GetRootAsConsumeLifeRequest(ByteBuffer _bb)
		{
			return default(ConsumeLifeRequest);
		}

		// Token: 0x06010DF4 RID: 69108 RVA: 0x00061E18 File Offset: 0x00060018
		[Token(Token = "0x6010DF4")]
		[Address(RVA = "0x214BF34", Offset = "0x214BF34", VA = "0x214BF34")]
		public static ConsumeLifeRequest GetRootAsConsumeLifeRequest(ByteBuffer _bb, ConsumeLifeRequest obj)
		{
			return default(ConsumeLifeRequest);
		}

		// Token: 0x06010DF5 RID: 69109 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DF5")]
		[Address(RVA = "0x214BFE4", Offset = "0x214BFE4", VA = "0x214BFE4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010DF6 RID: 69110 RVA: 0x00061E30 File Offset: 0x00060030
		[Token(Token = "0x6010DF6")]
		[Address(RVA = "0x214BFAC", Offset = "0x214BFAC", VA = "0x214BFAC")]
		public ConsumeLifeRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ConsumeLifeRequest);
		}

		// Token: 0x06010DF7 RID: 69111 RVA: 0x00061E48 File Offset: 0x00060048
		[Token(Token = "0x6010DF7")]
		[Address(RVA = "0x214BFF4", Offset = "0x214BFF4", VA = "0x214BFF4")]
		public long Consumed(int j)
		{
			return 0L;
		}

		// Token: 0x17001F72 RID: 8050
		// (get) Token: 0x06010DF8 RID: 69112 RVA: 0x00061E60 File Offset: 0x00060060
		[Token(Token = "0x17001F72")]
		public int ConsumedLength
		{
			[Token(Token = "0x6010DF8")]
			[Address(RVA = "0x214C058", Offset = "0x214C058", VA = "0x214C058")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010DF9 RID: 69113 RVA: 0x00061E78 File Offset: 0x00060078
		[Token(Token = "0x6010DF9")]
		[Address(RVA = "0x214C08C", Offset = "0x214C08C", VA = "0x214C08C")]
		public ArraySegment<byte>? GetConsumedBytes()
		{
			return null;
		}

		// Token: 0x06010DFA RID: 69114 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010DFA")]
		[Address(RVA = "0x214C0C4", Offset = "0x214C0C4", VA = "0x214C0C4")]
		public long[] GetConsumedArray()
		{
			return null;
		}

		// Token: 0x06010DFB RID: 69115 RVA: 0x00061E90 File Offset: 0x00060090
		[Token(Token = "0x6010DFB")]
		[Address(RVA = "0x2140C9C", Offset = "0x2140C9C", VA = "0x2140C9C")]
		public static Offset<ConsumeLifeRequest> CreateConsumeLifeRequest(FlatBufferBuilder builder, [Optional] VectorOffset consumedOffset)
		{
			return default(Offset<ConsumeLifeRequest>);
		}

		// Token: 0x06010DFC RID: 69116 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DFC")]
		[Address(RVA = "0x214C19C", Offset = "0x214C19C", VA = "0x214C19C")]
		public static void StartConsumeLifeRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010DFD RID: 69117 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DFD")]
		[Address(RVA = "0x214C110", Offset = "0x214C110", VA = "0x214C110")]
		public static void AddConsumed(FlatBufferBuilder builder, VectorOffset consumedOffset)
		{
		}

		// Token: 0x06010DFE RID: 69118 RVA: 0x00061EA8 File Offset: 0x000600A8
		[Token(Token = "0x6010DFE")]
		[Address(RVA = "0x2140BF4", Offset = "0x2140BF4", VA = "0x2140BF4")]
		public static VectorOffset CreateConsumedVector(FlatBufferBuilder builder, long[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010DFF RID: 69119 RVA: 0x00061EC0 File Offset: 0x000600C0
		[Token(Token = "0x6010DFF")]
		[Address(RVA = "0x214C1B4", Offset = "0x214C1B4", VA = "0x214C1B4")]
		public static VectorOffset CreateConsumedVectorBlock(FlatBufferBuilder builder, long[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010E00 RID: 69120 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E00")]
		[Address(RVA = "0x214C23C", Offset = "0x214C23C", VA = "0x214C23C")]
		public static void StartConsumedVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010E01 RID: 69121 RVA: 0x00061ED8 File Offset: 0x000600D8
		[Token(Token = "0x6010E01")]
		[Address(RVA = "0x214C130", Offset = "0x214C130", VA = "0x214C130")]
		public static Offset<ConsumeLifeRequest> EndConsumeLifeRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ConsumeLifeRequest>);
		}

		// Token: 0x0400E670 RID: 58992
		[Token(Token = "0x400E670")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
