﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002599 RID: 9625
	[Token(Token = "0x2002599")]
	public class DeviceInfo
	{
		// Token: 0x06012D51 RID: 77137 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D51")]
		[Address(RVA = "0x243AA14", Offset = "0x243AA14", VA = "0x243AA14")]
		public DeviceInfo()
		{
		}

		// Token: 0x0400ECEE RID: 60654
		[Token(Token = "0x400ECEE")]
		[FieldOffset(Offset = "0x10")]
		public string city;

		// Token: 0x0400ECEF RID: 60655
		[Token(Token = "0x400ECEF")]
		[FieldOffset(Offset = "0x18")]
		public string state;

		// Token: 0x0400ECF0 RID: 60656
		[Token(Token = "0x400ECF0")]
		[FieldOffset(Offset = "0x20")]
		public string country;

		// Token: 0x0400ECF1 RID: 60657
		[Token(Token = "0x400ECF1")]
		[FieldOffset(Offset = "0x28")]
		public string language;

		// Token: 0x0400ECF2 RID: 60658
		[Token(Token = "0x400ECF2")]
		[FieldOffset(Offset = "0x30")]
		public string platform;

		// Token: 0x0400ECF3 RID: 60659
		[Token(Token = "0x400ECF3")]
		[FieldOffset(Offset = "0x38")]
		public string os_version;

		// Token: 0x0400ECF4 RID: 60660
		[Token(Token = "0x400ECF4")]
		[FieldOffset(Offset = "0x40")]
		public string model_name;

		// Token: 0x0400ECF5 RID: 60661
		[Token(Token = "0x400ECF5")]
		[FieldOffset(Offset = "0x48")]
		public string app_version;
	}
}
