﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002395 RID: 9109
	[Token(Token = "0x2002395")]
	public struct DynamicOfferInfo : IFlatbufferObject
	{
		// Token: 0x17002017 RID: 8215
		// (get) Token: 0x0601106E RID: 69742 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002017")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601106E")]
			[Address(RVA = "0x1F9AE20", Offset = "0x1F9AE20", VA = "0x1F9AE20", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601106F RID: 69743 RVA: 0x00063E88 File Offset: 0x00062088
		[Token(Token = "0x601106F")]
		[Address(RVA = "0x1F9AE28", Offset = "0x1F9AE28", VA = "0x1F9AE28")]
		public static DynamicOfferInfo GetRootAsDynamicOfferInfo(ByteBuffer _bb)
		{
			return default(DynamicOfferInfo);
		}

		// Token: 0x06011070 RID: 69744 RVA: 0x00063EA0 File Offset: 0x000620A0
		[Token(Token = "0x6011070")]
		[Address(RVA = "0x1F9AE34", Offset = "0x1F9AE34", VA = "0x1F9AE34")]
		public static DynamicOfferInfo GetRootAsDynamicOfferInfo(ByteBuffer _bb, DynamicOfferInfo obj)
		{
			return default(DynamicOfferInfo);
		}

		// Token: 0x06011071 RID: 69745 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011071")]
		[Address(RVA = "0x1F9AEAC", Offset = "0x1F9AEAC", VA = "0x1F9AEAC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011072 RID: 69746 RVA: 0x00063EB8 File Offset: 0x000620B8
		[Token(Token = "0x6011072")]
		[Address(RVA = "0x1F9A07C", Offset = "0x1F9A07C", VA = "0x1F9A07C")]
		public DynamicOfferInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DynamicOfferInfo);
		}

		// Token: 0x17002018 RID: 8216
		// (get) Token: 0x06011073 RID: 69747 RVA: 0x00063ED0 File Offset: 0x000620D0
		[Token(Token = "0x17002018")]
		public int Id
		{
			[Token(Token = "0x6011073")]
			[Address(RVA = "0x1F9AEBC", Offset = "0x1F9AEBC", VA = "0x1F9AEBC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002019 RID: 8217
		// (get) Token: 0x06011074 RID: 69748 RVA: 0x00063EE8 File Offset: 0x000620E8
		[Token(Token = "0x17002019")]
		public long RemainingTime
		{
			[Token(Token = "0x6011074")]
			[Address(RVA = "0x1F9AF00", Offset = "0x1F9AF00", VA = "0x1F9AF00")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x1700201A RID: 8218
		// (get) Token: 0x06011075 RID: 69749 RVA: 0x00063F00 File Offset: 0x00062100
		[Token(Token = "0x1700201A")]
		public short ConfigVersion
		{
			[Token(Token = "0x6011075")]
			[Address(RVA = "0x1F9AF48", Offset = "0x1F9AF48", VA = "0x1F9AF48")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700201B RID: 8219
		// (get) Token: 0x06011076 RID: 69750 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700201B")]
		public string Config
		{
			[Token(Token = "0x6011076")]
			[Address(RVA = "0x1F9AF8C", Offset = "0x1F9AF8C", VA = "0x1F9AF8C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011077 RID: 69751 RVA: 0x00063F18 File Offset: 0x00062118
		[Token(Token = "0x6011077")]
		[Address(RVA = "0x1F9AFC8", Offset = "0x1F9AFC8", VA = "0x1F9AFC8")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06011078 RID: 69752 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011078")]
		[Address(RVA = "0x1F9B000", Offset = "0x1F9B000", VA = "0x1F9B000")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x1700201C RID: 8220
		// (get) Token: 0x06011079 RID: 69753 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700201C")]
		public string MetaAssetName
		{
			[Token(Token = "0x6011079")]
			[Address(RVA = "0x1F9B04C", Offset = "0x1F9B04C", VA = "0x1F9B04C")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601107A RID: 69754 RVA: 0x00063F30 File Offset: 0x00062130
		[Token(Token = "0x601107A")]
		[Address(RVA = "0x1F9B088", Offset = "0x1F9B088", VA = "0x1F9B088")]
		public ArraySegment<byte>? GetMetaAssetNameBytes()
		{
			return null;
		}

		// Token: 0x0601107B RID: 69755 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601107B")]
		[Address(RVA = "0x1F9B0C0", Offset = "0x1F9B0C0", VA = "0x1F9B0C0")]
		public byte[] GetMetaAssetNameArray()
		{
			return null;
		}

		// Token: 0x0601107C RID: 69756 RVA: 0x00063F48 File Offset: 0x00062148
		[Token(Token = "0x601107C")]
		[Address(RVA = "0x1F9B10C", Offset = "0x1F9B10C", VA = "0x1F9B10C")]
		public static Offset<DynamicOfferInfo> CreateDynamicOfferInfo(FlatBufferBuilder builder, int id = 0, long remaining_time = 0L, short config_version = 0, [Optional] StringOffset configOffset, [Optional] StringOffset metaAssetNameOffset)
		{
			return default(Offset<DynamicOfferInfo>);
		}

		// Token: 0x0601107D RID: 69757 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601107D")]
		[Address(RVA = "0x1F9B2B0", Offset = "0x1F9B2B0", VA = "0x1F9B2B0")]
		public static void StartDynamicOfferInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601107E RID: 69758 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601107E")]
		[Address(RVA = "0x1F9B204", Offset = "0x1F9B204", VA = "0x1F9B204")]
		public static void AddId(FlatBufferBuilder builder, int id)
		{
		}

		// Token: 0x0601107F RID: 69759 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601107F")]
		[Address(RVA = "0x1F9B1A4", Offset = "0x1F9B1A4", VA = "0x1F9B1A4")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06011080 RID: 69760 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011080")]
		[Address(RVA = "0x1F9B224", Offset = "0x1F9B224", VA = "0x1F9B224")]
		public static void AddConfigVersion(FlatBufferBuilder builder, short configVersion)
		{
		}

		// Token: 0x06011081 RID: 69761 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011081")]
		[Address(RVA = "0x1F9B1E4", Offset = "0x1F9B1E4", VA = "0x1F9B1E4")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06011082 RID: 69762 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011082")]
		[Address(RVA = "0x1F9B1C4", Offset = "0x1F9B1C4", VA = "0x1F9B1C4")]
		public static void AddMetaAssetName(FlatBufferBuilder builder, StringOffset metaAssetNameOffset)
		{
		}

		// Token: 0x06011083 RID: 69763 RVA: 0x00063F60 File Offset: 0x00062160
		[Token(Token = "0x6011083")]
		[Address(RVA = "0x1F9B244", Offset = "0x1F9B244", VA = "0x1F9B244")]
		public static Offset<DynamicOfferInfo> EndDynamicOfferInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DynamicOfferInfo>);
		}

		// Token: 0x0400E6B6 RID: 59062
		[Token(Token = "0x400E6B6")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
