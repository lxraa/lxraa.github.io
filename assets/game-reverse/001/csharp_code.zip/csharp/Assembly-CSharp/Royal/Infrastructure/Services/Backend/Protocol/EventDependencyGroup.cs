﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B4 RID: 9140
	[Token(Token = "0x20023B4")]
	public struct EventDependencyGroup : IFlatbufferObject
	{
		// Token: 0x1700208A RID: 8330
		// (get) Token: 0x06011206 RID: 70150 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700208A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011206")]
			[Address(RVA = "0x1FA0E44", Offset = "0x1FA0E44", VA = "0x1FA0E44", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011207 RID: 70151 RVA: 0x00065370 File Offset: 0x00063570
		[Token(Token = "0x6011207")]
		[Address(RVA = "0x1FA0E4C", Offset = "0x1FA0E4C", VA = "0x1FA0E4C")]
		public static EventDependencyGroup GetRootAsEventDependencyGroup(ByteBuffer _bb)
		{
			return default(EventDependencyGroup);
		}

		// Token: 0x06011208 RID: 70152 RVA: 0x00065388 File Offset: 0x00063588
		[Token(Token = "0x6011208")]
		[Address(RVA = "0x1FA0E58", Offset = "0x1FA0E58", VA = "0x1FA0E58")]
		public static EventDependencyGroup GetRootAsEventDependencyGroup(ByteBuffer _bb, EventDependencyGroup obj)
		{
			return default(EventDependencyGroup);
		}

		// Token: 0x06011209 RID: 70153 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011209")]
		[Address(RVA = "0x1FA0F08", Offset = "0x1FA0F08", VA = "0x1FA0F08", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601120A RID: 70154 RVA: 0x000653A0 File Offset: 0x000635A0
		[Token(Token = "0x601120A")]
		[Address(RVA = "0x1FA0ED0", Offset = "0x1FA0ED0", VA = "0x1FA0ED0")]
		public EventDependencyGroup __assign(int _i, ByteBuffer _bb)
		{
			return default(EventDependencyGroup);
		}

		// Token: 0x0601120B RID: 70155 RVA: 0x000653B8 File Offset: 0x000635B8
		[Token(Token = "0x601120B")]
		[Address(RVA = "0x1FA0F18", Offset = "0x1FA0F18", VA = "0x1FA0F18")]
		public GameEventType EventTypeList(int j)
		{
			return GameEventType.KINGS_CUP;
		}

		// Token: 0x1700208B RID: 8331
		// (get) Token: 0x0601120C RID: 70156 RVA: 0x000653D0 File Offset: 0x000635D0
		[Token(Token = "0x1700208B")]
		public int EventTypeListLength
		{
			[Token(Token = "0x601120C")]
			[Address(RVA = "0x1FA0F78", Offset = "0x1FA0F78", VA = "0x1FA0F78")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601120D RID: 70157 RVA: 0x000653E8 File Offset: 0x000635E8
		[Token(Token = "0x601120D")]
		[Address(RVA = "0x1FA0FAC", Offset = "0x1FA0FAC", VA = "0x1FA0FAC")]
		public ArraySegment<byte>? GetEventTypeListBytes()
		{
			return null;
		}

		// Token: 0x0601120E RID: 70158 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601120E")]
		[Address(RVA = "0x1FA0FE4", Offset = "0x1FA0FE4", VA = "0x1FA0FE4")]
		public GameEventType[] GetEventTypeListArray()
		{
			return null;
		}

		// Token: 0x0601120F RID: 70159 RVA: 0x00065400 File Offset: 0x00063600
		[Token(Token = "0x601120F")]
		[Address(RVA = "0x1FA1030", Offset = "0x1FA1030", VA = "0x1FA1030")]
		public static Offset<EventDependencyGroup> CreateEventDependencyGroup(FlatBufferBuilder builder, [Optional] VectorOffset event_type_listOffset)
		{
			return default(Offset<EventDependencyGroup>);
		}

		// Token: 0x06011210 RID: 70160 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011210")]
		[Address(RVA = "0x1FA1104", Offset = "0x1FA1104", VA = "0x1FA1104")]
		public static void StartEventDependencyGroup(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011211 RID: 70161 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011211")]
		[Address(RVA = "0x1FA1078", Offset = "0x1FA1078", VA = "0x1FA1078")]
		public static void AddEventTypeList(FlatBufferBuilder builder, VectorOffset eventTypeListOffset)
		{
		}

		// Token: 0x06011212 RID: 70162 RVA: 0x00065418 File Offset: 0x00063618
		[Token(Token = "0x6011212")]
		[Address(RVA = "0x1FA111C", Offset = "0x1FA111C", VA = "0x1FA111C")]
		public static VectorOffset CreateEventTypeListVector(FlatBufferBuilder builder, GameEventType[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011213 RID: 70163 RVA: 0x00065430 File Offset: 0x00063630
		[Token(Token = "0x6011213")]
		[Address(RVA = "0x1FA11C4", Offset = "0x1FA11C4", VA = "0x1FA11C4")]
		public static VectorOffset CreateEventTypeListVectorBlock(FlatBufferBuilder builder, GameEventType[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011214 RID: 70164 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011214")]
		[Address(RVA = "0x1FA124C", Offset = "0x1FA124C", VA = "0x1FA124C")]
		public static void StartEventTypeListVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011215 RID: 70165 RVA: 0x00065448 File Offset: 0x00063648
		[Token(Token = "0x6011215")]
		[Address(RVA = "0x1FA1098", Offset = "0x1FA1098", VA = "0x1FA1098")]
		public static Offset<EventDependencyGroup> EndEventDependencyGroup(FlatBufferBuilder builder)
		{
			return default(Offset<EventDependencyGroup>);
		}

		// Token: 0x0400E6EB RID: 59115
		[Token(Token = "0x400E6EB")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
