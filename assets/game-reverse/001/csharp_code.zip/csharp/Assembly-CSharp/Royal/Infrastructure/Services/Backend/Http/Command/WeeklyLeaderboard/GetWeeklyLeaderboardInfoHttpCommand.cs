﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.WeeklyLeaderboard
{
	// Token: 0x02002527 RID: 9511
	[Token(Token = "0x2002527")]
	public class GetWeeklyLeaderboardInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026FE RID: 9982
		// (get) Token: 0x06012995 RID: 76181 RVA: 0x00077A90 File Offset: 0x00075C90
		[Token(Token = "0x170026FE")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012995")]
			[Address(RVA = "0x1CF8FB4", Offset = "0x1CF8FB4", VA = "0x1CF8FB4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026FF RID: 9983
		// (get) Token: 0x06012996 RID: 76182 RVA: 0x00077AA8 File Offset: 0x00075CA8
		[Token(Token = "0x170026FF")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012996")]
			[Address(RVA = "0x1CF8FBC", Offset = "0x1CF8FBC", VA = "0x1CF8FBC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012997 RID: 76183 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012997")]
		[Address(RVA = "0x1CF8FC4", Offset = "0x1CF8FC4", VA = "0x1CF8FC4")]
		public GetWeeklyLeaderboardInfoHttpCommand(int eventId)
		{
		}

		// Token: 0x06012998 RID: 76184 RVA: 0x00077AC0 File Offset: 0x00075CC0
		[Token(Token = "0x6012998")]
		[Address(RVA = "0x1CF9064", Offset = "0x1CF9064", VA = "0x1CF9064", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012999 RID: 76185 RVA: 0x00077AD8 File Offset: 0x00075CD8
		[Token(Token = "0x6012999")]
		[Address(RVA = "0x1CF9124", Offset = "0x1CF9124", VA = "0x1CF9124", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x0601299A RID: 76186 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601299A")]
		[Address(RVA = "0x1CF91C4", Offset = "0x1CF91C4", VA = "0x1CF91C4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x0601299B RID: 76187 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601299B")]
		[Address(RVA = "0x1CF9334", Offset = "0x1CF9334", VA = "0x1CF9334", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB1A RID: 60186
		[Token(Token = "0x400EB1A")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;
	}
}
