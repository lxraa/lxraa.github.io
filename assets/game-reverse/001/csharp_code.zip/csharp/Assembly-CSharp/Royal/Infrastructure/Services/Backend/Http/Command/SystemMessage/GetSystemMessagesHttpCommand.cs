﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SystemMessage
{
	// Token: 0x0200253D RID: 9533
	[Token(Token = "0x200253D")]
	public class GetSystemMessagesHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002731 RID: 10033
		// (get) Token: 0x06012A2A RID: 76330 RVA: 0x000781B0 File Offset: 0x000763B0
		[Token(Token = "0x17002731")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A2A")]
			[Address(RVA = "0x1CFE950", Offset = "0x1CFE950", VA = "0x1CFE950", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002732 RID: 10034
		// (get) Token: 0x06012A2B RID: 76331 RVA: 0x000781C8 File Offset: 0x000763C8
		[Token(Token = "0x17002732")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A2B")]
			[Address(RVA = "0x1CFE958", Offset = "0x1CFE958", VA = "0x1CFE958", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A2C RID: 76332 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A2C")]
		[Address(RVA = "0x1CFE960", Offset = "0x1CFE960", VA = "0x1CFE960")]
		public GetSystemMessagesHttpCommand(string language, int lastSeenMessageId)
		{
		}

		// Token: 0x06012A2D RID: 76333 RVA: 0x000781E0 File Offset: 0x000763E0
		[Token(Token = "0x6012A2D")]
		[Address(RVA = "0x1CFE99C", Offset = "0x1CFE99C", VA = "0x1CFE99C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A2E RID: 76334 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A2E")]
		[Address(RVA = "0x1CFE9E4", Offset = "0x1CFE9E4", VA = "0x1CFE9E4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A2F RID: 76335 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A2F")]
		[Address(RVA = "0x1CFEB10", Offset = "0x1CFEB10", VA = "0x1CFEB10", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB57 RID: 60247
		[Token(Token = "0x400EB57")]
		[FieldOffset(Offset = "0x18")]
		private readonly string language;

		// Token: 0x0400EB58 RID: 60248
		[Token(Token = "0x400EB58")]
		[FieldOffset(Offset = "0x20")]
		private readonly int lastSeenMessageId;
	}
}
