﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002587 RID: 9607
	[Token(Token = "0x2002587")]
	[Serializable]
	public class FileDownloadSettings
	{
		// Token: 0x06012C55 RID: 76885 RVA: 0x000797E8 File Offset: 0x000779E8
		[Token(Token = "0x6012C55")]
		[Address(RVA = "0x1EDC33C", Offset = "0x1EDC33C", VA = "0x1EDC33C")]
		public bool CheckScene(SceneType currentScene)
		{
			return default(bool);
		}

		// Token: 0x06012C56 RID: 76886 RVA: 0x00079800 File Offset: 0x00077A00
		[Token(Token = "0x6012C56")]
		[Address(RVA = "0x1EDC694", Offset = "0x1EDC694", VA = "0x1EDC694")]
		public bool ShouldAddToQueue(int currentLevel)
		{
			return default(bool);
		}

		// Token: 0x06012C57 RID: 76887 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C57")]
		[Address(RVA = "0x1ED6FE0", Offset = "0x1ED6FE0", VA = "0x1ED6FE0")]
		public FileDownloadSettings()
		{
		}

		// Token: 0x0400EC59 RID: 60505
		[Token(Token = "0x400EC59")]
		[FieldOffset(Offset = "0x10")]
		public SceneType scene;

		// Token: 0x0400EC5A RID: 60506
		[Token(Token = "0x400EC5A")]
		[FieldOffset(Offset = "0x14")]
		public DownloadSize size;

		// Token: 0x0400EC5B RID: 60507
		[Token(Token = "0x400EC5B")]
		[FieldOffset(Offset = "0x18")]
		public int minLevel;

		// Token: 0x0400EC5C RID: 60508
		[Token(Token = "0x400EC5C")]
		[FieldOffset(Offset = "0x1C")]
		public DownloadPriority priority;

		// Token: 0x0400EC5D RID: 60509
		[Token(Token = "0x400EC5D")]
		[FieldOffset(Offset = "0x20")]
		public DownloadScheduler scheduler;

		// Token: 0x0400EC5E RID: 60510
		[Token(Token = "0x400EC5E")]
		[FieldOffset(Offset = "0x25")]
		public bool downloadDisabled;
	}
}
