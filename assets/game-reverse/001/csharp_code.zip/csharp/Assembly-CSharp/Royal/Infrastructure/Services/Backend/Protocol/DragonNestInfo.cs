﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002386 RID: 9094
	[Token(Token = "0x2002386")]
	public struct DragonNestInfo : IFlatbufferObject
	{
		// Token: 0x17001FE2 RID: 8162
		// (get) Token: 0x06010F9C RID: 69532 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FE2")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F9C")]
			[Address(RVA = "0x1F97A54", Offset = "0x1F97A54", VA = "0x1F97A54", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F9D RID: 69533 RVA: 0x00063390 File Offset: 0x00061590
		[Token(Token = "0x6010F9D")]
		[Address(RVA = "0x1F97A5C", Offset = "0x1F97A5C", VA = "0x1F97A5C")]
		public static DragonNestInfo GetRootAsDragonNestInfo(ByteBuffer _bb)
		{
			return default(DragonNestInfo);
		}

		// Token: 0x06010F9E RID: 69534 RVA: 0x000633A8 File Offset: 0x000615A8
		[Token(Token = "0x6010F9E")]
		[Address(RVA = "0x1F97A68", Offset = "0x1F97A68", VA = "0x1F97A68")]
		public static DragonNestInfo GetRootAsDragonNestInfo(ByteBuffer _bb, DragonNestInfo obj)
		{
			return default(DragonNestInfo);
		}

		// Token: 0x06010F9F RID: 69535 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F9F")]
		[Address(RVA = "0x1F97B18", Offset = "0x1F97B18", VA = "0x1F97B18", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010FA0 RID: 69536 RVA: 0x000633C0 File Offset: 0x000615C0
		[Token(Token = "0x6010FA0")]
		[Address(RVA = "0x1F97AE0", Offset = "0x1F97AE0", VA = "0x1F97AE0")]
		public DragonNestInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestInfo);
		}

		// Token: 0x17001FE3 RID: 8163
		// (get) Token: 0x06010FA1 RID: 69537 RVA: 0x000633D8 File Offset: 0x000615D8
		[Token(Token = "0x17001FE3")]
		public int EventId
		{
			[Token(Token = "0x6010FA1")]
			[Address(RVA = "0x1F97B28", Offset = "0x1F97B28", VA = "0x1F97B28")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FE4 RID: 8164
		// (get) Token: 0x06010FA2 RID: 69538 RVA: 0x000633F0 File Offset: 0x000615F0
		[Token(Token = "0x17001FE4")]
		public long RemainingTime
		{
			[Token(Token = "0x6010FA2")]
			[Address(RVA = "0x1F97B6C", Offset = "0x1F97B6C", VA = "0x1F97B6C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FE5 RID: 8165
		// (get) Token: 0x06010FA3 RID: 69539 RVA: 0x00063408 File Offset: 0x00061608
		[Token(Token = "0x17001FE5")]
		public int ConfigVersion
		{
			[Token(Token = "0x6010FA3")]
			[Address(RVA = "0x1F97BB4", Offset = "0x1F97BB4", VA = "0x1F97BB4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FE6 RID: 8166
		// (get) Token: 0x06010FA4 RID: 69540 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FE6")]
		public string Config
		{
			[Token(Token = "0x6010FA4")]
			[Address(RVA = "0x1F97BF8", Offset = "0x1F97BF8", VA = "0x1F97BF8")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FA5 RID: 69541 RVA: 0x00063420 File Offset: 0x00061620
		[Token(Token = "0x6010FA5")]
		[Address(RVA = "0x1F97C34", Offset = "0x1F97C34", VA = "0x1F97C34")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06010FA6 RID: 69542 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010FA6")]
		[Address(RVA = "0x1F97C6C", Offset = "0x1F97C6C", VA = "0x1F97C6C")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x06010FA7 RID: 69543 RVA: 0x00063438 File Offset: 0x00061638
		[Token(Token = "0x6010FA7")]
		[Address(RVA = "0x1F97CB8", Offset = "0x1F97CB8", VA = "0x1F97CB8")]
		public static Offset<DragonNestInfo> CreateDragonNestInfo(FlatBufferBuilder builder, int event_id = 0, long remaining_time = 0L, int config_version = 0, [Optional] StringOffset configOffset)
		{
			return default(Offset<DragonNestInfo>);
		}

		// Token: 0x06010FA8 RID: 69544 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FA8")]
		[Address(RVA = "0x1F97E24", Offset = "0x1F97E24", VA = "0x1F97E24")]
		public static void StartDragonNestInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010FA9 RID: 69545 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FA9")]
		[Address(RVA = "0x1F97D98", Offset = "0x1F97D98", VA = "0x1F97D98")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x06010FAA RID: 69546 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FAA")]
		[Address(RVA = "0x1F97D38", Offset = "0x1F97D38", VA = "0x1F97D38")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010FAB RID: 69547 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FAB")]
		[Address(RVA = "0x1F97D78", Offset = "0x1F97D78", VA = "0x1F97D78")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06010FAC RID: 69548 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FAC")]
		[Address(RVA = "0x1F97D58", Offset = "0x1F97D58", VA = "0x1F97D58")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06010FAD RID: 69549 RVA: 0x00063450 File Offset: 0x00061650
		[Token(Token = "0x6010FAD")]
		[Address(RVA = "0x1F97DB8", Offset = "0x1F97DB8", VA = "0x1F97DB8")]
		public static Offset<DragonNestInfo> EndDragonNestInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestInfo>);
		}

		// Token: 0x0400E69F RID: 59039
		[Token(Token = "0x400E69F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
