﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D9 RID: 9177
	[Token(Token = "0x20023D9")]
	public struct GetGoldenOffersInfoResponse : IFlatbufferObject
	{
		// Token: 0x17002101 RID: 8449
		// (get) Token: 0x060113FC RID: 70652 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002101")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60113FC")]
			[Address(RVA = "0x1CB1054", Offset = "0x1CB1054", VA = "0x1CB1054", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060113FD RID: 70653 RVA: 0x00066E40 File Offset: 0x00065040
		[Token(Token = "0x60113FD")]
		[Address(RVA = "0x1CB105C", Offset = "0x1CB105C", VA = "0x1CB105C")]
		public static GetGoldenOffersInfoResponse GetRootAsGetGoldenOffersInfoResponse(ByteBuffer _bb)
		{
			return default(GetGoldenOffersInfoResponse);
		}

		// Token: 0x060113FE RID: 70654 RVA: 0x00066E58 File Offset: 0x00065058
		[Token(Token = "0x60113FE")]
		[Address(RVA = "0x1CB1068", Offset = "0x1CB1068", VA = "0x1CB1068")]
		public static GetGoldenOffersInfoResponse GetRootAsGetGoldenOffersInfoResponse(ByteBuffer _bb, GetGoldenOffersInfoResponse obj)
		{
			return default(GetGoldenOffersInfoResponse);
		}

		// Token: 0x060113FF RID: 70655 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113FF")]
		[Address(RVA = "0x1CB1118", Offset = "0x1CB1118", VA = "0x1CB1118", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011400 RID: 70656 RVA: 0x00066E70 File Offset: 0x00065070
		[Token(Token = "0x6011400")]
		[Address(RVA = "0x1CB10E0", Offset = "0x1CB10E0", VA = "0x1CB10E0")]
		public GetGoldenOffersInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetGoldenOffersInfoResponse);
		}

		// Token: 0x17002102 RID: 8450
		// (get) Token: 0x06011401 RID: 70657 RVA: 0x00066E88 File Offset: 0x00065088
		[Token(Token = "0x17002102")]
		public GoldenOffersInfo? GoldenOffersInfo
		{
			[Token(Token = "0x6011401")]
			[Address(RVA = "0x1CB1128", Offset = "0x1CB1128", VA = "0x1CB1128")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011402 RID: 70658 RVA: 0x00066EA0 File Offset: 0x000650A0
		[Token(Token = "0x6011402")]
		[Address(RVA = "0x1CB11E8", Offset = "0x1CB11E8", VA = "0x1CB11E8")]
		public static Offset<GetGoldenOffersInfoResponse> CreateGetGoldenOffersInfoResponse(FlatBufferBuilder builder, [Optional] Offset<GoldenOffersInfo> golden_offers_infoOffset)
		{
			return default(Offset<GetGoldenOffersInfoResponse>);
		}

		// Token: 0x06011403 RID: 70659 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011403")]
		[Address(RVA = "0x1CB12BC", Offset = "0x1CB12BC", VA = "0x1CB12BC")]
		public static void StartGetGoldenOffersInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011404 RID: 70660 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011404")]
		[Address(RVA = "0x1CB1230", Offset = "0x1CB1230", VA = "0x1CB1230")]
		public static void AddGoldenOffersInfo(FlatBufferBuilder builder, Offset<GoldenOffersInfo> goldenOffersInfoOffset)
		{
		}

		// Token: 0x06011405 RID: 70661 RVA: 0x00066EB8 File Offset: 0x000650B8
		[Token(Token = "0x6011405")]
		[Address(RVA = "0x1CB1250", Offset = "0x1CB1250", VA = "0x1CB1250")]
		public static Offset<GetGoldenOffersInfoResponse> EndGetGoldenOffersInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetGoldenOffersInfoResponse>);
		}

		// Token: 0x0400E749 RID: 59209
		[Token(Token = "0x400E749")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
