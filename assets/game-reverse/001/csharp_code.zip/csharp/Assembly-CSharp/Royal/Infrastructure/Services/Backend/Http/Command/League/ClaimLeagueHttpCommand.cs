﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.League
{
	// Token: 0x0200255E RID: 9566
	[Token(Token = "0x200255E")]
	public class ClaimLeagueHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002781 RID: 10113
		// (get) Token: 0x06012B1B RID: 76571 RVA: 0x00078CC0 File Offset: 0x00076EC0
		[Token(Token = "0x17002781")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B1B")]
			[Address(RVA = "0x1ECF8CC", Offset = "0x1ECF8CC", VA = "0x1ECF8CC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002782 RID: 10114
		// (get) Token: 0x06012B1C RID: 76572 RVA: 0x00078CD8 File Offset: 0x00076ED8
		[Token(Token = "0x17002782")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B1C")]
			[Address(RVA = "0x1ECF8D4", Offset = "0x1ECF8D4", VA = "0x1ECF8D4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002783 RID: 10115
		// (get) Token: 0x06012B1D RID: 76573 RVA: 0x00078CF0 File Offset: 0x00076EF0
		// (set) Token: 0x06012B1E RID: 76574 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002783")]
		public ClaimLeagueRewardResponse Response
		{
			[Token(Token = "0x6012B1D")]
			[Address(RVA = "0x1ECF8DC", Offset = "0x1ECF8DC", VA = "0x1ECF8DC")]
			get
			{
				return default(ClaimLeagueRewardResponse);
			}
			[Token(Token = "0x6012B1E")]
			[Address(RVA = "0x1ECF8E8", Offset = "0x1ECF8E8", VA = "0x1ECF8E8")]
			set
			{
			}
		}

		// Token: 0x06012B1F RID: 76575 RVA: 0x00078D08 File Offset: 0x00076F08
		[Token(Token = "0x6012B1F")]
		[Address(RVA = "0x1ECF8F8", Offset = "0x1ECF8F8", VA = "0x1ECF8F8", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B20 RID: 76576 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B20")]
		[Address(RVA = "0x1ECF914", Offset = "0x1ECF914", VA = "0x1ECF914", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B21 RID: 76577 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B21")]
		[Address(RVA = "0x1ECFB28", Offset = "0x1ECFB28", VA = "0x1ECFB28", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012B22 RID: 76578 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B22")]
		[Address(RVA = "0x1ECFB2C", Offset = "0x1ECFB2C", VA = "0x1ECFB2C")]
		public ClaimLeagueHttpCommand()
		{
		}

		// Token: 0x0400EBB9 RID: 60345
		[Token(Token = "0x400EBB9")]
		[FieldOffset(Offset = "0x18")]
		private ClaimLeagueRewardResponse <Response>k__BackingField;
	}
}
