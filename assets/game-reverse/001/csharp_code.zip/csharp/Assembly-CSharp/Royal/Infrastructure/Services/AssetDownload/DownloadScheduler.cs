﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Http;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Scenes.Start.Context.Units.FeatureBundle;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x0200258A RID: 9610
	[Token(Token = "0x200258A")]
	public struct DownloadScheduler
	{
		// Token: 0x170027D0 RID: 10192
		// (get) Token: 0x06012C58 RID: 76888 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170027D0")]
		private static TimeHelper TimeHelper
		{
			[Token(Token = "0x6012C58")]
			[Address(RVA = "0x1EDC6B4", Offset = "0x1EDC6B4", VA = "0x1EDC6B4")]
			get
			{
				return null;
			}
		}

		// Token: 0x170027D1 RID: 10193
		// (get) Token: 0x06012C59 RID: 76889 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170027D1")]
		private static FeatureBundleManager FeatureBundleManager
		{
			[Token(Token = "0x6012C59")]
			[Address(RVA = "0x1EDC768", Offset = "0x1EDC768", VA = "0x1EDC768")]
			get
			{
				return null;
			}
		}

		// Token: 0x06012C5A RID: 76890 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C5A")]
		[Address(RVA = "0x1EDC818", Offset = "0x1EDC818", VA = "0x1EDC818")]
		public DownloadScheduler(byte startingMonth, byte startingDay, byte endingMonth, byte endingDay, bool useStartingDayOffset = false)
		{
		}

		// Token: 0x06012C5B RID: 76891 RVA: 0x00079818 File Offset: 0x00077A18
		[Token(Token = "0x6012C5B")]
		[Address(RVA = "0x1EDC834", Offset = "0x1EDC834", VA = "0x1EDC834")]
		public bool IsInSchedule()
		{
			return default(bool);
		}

		// Token: 0x06012C5C RID: 76892 RVA: 0x00079830 File Offset: 0x00077A30
		[Token(Token = "0x6012C5C")]
		[Address(RVA = "0x1EDCA10", Offset = "0x1EDCA10", VA = "0x1EDCA10")]
		private int GetBundleDownloadStartingDayOffset()
		{
			return 0;
		}

		// Token: 0x06012C5D RID: 76893 RVA: 0x00079848 File Offset: 0x00077A48
		[Token(Token = "0x6012C5D")]
		[Address(RVA = "0x1EDCA30", Offset = "0x1EDCA30", VA = "0x1EDCA30")]
		public static DownloadScheduler GetDownloadScheduler(Theme bundleTheme)
		{
			return default(DownloadScheduler);
		}

		// Token: 0x06012C5E RID: 76894 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C5E")]
		[Address(RVA = "0x1EDCA58", Offset = "0x1EDCA58", VA = "0x1EDCA58", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x0400EC6A RID: 60522
		[Token(Token = "0x400EC6A")]
		[FieldOffset(Offset = "0x0")]
		private readonly byte startingMonth;

		// Token: 0x0400EC6B RID: 60523
		[Token(Token = "0x400EC6B")]
		[FieldOffset(Offset = "0x1")]
		private readonly byte startingDay;

		// Token: 0x0400EC6C RID: 60524
		[Token(Token = "0x400EC6C")]
		[FieldOffset(Offset = "0x2")]
		private readonly byte endingMonth;

		// Token: 0x0400EC6D RID: 60525
		[Token(Token = "0x400EC6D")]
		[FieldOffset(Offset = "0x3")]
		private readonly byte endingDay;

		// Token: 0x0400EC6E RID: 60526
		[Token(Token = "0x400EC6E")]
		[FieldOffset(Offset = "0x4")]
		private readonly bool useStartingDayOffset;

		// Token: 0x0400EC6F RID: 60527
		[Token(Token = "0x400EC6F")]
		[FieldOffset(Offset = "0x0")]
		private static TimeHelper TimeHelperInstance;

		// Token: 0x0400EC70 RID: 60528
		[Token(Token = "0x400EC70")]
		[FieldOffset(Offset = "0x8")]
		private static FeatureBundleManager FeatureBundleManagerInstance;
	}
}
