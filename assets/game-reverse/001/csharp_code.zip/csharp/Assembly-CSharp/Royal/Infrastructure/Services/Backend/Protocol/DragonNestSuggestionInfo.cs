﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200238D RID: 9101
	[Token(Token = "0x200238D")]
	public struct DragonNestSuggestionInfo : IFlatbufferObject
	{
		// Token: 0x17001FFA RID: 8186
		// (get) Token: 0x06010FF8 RID: 69624 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FFA")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010FF8")]
			[Address(RVA = "0x1F98F64", Offset = "0x1F98F64", VA = "0x1F98F64", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FF9 RID: 69625 RVA: 0x00063870 File Offset: 0x00061A70
		[Token(Token = "0x6010FF9")]
		[Address(RVA = "0x1F98F6C", Offset = "0x1F98F6C", VA = "0x1F98F6C")]
		public static DragonNestSuggestionInfo GetRootAsDragonNestSuggestionInfo(ByteBuffer _bb)
		{
			return default(DragonNestSuggestionInfo);
		}

		// Token: 0x06010FFA RID: 69626 RVA: 0x00063888 File Offset: 0x00061A88
		[Token(Token = "0x6010FFA")]
		[Address(RVA = "0x1F98F78", Offset = "0x1F98F78", VA = "0x1F98F78")]
		public static DragonNestSuggestionInfo GetRootAsDragonNestSuggestionInfo(ByteBuffer _bb, DragonNestSuggestionInfo obj)
		{
			return default(DragonNestSuggestionInfo);
		}

		// Token: 0x06010FFB RID: 69627 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FFB")]
		[Address(RVA = "0x1F99028", Offset = "0x1F99028", VA = "0x1F99028", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010FFC RID: 69628 RVA: 0x000638A0 File Offset: 0x00061AA0
		[Token(Token = "0x6010FFC")]
		[Address(RVA = "0x1F98FF0", Offset = "0x1F98FF0", VA = "0x1F98FF0")]
		public DragonNestSuggestionInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestSuggestionInfo);
		}

		// Token: 0x17001FFB RID: 8187
		// (get) Token: 0x06010FFD RID: 69629 RVA: 0x000638B8 File Offset: 0x00061AB8
		[Token(Token = "0x17001FFB")]
		public DragonNestUser? ProfileData
		{
			[Token(Token = "0x6010FFD")]
			[Address(RVA = "0x1F99038", Offset = "0x1F99038", VA = "0x1F99038")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FFC RID: 8188
		// (get) Token: 0x06010FFE RID: 69630 RVA: 0x000638D0 File Offset: 0x00061AD0
		[Token(Token = "0x17001FFC")]
		public int MutualFriendCount
		{
			[Token(Token = "0x6010FFE")]
			[Address(RVA = "0x1F990F0", Offset = "0x1F990F0", VA = "0x1F990F0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010FFF RID: 69631 RVA: 0x000638E8 File Offset: 0x00061AE8
		[Token(Token = "0x6010FFF")]
		[Address(RVA = "0x1F99134", Offset = "0x1F99134", VA = "0x1F99134")]
		public static Offset<DragonNestSuggestionInfo> CreateDragonNestSuggestionInfo(FlatBufferBuilder builder, [Optional] Offset<DragonNestUser> profile_dataOffset, int mutual_friend_count = 0)
		{
			return default(Offset<DragonNestSuggestionInfo>);
		}

		// Token: 0x06011000 RID: 69632 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011000")]
		[Address(RVA = "0x1F99238", Offset = "0x1F99238", VA = "0x1F99238")]
		public static void StartDragonNestSuggestionInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011001 RID: 69633 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011001")]
		[Address(RVA = "0x1F991AC", Offset = "0x1F991AC", VA = "0x1F991AC")]
		public static void AddProfileData(FlatBufferBuilder builder, Offset<DragonNestUser> profileDataOffset)
		{
		}

		// Token: 0x06011002 RID: 69634 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011002")]
		[Address(RVA = "0x1F9918C", Offset = "0x1F9918C", VA = "0x1F9918C")]
		public static void AddMutualFriendCount(FlatBufferBuilder builder, int mutualFriendCount)
		{
		}

		// Token: 0x06011003 RID: 69635 RVA: 0x00063900 File Offset: 0x00061B00
		[Token(Token = "0x6011003")]
		[Address(RVA = "0x1F991CC", Offset = "0x1F991CC", VA = "0x1F991CC")]
		public static Offset<DragonNestSuggestionInfo> EndDragonNestSuggestionInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestSuggestionInfo>);
		}

		// Token: 0x0400E6A6 RID: 59046
		[Token(Token = "0x400E6A6")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
