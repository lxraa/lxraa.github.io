﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002355 RID: 9045
	[Token(Token = "0x2002355")]
	public enum ChatMessageType : sbyte
	{
		// Token: 0x0400E651 RID: 58961
		[Token(Token = "0x400E651")]
		TextMessage,
		// Token: 0x0400E652 RID: 58962
		[Token(Token = "0x400E652")]
		JoinedTeam,
		// Token: 0x0400E653 RID: 58963
		[Token(Token = "0x400E653")]
		LeftTeam,
		// Token: 0x0400E654 RID: 58964
		[Token(Token = "0x400E654")]
		JoinRequest,
		// Token: 0x0400E655 RID: 58965
		[Token(Token = "0x400E655")]
		LeaderChange,
		// Token: 0x0400E656 RID: 58966
		[Token(Token = "0x400E656")]
		ColeaderMake,
		// Token: 0x0400E657 RID: 58967
		[Token(Token = "0x400E657")]
		ColeaderRemove,
		// Token: 0x0400E658 RID: 58968
		[Token(Token = "0x400E658")]
		JoinRequestRejected,
		// Token: 0x0400E659 RID: 58969
		[Token(Token = "0x400E659")]
		UpdateProfile,
		// Token: 0x0400E65A RID: 58970
		[Token(Token = "0x400E65A")]
		ProfanityWarn,
		// Token: 0x0400E65B RID: 58971
		[Token(Token = "0x400E65B")]
		ProfanityBan
	}
}
