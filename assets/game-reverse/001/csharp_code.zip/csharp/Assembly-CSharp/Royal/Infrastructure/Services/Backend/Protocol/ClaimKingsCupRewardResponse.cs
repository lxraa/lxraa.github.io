﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200235B RID: 9051
	[Token(Token = "0x200235B")]
	public struct ClaimKingsCupRewardResponse : IFlatbufferObject
	{
		// Token: 0x17001F2A RID: 7978
		// (get) Token: 0x06010D02 RID: 68866 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F2A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D02")]
			[Address(RVA = "0x2148768", Offset = "0x2148768", VA = "0x2148768", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D03 RID: 68867 RVA: 0x000611A0 File Offset: 0x0005F3A0
		[Token(Token = "0x6010D03")]
		[Address(RVA = "0x2148770", Offset = "0x2148770", VA = "0x2148770")]
		public static ClaimKingsCupRewardResponse GetRootAsClaimKingsCupRewardResponse(ByteBuffer _bb)
		{
			return default(ClaimKingsCupRewardResponse);
		}

		// Token: 0x06010D04 RID: 68868 RVA: 0x000611B8 File Offset: 0x0005F3B8
		[Token(Token = "0x6010D04")]
		[Address(RVA = "0x214877C", Offset = "0x214877C", VA = "0x214877C")]
		public static ClaimKingsCupRewardResponse GetRootAsClaimKingsCupRewardResponse(ByteBuffer _bb, ClaimKingsCupRewardResponse obj)
		{
			return default(ClaimKingsCupRewardResponse);
		}

		// Token: 0x06010D05 RID: 68869 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D05")]
		[Address(RVA = "0x214882C", Offset = "0x214882C", VA = "0x214882C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D06 RID: 68870 RVA: 0x000611D0 File Offset: 0x0005F3D0
		[Token(Token = "0x6010D06")]
		[Address(RVA = "0x21487F4", Offset = "0x21487F4", VA = "0x21487F4")]
		public ClaimKingsCupRewardResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimKingsCupRewardResponse);
		}

		// Token: 0x17001F2B RID: 7979
		// (get) Token: 0x06010D07 RID: 68871 RVA: 0x000611E8 File Offset: 0x0005F3E8
		[Token(Token = "0x17001F2B")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010D07")]
			[Address(RVA = "0x214883C", Offset = "0x214883C", VA = "0x214883C")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001F2C RID: 7980
		// (get) Token: 0x06010D08 RID: 68872 RVA: 0x00061200 File Offset: 0x0005F400
		[Token(Token = "0x17001F2C")]
		public UserProgress? DeprecatedUserProgress
		{
			[Token(Token = "0x6010D08")]
			[Address(RVA = "0x2148880", Offset = "0x2148880", VA = "0x2148880")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F2D RID: 7981
		// (get) Token: 0x06010D09 RID: 68873 RVA: 0x00061218 File Offset: 0x0005F418
		[Token(Token = "0x17001F2D")]
		public int Rank
		{
			[Token(Token = "0x6010D09")]
			[Address(RVA = "0x2148940", Offset = "0x2148940", VA = "0x2148940")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F2E RID: 7982
		// (get) Token: 0x06010D0A RID: 68874 RVA: 0x00061230 File Offset: 0x0005F430
		[Token(Token = "0x17001F2E")]
		public long RemainingTime
		{
			[Token(Token = "0x6010D0A")]
			[Address(RVA = "0x2148984", Offset = "0x2148984", VA = "0x2148984")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010D0B RID: 68875 RVA: 0x00061248 File Offset: 0x0005F448
		[Token(Token = "0x6010D0B")]
		[Address(RVA = "0x21489CC", Offset = "0x21489CC", VA = "0x21489CC")]
		public static Offset<ClaimKingsCupRewardResponse> CreateClaimKingsCupRewardResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, [Optional] Offset<UserProgress> deprecated_user_progressOffset, int rank = 0, long remaining_time = 0L)
		{
			return default(Offset<ClaimKingsCupRewardResponse>);
		}

		// Token: 0x06010D0C RID: 68876 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D0C")]
		[Address(RVA = "0x2148B38", Offset = "0x2148B38", VA = "0x2148B38")]
		public static void StartClaimKingsCupRewardResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D0D RID: 68877 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D0D")]
		[Address(RVA = "0x2148AAC", Offset = "0x2148AAC", VA = "0x2148AAC")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010D0E RID: 68878 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D0E")]
		[Address(RVA = "0x2148A8C", Offset = "0x2148A8C", VA = "0x2148A8C")]
		public static void AddDeprecatedUserProgress(FlatBufferBuilder builder, Offset<UserProgress> deprecatedUserProgressOffset)
		{
		}

		// Token: 0x06010D0F RID: 68879 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D0F")]
		[Address(RVA = "0x2148A6C", Offset = "0x2148A6C", VA = "0x2148A6C")]
		public static void AddRank(FlatBufferBuilder builder, int rank)
		{
		}

		// Token: 0x06010D10 RID: 68880 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D10")]
		[Address(RVA = "0x2148A4C", Offset = "0x2148A4C", VA = "0x2148A4C")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010D11 RID: 68881 RVA: 0x00061260 File Offset: 0x0005F460
		[Token(Token = "0x6010D11")]
		[Address(RVA = "0x2148ACC", Offset = "0x2148ACC", VA = "0x2148ACC")]
		public static Offset<ClaimKingsCupRewardResponse> EndClaimKingsCupRewardResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimKingsCupRewardResponse>);
		}

		// Token: 0x0400E661 RID: 58977
		[Token(Token = "0x400E661")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
