﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A6 RID: 9126
	[Token(Token = "0x20023A6")]
	public enum EnterPropellerRushFailReason : sbyte
	{
		// Token: 0x0400E6D5 RID: 59093
		[Token(Token = "0x400E6D5")]
		None,
		// Token: 0x0400E6D6 RID: 59094
		[Token(Token = "0x400E6D6")]
		AlreadyEntered,
		// Token: 0x0400E6D7 RID: 59095
		[Token(Token = "0x400E6D7")]
		EventNotActive,
		// Token: 0x0400E6D8 RID: 59096
		[Token(Token = "0x400E6D8")]
		IsAboutToEnd
	}
}
