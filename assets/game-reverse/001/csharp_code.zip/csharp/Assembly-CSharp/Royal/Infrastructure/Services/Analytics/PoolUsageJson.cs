﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x0200259D RID: 9629
	[Token(Token = "0x200259D")]
	public class PoolUsageJson
	{
		// Token: 0x06012D55 RID: 77141 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D55")]
		[Address(RVA = "0x243AA34", Offset = "0x243AA34", VA = "0x243AA34")]
		public PoolUsageJson()
		{
		}

		// Token: 0x0400ED22 RID: 60706
		[Token(Token = "0x400ED22")]
		[FieldOffset(Offset = "0x10")]
		public string n;

		// Token: 0x0400ED23 RID: 60707
		[Token(Token = "0x400ED23")]
		[FieldOffset(Offset = "0x18")]
		public int i;

		// Token: 0x0400ED24 RID: 60708
		[Token(Token = "0x400ED24")]
		[FieldOffset(Offset = "0x1C")]
		public int o;

		// Token: 0x0400ED25 RID: 60709
		[Token(Token = "0x400ED25")]
		[FieldOffset(Offset = "0x20")]
		public int m;
	}
}
