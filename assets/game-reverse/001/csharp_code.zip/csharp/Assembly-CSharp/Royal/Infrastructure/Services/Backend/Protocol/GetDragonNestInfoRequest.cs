﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023CC RID: 9164
	[Token(Token = "0x20023CC")]
	public struct GetDragonNestInfoRequest : IFlatbufferObject
	{
		// Token: 0x170020DA RID: 8410
		// (get) Token: 0x06011335 RID: 70453 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020DA")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011335")]
			[Address(RVA = "0x1CAD8C0", Offset = "0x1CAD8C0", VA = "0x1CAD8C0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011336 RID: 70454 RVA: 0x00066318 File Offset: 0x00064518
		[Token(Token = "0x6011336")]
		[Address(RVA = "0x1CAD8C8", Offset = "0x1CAD8C8", VA = "0x1CAD8C8")]
		public static GetDragonNestInfoRequest GetRootAsGetDragonNestInfoRequest(ByteBuffer _bb)
		{
			return default(GetDragonNestInfoRequest);
		}

		// Token: 0x06011337 RID: 70455 RVA: 0x00066330 File Offset: 0x00064530
		[Token(Token = "0x6011337")]
		[Address(RVA = "0x1CAD8D4", Offset = "0x1CAD8D4", VA = "0x1CAD8D4")]
		public static GetDragonNestInfoRequest GetRootAsGetDragonNestInfoRequest(ByteBuffer _bb, GetDragonNestInfoRequest obj)
		{
			return default(GetDragonNestInfoRequest);
		}

		// Token: 0x06011338 RID: 70456 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011338")]
		[Address(RVA = "0x1CAD984", Offset = "0x1CAD984", VA = "0x1CAD984", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011339 RID: 70457 RVA: 0x00066348 File Offset: 0x00064548
		[Token(Token = "0x6011339")]
		[Address(RVA = "0x1CAD94C", Offset = "0x1CAD94C", VA = "0x1CAD94C")]
		public GetDragonNestInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetDragonNestInfoRequest);
		}

		// Token: 0x170020DB RID: 8411
		// (get) Token: 0x0601133A RID: 70458 RVA: 0x00066360 File Offset: 0x00064560
		[Token(Token = "0x170020DB")]
		public int EventId
		{
			[Token(Token = "0x601133A")]
			[Address(RVA = "0x1CAD994", Offset = "0x1CAD994", VA = "0x1CAD994")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020DC RID: 8412
		// (get) Token: 0x0601133B RID: 70459 RVA: 0x00066378 File Offset: 0x00064578
		[Token(Token = "0x170020DC")]
		public int ConfigVersion
		{
			[Token(Token = "0x601133B")]
			[Address(RVA = "0x1CAD9D8", Offset = "0x1CAD9D8", VA = "0x1CAD9D8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601133C RID: 70460 RVA: 0x00066390 File Offset: 0x00064590
		[Token(Token = "0x601133C")]
		[Address(RVA = "0x1CADA1C", Offset = "0x1CADA1C", VA = "0x1CADA1C")]
		public static Offset<GetDragonNestInfoRequest> CreateGetDragonNestInfoRequest(FlatBufferBuilder builder, int event_id = 0, int config_version = 0)
		{
			return default(Offset<GetDragonNestInfoRequest>);
		}

		// Token: 0x0601133D RID: 70461 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601133D")]
		[Address(RVA = "0x1CADB20", Offset = "0x1CADB20", VA = "0x1CADB20")]
		public static void StartGetDragonNestInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601133E RID: 70462 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601133E")]
		[Address(RVA = "0x1CADA94", Offset = "0x1CADA94", VA = "0x1CADA94")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x0601133F RID: 70463 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601133F")]
		[Address(RVA = "0x1CADA74", Offset = "0x1CADA74", VA = "0x1CADA74")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06011340 RID: 70464 RVA: 0x000663A8 File Offset: 0x000645A8
		[Token(Token = "0x6011340")]
		[Address(RVA = "0x1CADAB4", Offset = "0x1CADAB4", VA = "0x1CADAB4")]
		public static Offset<GetDragonNestInfoRequest> EndGetDragonNestInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetDragonNestInfoRequest>);
		}

		// Token: 0x0400E73C RID: 59196
		[Token(Token = "0x400E73C")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
