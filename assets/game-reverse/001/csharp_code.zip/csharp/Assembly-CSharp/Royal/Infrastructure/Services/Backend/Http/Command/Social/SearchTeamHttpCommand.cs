﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Social
{
	// Token: 0x02002547 RID: 9543
	[Token(Token = "0x2002547")]
	public class SearchTeamHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700274B RID: 10059
		// (get) Token: 0x06012A7C RID: 76412 RVA: 0x00078510 File Offset: 0x00076710
		[Token(Token = "0x1700274B")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A7C")]
			[Address(RVA = "0x1ECB5CC", Offset = "0x1ECB5CC", VA = "0x1ECB5CC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700274C RID: 10060
		// (get) Token: 0x06012A7D RID: 76413 RVA: 0x00078528 File Offset: 0x00076728
		[Token(Token = "0x1700274C")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A7D")]
			[Address(RVA = "0x1ECB5D4", Offset = "0x1ECB5D4", VA = "0x1ECB5D4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700274D RID: 10061
		// (get) Token: 0x06012A7E RID: 76414 RVA: 0x00078540 File Offset: 0x00076740
		// (set) Token: 0x06012A7F RID: 76415 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700274D")]
		public SearchTeamResponse Response
		{
			[Token(Token = "0x6012A7E")]
			[Address(RVA = "0x1ECB5DC", Offset = "0x1ECB5DC", VA = "0x1ECB5DC")]
			get
			{
				return default(SearchTeamResponse);
			}
			[Token(Token = "0x6012A7F")]
			[Address(RVA = "0x1ECB5E8", Offset = "0x1ECB5E8", VA = "0x1ECB5E8")]
			private set
			{
			}
		}

		// Token: 0x06012A80 RID: 76416 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A80")]
		[Address(RVA = "0x1ECB5F8", Offset = "0x1ECB5F8", VA = "0x1ECB5F8")]
		public SearchTeamHttpCommand(string searchText)
		{
		}

		// Token: 0x06012A81 RID: 76417 RVA: 0x00078558 File Offset: 0x00076758
		[Token(Token = "0x6012A81")]
		[Address(RVA = "0x1ECB628", Offset = "0x1ECB628", VA = "0x1ECB628", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A82 RID: 76418 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A82")]
		[Address(RVA = "0x1ECB6C8", Offset = "0x1ECB6C8", VA = "0x1ECB6C8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A83 RID: 76419 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A83")]
		[Address(RVA = "0x1ECB77C", Offset = "0x1ECB77C", VA = "0x1ECB77C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB7D RID: 60285
		[Token(Token = "0x400EB7D")]
		[FieldOffset(Offset = "0x18")]
		private SearchTeamResponse <Response>k__BackingField;

		// Token: 0x0400EB7E RID: 60286
		[Token(Token = "0x400EB7E")]
		[FieldOffset(Offset = "0x28")]
		private readonly string searchText;
	}
}
