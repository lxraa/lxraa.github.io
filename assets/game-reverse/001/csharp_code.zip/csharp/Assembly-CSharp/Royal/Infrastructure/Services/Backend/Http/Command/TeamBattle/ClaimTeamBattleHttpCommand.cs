﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TeamBattle
{
	// Token: 0x0200253A RID: 9530
	[Token(Token = "0x200253A")]
	public class ClaimTeamBattleHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002728 RID: 10024
		// (get) Token: 0x06012A12 RID: 76306 RVA: 0x00078090 File Offset: 0x00076290
		[Token(Token = "0x17002728")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A12")]
			[Address(RVA = "0x1CFDFC8", Offset = "0x1CFDFC8", VA = "0x1CFDFC8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002729 RID: 10025
		// (get) Token: 0x06012A13 RID: 76307 RVA: 0x000780A8 File Offset: 0x000762A8
		[Token(Token = "0x17002729")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A13")]
			[Address(RVA = "0x1CFDFD0", Offset = "0x1CFDFD0", VA = "0x1CFDFD0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700272A RID: 10026
		// (get) Token: 0x06012A14 RID: 76308 RVA: 0x000780C0 File Offset: 0x000762C0
		// (set) Token: 0x06012A15 RID: 76309 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700272A")]
		public ClaimTeamBattleRewardResponse Response
		{
			[Token(Token = "0x6012A14")]
			[Address(RVA = "0x1CFDFD8", Offset = "0x1CFDFD8", VA = "0x1CFDFD8")]
			get
			{
				return default(ClaimTeamBattleRewardResponse);
			}
			[Token(Token = "0x6012A15")]
			[Address(RVA = "0x1CFDFE4", Offset = "0x1CFDFE4", VA = "0x1CFDFE4")]
			set
			{
			}
		}

		// Token: 0x06012A16 RID: 76310 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A16")]
		[Address(RVA = "0x1CFDFF4", Offset = "0x1CFDFF4", VA = "0x1CFDFF4")]
		public ClaimTeamBattleHttpCommand(long groupId)
		{
		}

		// Token: 0x06012A17 RID: 76311 RVA: 0x000780D8 File Offset: 0x000762D8
		[Token(Token = "0x6012A17")]
		[Address(RVA = "0x1CFE01C", Offset = "0x1CFE01C", VA = "0x1CFE01C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A18 RID: 76312 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A18")]
		[Address(RVA = "0x1CFE094", Offset = "0x1CFE094", VA = "0x1CFE094", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A19 RID: 76313 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A19")]
		[Address(RVA = "0x1CFE2AC", Offset = "0x1CFE2AC", VA = "0x1CFE2AC", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB52 RID: 60242
		[Token(Token = "0x400EB52")]
		[FieldOffset(Offset = "0x18")]
		private ClaimTeamBattleRewardResponse <Response>k__BackingField;

		// Token: 0x0400EB53 RID: 60243
		[Token(Token = "0x400EB53")]
		[FieldOffset(Offset = "0x28")]
		private readonly long groupId;
	}
}
