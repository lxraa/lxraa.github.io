﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D2 RID: 9170
	[Token(Token = "0x20023D2")]
	public struct GetFacebookAppsecretProofRequest : IFlatbufferObject
	{
		// Token: 0x170020F2 RID: 8434
		// (get) Token: 0x060113A3 RID: 70563 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020F2")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60113A3")]
			[Address(RVA = "0x1CAF9E8", Offset = "0x1CAF9E8", VA = "0x1CAF9E8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060113A4 RID: 70564 RVA: 0x00066930 File Offset: 0x00064B30
		[Token(Token = "0x60113A4")]
		[Address(RVA = "0x1CAF9F0", Offset = "0x1CAF9F0", VA = "0x1CAF9F0")]
		public static GetFacebookAppsecretProofRequest GetRootAsGetFacebookAppsecretProofRequest(ByteBuffer _bb)
		{
			return default(GetFacebookAppsecretProofRequest);
		}

		// Token: 0x060113A5 RID: 70565 RVA: 0x00066948 File Offset: 0x00064B48
		[Token(Token = "0x60113A5")]
		[Address(RVA = "0x1CAF9FC", Offset = "0x1CAF9FC", VA = "0x1CAF9FC")]
		public static GetFacebookAppsecretProofRequest GetRootAsGetFacebookAppsecretProofRequest(ByteBuffer _bb, GetFacebookAppsecretProofRequest obj)
		{
			return default(GetFacebookAppsecretProofRequest);
		}

		// Token: 0x060113A6 RID: 70566 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113A6")]
		[Address(RVA = "0x1CAFAAC", Offset = "0x1CAFAAC", VA = "0x1CAFAAC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060113A7 RID: 70567 RVA: 0x00066960 File Offset: 0x00064B60
		[Token(Token = "0x60113A7")]
		[Address(RVA = "0x1CAFA74", Offset = "0x1CAFA74", VA = "0x1CAFA74")]
		public GetFacebookAppsecretProofRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetFacebookAppsecretProofRequest);
		}

		// Token: 0x060113A8 RID: 70568 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113A8")]
		[Address(RVA = "0x1CAFABC", Offset = "0x1CAFABC", VA = "0x1CAFABC")]
		public static void StartGetFacebookAppsecretProofRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060113A9 RID: 70569 RVA: 0x00066978 File Offset: 0x00064B78
		[Token(Token = "0x60113A9")]
		[Address(RVA = "0x1CAFAD4", Offset = "0x1CAFAD4", VA = "0x1CAFAD4")]
		public static Offset<GetFacebookAppsecretProofRequest> EndGetFacebookAppsecretProofRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetFacebookAppsecretProofRequest>);
		}

		// Token: 0x0400E742 RID: 59202
		[Token(Token = "0x400E742")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
