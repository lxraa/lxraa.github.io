﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025BB RID: 9659
	[Token(Token = "0x20025BB")]
	public enum ConsentState
	{
		// Token: 0x0400EE82 RID: 61058
		[Token(Token = "0x400EE82")]
		NotRequired,
		// Token: 0x0400EE83 RID: 61059
		[Token(Token = "0x400EE83")]
		RequiredNewInstall,
		// Token: 0x0400EE84 RID: 61060
		[Token(Token = "0x400EE84")]
		RequiredOther
	}
}
