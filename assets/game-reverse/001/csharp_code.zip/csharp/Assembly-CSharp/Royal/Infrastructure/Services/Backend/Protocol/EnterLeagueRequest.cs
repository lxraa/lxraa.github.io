﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A2 RID: 9122
	[Token(Token = "0x20023A2")]
	public struct EnterLeagueRequest : IFlatbufferObject
	{
		// Token: 0x1700203F RID: 8255
		// (get) Token: 0x060110FE RID: 69886 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700203F")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60110FE")]
			[Address(RVA = "0x1F9CED4", Offset = "0x1F9CED4", VA = "0x1F9CED4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110FF RID: 69887 RVA: 0x000645D8 File Offset: 0x000627D8
		[Token(Token = "0x60110FF")]
		[Address(RVA = "0x1F9CEDC", Offset = "0x1F9CEDC", VA = "0x1F9CEDC")]
		public static EnterLeagueRequest GetRootAsEnterLeagueRequest(ByteBuffer _bb)
		{
			return default(EnterLeagueRequest);
		}

		// Token: 0x06011100 RID: 69888 RVA: 0x000645F0 File Offset: 0x000627F0
		[Token(Token = "0x6011100")]
		[Address(RVA = "0x1F9CEE8", Offset = "0x1F9CEE8", VA = "0x1F9CEE8")]
		public static EnterLeagueRequest GetRootAsEnterLeagueRequest(ByteBuffer _bb, EnterLeagueRequest obj)
		{
			return default(EnterLeagueRequest);
		}

		// Token: 0x06011101 RID: 69889 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011101")]
		[Address(RVA = "0x1F9CF98", Offset = "0x1F9CF98", VA = "0x1F9CF98", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011102 RID: 69890 RVA: 0x00064608 File Offset: 0x00062808
		[Token(Token = "0x6011102")]
		[Address(RVA = "0x1F9CF60", Offset = "0x1F9CF60", VA = "0x1F9CF60")]
		public EnterLeagueRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterLeagueRequest);
		}

		// Token: 0x17002040 RID: 8256
		// (get) Token: 0x06011103 RID: 69891 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002040")]
		public string Name
		{
			[Token(Token = "0x6011103")]
			[Address(RVA = "0x1F9CFA8", Offset = "0x1F9CFA8", VA = "0x1F9CFA8")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011104 RID: 69892 RVA: 0x00064620 File Offset: 0x00062820
		[Token(Token = "0x6011104")]
		[Address(RVA = "0x1F9CFE4", Offset = "0x1F9CFE4", VA = "0x1F9CFE4")]
		public ArraySegment<byte>? GetNameBytes()
		{
			return null;
		}

		// Token: 0x06011105 RID: 69893 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011105")]
		[Address(RVA = "0x1F9D01C", Offset = "0x1F9D01C", VA = "0x1F9D01C")]
		public byte[] GetNameArray()
		{
			return null;
		}

		// Token: 0x17002041 RID: 8257
		// (get) Token: 0x06011106 RID: 69894 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002041")]
		public string Language
		{
			[Token(Token = "0x6011106")]
			[Address(RVA = "0x1F9D068", Offset = "0x1F9D068", VA = "0x1F9D068")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011107 RID: 69895 RVA: 0x00064638 File Offset: 0x00062838
		[Token(Token = "0x6011107")]
		[Address(RVA = "0x1F9D0A4", Offset = "0x1F9D0A4", VA = "0x1F9D0A4")]
		public ArraySegment<byte>? GetLanguageBytes()
		{
			return null;
		}

		// Token: 0x06011108 RID: 69896 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011108")]
		[Address(RVA = "0x1F9D0DC", Offset = "0x1F9D0DC", VA = "0x1F9D0DC")]
		public byte[] GetLanguageArray()
		{
			return null;
		}

		// Token: 0x17002042 RID: 8258
		// (get) Token: 0x06011109 RID: 69897 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002042")]
		public string DeviceLanguage
		{
			[Token(Token = "0x6011109")]
			[Address(RVA = "0x1F9D128", Offset = "0x1F9D128", VA = "0x1F9D128")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601110A RID: 69898 RVA: 0x00064650 File Offset: 0x00062850
		[Token(Token = "0x601110A")]
		[Address(RVA = "0x1F9D164", Offset = "0x1F9D164", VA = "0x1F9D164")]
		public ArraySegment<byte>? GetDeviceLanguageBytes()
		{
			return null;
		}

		// Token: 0x0601110B RID: 69899 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601110B")]
		[Address(RVA = "0x1F9D19C", Offset = "0x1F9D19C", VA = "0x1F9D19C")]
		public byte[] GetDeviceLanguageArray()
		{
			return null;
		}

		// Token: 0x0601110C RID: 69900 RVA: 0x00064668 File Offset: 0x00062868
		[Token(Token = "0x601110C")]
		[Address(RVA = "0x1F9D1E8", Offset = "0x1F9D1E8", VA = "0x1F9D1E8")]
		public static Offset<EnterLeagueRequest> CreateEnterLeagueRequest(FlatBufferBuilder builder, [Optional] StringOffset nameOffset, [Optional] StringOffset languageOffset, [Optional] StringOffset device_languageOffset)
		{
			return default(Offset<EnterLeagueRequest>);
		}

		// Token: 0x0601110D RID: 69901 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601110D")]
		[Address(RVA = "0x1F9D324", Offset = "0x1F9D324", VA = "0x1F9D324")]
		public static void StartEnterLeagueRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601110E RID: 69902 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601110E")]
		[Address(RVA = "0x1F9D298", Offset = "0x1F9D298", VA = "0x1F9D298")]
		public static void AddName(FlatBufferBuilder builder, StringOffset nameOffset)
		{
		}

		// Token: 0x0601110F RID: 69903 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601110F")]
		[Address(RVA = "0x1F9D278", Offset = "0x1F9D278", VA = "0x1F9D278")]
		public static void AddLanguage(FlatBufferBuilder builder, StringOffset languageOffset)
		{
		}

		// Token: 0x06011110 RID: 69904 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011110")]
		[Address(RVA = "0x1F9D258", Offset = "0x1F9D258", VA = "0x1F9D258")]
		public static void AddDeviceLanguage(FlatBufferBuilder builder, StringOffset deviceLanguageOffset)
		{
		}

		// Token: 0x06011111 RID: 69905 RVA: 0x00064680 File Offset: 0x00062880
		[Token(Token = "0x6011111")]
		[Address(RVA = "0x1F9D2B8", Offset = "0x1F9D2B8", VA = "0x1F9D2B8")]
		public static Offset<EnterLeagueRequest> EndEnterLeagueRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterLeagueRequest>);
		}

		// Token: 0x0400E6D0 RID: 59088
		[Token(Token = "0x400E6D0")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
