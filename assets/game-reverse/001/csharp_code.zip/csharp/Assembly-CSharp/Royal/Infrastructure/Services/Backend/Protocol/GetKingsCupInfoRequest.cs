﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023DC RID: 9180
	[Token(Token = "0x20023DC")]
	public struct GetKingsCupInfoRequest : IFlatbufferObject
	{
		// Token: 0x17002107 RID: 8455
		// (get) Token: 0x06011422 RID: 70690 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002107")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011422")]
			[Address(RVA = "0x1CB1A8C", Offset = "0x1CB1A8C", VA = "0x1CB1A8C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011423 RID: 70691 RVA: 0x00067068 File Offset: 0x00065268
		[Token(Token = "0x6011423")]
		[Address(RVA = "0x1CB1A94", Offset = "0x1CB1A94", VA = "0x1CB1A94")]
		public static GetKingsCupInfoRequest GetRootAsGetKingsCupInfoRequest(ByteBuffer _bb)
		{
			return default(GetKingsCupInfoRequest);
		}

		// Token: 0x06011424 RID: 70692 RVA: 0x00067080 File Offset: 0x00065280
		[Token(Token = "0x6011424")]
		[Address(RVA = "0x1CB1AA0", Offset = "0x1CB1AA0", VA = "0x1CB1AA0")]
		public static GetKingsCupInfoRequest GetRootAsGetKingsCupInfoRequest(ByteBuffer _bb, GetKingsCupInfoRequest obj)
		{
			return default(GetKingsCupInfoRequest);
		}

		// Token: 0x06011425 RID: 70693 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011425")]
		[Address(RVA = "0x1CB1B50", Offset = "0x1CB1B50", VA = "0x1CB1B50", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011426 RID: 70694 RVA: 0x00067098 File Offset: 0x00065298
		[Token(Token = "0x6011426")]
		[Address(RVA = "0x1CB1B18", Offset = "0x1CB1B18", VA = "0x1CB1B18")]
		public GetKingsCupInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetKingsCupInfoRequest);
		}

		// Token: 0x17002108 RID: 8456
		// (get) Token: 0x06011427 RID: 70695 RVA: 0x000670B0 File Offset: 0x000652B0
		[Token(Token = "0x17002108")]
		public long GroupId
		{
			[Token(Token = "0x6011427")]
			[Address(RVA = "0x1CB1B60", Offset = "0x1CB1B60", VA = "0x1CB1B60")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06011428 RID: 70696 RVA: 0x000670C8 File Offset: 0x000652C8
		[Token(Token = "0x6011428")]
		[Address(RVA = "0x1CB1BA8", Offset = "0x1CB1BA8", VA = "0x1CB1BA8")]
		public static Offset<GetKingsCupInfoRequest> CreateGetKingsCupInfoRequest(FlatBufferBuilder builder, long group_id = 0L)
		{
			return default(Offset<GetKingsCupInfoRequest>);
		}

		// Token: 0x06011429 RID: 70697 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011429")]
		[Address(RVA = "0x1CB1C7C", Offset = "0x1CB1C7C", VA = "0x1CB1C7C")]
		public static void StartGetKingsCupInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601142A RID: 70698 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601142A")]
		[Address(RVA = "0x1CB1BF0", Offset = "0x1CB1BF0", VA = "0x1CB1BF0")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x0601142B RID: 70699 RVA: 0x000670E0 File Offset: 0x000652E0
		[Token(Token = "0x601142B")]
		[Address(RVA = "0x1CB1C10", Offset = "0x1CB1C10", VA = "0x1CB1C10")]
		public static Offset<GetKingsCupInfoRequest> EndGetKingsCupInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetKingsCupInfoRequest>);
		}

		// Token: 0x0400E74C RID: 59212
		[Token(Token = "0x400E74C")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
