﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x0200259C RID: 9628
	[Token(Token = "0x200259C")]
	public class RemainingItemJson
	{
		// Token: 0x06012D54 RID: 77140 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D54")]
		[Address(RVA = "0x243AA2C", Offset = "0x243AA2C", VA = "0x243AA2C")]
		public RemainingItemJson()
		{
		}

		// Token: 0x0400ED1F RID: 60703
		[Token(Token = "0x400ED1F")]
		[FieldOffset(Offset = "0x10")]
		public string n;

		// Token: 0x0400ED20 RID: 60704
		[Token(Token = "0x400ED20")]
		[FieldOffset(Offset = "0x18")]
		public int t;

		// Token: 0x0400ED21 RID: 60705
		[Token(Token = "0x400ED21")]
		[FieldOffset(Offset = "0x1C")]
		public int r;
	}
}
