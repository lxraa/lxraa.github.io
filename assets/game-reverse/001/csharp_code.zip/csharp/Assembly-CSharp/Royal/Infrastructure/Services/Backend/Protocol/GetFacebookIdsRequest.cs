﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D4 RID: 9172
	[Token(Token = "0x20023D4")]
	public struct GetFacebookIdsRequest : IFlatbufferObject
	{
		// Token: 0x170020F4 RID: 8436
		// (get) Token: 0x060113B1 RID: 70577 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020F4")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60113B1")]
			[Address(RVA = "0x1CAFC98", Offset = "0x1CAFC98", VA = "0x1CAFC98", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060113B2 RID: 70578 RVA: 0x000669F0 File Offset: 0x00064BF0
		[Token(Token = "0x60113B2")]
		[Address(RVA = "0x1CAFCA0", Offset = "0x1CAFCA0", VA = "0x1CAFCA0")]
		public static GetFacebookIdsRequest GetRootAsGetFacebookIdsRequest(ByteBuffer _bb)
		{
			return default(GetFacebookIdsRequest);
		}

		// Token: 0x060113B3 RID: 70579 RVA: 0x00066A08 File Offset: 0x00064C08
		[Token(Token = "0x60113B3")]
		[Address(RVA = "0x1CAFCAC", Offset = "0x1CAFCAC", VA = "0x1CAFCAC")]
		public static GetFacebookIdsRequest GetRootAsGetFacebookIdsRequest(ByteBuffer _bb, GetFacebookIdsRequest obj)
		{
			return default(GetFacebookIdsRequest);
		}

		// Token: 0x060113B4 RID: 70580 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113B4")]
		[Address(RVA = "0x1CAFD5C", Offset = "0x1CAFD5C", VA = "0x1CAFD5C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060113B5 RID: 70581 RVA: 0x00066A20 File Offset: 0x00064C20
		[Token(Token = "0x60113B5")]
		[Address(RVA = "0x1CAFD24", Offset = "0x1CAFD24", VA = "0x1CAFD24")]
		public GetFacebookIdsRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetFacebookIdsRequest);
		}

		// Token: 0x170020F5 RID: 8437
		// (get) Token: 0x060113B6 RID: 70582 RVA: 0x00066A38 File Offset: 0x00064C38
		[Token(Token = "0x170020F5")]
		public int Version
		{
			[Token(Token = "0x60113B6")]
			[Address(RVA = "0x1CAFD6C", Offset = "0x1CAFD6C", VA = "0x1CAFD6C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020F6 RID: 8438
		// (get) Token: 0x060113B7 RID: 70583 RVA: 0x00066A50 File Offset: 0x00064C50
		[Token(Token = "0x170020F6")]
		public bool IsNew
		{
			[Token(Token = "0x60113B7")]
			[Address(RVA = "0x1CAFDB0", Offset = "0x1CAFDB0", VA = "0x1CAFDB0")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x060113B8 RID: 70584 RVA: 0x00066A68 File Offset: 0x00064C68
		[Token(Token = "0x60113B8")]
		[Address(RVA = "0x1CAFDF8", Offset = "0x1CAFDF8", VA = "0x1CAFDF8")]
		public static Offset<GetFacebookIdsRequest> CreateGetFacebookIdsRequest(FlatBufferBuilder builder, int version = 0, bool isNew = false)
		{
			return default(Offset<GetFacebookIdsRequest>);
		}

		// Token: 0x060113B9 RID: 70585 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113B9")]
		[Address(RVA = "0x1CAFEFC", Offset = "0x1CAFEFC", VA = "0x1CAFEFC")]
		public static void StartGetFacebookIdsRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060113BA RID: 70586 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113BA")]
		[Address(RVA = "0x1CAFE50", Offset = "0x1CAFE50", VA = "0x1CAFE50")]
		public static void AddVersion(FlatBufferBuilder builder, int version)
		{
		}

		// Token: 0x060113BB RID: 70587 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113BB")]
		[Address(RVA = "0x1CAFE70", Offset = "0x1CAFE70", VA = "0x1CAFE70")]
		public static void AddIsNew(FlatBufferBuilder builder, bool isNew)
		{
		}

		// Token: 0x060113BC RID: 70588 RVA: 0x00066A80 File Offset: 0x00064C80
		[Token(Token = "0x60113BC")]
		[Address(RVA = "0x1CAFE90", Offset = "0x1CAFE90", VA = "0x1CAFE90")]
		public static Offset<GetFacebookIdsRequest> EndGetFacebookIdsRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetFacebookIdsRequest>);
		}

		// Token: 0x0400E744 RID: 59204
		[Token(Token = "0x400E744")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
