﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TeamTournament
{
	// Token: 0x02002539 RID: 9529
	[Token(Token = "0x2002539")]
	public class UpdateTeamTournamentScoreHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002726 RID: 10022
		// (get) Token: 0x06012A0C RID: 76300 RVA: 0x00078048 File Offset: 0x00076248
		[Token(Token = "0x17002726")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A0C")]
			[Address(RVA = "0x1CFDAF0", Offset = "0x1CFDAF0", VA = "0x1CFDAF0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002727 RID: 10023
		// (get) Token: 0x06012A0D RID: 76301 RVA: 0x00078060 File Offset: 0x00076260
		[Token(Token = "0x17002727")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A0D")]
			[Address(RVA = "0x1CFDAF8", Offset = "0x1CFDAF8", VA = "0x1CFDAF8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A0E RID: 76302 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A0E")]
		[Address(RVA = "0x1CFDB00", Offset = "0x1CFDB00", VA = "0x1CFDB00")]
		public UpdateTeamTournamentScoreHttpCommand(long groupId, int totalScore, string usersHash, long teamId)
		{
		}

		// Token: 0x06012A0F RID: 76303 RVA: 0x00078078 File Offset: 0x00076278
		[Token(Token = "0x6012A0F")]
		[Address(RVA = "0x1CFDB54", Offset = "0x1CFDB54", VA = "0x1CFDB54", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A10 RID: 76304 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A10")]
		[Address(RVA = "0x1CFDCF4", Offset = "0x1CFDCF4", VA = "0x1CFDCF4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A11 RID: 76305 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A11")]
		[Address(RVA = "0x1CFDFC4", Offset = "0x1CFDFC4", VA = "0x1CFDFC4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB4E RID: 60238
		[Token(Token = "0x400EB4E")]
		[FieldOffset(Offset = "0x18")]
		private readonly long groupId;

		// Token: 0x0400EB4F RID: 60239
		[Token(Token = "0x400EB4F")]
		[FieldOffset(Offset = "0x20")]
		private readonly int totalScore;

		// Token: 0x0400EB50 RID: 60240
		[Token(Token = "0x400EB50")]
		[FieldOffset(Offset = "0x28")]
		private readonly string usersHash;

		// Token: 0x0400EB51 RID: 60241
		[Token(Token = "0x400EB51")]
		[FieldOffset(Offset = "0x30")]
		private readonly long teamId;
	}
}
