﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200239B RID: 9115
	[Token(Token = "0x200239B")]
	public enum EnterDailyLightningRushFailReason : sbyte
	{
		// Token: 0x0400E6BD RID: 59069
		[Token(Token = "0x400E6BD")]
		None,
		// Token: 0x0400E6BE RID: 59070
		[Token(Token = "0x400E6BE")]
		AlreadyEntered,
		// Token: 0x0400E6BF RID: 59071
		[Token(Token = "0x400E6BF")]
		EventNotActive,
		// Token: 0x0400E6C0 RID: 59072
		[Token(Token = "0x400E6C0")]
		IsAboutToEnd
	}
}
