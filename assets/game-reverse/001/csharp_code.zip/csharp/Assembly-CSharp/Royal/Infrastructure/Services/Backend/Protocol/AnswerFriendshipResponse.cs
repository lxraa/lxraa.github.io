﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002338 RID: 9016
	[Token(Token = "0x2002338")]
	public struct AnswerFriendshipResponse : IFlatbufferObject
	{
		// Token: 0x17001EB3 RID: 7859
		// (get) Token: 0x06010B33 RID: 68403 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EB3")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B33")]
			[Address(RVA = "0x2141C48", Offset = "0x2141C48", VA = "0x2141C48", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B34 RID: 68404 RVA: 0x0005FA78 File Offset: 0x0005DC78
		[Token(Token = "0x6010B34")]
		[Address(RVA = "0x2141C50", Offset = "0x2141C50", VA = "0x2141C50")]
		public static AnswerFriendshipResponse GetRootAsAnswerFriendshipResponse(ByteBuffer _bb)
		{
			return default(AnswerFriendshipResponse);
		}

		// Token: 0x06010B35 RID: 68405 RVA: 0x0005FA90 File Offset: 0x0005DC90
		[Token(Token = "0x6010B35")]
		[Address(RVA = "0x2141C5C", Offset = "0x2141C5C", VA = "0x2141C5C")]
		public static AnswerFriendshipResponse GetRootAsAnswerFriendshipResponse(ByteBuffer _bb, AnswerFriendshipResponse obj)
		{
			return default(AnswerFriendshipResponse);
		}

		// Token: 0x06010B36 RID: 68406 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B36")]
		[Address(RVA = "0x2141D0C", Offset = "0x2141D0C", VA = "0x2141D0C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B37 RID: 68407 RVA: 0x0005FAA8 File Offset: 0x0005DCA8
		[Token(Token = "0x6010B37")]
		[Address(RVA = "0x2141CD4", Offset = "0x2141CD4", VA = "0x2141CD4")]
		public AnswerFriendshipResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(AnswerFriendshipResponse);
		}

		// Token: 0x17001EB4 RID: 7860
		// (get) Token: 0x06010B38 RID: 68408 RVA: 0x0005FAC0 File Offset: 0x0005DCC0
		[Token(Token = "0x17001EB4")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010B38")]
			[Address(RVA = "0x2141D1C", Offset = "0x2141D1C", VA = "0x2141D1C")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x06010B39 RID: 68409 RVA: 0x0005FAD8 File Offset: 0x0005DCD8
		[Token(Token = "0x6010B39")]
		[Address(RVA = "0x2141D60", Offset = "0x2141D60", VA = "0x2141D60")]
		public static Offset<AnswerFriendshipResponse> CreateAnswerFriendshipResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success)
		{
			return default(Offset<AnswerFriendshipResponse>);
		}

		// Token: 0x06010B3A RID: 68410 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B3A")]
		[Address(RVA = "0x2141E34", Offset = "0x2141E34", VA = "0x2141E34")]
		public static void StartAnswerFriendshipResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B3B RID: 68411 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B3B")]
		[Address(RVA = "0x2141DA8", Offset = "0x2141DA8", VA = "0x2141DA8")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010B3C RID: 68412 RVA: 0x0005FAF0 File Offset: 0x0005DCF0
		[Token(Token = "0x6010B3C")]
		[Address(RVA = "0x2141DC8", Offset = "0x2141DC8", VA = "0x2141DC8")]
		public static Offset<AnswerFriendshipResponse> EndAnswerFriendshipResponse(FlatBufferBuilder builder)
		{
			return default(Offset<AnswerFriendshipResponse>);
		}

		// Token: 0x0400E612 RID: 58898
		[Token(Token = "0x400E612")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
