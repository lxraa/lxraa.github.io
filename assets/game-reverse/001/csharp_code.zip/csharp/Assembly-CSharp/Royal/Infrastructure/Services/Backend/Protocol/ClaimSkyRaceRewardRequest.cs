﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002360 RID: 9056
	[Token(Token = "0x2002360")]
	public struct ClaimSkyRaceRewardRequest : IFlatbufferObject
	{
		// Token: 0x17001F3A RID: 7994
		// (get) Token: 0x06010D42 RID: 68930 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F3A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D42")]
			[Address(RVA = "0x21495E8", Offset = "0x21495E8", VA = "0x21495E8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D43 RID: 68931 RVA: 0x00061500 File Offset: 0x0005F700
		[Token(Token = "0x6010D43")]
		[Address(RVA = "0x21495F0", Offset = "0x21495F0", VA = "0x21495F0")]
		public static ClaimSkyRaceRewardRequest GetRootAsClaimSkyRaceRewardRequest(ByteBuffer _bb)
		{
			return default(ClaimSkyRaceRewardRequest);
		}

		// Token: 0x06010D44 RID: 68932 RVA: 0x00061518 File Offset: 0x0005F718
		[Token(Token = "0x6010D44")]
		[Address(RVA = "0x21495FC", Offset = "0x21495FC", VA = "0x21495FC")]
		public static ClaimSkyRaceRewardRequest GetRootAsClaimSkyRaceRewardRequest(ByteBuffer _bb, ClaimSkyRaceRewardRequest obj)
		{
			return default(ClaimSkyRaceRewardRequest);
		}

		// Token: 0x06010D45 RID: 68933 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D45")]
		[Address(RVA = "0x21496AC", Offset = "0x21496AC", VA = "0x21496AC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D46 RID: 68934 RVA: 0x00061530 File Offset: 0x0005F730
		[Token(Token = "0x6010D46")]
		[Address(RVA = "0x2149674", Offset = "0x2149674", VA = "0x2149674")]
		public ClaimSkyRaceRewardRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimSkyRaceRewardRequest);
		}

		// Token: 0x17001F3B RID: 7995
		// (get) Token: 0x06010D47 RID: 68935 RVA: 0x00061548 File Offset: 0x0005F748
		[Token(Token = "0x17001F3B")]
		public long GroupId
		{
			[Token(Token = "0x6010D47")]
			[Address(RVA = "0x21496BC", Offset = "0x21496BC", VA = "0x21496BC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F3C RID: 7996
		// (get) Token: 0x06010D48 RID: 68936 RVA: 0x00061560 File Offset: 0x0005F760
		[Token(Token = "0x17001F3C")]
		public CurrentUserInventory? DeprecatedCurrentUserInventory
		{
			[Token(Token = "0x6010D48")]
			[Address(RVA = "0x2149704", Offset = "0x2149704", VA = "0x2149704")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F3D RID: 7997
		// (get) Token: 0x06010D49 RID: 68937 RVA: 0x00061578 File Offset: 0x0005F778
		[Token(Token = "0x17001F3D")]
		public int ConfigVersion
		{
			[Token(Token = "0x6010D49")]
			[Address(RVA = "0x21497C4", Offset = "0x21497C4", VA = "0x21497C4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010D4A RID: 68938 RVA: 0x00061590 File Offset: 0x0005F790
		[Token(Token = "0x6010D4A")]
		[Address(RVA = "0x2149808", Offset = "0x2149808", VA = "0x2149808")]
		public static Offset<ClaimSkyRaceRewardRequest> CreateClaimSkyRaceRewardRequest(FlatBufferBuilder builder, long group_id = 0L, [Optional] Offset<CurrentUserInventory> deprecated_current_user_inventoryOffset, int config_version = 0)
		{
			return default(Offset<ClaimSkyRaceRewardRequest>);
		}

		// Token: 0x06010D4B RID: 68939 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D4B")]
		[Address(RVA = "0x2149944", Offset = "0x2149944", VA = "0x2149944")]
		public static void StartClaimSkyRaceRewardRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D4C RID: 68940 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D4C")]
		[Address(RVA = "0x2149878", Offset = "0x2149878", VA = "0x2149878")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06010D4D RID: 68941 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D4D")]
		[Address(RVA = "0x21498B8", Offset = "0x21498B8", VA = "0x21498B8")]
		public static void AddDeprecatedCurrentUserInventory(FlatBufferBuilder builder, Offset<CurrentUserInventory> deprecatedCurrentUserInventoryOffset)
		{
		}

		// Token: 0x06010D4E RID: 68942 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D4E")]
		[Address(RVA = "0x2149898", Offset = "0x2149898", VA = "0x2149898")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06010D4F RID: 68943 RVA: 0x000615A8 File Offset: 0x0005F7A8
		[Token(Token = "0x6010D4F")]
		[Address(RVA = "0x21498D8", Offset = "0x21498D8", VA = "0x21498D8")]
		public static Offset<ClaimSkyRaceRewardRequest> EndClaimSkyRaceRewardRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimSkyRaceRewardRequest>);
		}

		// Token: 0x0400E666 RID: 58982
		[Token(Token = "0x400E666")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
