﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.PropellerRush
{
	// Token: 0x02002551 RID: 9553
	[Token(Token = "0x2002551")]
	public class GetPropellerRushInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002763 RID: 10083
		// (get) Token: 0x06012AC1 RID: 76481 RVA: 0x00078858 File Offset: 0x00076A58
		[Token(Token = "0x17002763")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AC1")]
			[Address(RVA = "0x1ECD66C", Offset = "0x1ECD66C", VA = "0x1ECD66C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002764 RID: 10084
		// (get) Token: 0x06012AC2 RID: 76482 RVA: 0x00078870 File Offset: 0x00076A70
		[Token(Token = "0x17002764")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AC2")]
			[Address(RVA = "0x1ECD674", Offset = "0x1ECD674", VA = "0x1ECD674", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AC3 RID: 76483 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AC3")]
		[Address(RVA = "0x1ECD67C", Offset = "0x1ECD67C", VA = "0x1ECD67C")]
		public GetPropellerRushInfoHttpCommand(long groupId, int configVersion, LeaderboardInfoType infoType, int eventId, bool afterLevelWin = false)
		{
		}

		// Token: 0x06012AC4 RID: 76484 RVA: 0x00078888 File Offset: 0x00076A88
		[Token(Token = "0x6012AC4")]
		[Address(RVA = "0x1ECD778", Offset = "0x1ECD778", VA = "0x1ECD778", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AC5 RID: 76485 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AC5")]
		[Address(RVA = "0x1ECD850", Offset = "0x1ECD850", VA = "0x1ECD850", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AC6 RID: 76486 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AC6")]
		[Address(RVA = "0x1ECDBA4", Offset = "0x1ECDBA4", VA = "0x1ECDBA4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB9B RID: 60315
		[Token(Token = "0x400EB9B")]
		[FieldOffset(Offset = "0x18")]
		private readonly long groupId;

		// Token: 0x0400EB9C RID: 60316
		[Token(Token = "0x400EB9C")]
		[FieldOffset(Offset = "0x20")]
		private readonly int configVersion;

		// Token: 0x0400EB9D RID: 60317
		[Token(Token = "0x400EB9D")]
		[FieldOffset(Offset = "0x24")]
		private readonly LeaderboardInfoType infoType;

		// Token: 0x0400EB9E RID: 60318
		[Token(Token = "0x400EB9E")]
		[FieldOffset(Offset = "0x28")]
		private readonly int eventId;

		// Token: 0x0400EB9F RID: 60319
		[Token(Token = "0x400EB9F")]
		[FieldOffset(Offset = "0x2C")]
		private readonly bool afterLevelWin;
	}
}
