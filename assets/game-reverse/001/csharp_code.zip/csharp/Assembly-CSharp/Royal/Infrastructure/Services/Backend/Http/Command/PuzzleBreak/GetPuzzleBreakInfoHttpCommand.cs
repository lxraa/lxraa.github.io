﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.PuzzleBreak
{
	// Token: 0x0200254F RID: 9551
	[Token(Token = "0x200254F")]
	public class GetPuzzleBreakInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700275F RID: 10079
		// (get) Token: 0x06012AB4 RID: 76468 RVA: 0x000787B0 File Offset: 0x000769B0
		[Token(Token = "0x1700275F")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AB4")]
			[Address(RVA = "0x1ECD0EC", Offset = "0x1ECD0EC", VA = "0x1ECD0EC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002760 RID: 10080
		// (get) Token: 0x06012AB5 RID: 76469 RVA: 0x000787C8 File Offset: 0x000769C8
		[Token(Token = "0x17002760")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AB5")]
			[Address(RVA = "0x1ECD0F4", Offset = "0x1ECD0F4", VA = "0x1ECD0F4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AB6 RID: 76470 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AB6")]
		[Address(RVA = "0x1ECD0FC", Offset = "0x1ECD0FC", VA = "0x1ECD0FC")]
		public GetPuzzleBreakInfoHttpCommand(int eventId)
		{
		}

		// Token: 0x06012AB7 RID: 76471 RVA: 0x000787E0 File Offset: 0x000769E0
		[Token(Token = "0x6012AB7")]
		[Address(RVA = "0x1ECD12C", Offset = "0x1ECD12C", VA = "0x1ECD12C", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012AB8 RID: 76472 RVA: 0x000787F8 File Offset: 0x000769F8
		[Token(Token = "0x6012AB8")]
		[Address(RVA = "0x1ECD1EC", Offset = "0x1ECD1EC", VA = "0x1ECD1EC", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AB9 RID: 76473 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AB9")]
		[Address(RVA = "0x1ECD20C", Offset = "0x1ECD20C", VA = "0x1ECD20C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012ABA RID: 76474 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ABA")]
		[Address(RVA = "0x1ECD2E4", Offset = "0x1ECD2E4", VA = "0x1ECD2E4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB96 RID: 60310
		[Token(Token = "0x400EB96")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;
	}
}
