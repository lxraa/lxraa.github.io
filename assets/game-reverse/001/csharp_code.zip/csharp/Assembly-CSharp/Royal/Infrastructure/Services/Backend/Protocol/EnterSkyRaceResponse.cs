﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023AA RID: 9130
	[Token(Token = "0x20023AA")]
	public struct EnterSkyRaceResponse : IFlatbufferObject
	{
		// Token: 0x17002060 RID: 8288
		// (get) Token: 0x06011174 RID: 70004 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002060")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011174")]
			[Address(RVA = "0x1F9EBD4", Offset = "0x1F9EBD4", VA = "0x1F9EBD4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011175 RID: 70005 RVA: 0x00064BD8 File Offset: 0x00062DD8
		[Token(Token = "0x6011175")]
		[Address(RVA = "0x1F9EBDC", Offset = "0x1F9EBDC", VA = "0x1F9EBDC")]
		public static EnterSkyRaceResponse GetRootAsEnterSkyRaceResponse(ByteBuffer _bb)
		{
			return default(EnterSkyRaceResponse);
		}

		// Token: 0x06011176 RID: 70006 RVA: 0x00064BF0 File Offset: 0x00062DF0
		[Token(Token = "0x6011176")]
		[Address(RVA = "0x1F9EBE8", Offset = "0x1F9EBE8", VA = "0x1F9EBE8")]
		public static EnterSkyRaceResponse GetRootAsEnterSkyRaceResponse(ByteBuffer _bb, EnterSkyRaceResponse obj)
		{
			return default(EnterSkyRaceResponse);
		}

		// Token: 0x06011177 RID: 70007 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011177")]
		[Address(RVA = "0x1F9EC98", Offset = "0x1F9EC98", VA = "0x1F9EC98", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011178 RID: 70008 RVA: 0x00064C08 File Offset: 0x00062E08
		[Token(Token = "0x6011178")]
		[Address(RVA = "0x1F9EC60", Offset = "0x1F9EC60", VA = "0x1F9EC60")]
		public EnterSkyRaceResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterSkyRaceResponse);
		}

		// Token: 0x17002061 RID: 8289
		// (get) Token: 0x06011179 RID: 70009 RVA: 0x00064C20 File Offset: 0x00062E20
		[Token(Token = "0x17002061")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6011179")]
			[Address(RVA = "0x1F9ECA8", Offset = "0x1F9ECA8", VA = "0x1F9ECA8")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17002062 RID: 8290
		// (get) Token: 0x0601117A RID: 70010 RVA: 0x00064C38 File Offset: 0x00062E38
		[Token(Token = "0x17002062")]
		public EnterEventFailReason FailReason
		{
			[Token(Token = "0x601117A")]
			[Address(RVA = "0x1F9ECEC", Offset = "0x1F9ECEC", VA = "0x1F9ECEC")]
			get
			{
				return EnterEventFailReason.None;
			}
		}

		// Token: 0x17002063 RID: 8291
		// (get) Token: 0x0601117B RID: 70011 RVA: 0x00064C50 File Offset: 0x00062E50
		[Token(Token = "0x17002063")]
		public long GroupId
		{
			[Token(Token = "0x601117B")]
			[Address(RVA = "0x1F9ED30", Offset = "0x1F9ED30", VA = "0x1F9ED30")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17002064 RID: 8292
		// (get) Token: 0x0601117C RID: 70012 RVA: 0x00064C68 File Offset: 0x00062E68
		[Token(Token = "0x17002064")]
		public SkyRaceInfo? SkyRaceInfo
		{
			[Token(Token = "0x601117C")]
			[Address(RVA = "0x1F9ED78", Offset = "0x1F9ED78", VA = "0x1F9ED78")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002065 RID: 8293
		// (get) Token: 0x0601117D RID: 70013 RVA: 0x00064C80 File Offset: 0x00062E80
		[Token(Token = "0x17002065")]
		public long SkyRaceStartTime
		{
			[Token(Token = "0x601117D")]
			[Address(RVA = "0x1F9EE38", Offset = "0x1F9EE38", VA = "0x1F9EE38")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x0601117E RID: 70014 RVA: 0x00064C98 File Offset: 0x00062E98
		[Token(Token = "0x601117E")]
		[Address(RVA = "0x1F9EE80", Offset = "0x1F9EE80", VA = "0x1F9EE80")]
		public static Offset<EnterSkyRaceResponse> CreateEnterSkyRaceResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, EnterEventFailReason fail_reason = EnterEventFailReason.None, long group_id = 0L, [Optional] Offset<SkyRaceInfo> sky_race_infoOffset, long sky_race_start_time = 0L)
		{
			return default(Offset<EnterSkyRaceResponse>);
		}

		// Token: 0x0601117F RID: 70015 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601117F")]
		[Address(RVA = "0x1F9F024", Offset = "0x1F9F024", VA = "0x1F9F024")]
		public static void StartEnterSkyRaceResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011180 RID: 70016 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011180")]
		[Address(RVA = "0x1F9EF98", Offset = "0x1F9EF98", VA = "0x1F9EF98")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06011181 RID: 70017 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011181")]
		[Address(RVA = "0x1F9EF78", Offset = "0x1F9EF78", VA = "0x1F9EF78")]
		public static void AddFailReason(FlatBufferBuilder builder, EnterEventFailReason failReason)
		{
		}

		// Token: 0x06011182 RID: 70018 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011182")]
		[Address(RVA = "0x1F9EF38", Offset = "0x1F9EF38", VA = "0x1F9EF38")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06011183 RID: 70019 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011183")]
		[Address(RVA = "0x1F9EF58", Offset = "0x1F9EF58", VA = "0x1F9EF58")]
		public static void AddSkyRaceInfo(FlatBufferBuilder builder, Offset<SkyRaceInfo> skyRaceInfoOffset)
		{
		}

		// Token: 0x06011184 RID: 70020 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011184")]
		[Address(RVA = "0x1F9EF18", Offset = "0x1F9EF18", VA = "0x1F9EF18")]
		public static void AddSkyRaceStartTime(FlatBufferBuilder builder, long skyRaceStartTime)
		{
		}

		// Token: 0x06011185 RID: 70021 RVA: 0x00064CB0 File Offset: 0x00062EB0
		[Token(Token = "0x6011185")]
		[Address(RVA = "0x1F9EFB8", Offset = "0x1F9EFB8", VA = "0x1F9EFB8")]
		public static Offset<EnterSkyRaceResponse> EndEnterSkyRaceResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterSkyRaceResponse>);
		}

		// Token: 0x0400E6DC RID: 59100
		[Token(Token = "0x400E6DC")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
