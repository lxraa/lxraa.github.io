﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C0 RID: 9152
	[Token(Token = "0x20023C0")]
	public struct GetAllTimePurchaseResponse : IFlatbufferObject
	{
		// Token: 0x170020B8 RID: 8376
		// (get) Token: 0x060112AA RID: 70314 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020B8")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60112AA")]
			[Address(RVA = "0x1CAB828", Offset = "0x1CAB828", VA = "0x1CAB828", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112AB RID: 70315 RVA: 0x00065B98 File Offset: 0x00063D98
		[Token(Token = "0x60112AB")]
		[Address(RVA = "0x1CAB830", Offset = "0x1CAB830", VA = "0x1CAB830")]
		public static GetAllTimePurchaseResponse GetRootAsGetAllTimePurchaseResponse(ByteBuffer _bb)
		{
			return default(GetAllTimePurchaseResponse);
		}

		// Token: 0x060112AC RID: 70316 RVA: 0x00065BB0 File Offset: 0x00063DB0
		[Token(Token = "0x60112AC")]
		[Address(RVA = "0x1CAB83C", Offset = "0x1CAB83C", VA = "0x1CAB83C")]
		public static GetAllTimePurchaseResponse GetRootAsGetAllTimePurchaseResponse(ByteBuffer _bb, GetAllTimePurchaseResponse obj)
		{
			return default(GetAllTimePurchaseResponse);
		}

		// Token: 0x060112AD RID: 70317 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112AD")]
		[Address(RVA = "0x1CAB8EC", Offset = "0x1CAB8EC", VA = "0x1CAB8EC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060112AE RID: 70318 RVA: 0x00065BC8 File Offset: 0x00063DC8
		[Token(Token = "0x60112AE")]
		[Address(RVA = "0x1CAB8B4", Offset = "0x1CAB8B4", VA = "0x1CAB8B4")]
		public GetAllTimePurchaseResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetAllTimePurchaseResponse);
		}

		// Token: 0x170020B9 RID: 8377
		// (get) Token: 0x060112AF RID: 70319 RVA: 0x00065BE0 File Offset: 0x00063DE0
		[Token(Token = "0x170020B9")]
		public int PurchaseAmount
		{
			[Token(Token = "0x60112AF")]
			[Address(RVA = "0x1CAB8FC", Offset = "0x1CAB8FC", VA = "0x1CAB8FC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020BA RID: 8378
		// (get) Token: 0x060112B0 RID: 70320 RVA: 0x00065BF8 File Offset: 0x00063DF8
		[Token(Token = "0x170020BA")]
		public long LastPurchaseTime
		{
			[Token(Token = "0x60112B0")]
			[Address(RVA = "0x1CAB940", Offset = "0x1CAB940", VA = "0x1CAB940")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x170020BB RID: 8379
		// (get) Token: 0x060112B1 RID: 70321 RVA: 0x00065C10 File Offset: 0x00063E10
		[Token(Token = "0x170020BB")]
		public ResponseStatusCode StatusCode
		{
			[Token(Token = "0x60112B1")]
			[Address(RVA = "0x1CAB988", Offset = "0x1CAB988", VA = "0x1CAB988")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x060112B2 RID: 70322 RVA: 0x00065C28 File Offset: 0x00063E28
		[Token(Token = "0x60112B2")]
		[Address(RVA = "0x1CAB9CC", Offset = "0x1CAB9CC", VA = "0x1CAB9CC")]
		public static Offset<GetAllTimePurchaseResponse> CreateGetAllTimePurchaseResponse(FlatBufferBuilder builder, int purchaseAmount = 0, long last_purchase_time = 0L, ResponseStatusCode statusCode = ResponseStatusCode.Success)
		{
			return default(Offset<GetAllTimePurchaseResponse>);
		}

		// Token: 0x060112B3 RID: 70323 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112B3")]
		[Address(RVA = "0x1CABB08", Offset = "0x1CABB08", VA = "0x1CABB08")]
		public static void StartGetAllTimePurchaseResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060112B4 RID: 70324 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112B4")]
		[Address(RVA = "0x1CABA5C", Offset = "0x1CABA5C", VA = "0x1CABA5C")]
		public static void AddPurchaseAmount(FlatBufferBuilder builder, int purchaseAmount)
		{
		}

		// Token: 0x060112B5 RID: 70325 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112B5")]
		[Address(RVA = "0x1CABA3C", Offset = "0x1CABA3C", VA = "0x1CABA3C")]
		public static void AddLastPurchaseTime(FlatBufferBuilder builder, long lastPurchaseTime)
		{
		}

		// Token: 0x060112B6 RID: 70326 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112B6")]
		[Address(RVA = "0x1CABA7C", Offset = "0x1CABA7C", VA = "0x1CABA7C")]
		public static void AddStatusCode(FlatBufferBuilder builder, ResponseStatusCode statusCode)
		{
		}

		// Token: 0x060112B7 RID: 70327 RVA: 0x00065C40 File Offset: 0x00063E40
		[Token(Token = "0x60112B7")]
		[Address(RVA = "0x1CABA9C", Offset = "0x1CABA9C", VA = "0x1CABA9C")]
		public static Offset<GetAllTimePurchaseResponse> EndGetAllTimePurchaseResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetAllTimePurchaseResponse>);
		}

		// Token: 0x0400E72D RID: 59181
		[Token(Token = "0x400E72D")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
