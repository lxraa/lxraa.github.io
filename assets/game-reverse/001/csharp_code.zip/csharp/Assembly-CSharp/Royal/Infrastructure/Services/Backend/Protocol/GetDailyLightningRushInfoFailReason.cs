﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C9 RID: 9161
	[Token(Token = "0x20023C9")]
	public enum GetDailyLightningRushInfoFailReason : sbyte
	{
		// Token: 0x0400E737 RID: 59191
		[Token(Token = "0x400E737")]
		None,
		// Token: 0x0400E738 RID: 59192
		[Token(Token = "0x400E738")]
		EventIsDeleted,
		// Token: 0x0400E739 RID: 59193
		[Token(Token = "0x400E739")]
		NotInEvent
	}
}
