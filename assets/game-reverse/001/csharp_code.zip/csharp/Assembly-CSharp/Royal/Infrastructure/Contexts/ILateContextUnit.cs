﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts
{
	// Token: 0x020025B0 RID: 9648
	[Token(Token = "0x20025B0")]
	public interface ILateContextUnit
	{
		// Token: 0x06012DB3 RID: 77235
		[Token(Token = "0x6012DB3")]
		void OnRemove();
	}
}
