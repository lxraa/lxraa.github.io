﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.LavaQuest
{
	// Token: 0x02002561 RID: 9569
	[Token(Token = "0x2002561")]
	public class EnterLavaQuestHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700278A RID: 10122
		// (get) Token: 0x06012B34 RID: 76596 RVA: 0x00078DE0 File Offset: 0x00076FE0
		[Token(Token = "0x1700278A")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B34")]
			[Address(RVA = "0x1ED0684", Offset = "0x1ED0684", VA = "0x1ED0684", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700278B RID: 10123
		// (get) Token: 0x06012B35 RID: 76597 RVA: 0x00078DF8 File Offset: 0x00076FF8
		[Token(Token = "0x1700278B")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B35")]
			[Address(RVA = "0x1ED068C", Offset = "0x1ED068C", VA = "0x1ED068C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700278C RID: 10124
		// (get) Token: 0x06012B36 RID: 76598 RVA: 0x00078E10 File Offset: 0x00077010
		// (set) Token: 0x06012B37 RID: 76599 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700278C")]
		private EnterLavaQuestResponse Response
		{
			[Token(Token = "0x6012B36")]
			[Address(RVA = "0x1ED0694", Offset = "0x1ED0694", VA = "0x1ED0694")]
			get
			{
				return default(EnterLavaQuestResponse);
			}
			[Token(Token = "0x6012B37")]
			[Address(RVA = "0x1ED06A0", Offset = "0x1ED06A0", VA = "0x1ED06A0")]
			set
			{
			}
		}

		// Token: 0x06012B38 RID: 76600 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B38")]
		[Address(RVA = "0x1ED06B0", Offset = "0x1ED06B0", VA = "0x1ED06B0")]
		public EnterLavaQuestHttpCommand(int startLevel, int leagueLevel, bool requestedWithLeague)
		{
		}

		// Token: 0x06012B39 RID: 76601 RVA: 0x00078E28 File Offset: 0x00077028
		[Token(Token = "0x6012B39")]
		[Address(RVA = "0x1ED06EC", Offset = "0x1ED06EC", VA = "0x1ED06EC", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B3A RID: 76602 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B3A")]
		[Address(RVA = "0x1ED0820", Offset = "0x1ED0820", VA = "0x1ED0820", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B3B RID: 76603 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B3B")]
		[Address(RVA = "0x1ED0970", Offset = "0x1ED0970", VA = "0x1ED0970", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBBD RID: 60349
		[Token(Token = "0x400EBBD")]
		[FieldOffset(Offset = "0x18")]
		private EnterLavaQuestResponse <Response>k__BackingField;

		// Token: 0x0400EBBE RID: 60350
		[Token(Token = "0x400EBBE")]
		[FieldOffset(Offset = "0x28")]
		private readonly int startLevel;

		// Token: 0x0400EBBF RID: 60351
		[Token(Token = "0x400EBBF")]
		[FieldOffset(Offset = "0x2C")]
		private readonly int leagueLevel;

		// Token: 0x0400EBC0 RID: 60352
		[Token(Token = "0x400EBC0")]
		[FieldOffset(Offset = "0x30")]
		private readonly bool requestedWithLeague;
	}
}
