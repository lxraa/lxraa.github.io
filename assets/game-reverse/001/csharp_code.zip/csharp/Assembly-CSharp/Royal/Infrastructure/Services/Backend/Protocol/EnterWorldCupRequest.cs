﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B1 RID: 9137
	[Token(Token = "0x20023B1")]
	public struct EnterWorldCupRequest : IFlatbufferObject
	{
		// Token: 0x17002082 RID: 8322
		// (get) Token: 0x060111E8 RID: 70120 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002082")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60111E8")]
			[Address(RVA = "0x1FA0764", Offset = "0x1FA0764", VA = "0x1FA0764", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060111E9 RID: 70121 RVA: 0x000651F0 File Offset: 0x000633F0
		[Token(Token = "0x60111E9")]
		[Address(RVA = "0x1FA076C", Offset = "0x1FA076C", VA = "0x1FA076C")]
		public static EnterWorldCupRequest GetRootAsEnterWorldCupRequest(ByteBuffer _bb)
		{
			return default(EnterWorldCupRequest);
		}

		// Token: 0x060111EA RID: 70122 RVA: 0x00065208 File Offset: 0x00063408
		[Token(Token = "0x60111EA")]
		[Address(RVA = "0x1FA0778", Offset = "0x1FA0778", VA = "0x1FA0778")]
		public static EnterWorldCupRequest GetRootAsEnterWorldCupRequest(ByteBuffer _bb, EnterWorldCupRequest obj)
		{
			return default(EnterWorldCupRequest);
		}

		// Token: 0x060111EB RID: 70123 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111EB")]
		[Address(RVA = "0x1FA0828", Offset = "0x1FA0828", VA = "0x1FA0828", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060111EC RID: 70124 RVA: 0x00065220 File Offset: 0x00063420
		[Token(Token = "0x60111EC")]
		[Address(RVA = "0x1FA07F0", Offset = "0x1FA07F0", VA = "0x1FA07F0")]
		public EnterWorldCupRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterWorldCupRequest);
		}

		// Token: 0x17002083 RID: 8323
		// (get) Token: 0x060111ED RID: 70125 RVA: 0x00065238 File Offset: 0x00063438
		[Token(Token = "0x17002083")]
		public int UserEventId
		{
			[Token(Token = "0x60111ED")]
			[Address(RVA = "0x1FA0838", Offset = "0x1FA0838", VA = "0x1FA0838")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002084 RID: 8324
		// (get) Token: 0x060111EE RID: 70126 RVA: 0x00065250 File Offset: 0x00063450
		[Token(Token = "0x17002084")]
		public WorldCupStage Stage
		{
			[Token(Token = "0x60111EE")]
			[Address(RVA = "0x1FA087C", Offset = "0x1FA087C", VA = "0x1FA087C")]
			get
			{
				return WorldCupStage.Upcoming;
			}
		}

		// Token: 0x17002085 RID: 8325
		// (get) Token: 0x060111EF RID: 70127 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002085")]
		public string Country
		{
			[Token(Token = "0x60111EF")]
			[Address(RVA = "0x1FA08C0", Offset = "0x1FA08C0", VA = "0x1FA08C0")]
			get
			{
				return null;
			}
		}

		// Token: 0x060111F0 RID: 70128 RVA: 0x00065268 File Offset: 0x00063468
		[Token(Token = "0x60111F0")]
		[Address(RVA = "0x1FA08FC", Offset = "0x1FA08FC", VA = "0x1FA08FC")]
		public ArraySegment<byte>? GetCountryBytes()
		{
			return null;
		}

		// Token: 0x060111F1 RID: 70129 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60111F1")]
		[Address(RVA = "0x1FA0934", Offset = "0x1FA0934", VA = "0x1FA0934")]
		public byte[] GetCountryArray()
		{
			return null;
		}

		// Token: 0x060111F2 RID: 70130 RVA: 0x00065280 File Offset: 0x00063480
		[Token(Token = "0x60111F2")]
		[Address(RVA = "0x1FA0980", Offset = "0x1FA0980", VA = "0x1FA0980")]
		public static Offset<EnterWorldCupRequest> CreateEnterWorldCupRequest(FlatBufferBuilder builder, int user_event_id = 0, WorldCupStage stage = WorldCupStage.Upcoming, [Optional] StringOffset countryOffset)
		{
			return default(Offset<EnterWorldCupRequest>);
		}

		// Token: 0x060111F3 RID: 70131 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111F3")]
		[Address(RVA = "0x1FA0ABC", Offset = "0x1FA0ABC", VA = "0x1FA0ABC")]
		public static void StartEnterWorldCupRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060111F4 RID: 70132 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111F4")]
		[Address(RVA = "0x1FA0A10", Offset = "0x1FA0A10", VA = "0x1FA0A10")]
		public static void AddUserEventId(FlatBufferBuilder builder, int userEventId)
		{
		}

		// Token: 0x060111F5 RID: 70133 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111F5")]
		[Address(RVA = "0x1FA0A30", Offset = "0x1FA0A30", VA = "0x1FA0A30")]
		public static void AddStage(FlatBufferBuilder builder, WorldCupStage stage)
		{
		}

		// Token: 0x060111F6 RID: 70134 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111F6")]
		[Address(RVA = "0x1FA09F0", Offset = "0x1FA09F0", VA = "0x1FA09F0")]
		public static void AddCountry(FlatBufferBuilder builder, StringOffset countryOffset)
		{
		}

		// Token: 0x060111F7 RID: 70135 RVA: 0x00065298 File Offset: 0x00063498
		[Token(Token = "0x60111F7")]
		[Address(RVA = "0x1FA0A50", Offset = "0x1FA0A50", VA = "0x1FA0A50")]
		public static Offset<EnterWorldCupRequest> EndEnterWorldCupRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterWorldCupRequest>);
		}

		// Token: 0x0400E6E3 RID: 59107
		[Token(Token = "0x400E6E3")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
