﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200237E RID: 9086
	[Token(Token = "0x200237E")]
	public struct DepreciatedCheckLeagueRequest : IFlatbufferObject
	{
		// Token: 0x17001FCC RID: 8140
		// (get) Token: 0x06010F3F RID: 69439 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FCC")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F3F")]
			[Address(RVA = "0x1F96604", Offset = "0x1F96604", VA = "0x1F96604", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F40 RID: 69440 RVA: 0x00062E98 File Offset: 0x00061098
		[Token(Token = "0x6010F40")]
		[Address(RVA = "0x1F9660C", Offset = "0x1F9660C", VA = "0x1F9660C")]
		public static DepreciatedCheckLeagueRequest GetRootAsDepreciatedCheckLeagueRequest(ByteBuffer _bb)
		{
			return default(DepreciatedCheckLeagueRequest);
		}

		// Token: 0x06010F41 RID: 69441 RVA: 0x00062EB0 File Offset: 0x000610B0
		[Token(Token = "0x6010F41")]
		[Address(RVA = "0x1F96618", Offset = "0x1F96618", VA = "0x1F96618")]
		public static DepreciatedCheckLeagueRequest GetRootAsDepreciatedCheckLeagueRequest(ByteBuffer _bb, DepreciatedCheckLeagueRequest obj)
		{
			return default(DepreciatedCheckLeagueRequest);
		}

		// Token: 0x06010F42 RID: 69442 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F42")]
		[Address(RVA = "0x1F966C8", Offset = "0x1F966C8", VA = "0x1F966C8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F43 RID: 69443 RVA: 0x00062EC8 File Offset: 0x000610C8
		[Token(Token = "0x6010F43")]
		[Address(RVA = "0x1F96690", Offset = "0x1F96690", VA = "0x1F96690")]
		public DepreciatedCheckLeagueRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(DepreciatedCheckLeagueRequest);
		}

		// Token: 0x06010F44 RID: 69444 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F44")]
		[Address(RVA = "0x1F966D8", Offset = "0x1F966D8", VA = "0x1F966D8")]
		public static void StartDepreciatedCheckLeagueRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F45 RID: 69445 RVA: 0x00062EE0 File Offset: 0x000610E0
		[Token(Token = "0x6010F45")]
		[Address(RVA = "0x1F966F0", Offset = "0x1F966F0", VA = "0x1F966F0")]
		public static Offset<DepreciatedCheckLeagueRequest> EndDepreciatedCheckLeagueRequest(FlatBufferBuilder builder)
		{
			return default(Offset<DepreciatedCheckLeagueRequest>);
		}

		// Token: 0x0400E697 RID: 59031
		[Token(Token = "0x400E697")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
