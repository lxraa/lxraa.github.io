﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002389 RID: 9097
	[Token(Token = "0x2002389")]
	public struct DragonNestLiveUpdateResponse : IFlatbufferObject
	{
		// Token: 0x17001FEF RID: 8175
		// (get) Token: 0x06010FCA RID: 69578 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FEF")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010FCA")]
			[Address(RVA = "0x1F98504", Offset = "0x1F98504", VA = "0x1F98504", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FCB RID: 69579 RVA: 0x000635E8 File Offset: 0x000617E8
		[Token(Token = "0x6010FCB")]
		[Address(RVA = "0x1F9850C", Offset = "0x1F9850C", VA = "0x1F9850C")]
		public static DragonNestLiveUpdateResponse GetRootAsDragonNestLiveUpdateResponse(ByteBuffer _bb)
		{
			return default(DragonNestLiveUpdateResponse);
		}

		// Token: 0x06010FCC RID: 69580 RVA: 0x00063600 File Offset: 0x00061800
		[Token(Token = "0x6010FCC")]
		[Address(RVA = "0x1F98518", Offset = "0x1F98518", VA = "0x1F98518")]
		public static DragonNestLiveUpdateResponse GetRootAsDragonNestLiveUpdateResponse(ByteBuffer _bb, DragonNestLiveUpdateResponse obj)
		{
			return default(DragonNestLiveUpdateResponse);
		}

		// Token: 0x06010FCD RID: 69581 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FCD")]
		[Address(RVA = "0x1F985C8", Offset = "0x1F985C8", VA = "0x1F985C8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010FCE RID: 69582 RVA: 0x00063618 File Offset: 0x00061818
		[Token(Token = "0x6010FCE")]
		[Address(RVA = "0x1F98590", Offset = "0x1F98590", VA = "0x1F98590")]
		public DragonNestLiveUpdateResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestLiveUpdateResponse);
		}

		// Token: 0x17001FF0 RID: 8176
		// (get) Token: 0x06010FCF RID: 69583 RVA: 0x00063630 File Offset: 0x00061830
		[Token(Token = "0x17001FF0")]
		public DragonNestScoreUpdate? ScoreUpdate
		{
			[Token(Token = "0x6010FCF")]
			[Address(RVA = "0x1F985D8", Offset = "0x1F985D8", VA = "0x1F985D8")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FF1 RID: 8177
		// (get) Token: 0x06010FD0 RID: 69584 RVA: 0x00063648 File Offset: 0x00061848
		[Token(Token = "0x17001FF1")]
		public DragonNestInvitationUpdate? InvitationUpdate
		{
			[Token(Token = "0x6010FD0")]
			[Address(RVA = "0x1F986C8", Offset = "0x1F986C8", VA = "0x1F986C8")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FD1 RID: 69585 RVA: 0x00063660 File Offset: 0x00061860
		[Token(Token = "0x6010FD1")]
		[Address(RVA = "0x1F98780", Offset = "0x1F98780", VA = "0x1F98780")]
		public static Offset<DragonNestLiveUpdateResponse> CreateDragonNestLiveUpdateResponse(FlatBufferBuilder builder, [Optional] Offset<DragonNestScoreUpdate> score_updateOffset, [Optional] Offset<DragonNestInvitationUpdate> invitationUpdateOffset)
		{
			return default(Offset<DragonNestLiveUpdateResponse>);
		}

		// Token: 0x06010FD2 RID: 69586 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FD2")]
		[Address(RVA = "0x1F98884", Offset = "0x1F98884", VA = "0x1F98884")]
		public static void StartDragonNestLiveUpdateResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010FD3 RID: 69587 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FD3")]
		[Address(RVA = "0x1F987F8", Offset = "0x1F987F8", VA = "0x1F987F8")]
		public static void AddScoreUpdate(FlatBufferBuilder builder, Offset<DragonNestScoreUpdate> scoreUpdateOffset)
		{
		}

		// Token: 0x06010FD4 RID: 69588 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FD4")]
		[Address(RVA = "0x1F987D8", Offset = "0x1F987D8", VA = "0x1F987D8")]
		public static void AddInvitationUpdate(FlatBufferBuilder builder, Offset<DragonNestInvitationUpdate> invitationUpdateOffset)
		{
		}

		// Token: 0x06010FD5 RID: 69589 RVA: 0x00063678 File Offset: 0x00061878
		[Token(Token = "0x6010FD5")]
		[Address(RVA = "0x1F98818", Offset = "0x1F98818", VA = "0x1F98818")]
		public static Offset<DragonNestLiveUpdateResponse> EndDragonNestLiveUpdateResponse(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestLiveUpdateResponse>);
		}

		// Token: 0x0400E6A2 RID: 59042
		[Token(Token = "0x400E6A2")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
