﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023DF RID: 9183
	[Token(Token = "0x20023DF")]
	public struct GetLavaQuestInfoResponse : IFlatbufferObject
	{
		// Token: 0x17002112 RID: 8466
		// (get) Token: 0x0601144A RID: 70730 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002112")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601144A")]
			[Address(RVA = "0x1CB2370", Offset = "0x1CB2370", VA = "0x1CB2370", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601144B RID: 70731 RVA: 0x00067290 File Offset: 0x00065490
		[Token(Token = "0x601144B")]
		[Address(RVA = "0x1CB2378", Offset = "0x1CB2378", VA = "0x1CB2378")]
		public static GetLavaQuestInfoResponse GetRootAsGetLavaQuestInfoResponse(ByteBuffer _bb)
		{
			return default(GetLavaQuestInfoResponse);
		}

		// Token: 0x0601144C RID: 70732 RVA: 0x000672A8 File Offset: 0x000654A8
		[Token(Token = "0x601144C")]
		[Address(RVA = "0x1CB2384", Offset = "0x1CB2384", VA = "0x1CB2384")]
		public static GetLavaQuestInfoResponse GetRootAsGetLavaQuestInfoResponse(ByteBuffer _bb, GetLavaQuestInfoResponse obj)
		{
			return default(GetLavaQuestInfoResponse);
		}

		// Token: 0x0601144D RID: 70733 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601144D")]
		[Address(RVA = "0x1CB2434", Offset = "0x1CB2434", VA = "0x1CB2434", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601144E RID: 70734 RVA: 0x000672C0 File Offset: 0x000654C0
		[Token(Token = "0x601144E")]
		[Address(RVA = "0x1CB23FC", Offset = "0x1CB23FC", VA = "0x1CB23FC")]
		public GetLavaQuestInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetLavaQuestInfoResponse);
		}

		// Token: 0x17002113 RID: 8467
		// (get) Token: 0x0601144F RID: 70735 RVA: 0x000672D8 File Offset: 0x000654D8
		[Token(Token = "0x17002113")]
		public LavaQuestUserGroupInfo? LavaQuestUserGroupInfo
		{
			[Token(Token = "0x601144F")]
			[Address(RVA = "0x1CB2444", Offset = "0x1CB2444", VA = "0x1CB2444")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002114 RID: 8468
		// (get) Token: 0x06011450 RID: 70736 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002114")]
		public string Config
		{
			[Token(Token = "0x6011450")]
			[Address(RVA = "0x1CB2504", Offset = "0x1CB2504", VA = "0x1CB2504")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011451 RID: 70737 RVA: 0x000672F0 File Offset: 0x000654F0
		[Token(Token = "0x6011451")]
		[Address(RVA = "0x1CB2540", Offset = "0x1CB2540", VA = "0x1CB2540")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06011452 RID: 70738 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011452")]
		[Address(RVA = "0x1CB2578", Offset = "0x1CB2578", VA = "0x1CB2578")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x06011453 RID: 70739 RVA: 0x00067308 File Offset: 0x00065508
		[Token(Token = "0x6011453")]
		[Address(RVA = "0x1CB25C4", Offset = "0x1CB25C4", VA = "0x1CB25C4")]
		public static Offset<GetLavaQuestInfoResponse> CreateGetLavaQuestInfoResponse(FlatBufferBuilder builder, [Optional] Offset<LavaQuestUserGroupInfo> lava_quest_user_group_infoOffset, [Optional] StringOffset configOffset)
		{
			return default(Offset<GetLavaQuestInfoResponse>);
		}

		// Token: 0x06011454 RID: 70740 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011454")]
		[Address(RVA = "0x1CB26C8", Offset = "0x1CB26C8", VA = "0x1CB26C8")]
		public static void StartGetLavaQuestInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011455 RID: 70741 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011455")]
		[Address(RVA = "0x1CB263C", Offset = "0x1CB263C", VA = "0x1CB263C")]
		public static void AddLavaQuestUserGroupInfo(FlatBufferBuilder builder, Offset<LavaQuestUserGroupInfo> lavaQuestUserGroupInfoOffset)
		{
		}

		// Token: 0x06011456 RID: 70742 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011456")]
		[Address(RVA = "0x1CB261C", Offset = "0x1CB261C", VA = "0x1CB261C")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06011457 RID: 70743 RVA: 0x00067320 File Offset: 0x00065520
		[Token(Token = "0x6011457")]
		[Address(RVA = "0x1CB265C", Offset = "0x1CB265C", VA = "0x1CB265C")]
		public static Offset<GetLavaQuestInfoResponse> EndGetLavaQuestInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetLavaQuestInfoResponse>);
		}

		// Token: 0x0400E74F RID: 59215
		[Token(Token = "0x400E74F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
