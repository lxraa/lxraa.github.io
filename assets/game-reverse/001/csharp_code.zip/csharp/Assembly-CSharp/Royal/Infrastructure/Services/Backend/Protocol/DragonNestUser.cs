﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200238F RID: 9103
	[Token(Token = "0x200238F")]
	public struct DragonNestUser : IFlatbufferObject
	{
		// Token: 0x17002001 RID: 8193
		// (get) Token: 0x06011012 RID: 69650 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002001")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011012")]
			[Address(RVA = "0x1F99640", Offset = "0x1F99640", VA = "0x1F99640", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011013 RID: 69651 RVA: 0x000639D8 File Offset: 0x00061BD8
		[Token(Token = "0x6011013")]
		[Address(RVA = "0x1F99648", Offset = "0x1F99648", VA = "0x1F99648")]
		public static DragonNestUser GetRootAsDragonNestUser(ByteBuffer _bb)
		{
			return default(DragonNestUser);
		}

		// Token: 0x06011014 RID: 69652 RVA: 0x000639F0 File Offset: 0x00061BF0
		[Token(Token = "0x6011014")]
		[Address(RVA = "0x1F99654", Offset = "0x1F99654", VA = "0x1F99654")]
		public static DragonNestUser GetRootAsDragonNestUser(ByteBuffer _bb, DragonNestUser obj)
		{
			return default(DragonNestUser);
		}

		// Token: 0x06011015 RID: 69653 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011015")]
		[Address(RVA = "0x1F996CC", Offset = "0x1F996CC", VA = "0x1F996CC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011016 RID: 69654 RVA: 0x00063A08 File Offset: 0x00061C08
		[Token(Token = "0x6011016")]
		[Address(RVA = "0x1F974E0", Offset = "0x1F974E0", VA = "0x1F974E0")]
		public DragonNestUser __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestUser);
		}

		// Token: 0x17002002 RID: 8194
		// (get) Token: 0x06011017 RID: 69655 RVA: 0x00063A20 File Offset: 0x00061C20
		[Token(Token = "0x17002002")]
		public long UserId
		{
			[Token(Token = "0x6011017")]
			[Address(RVA = "0x1F996DC", Offset = "0x1F996DC", VA = "0x1F996DC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17002003 RID: 8195
		// (get) Token: 0x06011018 RID: 69656 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002003")]
		public string Name
		{
			[Token(Token = "0x6011018")]
			[Address(RVA = "0x1F99724", Offset = "0x1F99724", VA = "0x1F99724")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011019 RID: 69657 RVA: 0x00063A38 File Offset: 0x00061C38
		[Token(Token = "0x6011019")]
		[Address(RVA = "0x1F99760", Offset = "0x1F99760", VA = "0x1F99760")]
		public ArraySegment<byte>? GetNameBytes()
		{
			return null;
		}

		// Token: 0x0601101A RID: 69658 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601101A")]
		[Address(RVA = "0x1F99798", Offset = "0x1F99798", VA = "0x1F99798")]
		public byte[] GetNameArray()
		{
			return null;
		}

		// Token: 0x17002004 RID: 8196
		// (get) Token: 0x0601101B RID: 69659 RVA: 0x00063A50 File Offset: 0x00061C50
		[Token(Token = "0x17002004")]
		public bool DeprecatedIsGold
		{
			[Token(Token = "0x601101B")]
			[Address(RVA = "0x1F997E4", Offset = "0x1F997E4", VA = "0x1F997E4")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17002005 RID: 8197
		// (get) Token: 0x0601101C RID: 69660 RVA: 0x00063A68 File Offset: 0x00061C68
		[Token(Token = "0x17002005")]
		public bool HasSpecialNameStyle
		{
			[Token(Token = "0x601101C")]
			[Address(RVA = "0x1F9982C", Offset = "0x1F9982C", VA = "0x1F9982C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17002006 RID: 8198
		// (get) Token: 0x0601101D RID: 69661 RVA: 0x00063A80 File Offset: 0x00061C80
		[Token(Token = "0x17002006")]
		public ProfileSetting? ProfileSetting
		{
			[Token(Token = "0x601101D")]
			[Address(RVA = "0x1F99874", Offset = "0x1F99874", VA = "0x1F99874")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601101E RID: 69662 RVA: 0x00063A98 File Offset: 0x00061C98
		[Token(Token = "0x601101E")]
		[Address(RVA = "0x1F99934", Offset = "0x1F99934", VA = "0x1F99934")]
		public static Offset<DragonNestUser> CreateDragonNestUser(FlatBufferBuilder builder, long user_id = 0L, [Optional] StringOffset nameOffset, bool deprecated_is_gold = false, bool has_special_name_style = false, [Optional] Offset<ProfileSetting> profile_settingOffset)
		{
			return default(Offset<DragonNestUser>);
		}

		// Token: 0x0601101F RID: 69663 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601101F")]
		[Address(RVA = "0x1F99AD8", Offset = "0x1F99AD8", VA = "0x1F99AD8")]
		public static void StartDragonNestUser(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011020 RID: 69664 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011020")]
		[Address(RVA = "0x1F999CC", Offset = "0x1F999CC", VA = "0x1F999CC")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06011021 RID: 69665 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011021")]
		[Address(RVA = "0x1F99A0C", Offset = "0x1F99A0C", VA = "0x1F99A0C")]
		public static void AddName(FlatBufferBuilder builder, StringOffset nameOffset)
		{
		}

		// Token: 0x06011022 RID: 69666 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011022")]
		[Address(RVA = "0x1F99A4C", Offset = "0x1F99A4C", VA = "0x1F99A4C")]
		public static void AddDeprecatedIsGold(FlatBufferBuilder builder, bool deprecatedIsGold)
		{
		}

		// Token: 0x06011023 RID: 69667 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011023")]
		[Address(RVA = "0x1F99A2C", Offset = "0x1F99A2C", VA = "0x1F99A2C")]
		public static void AddHasSpecialNameStyle(FlatBufferBuilder builder, bool hasSpecialNameStyle)
		{
		}

		// Token: 0x06011024 RID: 69668 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011024")]
		[Address(RVA = "0x1F999EC", Offset = "0x1F999EC", VA = "0x1F999EC")]
		public static void AddProfileSetting(FlatBufferBuilder builder, Offset<ProfileSetting> profileSettingOffset)
		{
		}

		// Token: 0x06011025 RID: 69669 RVA: 0x00063AB0 File Offset: 0x00061CB0
		[Token(Token = "0x6011025")]
		[Address(RVA = "0x1F99A6C", Offset = "0x1F99A6C", VA = "0x1F99A6C")]
		public static Offset<DragonNestUser> EndDragonNestUser(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestUser>);
		}

		// Token: 0x0400E6A8 RID: 59048
		[Token(Token = "0x400E6A8")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
