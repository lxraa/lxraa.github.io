﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.MissionPursuit
{
	// Token: 0x02002557 RID: 9559
	[Token(Token = "0x2002557")]
	public class GetMissionPursuitInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700276F RID: 10095
		// (get) Token: 0x06012AE6 RID: 76518 RVA: 0x00078A20 File Offset: 0x00076C20
		[Token(Token = "0x1700276F")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AE6")]
			[Address(RVA = "0x1ECE31C", Offset = "0x1ECE31C", VA = "0x1ECE31C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002770 RID: 10096
		// (get) Token: 0x06012AE7 RID: 76519 RVA: 0x00078A38 File Offset: 0x00076C38
		[Token(Token = "0x17002770")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AE7")]
			[Address(RVA = "0x1ECE324", Offset = "0x1ECE324", VA = "0x1ECE324", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AE8 RID: 76520 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AE8")]
		[Address(RVA = "0x1ECE32C", Offset = "0x1ECE32C", VA = "0x1ECE32C")]
		public GetMissionPursuitInfoHttpCommand(int eventId)
		{
		}

		// Token: 0x06012AE9 RID: 76521 RVA: 0x00078A50 File Offset: 0x00076C50
		[Token(Token = "0x6012AE9")]
		[Address(RVA = "0x1ECE35C", Offset = "0x1ECE35C", VA = "0x1ECE35C", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012AEA RID: 76522 RVA: 0x00078A68 File Offset: 0x00076C68
		[Token(Token = "0x6012AEA")]
		[Address(RVA = "0x1ECE41C", Offset = "0x1ECE41C", VA = "0x1ECE41C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AEB RID: 76523 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AEB")]
		[Address(RVA = "0x1ECE43C", Offset = "0x1ECE43C", VA = "0x1ECE43C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AEC RID: 76524 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AEC")]
		[Address(RVA = "0x1ECE518", Offset = "0x1ECE518", VA = "0x1ECE518", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBAE RID: 60334
		[Token(Token = "0x400EBAE")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;
	}
}
