﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002356 RID: 9046
	[Token(Token = "0x2002356")]
	public struct ChatProfile : IFlatbufferObject
	{
		// Token: 0x17001F1A RID: 7962
		// (get) Token: 0x06010CC5 RID: 68805 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F1A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010CC5")]
			[Address(RVA = "0x2147B10", Offset = "0x2147B10", VA = "0x2147B10", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CC6 RID: 68806 RVA: 0x00060E58 File Offset: 0x0005F058
		[Token(Token = "0x6010CC6")]
		[Address(RVA = "0x2147B18", Offset = "0x2147B18", VA = "0x2147B18")]
		public static ChatProfile GetRootAsChatProfile(ByteBuffer _bb)
		{
			return default(ChatProfile);
		}

		// Token: 0x06010CC7 RID: 68807 RVA: 0x00060E70 File Offset: 0x0005F070
		[Token(Token = "0x6010CC7")]
		[Address(RVA = "0x2147B24", Offset = "0x2147B24", VA = "0x2147B24")]
		public static ChatProfile GetRootAsChatProfile(ByteBuffer _bb, ChatProfile obj)
		{
			return default(ChatProfile);
		}

		// Token: 0x06010CC8 RID: 68808 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CC8")]
		[Address(RVA = "0x2147B9C", Offset = "0x2147B9C", VA = "0x2147B9C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010CC9 RID: 68809 RVA: 0x00060E88 File Offset: 0x0005F088
		[Token(Token = "0x6010CC9")]
		[Address(RVA = "0x214368C", Offset = "0x214368C", VA = "0x214368C")]
		public ChatProfile __assign(int _i, ByteBuffer _bb)
		{
			return default(ChatProfile);
		}

		// Token: 0x17001F1B RID: 7963
		// (get) Token: 0x06010CCA RID: 68810 RVA: 0x00060EA0 File Offset: 0x0005F0A0
		[Token(Token = "0x17001F1B")]
		public int Frame
		{
			[Token(Token = "0x6010CCA")]
			[Address(RVA = "0x2147BAC", Offset = "0x2147BAC", VA = "0x2147BAC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F1C RID: 7964
		// (get) Token: 0x06010CCB RID: 68811 RVA: 0x00060EB8 File Offset: 0x0005F0B8
		[Token(Token = "0x17001F1C")]
		public int Avatar
		{
			[Token(Token = "0x6010CCB")]
			[Address(RVA = "0x2147BF0", Offset = "0x2147BF0", VA = "0x2147BF0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F1D RID: 7965
		// (get) Token: 0x06010CCC RID: 68812 RVA: 0x00060ED0 File Offset: 0x0005F0D0
		[Token(Token = "0x17001F1D")]
		public long FacebookId
		{
			[Token(Token = "0x6010CCC")]
			[Address(RVA = "0x2147C34", Offset = "0x2147C34", VA = "0x2147C34")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F1E RID: 7966
		// (get) Token: 0x06010CCD RID: 68813 RVA: 0x00060EE8 File Offset: 0x0005F0E8
		[Token(Token = "0x17001F1E")]
		public int Badge
		{
			[Token(Token = "0x6010CCD")]
			[Address(RVA = "0x2147C7C", Offset = "0x2147C7C", VA = "0x2147C7C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F1F RID: 7967
		// (get) Token: 0x06010CCE RID: 68814 RVA: 0x00060F00 File Offset: 0x0005F100
		[Token(Token = "0x17001F1F")]
		public int NameStyle
		{
			[Token(Token = "0x6010CCE")]
			[Address(RVA = "0x2147CC0", Offset = "0x2147CC0", VA = "0x2147CC0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010CCF RID: 68815 RVA: 0x00060F18 File Offset: 0x0005F118
		[Token(Token = "0x6010CCF")]
		[Address(RVA = "0x21407E0", Offset = "0x21407E0", VA = "0x21407E0")]
		public static Offset<ChatProfile> CreateChatProfile(FlatBufferBuilder builder, int frame = 0, int avatar = 0, long facebook_id = 0L, int badge = 0, int name_style = 0)
		{
			return default(Offset<ChatProfile>);
		}

		// Token: 0x06010CD0 RID: 68816 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CD0")]
		[Address(RVA = "0x2147E10", Offset = "0x2147E10", VA = "0x2147E10")]
		public static void StartChatProfile(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010CD1 RID: 68817 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CD1")]
		[Address(RVA = "0x2147D84", Offset = "0x2147D84", VA = "0x2147D84")]
		public static void AddFrame(FlatBufferBuilder builder, int frame)
		{
		}

		// Token: 0x06010CD2 RID: 68818 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CD2")]
		[Address(RVA = "0x2147D64", Offset = "0x2147D64", VA = "0x2147D64")]
		public static void AddAvatar(FlatBufferBuilder builder, int avatar)
		{
		}

		// Token: 0x06010CD3 RID: 68819 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CD3")]
		[Address(RVA = "0x2147D04", Offset = "0x2147D04", VA = "0x2147D04")]
		public static void AddFacebookId(FlatBufferBuilder builder, long facebookId)
		{
		}

		// Token: 0x06010CD4 RID: 68820 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CD4")]
		[Address(RVA = "0x2147D44", Offset = "0x2147D44", VA = "0x2147D44")]
		public static void AddBadge(FlatBufferBuilder builder, int badge)
		{
		}

		// Token: 0x06010CD5 RID: 68821 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CD5")]
		[Address(RVA = "0x2147D24", Offset = "0x2147D24", VA = "0x2147D24")]
		public static void AddNameStyle(FlatBufferBuilder builder, int nameStyle)
		{
		}

		// Token: 0x06010CD6 RID: 68822 RVA: 0x00060F30 File Offset: 0x0005F130
		[Token(Token = "0x6010CD6")]
		[Address(RVA = "0x2147DA4", Offset = "0x2147DA4", VA = "0x2147DA4")]
		public static Offset<ChatProfile> EndChatProfile(FlatBufferBuilder builder)
		{
			return default(Offset<ChatProfile>);
		}

		// Token: 0x0400E65C RID: 58972
		[Token(Token = "0x400E65C")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
