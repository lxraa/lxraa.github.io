﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002381 RID: 9089
	[Token(Token = "0x2002381")]
	public struct DetachUserFromDeviceResponse : IFlatbufferObject
	{
		// Token: 0x17001FD3 RID: 8147
		// (get) Token: 0x06010F60 RID: 69472 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FD3")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F60")]
			[Address(RVA = "0x1F96CCC", Offset = "0x1F96CCC", VA = "0x1F96CCC", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F61 RID: 69473 RVA: 0x00063048 File Offset: 0x00061248
		[Token(Token = "0x6010F61")]
		[Address(RVA = "0x1F96CD4", Offset = "0x1F96CD4", VA = "0x1F96CD4")]
		public static DetachUserFromDeviceResponse GetRootAsDetachUserFromDeviceResponse(ByteBuffer _bb)
		{
			return default(DetachUserFromDeviceResponse);
		}

		// Token: 0x06010F62 RID: 69474 RVA: 0x00063060 File Offset: 0x00061260
		[Token(Token = "0x6010F62")]
		[Address(RVA = "0x1F96CE0", Offset = "0x1F96CE0", VA = "0x1F96CE0")]
		public static DetachUserFromDeviceResponse GetRootAsDetachUserFromDeviceResponse(ByteBuffer _bb, DetachUserFromDeviceResponse obj)
		{
			return default(DetachUserFromDeviceResponse);
		}

		// Token: 0x06010F63 RID: 69475 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F63")]
		[Address(RVA = "0x1F96D90", Offset = "0x1F96D90", VA = "0x1F96D90", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F64 RID: 69476 RVA: 0x00063078 File Offset: 0x00061278
		[Token(Token = "0x6010F64")]
		[Address(RVA = "0x1F96D58", Offset = "0x1F96D58", VA = "0x1F96D58")]
		public DetachUserFromDeviceResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(DetachUserFromDeviceResponse);
		}

		// Token: 0x17001FD4 RID: 8148
		// (get) Token: 0x06010F65 RID: 69477 RVA: 0x00063090 File Offset: 0x00061290
		[Token(Token = "0x17001FD4")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010F65")]
			[Address(RVA = "0x1F96DA0", Offset = "0x1F96DA0", VA = "0x1F96DA0")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001FD5 RID: 8149
		// (get) Token: 0x06010F66 RID: 69478 RVA: 0x000630A8 File Offset: 0x000612A8
		[Token(Token = "0x17001FD5")]
		public long DetachedUserId
		{
			[Token(Token = "0x6010F66")]
			[Address(RVA = "0x1F96DE4", Offset = "0x1F96DE4", VA = "0x1F96DE4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010F67 RID: 69479 RVA: 0x000630C0 File Offset: 0x000612C0
		[Token(Token = "0x6010F67")]
		[Address(RVA = "0x1F96E2C", Offset = "0x1F96E2C", VA = "0x1F96E2C")]
		public static Offset<DetachUserFromDeviceResponse> CreateDetachUserFromDeviceResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, long detached_user_id = 0L)
		{
			return default(Offset<DetachUserFromDeviceResponse>);
		}

		// Token: 0x06010F68 RID: 69480 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F68")]
		[Address(RVA = "0x1F96F30", Offset = "0x1F96F30", VA = "0x1F96F30")]
		public static void StartDetachUserFromDeviceResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F69 RID: 69481 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F69")]
		[Address(RVA = "0x1F96EA4", Offset = "0x1F96EA4", VA = "0x1F96EA4")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010F6A RID: 69482 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F6A")]
		[Address(RVA = "0x1F96E84", Offset = "0x1F96E84", VA = "0x1F96E84")]
		public static void AddDetachedUserId(FlatBufferBuilder builder, long detachedUserId)
		{
		}

		// Token: 0x06010F6B RID: 69483 RVA: 0x000630D8 File Offset: 0x000612D8
		[Token(Token = "0x6010F6B")]
		[Address(RVA = "0x1F96EC4", Offset = "0x1F96EC4", VA = "0x1F96EC4")]
		public static Offset<DetachUserFromDeviceResponse> EndDetachUserFromDeviceResponse(FlatBufferBuilder builder)
		{
			return default(Offset<DetachUserFromDeviceResponse>);
		}

		// Token: 0x0400E69A RID: 59034
		[Token(Token = "0x400E69A")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
