﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using Royal.Scenes.Game.Ui.Landscape;
using Royal.Scenes.Home.Ui.Sections.Home.Landscape;
using UnityEngine;

namespace Royal.Infrastructure.Contexts.Units
{
	// Token: 0x020025B2 RID: 9650
	[Token(Token = "0x20025B2")]
	public class CameraManager : IContextBehaviour, IContextUnit
	{
		// Token: 0x170027DE RID: 10206
		// (get) Token: 0x06012DB4 RID: 77236 RVA: 0x00079A40 File Offset: 0x00077C40
		[Token(Token = "0x170027DE")]
		public float WideDeviceCameraWidth
		{
			[Token(Token = "0x6012DB4")]
			[Address(RVA = "0x24415F4", Offset = "0x24415F4", VA = "0x24415F4")]
			get
			{
				return 0f;
			}
		}

		// Token: 0x170027DF RID: 10207
		// (get) Token: 0x06012DB5 RID: 77237 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170027DF")]
		public static CameraManager Current
		{
			[Token(Token = "0x6012DB5")]
			[Address(RVA = "0x2441660", Offset = "0x2441660", VA = "0x2441660")]
			get
			{
				return null;
			}
		}

		// Token: 0x170027E0 RID: 10208
		// (get) Token: 0x06012DB6 RID: 77238 RVA: 0x00079A58 File Offset: 0x00077C58
		[Token(Token = "0x170027E0")]
		public static bool IsLandscape
		{
			[Token(Token = "0x6012DB6")]
			[Address(RVA = "0x24416C8", Offset = "0x24416C8", VA = "0x24416C8")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170027E1 RID: 10209
		// (get) Token: 0x06012DB7 RID: 77239 RVA: 0x00079A70 File Offset: 0x00077C70
		[Token(Token = "0x170027E1")]
		public int Id
		{
			[Token(Token = "0x6012DB7")]
			[Address(RVA = "0x244172C", Offset = "0x244172C", VA = "0x244172C", Slot = "5")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1400009F RID: 159
		// (add) Token: 0x06012DB8 RID: 77240 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012DB9 RID: 77241 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1400009F")]
		public static event CameraManager.OrientationChange OnOrientationChange
		{
			[Token(Token = "0x6012DB8")]
			[Address(RVA = "0x2441734", Offset = "0x2441734", VA = "0x2441734")]
			add
			{
			}
			[Token(Token = "0x6012DB9")]
			[Address(RVA = "0x24417A0", Offset = "0x24417A0", VA = "0x24417A0")]
			remove
			{
			}
		}

		// Token: 0x06012DBA RID: 77242 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DBA")]
		[Address(RVA = "0x2441804", Offset = "0x2441804", VA = "0x2441804")]
		public static void DisableOrientation(OrientationDisabler orientationDisabler)
		{
		}

		// Token: 0x06012DBB RID: 77243 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DBB")]
		[Address(RVA = "0x24418EC", Offset = "0x24418EC", VA = "0x24418EC")]
		public static void EnableOrientation(OrientationDisabler orientationDisabler)
		{
		}

		// Token: 0x06012DBC RID: 77244 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DBC")]
		[Address(RVA = "0x2441948", Offset = "0x2441948", VA = "0x2441948")]
		public static void ArrangeAreaViewOnOrientationChangeOrder()
		{
		}

		// Token: 0x170027E2 RID: 10210
		// (get) Token: 0x06012DBD RID: 77245 RVA: 0x00079A88 File Offset: 0x00077C88
		[Token(Token = "0x170027E2")]
		private bool IsOrientationEnabled
		{
			[Token(Token = "0x6012DBD")]
			[Address(RVA = "0x2441BB4", Offset = "0x2441BB4", VA = "0x2441BB4")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06012DBE RID: 77246 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DBE")]
		[Address(RVA = "0x2441C04", Offset = "0x2441C04", VA = "0x2441C04", Slot = "6")]
		public void Bind()
		{
		}

		// Token: 0x06012DBF RID: 77247 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DBF")]
		[Address(RVA = "0x2441FC8", Offset = "0x2441FC8", VA = "0x2441FC8")]
		private void OnAppResumed()
		{
		}

		// Token: 0x06012DC0 RID: 77248 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DC0")]
		[Address(RVA = "0x2442270", Offset = "0x2442270", VA = "0x2442270")]
		public void ResetOrientationLock()
		{
		}

		// Token: 0x06012DC1 RID: 77249 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DC1")]
		[Address(RVA = "0x2441860", Offset = "0x2441860", VA = "0x2441860")]
		private void SetOrientationActive(bool isActive, OrientationDisabler orientationDisabler)
		{
		}

		// Token: 0x06012DC2 RID: 77250 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DC2")]
		[Address(RVA = "0x2441FCC", Offset = "0x2441FCC", VA = "0x2441FCC")]
		private void SetDeviceToAutoRotation()
		{
		}

		// Token: 0x06012DC3 RID: 77251 RVA: 0x00079AA0 File Offset: 0x00077CA0
		[Token(Token = "0x6012DC3")]
		[Address(RVA = "0x24422EC", Offset = "0x24422EC", VA = "0x24422EC")]
		private static bool DeviceAutoRotationIsOn()
		{
			return default(bool);
		}

		// Token: 0x06012DC4 RID: 77252 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DC4")]
		[Address(RVA = "0x244267C", Offset = "0x244267C", VA = "0x244267C")]
		private void OnSceneWillLoad(int scene)
		{
		}

		// Token: 0x06012DC5 RID: 77253 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DC5")]
		[Address(RVA = "0x24426D0", Offset = "0x24426D0", VA = "0x24426D0")]
		private void InitOrientation()
		{
		}

		// Token: 0x06012DC6 RID: 77254 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DC6")]
		[Address(RVA = "0x24422B4", Offset = "0x24422B4", VA = "0x24422B4")]
		private void EnableOrientation()
		{
		}

		// Token: 0x06012DC7 RID: 77255 RVA: 0x00079AB8 File Offset: 0x00077CB8
		[Token(Token = "0x6012DC7")]
		[Address(RVA = "0x2441798", Offset = "0x2441798", VA = "0x2441798")]
		public bool IsDeviceSupportLandscape()
		{
			return default(bool);
		}

		// Token: 0x06012DC8 RID: 77256 RVA: 0x00079AD0 File Offset: 0x00077CD0
		[Token(Token = "0x6012DC8")]
		[Address(RVA = "0x2441724", Offset = "0x2441724", VA = "0x2441724")]
		private bool GetIsLandscape()
		{
			return default(bool);
		}

		// Token: 0x06012DC9 RID: 77257 RVA: 0x00079AE8 File Offset: 0x00077CE8
		[Token(Token = "0x6012DC9")]
		[Address(RVA = "0x24429A8", Offset = "0x24429A8", VA = "0x24429A8")]
		private float SquarishDeviceGameCameraWidth()
		{
			return 0f;
		}

		// Token: 0x06012DCA RID: 77258 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DCA")]
		[Address(RVA = "0x24429B4", Offset = "0x24429B4", VA = "0x24429B4", Slot = "4")]
		public void ManualUpdate()
		{
		}

		// Token: 0x06012DCB RID: 77259 RVA: 0x00079B00 File Offset: 0x00077D00
		[Token(Token = "0x6012DCB")]
		[Address(RVA = "0x2442344", Offset = "0x2442344", VA = "0x2442344")]
		private ScreenOrientation GetReliableScreenOrientation()
		{
			return ScreenOrientation.Unknown;
		}

		// Token: 0x06012DCC RID: 77260 RVA: 0x00079B18 File Offset: 0x00077D18
		[Token(Token = "0x6012DCC")]
		[Address(RVA = "0x24422F4", Offset = "0x24422F4", VA = "0x24422F4")]
		private ScreenOrientation GetScreenOrientationOfDevice()
		{
			return ScreenOrientation.Unknown;
		}

		// Token: 0x06012DCD RID: 77261 RVA: 0x00079B30 File Offset: 0x00077D30
		[Token(Token = "0x6012DCD")]
		[Address(RVA = "0x2443024", Offset = "0x2443024", VA = "0x2443024")]
		private bool IsOrientationReliable(ScreenOrientation screenOrientation)
		{
			return default(bool);
		}

		// Token: 0x06012DCE RID: 77262 RVA: 0x00079B48 File Offset: 0x00077D48
		[Token(Token = "0x6012DCE")]
		[Address(RVA = "0x2442A04", Offset = "0x2442A04", VA = "0x2442A04")]
		private bool IsSameOrientationIssue()
		{
			return default(bool);
		}

		// Token: 0x06012DCF RID: 77263 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DCF")]
		[Address(RVA = "0x2442A0C", Offset = "0x2442A0C", VA = "0x2442A0C")]
		private void ArrangeOrientation(ScreenOrientation screenOrientation)
		{
		}

		// Token: 0x06012DD0 RID: 77264 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DD0")]
		[Address(RVA = "0x2443598", Offset = "0x2443598", VA = "0x2443598")]
		public void SetPosition(Vector3 position)
		{
		}

		// Token: 0x06012DD1 RID: 77265 RVA: 0x00079B60 File Offset: 0x00077D60
		[Token(Token = "0x6012DD1")]
		[Address(RVA = "0x24435E8", Offset = "0x24435E8", VA = "0x24435E8")]
		public Vector3 GetPosition()
		{
			return default(Vector3);
		}

		// Token: 0x06012DD2 RID: 77266 RVA: 0x00079B78 File Offset: 0x00077D78
		[Token(Token = "0x6012DD2")]
		[Address(RVA = "0x2443610", Offset = "0x2443610", VA = "0x2443610")]
		public Vector2 GetPositionVector2()
		{
			return default(Vector2);
		}

		// Token: 0x06012DD3 RID: 77267 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DD3")]
		[Address(RVA = "0x2443638", Offset = "0x2443638", VA = "0x2443638")]
		public void SetSceneCamera(Camera sceneCamera, int scene)
		{
		}

		// Token: 0x06012DD4 RID: 77268 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DD4")]
		[Address(RVA = "0x2443030", Offset = "0x2443030", VA = "0x2443030")]
		private void UpdateSizeParameters(int scene)
		{
		}

		// Token: 0x06012DD5 RID: 77269 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DD5")]
		[Address(RVA = "0x244397C", Offset = "0x244397C", VA = "0x244397C")]
		private void ResetSizeForScaledGame()
		{
		}

		// Token: 0x06012DD6 RID: 77270 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012DD6")]
		[Address(RVA = "0x2443AA8", Offset = "0x2443AA8", VA = "0x2443AA8")]
		public Camera GetCamera()
		{
			return null;
		}

		// Token: 0x06012DD7 RID: 77271 RVA: 0x00079B90 File Offset: 0x00077D90
		[Token(Token = "0x6012DD7")]
		[Address(RVA = "0x2443AB0", Offset = "0x2443AB0", VA = "0x2443AB0")]
		public float GetHeight()
		{
			return 0f;
		}

		// Token: 0x06012DD8 RID: 77272 RVA: 0x00079BA8 File Offset: 0x00077DA8
		[Token(Token = "0x6012DD8")]
		[Address(RVA = "0x2443AB8", Offset = "0x2443AB8", VA = "0x2443AB8")]
		public float GetWidth()
		{
			return 0f;
		}

		// Token: 0x06012DD9 RID: 77273 RVA: 0x00079BC0 File Offset: 0x00077DC0
		[Token(Token = "0x6012DD9")]
		[Address(RVA = "0x2443AC0", Offset = "0x2443AC0", VA = "0x2443AC0")]
		public float GetWidthBetweenLandscapeFlags()
		{
			return 0f;
		}

		// Token: 0x06012DDA RID: 77274 RVA: 0x00079BD8 File Offset: 0x00077DD8
		[Token(Token = "0x6012DDA")]
		[Address(RVA = "0x2443AE8", Offset = "0x2443AE8", VA = "0x2443AE8")]
		public float GetPortraitWidthOrLandscapeFlagsGap()
		{
			return 0f;
		}

		// Token: 0x06012DDB RID: 77275 RVA: 0x00079BF0 File Offset: 0x00077DF0
		[Token(Token = "0x6012DDB")]
		[Address(RVA = "0x2443AF0", Offset = "0x2443AF0", VA = "0x2443AF0")]
		public float GetPortraitWidthOrLandscapeFlagsGap(bool isLandscape)
		{
			return 0f;
		}

		// Token: 0x06012DDC RID: 77276 RVA: 0x00079C08 File Offset: 0x00077E08
		[Token(Token = "0x6012DDC")]
		[Address(RVA = "0x2443B24", Offset = "0x2443B24", VA = "0x2443B24")]
		public float ScreenToWorldUnit(float screenUnits)
		{
			return 0f;
		}

		// Token: 0x06012DDD RID: 77277 RVA: 0x00079C20 File Offset: 0x00077E20
		[Token(Token = "0x6012DDD")]
		[Address(RVA = "0x2443B54", Offset = "0x2443B54", VA = "0x2443B54")]
		private float WidthPixelRatio()
		{
			return 0f;
		}

		// Token: 0x06012DDE RID: 77278 RVA: 0x00079C38 File Offset: 0x00077E38
		[Token(Token = "0x6012DDE")]
		[Address(RVA = "0x2443B7C", Offset = "0x2443B7C", VA = "0x2443B7C")]
		public Vector2 GetCenterPosition()
		{
			return default(Vector2);
		}

		// Token: 0x06012DDF RID: 77279 RVA: 0x00079C50 File Offset: 0x00077E50
		[Token(Token = "0x6012DDF")]
		[Address(RVA = "0x2443BA4", Offset = "0x2443BA4", VA = "0x2443BA4")]
		public Vector3 GetTopCenterOfCamera()
		{
			return default(Vector3);
		}

		// Token: 0x06012DE0 RID: 77280 RVA: 0x00079C68 File Offset: 0x00077E68
		[Token(Token = "0x6012DE0")]
		[Address(RVA = "0x2443C0C", Offset = "0x2443C0C", VA = "0x2443C0C")]
		public Vector3 GetBottomCenterOfCamera()
		{
			return default(Vector3);
		}

		// Token: 0x06012DE1 RID: 77281 RVA: 0x00079C80 File Offset: 0x00077E80
		[Token(Token = "0x6012DE1")]
		[Address(RVA = "0x2443C74", Offset = "0x2443C74", VA = "0x2443C74")]
		public Vector3 GetLeftCenterOfCamera()
		{
			return default(Vector3);
		}

		// Token: 0x06012DE2 RID: 77282 RVA: 0x00079C98 File Offset: 0x00077E98
		[Token(Token = "0x6012DE2")]
		[Address(RVA = "0x2443CB4", Offset = "0x2443CB4", VA = "0x2443CB4")]
		public Vector3 GetLeftCenterOfCameraOrLandscapeFlagsGap()
		{
			return default(Vector3);
		}

		// Token: 0x06012DE3 RID: 77283 RVA: 0x00079CB0 File Offset: 0x00077EB0
		[Token(Token = "0x6012DE3")]
		[Address(RVA = "0x2443CF4", Offset = "0x2443CF4", VA = "0x2443CF4")]
		public Vector3 GetRightCenterOfCamera()
		{
			return default(Vector3);
		}

		// Token: 0x06012DE4 RID: 77284 RVA: 0x00079CC8 File Offset: 0x00077EC8
		[Token(Token = "0x6012DE4")]
		[Address(RVA = "0x2443D34", Offset = "0x2443D34", VA = "0x2443D34")]
		public Vector3 GetRightCenterOfCameraOrLandscapeFlagsGap()
		{
			return default(Vector3);
		}

		// Token: 0x06012DE5 RID: 77285 RVA: 0x00079CE0 File Offset: 0x00077EE0
		[Token(Token = "0x6012DE5")]
		[Address(RVA = "0x2443D74", Offset = "0x2443D74", VA = "0x2443D74")]
		public Vector3 GetSafeTopCenterOfCamera()
		{
			return default(Vector3);
		}

		// Token: 0x06012DE6 RID: 77286 RVA: 0x00079CF8 File Offset: 0x00077EF8
		[Token(Token = "0x6012DE6")]
		[Address(RVA = "0x2443E9C", Offset = "0x2443E9C", VA = "0x2443E9C")]
		public Vector3 GetSafeBottomCenterOfCamera()
		{
			return default(Vector3);
		}

		// Token: 0x06012DE7 RID: 77287 RVA: 0x00079D10 File Offset: 0x00077F10
		[Token(Token = "0x6012DE7")]
		[Address(RVA = "0x2443E60", Offset = "0x2443E60", VA = "0x2443E60")]
		private float GetLegacyOffset()
		{
			return 0f;
		}

		// Token: 0x06012DE8 RID: 77288 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DE8")]
		[Address(RVA = "0x244368C", Offset = "0x244368C", VA = "0x244368C")]
		private void SetSafeAreaOffset()
		{
		}

		// Token: 0x06012DE9 RID: 77289 RVA: 0x00079D28 File Offset: 0x00077F28
		[Token(Token = "0x6012DE9")]
		[Address(RVA = "0x244428C", Offset = "0x244428C", VA = "0x244428C")]
		public bool ShouldIncreasePosYOfUserInfoProfile()
		{
			return default(bool);
		}

		// Token: 0x06012DEA RID: 77290 RVA: 0x00079D40 File Offset: 0x00077F40
		[Token(Token = "0x6012DEA")]
		[Address(RVA = "0x2443F50", Offset = "0x2443F50", VA = "0x2443F50")]
		private Rect CalculateReliableSafeArea()
		{
			return default(Rect);
		}

		// Token: 0x06012DEB RID: 77291 RVA: 0x00079D58 File Offset: 0x00077F58
		[Token(Token = "0x6012DEB")]
		[Address(RVA = "0x244430C", Offset = "0x244430C", VA = "0x244430C")]
		private float GetSafeAreaOffset()
		{
			return 0f;
		}

		// Token: 0x06012DEC RID: 77292 RVA: 0x00079D70 File Offset: 0x00077F70
		[Token(Token = "0x6012DEC")]
		[Address(RVA = "0x2444314", Offset = "0x2444314", VA = "0x2444314")]
		public Vector2 GetSafeCenterPosition()
		{
			return default(Vector2);
		}

		// Token: 0x06012DED RID: 77293 RVA: 0x00079D88 File Offset: 0x00077F88
		[Token(Token = "0x6012DED")]
		[Address(RVA = "0x2444344", Offset = "0x2444344", VA = "0x2444344")]
		public Vector2 GetScreenSize()
		{
			return default(Vector2);
		}

		// Token: 0x06012DEE RID: 77294 RVA: 0x00079DA0 File Offset: 0x00077FA0
		[Token(Token = "0x6012DEE")]
		[Address(RVA = "0x244438C", Offset = "0x244438C", VA = "0x244438C")]
		public float GetOrtographicSize()
		{
			return 0f;
		}

		// Token: 0x06012DEF RID: 77295 RVA: 0x00079DB8 File Offset: 0x00077FB8
		[Token(Token = "0x6012DEF")]
		[Address(RVA = "0x24443A8", Offset = "0x24443A8", VA = "0x24443A8")]
		public float GetTopSafeHeightDiff()
		{
			return 0f;
		}

		// Token: 0x06012DF0 RID: 77296 RVA: 0x00079DD0 File Offset: 0x00077FD0
		[Token(Token = "0x6012DF0")]
		[Address(RVA = "0x24443D4", Offset = "0x24443D4", VA = "0x24443D4")]
		public Vector3 ScreenToWorldPoint(Vector2 screenCoordinates)
		{
			return default(Vector3);
		}

		// Token: 0x06012DF1 RID: 77297 RVA: 0x00079DE8 File Offset: 0x00077FE8
		[Token(Token = "0x6012DF1")]
		[Address(RVA = "0x24443F4", Offset = "0x24443F4", VA = "0x24443F4")]
		public Vector2 WorldToScreenPoint(Vector3 worldPosition)
		{
			return default(Vector2);
		}

		// Token: 0x06012DF2 RID: 77298 RVA: 0x00079E00 File Offset: 0x00078000
		[Token(Token = "0x6012DF2")]
		[Address(RVA = "0x2444410", Offset = "0x2444410", VA = "0x2444410")]
		public float GetCurrentAspect()
		{
			return 0f;
		}

		// Token: 0x06012DF3 RID: 77299 RVA: 0x00079E18 File Offset: 0x00078018
		[Token(Token = "0x6012DF3")]
		[Address(RVA = "0x2442978", Offset = "0x2442978", VA = "0x2442978")]
		public float GetPortraitAspect()
		{
			return 0f;
		}

		// Token: 0x06012DF4 RID: 77300 RVA: 0x00079E30 File Offset: 0x00078030
		[Token(Token = "0x6012DF4")]
		[Address(RVA = "0x244442C", Offset = "0x244442C", VA = "0x244442C")]
		public float GetSafePortraitAspect()
		{
			return 0f;
		}

		// Token: 0x06012DF5 RID: 77301 RVA: 0x00079E48 File Offset: 0x00078048
		[Token(Token = "0x6012DF5")]
		[Address(RVA = "0x2444414", Offset = "0x2444414", VA = "0x2444414")]
		public float GetLandscapeAspect()
		{
			return 0f;
		}

		// Token: 0x06012DF6 RID: 77302 RVA: 0x00079E60 File Offset: 0x00078060
		[Token(Token = "0x6012DF6")]
		[Address(RVA = "0x244366C", Offset = "0x244366C", VA = "0x244366C")]
		public bool IsDeviceSquarish()
		{
			return default(bool);
		}

		// Token: 0x06012DF7 RID: 77303 RVA: 0x00079E78 File Offset: 0x00078078
		[Token(Token = "0x6012DF7")]
		[Address(RVA = "0x244426C", Offset = "0x244426C", VA = "0x244426C")]
		public bool IsDeviceWide()
		{
			return default(bool);
		}

		// Token: 0x06012DF8 RID: 77304 RVA: 0x00079E90 File Offset: 0x00078090
		[Token(Token = "0x6012DF8")]
		[Address(RVA = "0x2444474", Offset = "0x2444474", VA = "0x2444474")]
		public bool IsDeviceTall()
		{
			return default(bool);
		}

		// Token: 0x06012DF9 RID: 77305 RVA: 0x00079EA8 File Offset: 0x000780A8
		[Token(Token = "0x6012DF9")]
		[Address(RVA = "0x2444490", Offset = "0x2444490", VA = "0x2444490")]
		public bool IsDeviceShort()
		{
			return default(bool);
		}

		// Token: 0x06012DFA RID: 77306 RVA: 0x00079EC0 File Offset: 0x000780C0
		[Token(Token = "0x6012DFA")]
		[Address(RVA = "0x24444D0", Offset = "0x24444D0", VA = "0x24444D0")]
		public bool IsDeviceExtraTall()
		{
			return default(bool);
		}

		// Token: 0x06012DFB RID: 77307 RVA: 0x00079ED8 File Offset: 0x000780D8
		[Token(Token = "0x6012DFB")]
		[Address(RVA = "0x244162C", Offset = "0x244162C", VA = "0x244162C")]
		public bool IsShortWideResolution()
		{
			return default(bool);
		}

		// Token: 0x06012DFC RID: 77308 RVA: 0x00079EF0 File Offset: 0x000780F0
		[Token(Token = "0x6012DFC")]
		[Address(RVA = "0x24444F0", Offset = "0x24444F0", VA = "0x24444F0")]
		public bool HasBigNotch()
		{
			return default(bool);
		}

		// Token: 0x06012DFD RID: 77309 RVA: 0x00079F08 File Offset: 0x00078108
		[Token(Token = "0x6012DFD")]
		[Address(RVA = "0x2444528", Offset = "0x2444528", VA = "0x2444528")]
		public float GetUiScaleFactor()
		{
			return 0f;
		}

		// Token: 0x06012DFE RID: 77310 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012DFE")]
		[Address(RVA = "0x24446B0", Offset = "0x24446B0", VA = "0x24446B0")]
		public Transform InsertAdjusterTransformIntoHierarchy(Transform transform)
		{
			return null;
		}

		// Token: 0x06012DFF RID: 77311 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DFF")]
		[Address(RVA = "0x24448C0", Offset = "0x24448C0", VA = "0x24448C0")]
		public void ApplyGameUiScaleParentingFix(Transform transform)
		{
		}

		// Token: 0x06012E00 RID: 77312 RVA: 0x00079F20 File Offset: 0x00078120
		[Token(Token = "0x6012E00")]
		[Address(RVA = "0x24449A4", Offset = "0x24449A4", VA = "0x24449A4")]
		public float ApplyGameUiScaleParticleFix(Transform transform, float forceFactor = -1f, bool shouldClear = false)
		{
			return 0f;
		}

		// Token: 0x06012E01 RID: 77313 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012E01")]
		[Address(RVA = "0x2444C60", Offset = "0x2444C60", VA = "0x2444C60")]
		public GameLandscapeAssets LoadGameLandscapeAssets()
		{
			return null;
		}

		// Token: 0x06012E02 RID: 77314 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012E02")]
		[Address(RVA = "0x2444D10", Offset = "0x2444D10", VA = "0x2444D10")]
		public HomeLandscapeAssets LoadHomeLandscapeAssets()
		{
			return null;
		}

		// Token: 0x06012E03 RID: 77315 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012E03")]
		[Address(RVA = "0x2444DC0", Offset = "0x2444DC0", VA = "0x2444DC0")]
		public string GetOrientationEventString()
		{
			return null;
		}

		// Token: 0x06012E04 RID: 77316 RVA: 0x00079F38 File Offset: 0x00078138
		[Token(Token = "0x6012E04")]
		[Address(RVA = "0x2444E24", Offset = "0x2444E24", VA = "0x2444E24")]
		public bool IsUnsupportedResolution()
		{
			return default(bool);
		}

		// Token: 0x06012E05 RID: 77317 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E05")]
		[Address(RVA = "0x2444E68", Offset = "0x2444E68", VA = "0x2444E68")]
		public CameraManager()
		{
		}

		// Token: 0x0400EE40 RID: 60992
		[Token(Token = "0x400EE40")]
		public const float DefaultCameraWidth = 9.3f;

		// Token: 0x0400EE41 RID: 60993
		[Token(Token = "0x400EE41")]
		public const float LandscapeHomeCameraHeight = 17.5f;

		// Token: 0x0400EE42 RID: 60994
		[Token(Token = "0x400EE42")]
		public const float LandscapeGameCameraHeight = 12.7f;

		// Token: 0x0400EE43 RID: 60995
		[Token(Token = "0x400EE43")]
		public const float ExtraTallDevice = 0.43f;

		// Token: 0x0400EE44 RID: 60996
		[Token(Token = "0x400EE44")]
		public const float TallDevice = 0.5f;

		// Token: 0x0400EE45 RID: 60997
		[Token(Token = "0x400EE45")]
		public const float WideDevice = 0.57f;

		// Token: 0x0400EE46 RID: 60998
		[Token(Token = "0x400EE46")]
		public const float SquarishDevice = 0.8f;

		// Token: 0x0400EE47 RID: 60999
		[Token(Token = "0x400EE47")]
		private const int Iphone11ScreenHeightPixels = 1792;

		// Token: 0x0400EE48 RID: 61000
		[Token(Token = "0x400EE48")]
		public const float LegacyWideAspectRatio = 0.6f;

		// Token: 0x0400EE49 RID: 61001
		[Token(Token = "0x400EE49")]
		private const float MaxAllowedTopCutoutDistanceForAndroid = 165f;

		// Token: 0x0400EE4A RID: 61002
		[Token(Token = "0x400EE4A")]
		private const float PixelPerUnit = 140f;

		// Token: 0x0400EE4B RID: 61003
		[Token(Token = "0x400EE4B")]
		[FieldOffset(Offset = "0x0")]
		private static readonly List<CameraManager.OrientationChange> List;

		// Token: 0x0400EE4C RID: 61004
		[Token(Token = "0x400EE4C")]
		[FieldOffset(Offset = "0x8")]
		private static readonly List<CameraManager.OrientationChange> MissingMethods;

		// Token: 0x0400EE4D RID: 61005
		[Token(Token = "0x400EE4D")]
		[FieldOffset(Offset = "0x10")]
		private float safeAreaOffset;

		// Token: 0x0400EE4E RID: 61006
		[Token(Token = "0x400EE4E")]
		[FieldOffset(Offset = "0x14")]
		private float safeAreaTopOffset;

		// Token: 0x0400EE4F RID: 61007
		[Token(Token = "0x400EE4F")]
		[FieldOffset(Offset = "0x18")]
		private Camera camera;

		// Token: 0x0400EE50 RID: 61008
		[Token(Token = "0x400EE50")]
		[FieldOffset(Offset = "0x20")]
		private float cameraHeight;

		// Token: 0x0400EE51 RID: 61009
		[Token(Token = "0x400EE51")]
		[FieldOffset(Offset = "0x24")]
		private float cameraWidth;

		// Token: 0x0400EE52 RID: 61010
		[Token(Token = "0x400EE52")]
		[FieldOffset(Offset = "0x28")]
		private float cameraAspect;

		// Token: 0x0400EE53 RID: 61011
		[Token(Token = "0x400EE53")]
		[FieldOffset(Offset = "0x2C")]
		private ScreenOrientation currentOrientation;

		// Token: 0x0400EE54 RID: 61012
		[Token(Token = "0x400EE54")]
		[FieldOffset(Offset = "0x30")]
		private bool? isDeviceSupportLandscape;

		// Token: 0x0400EE55 RID: 61013
		[Token(Token = "0x400EE55")]
		[FieldOffset(Offset = "0x38")]
		private GameLandscapeAssets gameLandscapesAssets;

		// Token: 0x0400EE56 RID: 61014
		[Token(Token = "0x400EE56")]
		[FieldOffset(Offset = "0x40")]
		private HomeLandscapeAssets homeLandscapesAssets;

		// Token: 0x0400EE57 RID: 61015
		[Token(Token = "0x400EE57")]
		[FieldOffset(Offset = "0x48")]
		private bool isOrientationInitialized;

		// Token: 0x0400EE58 RID: 61016
		[Token(Token = "0x400EE58")]
		[FieldOffset(Offset = "0x4C")]
		private Rect safeArea;

		// Token: 0x0400EE59 RID: 61017
		[Token(Token = "0x400EE59")]
		[FieldOffset(Offset = "0x60")]
		private readonly List<OrientationDisabler> orientationDisablerList;

		// Token: 0x020025B3 RID: 9651
		// (Invoke) Token: 0x06012E08 RID: 77320
		[Token(Token = "0x20025B3")]
		public delegate void OrientationChange(bool isLandscape);

		// Token: 0x020025B4 RID: 9652
		[Token(Token = "0x20025B4")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06012E0C RID: 77324 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012E0C")]
			[Address(RVA = "0x24451BC", Offset = "0x24451BC", VA = "0x24451BC")]
			public <>c()
			{
			}

			// Token: 0x06012E0D RID: 77325 RVA: 0x00079F50 File Offset: 0x00078150
			[Token(Token = "0x6012E0D")]
			[Address(RVA = "0x24451C4", Offset = "0x24451C4", VA = "0x24451C4")]
			internal bool <ArrangeAreaViewOnOrientationChangeOrder>b__25_0(CameraManager.OrientationChange x)
			{
				return default(bool);
			}

			// Token: 0x06012E0E RID: 77326 RVA: 0x00079F68 File Offset: 0x00078168
			[Token(Token = "0x6012E0E")]
			[Address(RVA = "0x2445248", Offset = "0x2445248", VA = "0x2445248")]
			internal bool <ArrangeAreaViewOnOrientationChangeOrder>b__25_1(CameraManager.OrientationChange x)
			{
				return default(bool);
			}

			// Token: 0x0400EE5A RID: 61018
			[Token(Token = "0x400EE5A")]
			[FieldOffset(Offset = "0x0")]
			public static readonly CameraManager.<>c <>9;

			// Token: 0x0400EE5B RID: 61019
			[Token(Token = "0x400EE5B")]
			[FieldOffset(Offset = "0x8")]
			public static Predicate<CameraManager.OrientationChange> <>9__25_0;

			// Token: 0x0400EE5C RID: 61020
			[Token(Token = "0x400EE5C")]
			[FieldOffset(Offset = "0x10")]
			public static Predicate<CameraManager.OrientationChange> <>9__25_1;
		}
	}
}
