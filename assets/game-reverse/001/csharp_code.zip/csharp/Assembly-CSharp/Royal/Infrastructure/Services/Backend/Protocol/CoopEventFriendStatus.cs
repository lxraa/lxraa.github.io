﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200236E RID: 9070
	[Token(Token = "0x200236E")]
	public enum CoopEventFriendStatus : sbyte
	{
		// Token: 0x0400E675 RID: 58997
		[Token(Token = "0x400E675")]
		None,
		// Token: 0x0400E676 RID: 58998
		[Token(Token = "0x400E676")]
		FullSlot
	}
}
