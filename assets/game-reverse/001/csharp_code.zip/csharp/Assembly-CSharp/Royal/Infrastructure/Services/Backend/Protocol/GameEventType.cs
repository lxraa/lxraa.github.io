﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023BC RID: 9148
	[Token(Token = "0x20023BC")]
	public enum GameEventType : short
	{
		// Token: 0x0400E6F9 RID: 59129
		[Token(Token = "0x400E6F9")]
		KINGS_CUP,
		// Token: 0x0400E6FA RID: 59130
		[Token(Token = "0x400E6FA")]
		TEAM_BATTLE,
		// Token: 0x0400E6FB RID: 59131
		[Token(Token = "0x400E6FB")]
		MADNESS_EVENT,
		// Token: 0x0400E6FC RID: 59132
		[Token(Token = "0x400E6FC")]
		SKY_RACE,
		// Token: 0x0400E6FD RID: 59133
		[Token(Token = "0x400E6FD")]
		PINATA_PARTY,
		// Token: 0x0400E6FE RID: 59134
		[Token(Token = "0x400E6FE")]
		TEAM_TREASURE,
		// Token: 0x0400E6FF RID: 59135
		[Token(Token = "0x400E6FF")]
		LIGHTNING_RUSH,
		// Token: 0x0400E700 RID: 59136
		[Token(Token = "0x400E700")]
		SPACE_MISSION,
		// Token: 0x0400E701 RID: 59137
		[Token(Token = "0x400E701")]
		BALLOON_RISE,
		// Token: 0x0400E702 RID: 59138
		[Token(Token = "0x400E702")]
		WEEKLY_LEADERBOARD,
		// Token: 0x0400E703 RID: 59139
		[Token(Token = "0x400E703")]
		WORLD_CUP,
		// Token: 0x0400E704 RID: 59140
		[Token(Token = "0x400E704")]
		LAVA_QUEST,
		// Token: 0x0400E705 RID: 59141
		[Token(Token = "0x400E705")]
		HIDDEN_TEMPLE,
		// Token: 0x0400E706 RID: 59142
		[Token(Token = "0x400E706")]
		MAGIC_CAULDRON,
		// Token: 0x0400E707 RID: 59143
		[Token(Token = "0x400E707")]
		DRAGON_NEST,
		// Token: 0x0400E708 RID: 59144
		[Token(Token = "0x400E708")]
		ARCHERY_ARENA,
		// Token: 0x0400E709 RID: 59145
		[Token(Token = "0x400E709")]
		DUKES_FORTUNE,
		// Token: 0x0400E70A RID: 59146
		[Token(Token = "0x400E70A")]
		TEAM_TOURNAMENT,
		// Token: 0x0400E70B RID: 59147
		[Token(Token = "0x400E70B")]
		TRAIN_JOURNEY,
		// Token: 0x0400E70C RID: 59148
		[Token(Token = "0x400E70C")]
		OCEAN_ODYSSEY,
		// Token: 0x0400E70D RID: 59149
		[Token(Token = "0x400E70D")]
		DAILY_LIGHTNING_RUSH,
		// Token: 0x0400E70E RID: 59150
		[Token(Token = "0x400E70E")]
		PUZZLE_BREAK,
		// Token: 0x0400E70F RID: 59151
		[Token(Token = "0x400E70F")]
		PROPELLER_RUSH,
		// Token: 0x0400E710 RID: 59152
		[Token(Token = "0x400E710")]
		ANCIENT_ADVENTURE
	}
}
