﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002348 RID: 9032
	[Token(Token = "0x2002348")]
	public struct BadWordsData : IFlatbufferObject
	{
		// Token: 0x17001EEA RID: 7914
		// (get) Token: 0x06010C09 RID: 68617 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EEA")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C09")]
			[Address(RVA = "0x2144E48", Offset = "0x2144E48", VA = "0x2144E48", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C0A RID: 68618 RVA: 0x00060528 File Offset: 0x0005E728
		[Token(Token = "0x6010C0A")]
		[Address(RVA = "0x2144E50", Offset = "0x2144E50", VA = "0x2144E50")]
		public static BadWordsData GetRootAsBadWordsData(ByteBuffer _bb)
		{
			return default(BadWordsData);
		}

		// Token: 0x06010C0B RID: 68619 RVA: 0x00060540 File Offset: 0x0005E740
		[Token(Token = "0x6010C0B")]
		[Address(RVA = "0x2144E5C", Offset = "0x2144E5C", VA = "0x2144E5C")]
		public static BadWordsData GetRootAsBadWordsData(ByteBuffer _bb, BadWordsData obj)
		{
			return default(BadWordsData);
		}

		// Token: 0x06010C0C RID: 68620 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C0C")]
		[Address(RVA = "0x2144F0C", Offset = "0x2144F0C", VA = "0x2144F0C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C0D RID: 68621 RVA: 0x00060558 File Offset: 0x0005E758
		[Token(Token = "0x6010C0D")]
		[Address(RVA = "0x2144ED4", Offset = "0x2144ED4", VA = "0x2144ED4")]
		public BadWordsData __assign(int _i, ByteBuffer _bb)
		{
			return default(BadWordsData);
		}

		// Token: 0x17001EEB RID: 7915
		// (get) Token: 0x06010C0E RID: 68622 RVA: 0x00060570 File Offset: 0x0005E770
		[Token(Token = "0x17001EEB")]
		public sbyte Version
		{
			[Token(Token = "0x6010C0E")]
			[Address(RVA = "0x2144F1C", Offset = "0x2144F1C", VA = "0x2144F1C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010C0F RID: 68623 RVA: 0x00060588 File Offset: 0x0005E788
		[Token(Token = "0x6010C0F")]
		[Address(RVA = "0x2144F60", Offset = "0x2144F60", VA = "0x2144F60")]
		public BadWords? Badwords(int j)
		{
			return null;
		}

		// Token: 0x17001EEC RID: 7916
		// (get) Token: 0x06010C10 RID: 68624 RVA: 0x000605A0 File Offset: 0x0005E7A0
		[Token(Token = "0x17001EEC")]
		public int BadwordsLength
		{
			[Token(Token = "0x6010C10")]
			[Address(RVA = "0x2145030", Offset = "0x2145030", VA = "0x2145030")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010C11 RID: 68625 RVA: 0x000605B8 File Offset: 0x0005E7B8
		[Token(Token = "0x6010C11")]
		[Address(RVA = "0x2145064", Offset = "0x2145064", VA = "0x2145064")]
		public static Offset<BadWordsData> CreateBadWordsData(FlatBufferBuilder builder, sbyte version = 0, [Optional] VectorOffset badwordsOffset)
		{
			return default(Offset<BadWordsData>);
		}

		// Token: 0x06010C12 RID: 68626 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C12")]
		[Address(RVA = "0x2145168", Offset = "0x2145168", VA = "0x2145168")]
		public static void StartBadWordsData(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C13 RID: 68627 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C13")]
		[Address(RVA = "0x21450DC", Offset = "0x21450DC", VA = "0x21450DC")]
		public static void AddVersion(FlatBufferBuilder builder, sbyte version)
		{
		}

		// Token: 0x06010C14 RID: 68628 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C14")]
		[Address(RVA = "0x21450BC", Offset = "0x21450BC", VA = "0x21450BC")]
		public static void AddBadwords(FlatBufferBuilder builder, VectorOffset badwordsOffset)
		{
		}

		// Token: 0x06010C15 RID: 68629 RVA: 0x000605D0 File Offset: 0x0005E7D0
		[Token(Token = "0x6010C15")]
		[Address(RVA = "0x2145180", Offset = "0x2145180", VA = "0x2145180")]
		public static VectorOffset CreateBadwordsVector(FlatBufferBuilder builder, Offset<BadWords>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010C16 RID: 68630 RVA: 0x000605E8 File Offset: 0x0005E7E8
		[Token(Token = "0x6010C16")]
		[Address(RVA = "0x2145228", Offset = "0x2145228", VA = "0x2145228")]
		public static VectorOffset CreateBadwordsVectorBlock(FlatBufferBuilder builder, Offset<BadWords>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010C17 RID: 68631 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C17")]
		[Address(RVA = "0x21452B0", Offset = "0x21452B0", VA = "0x21452B0")]
		public static void StartBadwordsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010C18 RID: 68632 RVA: 0x00060600 File Offset: 0x0005E800
		[Token(Token = "0x6010C18")]
		[Address(RVA = "0x21450FC", Offset = "0x21450FC", VA = "0x21450FC")]
		public static Offset<BadWordsData> EndBadWordsData(FlatBufferBuilder builder)
		{
			return default(Offset<BadWordsData>);
		}

		// Token: 0x0400E62C RID: 58924
		[Token(Token = "0x400E62C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
