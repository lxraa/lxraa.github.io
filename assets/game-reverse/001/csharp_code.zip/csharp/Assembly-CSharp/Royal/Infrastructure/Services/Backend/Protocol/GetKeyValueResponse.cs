﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023DB RID: 9179
	[Token(Token = "0x20023DB")]
	public struct GetKeyValueResponse : IFlatbufferObject
	{
		// Token: 0x17002105 RID: 8453
		// (get) Token: 0x06011414 RID: 70676 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002105")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011414")]
			[Address(RVA = "0x1CB1670", Offset = "0x1CB1670", VA = "0x1CB1670", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011415 RID: 70677 RVA: 0x00066F90 File Offset: 0x00065190
		[Token(Token = "0x6011415")]
		[Address(RVA = "0x1CB1678", Offset = "0x1CB1678", VA = "0x1CB1678")]
		public static GetKeyValueResponse GetRootAsGetKeyValueResponse(ByteBuffer _bb)
		{
			return default(GetKeyValueResponse);
		}

		// Token: 0x06011416 RID: 70678 RVA: 0x00066FA8 File Offset: 0x000651A8
		[Token(Token = "0x6011416")]
		[Address(RVA = "0x1CB1684", Offset = "0x1CB1684", VA = "0x1CB1684")]
		public static GetKeyValueResponse GetRootAsGetKeyValueResponse(ByteBuffer _bb, GetKeyValueResponse obj)
		{
			return default(GetKeyValueResponse);
		}

		// Token: 0x06011417 RID: 70679 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011417")]
		[Address(RVA = "0x1CB1734", Offset = "0x1CB1734", VA = "0x1CB1734", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011418 RID: 70680 RVA: 0x00066FC0 File Offset: 0x000651C0
		[Token(Token = "0x6011418")]
		[Address(RVA = "0x1CB16FC", Offset = "0x1CB16FC", VA = "0x1CB16FC")]
		public GetKeyValueResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetKeyValueResponse);
		}

		// Token: 0x06011419 RID: 70681 RVA: 0x00066FD8 File Offset: 0x000651D8
		[Token(Token = "0x6011419")]
		[Address(RVA = "0x1CB1744", Offset = "0x1CB1744", VA = "0x1CB1744")]
		public KeyValue? KeyValueList(int j)
		{
			return null;
		}

		// Token: 0x17002106 RID: 8454
		// (get) Token: 0x0601141A RID: 70682 RVA: 0x00066FF0 File Offset: 0x000651F0
		[Token(Token = "0x17002106")]
		public int KeyValueListLength
		{
			[Token(Token = "0x601141A")]
			[Address(RVA = "0x1CB181C", Offset = "0x1CB181C", VA = "0x1CB181C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601141B RID: 70683 RVA: 0x00067008 File Offset: 0x00065208
		[Token(Token = "0x601141B")]
		[Address(RVA = "0x1CB1850", Offset = "0x1CB1850", VA = "0x1CB1850")]
		public static Offset<GetKeyValueResponse> CreateGetKeyValueResponse(FlatBufferBuilder builder, [Optional] VectorOffset keyValueListOffset)
		{
			return default(Offset<GetKeyValueResponse>);
		}

		// Token: 0x0601141C RID: 70684 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601141C")]
		[Address(RVA = "0x1CB1924", Offset = "0x1CB1924", VA = "0x1CB1924")]
		public static void StartGetKeyValueResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601141D RID: 70685 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601141D")]
		[Address(RVA = "0x1CB1898", Offset = "0x1CB1898", VA = "0x1CB1898")]
		public static void AddKeyValueList(FlatBufferBuilder builder, VectorOffset keyValueListOffset)
		{
		}

		// Token: 0x0601141E RID: 70686 RVA: 0x00067020 File Offset: 0x00065220
		[Token(Token = "0x601141E")]
		[Address(RVA = "0x1CB193C", Offset = "0x1CB193C", VA = "0x1CB193C")]
		public static VectorOffset CreateKeyValueListVector(FlatBufferBuilder builder, Offset<KeyValue>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601141F RID: 70687 RVA: 0x00067038 File Offset: 0x00065238
		[Token(Token = "0x601141F")]
		[Address(RVA = "0x1CB19E4", Offset = "0x1CB19E4", VA = "0x1CB19E4")]
		public static VectorOffset CreateKeyValueListVectorBlock(FlatBufferBuilder builder, Offset<KeyValue>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011420 RID: 70688 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011420")]
		[Address(RVA = "0x1CB1A6C", Offset = "0x1CB1A6C", VA = "0x1CB1A6C")]
		public static void StartKeyValueListVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011421 RID: 70689 RVA: 0x00067050 File Offset: 0x00065250
		[Token(Token = "0x6011421")]
		[Address(RVA = "0x1CB18B8", Offset = "0x1CB18B8", VA = "0x1CB18B8")]
		public static Offset<GetKeyValueResponse> EndGetKeyValueResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetKeyValueResponse>);
		}

		// Token: 0x0400E74B RID: 59211
		[Token(Token = "0x400E74B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
