﻿using System;
using System.Net.Http;
using Il2CppDummyDll;
using UnityEngine.Networking;

namespace Royal.Infrastructure.Services.Backend.Http
{
	// Token: 0x0200250C RID: 9484
	[Token(Token = "0x200250C")]
	public static class RequestHeaderHelper
	{
		// Token: 0x0601285F RID: 75871 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601285F")]
		[Address(RVA = "0x1CE67A0", Offset = "0x1CE67A0", VA = "0x1CE67A0")]
		public static void AddCommonHeaders(HttpClient httpClient, bool includeUserId = true)
		{
		}

		// Token: 0x06012860 RID: 75872 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012860")]
		[Address(RVA = "0x1CE6AC4", Offset = "0x1CE6AC4", VA = "0x1CE6AC4")]
		public static void AddCommonHeaders(UnityWebRequest webRequest, bool includeUserId = true, bool isCdn = false)
		{
		}

		// Token: 0x06012861 RID: 75873 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012861")]
		[Address(RVA = "0x1CE6C80", Offset = "0x1CE6C80", VA = "0x1CE6C80")]
		public static void SetUserId(long userId)
		{
		}

		// Token: 0x06012862 RID: 75874 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012862")]
		[Address(RVA = "0x1CE6D8C", Offset = "0x1CE6D8C", VA = "0x1CE6D8C")]
		private static string GetUserIdHeaderString()
		{
			return null;
		}

		// Token: 0x06012863 RID: 75875 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012863")]
		[Address(RVA = "0x1CE69E8", Offset = "0x1CE69E8", VA = "0x1CE69E8")]
		private static string GetPlatformHeaderString()
		{
			return null;
		}

		// Token: 0x06012864 RID: 75876 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012864")]
		[Address(RVA = "0x1CE6920", Offset = "0x1CE6920", VA = "0x1CE6920")]
		private static string GetVersionHeaderString()
		{
			return null;
		}

		// Token: 0x0400EA7F RID: 60031
		[Token(Token = "0x400EA7F")]
		private const string VersionHeaderKey = "x-version";

		// Token: 0x0400EA80 RID: 60032
		[Token(Token = "0x400EA80")]
		private const string PlatformHeader = "x-platform";

		// Token: 0x0400EA81 RID: 60033
		[Token(Token = "0x400EA81")]
		private const string UserIdHeader = "x-userid";

		// Token: 0x0400EA82 RID: 60034
		[Token(Token = "0x400EA82")]
		private const string CdnVersionHeaderKey = "x-rm-version";

		// Token: 0x0400EA83 RID: 60035
		[Token(Token = "0x400EA83")]
		private const string CdnPlatformHeader = "x-rm-platform";

		// Token: 0x0400EA84 RID: 60036
		[Token(Token = "0x400EA84")]
		private const string CdnUserIdHeader = "x-rm-userid";

		// Token: 0x0400EA85 RID: 60037
		[Token(Token = "0x400EA85")]
		private const string AndroidPlatform = "android";

		// Token: 0x0400EA86 RID: 60038
		[Token(Token = "0x400EA86")]
		private const string IOSPlatform = "ios";

		// Token: 0x0400EA87 RID: 60039
		[Token(Token = "0x400EA87")]
		private const string VersionFormat = "v{0}";

		// Token: 0x0400EA88 RID: 60040
		[Token(Token = "0x400EA88")]
		private const string UserIdFormat = "{0}l";

		// Token: 0x0400EA89 RID: 60041
		[Token(Token = "0x400EA89")]
		[FieldOffset(Offset = "0x0")]
		private static readonly string AppVersion;

		// Token: 0x0400EA8A RID: 60042
		[Token(Token = "0x400EA8A")]
		[FieldOffset(Offset = "0x8")]
		private static string CachedPlatformHeader;

		// Token: 0x0400EA8B RID: 60043
		[Token(Token = "0x400EA8B")]
		[FieldOffset(Offset = "0x10")]
		private static string CachedAppVersionHeader;

		// Token: 0x0400EA8C RID: 60044
		[Token(Token = "0x400EA8C")]
		[FieldOffset(Offset = "0x18")]
		private static string CachedUserIdHeader;

		// Token: 0x0400EA8D RID: 60045
		[Token(Token = "0x400EA8D")]
		[FieldOffset(Offset = "0x20")]
		private static long CachedUserId;
	}
}
