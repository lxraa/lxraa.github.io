﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002397 RID: 9111
	[Token(Token = "0x2002397")]
	public struct EchoRequest : IFlatbufferObject
	{
		// Token: 0x17002024 RID: 8228
		// (get) Token: 0x0601109A RID: 69786 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002024")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601109A")]
			[Address(RVA = "0x1F9B7A0", Offset = "0x1F9B7A0", VA = "0x1F9B7A0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601109B RID: 69787 RVA: 0x00064080 File Offset: 0x00062280
		[Token(Token = "0x601109B")]
		[Address(RVA = "0x1F9B7A8", Offset = "0x1F9B7A8", VA = "0x1F9B7A8")]
		public static EchoRequest GetRootAsEchoRequest(ByteBuffer _bb)
		{
			return default(EchoRequest);
		}

		// Token: 0x0601109C RID: 69788 RVA: 0x00064098 File Offset: 0x00062298
		[Token(Token = "0x601109C")]
		[Address(RVA = "0x1F9B7B4", Offset = "0x1F9B7B4", VA = "0x1F9B7B4")]
		public static EchoRequest GetRootAsEchoRequest(ByteBuffer _bb, EchoRequest obj)
		{
			return default(EchoRequest);
		}

		// Token: 0x0601109D RID: 69789 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601109D")]
		[Address(RVA = "0x1F9B864", Offset = "0x1F9B864", VA = "0x1F9B864", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601109E RID: 69790 RVA: 0x000640B0 File Offset: 0x000622B0
		[Token(Token = "0x601109E")]
		[Address(RVA = "0x1F9B82C", Offset = "0x1F9B82C", VA = "0x1F9B82C")]
		public EchoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EchoRequest);
		}

		// Token: 0x0601109F RID: 69791 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601109F")]
		[Address(RVA = "0x1F9B874", Offset = "0x1F9B874", VA = "0x1F9B874")]
		public static void StartEchoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060110A0 RID: 69792 RVA: 0x000640C8 File Offset: 0x000622C8
		[Token(Token = "0x60110A0")]
		[Address(RVA = "0x1F9B88C", Offset = "0x1F9B88C", VA = "0x1F9B88C")]
		public static Offset<EchoRequest> EndEchoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EchoRequest>);
		}

		// Token: 0x0400E6B8 RID: 59064
		[Token(Token = "0x400E6B8")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
