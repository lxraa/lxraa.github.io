﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B2 RID: 9138
	[Token(Token = "0x20023B2")]
	public struct EnterWorldCupResponse : IFlatbufferObject
	{
		// Token: 0x17002086 RID: 8326
		// (get) Token: 0x060111F8 RID: 70136 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002086")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60111F8")]
			[Address(RVA = "0x1FA0AD4", Offset = "0x1FA0AD4", VA = "0x1FA0AD4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060111F9 RID: 70137 RVA: 0x000652B0 File Offset: 0x000634B0
		[Token(Token = "0x60111F9")]
		[Address(RVA = "0x1FA0ADC", Offset = "0x1FA0ADC", VA = "0x1FA0ADC")]
		public static EnterWorldCupResponse GetRootAsEnterWorldCupResponse(ByteBuffer _bb)
		{
			return default(EnterWorldCupResponse);
		}

		// Token: 0x060111FA RID: 70138 RVA: 0x000652C8 File Offset: 0x000634C8
		[Token(Token = "0x60111FA")]
		[Address(RVA = "0x1FA0AE8", Offset = "0x1FA0AE8", VA = "0x1FA0AE8")]
		public static EnterWorldCupResponse GetRootAsEnterWorldCupResponse(ByteBuffer _bb, EnterWorldCupResponse obj)
		{
			return default(EnterWorldCupResponse);
		}

		// Token: 0x060111FB RID: 70139 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111FB")]
		[Address(RVA = "0x1FA0B98", Offset = "0x1FA0B98", VA = "0x1FA0B98", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060111FC RID: 70140 RVA: 0x000652E0 File Offset: 0x000634E0
		[Token(Token = "0x60111FC")]
		[Address(RVA = "0x1FA0B60", Offset = "0x1FA0B60", VA = "0x1FA0B60")]
		public EnterWorldCupResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterWorldCupResponse);
		}

		// Token: 0x17002087 RID: 8327
		// (get) Token: 0x060111FD RID: 70141 RVA: 0x000652F8 File Offset: 0x000634F8
		[Token(Token = "0x17002087")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x60111FD")]
			[Address(RVA = "0x1FA0BA8", Offset = "0x1FA0BA8", VA = "0x1FA0BA8")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17002088 RID: 8328
		// (get) Token: 0x060111FE RID: 70142 RVA: 0x00065310 File Offset: 0x00063510
		[Token(Token = "0x17002088")]
		public EnterWorldCupResult Result
		{
			[Token(Token = "0x60111FE")]
			[Address(RVA = "0x1FA0BEC", Offset = "0x1FA0BEC", VA = "0x1FA0BEC")]
			get
			{
				return EnterWorldCupResult.Success;
			}
		}

		// Token: 0x17002089 RID: 8329
		// (get) Token: 0x060111FF RID: 70143 RVA: 0x00065328 File Offset: 0x00063528
		[Token(Token = "0x17002089")]
		public WorldCupInfo? WorldCupServerEventInfo
		{
			[Token(Token = "0x60111FF")]
			[Address(RVA = "0x1FA0C30", Offset = "0x1FA0C30", VA = "0x1FA0C30")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011200 RID: 70144 RVA: 0x00065340 File Offset: 0x00063540
		[Token(Token = "0x6011200")]
		[Address(RVA = "0x1FA0CF0", Offset = "0x1FA0CF0", VA = "0x1FA0CF0")]
		public static Offset<EnterWorldCupResponse> CreateEnterWorldCupResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, EnterWorldCupResult result = EnterWorldCupResult.Success, [Optional] Offset<WorldCupInfo> world_cup_server_event_infoOffset)
		{
			return default(Offset<EnterWorldCupResponse>);
		}

		// Token: 0x06011201 RID: 70145 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011201")]
		[Address(RVA = "0x1FA0E2C", Offset = "0x1FA0E2C", VA = "0x1FA0E2C")]
		public static void StartEnterWorldCupResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011202 RID: 70146 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011202")]
		[Address(RVA = "0x1FA0DA0", Offset = "0x1FA0DA0", VA = "0x1FA0DA0")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06011203 RID: 70147 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011203")]
		[Address(RVA = "0x1FA0D80", Offset = "0x1FA0D80", VA = "0x1FA0D80")]
		public static void AddResult(FlatBufferBuilder builder, EnterWorldCupResult result)
		{
		}

		// Token: 0x06011204 RID: 70148 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011204")]
		[Address(RVA = "0x1FA0D60", Offset = "0x1FA0D60", VA = "0x1FA0D60")]
		public static void AddWorldCupServerEventInfo(FlatBufferBuilder builder, Offset<WorldCupInfo> worldCupServerEventInfoOffset)
		{
		}

		// Token: 0x06011205 RID: 70149 RVA: 0x00065358 File Offset: 0x00063558
		[Token(Token = "0x6011205")]
		[Address(RVA = "0x1FA0DC0", Offset = "0x1FA0DC0", VA = "0x1FA0DC0")]
		public static Offset<EnterWorldCupResponse> EndEnterWorldCupResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterWorldCupResponse>);
		}

		// Token: 0x0400E6E4 RID: 59108
		[Token(Token = "0x400E6E4")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
