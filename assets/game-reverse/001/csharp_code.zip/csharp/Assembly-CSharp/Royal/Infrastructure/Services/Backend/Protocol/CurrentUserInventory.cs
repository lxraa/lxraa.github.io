﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002374 RID: 9076
	[Token(Token = "0x2002374")]
	public struct CurrentUserInventory : IFlatbufferObject
	{
		// Token: 0x17001F8B RID: 8075
		// (get) Token: 0x06010E5A RID: 69210 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F8B")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010E5A")]
			[Address(RVA = "0x1F92A7C", Offset = "0x1F92A7C", VA = "0x1F92A7C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E5B RID: 69211 RVA: 0x00062310 File Offset: 0x00060510
		[Token(Token = "0x6010E5B")]
		[Address(RVA = "0x1F92A84", Offset = "0x1F92A84", VA = "0x1F92A84")]
		public static CurrentUserInventory GetRootAsCurrentUserInventory(ByteBuffer _bb)
		{
			return default(CurrentUserInventory);
		}

		// Token: 0x06010E5C RID: 69212 RVA: 0x00062328 File Offset: 0x00060528
		[Token(Token = "0x6010E5C")]
		[Address(RVA = "0x1F92A90", Offset = "0x1F92A90", VA = "0x1F92A90")]
		public static CurrentUserInventory GetRootAsCurrentUserInventory(ByteBuffer _bb, CurrentUserInventory obj)
		{
			return default(CurrentUserInventory);
		}

		// Token: 0x06010E5D RID: 69213 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E5D")]
		[Address(RVA = "0x1F92B40", Offset = "0x1F92B40", VA = "0x1F92B40", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010E5E RID: 69214 RVA: 0x00062340 File Offset: 0x00060540
		[Token(Token = "0x6010E5E")]
		[Address(RVA = "0x1F92B08", Offset = "0x1F92B08", VA = "0x1F92B08")]
		public CurrentUserInventory __assign(int _i, ByteBuffer _bb)
		{
			return default(CurrentUserInventory);
		}

		// Token: 0x17001F8C RID: 8076
		// (get) Token: 0x06010E5F RID: 69215 RVA: 0x00062358 File Offset: 0x00060558
		[Token(Token = "0x17001F8C")]
		public int Coins
		{
			[Token(Token = "0x6010E5F")]
			[Address(RVA = "0x1F92B50", Offset = "0x1F92B50", VA = "0x1F92B50")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F8D RID: 8077
		// (get) Token: 0x06010E60 RID: 69216 RVA: 0x00062370 File Offset: 0x00060570
		[Token(Token = "0x17001F8D")]
		public int Chest
		{
			[Token(Token = "0x6010E60")]
			[Address(RVA = "0x1F92B94", Offset = "0x1F92B94", VA = "0x1F92B94")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F8E RID: 8078
		// (get) Token: 0x06010E61 RID: 69217 RVA: 0x00062388 File Offset: 0x00060588
		[Token(Token = "0x17001F8E")]
		public long InGameInventory
		{
			[Token(Token = "0x6010E61")]
			[Address(RVA = "0x1F92BD8", Offset = "0x1F92BD8", VA = "0x1F92BD8")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F8F RID: 8079
		// (get) Token: 0x06010E62 RID: 69218 RVA: 0x000623A0 File Offset: 0x000605A0
		[Token(Token = "0x17001F8F")]
		public long PreLevelInventory
		{
			[Token(Token = "0x6010E62")]
			[Address(RVA = "0x1F92C20", Offset = "0x1F92C20", VA = "0x1F92C20")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F90 RID: 8080
		// (get) Token: 0x06010E63 RID: 69219 RVA: 0x000623B8 File Offset: 0x000605B8
		[Token(Token = "0x17001F90")]
		public long FullLivesTimeInMs
		{
			[Token(Token = "0x6010E63")]
			[Address(RVA = "0x1F92C68", Offset = "0x1F92C68", VA = "0x1F92C68")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F91 RID: 8081
		// (get) Token: 0x06010E64 RID: 69220 RVA: 0x000623D0 File Offset: 0x000605D0
		[Token(Token = "0x17001F91")]
		public long UnlimitedLivesEndTimeInMs
		{
			[Token(Token = "0x6010E64")]
			[Address(RVA = "0x1F92CB0", Offset = "0x1F92CB0", VA = "0x1F92CB0")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F92 RID: 8082
		// (get) Token: 0x06010E65 RID: 69221 RVA: 0x000623E8 File Offset: 0x000605E8
		[Token(Token = "0x17001F92")]
		public int UnlimitedRocketEndTime
		{
			[Token(Token = "0x6010E65")]
			[Address(RVA = "0x1F92CF8", Offset = "0x1F92CF8", VA = "0x1F92CF8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F93 RID: 8083
		// (get) Token: 0x06010E66 RID: 69222 RVA: 0x00062400 File Offset: 0x00060600
		[Token(Token = "0x17001F93")]
		public int UnlimitedTntEndTime
		{
			[Token(Token = "0x6010E66")]
			[Address(RVA = "0x1F92D3C", Offset = "0x1F92D3C", VA = "0x1F92D3C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F94 RID: 8084
		// (get) Token: 0x06010E67 RID: 69223 RVA: 0x00062418 File Offset: 0x00060618
		[Token(Token = "0x17001F94")]
		public int UnlimitedLightballEndTime
		{
			[Token(Token = "0x6010E67")]
			[Address(RVA = "0x1F92D80", Offset = "0x1F92D80", VA = "0x1F92D80")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F95 RID: 8085
		// (get) Token: 0x06010E68 RID: 69224 RVA: 0x00062430 File Offset: 0x00060630
		[Token(Token = "0x17001F95")]
		public long RemainingBoosterTimes
		{
			[Token(Token = "0x6010E68")]
			[Address(RVA = "0x1F92DC4", Offset = "0x1F92DC4", VA = "0x1F92DC4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F96 RID: 8086
		// (get) Token: 0x06010E69 RID: 69225 RVA: 0x00062448 File Offset: 0x00060648
		[Token(Token = "0x17001F96")]
		public long Feature1
		{
			[Token(Token = "0x6010E69")]
			[Address(RVA = "0x1F92E0C", Offset = "0x1F92E0C", VA = "0x1F92E0C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F97 RID: 8087
		// (get) Token: 0x06010E6A RID: 69226 RVA: 0x00062460 File Offset: 0x00060660
		[Token(Token = "0x17001F97")]
		public RoyalPassUserProgress? RoyalPassUserProgress
		{
			[Token(Token = "0x6010E6A")]
			[Address(RVA = "0x1F92E54", Offset = "0x1F92E54", VA = "0x1F92E54")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F98 RID: 8088
		// (get) Token: 0x06010E6B RID: 69227 RVA: 0x00062478 File Offset: 0x00060678
		[Token(Token = "0x17001F98")]
		public long MultiplierEndTimes
		{
			[Token(Token = "0x6010E6B")]
			[Address(RVA = "0x1F92F14", Offset = "0x1F92F14", VA = "0x1F92F14")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F99 RID: 8089
		// (get) Token: 0x06010E6C RID: 69228 RVA: 0x00062490 File Offset: 0x00060690
		[Token(Token = "0x17001F99")]
		public long Feature2
		{
			[Token(Token = "0x6010E6C")]
			[Address(RVA = "0x1F92F5C", Offset = "0x1F92F5C", VA = "0x1F92F5C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010E6D RID: 69229 RVA: 0x000624A8 File Offset: 0x000606A8
		[Token(Token = "0x6010E6D")]
		[Address(RVA = "0x1F92FA4", Offset = "0x1F92FA4", VA = "0x1F92FA4")]
		public static Offset<CurrentUserInventory> CreateCurrentUserInventory(FlatBufferBuilder builder, int coins = 0, int chest = 0, long in_game_inventory = 0L, long pre_level_inventory = 0L, long full_lives_time_in_ms = 0L, long unlimited_lives_end_time_in_ms = 0L, int unlimited_rocket_end_time = 0, int unlimited_tnt_end_time = 0, int unlimited_lightball_end_time = 0, long remaining_booster_times = 0L, long feature_1 = 0L, [Optional] Offset<RoyalPassUserProgress> royal_pass_user_progressOffset, long multiplier_end_times = 0L, long feature_2 = 0L)
		{
			return default(Offset<CurrentUserInventory>);
		}

		// Token: 0x06010E6E RID: 69230 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E6E")]
		[Address(RVA = "0x1F93304", Offset = "0x1F93304", VA = "0x1F93304")]
		public static void StartCurrentUserInventory(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010E6F RID: 69231 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E6F")]
		[Address(RVA = "0x1F93278", Offset = "0x1F93278", VA = "0x1F93278")]
		public static void AddCoins(FlatBufferBuilder builder, int coins)
		{
		}

		// Token: 0x06010E70 RID: 69232 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E70")]
		[Address(RVA = "0x1F93258", Offset = "0x1F93258", VA = "0x1F93258")]
		public static void AddChest(FlatBufferBuilder builder, int chest)
		{
		}

		// Token: 0x06010E71 RID: 69233 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E71")]
		[Address(RVA = "0x1F931B8", Offset = "0x1F931B8", VA = "0x1F931B8")]
		public static void AddInGameInventory(FlatBufferBuilder builder, long inGameInventory)
		{
		}

		// Token: 0x06010E72 RID: 69234 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E72")]
		[Address(RVA = "0x1F93198", Offset = "0x1F93198", VA = "0x1F93198")]
		public static void AddPreLevelInventory(FlatBufferBuilder builder, long preLevelInventory)
		{
		}

		// Token: 0x06010E73 RID: 69235 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E73")]
		[Address(RVA = "0x1F93178", Offset = "0x1F93178", VA = "0x1F93178")]
		public static void AddFullLivesTimeInMs(FlatBufferBuilder builder, long fullLivesTimeInMs)
		{
		}

		// Token: 0x06010E74 RID: 69236 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E74")]
		[Address(RVA = "0x1F93158", Offset = "0x1F93158", VA = "0x1F93158")]
		public static void AddUnlimitedLivesEndTimeInMs(FlatBufferBuilder builder, long unlimitedLivesEndTimeInMs)
		{
		}

		// Token: 0x06010E75 RID: 69237 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E75")]
		[Address(RVA = "0x1F93238", Offset = "0x1F93238", VA = "0x1F93238")]
		public static void AddUnlimitedRocketEndTime(FlatBufferBuilder builder, int unlimitedRocketEndTime)
		{
		}

		// Token: 0x06010E76 RID: 69238 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E76")]
		[Address(RVA = "0x1F93218", Offset = "0x1F93218", VA = "0x1F93218")]
		public static void AddUnlimitedTntEndTime(FlatBufferBuilder builder, int unlimitedTntEndTime)
		{
		}

		// Token: 0x06010E77 RID: 69239 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E77")]
		[Address(RVA = "0x1F931F8", Offset = "0x1F931F8", VA = "0x1F931F8")]
		public static void AddUnlimitedLightballEndTime(FlatBufferBuilder builder, int unlimitedLightballEndTime)
		{
		}

		// Token: 0x06010E78 RID: 69240 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E78")]
		[Address(RVA = "0x1F93138", Offset = "0x1F93138", VA = "0x1F93138")]
		public static void AddRemainingBoosterTimes(FlatBufferBuilder builder, long remainingBoosterTimes)
		{
		}

		// Token: 0x06010E79 RID: 69241 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E79")]
		[Address(RVA = "0x1F93118", Offset = "0x1F93118", VA = "0x1F93118")]
		public static void AddFeature1(FlatBufferBuilder builder, long feature1)
		{
		}

		// Token: 0x06010E7A RID: 69242 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E7A")]
		[Address(RVA = "0x1F931D8", Offset = "0x1F931D8", VA = "0x1F931D8")]
		public static void AddRoyalPassUserProgress(FlatBufferBuilder builder, Offset<RoyalPassUserProgress> royalPassUserProgressOffset)
		{
		}

		// Token: 0x06010E7B RID: 69243 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E7B")]
		[Address(RVA = "0x1F930F8", Offset = "0x1F930F8", VA = "0x1F930F8")]
		public static void AddMultiplierEndTimes(FlatBufferBuilder builder, long multiplierEndTimes)
		{
		}

		// Token: 0x06010E7C RID: 69244 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E7C")]
		[Address(RVA = "0x1F930D8", Offset = "0x1F930D8", VA = "0x1F930D8")]
		public static void AddFeature2(FlatBufferBuilder builder, long feature2)
		{
		}

		// Token: 0x06010E7D RID: 69245 RVA: 0x000624C0 File Offset: 0x000606C0
		[Token(Token = "0x6010E7D")]
		[Address(RVA = "0x1F93298", Offset = "0x1F93298", VA = "0x1F93298")]
		public static Offset<CurrentUserInventory> EndCurrentUserInventory(FlatBufferBuilder builder)
		{
			return default(Offset<CurrentUserInventory>);
		}

		// Token: 0x0400E68D RID: 59021
		[Token(Token = "0x400E68D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
