﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D7 RID: 9175
	[Token(Token = "0x20023D7")]
	public struct GetFriendsResponse : IFlatbufferObject
	{
		// Token: 0x170020FD RID: 8445
		// (get) Token: 0x060113E1 RID: 70625 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020FD")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60113E1")]
			[Address(RVA = "0x1CB085C", Offset = "0x1CB085C", VA = "0x1CB085C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060113E2 RID: 70626 RVA: 0x00066CA8 File Offset: 0x00064EA8
		[Token(Token = "0x60113E2")]
		[Address(RVA = "0x1CB0864", Offset = "0x1CB0864", VA = "0x1CB0864")]
		public static GetFriendsResponse GetRootAsGetFriendsResponse(ByteBuffer _bb)
		{
			return default(GetFriendsResponse);
		}

		// Token: 0x060113E3 RID: 70627 RVA: 0x00066CC0 File Offset: 0x00064EC0
		[Token(Token = "0x60113E3")]
		[Address(RVA = "0x1CB0870", Offset = "0x1CB0870", VA = "0x1CB0870")]
		public static GetFriendsResponse GetRootAsGetFriendsResponse(ByteBuffer _bb, GetFriendsResponse obj)
		{
			return default(GetFriendsResponse);
		}

		// Token: 0x060113E4 RID: 70628 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113E4")]
		[Address(RVA = "0x1CB0920", Offset = "0x1CB0920", VA = "0x1CB0920", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060113E5 RID: 70629 RVA: 0x00066CD8 File Offset: 0x00064ED8
		[Token(Token = "0x60113E5")]
		[Address(RVA = "0x1CB08E8", Offset = "0x1CB08E8", VA = "0x1CB08E8")]
		public GetFriendsResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetFriendsResponse);
		}

		// Token: 0x060113E6 RID: 70630 RVA: 0x00066CF0 File Offset: 0x00064EF0
		[Token(Token = "0x60113E6")]
		[Address(RVA = "0x1CB0930", Offset = "0x1CB0930", VA = "0x1CB0930")]
		public FriendProfile? Friends(int j)
		{
			return null;
		}

		// Token: 0x170020FE RID: 8446
		// (get) Token: 0x060113E7 RID: 70631 RVA: 0x00066D08 File Offset: 0x00064F08
		[Token(Token = "0x170020FE")]
		public int FriendsLength
		{
			[Token(Token = "0x60113E7")]
			[Address(RVA = "0x1CB0A00", Offset = "0x1CB0A00", VA = "0x1CB0A00")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060113E8 RID: 70632 RVA: 0x00066D20 File Offset: 0x00064F20
		[Token(Token = "0x60113E8")]
		[Address(RVA = "0x1CB0A34", Offset = "0x1CB0A34", VA = "0x1CB0A34")]
		public SuggestionProfile? Suggestions(int j)
		{
			return null;
		}

		// Token: 0x170020FF RID: 8447
		// (get) Token: 0x060113E9 RID: 70633 RVA: 0x00066D38 File Offset: 0x00064F38
		[Token(Token = "0x170020FF")]
		public int SuggestionsLength
		{
			[Token(Token = "0x60113E9")]
			[Address(RVA = "0x1CB0B0C", Offset = "0x1CB0B0C", VA = "0x1CB0B0C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060113EA RID: 70634 RVA: 0x00066D50 File Offset: 0x00064F50
		[Token(Token = "0x60113EA")]
		[Address(RVA = "0x1CB0B40", Offset = "0x1CB0B40", VA = "0x1CB0B40")]
		public static Offset<GetFriendsResponse> CreateGetFriendsResponse(FlatBufferBuilder builder, [Optional] VectorOffset friendsOffset, [Optional] VectorOffset suggestionsOffset)
		{
			return default(Offset<GetFriendsResponse>);
		}

		// Token: 0x060113EB RID: 70635 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113EB")]
		[Address(RVA = "0x1CB0C44", Offset = "0x1CB0C44", VA = "0x1CB0C44")]
		public static void StartGetFriendsResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060113EC RID: 70636 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113EC")]
		[Address(RVA = "0x1CB0BB8", Offset = "0x1CB0BB8", VA = "0x1CB0BB8")]
		public static void AddFriends(FlatBufferBuilder builder, VectorOffset friendsOffset)
		{
		}

		// Token: 0x060113ED RID: 70637 RVA: 0x00066D68 File Offset: 0x00064F68
		[Token(Token = "0x60113ED")]
		[Address(RVA = "0x1CB0C5C", Offset = "0x1CB0C5C", VA = "0x1CB0C5C")]
		public static VectorOffset CreateFriendsVector(FlatBufferBuilder builder, Offset<FriendProfile>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113EE RID: 70638 RVA: 0x00066D80 File Offset: 0x00064F80
		[Token(Token = "0x60113EE")]
		[Address(RVA = "0x1CB0D04", Offset = "0x1CB0D04", VA = "0x1CB0D04")]
		public static VectorOffset CreateFriendsVectorBlock(FlatBufferBuilder builder, Offset<FriendProfile>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113EF RID: 70639 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113EF")]
		[Address(RVA = "0x1CB0D8C", Offset = "0x1CB0D8C", VA = "0x1CB0D8C")]
		public static void StartFriendsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x060113F0 RID: 70640 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113F0")]
		[Address(RVA = "0x1CB0B98", Offset = "0x1CB0B98", VA = "0x1CB0B98")]
		public static void AddSuggestions(FlatBufferBuilder builder, VectorOffset suggestionsOffset)
		{
		}

		// Token: 0x060113F1 RID: 70641 RVA: 0x00066D98 File Offset: 0x00064F98
		[Token(Token = "0x60113F1")]
		[Address(RVA = "0x1CB0DAC", Offset = "0x1CB0DAC", VA = "0x1CB0DAC")]
		public static VectorOffset CreateSuggestionsVector(FlatBufferBuilder builder, Offset<SuggestionProfile>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113F2 RID: 70642 RVA: 0x00066DB0 File Offset: 0x00064FB0
		[Token(Token = "0x60113F2")]
		[Address(RVA = "0x1CB0E54", Offset = "0x1CB0E54", VA = "0x1CB0E54")]
		public static VectorOffset CreateSuggestionsVectorBlock(FlatBufferBuilder builder, Offset<SuggestionProfile>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113F3 RID: 70643 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113F3")]
		[Address(RVA = "0x1CB0EDC", Offset = "0x1CB0EDC", VA = "0x1CB0EDC")]
		public static void StartSuggestionsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x060113F4 RID: 70644 RVA: 0x00066DC8 File Offset: 0x00064FC8
		[Token(Token = "0x60113F4")]
		[Address(RVA = "0x1CB0BD8", Offset = "0x1CB0BD8", VA = "0x1CB0BD8")]
		public static Offset<GetFriendsResponse> EndGetFriendsResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetFriendsResponse>);
		}

		// Token: 0x0400E747 RID: 59207
		[Token(Token = "0x400E747")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
