﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002359 RID: 9049
	[Token(Token = "0x2002359")]
	public struct ClaimedEvents : IFlatbufferObject
	{
		// Token: 0x17001F24 RID: 7972
		// (get) Token: 0x06010CEA RID: 68842 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F24")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010CEA")]
			[Address(RVA = "0x21481F8", Offset = "0x21481F8", VA = "0x21481F8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CEB RID: 68843 RVA: 0x00061050 File Offset: 0x0005F250
		[Token(Token = "0x6010CEB")]
		[Address(RVA = "0x2148200", Offset = "0x2148200", VA = "0x2148200")]
		public static ClaimedEvents GetRootAsClaimedEvents(ByteBuffer _bb)
		{
			return default(ClaimedEvents);
		}

		// Token: 0x06010CEC RID: 68844 RVA: 0x00061068 File Offset: 0x0005F268
		[Token(Token = "0x6010CEC")]
		[Address(RVA = "0x214820C", Offset = "0x214820C", VA = "0x214820C")]
		public static ClaimedEvents GetRootAsClaimedEvents(ByteBuffer _bb, ClaimedEvents obj)
		{
			return default(ClaimedEvents);
		}

		// Token: 0x06010CED RID: 68845 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CED")]
		[Address(RVA = "0x21482BC", Offset = "0x21482BC", VA = "0x21482BC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010CEE RID: 68846 RVA: 0x00061080 File Offset: 0x0005F280
		[Token(Token = "0x6010CEE")]
		[Address(RVA = "0x2148284", Offset = "0x2148284", VA = "0x2148284")]
		public ClaimedEvents __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimedEvents);
		}

		// Token: 0x17001F25 RID: 7973
		// (get) Token: 0x06010CEF RID: 68847 RVA: 0x00061098 File Offset: 0x0005F298
		[Token(Token = "0x17001F25")]
		public int BalloonRiseClaimedEventId
		{
			[Token(Token = "0x6010CEF")]
			[Address(RVA = "0x21482CC", Offset = "0x21482CC", VA = "0x21482CC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F26 RID: 7974
		// (get) Token: 0x06010CF0 RID: 68848 RVA: 0x000610B0 File Offset: 0x0005F2B0
		[Token(Token = "0x17001F26")]
		public int MagicCauldronClaimedEventId
		{
			[Token(Token = "0x6010CF0")]
			[Address(RVA = "0x2148310", Offset = "0x2148310", VA = "0x2148310")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010CF1 RID: 68849 RVA: 0x000610C8 File Offset: 0x0005F2C8
		[Token(Token = "0x6010CF1")]
		[Address(RVA = "0x2148354", Offset = "0x2148354", VA = "0x2148354")]
		public static Offset<ClaimedEvents> CreateClaimedEvents(FlatBufferBuilder builder, int balloonRiseClaimedEventId = 0, int magicCauldronClaimedEventId = 0)
		{
			return default(Offset<ClaimedEvents>);
		}

		// Token: 0x06010CF2 RID: 68850 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CF2")]
		[Address(RVA = "0x2148458", Offset = "0x2148458", VA = "0x2148458")]
		public static void StartClaimedEvents(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010CF3 RID: 68851 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CF3")]
		[Address(RVA = "0x21483CC", Offset = "0x21483CC", VA = "0x21483CC")]
		public static void AddBalloonRiseClaimedEventId(FlatBufferBuilder builder, int balloonRiseClaimedEventId)
		{
		}

		// Token: 0x06010CF4 RID: 68852 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CF4")]
		[Address(RVA = "0x21483AC", Offset = "0x21483AC", VA = "0x21483AC")]
		public static void AddMagicCauldronClaimedEventId(FlatBufferBuilder builder, int magicCauldronClaimedEventId)
		{
		}

		// Token: 0x06010CF5 RID: 68853 RVA: 0x000610E0 File Offset: 0x0005F2E0
		[Token(Token = "0x6010CF5")]
		[Address(RVA = "0x21483EC", Offset = "0x21483EC", VA = "0x21483EC")]
		public static Offset<ClaimedEvents> EndClaimedEvents(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimedEvents>);
		}

		// Token: 0x0400E65F RID: 58975
		[Token(Token = "0x400E65F")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
