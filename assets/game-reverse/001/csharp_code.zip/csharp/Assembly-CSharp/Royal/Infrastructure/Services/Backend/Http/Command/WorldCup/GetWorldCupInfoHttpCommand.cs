﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.WorldCup
{
	// Token: 0x02002523 RID: 9507
	[Token(Token = "0x2002523")]
	public class GetWorldCupInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026F6 RID: 9974
		// (get) Token: 0x0601297C RID: 76156 RVA: 0x00077958 File Offset: 0x00075B58
		[Token(Token = "0x170026F6")]
		public override RequestType RequestType
		{
			[Token(Token = "0x601297C")]
			[Address(RVA = "0x1CF7DF4", Offset = "0x1CF7DF4", VA = "0x1CF7DF4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026F7 RID: 9975
		// (get) Token: 0x0601297D RID: 76157 RVA: 0x00077970 File Offset: 0x00075B70
		[Token(Token = "0x170026F7")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x601297D")]
			[Address(RVA = "0x1CF7DFC", Offset = "0x1CF7DFC", VA = "0x1CF7DFC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x0601297E RID: 76158 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601297E")]
		[Address(RVA = "0x1CF7E04", Offset = "0x1CF7E04", VA = "0x1CF7E04")]
		public GetWorldCupInfoHttpCommand(int userEventID, WorldCupStage leaderboardStage, string country)
		{
		}

		// Token: 0x0601297F RID: 76159 RVA: 0x00077988 File Offset: 0x00075B88
		[Token(Token = "0x601297F")]
		[Address(RVA = "0x1CF7E5C", Offset = "0x1CF7E5C", VA = "0x1CF7E5C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012980 RID: 76160 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012980")]
		[Address(RVA = "0x1CF8080", Offset = "0x1CF8080", VA = "0x1CF8080", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012981 RID: 76161 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012981")]
		[Address(RVA = "0x1CF82D4", Offset = "0x1CF82D4", VA = "0x1CF82D4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB11 RID: 60177
		[Token(Token = "0x400EB11")]
		[FieldOffset(Offset = "0x14")]
		private readonly int userEventID;

		// Token: 0x0400EB12 RID: 60178
		[Token(Token = "0x400EB12")]
		[FieldOffset(Offset = "0x18")]
		private readonly WorldCupStage leaderboardStage;

		// Token: 0x0400EB13 RID: 60179
		[Token(Token = "0x400EB13")]
		[FieldOffset(Offset = "0x20")]
		private readonly string country;
	}
}
