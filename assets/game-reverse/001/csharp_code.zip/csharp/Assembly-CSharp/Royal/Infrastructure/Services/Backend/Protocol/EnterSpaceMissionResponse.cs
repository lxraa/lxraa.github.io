﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023AC RID: 9132
	[Token(Token = "0x20023AC")]
	public struct EnterSpaceMissionResponse : IFlatbufferObject
	{
		// Token: 0x1700206A RID: 8298
		// (get) Token: 0x06011194 RID: 70036 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700206A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011194")]
			[Address(RVA = "0x1F9F330", Offset = "0x1F9F330", VA = "0x1F9F330", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011195 RID: 70037 RVA: 0x00064D88 File Offset: 0x00062F88
		[Token(Token = "0x6011195")]
		[Address(RVA = "0x1F9F338", Offset = "0x1F9F338", VA = "0x1F9F338")]
		public static EnterSpaceMissionResponse GetRootAsEnterSpaceMissionResponse(ByteBuffer _bb)
		{
			return default(EnterSpaceMissionResponse);
		}

		// Token: 0x06011196 RID: 70038 RVA: 0x00064DA0 File Offset: 0x00062FA0
		[Token(Token = "0x6011196")]
		[Address(RVA = "0x1F9F344", Offset = "0x1F9F344", VA = "0x1F9F344")]
		public static EnterSpaceMissionResponse GetRootAsEnterSpaceMissionResponse(ByteBuffer _bb, EnterSpaceMissionResponse obj)
		{
			return default(EnterSpaceMissionResponse);
		}

		// Token: 0x06011197 RID: 70039 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011197")]
		[Address(RVA = "0x1F9F3F4", Offset = "0x1F9F3F4", VA = "0x1F9F3F4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011198 RID: 70040 RVA: 0x00064DB8 File Offset: 0x00062FB8
		[Token(Token = "0x6011198")]
		[Address(RVA = "0x1F9F3BC", Offset = "0x1F9F3BC", VA = "0x1F9F3BC")]
		public EnterSpaceMissionResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterSpaceMissionResponse);
		}

		// Token: 0x1700206B RID: 8299
		// (get) Token: 0x06011199 RID: 70041 RVA: 0x00064DD0 File Offset: 0x00062FD0
		[Token(Token = "0x1700206B")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6011199")]
			[Address(RVA = "0x1F9F404", Offset = "0x1F9F404", VA = "0x1F9F404")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x1700206C RID: 8300
		// (get) Token: 0x0601119A RID: 70042 RVA: 0x00064DE8 File Offset: 0x00062FE8
		[Token(Token = "0x1700206C")]
		public EnterEventFailReason FailReason
		{
			[Token(Token = "0x601119A")]
			[Address(RVA = "0x1F9F448", Offset = "0x1F9F448", VA = "0x1F9F448")]
			get
			{
				return EnterEventFailReason.None;
			}
		}

		// Token: 0x1700206D RID: 8301
		// (get) Token: 0x0601119B RID: 70043 RVA: 0x00064E00 File Offset: 0x00063000
		[Token(Token = "0x1700206D")]
		public SpaceMissionInfo? SpaceMissionInfo
		{
			[Token(Token = "0x601119B")]
			[Address(RVA = "0x1F9F48C", Offset = "0x1F9F48C", VA = "0x1F9F48C")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700206E RID: 8302
		// (get) Token: 0x0601119C RID: 70044 RVA: 0x00064E18 File Offset: 0x00063018
		[Token(Token = "0x1700206E")]
		public long SpaceMissionStartTime
		{
			[Token(Token = "0x601119C")]
			[Address(RVA = "0x1F9F54C", Offset = "0x1F9F54C", VA = "0x1F9F54C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x0601119D RID: 70045 RVA: 0x00064E30 File Offset: 0x00063030
		[Token(Token = "0x601119D")]
		[Address(RVA = "0x1F9F594", Offset = "0x1F9F594", VA = "0x1F9F594")]
		public static Offset<EnterSpaceMissionResponse> CreateEnterSpaceMissionResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, EnterEventFailReason fail_reason = EnterEventFailReason.None, [Optional] Offset<SpaceMissionInfo> space_mission_infoOffset, long space_mission_start_time = 0L)
		{
			return default(Offset<EnterSpaceMissionResponse>);
		}

		// Token: 0x0601119E RID: 70046 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601119E")]
		[Address(RVA = "0x1F9F700", Offset = "0x1F9F700", VA = "0x1F9F700")]
		public static void StartEnterSpaceMissionResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601119F RID: 70047 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601119F")]
		[Address(RVA = "0x1F9F674", Offset = "0x1F9F674", VA = "0x1F9F674")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x060111A0 RID: 70048 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111A0")]
		[Address(RVA = "0x1F9F654", Offset = "0x1F9F654", VA = "0x1F9F654")]
		public static void AddFailReason(FlatBufferBuilder builder, EnterEventFailReason failReason)
		{
		}

		// Token: 0x060111A1 RID: 70049 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111A1")]
		[Address(RVA = "0x1F9F634", Offset = "0x1F9F634", VA = "0x1F9F634")]
		public static void AddSpaceMissionInfo(FlatBufferBuilder builder, Offset<SpaceMissionInfo> spaceMissionInfoOffset)
		{
		}

		// Token: 0x060111A2 RID: 70050 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111A2")]
		[Address(RVA = "0x1F9F614", Offset = "0x1F9F614", VA = "0x1F9F614")]
		public static void AddSpaceMissionStartTime(FlatBufferBuilder builder, long spaceMissionStartTime)
		{
		}

		// Token: 0x060111A3 RID: 70051 RVA: 0x00064E48 File Offset: 0x00063048
		[Token(Token = "0x60111A3")]
		[Address(RVA = "0x1F9F694", Offset = "0x1F9F694", VA = "0x1F9F694")]
		public static Offset<EnterSpaceMissionResponse> EndEnterSpaceMissionResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterSpaceMissionResponse>);
		}

		// Token: 0x0400E6DE RID: 59102
		[Token(Token = "0x400E6DE")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
