﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C6 RID: 9158
	[Token(Token = "0x20023C6")]
	public struct GetBalloonRiseInfoResponse : IFlatbufferObject
	{
		// Token: 0x170020CC RID: 8396
		// (get) Token: 0x060112F8 RID: 70392 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020CC")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60112F8")]
			[Address(RVA = "0x1CAC974", Offset = "0x1CAC974", VA = "0x1CAC974", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112F9 RID: 70393 RVA: 0x00065FB8 File Offset: 0x000641B8
		[Token(Token = "0x60112F9")]
		[Address(RVA = "0x1CAC97C", Offset = "0x1CAC97C", VA = "0x1CAC97C")]
		public static GetBalloonRiseInfoResponse GetRootAsGetBalloonRiseInfoResponse(ByteBuffer _bb)
		{
			return default(GetBalloonRiseInfoResponse);
		}

		// Token: 0x060112FA RID: 70394 RVA: 0x00065FD0 File Offset: 0x000641D0
		[Token(Token = "0x60112FA")]
		[Address(RVA = "0x1CAC988", Offset = "0x1CAC988", VA = "0x1CAC988")]
		public static GetBalloonRiseInfoResponse GetRootAsGetBalloonRiseInfoResponse(ByteBuffer _bb, GetBalloonRiseInfoResponse obj)
		{
			return default(GetBalloonRiseInfoResponse);
		}

		// Token: 0x060112FB RID: 70395 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112FB")]
		[Address(RVA = "0x1CACA38", Offset = "0x1CACA38", VA = "0x1CACA38", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060112FC RID: 70396 RVA: 0x00065FE8 File Offset: 0x000641E8
		[Token(Token = "0x60112FC")]
		[Address(RVA = "0x1CACA00", Offset = "0x1CACA00", VA = "0x1CACA00")]
		public GetBalloonRiseInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetBalloonRiseInfoResponse);
		}

		// Token: 0x170020CD RID: 8397
		// (get) Token: 0x060112FD RID: 70397 RVA: 0x00066000 File Offset: 0x00064200
		[Token(Token = "0x170020CD")]
		public BalloonRiseUserConfigInfo? BalloonRiseUserInfo
		{
			[Token(Token = "0x60112FD")]
			[Address(RVA = "0x1CACA48", Offset = "0x1CACA48", VA = "0x1CACA48")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112FE RID: 70398 RVA: 0x00066018 File Offset: 0x00064218
		[Token(Token = "0x60112FE")]
		[Address(RVA = "0x1CACB08", Offset = "0x1CACB08", VA = "0x1CACB08")]
		public static Offset<GetBalloonRiseInfoResponse> CreateGetBalloonRiseInfoResponse(FlatBufferBuilder builder, [Optional] Offset<BalloonRiseUserConfigInfo> balloon_rise_user_infoOffset)
		{
			return default(Offset<GetBalloonRiseInfoResponse>);
		}

		// Token: 0x060112FF RID: 70399 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112FF")]
		[Address(RVA = "0x1CACBDC", Offset = "0x1CACBDC", VA = "0x1CACBDC")]
		public static void StartGetBalloonRiseInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011300 RID: 70400 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011300")]
		[Address(RVA = "0x1CACB50", Offset = "0x1CACB50", VA = "0x1CACB50")]
		public static void AddBalloonRiseUserInfo(FlatBufferBuilder builder, Offset<BalloonRiseUserConfigInfo> balloonRiseUserInfoOffset)
		{
		}

		// Token: 0x06011301 RID: 70401 RVA: 0x00066030 File Offset: 0x00064230
		[Token(Token = "0x6011301")]
		[Address(RVA = "0x1CACB70", Offset = "0x1CACB70", VA = "0x1CACB70")]
		public static Offset<GetBalloonRiseInfoResponse> EndGetBalloonRiseInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetBalloonRiseInfoResponse>);
		}

		// Token: 0x0400E733 RID: 59187
		[Token(Token = "0x400E733")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
