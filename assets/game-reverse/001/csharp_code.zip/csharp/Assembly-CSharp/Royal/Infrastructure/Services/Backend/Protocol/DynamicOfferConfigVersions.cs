﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002394 RID: 9108
	[Token(Token = "0x2002394")]
	public struct DynamicOfferConfigVersions : IFlatbufferObject
	{
		// Token: 0x17002013 RID: 8211
		// (get) Token: 0x0601105C RID: 69724 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002013")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601105C")]
			[Address(RVA = "0x1F9A91C", Offset = "0x1F9A91C", VA = "0x1F9A91C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601105D RID: 69725 RVA: 0x00063D80 File Offset: 0x00061F80
		[Token(Token = "0x601105D")]
		[Address(RVA = "0x1F9A924", Offset = "0x1F9A924", VA = "0x1F9A924")]
		public static DynamicOfferConfigVersions GetRootAsDynamicOfferConfigVersions(ByteBuffer _bb)
		{
			return default(DynamicOfferConfigVersions);
		}

		// Token: 0x0601105E RID: 69726 RVA: 0x00063D98 File Offset: 0x00061F98
		[Token(Token = "0x601105E")]
		[Address(RVA = "0x1F9A930", Offset = "0x1F9A930", VA = "0x1F9A930")]
		public static DynamicOfferConfigVersions GetRootAsDynamicOfferConfigVersions(ByteBuffer _bb, DynamicOfferConfigVersions obj)
		{
			return default(DynamicOfferConfigVersions);
		}

		// Token: 0x0601105F RID: 69727 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601105F")]
		[Address(RVA = "0x1F9A9E0", Offset = "0x1F9A9E0", VA = "0x1F9A9E0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011060 RID: 69728 RVA: 0x00063DB0 File Offset: 0x00061FB0
		[Token(Token = "0x6011060")]
		[Address(RVA = "0x1F9A9A8", Offset = "0x1F9A9A8", VA = "0x1F9A9A8")]
		public DynamicOfferConfigVersions __assign(int _i, ByteBuffer _bb)
		{
			return default(DynamicOfferConfigVersions);
		}

		// Token: 0x17002014 RID: 8212
		// (get) Token: 0x06011061 RID: 69729 RVA: 0x00063DC8 File Offset: 0x00061FC8
		[Token(Token = "0x17002014")]
		public short DynamicOfferConfigVersion
		{
			[Token(Token = "0x6011061")]
			[Address(RVA = "0x1F9A9F0", Offset = "0x1F9A9F0", VA = "0x1F9A9F0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002015 RID: 8213
		// (get) Token: 0x06011062 RID: 69730 RVA: 0x00063DE0 File Offset: 0x00061FE0
		[Token(Token = "0x17002015")]
		public short DynamicOfferUserSegmentVersion
		{
			[Token(Token = "0x6011062")]
			[Address(RVA = "0x1F9AA34", Offset = "0x1F9AA34", VA = "0x1F9AA34")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011063 RID: 69731 RVA: 0x00063DF8 File Offset: 0x00061FF8
		[Token(Token = "0x6011063")]
		[Address(RVA = "0x1F9AA78", Offset = "0x1F9AA78", VA = "0x1F9AA78")]
		public DynamicOfferConfigVersion? DynamicOfferConfigVersionList(int j)
		{
			return null;
		}

		// Token: 0x17002016 RID: 8214
		// (get) Token: 0x06011064 RID: 69732 RVA: 0x00063E10 File Offset: 0x00062010
		[Token(Token = "0x17002016")]
		public int DynamicOfferConfigVersionListLength
		{
			[Token(Token = "0x6011064")]
			[Address(RVA = "0x1F9AB48", Offset = "0x1F9AB48", VA = "0x1F9AB48")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011065 RID: 69733 RVA: 0x00063E28 File Offset: 0x00062028
		[Token(Token = "0x6011065")]
		[Address(RVA = "0x1F9AB7C", Offset = "0x1F9AB7C", VA = "0x1F9AB7C")]
		public static Offset<DynamicOfferConfigVersions> CreateDynamicOfferConfigVersions(FlatBufferBuilder builder, short dynamic_offer_config_version = 0, short dynamic_offer_user_segment_version = 0, [Optional] VectorOffset dynamic_offer_config_version_listOffset)
		{
			return default(Offset<DynamicOfferConfigVersions>);
		}

		// Token: 0x06011066 RID: 69734 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011066")]
		[Address(RVA = "0x1F9ACB8", Offset = "0x1F9ACB8", VA = "0x1F9ACB8")]
		public static void StartDynamicOfferConfigVersions(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011067 RID: 69735 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011067")]
		[Address(RVA = "0x1F9AC2C", Offset = "0x1F9AC2C", VA = "0x1F9AC2C")]
		public static void AddDynamicOfferConfigVersion(FlatBufferBuilder builder, short dynamicOfferConfigVersion)
		{
		}

		// Token: 0x06011068 RID: 69736 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011068")]
		[Address(RVA = "0x1F9AC0C", Offset = "0x1F9AC0C", VA = "0x1F9AC0C")]
		public static void AddDynamicOfferUserSegmentVersion(FlatBufferBuilder builder, short dynamicOfferUserSegmentVersion)
		{
		}

		// Token: 0x06011069 RID: 69737 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011069")]
		[Address(RVA = "0x1F9ABEC", Offset = "0x1F9ABEC", VA = "0x1F9ABEC")]
		public static void AddDynamicOfferConfigVersionList(FlatBufferBuilder builder, VectorOffset dynamicOfferConfigVersionListOffset)
		{
		}

		// Token: 0x0601106A RID: 69738 RVA: 0x00063E40 File Offset: 0x00062040
		[Token(Token = "0x601106A")]
		[Address(RVA = "0x1F9ACD0", Offset = "0x1F9ACD0", VA = "0x1F9ACD0")]
		public static VectorOffset CreateDynamicOfferConfigVersionListVector(FlatBufferBuilder builder, Offset<DynamicOfferConfigVersion>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601106B RID: 69739 RVA: 0x00063E58 File Offset: 0x00062058
		[Token(Token = "0x601106B")]
		[Address(RVA = "0x1F9AD78", Offset = "0x1F9AD78", VA = "0x1F9AD78")]
		public static VectorOffset CreateDynamicOfferConfigVersionListVectorBlock(FlatBufferBuilder builder, Offset<DynamicOfferConfigVersion>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601106C RID: 69740 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601106C")]
		[Address(RVA = "0x1F9AE00", Offset = "0x1F9AE00", VA = "0x1F9AE00")]
		public static void StartDynamicOfferConfigVersionListVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x0601106D RID: 69741 RVA: 0x00063E70 File Offset: 0x00062070
		[Token(Token = "0x601106D")]
		[Address(RVA = "0x1F9AC4C", Offset = "0x1F9AC4C", VA = "0x1F9AC4C")]
		public static Offset<DynamicOfferConfigVersions> EndDynamicOfferConfigVersions(FlatBufferBuilder builder)
		{
			return default(Offset<DynamicOfferConfigVersions>);
		}

		// Token: 0x0400E6B5 RID: 59061
		[Token(Token = "0x400E6B5")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
