﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002514 RID: 9492
	[Token(Token = "0x2002514")]
	public class GetAllTimePurchaseHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026CE RID: 9934
		// (get) Token: 0x060128BD RID: 75965 RVA: 0x00077430 File Offset: 0x00075630
		[Token(Token = "0x170026CE")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60128BD")]
			[Address(RVA = "0x1CEAD38", Offset = "0x1CEAD38", VA = "0x1CEAD38", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026CF RID: 9935
		// (get) Token: 0x060128BE RID: 75966 RVA: 0x00077448 File Offset: 0x00075648
		[Token(Token = "0x170026CF")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60128BE")]
			[Address(RVA = "0x1CEAD40", Offset = "0x1CEAD40", VA = "0x1CEAD40", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060128BF RID: 75967 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128BF")]
		[Address(RVA = "0x1CEAD48", Offset = "0x1CEAD48", VA = "0x1CEAD48")]
		public GetAllTimePurchaseHttpCommand(Action onCompleted)
		{
		}

		// Token: 0x060128C0 RID: 75968 RVA: 0x00077460 File Offset: 0x00075660
		[Token(Token = "0x60128C0")]
		[Address(RVA = "0x1CEAD78", Offset = "0x1CEAD78", VA = "0x1CEAD78", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060128C1 RID: 75969 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128C1")]
		[Address(RVA = "0x1CEADF8", Offset = "0x1CEADF8", VA = "0x1CEADF8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060128C2 RID: 75970 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128C2")]
		[Address(RVA = "0x1CEAFF0", Offset = "0x1CEAFF0", VA = "0x1CEAFF0")]
		private void MigrateTotalPurchase(GetAllTimePurchaseResponse response)
		{
		}

		// Token: 0x060128C3 RID: 75971 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128C3")]
		[Address(RVA = "0x1CEB0B0", Offset = "0x1CEB0B0", VA = "0x1CEB0B0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EABF RID: 60095
		[Token(Token = "0x400EABF")]
		[FieldOffset(Offset = "0x18")]
		private readonly Action onCompleted;

		// Token: 0x0400EAC0 RID: 60096
		[Token(Token = "0x400EAC0")]
		[FieldOffset(Offset = "0x20")]
		private long requestUserId;
	}
}
