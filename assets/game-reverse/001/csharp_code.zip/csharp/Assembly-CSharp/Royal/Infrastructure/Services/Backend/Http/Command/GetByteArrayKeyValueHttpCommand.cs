﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002515 RID: 9493
	[Token(Token = "0x2002515")]
	public class GetByteArrayKeyValueHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026D0 RID: 9936
		// (get) Token: 0x060128C4 RID: 75972 RVA: 0x00077478 File Offset: 0x00075678
		[Token(Token = "0x170026D0")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60128C4")]
			[Address(RVA = "0x1CEB0B8", Offset = "0x1CEB0B8", VA = "0x1CEB0B8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026D1 RID: 9937
		// (get) Token: 0x060128C5 RID: 75973 RVA: 0x00077490 File Offset: 0x00075690
		[Token(Token = "0x170026D1")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60128C5")]
			[Address(RVA = "0x1CEB0C0", Offset = "0x1CEB0C0", VA = "0x1CEB0C0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060128C6 RID: 75974 RVA: 0x000774A8 File Offset: 0x000756A8
		[Token(Token = "0x60128C6")]
		[Address(RVA = "0x1CEB0C8", Offset = "0x1CEB0C8", VA = "0x1CEB0C8", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060128C7 RID: 75975 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128C7")]
		[Address(RVA = "0x1CEB148", Offset = "0x1CEB148", VA = "0x1CEB148", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060128C8 RID: 75976 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128C8")]
		[Address(RVA = "0x1CEB3A4", Offset = "0x1CEB3A4", VA = "0x1CEB3A4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x060128C9 RID: 75977 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128C9")]
		[Address(RVA = "0x1CEB420", Offset = "0x1CEB420", VA = "0x1CEB420")]
		public GetByteArrayKeyValueHttpCommand()
		{
		}

		// Token: 0x0400EAC1 RID: 60097
		[Token(Token = "0x400EAC1")]
		[FieldOffset(Offset = "0x18")]
		private long requestUserId;
	}
}
