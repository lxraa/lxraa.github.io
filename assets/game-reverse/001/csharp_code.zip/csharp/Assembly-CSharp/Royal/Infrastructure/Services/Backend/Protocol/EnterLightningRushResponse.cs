﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A5 RID: 9125
	[Token(Token = "0x20023A5")]
	public struct EnterLightningRushResponse : IFlatbufferObject
	{
		// Token: 0x17002051 RID: 8273
		// (get) Token: 0x0601113E RID: 69950 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002051")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601113E")]
			[Address(RVA = "0x1F9DF08", Offset = "0x1F9DF08", VA = "0x1F9DF08", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601113F RID: 69951 RVA: 0x000648F0 File Offset: 0x00062AF0
		[Token(Token = "0x601113F")]
		[Address(RVA = "0x1F9DF10", Offset = "0x1F9DF10", VA = "0x1F9DF10")]
		public static EnterLightningRushResponse GetRootAsEnterLightningRushResponse(ByteBuffer _bb)
		{
			return default(EnterLightningRushResponse);
		}

		// Token: 0x06011140 RID: 69952 RVA: 0x00064908 File Offset: 0x00062B08
		[Token(Token = "0x6011140")]
		[Address(RVA = "0x1F9DF1C", Offset = "0x1F9DF1C", VA = "0x1F9DF1C")]
		public static EnterLightningRushResponse GetRootAsEnterLightningRushResponse(ByteBuffer _bb, EnterLightningRushResponse obj)
		{
			return default(EnterLightningRushResponse);
		}

		// Token: 0x06011141 RID: 69953 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011141")]
		[Address(RVA = "0x1F9DFCC", Offset = "0x1F9DFCC", VA = "0x1F9DFCC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011142 RID: 69954 RVA: 0x00064920 File Offset: 0x00062B20
		[Token(Token = "0x6011142")]
		[Address(RVA = "0x1F9DF94", Offset = "0x1F9DF94", VA = "0x1F9DF94")]
		public EnterLightningRushResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterLightningRushResponse);
		}

		// Token: 0x17002052 RID: 8274
		// (get) Token: 0x06011143 RID: 69955 RVA: 0x00064938 File Offset: 0x00062B38
		[Token(Token = "0x17002052")]
		public EnterEventFailReason FailReason
		{
			[Token(Token = "0x6011143")]
			[Address(RVA = "0x1F9DFDC", Offset = "0x1F9DFDC", VA = "0x1F9DFDC")]
			get
			{
				return EnterEventFailReason.None;
			}
		}

		// Token: 0x17002053 RID: 8275
		// (get) Token: 0x06011144 RID: 69956 RVA: 0x00064950 File Offset: 0x00062B50
		[Token(Token = "0x17002053")]
		public LightningRushInfo? LightningRushInfo
		{
			[Token(Token = "0x6011144")]
			[Address(RVA = "0x1F9E020", Offset = "0x1F9E020", VA = "0x1F9E020")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002054 RID: 8276
		// (get) Token: 0x06011145 RID: 69957 RVA: 0x00064968 File Offset: 0x00062B68
		[Token(Token = "0x17002054")]
		public long DeprecatedTotalUnlimitedLives
		{
			[Token(Token = "0x6011145")]
			[Address(RVA = "0x1F9E0E0", Offset = "0x1F9E0E0", VA = "0x1F9E0E0")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06011146 RID: 69958 RVA: 0x00064980 File Offset: 0x00062B80
		[Token(Token = "0x6011146")]
		[Address(RVA = "0x1F9E128", Offset = "0x1F9E128", VA = "0x1F9E128")]
		public static Offset<EnterLightningRushResponse> CreateEnterLightningRushResponse(FlatBufferBuilder builder, EnterEventFailReason fail_reason = EnterEventFailReason.None, [Optional] Offset<LightningRushInfo> lightning_rush_infoOffset, long deprecated_total_unlimited_lives = 0L)
		{
			return default(Offset<EnterLightningRushResponse>);
		}

		// Token: 0x06011147 RID: 69959 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011147")]
		[Address(RVA = "0x1F9E264", Offset = "0x1F9E264", VA = "0x1F9E264")]
		public static void StartEnterLightningRushResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011148 RID: 69960 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011148")]
		[Address(RVA = "0x1F9E1D8", Offset = "0x1F9E1D8", VA = "0x1F9E1D8")]
		public static void AddFailReason(FlatBufferBuilder builder, EnterEventFailReason failReason)
		{
		}

		// Token: 0x06011149 RID: 69961 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011149")]
		[Address(RVA = "0x1F9E1B8", Offset = "0x1F9E1B8", VA = "0x1F9E1B8")]
		public static void AddLightningRushInfo(FlatBufferBuilder builder, Offset<LightningRushInfo> lightningRushInfoOffset)
		{
		}

		// Token: 0x0601114A RID: 69962 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601114A")]
		[Address(RVA = "0x1F9E198", Offset = "0x1F9E198", VA = "0x1F9E198")]
		public static void AddDeprecatedTotalUnlimitedLives(FlatBufferBuilder builder, long deprecatedTotalUnlimitedLives)
		{
		}

		// Token: 0x0601114B RID: 69963 RVA: 0x00064998 File Offset: 0x00062B98
		[Token(Token = "0x601114B")]
		[Address(RVA = "0x1F9E1F8", Offset = "0x1F9E1F8", VA = "0x1F9E1F8")]
		public static Offset<EnterLightningRushResponse> EndEnterLightningRushResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterLightningRushResponse>);
		}

		// Token: 0x0400E6D3 RID: 59091
		[Token(Token = "0x400E6D3")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
