﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200238C RID: 9100
	[Token(Token = "0x200238C")]
	public struct DragonNestScoreUpdate : IFlatbufferObject
	{
		// Token: 0x17001FF7 RID: 8183
		// (get) Token: 0x06010FEC RID: 69612 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FF7")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010FEC")]
			[Address(RVA = "0x1F98D20", Offset = "0x1F98D20", VA = "0x1F98D20", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FED RID: 69613 RVA: 0x000637C8 File Offset: 0x000619C8
		[Token(Token = "0x6010FED")]
		[Address(RVA = "0x1F98D28", Offset = "0x1F98D28", VA = "0x1F98D28")]
		public static DragonNestScoreUpdate GetRootAsDragonNestScoreUpdate(ByteBuffer _bb)
		{
			return default(DragonNestScoreUpdate);
		}

		// Token: 0x06010FEE RID: 69614 RVA: 0x000637E0 File Offset: 0x000619E0
		[Token(Token = "0x6010FEE")]
		[Address(RVA = "0x1F98D34", Offset = "0x1F98D34", VA = "0x1F98D34")]
		public static DragonNestScoreUpdate GetRootAsDragonNestScoreUpdate(ByteBuffer _bb, DragonNestScoreUpdate obj)
		{
			return default(DragonNestScoreUpdate);
		}

		// Token: 0x06010FEF RID: 69615 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FEF")]
		[Address(RVA = "0x1F98DAC", Offset = "0x1F98DAC", VA = "0x1F98DAC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010FF0 RID: 69616 RVA: 0x000637F8 File Offset: 0x000619F8
		[Token(Token = "0x6010FF0")]
		[Address(RVA = "0x1F98690", Offset = "0x1F98690", VA = "0x1F98690")]
		public DragonNestScoreUpdate __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestScoreUpdate);
		}

		// Token: 0x17001FF8 RID: 8184
		// (get) Token: 0x06010FF1 RID: 69617 RVA: 0x00063810 File Offset: 0x00061A10
		[Token(Token = "0x17001FF8")]
		public long PartnerUserId
		{
			[Token(Token = "0x6010FF1")]
			[Address(RVA = "0x1F98DBC", Offset = "0x1F98DBC", VA = "0x1F98DBC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FF9 RID: 8185
		// (get) Token: 0x06010FF2 RID: 69618 RVA: 0x00063828 File Offset: 0x00061A28
		[Token(Token = "0x17001FF9")]
		public int PartnerScore
		{
			[Token(Token = "0x6010FF2")]
			[Address(RVA = "0x1F98E04", Offset = "0x1F98E04", VA = "0x1F98E04")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010FF3 RID: 69619 RVA: 0x00063840 File Offset: 0x00061A40
		[Token(Token = "0x6010FF3")]
		[Address(RVA = "0x1F98E48", Offset = "0x1F98E48", VA = "0x1F98E48")]
		public static Offset<DragonNestScoreUpdate> CreateDragonNestScoreUpdate(FlatBufferBuilder builder, long partner_user_id = 0L, int partner_score = 0)
		{
			return default(Offset<DragonNestScoreUpdate>);
		}

		// Token: 0x06010FF4 RID: 69620 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FF4")]
		[Address(RVA = "0x1F98F4C", Offset = "0x1F98F4C", VA = "0x1F98F4C")]
		public static void StartDragonNestScoreUpdate(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010FF5 RID: 69621 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FF5")]
		[Address(RVA = "0x1F98EA0", Offset = "0x1F98EA0", VA = "0x1F98EA0")]
		public static void AddPartnerUserId(FlatBufferBuilder builder, long partnerUserId)
		{
		}

		// Token: 0x06010FF6 RID: 69622 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FF6")]
		[Address(RVA = "0x1F98EC0", Offset = "0x1F98EC0", VA = "0x1F98EC0")]
		public static void AddPartnerScore(FlatBufferBuilder builder, int partnerScore)
		{
		}

		// Token: 0x06010FF7 RID: 69623 RVA: 0x00063858 File Offset: 0x00061A58
		[Token(Token = "0x6010FF7")]
		[Address(RVA = "0x1F98EE0", Offset = "0x1F98EE0", VA = "0x1F98EE0")]
		public static Offset<DragonNestScoreUpdate> EndDragonNestScoreUpdate(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestScoreUpdate>);
		}

		// Token: 0x0400E6A5 RID: 59045
		[Token(Token = "0x400E6A5")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
