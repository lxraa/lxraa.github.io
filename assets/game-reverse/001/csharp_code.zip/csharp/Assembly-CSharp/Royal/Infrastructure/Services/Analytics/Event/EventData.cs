﻿using System;
using System.Collections.Generic;
using System.Text;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics.Event
{
	// Token: 0x020025A4 RID: 9636
	[Token(Token = "0x20025A4")]
	public class EventData
	{
		// Token: 0x06012D70 RID: 77168 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D70")]
		[Address(RVA = "0x243C3B4", Offset = "0x243C3B4", VA = "0x243C3B4")]
		public EventData(string name, List<EventParameter> parameters, int timeOffset = 0)
		{
		}

		// Token: 0x06012D71 RID: 77169 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D71")]
		[Address(RVA = "0x243C5F8", Offset = "0x243C5F8", VA = "0x243C5F8")]
		public void ToString(StringBuilder builder)
		{
		}

		// Token: 0x06012D72 RID: 77170 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D72")]
		[Address(RVA = "0x243C7D8", Offset = "0x243C7D8", VA = "0x243C7D8", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x0400ED36 RID: 60726
		[Token(Token = "0x400ED36")]
		[FieldOffset(Offset = "0x0")]
		private static readonly string BasicInfoKey;

		// Token: 0x0400ED37 RID: 60727
		[Token(Token = "0x400ED37")]
		[FieldOffset(Offset = "0x8")]
		private static readonly string DeviceInfoKey;

		// Token: 0x0400ED38 RID: 60728
		[Token(Token = "0x400ED38")]
		[FieldOffset(Offset = "0x10")]
		private static readonly string KeyProperty;

		// Token: 0x0400ED39 RID: 60729
		[Token(Token = "0x400ED39")]
		[FieldOffset(Offset = "0x18")]
		private static readonly string ValueProperty;

		// Token: 0x0400ED3A RID: 60730
		[Token(Token = "0x400ED3A")]
		[FieldOffset(Offset = "0x20")]
		private static readonly string Suffix;

		// Token: 0x0400ED3B RID: 60731
		[Token(Token = "0x400ED3B")]
		[FieldOffset(Offset = "0x28")]
		private static readonly char Underscore;

		// Token: 0x0400ED3C RID: 60732
		[Token(Token = "0x400ED3C")]
		[FieldOffset(Offset = "0x2A")]
		private static readonly char Concat;

		// Token: 0x0400ED3D RID: 60733
		[Token(Token = "0x400ED3D")]
		[FieldOffset(Offset = "0x10")]
		private readonly string name;

		// Token: 0x0400ED3E RID: 60734
		[Token(Token = "0x400ED3E")]
		[FieldOffset(Offset = "0x18")]
		private readonly List<EventParameter> parameters;

		// Token: 0x0400ED3F RID: 60735
		[Token(Token = "0x400ED3F")]
		[FieldOffset(Offset = "0x20")]
		private readonly long eventTime;

		// Token: 0x0400ED40 RID: 60736
		[Token(Token = "0x400ED40")]
		[FieldOffset(Offset = "0x28")]
		private readonly EventParameter basicInfo;

		// Token: 0x0400ED41 RID: 60737
		[Token(Token = "0x400ED41")]
		[FieldOffset(Offset = "0x30")]
		private readonly EventParameter deviceInfo;
	}
}
