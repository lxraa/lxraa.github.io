﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.PropellerRush
{
	// Token: 0x02002552 RID: 9554
	[Token(Token = "0x2002552")]
	public class UpdatePropellerRushScoreHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002765 RID: 10085
		// (get) Token: 0x06012AC7 RID: 76487 RVA: 0x000788A0 File Offset: 0x00076AA0
		[Token(Token = "0x17002765")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AC7")]
			[Address(RVA = "0x1ECDBA8", Offset = "0x1ECDBA8", VA = "0x1ECDBA8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002766 RID: 10086
		// (get) Token: 0x06012AC8 RID: 76488 RVA: 0x000788B8 File Offset: 0x00076AB8
		[Token(Token = "0x17002766")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AC8")]
			[Address(RVA = "0x1ECDBB0", Offset = "0x1ECDBB0", VA = "0x1ECDBB0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AC9 RID: 76489 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AC9")]
		[Address(RVA = "0x1ECDBB8", Offset = "0x1ECDBB8", VA = "0x1ECDBB8")]
		public UpdatePropellerRushScoreHttpCommand(long groupId, int score)
		{
		}

		// Token: 0x06012ACA RID: 76490 RVA: 0x000788D0 File Offset: 0x00076AD0
		[Token(Token = "0x6012ACA")]
		[Address(RVA = "0x1ECDBE8", Offset = "0x1ECDBE8", VA = "0x1ECDBE8", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012ACB RID: 76491 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ACB")]
		[Address(RVA = "0x1ECDC0C", Offset = "0x1ECDC0C", VA = "0x1ECDC0C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012ACC RID: 76492 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ACC")]
		[Address(RVA = "0x1ECDC10", Offset = "0x1ECDC10", VA = "0x1ECDC10", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBA0 RID: 60320
		[Token(Token = "0x400EBA0")]
		[FieldOffset(Offset = "0x18")]
		private readonly long groupId;

		// Token: 0x0400EBA1 RID: 60321
		[Token(Token = "0x400EBA1")]
		[FieldOffset(Offset = "0x20")]
		private readonly int score;

		// Token: 0x0400EBA2 RID: 60322
		[Token(Token = "0x400EBA2")]
		[FieldOffset(Offset = "0x24")]
		private readonly LeaderboardInfoType infoType;
	}
}
