﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200239F RID: 9119
	[Token(Token = "0x200239F")]
	public struct EnterLavaQuestRequest : IFlatbufferObject
	{
		// Token: 0x17002039 RID: 8249
		// (get) Token: 0x060110E6 RID: 69862 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002039")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60110E6")]
			[Address(RVA = "0x1F9C968", Offset = "0x1F9C968", VA = "0x1F9C968", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110E7 RID: 69863 RVA: 0x00064488 File Offset: 0x00062688
		[Token(Token = "0x60110E7")]
		[Address(RVA = "0x1F9C970", Offset = "0x1F9C970", VA = "0x1F9C970")]
		public static EnterLavaQuestRequest GetRootAsEnterLavaQuestRequest(ByteBuffer _bb)
		{
			return default(EnterLavaQuestRequest);
		}

		// Token: 0x060110E8 RID: 69864 RVA: 0x000644A0 File Offset: 0x000626A0
		[Token(Token = "0x60110E8")]
		[Address(RVA = "0x1F9C97C", Offset = "0x1F9C97C", VA = "0x1F9C97C")]
		public static EnterLavaQuestRequest GetRootAsEnterLavaQuestRequest(ByteBuffer _bb, EnterLavaQuestRequest obj)
		{
			return default(EnterLavaQuestRequest);
		}

		// Token: 0x060110E9 RID: 69865 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110E9")]
		[Address(RVA = "0x1F9CA2C", Offset = "0x1F9CA2C", VA = "0x1F9CA2C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060110EA RID: 69866 RVA: 0x000644B8 File Offset: 0x000626B8
		[Token(Token = "0x60110EA")]
		[Address(RVA = "0x1F9C9F4", Offset = "0x1F9C9F4", VA = "0x1F9C9F4")]
		public EnterLavaQuestRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterLavaQuestRequest);
		}

		// Token: 0x1700203A RID: 8250
		// (get) Token: 0x060110EB RID: 69867 RVA: 0x000644D0 File Offset: 0x000626D0
		[Token(Token = "0x1700203A")]
		public int Level
		{
			[Token(Token = "0x60110EB")]
			[Address(RVA = "0x1F9CA3C", Offset = "0x1F9CA3C", VA = "0x1F9CA3C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700203B RID: 8251
		// (get) Token: 0x060110EC RID: 69868 RVA: 0x000644E8 File Offset: 0x000626E8
		[Token(Token = "0x1700203B")]
		public int LeagueLevel
		{
			[Token(Token = "0x60110EC")]
			[Address(RVA = "0x1F9CA80", Offset = "0x1F9CA80", VA = "0x1F9CA80")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060110ED RID: 69869 RVA: 0x00064500 File Offset: 0x00062700
		[Token(Token = "0x60110ED")]
		[Address(RVA = "0x1F9CAC4", Offset = "0x1F9CAC4", VA = "0x1F9CAC4")]
		public static Offset<EnterLavaQuestRequest> CreateEnterLavaQuestRequest(FlatBufferBuilder builder, int level = 0, int league_level = 0)
		{
			return default(Offset<EnterLavaQuestRequest>);
		}

		// Token: 0x060110EE RID: 69870 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110EE")]
		[Address(RVA = "0x1F9CBC8", Offset = "0x1F9CBC8", VA = "0x1F9CBC8")]
		public static void StartEnterLavaQuestRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060110EF RID: 69871 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110EF")]
		[Address(RVA = "0x1F9CB3C", Offset = "0x1F9CB3C", VA = "0x1F9CB3C")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x060110F0 RID: 69872 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110F0")]
		[Address(RVA = "0x1F9CB1C", Offset = "0x1F9CB1C", VA = "0x1F9CB1C")]
		public static void AddLeagueLevel(FlatBufferBuilder builder, int leagueLevel)
		{
		}

		// Token: 0x060110F1 RID: 69873 RVA: 0x00064518 File Offset: 0x00062718
		[Token(Token = "0x60110F1")]
		[Address(RVA = "0x1F9CB5C", Offset = "0x1F9CB5C", VA = "0x1F9CB5C")]
		public static Offset<EnterLavaQuestRequest> EndEnterLavaQuestRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterLavaQuestRequest>);
		}

		// Token: 0x0400E6C8 RID: 59080
		[Token(Token = "0x400E6C8")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
