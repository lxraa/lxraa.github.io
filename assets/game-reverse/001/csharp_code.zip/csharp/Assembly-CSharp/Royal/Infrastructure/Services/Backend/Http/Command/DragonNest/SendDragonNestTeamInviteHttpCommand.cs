﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.DragonNest
{
	// Token: 0x02002570 RID: 9584
	[Token(Token = "0x2002570")]
	public class SendDragonNestTeamInviteHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027AA RID: 10154
		// (get) Token: 0x06012B91 RID: 76689 RVA: 0x00079248 File Offset: 0x00077448
		[Token(Token = "0x170027AA")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B91")]
			[Address(RVA = "0x1ED3AE8", Offset = "0x1ED3AE8", VA = "0x1ED3AE8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027AB RID: 10155
		// (get) Token: 0x06012B92 RID: 76690 RVA: 0x00079260 File Offset: 0x00077460
		[Token(Token = "0x170027AB")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B92")]
			[Address(RVA = "0x1ED3AF0", Offset = "0x1ED3AF0", VA = "0x1ED3AF0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B93 RID: 76691 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B93")]
		[Address(RVA = "0x1ED3AF8", Offset = "0x1ED3AF8", VA = "0x1ED3AF8")]
		public SendDragonNestTeamInviteHttpCommand(long id, string userName, UserProfileSetting userProfileSetting)
		{
		}

		// Token: 0x06012B94 RID: 76692 RVA: 0x00079278 File Offset: 0x00077478
		[Token(Token = "0x6012B94")]
		[Address(RVA = "0x1ED3B4C", Offset = "0x1ED3B4C", VA = "0x1ED3B4C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B95 RID: 76693 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B95")]
		[Address(RVA = "0x1ED3C34", Offset = "0x1ED3C34", VA = "0x1ED3C34", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B96 RID: 76694 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B96")]
		[Address(RVA = "0x1ED3E10", Offset = "0x1ED3E10", VA = "0x1ED3E10", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBEF RID: 60399
		[Token(Token = "0x400EBEF")]
		[FieldOffset(Offset = "0x18")]
		private readonly long teamId;

		// Token: 0x0400EBF0 RID: 60400
		[Token(Token = "0x400EBF0")]
		[FieldOffset(Offset = "0x20")]
		private readonly string name;

		// Token: 0x0400EBF1 RID: 60401
		[Token(Token = "0x400EBF1")]
		[FieldOffset(Offset = "0x28")]
		private readonly UserProfileSetting setting;
	}
}
