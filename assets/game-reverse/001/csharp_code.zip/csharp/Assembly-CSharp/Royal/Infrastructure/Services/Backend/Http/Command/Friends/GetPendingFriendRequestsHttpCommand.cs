﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Friends
{
	// Token: 0x0200256A RID: 9578
	[Token(Token = "0x200256A")]
	public class GetPendingFriendRequestsHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700279E RID: 10142
		// (get) Token: 0x06012B6C RID: 76652 RVA: 0x00079080 File Offset: 0x00077280
		[Token(Token = "0x1700279E")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B6C")]
			[Address(RVA = "0x1ED21B0", Offset = "0x1ED21B0", VA = "0x1ED21B0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700279F RID: 10143
		// (get) Token: 0x06012B6D RID: 76653 RVA: 0x00079098 File Offset: 0x00077298
		[Token(Token = "0x1700279F")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B6D")]
			[Address(RVA = "0x1ED21B8", Offset = "0x1ED21B8", VA = "0x1ED21B8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B6E RID: 76654 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B6E")]
		[Address(RVA = "0x1ED21C0", Offset = "0x1ED21C0", VA = "0x1ED21C0")]
		public GetPendingFriendRequestsHttpCommand(Action onCompleted)
		{
		}

		// Token: 0x06012B6F RID: 76655 RVA: 0x000790B0 File Offset: 0x000772B0
		[Token(Token = "0x6012B6F")]
		[Address(RVA = "0x1ED21F0", Offset = "0x1ED21F0", VA = "0x1ED21F0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B70 RID: 76656 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B70")]
		[Address(RVA = "0x1ED2218", Offset = "0x1ED2218", VA = "0x1ED2218", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B71 RID: 76657 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B71")]
		[Address(RVA = "0x1ED23F4", Offset = "0x1ED23F4", VA = "0x1ED23F4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBE0 RID: 60384
		[Token(Token = "0x400EBE0")]
		[FieldOffset(Offset = "0x18")]
		private readonly Action onCompleted;
	}
}
