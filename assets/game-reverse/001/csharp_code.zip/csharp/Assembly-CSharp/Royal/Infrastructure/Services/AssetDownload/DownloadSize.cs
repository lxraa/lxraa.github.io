﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002589 RID: 9609
	[Token(Token = "0x2002589")]
	public enum DownloadSize
	{
		// Token: 0x0400EC65 RID: 60517
		[Token(Token = "0x400EC65")]
		VerySmall,
		// Token: 0x0400EC66 RID: 60518
		[Token(Token = "0x400EC66")]
		Small,
		// Token: 0x0400EC67 RID: 60519
		[Token(Token = "0x400EC67")]
		Medium,
		// Token: 0x0400EC68 RID: 60520
		[Token(Token = "0x400EC68")]
		Large,
		// Token: 0x0400EC69 RID: 60521
		[Token(Token = "0x400EC69")]
		VeryLarge
	}
}
