﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.League
{
	// Token: 0x02002560 RID: 9568
	[Token(Token = "0x2002560")]
	public class GetLeagueInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002787 RID: 10119
		// (get) Token: 0x06012B2C RID: 76588 RVA: 0x00078D80 File Offset: 0x00076F80
		[Token(Token = "0x17002787")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B2C")]
			[Address(RVA = "0x1ED03D4", Offset = "0x1ED03D4", VA = "0x1ED03D4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002788 RID: 10120
		// (get) Token: 0x06012B2D RID: 76589 RVA: 0x00078D98 File Offset: 0x00076F98
		[Token(Token = "0x17002788")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B2D")]
			[Address(RVA = "0x1ED03DC", Offset = "0x1ED03DC", VA = "0x1ED03DC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002789 RID: 10121
		// (get) Token: 0x06012B2E RID: 76590 RVA: 0x00078DB0 File Offset: 0x00076FB0
		// (set) Token: 0x06012B2F RID: 76591 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002789")]
		private GetLeagueInfoResponse Response
		{
			[Token(Token = "0x6012B2E")]
			[Address(RVA = "0x1ED03E4", Offset = "0x1ED03E4", VA = "0x1ED03E4")]
			get
			{
				return default(GetLeagueInfoResponse);
			}
			[Token(Token = "0x6012B2F")]
			[Address(RVA = "0x1ED03F0", Offset = "0x1ED03F0", VA = "0x1ED03F0")]
			set
			{
			}
		}

		// Token: 0x06012B30 RID: 76592 RVA: 0x00078DC8 File Offset: 0x00076FC8
		[Token(Token = "0x6012B30")]
		[Address(RVA = "0x1ED0400", Offset = "0x1ED0400", VA = "0x1ED0400", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B31 RID: 76593 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B31")]
		[Address(RVA = "0x1ED048C", Offset = "0x1ED048C", VA = "0x1ED048C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B32 RID: 76594 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B32")]
		[Address(RVA = "0x1ED0678", Offset = "0x1ED0678", VA = "0x1ED0678", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012B33 RID: 76595 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B33")]
		[Address(RVA = "0x1ED067C", Offset = "0x1ED067C", VA = "0x1ED067C")]
		public GetLeagueInfoHttpCommand()
		{
		}

		// Token: 0x0400EBBC RID: 60348
		[Token(Token = "0x400EBBC")]
		[FieldOffset(Offset = "0x18")]
		private GetLeagueInfoResponse <Response>k__BackingField;
	}
}
