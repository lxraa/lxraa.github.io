﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200235C RID: 9052
	[Token(Token = "0x200235C")]
	public struct ClaimLeagueRewardRequest : IFlatbufferObject
	{
		// Token: 0x17001F2F RID: 7983
		// (get) Token: 0x06010D12 RID: 68882 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F2F")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D12")]
			[Address(RVA = "0x2148B50", Offset = "0x2148B50", VA = "0x2148B50", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D13 RID: 68883 RVA: 0x00061278 File Offset: 0x0005F478
		[Token(Token = "0x6010D13")]
		[Address(RVA = "0x2148B58", Offset = "0x2148B58", VA = "0x2148B58")]
		public static ClaimLeagueRewardRequest GetRootAsClaimLeagueRewardRequest(ByteBuffer _bb)
		{
			return default(ClaimLeagueRewardRequest);
		}

		// Token: 0x06010D14 RID: 68884 RVA: 0x00061290 File Offset: 0x0005F490
		[Token(Token = "0x6010D14")]
		[Address(RVA = "0x2148B64", Offset = "0x2148B64", VA = "0x2148B64")]
		public static ClaimLeagueRewardRequest GetRootAsClaimLeagueRewardRequest(ByteBuffer _bb, ClaimLeagueRewardRequest obj)
		{
			return default(ClaimLeagueRewardRequest);
		}

		// Token: 0x06010D15 RID: 68885 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D15")]
		[Address(RVA = "0x2148C14", Offset = "0x2148C14", VA = "0x2148C14", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D16 RID: 68886 RVA: 0x000612A8 File Offset: 0x0005F4A8
		[Token(Token = "0x6010D16")]
		[Address(RVA = "0x2148BDC", Offset = "0x2148BDC", VA = "0x2148BDC")]
		public ClaimLeagueRewardRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimLeagueRewardRequest);
		}

		// Token: 0x17001F30 RID: 7984
		// (get) Token: 0x06010D17 RID: 68887 RVA: 0x000612C0 File Offset: 0x0005F4C0
		[Token(Token = "0x17001F30")]
		public CurrentUserInventory? DeprecatedCurrentUserInventory
		{
			[Token(Token = "0x6010D17")]
			[Address(RVA = "0x2148C24", Offset = "0x2148C24", VA = "0x2148C24")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D18 RID: 68888 RVA: 0x000612D8 File Offset: 0x0005F4D8
		[Token(Token = "0x6010D18")]
		[Address(RVA = "0x2148CE4", Offset = "0x2148CE4", VA = "0x2148CE4")]
		public static Offset<ClaimLeagueRewardRequest> CreateClaimLeagueRewardRequest(FlatBufferBuilder builder, [Optional] Offset<CurrentUserInventory> deprecated_current_user_inventoryOffset)
		{
			return default(Offset<ClaimLeagueRewardRequest>);
		}

		// Token: 0x06010D19 RID: 68889 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D19")]
		[Address(RVA = "0x2148DB8", Offset = "0x2148DB8", VA = "0x2148DB8")]
		public static void StartClaimLeagueRewardRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D1A RID: 68890 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D1A")]
		[Address(RVA = "0x2148D2C", Offset = "0x2148D2C", VA = "0x2148D2C")]
		public static void AddDeprecatedCurrentUserInventory(FlatBufferBuilder builder, Offset<CurrentUserInventory> deprecatedCurrentUserInventoryOffset)
		{
		}

		// Token: 0x06010D1B RID: 68891 RVA: 0x000612F0 File Offset: 0x0005F4F0
		[Token(Token = "0x6010D1B")]
		[Address(RVA = "0x2148D4C", Offset = "0x2148D4C", VA = "0x2148D4C")]
		public static Offset<ClaimLeagueRewardRequest> EndClaimLeagueRewardRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimLeagueRewardRequest>);
		}

		// Token: 0x0400E662 RID: 58978
		[Token(Token = "0x400E662")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
