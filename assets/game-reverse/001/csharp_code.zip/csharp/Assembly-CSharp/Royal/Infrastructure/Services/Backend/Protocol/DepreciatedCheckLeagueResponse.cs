﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200237F RID: 9087
	[Token(Token = "0x200237F")]
	public struct DepreciatedCheckLeagueResponse : IFlatbufferObject
	{
		// Token: 0x17001FCD RID: 8141
		// (get) Token: 0x06010F46 RID: 69446 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FCD")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F46")]
			[Address(RVA = "0x1F9675C", Offset = "0x1F9675C", VA = "0x1F9675C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F47 RID: 69447 RVA: 0x00062EF8 File Offset: 0x000610F8
		[Token(Token = "0x6010F47")]
		[Address(RVA = "0x1F96764", Offset = "0x1F96764", VA = "0x1F96764")]
		public static DepreciatedCheckLeagueResponse GetRootAsDepreciatedCheckLeagueResponse(ByteBuffer _bb)
		{
			return default(DepreciatedCheckLeagueResponse);
		}

		// Token: 0x06010F48 RID: 69448 RVA: 0x00062F10 File Offset: 0x00061110
		[Token(Token = "0x6010F48")]
		[Address(RVA = "0x1F96770", Offset = "0x1F96770", VA = "0x1F96770")]
		public static DepreciatedCheckLeagueResponse GetRootAsDepreciatedCheckLeagueResponse(ByteBuffer _bb, DepreciatedCheckLeagueResponse obj)
		{
			return default(DepreciatedCheckLeagueResponse);
		}

		// Token: 0x06010F49 RID: 69449 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F49")]
		[Address(RVA = "0x1F96820", Offset = "0x1F96820", VA = "0x1F96820", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F4A RID: 69450 RVA: 0x00062F28 File Offset: 0x00061128
		[Token(Token = "0x6010F4A")]
		[Address(RVA = "0x1F967E8", Offset = "0x1F967E8", VA = "0x1F967E8")]
		public DepreciatedCheckLeagueResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(DepreciatedCheckLeagueResponse);
		}

		// Token: 0x17001FCE RID: 8142
		// (get) Token: 0x06010F4B RID: 69451 RVA: 0x00062F40 File Offset: 0x00061140
		[Token(Token = "0x17001FCE")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010F4B")]
			[Address(RVA = "0x1F96830", Offset = "0x1F96830", VA = "0x1F96830")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001FCF RID: 8143
		// (get) Token: 0x06010F4C RID: 69452 RVA: 0x00062F58 File Offset: 0x00061158
		[Token(Token = "0x17001FCF")]
		public int LeagueId
		{
			[Token(Token = "0x6010F4C")]
			[Address(RVA = "0x1F96874", Offset = "0x1F96874", VA = "0x1F96874")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010F4D RID: 69453 RVA: 0x00062F70 File Offset: 0x00061170
		[Token(Token = "0x6010F4D")]
		[Address(RVA = "0x1F968B8", Offset = "0x1F968B8", VA = "0x1F968B8")]
		public static Offset<DepreciatedCheckLeagueResponse> CreateDepreciatedCheckLeagueResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, int league_id = 0)
		{
			return default(Offset<DepreciatedCheckLeagueResponse>);
		}

		// Token: 0x06010F4E RID: 69454 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F4E")]
		[Address(RVA = "0x1F969BC", Offset = "0x1F969BC", VA = "0x1F969BC")]
		public static void StartDepreciatedCheckLeagueResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F4F RID: 69455 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F4F")]
		[Address(RVA = "0x1F96930", Offset = "0x1F96930", VA = "0x1F96930")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010F50 RID: 69456 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F50")]
		[Address(RVA = "0x1F96910", Offset = "0x1F96910", VA = "0x1F96910")]
		public static void AddLeagueId(FlatBufferBuilder builder, int leagueId)
		{
		}

		// Token: 0x06010F51 RID: 69457 RVA: 0x00062F88 File Offset: 0x00061188
		[Token(Token = "0x6010F51")]
		[Address(RVA = "0x1F96950", Offset = "0x1F96950", VA = "0x1F96950")]
		public static Offset<DepreciatedCheckLeagueResponse> EndDepreciatedCheckLeagueResponse(FlatBufferBuilder builder)
		{
			return default(Offset<DepreciatedCheckLeagueResponse>);
		}

		// Token: 0x0400E698 RID: 59032
		[Token(Token = "0x400E698")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
