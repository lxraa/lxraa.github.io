﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x0200259F RID: 9631
	[Token(Token = "0x200259F")]
	public class DragonNestDragonInfo
	{
		// Token: 0x06012D57 RID: 77143 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D57")]
		[Address(RVA = "0x243AA44", Offset = "0x243AA44", VA = "0x243AA44")]
		public DragonNestDragonInfo()
		{
		}

		// Token: 0x0400ED29 RID: 60713
		[Token(Token = "0x400ED29")]
		[FieldOffset(Offset = "0x10")]
		public int dragon_type;

		// Token: 0x0400ED2A RID: 60714
		[Token(Token = "0x400ED2A")]
		[FieldOffset(Offset = "0x14")]
		public int myScore;

		// Token: 0x0400ED2B RID: 60715
		[Token(Token = "0x400ED2B")]
		[FieldOffset(Offset = "0x18")]
		public int partnerScore;

		// Token: 0x0400ED2C RID: 60716
		[Token(Token = "0x400ED2C")]
		[FieldOffset(Offset = "0x1C")]
		public int rewardStep;
	}
}
