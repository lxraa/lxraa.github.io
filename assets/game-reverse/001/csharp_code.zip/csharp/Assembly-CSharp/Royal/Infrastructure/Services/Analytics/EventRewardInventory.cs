﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002597 RID: 9623
	[Token(Token = "0x2002597")]
	public class EventRewardInventory
	{
		// Token: 0x06012D4F RID: 77135 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D4F")]
		[Address(RVA = "0x243AA04", Offset = "0x243AA04", VA = "0x243AA04")]
		public EventRewardInventory()
		{
		}

		// Token: 0x0400ECDC RID: 60636
		[Token(Token = "0x400ECDC")]
		[FieldOffset(Offset = "0x10")]
		public int r_pickaxe;

		// Token: 0x0400ECDD RID: 60637
		[Token(Token = "0x400ECDD")]
		[FieldOffset(Offset = "0x14")]
		public int r_elixir;
	}
}
