﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A4 RID: 9124
	[Token(Token = "0x20023A4")]
	public struct EnterLightningRushRequest : IFlatbufferObject
	{
		// Token: 0x1700204C RID: 8268
		// (get) Token: 0x0601112E RID: 69934 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700204C")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601112E")]
			[Address(RVA = "0x1F9DB9C", Offset = "0x1F9DB9C", VA = "0x1F9DB9C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601112F RID: 69935 RVA: 0x00064818 File Offset: 0x00062A18
		[Token(Token = "0x601112F")]
		[Address(RVA = "0x1F9DBA4", Offset = "0x1F9DBA4", VA = "0x1F9DBA4")]
		public static EnterLightningRushRequest GetRootAsEnterLightningRushRequest(ByteBuffer _bb)
		{
			return default(EnterLightningRushRequest);
		}

		// Token: 0x06011130 RID: 69936 RVA: 0x00064830 File Offset: 0x00062A30
		[Token(Token = "0x6011130")]
		[Address(RVA = "0x1F9DBB0", Offset = "0x1F9DBB0", VA = "0x1F9DBB0")]
		public static EnterLightningRushRequest GetRootAsEnterLightningRushRequest(ByteBuffer _bb, EnterLightningRushRequest obj)
		{
			return default(EnterLightningRushRequest);
		}

		// Token: 0x06011131 RID: 69937 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011131")]
		[Address(RVA = "0x1F9DC60", Offset = "0x1F9DC60", VA = "0x1F9DC60", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011132 RID: 69938 RVA: 0x00064848 File Offset: 0x00062A48
		[Token(Token = "0x6011132")]
		[Address(RVA = "0x1F9DC28", Offset = "0x1F9DC28", VA = "0x1F9DC28")]
		public EnterLightningRushRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterLightningRushRequest);
		}

		// Token: 0x1700204D RID: 8269
		// (get) Token: 0x06011133 RID: 69939 RVA: 0x00064860 File Offset: 0x00062A60
		[Token(Token = "0x1700204D")]
		public int EnterDay
		{
			[Token(Token = "0x6011133")]
			[Address(RVA = "0x1F9DC70", Offset = "0x1F9DC70", VA = "0x1F9DC70")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700204E RID: 8270
		// (get) Token: 0x06011134 RID: 69940 RVA: 0x00064878 File Offset: 0x00062A78
		[Token(Token = "0x1700204E")]
		public int Level
		{
			[Token(Token = "0x6011134")]
			[Address(RVA = "0x1F9DCB4", Offset = "0x1F9DCB4", VA = "0x1F9DCB4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700204F RID: 8271
		// (get) Token: 0x06011135 RID: 69941 RVA: 0x00064890 File Offset: 0x00062A90
		[Token(Token = "0x1700204F")]
		public int LeagueLevel
		{
			[Token(Token = "0x6011135")]
			[Address(RVA = "0x1F9DCF8", Offset = "0x1F9DCF8", VA = "0x1F9DCF8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002050 RID: 8272
		// (get) Token: 0x06011136 RID: 69942 RVA: 0x000648A8 File Offset: 0x00062AA8
		[Token(Token = "0x17002050")]
		public long CurrentUnlimitedLives
		{
			[Token(Token = "0x6011136")]
			[Address(RVA = "0x1F9DD3C", Offset = "0x1F9DD3C", VA = "0x1F9DD3C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06011137 RID: 69943 RVA: 0x000648C0 File Offset: 0x00062AC0
		[Token(Token = "0x6011137")]
		[Address(RVA = "0x1F9DD84", Offset = "0x1F9DD84", VA = "0x1F9DD84")]
		public static Offset<EnterLightningRushRequest> CreateEnterLightningRushRequest(FlatBufferBuilder builder, int enter_day = 0, int level = 0, int league_level = 0, long current_unlimited_lives = 0L)
		{
			return default(Offset<EnterLightningRushRequest>);
		}

		// Token: 0x06011138 RID: 69944 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011138")]
		[Address(RVA = "0x1F9DEF0", Offset = "0x1F9DEF0", VA = "0x1F9DEF0")]
		public static void StartEnterLightningRushRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011139 RID: 69945 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011139")]
		[Address(RVA = "0x1F9DE64", Offset = "0x1F9DE64", VA = "0x1F9DE64")]
		public static void AddEnterDay(FlatBufferBuilder builder, int enterDay)
		{
		}

		// Token: 0x0601113A RID: 69946 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601113A")]
		[Address(RVA = "0x1F9DE44", Offset = "0x1F9DE44", VA = "0x1F9DE44")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x0601113B RID: 69947 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601113B")]
		[Address(RVA = "0x1F9DE24", Offset = "0x1F9DE24", VA = "0x1F9DE24")]
		public static void AddLeagueLevel(FlatBufferBuilder builder, int leagueLevel)
		{
		}

		// Token: 0x0601113C RID: 69948 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601113C")]
		[Address(RVA = "0x1F9DE04", Offset = "0x1F9DE04", VA = "0x1F9DE04")]
		public static void AddCurrentUnlimitedLives(FlatBufferBuilder builder, long currentUnlimitedLives)
		{
		}

		// Token: 0x0601113D RID: 69949 RVA: 0x000648D8 File Offset: 0x00062AD8
		[Token(Token = "0x601113D")]
		[Address(RVA = "0x1F9DE84", Offset = "0x1F9DE84", VA = "0x1F9DE84")]
		public static Offset<EnterLightningRushRequest> EndEnterLightningRushRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterLightningRushRequest>);
		}

		// Token: 0x0400E6D2 RID: 59090
		[Token(Token = "0x400E6D2")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
