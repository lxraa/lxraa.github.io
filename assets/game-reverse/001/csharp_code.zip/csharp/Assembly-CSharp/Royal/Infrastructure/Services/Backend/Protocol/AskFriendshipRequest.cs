﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200233E RID: 9022
	[Token(Token = "0x200233E")]
	public struct AskFriendshipRequest : IFlatbufferObject
	{
		// Token: 0x17001EC9 RID: 7881
		// (get) Token: 0x06010B85 RID: 68485 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EC9")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B85")]
			[Address(RVA = "0x2143008", Offset = "0x2143008", VA = "0x2143008", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B86 RID: 68486 RVA: 0x0005FEB0 File Offset: 0x0005E0B0
		[Token(Token = "0x6010B86")]
		[Address(RVA = "0x2143010", Offset = "0x2143010", VA = "0x2143010")]
		public static AskFriendshipRequest GetRootAsAskFriendshipRequest(ByteBuffer _bb)
		{
			return default(AskFriendshipRequest);
		}

		// Token: 0x06010B87 RID: 68487 RVA: 0x0005FEC8 File Offset: 0x0005E0C8
		[Token(Token = "0x6010B87")]
		[Address(RVA = "0x214301C", Offset = "0x214301C", VA = "0x214301C")]
		public static AskFriendshipRequest GetRootAsAskFriendshipRequest(ByteBuffer _bb, AskFriendshipRequest obj)
		{
			return default(AskFriendshipRequest);
		}

		// Token: 0x06010B88 RID: 68488 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B88")]
		[Address(RVA = "0x21430CC", Offset = "0x21430CC", VA = "0x21430CC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B89 RID: 68489 RVA: 0x0005FEE0 File Offset: 0x0005E0E0
		[Token(Token = "0x6010B89")]
		[Address(RVA = "0x2143094", Offset = "0x2143094", VA = "0x2143094")]
		public AskFriendshipRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(AskFriendshipRequest);
		}

		// Token: 0x17001ECA RID: 7882
		// (get) Token: 0x06010B8A RID: 68490 RVA: 0x0005FEF8 File Offset: 0x0005E0F8
		[Token(Token = "0x17001ECA")]
		public long UserId
		{
			[Token(Token = "0x6010B8A")]
			[Address(RVA = "0x21430DC", Offset = "0x21430DC", VA = "0x21430DC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001ECB RID: 7883
		// (get) Token: 0x06010B8B RID: 68491 RVA: 0x0005FF10 File Offset: 0x0005E110
		[Token(Token = "0x17001ECB")]
		public bool IsDeeplink
		{
			[Token(Token = "0x6010B8B")]
			[Address(RVA = "0x2143124", Offset = "0x2143124", VA = "0x2143124")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06010B8C RID: 68492 RVA: 0x0005FF28 File Offset: 0x0005E128
		[Token(Token = "0x6010B8C")]
		[Address(RVA = "0x214316C", Offset = "0x214316C", VA = "0x214316C")]
		public static Offset<AskFriendshipRequest> CreateAskFriendshipRequest(FlatBufferBuilder builder, long user_id = 0L, bool is_deeplink = false)
		{
			return default(Offset<AskFriendshipRequest>);
		}

		// Token: 0x06010B8D RID: 68493 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B8D")]
		[Address(RVA = "0x2143270", Offset = "0x2143270", VA = "0x2143270")]
		public static void StartAskFriendshipRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B8E RID: 68494 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B8E")]
		[Address(RVA = "0x21431C4", Offset = "0x21431C4", VA = "0x21431C4")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010B8F RID: 68495 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B8F")]
		[Address(RVA = "0x21431E4", Offset = "0x21431E4", VA = "0x21431E4")]
		public static void AddIsDeeplink(FlatBufferBuilder builder, bool isDeeplink)
		{
		}

		// Token: 0x06010B90 RID: 68496 RVA: 0x0005FF40 File Offset: 0x0005E140
		[Token(Token = "0x6010B90")]
		[Address(RVA = "0x2143204", Offset = "0x2143204", VA = "0x2143204")]
		public static Offset<AskFriendshipRequest> EndAskFriendshipRequest(FlatBufferBuilder builder)
		{
			return default(Offset<AskFriendshipRequest>);
		}

		// Token: 0x0400E61F RID: 58911
		[Token(Token = "0x400E61F")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
