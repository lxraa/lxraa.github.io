﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Infrastructure.Services.Storage.Tables;

namespace Royal.Infrastructure.Services.Backend.Http.Command.DragonNest
{
	// Token: 0x0200256F RID: 9583
	[Token(Token = "0x200256F")]
	public class SendDragonNestInvitationHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027A8 RID: 10152
		// (get) Token: 0x06012B8B RID: 76683 RVA: 0x00079200 File Offset: 0x00077400
		[Token(Token = "0x170027A8")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B8B")]
			[Address(RVA = "0x1ED318C", Offset = "0x1ED318C", VA = "0x1ED318C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027A9 RID: 10153
		// (get) Token: 0x06012B8C RID: 76684 RVA: 0x00079218 File Offset: 0x00077418
		[Token(Token = "0x170027A9")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B8C")]
			[Address(RVA = "0x1ED3194", Offset = "0x1ED3194", VA = "0x1ED3194", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B8D RID: 76685 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B8D")]
		[Address(RVA = "0x1ED319C", Offset = "0x1ED319C", VA = "0x1ED319C")]
		public SendDragonNestInvitationHttpCommand(DragonNestUserProfileTableItem invitedUserProfile, CoopEventInvitationType type, bool isTeamInvite, bool isFriend, Action onCommandFinished)
		{
		}

		// Token: 0x06012B8E RID: 76686 RVA: 0x00079230 File Offset: 0x00077430
		[Token(Token = "0x6012B8E")]
		[Address(RVA = "0x1ED3478", Offset = "0x1ED3478", VA = "0x1ED3478", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B8F RID: 76687 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B8F")]
		[Address(RVA = "0x1ED34AC", Offset = "0x1ED34AC", VA = "0x1ED34AC", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B90 RID: 76688 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B90")]
		[Address(RVA = "0x1ED3980", Offset = "0x1ED3980", VA = "0x1ED3980", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBEA RID: 60394
		[Token(Token = "0x400EBEA")]
		[FieldOffset(Offset = "0x18")]
		private readonly DragonNestUserProfileTableItem invitedUserProfile;

		// Token: 0x0400EBEB RID: 60395
		[Token(Token = "0x400EBEB")]
		[FieldOffset(Offset = "0x20")]
		private readonly CoopEventInvitationType invitationType;

		// Token: 0x0400EBEC RID: 60396
		[Token(Token = "0x400EBEC")]
		[FieldOffset(Offset = "0x21")]
		private readonly bool isTeamInvite;

		// Token: 0x0400EBED RID: 60397
		[Token(Token = "0x400EBED")]
		[FieldOffset(Offset = "0x22")]
		private readonly bool isFriend;

		// Token: 0x0400EBEE RID: 60398
		[Token(Token = "0x400EBEE")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action onCommandFinished;
	}
}
