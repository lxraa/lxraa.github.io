﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023BD RID: 9149
	[Token(Token = "0x20023BD")]
	public struct GameReward : IFlatbufferObject
	{
		// Token: 0x170020B4 RID: 8372
		// (get) Token: 0x06011297 RID: 70295 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020B4")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011297")]
			[Address(RVA = "0x1CAB458", Offset = "0x1CAB458", VA = "0x1CAB458", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011298 RID: 70296 RVA: 0x00065A90 File Offset: 0x00063C90
		[Token(Token = "0x6011298")]
		[Address(RVA = "0x1CAB460", Offset = "0x1CAB460", VA = "0x1CAB460")]
		public static GameReward GetRootAsGameReward(ByteBuffer _bb)
		{
			return default(GameReward);
		}

		// Token: 0x06011299 RID: 70297 RVA: 0x00065AA8 File Offset: 0x00063CA8
		[Token(Token = "0x6011299")]
		[Address(RVA = "0x1CAB46C", Offset = "0x1CAB46C", VA = "0x1CAB46C")]
		public static GameReward GetRootAsGameReward(ByteBuffer _bb, GameReward obj)
		{
			return default(GameReward);
		}

		// Token: 0x0601129A RID: 70298 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601129A")]
		[Address(RVA = "0x1CAB51C", Offset = "0x1CAB51C", VA = "0x1CAB51C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601129B RID: 70299 RVA: 0x00065AC0 File Offset: 0x00063CC0
		[Token(Token = "0x601129B")]
		[Address(RVA = "0x1CAB4E4", Offset = "0x1CAB4E4", VA = "0x1CAB4E4")]
		public GameReward __assign(int _i, ByteBuffer _bb)
		{
			return default(GameReward);
		}

		// Token: 0x170020B5 RID: 8373
		// (get) Token: 0x0601129C RID: 70300 RVA: 0x00065AD8 File Offset: 0x00063CD8
		[Token(Token = "0x170020B5")]
		public GameRewardType Type
		{
			[Token(Token = "0x601129C")]
			[Address(RVA = "0x1CAB52C", Offset = "0x1CAB52C", VA = "0x1CAB52C")]
			get
			{
				return GameRewardType.NONE;
			}
		}

		// Token: 0x170020B6 RID: 8374
		// (get) Token: 0x0601129D RID: 70301 RVA: 0x00065AF0 File Offset: 0x00063CF0
		[Token(Token = "0x170020B6")]
		public int Amount
		{
			[Token(Token = "0x601129D")]
			[Address(RVA = "0x1CAB570", Offset = "0x1CAB570", VA = "0x1CAB570")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601129E RID: 70302 RVA: 0x00065B08 File Offset: 0x00063D08
		[Token(Token = "0x601129E")]
		[Address(RVA = "0x1CAB5B4", Offset = "0x1CAB5B4", VA = "0x1CAB5B4")]
		public static Offset<GameReward> CreateGameReward(FlatBufferBuilder builder, GameRewardType type = GameRewardType.NONE, int amount = 0)
		{
			return default(Offset<GameReward>);
		}

		// Token: 0x0601129F RID: 70303 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601129F")]
		[Address(RVA = "0x1CAB6B8", Offset = "0x1CAB6B8", VA = "0x1CAB6B8")]
		public static void StartGameReward(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060112A0 RID: 70304 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112A0")]
		[Address(RVA = "0x1CAB62C", Offset = "0x1CAB62C", VA = "0x1CAB62C")]
		public static void AddType(FlatBufferBuilder builder, GameRewardType type)
		{
		}

		// Token: 0x060112A1 RID: 70305 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112A1")]
		[Address(RVA = "0x1CAB60C", Offset = "0x1CAB60C", VA = "0x1CAB60C")]
		public static void AddAmount(FlatBufferBuilder builder, int amount)
		{
		}

		// Token: 0x060112A2 RID: 70306 RVA: 0x00065B20 File Offset: 0x00063D20
		[Token(Token = "0x60112A2")]
		[Address(RVA = "0x1CAB64C", Offset = "0x1CAB64C", VA = "0x1CAB64C")]
		public static Offset<GameReward> EndGameReward(FlatBufferBuilder builder)
		{
			return default(Offset<GameReward>);
		}

		// Token: 0x0400E711 RID: 59153
		[Token(Token = "0x400E711")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
