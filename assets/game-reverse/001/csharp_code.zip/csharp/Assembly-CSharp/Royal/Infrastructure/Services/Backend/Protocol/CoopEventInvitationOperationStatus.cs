﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200236F RID: 9071
	[Token(Token = "0x200236F")]
	public enum CoopEventInvitationOperationStatus : sbyte
	{
		// Token: 0x0400E678 RID: 59000
		[Token(Token = "0x400E678")]
		Ok,
		// Token: 0x0400E679 RID: 59001
		[Token(Token = "0x400E679")]
		AlreadyMatched,
		// Token: 0x0400E67A RID: 59002
		[Token(Token = "0x400E67A")]
		Fail,
		// Token: 0x0400E67B RID: 59003
		[Token(Token = "0x400E67B")]
		TooManyRequests,
		// Token: 0x0400E67C RID: 59004
		[Token(Token = "0x400E67C")]
		FullSlot,
		// Token: 0x0400E67D RID: 59005
		[Token(Token = "0x400E67D")]
		UserRejectedBefore,
		// Token: 0x0400E67E RID: 59006
		[Token(Token = "0x400E67E")]
		TeamInvitationDoesNotExist,
		// Token: 0x0400E67F RID: 59007
		[Token(Token = "0x400E67F")]
		UserDetachedOrBanned,
		// Token: 0x0400E680 RID: 59008
		[Token(Token = "0x400E680")]
		EventNotActive
	}
}
