﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002339 RID: 9017
	[Token(Token = "0x2002339")]
	public enum ArcheryArenaFailReason : sbyte
	{
		// Token: 0x0400E614 RID: 58900
		[Token(Token = "0x400E614")]
		None,
		// Token: 0x0400E615 RID: 58901
		[Token(Token = "0x400E615")]
		AlreadyEntered,
		// Token: 0x0400E616 RID: 58902
		[Token(Token = "0x400E616")]
		AlreadyClaimed,
		// Token: 0x0400E617 RID: 58903
		[Token(Token = "0x400E617")]
		EventDeleted,
		// Token: 0x0400E618 RID: 58904
		[Token(Token = "0x400E618")]
		LevelNotReached,
		// Token: 0x0400E619 RID: 58905
		[Token(Token = "0x400E619")]
		EventNotActive,
		// Token: 0x0400E61A RID: 58906
		[Token(Token = "0x400E61A")]
		NotInEvent
	}
}
