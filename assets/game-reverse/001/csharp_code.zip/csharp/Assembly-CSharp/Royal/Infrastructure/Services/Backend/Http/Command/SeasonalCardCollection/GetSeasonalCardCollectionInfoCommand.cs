﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SeasonalCardCollection
{
	// Token: 0x0200254D RID: 9549
	[Token(Token = "0x200254D")]
	public class GetSeasonalCardCollectionInfoCommand : BaseHttpCommand
	{
		// Token: 0x1700275B RID: 10075
		// (get) Token: 0x06012AA8 RID: 76456 RVA: 0x00078720 File Offset: 0x00076920
		[Token(Token = "0x1700275B")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AA8")]
			[Address(RVA = "0x1ECC934", Offset = "0x1ECC934", VA = "0x1ECC934", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700275C RID: 10076
		// (get) Token: 0x06012AA9 RID: 76457 RVA: 0x00078738 File Offset: 0x00076938
		[Token(Token = "0x1700275C")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AA9")]
			[Address(RVA = "0x1ECC93C", Offset = "0x1ECC93C", VA = "0x1ECC93C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AAA RID: 76458 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AAA")]
		[Address(RVA = "0x1ECC944", Offset = "0x1ECC944", VA = "0x1ECC944")]
		public GetSeasonalCardCollectionInfoCommand(int eventId, int configVersion, Action<GetSeasonalCardCollectionInfoResponse> onComplete)
		{
		}

		// Token: 0x06012AAB RID: 76459 RVA: 0x00078750 File Offset: 0x00076950
		[Token(Token = "0x6012AAB")]
		[Address(RVA = "0x1ECC988", Offset = "0x1ECC988", VA = "0x1ECC988", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AAC RID: 76460 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AAC")]
		[Address(RVA = "0x1ECCA4C", Offset = "0x1ECCA4C", VA = "0x1ECCA4C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AAD RID: 76461 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AAD")]
		[Address(RVA = "0x1ECCBE0", Offset = "0x1ECCBE0", VA = "0x1ECCBE0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB8B RID: 60299
		[Token(Token = "0x400EB8B")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;

		// Token: 0x0400EB8C RID: 60300
		[Token(Token = "0x400EB8C")]
		[FieldOffset(Offset = "0x18")]
		private readonly int configVersion;

		// Token: 0x0400EB8D RID: 60301
		[Token(Token = "0x400EB8D")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action<GetSeasonalCardCollectionInfoResponse> onComplete;
	}
}
