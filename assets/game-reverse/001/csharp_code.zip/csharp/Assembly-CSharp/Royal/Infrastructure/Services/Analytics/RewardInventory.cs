﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002598 RID: 9624
	[Token(Token = "0x2002598")]
	public class RewardInventory
	{
		// Token: 0x06012D50 RID: 77136 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D50")]
		[Address(RVA = "0x243AA0C", Offset = "0x243AA0C", VA = "0x243AA0C")]
		public RewardInventory()
		{
		}

		// Token: 0x0400ECDE RID: 60638
		[Token(Token = "0x400ECDE")]
		[FieldOffset(Offset = "0x10")]
		public int r_rck;

		// Token: 0x0400ECDF RID: 60639
		[Token(Token = "0x400ECDF")]
		[FieldOffset(Offset = "0x14")]
		public int r_tnt;

		// Token: 0x0400ECE0 RID: 60640
		[Token(Token = "0x400ECE0")]
		[FieldOffset(Offset = "0x18")]
		public int r_lb;

		// Token: 0x0400ECE1 RID: 60641
		[Token(Token = "0x400ECE1")]
		[FieldOffset(Offset = "0x1C")]
		public int r_rh;

		// Token: 0x0400ECE2 RID: 60642
		[Token(Token = "0x400ECE2")]
		[FieldOffset(Offset = "0x20")]
		public int r_ar;

		// Token: 0x0400ECE3 RID: 60643
		[Token(Token = "0x400ECE3")]
		[FieldOffset(Offset = "0x24")]
		public int r_ca;

		// Token: 0x0400ECE4 RID: 60644
		[Token(Token = "0x400ECE4")]
		[FieldOffset(Offset = "0x28")]
		public int r_jh;

		// Token: 0x0400ECE5 RID: 60645
		[Token(Token = "0x400ECE5")]
		[FieldOffset(Offset = "0x2C")]
		public int ur_rck;

		// Token: 0x0400ECE6 RID: 60646
		[Token(Token = "0x400ECE6")]
		[FieldOffset(Offset = "0x30")]
		public int ur_tnt;

		// Token: 0x0400ECE7 RID: 60647
		[Token(Token = "0x400ECE7")]
		[FieldOffset(Offset = "0x34")]
		public int ur_lb;

		// Token: 0x0400ECE8 RID: 60648
		[Token(Token = "0x400ECE8")]
		[FieldOffset(Offset = "0x38")]
		public int ur_mlt_evt;

		// Token: 0x0400ECE9 RID: 60649
		[Token(Token = "0x400ECE9")]
		[FieldOffset(Offset = "0x3C")]
		public int cards;

		// Token: 0x0400ECEA RID: 60650
		[Token(Token = "0x400ECEA")]
		[FieldOffset(Offset = "0x40")]
		public int token;

		// Token: 0x0400ECEB RID: 60651
		[Token(Token = "0x400ECEB")]
		[FieldOffset(Offset = "0x44")]
		public int wild_c;

		// Token: 0x0400ECEC RID: 60652
		[Token(Token = "0x400ECEC")]
		[FieldOffset(Offset = "0x48")]
		public int mb;

		// Token: 0x0400ECED RID: 60653
		[Token(Token = "0x400ECED")]
		[FieldOffset(Offset = "0x4C")]
		public int rt;
	}
}
