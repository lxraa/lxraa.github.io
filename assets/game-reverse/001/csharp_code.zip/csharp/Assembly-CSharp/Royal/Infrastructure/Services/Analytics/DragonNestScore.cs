﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x020025A0 RID: 9632
	[Token(Token = "0x20025A0")]
	public class DragonNestScore
	{
		// Token: 0x06012D58 RID: 77144 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D58")]
		[Address(RVA = "0x243AA4C", Offset = "0x243AA4C", VA = "0x243AA4C")]
		public DragonNestScore()
		{
		}

		// Token: 0x0400ED2D RID: 60717
		[Token(Token = "0x400ED2D")]
		[FieldOffset(Offset = "0x10")]
		public int myScore;

		// Token: 0x0400ED2E RID: 60718
		[Token(Token = "0x400ED2E")]
		[FieldOffset(Offset = "0x14")]
		public int partnerScore;
	}
}
