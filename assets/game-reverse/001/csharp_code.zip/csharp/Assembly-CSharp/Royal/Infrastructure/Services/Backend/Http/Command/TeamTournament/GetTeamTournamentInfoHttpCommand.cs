﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TeamTournament
{
	// Token: 0x02002538 RID: 9528
	[Token(Token = "0x2002538")]
	public class GetTeamTournamentInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002724 RID: 10020
		// (get) Token: 0x06012A05 RID: 76293 RVA: 0x00077FE8 File Offset: 0x000761E8
		[Token(Token = "0x17002724")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A05")]
			[Address(RVA = "0x1CFD16C", Offset = "0x1CFD16C", VA = "0x1CFD16C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002725 RID: 10021
		// (get) Token: 0x06012A06 RID: 76294 RVA: 0x00078000 File Offset: 0x00076200
		[Token(Token = "0x17002725")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A06")]
			[Address(RVA = "0x1CFD174", Offset = "0x1CFD174", VA = "0x1CFD174", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A07 RID: 76295 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A07")]
		[Address(RVA = "0x1CFD17C", Offset = "0x1CFD17C", VA = "0x1CFD17C")]
		public GetTeamTournamentInfoHttpCommand(long groupId, long teamId, int configVersion, int teamRank, string usersHash, int eventId = 0)
		{
		}

		// Token: 0x06012A08 RID: 76296 RVA: 0x00078018 File Offset: 0x00076218
		[Token(Token = "0x6012A08")]
		[Address(RVA = "0x1CFD1E8", Offset = "0x1CFD1E8", VA = "0x1CFD1E8", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012A09 RID: 76297 RVA: 0x00078030 File Offset: 0x00076230
		[Token(Token = "0x6012A09")]
		[Address(RVA = "0x1CFD2FC", Offset = "0x1CFD2FC", VA = "0x1CFD2FC", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A0A RID: 76298 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A0A")]
		[Address(RVA = "0x1CFD650", Offset = "0x1CFD650", VA = "0x1CFD650", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A0B RID: 76299 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A0B")]
		[Address(RVA = "0x1CFDAEC", Offset = "0x1CFDAEC", VA = "0x1CFDAEC", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB48 RID: 60232
		[Token(Token = "0x400EB48")]
		[FieldOffset(Offset = "0x18")]
		private readonly long groupId;

		// Token: 0x0400EB49 RID: 60233
		[Token(Token = "0x400EB49")]
		[FieldOffset(Offset = "0x20")]
		private readonly long teamId;

		// Token: 0x0400EB4A RID: 60234
		[Token(Token = "0x400EB4A")]
		[FieldOffset(Offset = "0x28")]
		private readonly int configVersion;

		// Token: 0x0400EB4B RID: 60235
		[Token(Token = "0x400EB4B")]
		[FieldOffset(Offset = "0x2C")]
		private readonly int teamRank;

		// Token: 0x0400EB4C RID: 60236
		[Token(Token = "0x400EB4C")]
		[FieldOffset(Offset = "0x30")]
		private readonly string usersHash;

		// Token: 0x0400EB4D RID: 60237
		[Token(Token = "0x400EB4D")]
		[FieldOffset(Offset = "0x38")]
		private readonly int eventId;
	}
}
