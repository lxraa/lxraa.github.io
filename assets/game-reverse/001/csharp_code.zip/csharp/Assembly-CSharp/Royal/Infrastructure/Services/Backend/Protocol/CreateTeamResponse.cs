﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002373 RID: 9075
	[Token(Token = "0x2002373")]
	public struct CreateTeamResponse : IFlatbufferObject
	{
		// Token: 0x17001F84 RID: 8068
		// (get) Token: 0x06010E46 RID: 69190 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F84")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010E46")]
			[Address(RVA = "0x1F9259C", Offset = "0x1F9259C", VA = "0x1F9259C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E47 RID: 69191 RVA: 0x00062208 File Offset: 0x00060408
		[Token(Token = "0x6010E47")]
		[Address(RVA = "0x1F925A4", Offset = "0x1F925A4", VA = "0x1F925A4")]
		public static CreateTeamResponse GetRootAsCreateTeamResponse(ByteBuffer _bb)
		{
			return default(CreateTeamResponse);
		}

		// Token: 0x06010E48 RID: 69192 RVA: 0x00062220 File Offset: 0x00060420
		[Token(Token = "0x6010E48")]
		[Address(RVA = "0x1F925B0", Offset = "0x1F925B0", VA = "0x1F925B0")]
		public static CreateTeamResponse GetRootAsCreateTeamResponse(ByteBuffer _bb, CreateTeamResponse obj)
		{
			return default(CreateTeamResponse);
		}

		// Token: 0x06010E49 RID: 69193 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E49")]
		[Address(RVA = "0x1F92660", Offset = "0x1F92660", VA = "0x1F92660", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010E4A RID: 69194 RVA: 0x00062238 File Offset: 0x00060438
		[Token(Token = "0x6010E4A")]
		[Address(RVA = "0x1F92628", Offset = "0x1F92628", VA = "0x1F92628")]
		public CreateTeamResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(CreateTeamResponse);
		}

		// Token: 0x17001F85 RID: 8069
		// (get) Token: 0x06010E4B RID: 69195 RVA: 0x00062250 File Offset: 0x00060450
		[Token(Token = "0x17001F85")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010E4B")]
			[Address(RVA = "0x1F92670", Offset = "0x1F92670", VA = "0x1F92670")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001F86 RID: 8070
		// (get) Token: 0x06010E4C RID: 69196 RVA: 0x00062268 File Offset: 0x00060468
		[Token(Token = "0x17001F86")]
		public long TeamId
		{
			[Token(Token = "0x6010E4C")]
			[Address(RVA = "0x1F926B4", Offset = "0x1F926B4", VA = "0x1F926B4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F87 RID: 8071
		// (get) Token: 0x06010E4D RID: 69197 RVA: 0x00062280 File Offset: 0x00060480
		[Token(Token = "0x17001F87")]
		public long UserData
		{
			[Token(Token = "0x6010E4D")]
			[Address(RVA = "0x1F926FC", Offset = "0x1F926FC", VA = "0x1F926FC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F88 RID: 8072
		// (get) Token: 0x06010E4E RID: 69198 RVA: 0x00062298 File Offset: 0x00060498
		[Token(Token = "0x17001F88")]
		public TeamTreasureInfo? TeamTreasureInfo
		{
			[Token(Token = "0x6010E4E")]
			[Address(RVA = "0x1F92744", Offset = "0x1F92744", VA = "0x1F92744")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F89 RID: 8073
		// (get) Token: 0x06010E4F RID: 69199 RVA: 0x000622B0 File Offset: 0x000604B0
		[Token(Token = "0x17001F89")]
		public ChatMessageFailReason FailReason
		{
			[Token(Token = "0x6010E4F")]
			[Address(RVA = "0x1F92804", Offset = "0x1F92804", VA = "0x1F92804")]
			get
			{
				return ChatMessageFailReason.None;
			}
		}

		// Token: 0x17001F8A RID: 8074
		// (get) Token: 0x06010E50 RID: 69200 RVA: 0x000622C8 File Offset: 0x000604C8
		[Token(Token = "0x17001F8A")]
		public bool IsEdit
		{
			[Token(Token = "0x6010E50")]
			[Address(RVA = "0x1F92848", Offset = "0x1F92848", VA = "0x1F92848")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06010E51 RID: 69201 RVA: 0x000622E0 File Offset: 0x000604E0
		[Token(Token = "0x6010E51")]
		[Address(RVA = "0x1F92890", Offset = "0x1F92890", VA = "0x1F92890")]
		public static Offset<CreateTeamResponse> CreateCreateTeamResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, long team_id = 0L, long userData = 0L, [Optional] Offset<TeamTreasureInfo> team_treasure_infoOffset, ChatMessageFailReason fail_reason = ChatMessageFailReason.None, bool is_edit = false)
		{
			return default(Offset<CreateTeamResponse>);
		}

		// Token: 0x06010E52 RID: 69202 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E52")]
		[Address(RVA = "0x1F92A64", Offset = "0x1F92A64", VA = "0x1F92A64")]
		public static void StartCreateTeamResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010E53 RID: 69203 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E53")]
		[Address(RVA = "0x1F929D8", Offset = "0x1F929D8", VA = "0x1F929D8")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010E54 RID: 69204 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E54")]
		[Address(RVA = "0x1F92958", Offset = "0x1F92958", VA = "0x1F92958")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x06010E55 RID: 69205 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E55")]
		[Address(RVA = "0x1F92938", Offset = "0x1F92938", VA = "0x1F92938")]
		public static void AddUserData(FlatBufferBuilder builder, long userData)
		{
		}

		// Token: 0x06010E56 RID: 69206 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E56")]
		[Address(RVA = "0x1F92978", Offset = "0x1F92978", VA = "0x1F92978")]
		public static void AddTeamTreasureInfo(FlatBufferBuilder builder, Offset<TeamTreasureInfo> teamTreasureInfoOffset)
		{
		}

		// Token: 0x06010E57 RID: 69207 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E57")]
		[Address(RVA = "0x1F929B8", Offset = "0x1F929B8", VA = "0x1F929B8")]
		public static void AddFailReason(FlatBufferBuilder builder, ChatMessageFailReason failReason)
		{
		}

		// Token: 0x06010E58 RID: 69208 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E58")]
		[Address(RVA = "0x1F92998", Offset = "0x1F92998", VA = "0x1F92998")]
		public static void AddIsEdit(FlatBufferBuilder builder, bool isEdit)
		{
		}

		// Token: 0x06010E59 RID: 69209 RVA: 0x000622F8 File Offset: 0x000604F8
		[Token(Token = "0x6010E59")]
		[Address(RVA = "0x1F929F8", Offset = "0x1F929F8", VA = "0x1F929F8")]
		public static Offset<CreateTeamResponse> EndCreateTeamResponse(FlatBufferBuilder builder)
		{
			return default(Offset<CreateTeamResponse>);
		}

		// Token: 0x0400E68C RID: 59020
		[Token(Token = "0x400E68C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
