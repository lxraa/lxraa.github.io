﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002384 RID: 9092
	[Token(Token = "0x2002384")]
	public struct DragonNestFriendInfo : IFlatbufferObject
	{
		// Token: 0x17001FDA RID: 8154
		// (get) Token: 0x06010F80 RID: 69504 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FDA")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F80")]
			[Address(RVA = "0x1F97354", Offset = "0x1F97354", VA = "0x1F97354", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F81 RID: 69505 RVA: 0x00063210 File Offset: 0x00061410
		[Token(Token = "0x6010F81")]
		[Address(RVA = "0x1F9735C", Offset = "0x1F9735C", VA = "0x1F9735C")]
		public static DragonNestFriendInfo GetRootAsDragonNestFriendInfo(ByteBuffer _bb)
		{
			return default(DragonNestFriendInfo);
		}

		// Token: 0x06010F82 RID: 69506 RVA: 0x00063228 File Offset: 0x00061428
		[Token(Token = "0x6010F82")]
		[Address(RVA = "0x1F97368", Offset = "0x1F97368", VA = "0x1F97368")]
		public static DragonNestFriendInfo GetRootAsDragonNestFriendInfo(ByteBuffer _bb, DragonNestFriendInfo obj)
		{
			return default(DragonNestFriendInfo);
		}

		// Token: 0x06010F83 RID: 69507 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F83")]
		[Address(RVA = "0x1F97418", Offset = "0x1F97418", VA = "0x1F97418", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F84 RID: 69508 RVA: 0x00063240 File Offset: 0x00061440
		[Token(Token = "0x6010F84")]
		[Address(RVA = "0x1F973E0", Offset = "0x1F973E0", VA = "0x1F973E0")]
		public DragonNestFriendInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestFriendInfo);
		}

		// Token: 0x17001FDB RID: 8155
		// (get) Token: 0x06010F85 RID: 69509 RVA: 0x00063258 File Offset: 0x00061458
		[Token(Token = "0x17001FDB")]
		public DragonNestUser? ProfileData
		{
			[Token(Token = "0x6010F85")]
			[Address(RVA = "0x1F97428", Offset = "0x1F97428", VA = "0x1F97428")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FDC RID: 8156
		// (get) Token: 0x06010F86 RID: 69510 RVA: 0x00063270 File Offset: 0x00061470
		[Token(Token = "0x17001FDC")]
		public CoopEventFriendStatus Status
		{
			[Token(Token = "0x6010F86")]
			[Address(RVA = "0x1F97518", Offset = "0x1F97518", VA = "0x1F97518")]
			get
			{
				return CoopEventFriendStatus.None;
			}
		}

		// Token: 0x06010F87 RID: 69511 RVA: 0x00063288 File Offset: 0x00061488
		[Token(Token = "0x6010F87")]
		[Address(RVA = "0x1F9755C", Offset = "0x1F9755C", VA = "0x1F9755C")]
		public static Offset<DragonNestFriendInfo> CreateDragonNestFriendInfo(FlatBufferBuilder builder, [Optional] Offset<DragonNestUser> profile_dataOffset, CoopEventFriendStatus status = CoopEventFriendStatus.None)
		{
			return default(Offset<DragonNestFriendInfo>);
		}

		// Token: 0x06010F88 RID: 69512 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F88")]
		[Address(RVA = "0x1F97660", Offset = "0x1F97660", VA = "0x1F97660")]
		public static void StartDragonNestFriendInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F89 RID: 69513 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F89")]
		[Address(RVA = "0x1F975B4", Offset = "0x1F975B4", VA = "0x1F975B4")]
		public static void AddProfileData(FlatBufferBuilder builder, Offset<DragonNestUser> profileDataOffset)
		{
		}

		// Token: 0x06010F8A RID: 69514 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F8A")]
		[Address(RVA = "0x1F975D4", Offset = "0x1F975D4", VA = "0x1F975D4")]
		public static void AddStatus(FlatBufferBuilder builder, CoopEventFriendStatus status)
		{
		}

		// Token: 0x06010F8B RID: 69515 RVA: 0x000632A0 File Offset: 0x000614A0
		[Token(Token = "0x6010F8B")]
		[Address(RVA = "0x1F975F4", Offset = "0x1F975F4", VA = "0x1F975F4")]
		public static Offset<DragonNestFriendInfo> EndDragonNestFriendInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestFriendInfo>);
		}

		// Token: 0x0400E69D RID: 59037
		[Token(Token = "0x400E69D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
