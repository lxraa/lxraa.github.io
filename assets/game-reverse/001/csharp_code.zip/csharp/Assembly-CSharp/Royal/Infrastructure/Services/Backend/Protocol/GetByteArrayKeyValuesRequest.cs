﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C7 RID: 9159
	[Token(Token = "0x20023C7")]
	public struct GetByteArrayKeyValuesRequest : IFlatbufferObject
	{
		// Token: 0x170020CE RID: 8398
		// (get) Token: 0x06011302 RID: 70402 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020CE")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011302")]
			[Address(RVA = "0x1CACBF4", Offset = "0x1CACBF4", VA = "0x1CACBF4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011303 RID: 70403 RVA: 0x00066048 File Offset: 0x00064248
		[Token(Token = "0x6011303")]
		[Address(RVA = "0x1CACBFC", Offset = "0x1CACBFC", VA = "0x1CACBFC")]
		public static GetByteArrayKeyValuesRequest GetRootAsGetByteArrayKeyValuesRequest(ByteBuffer _bb)
		{
			return default(GetByteArrayKeyValuesRequest);
		}

		// Token: 0x06011304 RID: 70404 RVA: 0x00066060 File Offset: 0x00064260
		[Token(Token = "0x6011304")]
		[Address(RVA = "0x1CACC08", Offset = "0x1CACC08", VA = "0x1CACC08")]
		public static GetByteArrayKeyValuesRequest GetRootAsGetByteArrayKeyValuesRequest(ByteBuffer _bb, GetByteArrayKeyValuesRequest obj)
		{
			return default(GetByteArrayKeyValuesRequest);
		}

		// Token: 0x06011305 RID: 70405 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011305")]
		[Address(RVA = "0x1CACCB8", Offset = "0x1CACCB8", VA = "0x1CACCB8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011306 RID: 70406 RVA: 0x00066078 File Offset: 0x00064278
		[Token(Token = "0x6011306")]
		[Address(RVA = "0x1CACC80", Offset = "0x1CACC80", VA = "0x1CACC80")]
		public GetByteArrayKeyValuesRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetByteArrayKeyValuesRequest);
		}

		// Token: 0x06011307 RID: 70407 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011307")]
		[Address(RVA = "0x1CACCC8", Offset = "0x1CACCC8", VA = "0x1CACCC8")]
		public static void StartGetByteArrayKeyValuesRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011308 RID: 70408 RVA: 0x00066090 File Offset: 0x00064290
		[Token(Token = "0x6011308")]
		[Address(RVA = "0x1CACCE0", Offset = "0x1CACCE0", VA = "0x1CACCE0")]
		public static Offset<GetByteArrayKeyValuesRequest> EndGetByteArrayKeyValuesRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetByteArrayKeyValuesRequest>);
		}

		// Token: 0x0400E734 RID: 59188
		[Token(Token = "0x400E734")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
