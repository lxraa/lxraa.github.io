﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002392 RID: 9106
	[Token(Token = "0x2002392")]
	public struct DynamicOfferAllInfo : IFlatbufferObject
	{
		// Token: 0x1700200C RID: 8204
		// (get) Token: 0x06011038 RID: 69688 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700200C")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011038")]
			[Address(RVA = "0x1F99ED8", Offset = "0x1F99ED8", VA = "0x1F99ED8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011039 RID: 69689 RVA: 0x00063BA0 File Offset: 0x00061DA0
		[Token(Token = "0x6011039")]
		[Address(RVA = "0x1F99EE0", Offset = "0x1F99EE0", VA = "0x1F99EE0")]
		public static DynamicOfferAllInfo GetRootAsDynamicOfferAllInfo(ByteBuffer _bb)
		{
			return default(DynamicOfferAllInfo);
		}

		// Token: 0x0601103A RID: 69690 RVA: 0x00063BB8 File Offset: 0x00061DB8
		[Token(Token = "0x601103A")]
		[Address(RVA = "0x1F99EEC", Offset = "0x1F99EEC", VA = "0x1F99EEC")]
		public static DynamicOfferAllInfo GetRootAsDynamicOfferAllInfo(ByteBuffer _bb, DynamicOfferAllInfo obj)
		{
			return default(DynamicOfferAllInfo);
		}

		// Token: 0x0601103B RID: 69691 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601103B")]
		[Address(RVA = "0x1F99F9C", Offset = "0x1F99F9C", VA = "0x1F99F9C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601103C RID: 69692 RVA: 0x00063BD0 File Offset: 0x00061DD0
		[Token(Token = "0x601103C")]
		[Address(RVA = "0x1F99F64", Offset = "0x1F99F64", VA = "0x1F99F64")]
		public DynamicOfferAllInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DynamicOfferAllInfo);
		}

		// Token: 0x0601103D RID: 69693 RVA: 0x00063BE8 File Offset: 0x00061DE8
		[Token(Token = "0x601103D")]
		[Address(RVA = "0x1F99FAC", Offset = "0x1F99FAC", VA = "0x1F99FAC")]
		public DynamicOfferInfo? DynamicOfferEventInfoList(int j)
		{
			return null;
		}

		// Token: 0x1700200D RID: 8205
		// (get) Token: 0x0601103E RID: 69694 RVA: 0x00063C00 File Offset: 0x00061E00
		[Token(Token = "0x1700200D")]
		public int DynamicOfferEventInfoListLength
		{
			[Token(Token = "0x601103E")]
			[Address(RVA = "0x1F9A0B4", Offset = "0x1F9A0B4", VA = "0x1F9A0B4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601103F RID: 69695 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601103F")]
		[Address(RVA = "0x1F9A0E8", Offset = "0x1F9A0E8", VA = "0x1F9A0E8")]
		public string DynamicOfferDisableFlags(int j)
		{
			return null;
		}

		// Token: 0x1700200E RID: 8206
		// (get) Token: 0x06011040 RID: 69696 RVA: 0x00063C18 File Offset: 0x00061E18
		[Token(Token = "0x1700200E")]
		public int DynamicOfferDisableFlagsLength
		{
			[Token(Token = "0x6011040")]
			[Address(RVA = "0x1F9A140", Offset = "0x1F9A140", VA = "0x1F9A140")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700200F RID: 8207
		// (get) Token: 0x06011041 RID: 69697 RVA: 0x00063C30 File Offset: 0x00061E30
		[Token(Token = "0x1700200F")]
		public UserDynamicSegmentInfo? UserDynamicSegmentInfo
		{
			[Token(Token = "0x6011041")]
			[Address(RVA = "0x1F9A174", Offset = "0x1F9A174", VA = "0x1F9A174")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011042 RID: 69698 RVA: 0x00063C48 File Offset: 0x00061E48
		[Token(Token = "0x6011042")]
		[Address(RVA = "0x1F9A234", Offset = "0x1F9A234", VA = "0x1F9A234")]
		public static Offset<DynamicOfferAllInfo> CreateDynamicOfferAllInfo(FlatBufferBuilder builder, [Optional] VectorOffset dynamic_offer_event_info_listOffset, [Optional] VectorOffset dynamic_offer_disable_flagsOffset, [Optional] Offset<UserDynamicSegmentInfo> user_dynamic_segment_infoOffset)
		{
			return default(Offset<DynamicOfferAllInfo>);
		}

		// Token: 0x06011043 RID: 69699 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011043")]
		[Address(RVA = "0x1F9A370", Offset = "0x1F9A370", VA = "0x1F9A370")]
		public static void StartDynamicOfferAllInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011044 RID: 69700 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011044")]
		[Address(RVA = "0x1F9A2E4", Offset = "0x1F9A2E4", VA = "0x1F9A2E4")]
		public static void AddDynamicOfferEventInfoList(FlatBufferBuilder builder, VectorOffset dynamicOfferEventInfoListOffset)
		{
		}

		// Token: 0x06011045 RID: 69701 RVA: 0x00063C60 File Offset: 0x00061E60
		[Token(Token = "0x6011045")]
		[Address(RVA = "0x1F9A388", Offset = "0x1F9A388", VA = "0x1F9A388")]
		public static VectorOffset CreateDynamicOfferEventInfoListVector(FlatBufferBuilder builder, Offset<DynamicOfferInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011046 RID: 69702 RVA: 0x00063C78 File Offset: 0x00061E78
		[Token(Token = "0x6011046")]
		[Address(RVA = "0x1F9A430", Offset = "0x1F9A430", VA = "0x1F9A430")]
		public static VectorOffset CreateDynamicOfferEventInfoListVectorBlock(FlatBufferBuilder builder, Offset<DynamicOfferInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011047 RID: 69703 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011047")]
		[Address(RVA = "0x1F9A4B8", Offset = "0x1F9A4B8", VA = "0x1F9A4B8")]
		public static void StartDynamicOfferEventInfoListVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011048 RID: 69704 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011048")]
		[Address(RVA = "0x1F9A2C4", Offset = "0x1F9A2C4", VA = "0x1F9A2C4")]
		public static void AddDynamicOfferDisableFlags(FlatBufferBuilder builder, VectorOffset dynamicOfferDisableFlagsOffset)
		{
		}

		// Token: 0x06011049 RID: 69705 RVA: 0x00063C90 File Offset: 0x00061E90
		[Token(Token = "0x6011049")]
		[Address(RVA = "0x1F9A4D8", Offset = "0x1F9A4D8", VA = "0x1F9A4D8")]
		public static VectorOffset CreateDynamicOfferDisableFlagsVector(FlatBufferBuilder builder, StringOffset[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601104A RID: 69706 RVA: 0x00063CA8 File Offset: 0x00061EA8
		[Token(Token = "0x601104A")]
		[Address(RVA = "0x1F9A580", Offset = "0x1F9A580", VA = "0x1F9A580")]
		public static VectorOffset CreateDynamicOfferDisableFlagsVectorBlock(FlatBufferBuilder builder, StringOffset[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601104B RID: 69707 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601104B")]
		[Address(RVA = "0x1F9A608", Offset = "0x1F9A608", VA = "0x1F9A608")]
		public static void StartDynamicOfferDisableFlagsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x0601104C RID: 69708 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601104C")]
		[Address(RVA = "0x1F9A2A4", Offset = "0x1F9A2A4", VA = "0x1F9A2A4")]
		public static void AddUserDynamicSegmentInfo(FlatBufferBuilder builder, Offset<UserDynamicSegmentInfo> userDynamicSegmentInfoOffset)
		{
		}

		// Token: 0x0601104D RID: 69709 RVA: 0x00063CC0 File Offset: 0x00061EC0
		[Token(Token = "0x601104D")]
		[Address(RVA = "0x1F9A304", Offset = "0x1F9A304", VA = "0x1F9A304")]
		public static Offset<DynamicOfferAllInfo> EndDynamicOfferAllInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DynamicOfferAllInfo>);
		}

		// Token: 0x0400E6B3 RID: 59059
		[Token(Token = "0x400E6B3")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
