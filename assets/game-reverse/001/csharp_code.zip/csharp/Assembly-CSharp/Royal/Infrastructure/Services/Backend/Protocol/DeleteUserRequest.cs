﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200237A RID: 9082
	[Token(Token = "0x200237A")]
	public struct DeleteUserRequest : IFlatbufferObject
	{
		// Token: 0x17001FB6 RID: 8118
		// (get) Token: 0x06010EE0 RID: 69344 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FB6")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010EE0")]
			[Address(RVA = "0x1F94B90", Offset = "0x1F94B90", VA = "0x1F94B90", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EE1 RID: 69345 RVA: 0x000629A0 File Offset: 0x00060BA0
		[Token(Token = "0x6010EE1")]
		[Address(RVA = "0x1F94B98", Offset = "0x1F94B98", VA = "0x1F94B98")]
		public static DeleteUserRequest GetRootAsDeleteUserRequest(ByteBuffer _bb)
		{
			return default(DeleteUserRequest);
		}

		// Token: 0x06010EE2 RID: 69346 RVA: 0x000629B8 File Offset: 0x00060BB8
		[Token(Token = "0x6010EE2")]
		[Address(RVA = "0x1F94BA4", Offset = "0x1F94BA4", VA = "0x1F94BA4")]
		public static DeleteUserRequest GetRootAsDeleteUserRequest(ByteBuffer _bb, DeleteUserRequest obj)
		{
			return default(DeleteUserRequest);
		}

		// Token: 0x06010EE3 RID: 69347 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EE3")]
		[Address(RVA = "0x1F94C54", Offset = "0x1F94C54", VA = "0x1F94C54", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010EE4 RID: 69348 RVA: 0x000629D0 File Offset: 0x00060BD0
		[Token(Token = "0x6010EE4")]
		[Address(RVA = "0x1F94C1C", Offset = "0x1F94C1C", VA = "0x1F94C1C")]
		public DeleteUserRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(DeleteUserRequest);
		}

		// Token: 0x06010EE5 RID: 69349 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EE5")]
		[Address(RVA = "0x1F94C64", Offset = "0x1F94C64", VA = "0x1F94C64")]
		public static void StartDeleteUserRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010EE6 RID: 69350 RVA: 0x000629E8 File Offset: 0x00060BE8
		[Token(Token = "0x6010EE6")]
		[Address(RVA = "0x1F94C7C", Offset = "0x1F94C7C", VA = "0x1F94C7C")]
		public static Offset<DeleteUserRequest> EndDeleteUserRequest(FlatBufferBuilder builder)
		{
			return default(Offset<DeleteUserRequest>);
		}

		// Token: 0x0400E693 RID: 59027
		[Token(Token = "0x400E693")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
