﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x0200259A RID: 9626
	[Token(Token = "0x200259A")]
	public class SpecialItemCountsJson
	{
		// Token: 0x06012D52 RID: 77138 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D52")]
		[Address(RVA = "0x243AA1C", Offset = "0x243AA1C", VA = "0x243AA1C")]
		public SpecialItemCountsJson()
		{
		}

		// Token: 0x0400ECF6 RID: 60662
		[Token(Token = "0x400ECF6")]
		[FieldOffset(Offset = "0x10")]
		public int rocket_creation;

		// Token: 0x0400ECF7 RID: 60663
		[Token(Token = "0x400ECF7")]
		[FieldOffset(Offset = "0x14")]
		public int rocket_ac;

		// Token: 0x0400ECF8 RID: 60664
		[Token(Token = "0x400ECF8")]
		[FieldOffset(Offset = "0x18")]
		public int tnt_creation;

		// Token: 0x0400ECF9 RID: 60665
		[Token(Token = "0x400ECF9")]
		[FieldOffset(Offset = "0x1C")]
		public int tnt_ac;

		// Token: 0x0400ECFA RID: 60666
		[Token(Token = "0x400ECFA")]
		[FieldOffset(Offset = "0x20")]
		public int lb_creation;

		// Token: 0x0400ECFB RID: 60667
		[Token(Token = "0x400ECFB")]
		[FieldOffset(Offset = "0x24")]
		public int lb_ac;

		// Token: 0x0400ECFC RID: 60668
		[Token(Token = "0x400ECFC")]
		[FieldOffset(Offset = "0x28")]
		public int propeller_creation;

		// Token: 0x0400ECFD RID: 60669
		[Token(Token = "0x400ECFD")]
		[FieldOffset(Offset = "0x2C")]
		public int propeller_ac;

		// Token: 0x0400ECFE RID: 60670
		[Token(Token = "0x400ECFE")]
		[FieldOffset(Offset = "0x30")]
		public int rocket_use;

		// Token: 0x0400ECFF RID: 60671
		[Token(Token = "0x400ECFF")]
		[FieldOffset(Offset = "0x34")]
		public int tnt_use;

		// Token: 0x0400ED00 RID: 60672
		[Token(Token = "0x400ED00")]
		[FieldOffset(Offset = "0x38")]
		public int lb_use;

		// Token: 0x0400ED01 RID: 60673
		[Token(Token = "0x400ED01")]
		[FieldOffset(Offset = "0x3C")]
		public int propeller_use;

		// Token: 0x0400ED02 RID: 60674
		[Token(Token = "0x400ED02")]
		[FieldOffset(Offset = "0x40")]
		public int rocket_rocket;

		// Token: 0x0400ED03 RID: 60675
		[Token(Token = "0x400ED03")]
		[FieldOffset(Offset = "0x44")]
		public int propeller_propeller;

		// Token: 0x0400ED04 RID: 60676
		[Token(Token = "0x400ED04")]
		[FieldOffset(Offset = "0x48")]
		public int tnt_tnt;

		// Token: 0x0400ED05 RID: 60677
		[Token(Token = "0x400ED05")]
		[FieldOffset(Offset = "0x4C")]
		public int lb_lb;

		// Token: 0x0400ED06 RID: 60678
		[Token(Token = "0x400ED06")]
		[FieldOffset(Offset = "0x50")]
		public int lb_tnt;

		// Token: 0x0400ED07 RID: 60679
		[Token(Token = "0x400ED07")]
		[FieldOffset(Offset = "0x54")]
		public int lb_rocket;

		// Token: 0x0400ED08 RID: 60680
		[Token(Token = "0x400ED08")]
		[FieldOffset(Offset = "0x58")]
		public int lb_propeller;

		// Token: 0x0400ED09 RID: 60681
		[Token(Token = "0x400ED09")]
		[FieldOffset(Offset = "0x5C")]
		public int tnt_rocket;

		// Token: 0x0400ED0A RID: 60682
		[Token(Token = "0x400ED0A")]
		[FieldOffset(Offset = "0x60")]
		public int tnt_propeller;

		// Token: 0x0400ED0B RID: 60683
		[Token(Token = "0x400ED0B")]
		[FieldOffset(Offset = "0x64")]
		public int rocket_propeller;

		// Token: 0x0400ED0C RID: 60684
		[Token(Token = "0x400ED0C")]
		[FieldOffset(Offset = "0x68")]
		public int swap_use;

		// Token: 0x0400ED0D RID: 60685
		[Token(Token = "0x400ED0D")]
		[FieldOffset(Offset = "0x6C")]
		public int tap_use;

		// Token: 0x0400ED0E RID: 60686
		[Token(Token = "0x400ED0E")]
		[FieldOffset(Offset = "0x70")]
		public int auto_trigger;

		// Token: 0x0400ED0F RID: 60687
		[Token(Token = "0x400ED0F")]
		[FieldOffset(Offset = "0x74")]
		public int crystal_ac;

		// Token: 0x0400ED10 RID: 60688
		[Token(Token = "0x400ED10")]
		[FieldOffset(Offset = "0x78")]
		public int p_at;

		// Token: 0x0400ED11 RID: 60689
		[Token(Token = "0x400ED11")]
		[FieldOffset(Offset = "0x7C")]
		public int r_at;

		// Token: 0x0400ED12 RID: 60690
		[Token(Token = "0x400ED12")]
		[FieldOffset(Offset = "0x80")]
		public int t_at;

		// Token: 0x0400ED13 RID: 60691
		[Token(Token = "0x400ED13")]
		[FieldOffset(Offset = "0x84")]
		public int lb_at;

		// Token: 0x0400ED14 RID: 60692
		[Token(Token = "0x400ED14")]
		[FieldOffset(Offset = "0x88")]
		public int lb_p_crt;

		// Token: 0x0400ED15 RID: 60693
		[Token(Token = "0x400ED15")]
		[FieldOffset(Offset = "0x8C")]
		public int lb_r_crt;

		// Token: 0x0400ED16 RID: 60694
		[Token(Token = "0x400ED16")]
		[FieldOffset(Offset = "0x90")]
		public int lb_t_crt;

		// Token: 0x0400ED17 RID: 60695
		[Token(Token = "0x400ED17")]
		[FieldOffset(Offset = "0x98")]
		public string md_score;

		// Token: 0x0400ED18 RID: 60696
		[Token(Token = "0x400ED18")]
		[FieldOffset(Offset = "0xA0")]
		public string md_throw_move;

		// Token: 0x0400ED19 RID: 60697
		[Token(Token = "0x400ED19")]
		[FieldOffset(Offset = "0xA8")]
		public int md_config_id;
	}
}
