﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002362 RID: 9058
	[Token(Token = "0x2002362")]
	public struct ClaimSpaceMissionRewardRequest : IFlatbufferObject
	{
		// Token: 0x17001F45 RID: 8005
		// (get) Token: 0x06010D66 RID: 68966 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F45")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D66")]
			[Address(RVA = "0x2149EB0", Offset = "0x2149EB0", VA = "0x2149EB0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D67 RID: 68967 RVA: 0x000616C8 File Offset: 0x0005F8C8
		[Token(Token = "0x6010D67")]
		[Address(RVA = "0x2149EB8", Offset = "0x2149EB8", VA = "0x2149EB8")]
		public static ClaimSpaceMissionRewardRequest GetRootAsClaimSpaceMissionRewardRequest(ByteBuffer _bb)
		{
			return default(ClaimSpaceMissionRewardRequest);
		}

		// Token: 0x06010D68 RID: 68968 RVA: 0x000616E0 File Offset: 0x0005F8E0
		[Token(Token = "0x6010D68")]
		[Address(RVA = "0x2149EC4", Offset = "0x2149EC4", VA = "0x2149EC4")]
		public static ClaimSpaceMissionRewardRequest GetRootAsClaimSpaceMissionRewardRequest(ByteBuffer _bb, ClaimSpaceMissionRewardRequest obj)
		{
			return default(ClaimSpaceMissionRewardRequest);
		}

		// Token: 0x06010D69 RID: 68969 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D69")]
		[Address(RVA = "0x2149F74", Offset = "0x2149F74", VA = "0x2149F74", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D6A RID: 68970 RVA: 0x000616F8 File Offset: 0x0005F8F8
		[Token(Token = "0x6010D6A")]
		[Address(RVA = "0x2149F3C", Offset = "0x2149F3C", VA = "0x2149F3C")]
		public ClaimSpaceMissionRewardRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimSpaceMissionRewardRequest);
		}

		// Token: 0x17001F46 RID: 8006
		// (get) Token: 0x06010D6B RID: 68971 RVA: 0x00061710 File Offset: 0x0005F910
		[Token(Token = "0x17001F46")]
		public long GroupId
		{
			[Token(Token = "0x6010D6B")]
			[Address(RVA = "0x2149F84", Offset = "0x2149F84", VA = "0x2149F84")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F47 RID: 8007
		// (get) Token: 0x06010D6C RID: 68972 RVA: 0x00061728 File Offset: 0x0005F928
		[Token(Token = "0x17001F47")]
		public bool IsWinner
		{
			[Token(Token = "0x6010D6C")]
			[Address(RVA = "0x2149FCC", Offset = "0x2149FCC", VA = "0x2149FCC")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06010D6D RID: 68973 RVA: 0x00061740 File Offset: 0x0005F940
		[Token(Token = "0x6010D6D")]
		[Address(RVA = "0x214A014", Offset = "0x214A014", VA = "0x214A014")]
		public static Offset<ClaimSpaceMissionRewardRequest> CreateClaimSpaceMissionRewardRequest(FlatBufferBuilder builder, long group_id = 0L, bool is_winner = false)
		{
			return default(Offset<ClaimSpaceMissionRewardRequest>);
		}

		// Token: 0x06010D6E RID: 68974 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D6E")]
		[Address(RVA = "0x214A118", Offset = "0x214A118", VA = "0x214A118")]
		public static void StartClaimSpaceMissionRewardRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D6F RID: 68975 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D6F")]
		[Address(RVA = "0x214A06C", Offset = "0x214A06C", VA = "0x214A06C")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06010D70 RID: 68976 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D70")]
		[Address(RVA = "0x214A08C", Offset = "0x214A08C", VA = "0x214A08C")]
		public static void AddIsWinner(FlatBufferBuilder builder, bool isWinner)
		{
		}

		// Token: 0x06010D71 RID: 68977 RVA: 0x00061758 File Offset: 0x0005F958
		[Token(Token = "0x6010D71")]
		[Address(RVA = "0x214A0AC", Offset = "0x214A0AC", VA = "0x214A0AC")]
		public static Offset<ClaimSpaceMissionRewardRequest> EndClaimSpaceMissionRewardRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimSpaceMissionRewardRequest>);
		}

		// Token: 0x0400E668 RID: 58984
		[Token(Token = "0x400E668")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
