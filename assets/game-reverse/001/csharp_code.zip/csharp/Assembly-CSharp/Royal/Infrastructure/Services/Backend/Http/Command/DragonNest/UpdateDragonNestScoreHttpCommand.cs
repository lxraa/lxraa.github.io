﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.DragonNest
{
	// Token: 0x02002571 RID: 9585
	[Token(Token = "0x2002571")]
	public class UpdateDragonNestScoreHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027AC RID: 10156
		// (get) Token: 0x06012B97 RID: 76695 RVA: 0x00079290 File Offset: 0x00077490
		[Token(Token = "0x170027AC")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B97")]
			[Address(RVA = "0x1ED3EB4", Offset = "0x1ED3EB4", VA = "0x1ED3EB4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027AD RID: 10157
		// (get) Token: 0x06012B98 RID: 76696 RVA: 0x000792A8 File Offset: 0x000774A8
		[Token(Token = "0x170027AD")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B98")]
			[Address(RVA = "0x1ED3EBC", Offset = "0x1ED3EBC", VA = "0x1ED3EBC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B99 RID: 76697 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B99")]
		[Address(RVA = "0x1ED3EC4", Offset = "0x1ED3EC4", VA = "0x1ED3EC4")]
		public UpdateDragonNestScoreHttpCommand(long partnerUserId, int myScore, sbyte stageUpStep)
		{
		}

		// Token: 0x06012B9A RID: 76698 RVA: 0x000792C0 File Offset: 0x000774C0
		[Token(Token = "0x6012B9A")]
		[Address(RVA = "0x1ED3F0C", Offset = "0x1ED3F0C", VA = "0x1ED3F0C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B9B RID: 76699 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B9B")]
		[Address(RVA = "0x1ED3F34", Offset = "0x1ED3F34", VA = "0x1ED3F34", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B9C RID: 76700 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B9C")]
		[Address(RVA = "0x1ED3F38", Offset = "0x1ED3F38", VA = "0x1ED3F38", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBF2 RID: 60402
		[Token(Token = "0x400EBF2")]
		[FieldOffset(Offset = "0x18")]
		private readonly long partnerUserId;

		// Token: 0x0400EBF3 RID: 60403
		[Token(Token = "0x400EBF3")]
		[FieldOffset(Offset = "0x20")]
		private readonly int myScore;

		// Token: 0x0400EBF4 RID: 60404
		[Token(Token = "0x400EBF4")]
		[FieldOffset(Offset = "0x24")]
		private readonly sbyte stageUpStep;
	}
}
