﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics.Event
{
	// Token: 0x020025A5 RID: 9637
	[Token(Token = "0x20025A5")]
	public class EventParameter
	{
		// Token: 0x06012D74 RID: 77172 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D74")]
		[Address(RVA = "0x243C980", Offset = "0x243C980", VA = "0x243C980")]
		public EventParameter(string key, string value)
		{
		}

		// Token: 0x06012D75 RID: 77173 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D75")]
		[Address(RVA = "0x243C9CC", Offset = "0x243C9CC", VA = "0x243C9CC")]
		public EventParameter(string key, long value)
		{
		}

		// Token: 0x06012D76 RID: 77174 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D76")]
		[Address(RVA = "0x243CA68", Offset = "0x243CA68", VA = "0x243CA68")]
		public EventParameter(string key, double value)
		{
		}

		// Token: 0x06012D77 RID: 77175 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D77")]
		[Address(RVA = "0x243C5A8", Offset = "0x243C5A8", VA = "0x243C5A8")]
		public EventParameter(string key, object value)
		{
		}

		// Token: 0x06012D78 RID: 77176 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D78")]
		[Address(RVA = "0x243CB0C", Offset = "0x243CB0C", VA = "0x243CB0C")]
		public EventParameter(string key, object[] value)
		{
		}

		// Token: 0x06012D79 RID: 77177 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D79")]
		[Address(RVA = "0x243CB5C", Offset = "0x243CB5C", VA = "0x243CB5C", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x06012D7A RID: 77178 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D7A")]
		[Address(RVA = "0x243CFF0", Offset = "0x243CFF0", VA = "0x243CFF0")]
		private void ConvertToJsonStringType()
		{
		}

		// Token: 0x0400ED42 RID: 60738
		[Token(Token = "0x400ED42")]
		private const byte StringType = 0;

		// Token: 0x0400ED43 RID: 60739
		[Token(Token = "0x400ED43")]
		private const byte LongType = 1;

		// Token: 0x0400ED44 RID: 60740
		[Token(Token = "0x400ED44")]
		private const byte DoubleType = 2;

		// Token: 0x0400ED45 RID: 60741
		[Token(Token = "0x400ED45")]
		private const byte JsonType = 3;

		// Token: 0x0400ED46 RID: 60742
		[Token(Token = "0x400ED46")]
		private const byte JsonStringType = 4;

		// Token: 0x0400ED47 RID: 60743
		[Token(Token = "0x400ED47")]
		private const byte JsonArrayType = 5;

		// Token: 0x0400ED48 RID: 60744
		[Token(Token = "0x400ED48")]
		[FieldOffset(Offset = "0x0")]
		private static readonly string JsonQuotes;

		// Token: 0x0400ED49 RID: 60745
		[Token(Token = "0x400ED49")]
		[FieldOffset(Offset = "0x8")]
		private static readonly string JsonColonString;

		// Token: 0x0400ED4A RID: 60746
		[Token(Token = "0x400ED4A")]
		[FieldOffset(Offset = "0x10")]
		private static readonly string JsonColonOthers;

		// Token: 0x0400ED4B RID: 60747
		[Token(Token = "0x400ED4B")]
		[FieldOffset(Offset = "0x18")]
		private static readonly string JsonArrayOpen;

		// Token: 0x0400ED4C RID: 60748
		[Token(Token = "0x400ED4C")]
		[FieldOffset(Offset = "0x20")]
		private static readonly string JsonArrayClose;

		// Token: 0x0400ED4D RID: 60749
		[Token(Token = "0x400ED4D")]
		[FieldOffset(Offset = "0x28")]
		private static readonly string JsonComma;

		// Token: 0x0400ED4E RID: 60750
		[Token(Token = "0x400ED4E")]
		[FieldOffset(Offset = "0x10")]
		private readonly string key;

		// Token: 0x0400ED4F RID: 60751
		[Token(Token = "0x400ED4F")]
		[FieldOffset(Offset = "0x18")]
		private object value;

		// Token: 0x0400ED50 RID: 60752
		[Token(Token = "0x400ED50")]
		[FieldOffset(Offset = "0x20")]
		private object[] valueArray;

		// Token: 0x0400ED51 RID: 60753
		[Token(Token = "0x400ED51")]
		[FieldOffset(Offset = "0x28")]
		private byte type;
	}
}
