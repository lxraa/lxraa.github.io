﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002371 RID: 9073
	[Token(Token = "0x2002371")]
	public enum CoopEventInvitationType : sbyte
	{
		// Token: 0x0400E687 RID: 59015
		[Token(Token = "0x400E687")]
		Invite,
		// Token: 0x0400E688 RID: 59016
		[Token(Token = "0x400E688")]
		Accept,
		// Token: 0x0400E689 RID: 59017
		[Token(Token = "0x400E689")]
		Reject,
		// Token: 0x0400E68A RID: 59018
		[Token(Token = "0x400E68A")]
		Dismiss
	}
}
