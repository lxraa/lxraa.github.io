﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TrainJourney
{
	// Token: 0x02002533 RID: 9523
	[Token(Token = "0x2002533")]
	public class UpdateTrainJourneyScoreHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700271A RID: 10010
		// (get) Token: 0x060129E8 RID: 76264 RVA: 0x00077E98 File Offset: 0x00076098
		[Token(Token = "0x1700271A")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129E8")]
			[Address(RVA = "0x1CFC0F8", Offset = "0x1CFC0F8", VA = "0x1CFC0F8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700271B RID: 10011
		// (get) Token: 0x060129E9 RID: 76265 RVA: 0x00077EB0 File Offset: 0x000760B0
		[Token(Token = "0x1700271B")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129E9")]
			[Address(RVA = "0x1CFC100", Offset = "0x1CFC100", VA = "0x1CFC100", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060129EA RID: 76266 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129EA")]
		[Address(RVA = "0x1CFC108", Offset = "0x1CFC108", VA = "0x1CFC108")]
		public UpdateTrainJourneyScoreHttpCommand(long partnerUserId, int myScore, sbyte stageUpStep)
		{
		}

		// Token: 0x060129EB RID: 76267 RVA: 0x00077EC8 File Offset: 0x000760C8
		[Token(Token = "0x60129EB")]
		[Address(RVA = "0x1CFC150", Offset = "0x1CFC150", VA = "0x1CFC150", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129EC RID: 76268 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129EC")]
		[Address(RVA = "0x1CFC178", Offset = "0x1CFC178", VA = "0x1CFC178", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129ED RID: 76269 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129ED")]
		[Address(RVA = "0x1CFC17C", Offset = "0x1CFC17C", VA = "0x1CFC17C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB38 RID: 60216
		[Token(Token = "0x400EB38")]
		[FieldOffset(Offset = "0x18")]
		private readonly long partnerUserId;

		// Token: 0x0400EB39 RID: 60217
		[Token(Token = "0x400EB39")]
		[FieldOffset(Offset = "0x20")]
		private readonly int myScore;

		// Token: 0x0400EB3A RID: 60218
		[Token(Token = "0x400EB3A")]
		[FieldOffset(Offset = "0x24")]
		private readonly sbyte stageUpStep;
	}
}
