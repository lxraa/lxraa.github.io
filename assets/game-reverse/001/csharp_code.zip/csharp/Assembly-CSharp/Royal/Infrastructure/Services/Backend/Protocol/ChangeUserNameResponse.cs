﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002352 RID: 9042
	[Token(Token = "0x2002352")]
	public struct ChangeUserNameResponse : IFlatbufferObject
	{
		// Token: 0x17001F0A RID: 7946
		// (get) Token: 0x06010C93 RID: 68755 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F0A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C93")]
			[Address(RVA = "0x2146F68", Offset = "0x2146F68", VA = "0x2146F68", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C94 RID: 68756 RVA: 0x00060C18 File Offset: 0x0005EE18
		[Token(Token = "0x6010C94")]
		[Address(RVA = "0x2146F70", Offset = "0x2146F70", VA = "0x2146F70")]
		public static ChangeUserNameResponse GetRootAsChangeUserNameResponse(ByteBuffer _bb)
		{
			return default(ChangeUserNameResponse);
		}

		// Token: 0x06010C95 RID: 68757 RVA: 0x00060C30 File Offset: 0x0005EE30
		[Token(Token = "0x6010C95")]
		[Address(RVA = "0x2146F7C", Offset = "0x2146F7C", VA = "0x2146F7C")]
		public static ChangeUserNameResponse GetRootAsChangeUserNameResponse(ByteBuffer _bb, ChangeUserNameResponse obj)
		{
			return default(ChangeUserNameResponse);
		}

		// Token: 0x06010C96 RID: 68758 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C96")]
		[Address(RVA = "0x214702C", Offset = "0x214702C", VA = "0x214702C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C97 RID: 68759 RVA: 0x00060C48 File Offset: 0x0005EE48
		[Token(Token = "0x6010C97")]
		[Address(RVA = "0x2146FF4", Offset = "0x2146FF4", VA = "0x2146FF4")]
		public ChangeUserNameResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ChangeUserNameResponse);
		}

		// Token: 0x17001F0B RID: 7947
		// (get) Token: 0x06010C98 RID: 68760 RVA: 0x00060C60 File Offset: 0x0005EE60
		[Token(Token = "0x17001F0B")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010C98")]
			[Address(RVA = "0x214703C", Offset = "0x214703C", VA = "0x214703C")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001F0C RID: 7948
		// (get) Token: 0x06010C99 RID: 68761 RVA: 0x00060C78 File Offset: 0x0005EE78
		[Token(Token = "0x17001F0C")]
		public long UserData
		{
			[Token(Token = "0x6010C99")]
			[Address(RVA = "0x2147080", Offset = "0x2147080", VA = "0x2147080")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F0D RID: 7949
		// (get) Token: 0x06010C9A RID: 68762 RVA: 0x00060C90 File Offset: 0x0005EE90
		[Token(Token = "0x17001F0D")]
		public ChatMessageFailReason FailReason
		{
			[Token(Token = "0x6010C9A")]
			[Address(RVA = "0x21470C8", Offset = "0x21470C8", VA = "0x21470C8")]
			get
			{
				return ChatMessageFailReason.None;
			}
		}

		// Token: 0x06010C9B RID: 68763 RVA: 0x00060CA8 File Offset: 0x0005EEA8
		[Token(Token = "0x6010C9B")]
		[Address(RVA = "0x214710C", Offset = "0x214710C", VA = "0x214710C")]
		public static Offset<ChangeUserNameResponse> CreateChangeUserNameResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, long user_data = 0L, ChatMessageFailReason fail_reason = ChatMessageFailReason.None)
		{
			return default(Offset<ChangeUserNameResponse>);
		}

		// Token: 0x06010C9C RID: 68764 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C9C")]
		[Address(RVA = "0x2147248", Offset = "0x2147248", VA = "0x2147248")]
		public static void StartChangeUserNameResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C9D RID: 68765 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C9D")]
		[Address(RVA = "0x21471BC", Offset = "0x21471BC", VA = "0x21471BC")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010C9E RID: 68766 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C9E")]
		[Address(RVA = "0x214717C", Offset = "0x214717C", VA = "0x214717C")]
		public static void AddUserData(FlatBufferBuilder builder, long userData)
		{
		}

		// Token: 0x06010C9F RID: 68767 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C9F")]
		[Address(RVA = "0x214719C", Offset = "0x214719C", VA = "0x214719C")]
		public static void AddFailReason(FlatBufferBuilder builder, ChatMessageFailReason failReason)
		{
		}

		// Token: 0x06010CA0 RID: 68768 RVA: 0x00060CC0 File Offset: 0x0005EEC0
		[Token(Token = "0x6010CA0")]
		[Address(RVA = "0x21471DC", Offset = "0x21471DC", VA = "0x21471DC")]
		public static Offset<ChangeUserNameResponse> EndChangeUserNameResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ChangeUserNameResponse>);
		}

		// Token: 0x0400E644 RID: 58948
		[Token(Token = "0x400E644")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
