﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts
{
	// Token: 0x020025AE RID: 9646
	[Token(Token = "0x20025AE")]
	public interface IContextBehaviour : IContextUnit
	{
		// Token: 0x06012DB0 RID: 77232
		[Token(Token = "0x6012DB0")]
		void ManualUpdate();
	}
}
