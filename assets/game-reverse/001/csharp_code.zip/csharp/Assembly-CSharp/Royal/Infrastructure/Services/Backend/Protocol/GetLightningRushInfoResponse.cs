﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023E3 RID: 9187
	[Token(Token = "0x20023E3")]
	public struct GetLightningRushInfoResponse : IFlatbufferObject
	{
		// Token: 0x17002120 RID: 8480
		// (get) Token: 0x06011484 RID: 70788 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002120")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011484")]
			[Address(RVA = "0x1CB325C", Offset = "0x1CB325C", VA = "0x1CB325C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011485 RID: 70789 RVA: 0x000675A8 File Offset: 0x000657A8
		[Token(Token = "0x6011485")]
		[Address(RVA = "0x1CB3264", Offset = "0x1CB3264", VA = "0x1CB3264")]
		public static GetLightningRushInfoResponse GetRootAsGetLightningRushInfoResponse(ByteBuffer _bb)
		{
			return default(GetLightningRushInfoResponse);
		}

		// Token: 0x06011486 RID: 70790 RVA: 0x000675C0 File Offset: 0x000657C0
		[Token(Token = "0x6011486")]
		[Address(RVA = "0x1CB3270", Offset = "0x1CB3270", VA = "0x1CB3270")]
		public static GetLightningRushInfoResponse GetRootAsGetLightningRushInfoResponse(ByteBuffer _bb, GetLightningRushInfoResponse obj)
		{
			return default(GetLightningRushInfoResponse);
		}

		// Token: 0x06011487 RID: 70791 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011487")]
		[Address(RVA = "0x1CB3320", Offset = "0x1CB3320", VA = "0x1CB3320", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011488 RID: 70792 RVA: 0x000675D8 File Offset: 0x000657D8
		[Token(Token = "0x6011488")]
		[Address(RVA = "0x1CB32E8", Offset = "0x1CB32E8", VA = "0x1CB32E8")]
		public GetLightningRushInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetLightningRushInfoResponse);
		}

		// Token: 0x17002121 RID: 8481
		// (get) Token: 0x06011489 RID: 70793 RVA: 0x000675F0 File Offset: 0x000657F0
		[Token(Token = "0x17002121")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6011489")]
			[Address(RVA = "0x1CB3330", Offset = "0x1CB3330", VA = "0x1CB3330")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17002122 RID: 8482
		// (get) Token: 0x0601148A RID: 70794 RVA: 0x00067608 File Offset: 0x00065808
		[Token(Token = "0x17002122")]
		public LightningRushInfo? LightningRushInfo
		{
			[Token(Token = "0x601148A")]
			[Address(RVA = "0x1CB3374", Offset = "0x1CB3374", VA = "0x1CB3374")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601148B RID: 70795 RVA: 0x00067620 File Offset: 0x00065820
		[Token(Token = "0x601148B")]
		[Address(RVA = "0x1CB3434", Offset = "0x1CB3434", VA = "0x1CB3434")]
		public static Offset<GetLightningRushInfoResponse> CreateGetLightningRushInfoResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, [Optional] Offset<LightningRushInfo> lightning_rush_infoOffset)
		{
			return default(Offset<GetLightningRushInfoResponse>);
		}

		// Token: 0x0601148C RID: 70796 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601148C")]
		[Address(RVA = "0x1CB3538", Offset = "0x1CB3538", VA = "0x1CB3538")]
		public static void StartGetLightningRushInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601148D RID: 70797 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601148D")]
		[Address(RVA = "0x1CB34AC", Offset = "0x1CB34AC", VA = "0x1CB34AC")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x0601148E RID: 70798 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601148E")]
		[Address(RVA = "0x1CB348C", Offset = "0x1CB348C", VA = "0x1CB348C")]
		public static void AddLightningRushInfo(FlatBufferBuilder builder, Offset<LightningRushInfo> lightningRushInfoOffset)
		{
		}

		// Token: 0x0601148F RID: 70799 RVA: 0x00067638 File Offset: 0x00065838
		[Token(Token = "0x601148F")]
		[Address(RVA = "0x1CB34CC", Offset = "0x1CB34CC", VA = "0x1CB34CC")]
		public static Offset<GetLightningRushInfoResponse> EndGetLightningRushInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetLightningRushInfoResponse>);
		}

		// Token: 0x0400E753 RID: 59219
		[Token(Token = "0x400E753")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
