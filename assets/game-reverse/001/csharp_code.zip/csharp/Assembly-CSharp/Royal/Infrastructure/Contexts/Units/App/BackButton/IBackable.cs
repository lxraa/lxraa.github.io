﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App.BackButton
{
	// Token: 0x020025C7 RID: 9671
	[Token(Token = "0x20025C7")]
	public interface IBackable
	{
		// Token: 0x06012EC4 RID: 77508
		[Token(Token = "0x6012EC4")]
		void PressBack();
	}
}
