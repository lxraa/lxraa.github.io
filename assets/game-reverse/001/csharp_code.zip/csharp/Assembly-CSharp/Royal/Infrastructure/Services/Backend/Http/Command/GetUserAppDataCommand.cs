﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002517 RID: 9495
	[Token(Token = "0x2002517")]
	public class GetUserAppDataCommand : BaseHttpCommand
	{
		// Token: 0x060128D1 RID: 75985 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128D1")]
		[Address(RVA = "0x1CEB690", Offset = "0x1CEB690", VA = "0x1CEB690")]
		public GetUserAppDataCommand(Action<long> onSuccess, Action onFail)
		{
		}

		// Token: 0x170026D4 RID: 9940
		// (get) Token: 0x060128D2 RID: 75986 RVA: 0x00077508 File Offset: 0x00075708
		[Token(Token = "0x170026D4")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60128D2")]
			[Address(RVA = "0x1CEB6D4", Offset = "0x1CEB6D4", VA = "0x1CEB6D4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026D5 RID: 9941
		// (get) Token: 0x060128D3 RID: 75987 RVA: 0x00077520 File Offset: 0x00075720
		[Token(Token = "0x170026D5")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60128D3")]
			[Address(RVA = "0x1CEB6DC", Offset = "0x1CEB6DC", VA = "0x1CEB6DC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026D6 RID: 9942
		// (get) Token: 0x060128D4 RID: 75988 RVA: 0x00077538 File Offset: 0x00075738
		// (set) Token: 0x060128D5 RID: 75989 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026D6")]
		private GetUserAppDataResponse Response
		{
			[Token(Token = "0x60128D4")]
			[Address(RVA = "0x1CEB6E4", Offset = "0x1CEB6E4", VA = "0x1CEB6E4")]
			get
			{
				return default(GetUserAppDataResponse);
			}
			[Token(Token = "0x60128D5")]
			[Address(RVA = "0x1CEB6F0", Offset = "0x1CEB6F0", VA = "0x1CEB6F0")]
			set
			{
			}
		}

		// Token: 0x060128D6 RID: 75990 RVA: 0x00077550 File Offset: 0x00075750
		[Token(Token = "0x60128D6")]
		[Address(RVA = "0x1CEB700", Offset = "0x1CEB700", VA = "0x1CEB700", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060128D7 RID: 75991 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128D7")]
		[Address(RVA = "0x1CEB728", Offset = "0x1CEB728", VA = "0x1CEB728", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060128D8 RID: 75992 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128D8")]
		[Address(RVA = "0x1CEB80C", Offset = "0x1CEB80C", VA = "0x1CEB80C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EAC5 RID: 60101
		[Token(Token = "0x400EAC5")]
		[FieldOffset(Offset = "0x18")]
		private readonly Action<long> onSuccess;

		// Token: 0x0400EAC6 RID: 60102
		[Token(Token = "0x400EAC6")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action onFail;

		// Token: 0x0400EAC7 RID: 60103
		[Token(Token = "0x400EAC7")]
		[FieldOffset(Offset = "0x28")]
		private GetUserAppDataResponse <Response>k__BackingField;
	}
}
