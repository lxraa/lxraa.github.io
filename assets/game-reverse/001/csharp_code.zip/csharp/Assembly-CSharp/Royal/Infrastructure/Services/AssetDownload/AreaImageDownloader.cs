﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using Royal.Scenes.Home.Ui.Sections.Episodes;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002580 RID: 9600
	[Token(Token = "0x2002580")]
	public class AreaImageDownloader
	{
		// Token: 0x170027C9 RID: 10185
		// (get) Token: 0x06012C1E RID: 76830 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012C1F RID: 76831 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027C9")]
		public string BundleName
		{
			[Token(Token = "0x6012C1E")]
			[Address(RVA = "0x1ED9904", Offset = "0x1ED9904", VA = "0x1ED9904")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012C1F")]
			[Address(RVA = "0x1ED990C", Offset = "0x1ED990C", VA = "0x1ED990C")]
			private set
			{
			}
		}

		// Token: 0x06012C20 RID: 76832 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C20")]
		[Address(RVA = "0x1ED9914", Offset = "0x1ED9914", VA = "0x1ED9914")]
		public AreaImageDownloader(EpisodeImageAssetsManager manager)
		{
		}

		// Token: 0x170027CA RID: 10186
		// (get) Token: 0x06012C21 RID: 76833 RVA: 0x00079710 File Offset: 0x00077910
		// (set) Token: 0x06012C22 RID: 76834 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027CA")]
		public bool IsDownloading
		{
			[Token(Token = "0x6012C21")]
			[Address(RVA = "0x1ED99B8", Offset = "0x1ED99B8", VA = "0x1ED99B8")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012C22")]
			[Address(RVA = "0x1ED99C0", Offset = "0x1ED99C0", VA = "0x1ED99C0")]
			private set
			{
			}
		}

		// Token: 0x06012C23 RID: 76835 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C23")]
		[Address(RVA = "0x1ED99CC", Offset = "0x1ED99CC", VA = "0x1ED99CC")]
		public void Download(string episodeQuaternaryBundleName)
		{
		}

		// Token: 0x06012C24 RID: 76836 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C24")]
		[Address(RVA = "0x1ED9BB4", Offset = "0x1ED9BB4", VA = "0x1ED9BB4")]
		private void OnFileSaveCompleted(bool downloaded, string eTag)
		{
		}

		// Token: 0x06012C25 RID: 76837 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C25")]
		[Address(RVA = "0x1ED9B4C", Offset = "0x1ED9B4C", VA = "0x1ED9B4C")]
		private FileDownloadSettings GetFileDownloadSettings()
		{
			return null;
		}

		// Token: 0x06012C26 RID: 76838 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C26")]
		[Address(RVA = "0x1ED9BE0", Offset = "0x1ED9BE0", VA = "0x1ED9BE0")]
		public static void CreateDirectory()
		{
		}

		// Token: 0x06012C27 RID: 76839 RVA: 0x00079728 File Offset: 0x00077928
		[Token(Token = "0x6012C27")]
		[Address(RVA = "0x1ED9C70", Offset = "0x1ED9C70", VA = "0x1ED9C70")]
		public static bool IsBundleExistInFileSystem(string bundleName)
		{
			return default(bool);
		}

		// Token: 0x06012C28 RID: 76840 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C28")]
		[Address(RVA = "0x1ED9D5C", Offset = "0x1ED9D5C", VA = "0x1ED9D5C")]
		public static HashSet<string> GetDownloadedAreaImageBundles()
		{
			return null;
		}

		// Token: 0x06012C29 RID: 76841 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C29")]
		[Address(RVA = "0x1ED9EB4", Offset = "0x1ED9EB4", VA = "0x1ED9EB4")]
		public static string GetBundlePath(string bundleName, bool loadFromStreamingAssets)
		{
			return null;
		}

		// Token: 0x06012C2A RID: 76842 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C2A")]
		[Address(RVA = "0x1ED9CCC", Offset = "0x1ED9CCC", VA = "0x1ED9CCC")]
		private static string GetPersistentBundlePath(string bundleName)
		{
			return null;
		}

		// Token: 0x06012C2B RID: 76843 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C2B")]
		[Address(RVA = "0x1ED9F28", Offset = "0x1ED9F28", VA = "0x1ED9F28")]
		private static string GetStreamingAssetsBundlePath(string bundleName)
		{
			return null;
		}

		// Token: 0x06012C2C RID: 76844 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C2C")]
		[Address(RVA = "0x1EDA00C", Offset = "0x1EDA00C", VA = "0x1EDA00C")]
		public static void CopyAreaImageQuaternaryFromStreamingAssets(int areaId)
		{
		}

		// Token: 0x06012C2E RID: 76846 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C2E")]
		[Address(RVA = "0x1EDA154", Offset = "0x1EDA154", VA = "0x1EDA154")]
		private void <Download>b__13_0()
		{
		}

		// Token: 0x0400EC34 RID: 60468
		[Token(Token = "0x400EC34")]
		private const string AreaImageDownloadUrl = "https://contents.prod.rylmtch.com/asset-bundles/area-image/android/";

		// Token: 0x0400EC35 RID: 60469
		[Token(Token = "0x400EC35")]
		[FieldOffset(Offset = "0x0")]
		private static readonly string AreaImageAssetBundlesDirectory;

		// Token: 0x0400EC36 RID: 60470
		[Token(Token = "0x400EC36")]
		[FieldOffset(Offset = "0x10")]
		private readonly EpisodeImageAssetsManager manager;

		// Token: 0x0400EC37 RID: 60471
		[Token(Token = "0x400EC37")]
		[FieldOffset(Offset = "0x18")]
		private readonly FileDownloadManager fileDownloadManager;

		// Token: 0x0400EC38 RID: 60472
		[Token(Token = "0x400EC38")]
		[FieldOffset(Offset = "0x20")]
		private string <BundleName>k__BackingField;

		// Token: 0x0400EC39 RID: 60473
		[Token(Token = "0x400EC39")]
		[FieldOffset(Offset = "0x28")]
		private bool <IsDownloading>k__BackingField;
	}
}
