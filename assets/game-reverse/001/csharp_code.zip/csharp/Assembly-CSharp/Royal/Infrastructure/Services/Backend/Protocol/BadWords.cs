﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002347 RID: 9031
	[Token(Token = "0x2002347")]
	public struct BadWords : IFlatbufferObject
	{
		// Token: 0x17001EE7 RID: 7911
		// (get) Token: 0x06010BF9 RID: 68601 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EE7")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010BF9")]
			[Address(RVA = "0x2144AD8", Offset = "0x2144AD8", VA = "0x2144AD8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BFA RID: 68602 RVA: 0x00060480 File Offset: 0x0005E680
		[Token(Token = "0x6010BFA")]
		[Address(RVA = "0x2144AE0", Offset = "0x2144AE0", VA = "0x2144AE0")]
		public static BadWords GetRootAsBadWords(ByteBuffer _bb)
		{
			return default(BadWords);
		}

		// Token: 0x06010BFB RID: 68603 RVA: 0x00060498 File Offset: 0x0005E698
		[Token(Token = "0x6010BFB")]
		[Address(RVA = "0x2144AEC", Offset = "0x2144AEC", VA = "0x2144AEC")]
		public static BadWords GetRootAsBadWords(ByteBuffer _bb, BadWords obj)
		{
			return default(BadWords);
		}

		// Token: 0x06010BFC RID: 68604 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BFC")]
		[Address(RVA = "0x2144B9C", Offset = "0x2144B9C", VA = "0x2144B9C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010BFD RID: 68605 RVA: 0x000604B0 File Offset: 0x0005E6B0
		[Token(Token = "0x6010BFD")]
		[Address(RVA = "0x2144B64", Offset = "0x2144B64", VA = "0x2144B64")]
		public BadWords __assign(int _i, ByteBuffer _bb)
		{
			return default(BadWords);
		}

		// Token: 0x17001EE8 RID: 7912
		// (get) Token: 0x06010BFE RID: 68606 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EE8")]
		public string Language
		{
			[Token(Token = "0x6010BFE")]
			[Address(RVA = "0x2144BAC", Offset = "0x2144BAC", VA = "0x2144BAC")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BFF RID: 68607 RVA: 0x000604C8 File Offset: 0x0005E6C8
		[Token(Token = "0x6010BFF")]
		[Address(RVA = "0x2144BE8", Offset = "0x2144BE8", VA = "0x2144BE8")]
		public ArraySegment<byte>? GetLanguageBytes()
		{
			return null;
		}

		// Token: 0x06010C00 RID: 68608 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010C00")]
		[Address(RVA = "0x2144C20", Offset = "0x2144C20", VA = "0x2144C20")]
		public byte[] GetLanguageArray()
		{
			return null;
		}

		// Token: 0x17001EE9 RID: 7913
		// (get) Token: 0x06010C01 RID: 68609 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EE9")]
		public string Regex
		{
			[Token(Token = "0x6010C01")]
			[Address(RVA = "0x2144C6C", Offset = "0x2144C6C", VA = "0x2144C6C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C02 RID: 68610 RVA: 0x000604E0 File Offset: 0x0005E6E0
		[Token(Token = "0x6010C02")]
		[Address(RVA = "0x2144CA8", Offset = "0x2144CA8", VA = "0x2144CA8")]
		public ArraySegment<byte>? GetRegexBytes()
		{
			return null;
		}

		// Token: 0x06010C03 RID: 68611 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010C03")]
		[Address(RVA = "0x2144CE0", Offset = "0x2144CE0", VA = "0x2144CE0")]
		public byte[] GetRegexArray()
		{
			return null;
		}

		// Token: 0x06010C04 RID: 68612 RVA: 0x000604F8 File Offset: 0x0005E6F8
		[Token(Token = "0x6010C04")]
		[Address(RVA = "0x2144D2C", Offset = "0x2144D2C", VA = "0x2144D2C")]
		public static Offset<BadWords> CreateBadWords(FlatBufferBuilder builder, [Optional] StringOffset languageOffset, [Optional] StringOffset regexOffset)
		{
			return default(Offset<BadWords>);
		}

		// Token: 0x06010C05 RID: 68613 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C05")]
		[Address(RVA = "0x2144E30", Offset = "0x2144E30", VA = "0x2144E30")]
		public static void StartBadWords(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C06 RID: 68614 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C06")]
		[Address(RVA = "0x2144DA4", Offset = "0x2144DA4", VA = "0x2144DA4")]
		public static void AddLanguage(FlatBufferBuilder builder, StringOffset languageOffset)
		{
		}

		// Token: 0x06010C07 RID: 68615 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C07")]
		[Address(RVA = "0x2144D84", Offset = "0x2144D84", VA = "0x2144D84")]
		public static void AddRegex(FlatBufferBuilder builder, StringOffset regexOffset)
		{
		}

		// Token: 0x06010C08 RID: 68616 RVA: 0x00060510 File Offset: 0x0005E710
		[Token(Token = "0x6010C08")]
		[Address(RVA = "0x2144DC4", Offset = "0x2144DC4", VA = "0x2144DC4")]
		public static Offset<BadWords> EndBadWords(FlatBufferBuilder builder)
		{
			return default(Offset<BadWords>);
		}

		// Token: 0x0400E62B RID: 58923
		[Token(Token = "0x400E62B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
