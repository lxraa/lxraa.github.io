﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SystemMessage
{
	// Token: 0x0200253C RID: 9532
	[Token(Token = "0x200253C")]
	public class ConsumeSystemMessageHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700272E RID: 10030
		// (get) Token: 0x06012A22 RID: 76322 RVA: 0x00078150 File Offset: 0x00076350
		[Token(Token = "0x1700272E")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A22")]
			[Address(RVA = "0x1CFE5B0", Offset = "0x1CFE5B0", VA = "0x1CFE5B0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700272F RID: 10031
		// (get) Token: 0x06012A23 RID: 76323 RVA: 0x00078168 File Offset: 0x00076368
		[Token(Token = "0x1700272F")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A23")]
			[Address(RVA = "0x1CFE5B8", Offset = "0x1CFE5B8", VA = "0x1CFE5B8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A24 RID: 76324 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A24")]
		[Address(RVA = "0x1CFE5C0", Offset = "0x1CFE5C0", VA = "0x1CFE5C0")]
		public ConsumeSystemMessageHttpCommand(int messageId)
		{
		}

		// Token: 0x17002730 RID: 10032
		// (get) Token: 0x06012A25 RID: 76325 RVA: 0x00078180 File Offset: 0x00076380
		// (set) Token: 0x06012A26 RID: 76326 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002730")]
		private ConsumeSystemMessagesResponse Response
		{
			[Token(Token = "0x6012A25")]
			[Address(RVA = "0x1CFE5F0", Offset = "0x1CFE5F0", VA = "0x1CFE5F0")]
			get
			{
				return default(ConsumeSystemMessagesResponse);
			}
			[Token(Token = "0x6012A26")]
			[Address(RVA = "0x1CFE5FC", Offset = "0x1CFE5FC", VA = "0x1CFE5FC")]
			set
			{
			}
		}

		// Token: 0x06012A27 RID: 76327 RVA: 0x00078198 File Offset: 0x00076398
		[Token(Token = "0x6012A27")]
		[Address(RVA = "0x1CFE60C", Offset = "0x1CFE60C", VA = "0x1CFE60C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A28 RID: 76328 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A28")]
		[Address(RVA = "0x1CFE724", Offset = "0x1CFE724", VA = "0x1CFE724", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A29 RID: 76329 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A29")]
		[Address(RVA = "0x1CFE94C", Offset = "0x1CFE94C", VA = "0x1CFE94C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB55 RID: 60245
		[Token(Token = "0x400EB55")]
		[FieldOffset(Offset = "0x14")]
		private readonly int messageId;

		// Token: 0x0400EB56 RID: 60246
		[Token(Token = "0x400EB56")]
		[FieldOffset(Offset = "0x18")]
		private ConsumeSystemMessagesResponse <Response>k__BackingField;
	}
}
