﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Contexts.Units.App;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002521 RID: 9505
	[Token(Token = "0x2002521")]
	public class UpdateUserProgressHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026F1 RID: 9969
		// (get) Token: 0x0601294C RID: 76108 RVA: 0x000778B0 File Offset: 0x00075AB0
		[Token(Token = "0x170026F1")]
		public override RequestType RequestType
		{
			[Token(Token = "0x601294C")]
			[Address(RVA = "0x1CF329C", Offset = "0x1CF329C", VA = "0x1CF329C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026F2 RID: 9970
		// (get) Token: 0x0601294D RID: 76109 RVA: 0x000778C8 File Offset: 0x00075AC8
		[Token(Token = "0x170026F2")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x601294D")]
			[Address(RVA = "0x1CF32A4", Offset = "0x1CF32A4", VA = "0x1CF32A4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026F3 RID: 9971
		// (get) Token: 0x0601294E RID: 76110 RVA: 0x000778E0 File Offset: 0x00075AE0
		// (set) Token: 0x0601294F RID: 76111 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026F3")]
		private UpdateUserProgressResponse Response
		{
			[Token(Token = "0x601294E")]
			[Address(RVA = "0x1CF32AC", Offset = "0x1CF32AC", VA = "0x1CF32AC")]
			get
			{
				return default(UpdateUserProgressResponse);
			}
			[Token(Token = "0x601294F")]
			[Address(RVA = "0x1CF32B8", Offset = "0x1CF32B8", VA = "0x1CF32B8")]
			set
			{
			}
		}

		// Token: 0x06012950 RID: 76112 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012950")]
		[Address(RVA = "0x1CF32C8", Offset = "0x1CF32C8", VA = "0x1CF32C8")]
		public UpdateUserProgressHttpCommand(bool updateBasicData, bool updateInventory = false, bool updateArea = false, bool updateLogData = false)
		{
		}

		// Token: 0x06012951 RID: 76113 RVA: 0x000778F8 File Offset: 0x00075AF8
		[Token(Token = "0x6012951")]
		[Address(RVA = "0x1CF33B8", Offset = "0x1CF33B8", VA = "0x1CF33B8", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012952 RID: 76114 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012952")]
		[Address(RVA = "0x1CF4DF4", Offset = "0x1CF4DF4", VA = "0x1CF4DF4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012953 RID: 76115 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012953")]
		[Address(RVA = "0x1CF60DC", Offset = "0x1CF60DC", VA = "0x1CF60DC")]
		private void UpdateTeamOfferData()
		{
		}

		// Token: 0x06012954 RID: 76116 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012954")]
		[Address(RVA = "0x1CF7954", Offset = "0x1CF7954", VA = "0x1CF7954", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012955 RID: 76117 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012955")]
		[Address(RVA = "0x1CF55F4", Offset = "0x1CF55F4", VA = "0x1CF55F4")]
		private void UpdateLeagueInfo()
		{
		}

		// Token: 0x06012956 RID: 76118 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012956")]
		[Address(RVA = "0x1CF5804", Offset = "0x1CF5804", VA = "0x1CF5804")]
		private void UpdateKingsCupInfo()
		{
		}

		// Token: 0x06012957 RID: 76119 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012957")]
		[Address(RVA = "0x1CF56D4", Offset = "0x1CF56D4", VA = "0x1CF56D4")]
		private void UpdateTeamBattleInfo()
		{
		}

		// Token: 0x06012958 RID: 76120 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012958")]
		[Address(RVA = "0x1CF5D40", Offset = "0x1CF5D40", VA = "0x1CF5D40")]
		private void UpdateTeamTreasureData()
		{
		}

		// Token: 0x06012959 RID: 76121 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012959")]
		[Address(RVA = "0x1CF5E70", Offset = "0x1CF5E70", VA = "0x1CF5E70")]
		private void UpdateLightningRush()
		{
		}

		// Token: 0x0601295A RID: 76122 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601295A")]
		[Address(RVA = "0x1CF5F9C", Offset = "0x1CF5F9C", VA = "0x1CF5F9C")]
		private void UpdateSpaceMission()
		{
		}

		// Token: 0x0601295B RID: 76123 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601295B")]
		[Address(RVA = "0x1CF61AC", Offset = "0x1CF61AC", VA = "0x1CF61AC")]
		private void UpdateDragonNest()
		{
		}

		// Token: 0x0601295C RID: 76124 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601295C")]
		[Address(RVA = "0x1CF62D8", Offset = "0x1CF62D8", VA = "0x1CF62D8")]
		private void UpdateTrainJourney()
		{
		}

		// Token: 0x0601295D RID: 76125 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601295D")]
		[Address(RVA = "0x1CF5930", Offset = "0x1CF5930", VA = "0x1CF5930")]
		private void UpdateMadnessData()
		{
		}

		// Token: 0x0601295E RID: 76126 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601295E")]
		[Address(RVA = "0x1CF5A00", Offset = "0x1CF5A00", VA = "0x1CF5A00")]
		private void UpdateLadderOfferData()
		{
		}

		// Token: 0x0601295F RID: 76127 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601295F")]
		[Address(RVA = "0x1CF5AD0", Offset = "0x1CF5AD0", VA = "0x1CF5AD0")]
		private void UpdateRoyalPassData()
		{
		}

		// Token: 0x06012960 RID: 76128 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012960")]
		[Address(RVA = "0x1CF5BA0", Offset = "0x1CF5BA0", VA = "0x1CF5BA0")]
		private void UpdateSkyRace()
		{
		}

		// Token: 0x06012961 RID: 76129 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012961")]
		[Address(RVA = "0x1CF5C70", Offset = "0x1CF5C70", VA = "0x1CF5C70")]
		private void UpdateOfferData()
		{
		}

		// Token: 0x06012962 RID: 76130 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012962")]
		[Address(RVA = "0x1CF6404", Offset = "0x1CF6404", VA = "0x1CF6404")]
		private void UpdateArcheryArenaData()
		{
		}

		// Token: 0x06012963 RID: 76131 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012963")]
		[Address(RVA = "0x1CF64D4", Offset = "0x1CF64D4", VA = "0x1CF64D4")]
		private void UpdateTeamTournamentData()
		{
		}

		// Token: 0x06012964 RID: 76132 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012964")]
		[Address(RVA = "0x1CF65A8", Offset = "0x1CF65A8", VA = "0x1CF65A8")]
		private void UpdateDukesFortune()
		{
		}

		// Token: 0x06012965 RID: 76133 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012965")]
		[Address(RVA = "0x1CF66D4", Offset = "0x1CF66D4", VA = "0x1CF66D4")]
		private void UpdateLavaQuestData()
		{
		}

		// Token: 0x06012966 RID: 76134 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012966")]
		[Address(RVA = "0x1CF67CC", Offset = "0x1CF67CC", VA = "0x1CF67CC")]
		private void UpdateHiddenTemple()
		{
		}

		// Token: 0x06012967 RID: 76135 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012967")]
		[Address(RVA = "0x1CF689C", Offset = "0x1CF689C", VA = "0x1CF689C")]
		private void UpdatePinataParty()
		{
		}

		// Token: 0x06012968 RID: 76136 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012968")]
		[Address(RVA = "0x1CF696C", Offset = "0x1CF696C", VA = "0x1CF696C")]
		private void UpdateBalloonRise()
		{
		}

		// Token: 0x06012969 RID: 76137 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012969")]
		[Address(RVA = "0x1CF6A98", Offset = "0x1CF6A98", VA = "0x1CF6A98")]
		private void UpdateMagicCauldron()
		{
		}

		// Token: 0x0601296A RID: 76138 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601296A")]
		[Address(RVA = "0x1CF6BC4", Offset = "0x1CF6BC4", VA = "0x1CF6BC4")]
		private void UpdateOceanOdyssey()
		{
		}

		// Token: 0x0601296B RID: 76139 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601296B")]
		[Address(RVA = "0x1CF6DE8", Offset = "0x1CF6DE8", VA = "0x1CF6DE8")]
		private void UpdateMissionPursuit()
		{
		}

		// Token: 0x0601296C RID: 76140 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601296C")]
		[Address(RVA = "0x1CF6F14", Offset = "0x1CF6F14", VA = "0x1CF6F14")]
		private void UpdateMissionControl()
		{
		}

		// Token: 0x0601296D RID: 76141 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601296D")]
		[Address(RVA = "0x1CF7040", Offset = "0x1CF7040", VA = "0x1CF7040")]
		private void UpdateCoinShopData()
		{
		}

		// Token: 0x0601296E RID: 76142 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601296E")]
		[Address(RVA = "0x1CF7138", Offset = "0x1CF7138", VA = "0x1CF7138")]
		private void UpdateDailyLightningRush()
		{
		}

		// Token: 0x0601296F RID: 76143 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601296F")]
		[Address(RVA = "0x1CF7264", Offset = "0x1CF7264", VA = "0x1CF7264")]
		private void UpdatePuzzleBreak()
		{
		}

		// Token: 0x06012970 RID: 76144 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012970")]
		[Address(RVA = "0x1CF74BC", Offset = "0x1CF74BC", VA = "0x1CF74BC")]
		private void UpdatePropellerRush()
		{
		}

		// Token: 0x06012971 RID: 76145 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012971")]
		[Address(RVA = "0x1CF75E8", Offset = "0x1CF75E8", VA = "0x1CF75E8")]
		private void UpdateAncientAdventure()
		{
		}

		// Token: 0x06012972 RID: 76146 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012972")]
		[Address(RVA = "0x1CF785C", Offset = "0x1CF785C", VA = "0x1CF785C")]
		private void UpdateDynamicOfferData()
		{
		}

		// Token: 0x06012973 RID: 76147 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012973")]
		[Address(RVA = "0x1CF7390", Offset = "0x1CF7390", VA = "0x1CF7390")]
		private void UpdateNewRoyalPassData()
		{
		}

		// Token: 0x06012974 RID: 76148 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012974")]
		[Address(RVA = "0x1CF7714", Offset = "0x1CF7714", VA = "0x1CF7714")]
		private void UpdateEventDependency()
		{
		}

		// Token: 0x06012975 RID: 76149 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012975")]
		[Address(RVA = "0x1CF6CF0", Offset = "0x1CF6CF0", VA = "0x1CF6CF0")]
		private void UpdateSeasonalCardCollectionData()
		{
		}

		// Token: 0x0400EB06 RID: 60166
		[Token(Token = "0x400EB06")]
		[FieldOffset(Offset = "0x13")]
		private readonly bool updateArea;

		// Token: 0x0400EB07 RID: 60167
		[Token(Token = "0x400EB07")]
		[FieldOffset(Offset = "0x14")]
		private readonly bool updateInventory;

		// Token: 0x0400EB08 RID: 60168
		[Token(Token = "0x400EB08")]
		[FieldOffset(Offset = "0x15")]
		private readonly bool updateBasicData;

		// Token: 0x0400EB09 RID: 60169
		[Token(Token = "0x400EB09")]
		[FieldOffset(Offset = "0x16")]
		private readonly bool updateLogData;

		// Token: 0x0400EB0A RID: 60170
		[Token(Token = "0x400EB0A")]
		[FieldOffset(Offset = "0x18")]
		private int syncRequiredCommandsCountAtBuild;

		// Token: 0x0400EB0B RID: 60171
		[Token(Token = "0x400EB0B")]
		[FieldOffset(Offset = "0x20")]
		private readonly BackendHttpService backendHttpService;

		// Token: 0x0400EB0C RID: 60172
		[Token(Token = "0x400EB0C")]
		[FieldOffset(Offset = "0x28")]
		private AppManager appManager;

		// Token: 0x0400EB0D RID: 60173
		[Token(Token = "0x400EB0D")]
		[FieldOffset(Offset = "0x30")]
		private UpdateUserProgressResponse <Response>k__BackingField;
	}
}
