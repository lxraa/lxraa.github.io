﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x0200257B RID: 9595
	[Token(Token = "0x200257B")]
	public class AreaDownloader
	{
		// Token: 0x170027C3 RID: 10179
		// (get) Token: 0x06012BDC RID: 76764 RVA: 0x000795F0 File Offset: 0x000777F0
		[Token(Token = "0x170027C3")]
		public bool IsQueuedForDownload
		{
			[Token(Token = "0x6012BDC")]
			[Address(RVA = "0x1ED633C", Offset = "0x1ED633C", VA = "0x1ED633C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170027C4 RID: 10180
		// (get) Token: 0x06012BDD RID: 76765 RVA: 0x00079608 File Offset: 0x00077808
		[Token(Token = "0x170027C4")]
		public bool IsDownloading
		{
			[Token(Token = "0x6012BDD")]
			[Address(RVA = "0x1ED635C", Offset = "0x1ED635C", VA = "0x1ED635C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170027C5 RID: 10181
		// (get) Token: 0x06012BDE RID: 76766 RVA: 0x00079620 File Offset: 0x00077820
		[Token(Token = "0x170027C5")]
		private bool IsSuccess
		{
			[Token(Token = "0x6012BDE")]
			[Address(RVA = "0x1ED637C", Offset = "0x1ED637C", VA = "0x1ED637C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06012BDF RID: 76767 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BDF")]
		[Address(RVA = "0x1ED639C", Offset = "0x1ED639C", VA = "0x1ED639C")]
		public AreaDownloader(AreaDownloadManager manager)
		{
		}

		// Token: 0x06012BE0 RID: 76768 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BE0")]
		[Address(RVA = "0x1ED6440", Offset = "0x1ED6440", VA = "0x1ED6440")]
		public void Download(int areaIdToDownload, bool prioritize = false)
		{
		}

		// Token: 0x06012BE1 RID: 76769 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BE1")]
		[Address(RVA = "0x1ED6C58", Offset = "0x1ED6C58", VA = "0x1ED6C58")]
		public void PrioritizeDownload()
		{
		}

		// Token: 0x06012BE2 RID: 76770 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BE2")]
		[Address(RVA = "0x1ED6D7C", Offset = "0x1ED6D7C", VA = "0x1ED6D7C")]
		private void OnAreaBundleSaveCompleted(bool downloaded, string eTag)
		{
		}

		// Token: 0x06012BE3 RID: 76771 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BE3")]
		[Address(RVA = "0x1ED6DF4", Offset = "0x1ED6DF4", VA = "0x1ED6DF4")]
		private void OnExtraBundleSaveCompleted(bool downloaded, string eTag)
		{
		}

		// Token: 0x06012BE4 RID: 76772 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BE4")]
		[Address(RVA = "0x1ED6D90", Offset = "0x1ED6D90", VA = "0x1ED6D90")]
		private void OnFileSaveCompleted()
		{
		}

		// Token: 0x06012BE5 RID: 76773 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012BE5")]
		[Address(RVA = "0x1ED696C", Offset = "0x1ED696C", VA = "0x1ED696C")]
		private FileDownloadSettings GetAreaFileDownloadSettings()
		{
			return null;
		}

		// Token: 0x06012BE6 RID: 76774 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012BE6")]
		[Address(RVA = "0x1ED6BF0", Offset = "0x1ED6BF0", VA = "0x1ED6BF0")]
		private FileDownloadSettings GetExtraFileDownloadSettings()
		{
			return null;
		}

		// Token: 0x06012BE7 RID: 76775 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BE7")]
		[Address(RVA = "0x1ED6FE8", Offset = "0x1ED6FE8", VA = "0x1ED6FE8")]
		public static void CreateDirectory()
		{
		}

		// Token: 0x06012BE8 RID: 76776 RVA: 0x00079638 File Offset: 0x00077838
		[Token(Token = "0x6012BE8")]
		[Address(RVA = "0x1ED6910", Offset = "0x1ED6910", VA = "0x1ED6910")]
		private static bool IsBundleExistInFileSystem(string bundleName)
		{
			return default(bool);
		}

		// Token: 0x06012BE9 RID: 76777 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012BE9")]
		[Address(RVA = "0x1ED714C", Offset = "0x1ED714C", VA = "0x1ED714C")]
		public static HashSet<string> GetDownloadedAreaBundles()
		{
			return null;
		}

		// Token: 0x06012BEA RID: 76778 RVA: 0x00079650 File Offset: 0x00077850
		[Token(Token = "0x6012BEA")]
		[Address(RVA = "0x1ED7414", Offset = "0x1ED7414", VA = "0x1ED7414")]
		private static bool HasExtraBundleOfAreaFile(string areaFileName, string[] downloadedFiles)
		{
			return default(bool);
		}

		// Token: 0x06012BEB RID: 76779 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012BEB")]
		[Address(RVA = "0x1ED72A4", Offset = "0x1ED72A4", VA = "0x1ED72A4")]
		private static string[] GetFilesInAssetBundlesFolder()
		{
			return null;
		}

		// Token: 0x06012BEC RID: 76780 RVA: 0x00079668 File Offset: 0x00077868
		[Token(Token = "0x6012BEC")]
		[Address(RVA = "0x1ED7598", Offset = "0x1ED7598", VA = "0x1ED7598")]
		public static bool IsAreaAndExtraBundleExistInFileSystem(int areaId)
		{
			return default(bool);
		}

		// Token: 0x06012BED RID: 76781 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012BED")]
		[Address(RVA = "0x1ED7078", Offset = "0x1ED7078", VA = "0x1ED7078")]
		public static string GetPersistentBundlePath(string bundleName)
		{
			return null;
		}

		// Token: 0x06012BEE RID: 76782 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012BEE")]
		[Address(RVA = "0x1ED67BC", Offset = "0x1ED67BC", VA = "0x1ED67BC")]
		public static string GetAreaBundleName(int areaId)
		{
			return null;
		}

		// Token: 0x06012BEF RID: 76783 RVA: 0x00079680 File Offset: 0x00077880
		[Token(Token = "0x6012BEF")]
		[Address(RVA = "0x1ED7620", Offset = "0x1ED7620", VA = "0x1ED7620")]
		private static int GetVersion(int areaId)
		{
			return 0;
		}

		// Token: 0x06012BF0 RID: 76784 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012BF0")]
		[Address(RVA = "0x1ED6B20", Offset = "0x1ED6B20", VA = "0x1ED6B20")]
		public static string GetExtraBundleName(int areaId)
		{
			return null;
		}

		// Token: 0x06012BF1 RID: 76785 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BF1")]
		[Address(RVA = "0x1ED7684", Offset = "0x1ED7684", VA = "0x1ED7684")]
		public static void CopyAreaFromStreamingAssets(int areaId, bool onlyAreaRequired = false)
		{
		}

		// Token: 0x06012BF2 RID: 76786 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BF2")]
		[Address(RVA = "0x1ED77B4", Offset = "0x1ED77B4", VA = "0x1ED77B4")]
		public static void DeleteAreaFromFileSystem(int areaId)
		{
		}

		// Token: 0x06012BF4 RID: 76788 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BF4")]
		[Address(RVA = "0x1ED7AE0", Offset = "0x1ED7AE0", VA = "0x1ED7AE0")]
		private void <Download>b__25_0()
		{
		}

		// Token: 0x06012BF5 RID: 76789 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BF5")]
		[Address(RVA = "0x1ED7AEC", Offset = "0x1ED7AEC", VA = "0x1ED7AEC")]
		private void <Download>b__25_1()
		{
		}

		// Token: 0x06012BF6 RID: 76790 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BF6")]
		[Address(RVA = "0x1ED7AF8", Offset = "0x1ED7AF8", VA = "0x1ED7AF8")]
		private void <Download>b__25_2()
		{
		}

		// Token: 0x06012BF7 RID: 76791 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BF7")]
		[Address(RVA = "0x1ED7B04", Offset = "0x1ED7B04", VA = "0x1ED7B04")]
		private void <Download>b__25_3()
		{
		}

		// Token: 0x0400EC12 RID: 60434
		[Token(Token = "0x400EC12")]
		public const string AreaDownloadUrl = "https://contents.prod.rylmtch.com/asset-bundles/area/android/";

		// Token: 0x0400EC13 RID: 60435
		[Token(Token = "0x400EC13")]
		private const string AreaPrefix = "area";

		// Token: 0x0400EC14 RID: 60436
		[Token(Token = "0x400EC14")]
		private const string ExtraPrefix = "extra";

		// Token: 0x0400EC15 RID: 60437
		[Token(Token = "0x400EC15")]
		private const string BundleSuffix = ".ab";

		// Token: 0x0400EC16 RID: 60438
		[Token(Token = "0x400EC16")]
		private const string VersionPrefix = "_v";

		// Token: 0x0400EC17 RID: 60439
		[Token(Token = "0x400EC17")]
		[FieldOffset(Offset = "0x0")]
		public static readonly string AreaAssetBundlesDirectory;

		// Token: 0x0400EC18 RID: 60440
		[Token(Token = "0x400EC18")]
		[FieldOffset(Offset = "0x10")]
		private readonly AreaDownloadManager manager;

		// Token: 0x0400EC19 RID: 60441
		[Token(Token = "0x400EC19")]
		[FieldOffset(Offset = "0x18")]
		private readonly FileDownloadManager fileDownloadManager;

		// Token: 0x0400EC1A RID: 60442
		[Token(Token = "0x400EC1A")]
		[FieldOffset(Offset = "0x20")]
		private int areaDownloadId;

		// Token: 0x0400EC1B RID: 60443
		[Token(Token = "0x400EC1B")]
		[FieldOffset(Offset = "0x24")]
		private int extraDownloadId;

		// Token: 0x0400EC1C RID: 60444
		[Token(Token = "0x400EC1C")]
		[FieldOffset(Offset = "0x28")]
		private bool isAreaDownloadSuccess;

		// Token: 0x0400EC1D RID: 60445
		[Token(Token = "0x400EC1D")]
		[FieldOffset(Offset = "0x29")]
		private bool isExtraDownloadSuccess;

		// Token: 0x0400EC1E RID: 60446
		[Token(Token = "0x400EC1E")]
		[FieldOffset(Offset = "0x2A")]
		private bool isAreaDownloading;

		// Token: 0x0400EC1F RID: 60447
		[Token(Token = "0x400EC1F")]
		[FieldOffset(Offset = "0x2B")]
		private bool isExtraDownloading;

		// Token: 0x0400EC20 RID: 60448
		[Token(Token = "0x400EC20")]
		[FieldOffset(Offset = "0x2C")]
		private bool isAreaQueuedForDownload;

		// Token: 0x0400EC21 RID: 60449
		[Token(Token = "0x400EC21")]
		[FieldOffset(Offset = "0x2D")]
		private bool isExtraQueuedForDownload;

		// Token: 0x0400EC22 RID: 60450
		[Token(Token = "0x400EC22")]
		[FieldOffset(Offset = "0x30")]
		public Action<bool> onComplete;

		// Token: 0x0400EC23 RID: 60451
		[Token(Token = "0x400EC23")]
		[FieldOffset(Offset = "0x38")]
		public int areaId;

		// Token: 0x0200257C RID: 9596
		[Token(Token = "0x200257C")]
		private sealed class <>c__DisplayClass35_0
		{
			// Token: 0x06012BF8 RID: 76792 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012BF8")]
			[Address(RVA = "0x1ED7590", Offset = "0x1ED7590", VA = "0x1ED7590")]
			public <>c__DisplayClass35_0()
			{
			}

			// Token: 0x06012BF9 RID: 76793 RVA: 0x00079698 File Offset: 0x00077898
			[Token(Token = "0x6012BF9")]
			[Address(RVA = "0x1ED7B10", Offset = "0x1ED7B10", VA = "0x1ED7B10")]
			internal bool <HasExtraBundleOfAreaFile>b__0(string t)
			{
				return default(bool);
			}

			// Token: 0x0400EC24 RID: 60452
			[Token(Token = "0x400EC24")]
			[FieldOffset(Offset = "0x10")]
			public string extraFileName;
		}
	}
}
