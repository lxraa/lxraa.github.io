﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002341 RID: 9025
	[Token(Token = "0x2002341")]
	public struct AskLifeRequest : IFlatbufferObject
	{
		// Token: 0x17001ECF RID: 7887
		// (get) Token: 0x06010B9D RID: 68509 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001ECF")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B9D")]
			[Address(RVA = "0x2143500", Offset = "0x2143500", VA = "0x2143500", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B9E RID: 68510 RVA: 0x00060000 File Offset: 0x0005E200
		[Token(Token = "0x6010B9E")]
		[Address(RVA = "0x2143508", Offset = "0x2143508", VA = "0x2143508")]
		public static AskLifeRequest GetRootAsAskLifeRequest(ByteBuffer _bb)
		{
			return default(AskLifeRequest);
		}

		// Token: 0x06010B9F RID: 68511 RVA: 0x00060018 File Offset: 0x0005E218
		[Token(Token = "0x6010B9F")]
		[Address(RVA = "0x2143514", Offset = "0x2143514", VA = "0x2143514")]
		public static AskLifeRequest GetRootAsAskLifeRequest(ByteBuffer _bb, AskLifeRequest obj)
		{
			return default(AskLifeRequest);
		}

		// Token: 0x06010BA0 RID: 68512 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BA0")]
		[Address(RVA = "0x21435C4", Offset = "0x21435C4", VA = "0x21435C4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010BA1 RID: 68513 RVA: 0x00060030 File Offset: 0x0005E230
		[Token(Token = "0x6010BA1")]
		[Address(RVA = "0x214358C", Offset = "0x214358C", VA = "0x214358C")]
		public AskLifeRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(AskLifeRequest);
		}

		// Token: 0x17001ED0 RID: 7888
		// (get) Token: 0x06010BA2 RID: 68514 RVA: 0x00060048 File Offset: 0x0005E248
		[Token(Token = "0x17001ED0")]
		public ChatProfile? OwnerChatProfile
		{
			[Token(Token = "0x6010BA2")]
			[Address(RVA = "0x21435D4", Offset = "0x21435D4", VA = "0x21435D4")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001ED1 RID: 7889
		// (get) Token: 0x06010BA3 RID: 68515 RVA: 0x00060060 File Offset: 0x0005E260
		[Token(Token = "0x17001ED1")]
		public SpecialChatProfile? OwnerSpecialChatProfile
		{
			[Token(Token = "0x6010BA3")]
			[Address(RVA = "0x21436C4", Offset = "0x21436C4", VA = "0x21436C4")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BA4 RID: 68516 RVA: 0x00060078 File Offset: 0x0005E278
		[Token(Token = "0x6010BA4")]
		[Address(RVA = "0x2140878", Offset = "0x2140878", VA = "0x2140878")]
		public static Offset<AskLifeRequest> CreateAskLifeRequest(FlatBufferBuilder builder, [Optional] Offset<ChatProfile> owner_chat_profileOffset, [Optional] Offset<SpecialChatProfile> owner_special_chat_profileOffset)
		{
			return default(Offset<AskLifeRequest>);
		}

		// Token: 0x06010BA5 RID: 68517 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BA5")]
		[Address(RVA = "0x2143830", Offset = "0x2143830", VA = "0x2143830")]
		public static void StartAskLifeRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010BA6 RID: 68518 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BA6")]
		[Address(RVA = "0x21437A4", Offset = "0x21437A4", VA = "0x21437A4")]
		public static void AddOwnerChatProfile(FlatBufferBuilder builder, Offset<ChatProfile> ownerChatProfileOffset)
		{
		}

		// Token: 0x06010BA7 RID: 68519 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BA7")]
		[Address(RVA = "0x2143784", Offset = "0x2143784", VA = "0x2143784")]
		public static void AddOwnerSpecialChatProfile(FlatBufferBuilder builder, Offset<SpecialChatProfile> ownerSpecialChatProfileOffset)
		{
		}

		// Token: 0x06010BA8 RID: 68520 RVA: 0x00060090 File Offset: 0x0005E290
		[Token(Token = "0x6010BA8")]
		[Address(RVA = "0x21437C4", Offset = "0x21437C4", VA = "0x21437C4")]
		public static Offset<AskLifeRequest> EndAskLifeRequest(FlatBufferBuilder builder)
		{
			return default(Offset<AskLifeRequest>);
		}

		// Token: 0x0400E625 RID: 58917
		[Token(Token = "0x400E625")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
