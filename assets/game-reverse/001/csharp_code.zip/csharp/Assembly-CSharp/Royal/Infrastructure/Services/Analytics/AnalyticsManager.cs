﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Il2CppDummyDll;
using Royal.Infrastructure.Contexts;
using Royal.Infrastructure.Contexts.Units;
using Royal.Infrastructure.Services.Analytics.Event;
using Royal.Infrastructure.Services.Analytics.Marketing;
using Royal.Infrastructure.Services.Backend.Http;
using Royal.Infrastructure.Services.Backend.Http.Command.Friends;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Infrastructure.Services.Native.Purchase;
using Royal.Infrastructure.Services.NetworkMetrics;
using Royal.Player.Configs;
using Royal.Player.Context.Data;
using Royal.Player.Context.Data.Session;
using Royal.Player.Context.Units;
using Royal.Scenes.Game.Mechanics.Boosters;
using Royal.Scenes.Home.Context.Units.Area.Config;
using Royal.Scenes.Home.Ui.Dialogs.Madness.Multiplier;
using Royal.Scenes.Home.Ui.Dialogs.TrainJourney.Scripts;
using Royal.Scenes.Home.Ui.Sections.Shop.Package;
using Royal.Scenes.Start.Context.Units.Audio;
using Royal.Scenes.Start.Context.Units.Haptic;
using UnityEngine;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x0200258E RID: 9614
	[Token(Token = "0x200258E")]
	public class AnalyticsManager : IContextBehaviour, IContextUnit
	{
		// Token: 0x170027D3 RID: 10195
		// (get) Token: 0x06012C72 RID: 76914 RVA: 0x000798F0 File Offset: 0x00077AF0
		[Token(Token = "0x170027D3")]
		public int Id
		{
			[Token(Token = "0x6012C72")]
			[Address(RVA = "0x21B897C", Offset = "0x21B897C", VA = "0x21B897C", Slot = "5")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06012C73 RID: 76915 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C73")]
		[Address(RVA = "0x21B8984", Offset = "0x21B8984", VA = "0x21B8984", Slot = "6")]
		public void Bind()
		{
		}

		// Token: 0x06012C74 RID: 76916 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C74")]
		[Address(RVA = "0x21B935C", Offset = "0x21B935C", VA = "0x21B935C", Slot = "4")]
		public void ManualUpdate()
		{
		}

		// Token: 0x06012C75 RID: 76917 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C75")]
		[Address(RVA = "0x21B96E4", Offset = "0x21B96E4", VA = "0x21B96E4")]
		private void OnAppFocusIn()
		{
		}

		// Token: 0x06012C76 RID: 76918 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C76")]
		[Address(RVA = "0x21B9794", Offset = "0x21B9794", VA = "0x21B9794")]
		private void OnAppFocusOut()
		{
		}

		// Token: 0x06012C77 RID: 76919 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C77")]
		[Address(RVA = "0x21BC278", Offset = "0x21BC278", VA = "0x21BC278")]
		private void OnAppQuit()
		{
		}

		// Token: 0x06012C78 RID: 76920 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C78")]
		[Address(RVA = "0x21B8E88", Offset = "0x21B8E88", VA = "0x21B8E88")]
		private IEnumerator CheckForInit()
		{
			return null;
		}

		// Token: 0x06012C79 RID: 76921 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C79")]
		[Address(RVA = "0x21BC29C", Offset = "0x21BC29C", VA = "0x21BC29C")]
		private static void TrySetFirebaseConsentData()
		{
		}

		// Token: 0x06012C7A RID: 76922 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C7A")]
		[Address(RVA = "0x21BC34C", Offset = "0x21BC34C", VA = "0x21BC34C")]
		public void UpdateUserId()
		{
		}

		// Token: 0x06012C7B RID: 76923 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C7B")]
		[Address(RVA = "0x21BC468", Offset = "0x21BC468", VA = "0x21BC468")]
		public void ClearEvents()
		{
		}

		// Token: 0x06012C7C RID: 76924 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C7C")]
		[Address(RVA = "0x21BC484", Offset = "0x21BC484", VA = "0x21BC484")]
		private static string GetInstallId()
		{
			return null;
		}

		// Token: 0x06012C7D RID: 76925 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C7D")]
		[Address(RVA = "0x21BC59C", Offset = "0x21BC59C", VA = "0x21BC59C")]
		public void LevelStart(int origin)
		{
		}

		// Token: 0x06012C7E RID: 76926 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C7E")]
		[Address(RVA = "0x21BDEF4", Offset = "0x21BDEF4", VA = "0x21BDEF4")]
		public void LevelEnd()
		{
		}

		// Token: 0x06012C7F RID: 76927 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C7F")]
		[Address(RVA = "0x21BE328", Offset = "0x21BE328", VA = "0x21BE328")]
		public void SkipStoryLevel()
		{
		}

		// Token: 0x06012C80 RID: 76928 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C80")]
		[Address(RVA = "0x21BE7C4", Offset = "0x21BE7C4", VA = "0x21BE7C4")]
		public void BatteryUsage(int batteryAtStart, int batteryAtEnd, int levelStartCount, int levelStartCountLowPower, int frameRate, int passedMinutes)
		{
		}

		// Token: 0x06012C81 RID: 76929 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C81")]
		[Address(RVA = "0x21BEC48", Offset = "0x21BEC48", VA = "0x21BEC48")]
		public void LevelEndReward(MultiplierDto multiplierDto)
		{
		}

		// Token: 0x06012C82 RID: 76930 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C82")]
		[Address(RVA = "0x21B990C", Offset = "0x21B990C", VA = "0x21B990C")]
		private EventData PrepareLevelEndEvent(UserActiveLevelData ald)
		{
			return null;
		}

		// Token: 0x06012C83 RID: 76931 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C83")]
		[Address(RVA = "0x21BE3B0", Offset = "0x21BE3B0", VA = "0x21BE3B0")]
		private EventData PrepareSkippedStoryLevelEndEvent(UserActiveLevelData ald)
		{
			return null;
		}

		// Token: 0x06012C84 RID: 76932 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C84")]
		[Address(RVA = "0x21C0C6C", Offset = "0x21C0C6C", VA = "0x21C0C6C")]
		public void LevelRestore()
		{
		}

		// Token: 0x06012C85 RID: 76933 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C85")]
		[Address(RVA = "0x21C10C4", Offset = "0x21C10C4", VA = "0x21C10C4")]
		public void LevelRestoreAppKill(int movesLeft, float killDuration, long batteryLevel)
		{
		}

		// Token: 0x06012C86 RID: 76934 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C86")]
		[Address(RVA = "0x21BDFA8", Offset = "0x21BDFA8", VA = "0x21BDFA8")]
		private void BonusLevel()
		{
		}

		// Token: 0x06012C87 RID: 76935 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C87")]
		[Address(RVA = "0x21B93B0", Offset = "0x21B93B0", VA = "0x21B93B0")]
		private void SessionEvent(int timeSpent)
		{
		}

		// Token: 0x06012C88 RID: 76936 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C88")]
		[Address(RVA = "0x21C1378", Offset = "0x21C1378", VA = "0x21C1378")]
		public void Spending(SpendingData spendingData, InventoryPackage inventoryPackage, int egoWarningStep)
		{
		}

		// Token: 0x06012C89 RID: 76937 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C89")]
		[Address(RVA = "0x21C1A7C", Offset = "0x21C1A7C", VA = "0x21C1A7C")]
		public void SendMarketingPurchaseEvent(PurchaseProduct product)
		{
		}

		// Token: 0x06012C8A RID: 76938 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C8A")]
		[Address(RVA = "0x21C1AC8", Offset = "0x21C1AC8", VA = "0x21C1AC8")]
		public void PurchaseSuccess(ShopPackageConfig config, string purchaseType, string transactionId, bool isSandbox, bool isVerificationNeeded, bool isRoyalFavorFromMoreLives = false)
		{
		}

		// Token: 0x06012C8B RID: 76939 RVA: 0x00079908 File Offset: 0x00077B08
		[Token(Token = "0x6012C8B")]
		[Address(RVA = "0x21C2F00", Offset = "0x21C2F00", VA = "0x21C2F00")]
		private int GetOfferType(ShopPackageConfig config, bool isRoyalFavorFromMoreLives)
		{
			return 0;
		}

		// Token: 0x06012C8C RID: 76940 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C8C")]
		[Address(RVA = "0x21C33D0", Offset = "0x21C33D0", VA = "0x21C33D0")]
		private static string GetOfferIdParameter(ShopPackageConfig config)
		{
			return null;
		}

		// Token: 0x06012C8D RID: 76941 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C8D")]
		[Address(RVA = "0x21C355C", Offset = "0x21C355C", VA = "0x21C355C")]
		public void VerificationFinish(string status, string transactionId, bool isSandbox)
		{
		}

		// Token: 0x06012C8E RID: 76942 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C8E")]
		[Address(RVA = "0x21C38B4", Offset = "0x21C38B4", VA = "0x21C38B4")]
		public void PurchaseFail(ShopPackageConfig config, string purchaseType, PurchaseStatus status, string errorCode, bool isRoyalFavorFromMoreLives = false)
		{
		}

		// Token: 0x06012C8F RID: 76943 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C8F")]
		[Address(RVA = "0x21C3FB0", Offset = "0x21C3FB0", VA = "0x21C3FB0")]
		public void BoosterUse(BoosterType boosterType)
		{
		}

		// Token: 0x06012C90 RID: 76944 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C90")]
		[Address(RVA = "0x21C43AC", Offset = "0x21C43AC", VA = "0x21C43AC")]
		public void Tasks(int areaId, AreaConfig config, AreaTaskConfig taskConfig, int starCost)
		{
		}

		// Token: 0x06012C91 RID: 76945 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C91")]
		[Address(RVA = "0x21C49CC", Offset = "0x21C49CC", VA = "0x21C49CC")]
		public void SocialConnection(string typePrefix, bool isConnect, int triggerId, long oldUserId, int oldUserLevel, string platformId, int timeOffset)
		{
		}

		// Token: 0x06012C92 RID: 76946 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C92")]
		[Address(RVA = "0x21C4B04", Offset = "0x21C4B04", VA = "0x21C4B04")]
		public void SocialConnect(string typeString, long oldUserId, int oldUserLevel, string trigger, string platformId, int timeOffset)
		{
		}

		// Token: 0x06012C93 RID: 76947 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C93")]
		[Address(RVA = "0x21C4EF0", Offset = "0x21C4EF0", VA = "0x21C4EF0")]
		public void ConsentGiven()
		{
		}

		// Token: 0x06012C94 RID: 76948 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C94")]
		[Address(RVA = "0x21C4F94", Offset = "0x21C4F94", VA = "0x21C4F94")]
		public void PrivacyConsent(string scene, string action, [Optional] string category, [Optional] string service, [Optional] string st1, long sessionCount = 0L)
		{
		}

		// Token: 0x06012C95 RID: 76949 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C95")]
		[Address(RVA = "0x21C5428", Offset = "0x21C5428", VA = "0x21C5428")]
		public void TermsOfUse(long version, string action, string type)
		{
		}

		// Token: 0x06012C96 RID: 76950 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C96")]
		[Address(RVA = "0x21C56D8", Offset = "0x21C56D8", VA = "0x21C56D8")]
		public void AgePopup(int age, string action)
		{
		}

		// Token: 0x06012C97 RID: 76951 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C97")]
		[Address(RVA = "0x21C58E8", Offset = "0x21C58E8", VA = "0x21C58E8")]
		public void SupportTicket()
		{
		}

		// Token: 0x06012C98 RID: 76952 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C98")]
		[Address(RVA = "0x21C5B68", Offset = "0x21C5B68", VA = "0x21C5B68")]
		public void EpisodeChestClaim(InventoryPackage package)
		{
		}

		// Token: 0x06012C99 RID: 76953 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C99")]
		[Address(RVA = "0x21C60C8", Offset = "0x21C60C8", VA = "0x21C60C8")]
		public void NThousandRewardClaim(InventoryPackage package)
		{
		}

		// Token: 0x06012C9A RID: 76954 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C9A")]
		[Address(RVA = "0x21C6418", Offset = "0x21C6418", VA = "0x21C6418")]
		public void RefreshProgress(long oldUserId, int oldUserLevel, int trigger)
		{
		}

		// Token: 0x06012C9B RID: 76955 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C9B")]
		[Address(RVA = "0x21C66C8", Offset = "0x21C66C8", VA = "0x21C66C8")]
		public void TeamCreate(bool isCreate, long id, string name, bool type, string desc, int logo, int level, int crown)
		{
		}

		// Token: 0x06012C9C RID: 76956 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C9C")]
		[Address(RVA = "0x21C6C4C", Offset = "0x21C6C4C", VA = "0x21C6C4C")]
		public void TeamJoin(long teamId, string name, string joinType, string activity)
		{
		}

		// Token: 0x06012C9D RID: 76957 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C9D")]
		[Address(RVA = "0x21C6F94", Offset = "0x21C6F94", VA = "0x21C6F94")]
		public void TeamLeave(long id, string name, string activity)
		{
		}

		// Token: 0x06012C9E RID: 76958 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C9E")]
		[Address(RVA = "0x21C7244", Offset = "0x21C7244", VA = "0x21C7244")]
		public void TeamKick(long id, string name, long kickedUser)
		{
		}

		// Token: 0x06012C9F RID: 76959 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C9F")]
		[Address(RVA = "0x21C74F4", Offset = "0x21C74F4", VA = "0x21C74F4")]
		public void LifeRequest(long id, string name, long askId)
		{
		}

		// Token: 0x06012CA0 RID: 76960 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA0")]
		[Address(RVA = "0x21C77A4", Offset = "0x21C77A4", VA = "0x21C77A4")]
		public void LifeHelp(long id, string name, long askId, int coin)
		{
		}

		// Token: 0x06012CA1 RID: 76961 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA1")]
		[Address(RVA = "0x21C7AEC", Offset = "0x21C7AEC", VA = "0x21C7AEC")]
		public void NameCreate(string name, string trigger)
		{
		}

		// Token: 0x06012CA2 RID: 76962 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA2")]
		[Address(RVA = "0x21C7CFC", Offset = "0x21C7CFC", VA = "0x21C7CFC")]
		public void NameChange(string name, string oldName)
		{
		}

		// Token: 0x06012CA3 RID: 76963 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA3")]
		[Address(RVA = "0x21C7F0C", Offset = "0x21C7F0C", VA = "0x21C7F0C")]
		public void Search(string query)
		{
		}

		// Token: 0x06012CA4 RID: 76964 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA4")]
		[Address(RVA = "0x21C80BC", Offset = "0x21C80BC", VA = "0x21C80BC")]
		public void LifeUse(int life, int scene)
		{
		}

		// Token: 0x06012CA5 RID: 76965 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA5")]
		[Address(RVA = "0x21C830C", Offset = "0x21C830C", VA = "0x21C830C")]
		public void CoLeaderEvents(string actionType, long coLeaderId)
		{
		}

		// Token: 0x06012CA6 RID: 76966 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA6")]
		[Address(RVA = "0x21C851C", Offset = "0x21C851C", VA = "0x21C851C")]
		public void ClosedRequestResponse(long teamId, string name, long requestingUser, bool accepted)
		{
		}

		// Token: 0x06012CA7 RID: 76967 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA7")]
		[Address(RVA = "0x21C88A4", Offset = "0x21C88A4", VA = "0x21C88A4")]
		public void AbTestEnter(string name, int groupId, int timeOffset)
		{
		}

		// Token: 0x06012CA8 RID: 76968 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA8")]
		[Address(RVA = "0x21C8AC0", Offset = "0x21C8AC0", VA = "0x21C8AC0")]
		public void SaveAbTestEnter(string name, int groupId, int timeOffset)
		{
		}

		// Token: 0x06012CA9 RID: 76969 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CA9")]
		[Address(RVA = "0x21C8D54", Offset = "0x21C8D54", VA = "0x21C8D54")]
		public void SendSavedAbTestEnter()
		{
		}

		// Token: 0x06012CAA RID: 76970 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CAA")]
		[Address(RVA = "0x21C8EDC", Offset = "0x21C8EDC", VA = "0x21C8EDC")]
		public void RlClaim(long groupId, int rank, int coins, int hammers)
		{
		}

		// Token: 0x06012CAB RID: 76971 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CAB")]
		[Address(RVA = "0x21C92E0", Offset = "0x21C92E0", VA = "0x21C92E0")]
		public void RlEnter()
		{
		}

		// Token: 0x06012CAC RID: 76972 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CAC")]
		[Address(RVA = "0x21C9494", Offset = "0x21C9494", VA = "0x21C9494")]
		public void RlStepClaim(int step, int target, InventoryPackage package)
		{
		}

		// Token: 0x06012CAD RID: 76973 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CAD")]
		[Address(RVA = "0x21C99F0", Offset = "0x21C99F0", VA = "0x21C99F0")]
		public void LifeHack(int hackLevel)
		{
		}

		// Token: 0x06012CAE RID: 76974 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CAE")]
		[Address(RVA = "0x21C9B60", Offset = "0x21C9B60", VA = "0x21C9B60")]
		public void ShopOpen(int timeSpent, bool moreOffersClicked, string purchaseType)
		{
		}

		// Token: 0x06012CAF RID: 76975 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CAF")]
		[Address(RVA = "0x21C9E1C", Offset = "0x21C9E1C", VA = "0x21C9E1C")]
		public void GoldenOfferAction(int scene, int action, string offerType, int coinPrice, int offerId)
		{
		}

		// Token: 0x06012CB0 RID: 76976 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB0")]
		[Address(RVA = "0x21CA204", Offset = "0x21CA204", VA = "0x21CA204")]
		public void KcClaim(int kcId, long groupId, int rank, int trophy, InventoryPackage package)
		{
		}

		// Token: 0x06012CB1 RID: 76977 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB1")]
		[Address(RVA = "0x21CA734", Offset = "0x21CA734", VA = "0x21CA734")]
		public void KcFinish(int kcId, long groupId, int rank, int trophy, InventoryPackage package)
		{
		}

		// Token: 0x06012CB2 RID: 76978 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB2")]
		[Address(RVA = "0x21CAC64", Offset = "0x21CAC64", VA = "0x21CAC64")]
		public void KcEnter(int kcId, long groupId, int unlimitedLivesMin)
		{
		}

		// Token: 0x06012CB3 RID: 76979 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB3")]
		[Address(RVA = "0x21CAF14", Offset = "0x21CAF14", VA = "0x21CAF14")]
		public void TbClaim(int tbId, long groupId, int rank, long teamId, InventoryPackage package, int userRank, int teamShield, int userShield)
		{
		}

		// Token: 0x06012CB4 RID: 76980 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB4")]
		[Address(RVA = "0x21CB624", Offset = "0x21CB624", VA = "0x21CB624")]
		public void TbFinish(int tbId, long groupId, int rank, long teamId, InventoryPackage package, int userRank, int teamShield, int userShield)
		{
		}

		// Token: 0x06012CB5 RID: 76981 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB5")]
		[Address(RVA = "0x21CBD34", Offset = "0x21CBD34", VA = "0x21CBD34")]
		public void MadnessClaim(int type, long eventId, int step, int target, InventoryPackage package)
		{
		}

		// Token: 0x06012CB6 RID: 76982 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB6")]
		[Address(RVA = "0x21CC264", Offset = "0x21CC264", VA = "0x21CC264")]
		public void OfferClaim(long eventId, int step, int price, InventoryPackage package, int type, string transactionId, int segment = -1)
		{
		}

		// Token: 0x06012CB7 RID: 76983 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB7")]
		[Address(RVA = "0x21CCA28", Offset = "0x21CCA28", VA = "0x21CCA28")]
		public void OfferOpen(long eventId, int trigger, int type, int step, [Optional] InventoryPackage inventoryPackage)
		{
		}

		// Token: 0x06012CB8 RID: 76984 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB8")]
		[Address(RVA = "0x21CCECC", Offset = "0x21CCECC", VA = "0x21CCECC")]
		public void PassStage(int passType, long eventId, int stage, SpecialRewardTypes specialRewardType)
		{
		}

		// Token: 0x06012CB9 RID: 76985 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CB9")]
		[Address(RVA = "0x21CD214", Offset = "0x21CD214", VA = "0x21CD214")]
		public void PassClaim(int passType, long eventId, int stage, int claimStage, int safeStage, bool isFree, SpecialRewardTypes specialRewardType, [Optional] InventoryPackage package, bool isPremium = false)
		{
		}

		// Token: 0x06012CBA RID: 76986 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CBA")]
		[Address(RVA = "0x21CD908", Offset = "0x21CD908", VA = "0x21CD908")]
		public void PassPurchaseOpen(int passType, long eventId, int stage, int safeStage, string trigger)
		{
		}

		// Token: 0x06012CBB RID: 76987 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CBB")]
		[Address(RVA = "0x21CDC68", Offset = "0x21CDC68", VA = "0x21CDC68")]
		public void PassPurchaseSuccess(int passType, long eventId, int stage, int safeStage, long giftId, string trigger)
		{
		}

		// Token: 0x06012CBC RID: 76988 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CBC")]
		[Address(RVA = "0x21CE060", Offset = "0x21CE060", VA = "0x21CE060")]
		public void PassGiftClaim(long teamId, string teamName, long sender, int passType, long eventId, long giftId, int coin)
		{
		}

		// Token: 0x06012CBD RID: 76989 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CBD")]
		[Address(RVA = "0x21CE584", Offset = "0x21CE584", VA = "0x21CE584")]
		public void PremiumPassEnterAction(int passType, long eventId, int action)
		{
		}

		// Token: 0x06012CBE RID: 76990 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CBE")]
		[Address(RVA = "0x21CE834", Offset = "0x21CE834", VA = "0x21CE834")]
		public void OfferGiftClaim(long teamId, string teamName, long sender, long eventId, long giftId, int unlimitedLivesInMinutes, [Optional] InventoryPackage package, int type = 1)
		{
		}

		// Token: 0x06012CBF RID: 76991 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CBF")]
		[Address(RVA = "0x21CEE18", Offset = "0x21CEE18", VA = "0x21CEE18")]
		public void PpClaim(int ppType, int ppId, int segment, int step, int stepGoal, int candyCount, InventoryPackage package)
		{
		}

		// Token: 0x06012CC0 RID: 76992 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC0")]
		[Address(RVA = "0x21CF48C", Offset = "0x21CF48C", VA = "0x21CF48C")]
		public void PpFinish(int ppType, int ppId, int segment, int step, int stepGoal, int candyCount, InventoryPackage package)
		{
		}

		// Token: 0x06012CC1 RID: 76993 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC1")]
		[Address(RVA = "0x21CFB00", Offset = "0x21CFB00", VA = "0x21CFB00")]
		public void LrEnter(int lrId, int enterDay, long groupId, EventInteractionOrigin eventInteractionOrigin, int unlimitedLife, int playerCount, int maxScore, int stage = -1)
		{
		}

		// Token: 0x06012CC2 RID: 76994 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC2")]
		[Address(RVA = "0x21D011C", Offset = "0x21D011C", VA = "0x21D011C")]
		public void LrClaim(int lrId, int enterDay, long groupId, int rank, InventoryPackage package, int score, EventInteractionOrigin origin, int stage = -1)
		{
		}

		// Token: 0x06012CC3 RID: 76995 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC3")]
		[Address(RVA = "0x21D0880", Offset = "0x21D0880", VA = "0x21D0880")]
		public void LrFinish(int lrId, int enterDay, long groupId, int playerCount, string otherScores, int rank, int score, int stage = -1)
		{
		}

		// Token: 0x06012CC4 RID: 76996 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC4")]
		[Address(RVA = "0x21D0E54", Offset = "0x21D0E54", VA = "0x21D0E54")]
		public void PrEnter(int prId, int stage, long groupId, int playerCount, int maxScore, int unlimitedLife, EventInteractionOrigin origin)
		{
		}

		// Token: 0x06012CC5 RID: 76997 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC5")]
		[Address(RVA = "0x21D13C8", Offset = "0x21D13C8", VA = "0x21D13C8")]
		public void PrFinish(int prId, int stage, long groupId, int rank, int propellerCount, int playerCount, string otherScores)
		{
		}

		// Token: 0x06012CC6 RID: 76998 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC6")]
		[Address(RVA = "0x21D18E8", Offset = "0x21D18E8", VA = "0x21D18E8")]
		public void PrClaim(int prId, int stage, long groupId, int rank, int propellerCount, InventoryPackage package, EventInteractionOrigin origin)
		{
		}

		// Token: 0x06012CC7 RID: 76999 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC7")]
		[Address(RVA = "0x21D1FA4", Offset = "0x21D1FA4", VA = "0x21D1FA4")]
		public void SmEnter(int eventId, int step, long groupId, bool isFromPrelevel, int playerCount, int maxLevel)
		{
		}

		// Token: 0x06012CC8 RID: 77000 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC8")]
		[Address(RVA = "0x21D245C", Offset = "0x21D245C", VA = "0x21D245C")]
		public void SmFinish(int eventId, int step, long groupId, int rank, int levelCount, int streakCount, int playerCount, string otherStreaks)
		{
		}

		// Token: 0x06012CC9 RID: 77001 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CC9")]
		[Address(RVA = "0x21D2A20", Offset = "0x21D2A20", VA = "0x21D2A20")]
		public void SmClaim(int eventId, int step, long groupId, int rank, bool isFromPrelevel, int levelCount, int streakCount, InventoryPackage package)
		{
		}

		// Token: 0x06012CCA RID: 77002 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CCA")]
		[Address(RVA = "0x21D3168", Offset = "0x21D3168", VA = "0x21D3168")]
		public void SmStreakLost(int eventId, int step, long groupId, int rank, int streakCount)
		{
		}

		// Token: 0x06012CCB RID: 77003 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CCB")]
		[Address(RVA = "0x21D3550", Offset = "0x21D3550", VA = "0x21D3550")]
		public void BrClaim(int eventId, int brType, int step, int segment, int claimedStep, InventoryPackage package, int timeOffset)
		{
		}

		// Token: 0x06012CCC RID: 77004 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CCC")]
		[Address(RVA = "0x21D3B28", Offset = "0x21D3B28", VA = "0x21D3B28")]
		public void BrFinish(int eventId, int brType, int step, int segment, int balloonCount, int levelCount, int stepGoal)
		{
		}

		// Token: 0x06012CCD RID: 77005 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CCD")]
		[Address(RVA = "0x21D4050", Offset = "0x21D4050", VA = "0x21D4050")]
		public void BrStreakLost(int eventId, int brType, int step, int segment, int stepProgress, int balloonLost, int stepGoal)
		{
		}

		// Token: 0x06012CCE RID: 77006 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CCE")]
		[Address(RVA = "0x21D4578", Offset = "0x21D4578", VA = "0x21D4578")]
		public void WcEnter(int eventId, int score, int segment, int rank, int playerCount, string groupUserIds, int maxLevel)
		{
		}

		// Token: 0x06012CCF RID: 77007 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CCF")]
		[Address(RVA = "0x21D4A9C", Offset = "0x21D4A9C", VA = "0x21D4A9C")]
		public void WcClaim(int eventId, int score, int segment, int rank, int playerCount, string groupUserIds, int trigger, int maxLevel, int state, InventoryPackage package)
		{
		}

		// Token: 0x06012CD0 RID: 77008 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD0")]
		[Address(RVA = "0x21D51B0", Offset = "0x21D51B0", VA = "0x21D51B0")]
		public void WelcomeBackGiftClaim(int tier, int churnedPeriod, InventoryPackage package)
		{
		}

		// Token: 0x06012CD1 RID: 77009 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD1")]
		[Address(RVA = "0x21D55A8", Offset = "0x21D55A8", VA = "0x21D55A8")]
		public void EventReactivationEnter(int eventType)
		{
		}

		// Token: 0x06012CD2 RID: 77010 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD2")]
		[Address(RVA = "0x21D5718", Offset = "0x21D5718", VA = "0x21D5718")]
		public void EventReactivationPrevent(int eventType)
		{
		}

		// Token: 0x06012CD3 RID: 77011 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD3")]
		[Address(RVA = "0x21D5888", Offset = "0x21D5888", VA = "0x21D5888")]
		public void HtFinish(int eventId, int seedId, int step, int pickaxeCount, int pickaxeUsed, int gemsFound)
		{
		}

		// Token: 0x06012CD4 RID: 77012 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD4")]
		[Address(RVA = "0x21D5D08", Offset = "0x21D5D08", VA = "0x21D5D08")]
		public void HtClaim(int eventId, int seedId, int step, int claimedStep, InventoryPackage package)
		{
		}

		// Token: 0x06012CD5 RID: 77013 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD5")]
		[Address(RVA = "0x21D6238", Offset = "0x21D6238", VA = "0x21D6238")]
		public void CollectionClaim(string rewardId, List<int> newSilverCards, List<int> duplicateSilverCards, List<int> newGoldCards, List<int> duplicateGoldCards, int wildCardCount, int tokenCount, string trigger, int eventId, int silverTokenValue, int goldTokenValue)
		{
		}

		// Token: 0x06012CD6 RID: 77014 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD6")]
		[Address(RVA = "0x21D6ADC", Offset = "0x21D6ADC", VA = "0x21D6ADC")]
		public void WildCardUse(string rewardId, List<int> selectedCards)
		{
		}

		// Token: 0x06012CD7 RID: 77015 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD7")]
		[Address(RVA = "0x21D6D54", Offset = "0x21D6D54", VA = "0x21D6D54")]
		public void SetComplete(int setId, int lastClaimedCardId, InventoryPackage package)
		{
		}

		// Token: 0x06012CD8 RID: 77016 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD8")]
		[Address(RVA = "0x21D70B4", Offset = "0x21D70B4", VA = "0x21D70B4")]
		public void SetRewardClaim(int setId, InventoryPackage package)
		{
		}

		// Token: 0x06012CD9 RID: 77017 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CD9")]
		[Address(RVA = "0x21D7374", Offset = "0x21D7374", VA = "0x21D7374")]
		public void GiftMessageClaim(int messageId, SystemMessageType messageType, InventoryPackage package)
		{
		}

		// Token: 0x06012CDA RID: 77018 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CDA")]
		[Address(RVA = "0x21D776C", Offset = "0x21D776C", VA = "0x21D776C")]
		public void TtClaim(int ttId, long teamId, int segment, int step, int stepGoal, int teamWheelCount, int userWheelCount, int userRank, InventoryPackage package)
		{
		}

		// Token: 0x06012CDB RID: 77019 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CDB")]
		[Address(RVA = "0x21D7F18", Offset = "0x21D7F18", VA = "0x21D7F18")]
		public void TtFinish(int ttId, long teamId, int segment, int step, int stepGoal, int teamWheelCount, int userWheelCount, int userRank, InventoryPackage package)
		{
		}

		// Token: 0x06012CDC RID: 77020 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CDC")]
		[Address(RVA = "0x21D86C4", Offset = "0x21D86C4", VA = "0x21D86C4")]
		public void SocialPageLike(int type, int trigger, string action, int coin)
		{
		}

		// Token: 0x06012CDD RID: 77021 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CDD")]
		[Address(RVA = "0x21D8A0C", Offset = "0x21D8A0C", VA = "0x21D8A0C")]
		public void UserAction(string action, [Optional] string st1, [Optional] string st2)
		{
		}

		// Token: 0x06012CDE RID: 77022 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CDE")]
		[Address(RVA = "0x21D8CC4", Offset = "0x21D8CC4", VA = "0x21D8CC4")]
		public void SkillChangedAction(string newSkill, string oldSkill)
		{
		}

		// Token: 0x06012CDF RID: 77023 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CDF")]
		[Address(RVA = "0x21D8F7C", Offset = "0x21D8F7C", VA = "0x21D8F7C")]
		public void SrClaim(int srId, long groupId, int rank, int levelCount, bool isFromPrelevel, InventoryPackage package)
		{
		}

		// Token: 0x06012CE0 RID: 77024 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CE0")]
		[Address(RVA = "0x21D957C", Offset = "0x21D957C", VA = "0x21D957C")]
		public void SrEnter(int srId, long groupId, int maxLevel, int playerCount, bool isFromPrelevel)
		{
		}

		// Token: 0x06012CE1 RID: 77025 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CE1")]
		[Address(RVA = "0x21D999C", Offset = "0x21D999C", VA = "0x21D999C")]
		public void SrFinish(int srId, long groupId, int rank, int levelCount, int playerCount, string otherScores)
		{
		}

		// Token: 0x06012CE2 RID: 77026 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CE2")]
		[Address(RVA = "0x21D9E1C", Offset = "0x21D9E1C", VA = "0x21D9E1C")]
		public void InstallEvent([Optional] string installReferrer, [Optional] string facebookReferrer)
		{
		}

		// Token: 0x170027D4 RID: 10196
		// (get) Token: 0x06012CE3 RID: 77027 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012CE4 RID: 77028 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027D4")]
		public string AppsFlyerId
		{
			[Token(Token = "0x6012CE3")]
			[Address(RVA = "0x21DAA00", Offset = "0x21DAA00", VA = "0x21DAA00")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012CE4")]
			[Address(RVA = "0x21DAA08", Offset = "0x21DAA08", VA = "0x21DAA08")]
			private set
			{
			}
		}

		// Token: 0x170027D5 RID: 10197
		// (get) Token: 0x06012CE5 RID: 77029 RVA: 0x00079920 File Offset: 0x00077B20
		// (set) Token: 0x06012CE6 RID: 77030 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027D5")]
		public int OnlineStatus
		{
			[Token(Token = "0x6012CE5")]
			[Address(RVA = "0x21DAA10", Offset = "0x21DAA10", VA = "0x21DAA10")]
			get
			{
				return 0;
			}
			[Token(Token = "0x6012CE6")]
			[Address(RVA = "0x21DAA18", Offset = "0x21DAA18", VA = "0x21DAA18")]
			private set
			{
			}
		}

		// Token: 0x06012CE7 RID: 77031 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CE7")]
		[Address(RVA = "0x21DAA20", Offset = "0x21DAA20", VA = "0x21DAA20")]
		public void LavaQuestEnter(int eventId, string scenarioId)
		{
		}

		// Token: 0x06012CE8 RID: 77032 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CE8")]
		[Address(RVA = "0x21DAC30", Offset = "0x21DAC30", VA = "0x21DAC30")]
		public void LavaQuestClaim(int eventId, string scenarioId, int winnerCount, InventoryPackage package)
		{
		}

		// Token: 0x06012CE9 RID: 77033 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CE9")]
		[Address(RVA = "0x21DB0C0", Offset = "0x21DB0C0", VA = "0x21DB0C0")]
		public void LavaQuestFinish(int eventId, string scenarioId, int playerCount, int stage, int finishState)
		{
		}

		// Token: 0x06012CEA RID: 77034 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CEA")]
		[Address(RVA = "0x21DB4A8", Offset = "0x21DB4A8", VA = "0x21DB4A8")]
		public void MagicCauldronFinish(int eventId, int seed, int step, int elixirCount, int elixirUsed, int tryCount)
		{
		}

		// Token: 0x06012CEB RID: 77035 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CEB")]
		[Address(RVA = "0x21DB928", Offset = "0x21DB928", VA = "0x21DB928")]
		public void MagicCauldronClaim(int eventId, int seed, int step, InventoryPackage package)
		{
		}

		// Token: 0x06012CEC RID: 77036 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CEC")]
		[Address(RVA = "0x21DBDB8", Offset = "0x21DBDB8", VA = "0x21DBDB8")]
		public void ArcheryArenaEnter(int eventId, int segment, long groupId)
		{
		}

		// Token: 0x06012CED RID: 77037 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CED")]
		[Address(RVA = "0x21DC068", Offset = "0x21DC068", VA = "0x21DC068")]
		public void ArcheryArenaClaim(int eventId, int segment, long groupId, int rank, int collectedTarget, InventoryPackage package)
		{
		}

		// Token: 0x06012CEE RID: 77038 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CEE")]
		[Address(RVA = "0x21DC630", Offset = "0x21DC630", VA = "0x21DC630")]
		public void ArcheryArenaFinish(int eventId, int segment, long groupId, int rank, int collectedTarget, InventoryPackage package)
		{
		}

		// Token: 0x06012CEF RID: 77039 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CEF")]
		[Address(RVA = "0x21DCBF8", Offset = "0x21DCBF8", VA = "0x21DCBF8")]
		public void ArcheryArenaStepClaim(int eventId, int segment, long groupId, int step, int goal, int collectedTarget, InventoryPackage package)
		{
		}

		// Token: 0x06012CF0 RID: 77040 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF0")]
		[Address(RVA = "0x21DD268", Offset = "0x21DD268", VA = "0x21DD268")]
		public void DragonNestEnter(int eventId, int matchmakingSource, int dragonType, long partnerUserId)
		{
		}

		// Token: 0x06012CF1 RID: 77041 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF1")]
		[Address(RVA = "0x21DD5B0", Offset = "0x21DD5B0", VA = "0x21DD5B0")]
		public void DragonNestInvite(int eventId, int userAction, int inviteSource, long partnerUserId, long teamId)
		{
		}

		// Token: 0x06012CF2 RID: 77042 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF2")]
		[Address(RVA = "0x21DD998", Offset = "0x21DD998", VA = "0x21DD998")]
		public void DragonNestProgress(int eventId, int dragonType, int dragonballCount, int dragonballMultiplier, int scenarioId, int dragonTokenCount, DragonNestScore totalScore)
		{
		}

		// Token: 0x06012CF3 RID: 77043 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF3")]
		[Address(RVA = "0x21DDEB8", Offset = "0x21DDEB8", VA = "0x21DDEB8")]
		public void DragonNestClaim(int eventId, int dragonType, int rewardStep, InventoryPackage package)
		{
		}

		// Token: 0x06012CF4 RID: 77044 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF4")]
		[Address(RVA = "0x21DE348", Offset = "0x21DE348", VA = "0x21DE348")]
		public void DragonNestFinish(int eventId, int finishStatus, int magicBallCount, int lightballConversionCount, DragonNestDragonInfo dragonInfo1, DragonNestDragonInfo dragonInfo2, DragonNestDragonInfo dragonInfo3, DragonNestDragonInfo dragonInfo4)
		{
		}

		// Token: 0x06012CF5 RID: 77045 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF5")]
		[Address(RVA = "0x21DE90C", Offset = "0x21DE90C", VA = "0x21DE90C")]
		public void TrainJourneyInvite(int eventId, int userAction, int inviteSource, long friendUserId, long teamId)
		{
		}

		// Token: 0x06012CF6 RID: 77046 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF6")]
		[Address(RVA = "0x21DECF4", Offset = "0x21DECF4", VA = "0x21DECF4")]
		public void TrainJourneyEnter(int eventId, int matchmakingSource, int friendType, long partnerUserId)
		{
		}

		// Token: 0x06012CF7 RID: 77047 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF7")]
		[Address(RVA = "0x21DF03C", Offset = "0x21DF03C", VA = "0x21DF03C")]
		public void TrainJourneyProgress(int eventId, int friendType, int wheelColor, int trainMultiplier, int trainCount, int railTokenCollected, int myRailToken, int partnerRailToken)
		{
		}

		// Token: 0x06012CF8 RID: 77048 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF8")]
		[Address(RVA = "0x21DF604", Offset = "0x21DF604", VA = "0x21DF604")]
		public void TrainJourneyClaim(int eventId, int friendType, int rewardStep, InventoryPackage package)
		{
		}

		// Token: 0x06012CF9 RID: 77049 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CF9")]
		[Address(RVA = "0x21DFA94", Offset = "0x21DFA94", VA = "0x21DFA94")]
		public void TrainJourneyFinish(int eventId, int friendType, int trainCount, int lightballConversionCount, TrainJourneyEvtHelper.PartnerProgressInfo friend1, TrainJourneyEvtHelper.PartnerProgressInfo friend2, TrainJourneyEvtHelper.PartnerProgressInfo friend3)
		{
		}

		// Token: 0x06012CFA RID: 77050 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CFA")]
		[Address(RVA = "0x21E0370", Offset = "0x21E0370", VA = "0x21E0370")]
		public void DukesFortuneFinish(int eventId, int finishStatus, int remainingTokens, int tokensUsed, int rocketConversion, int totalScore, int step)
		{
		}

		// Token: 0x06012CFB RID: 77051 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CFB")]
		[Address(RVA = "0x21E0894", Offset = "0x21E0894", VA = "0x21E0894")]
		public void DukesFortuneProgress(int eventId, int reels, int multiplier, int step, int tokenCount, bool isFreeSpin, int boneEarned, int coinEarned, int spinEarned, int totalScore)
		{
		}

		// Token: 0x06012CFC RID: 77052 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CFC")]
		[Address(RVA = "0x21E0FA0", Offset = "0x21E0FA0", VA = "0x21E0FA0")]
		public void DukesFortuneClaim(int eventId, int step, InventoryPackage rewardPackage, int stepGoal)
		{
		}

		// Token: 0x06012CFD RID: 77053 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CFD")]
		[Address(RVA = "0x21E14DC", Offset = "0x21E14DC", VA = "0x21E14DC")]
		public void TeamTournamentEnter(int teamEventId, int groupSegment, int teamSegment, long groupId, long teamId)
		{
		}

		// Token: 0x06012CFE RID: 77054 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CFE")]
		[Address(RVA = "0x21E18C4", Offset = "0x21E18C4", VA = "0x21E18C4")]
		public void TeamTournamentStepClaim(int eventId, int groupSegment, int teamSegment, int teamRank, int myRankInTeam, int myLanceCount, int teamLanceCount, int claimedStep, int stepTokenTarget, long groupId, long teamId, InventoryPackage package)
		{
		}

		// Token: 0x06012CFF RID: 77055 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012CFF")]
		[Address(RVA = "0x21E2240", Offset = "0x21E2240", VA = "0x21E2240")]
		public void TeamTournamentEventClaim(int eventId, int groupSegment, int teamSegment, int teamRank, int myRankInTeam, int myLanceCount, int teamLanceCount, long groupId, long teamId, InventoryPackage package)
		{
		}

		// Token: 0x06012D00 RID: 77056 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D00")]
		[Address(RVA = "0x21E2A7C", Offset = "0x21E2A7C", VA = "0x21E2A7C")]
		public void TeamTournamentEventFinish(int eventId, int groupSegment, int teamSegment, int teamRank, int myRankInTeam, int myLanceCount, int teamLanceCount, long groupId, long teamId, InventoryPackage package)
		{
		}

		// Token: 0x06012D01 RID: 77057 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D01")]
		[Address(RVA = "0x21E32B8", Offset = "0x21E32B8", VA = "0x21E32B8")]
		public void MissionPursuitFinish(int eventId, int finishStatus, int stage, int totalMagnifier, int claimedMissions, int lockedCompletedMissions)
		{
		}

		// Token: 0x06012D02 RID: 77058 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D02")]
		[Address(RVA = "0x21E3738", Offset = "0x21E3738", VA = "0x21E3738")]
		public void MissionPursuitTaskClaim(int eventId, int stage, int missionId, int rewardMagnifier, int trigger)
		{
		}

		// Token: 0x06012D03 RID: 77059 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D03")]
		[Address(RVA = "0x21E3B20", Offset = "0x21E3B20", VA = "0x21E3B20")]
		public void MissionPursuitTaskComplete(int eventId, int stage, int missionId, int missionTarget, int missionStage)
		{
		}

		// Token: 0x06012D04 RID: 77060 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D04")]
		[Address(RVA = "0x21E3F08", Offset = "0x21E3F08", VA = "0x21E3F08")]
		public void MissionPursuitChestClaim(int eventId, int stage, int totalMagnifier, int claimedChest, InventoryPackage package, int trigger)
		{
		}

		// Token: 0x06012D05 RID: 77061 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D05")]
		[Address(RVA = "0x21E44D0", Offset = "0x21E44D0", VA = "0x21E44D0")]
		public void MissionControlFinish(int eventId, int finishStatus, int claimedMissions)
		{
		}

		// Token: 0x06012D06 RID: 77062 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D06")]
		[Address(RVA = "0x21E4780", Offset = "0x21E4780", VA = "0x21E4780")]
		public void MissionControlTaskClaim(int eventId, int stage, int missionId, int trigger)
		{
		}

		// Token: 0x06012D07 RID: 77063 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D07")]
		[Address(RVA = "0x21E4AC8", Offset = "0x21E4AC8", VA = "0x21E4AC8")]
		public void MissionControlTaskComplete(int eventId, int missionId, int missionTarget, int missionStage)
		{
		}

		// Token: 0x06012D08 RID: 77064 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D08")]
		[Address(RVA = "0x21E4E10", Offset = "0x21E4E10", VA = "0x21E4E10")]
		public void MissionControlChestClaim(int eventId, int claimedChest, InventoryPackage package, int trigger)
		{
		}

		// Token: 0x06012D09 RID: 77065 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D09")]
		[Address(RVA = "0x21E52A0", Offset = "0x21E52A0", VA = "0x21E52A0")]
		public void OceanOdysseyFinish(int eventId, int stage, string stageName, int finishStatus, int oceanballCount, int oceanballMultiplier, int tntConversionCount)
		{
		}

		// Token: 0x06012D0A RID: 77066 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D0A")]
		[Address(RVA = "0x21E5814", Offset = "0x21E5814", VA = "0x21E5814")]
		public void OceanOdysseyStageComplete(int eventId, int stage, string stageName, int oceanballUsed, int oceanballLeft, int oceanballMultiplier, int oceanballEarned, int oceanballWasted)
		{
		}

		// Token: 0x06012D0B RID: 77067 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D0B")]
		[Address(RVA = "0x21E5E28", Offset = "0x21E5E28", VA = "0x21E5E28")]
		public void OceanOdysseyClaim(int eventId, int stage, string stageName, InventoryPackage package)
		{
		}

		// Token: 0x06012D0C RID: 77068 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D0C")]
		[Address(RVA = "0x21E6304", Offset = "0x21E6304", VA = "0x21E6304")]
		public void PuzzleBreakFinish(int eventId, int step, string puzzleName, int puzzleSize, int pieceCount, int piecesUsed, int piecesPlaced, int conversionCount)
		{
		}

		// Token: 0x06012D0D RID: 77069 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D0D")]
		[Address(RVA = "0x21E68CC", Offset = "0x21E68CC", VA = "0x21E68CC")]
		public void PuzzleBreakClaim(int eventId, int currentStage, int claimedStage, InventoryPackage package, bool hasGivenMissingCard)
		{
		}

		// Token: 0x06012D0E RID: 77070 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D0E")]
		[Address(RVA = "0x21E6E00", Offset = "0x21E6E00", VA = "0x21E6E00")]
		public void AncientAdventureFinish(int eventId, int endingType, int stage, int step, int finishStatus)
		{
		}

		// Token: 0x06012D0F RID: 77071 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D0F")]
		[Address(RVA = "0x21E71E8", Offset = "0x21E71E8", VA = "0x21E71E8")]
		public void AncientAdventureClaim(int eventId, int endingType, int step, int stage, InventoryPackage package, int heistLowestCount = 0, int heistMediumCount = 0, int heistHighestCount = 0)
		{
		}

		// Token: 0x06012D10 RID: 77072 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D10")]
		[Address(RVA = "0x21E77B8", Offset = "0x21E77B8", VA = "0x21E77B8")]
		public void WorldCupEnterEvent(int eventId, int countryId, int eventStage)
		{
		}

		// Token: 0x06012D11 RID: 77073 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D11")]
		[Address(RVA = "0x21E7A68", Offset = "0x21E7A68", VA = "0x21E7A68")]
		public void WorldCupFinish(int eventId, int countryId, int eventStage, int userRank, int userScore, int countryRank, int countryScore)
		{
		}

		// Token: 0x06012D12 RID: 77074 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D12")]
		[Address(RVA = "0x21E7F8C", Offset = "0x21E7F8C", VA = "0x21E7F8C")]
		public void WorldCupClaim(int eventId, int countryId, int eventStage, int userRank, int userScore, int countryRank, int countryScore, InventoryPackage package)
		{
		}

		// Token: 0x06012D13 RID: 77075 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D13")]
		[Address(RVA = "0x21E869C", Offset = "0x21E869C", VA = "0x21E869C")]
		public void UserProfileCompleteTutorial(string trigger, string visualConfig)
		{
		}

		// Token: 0x06012D14 RID: 77076 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D14")]
		[Address(RVA = "0x21E8940", Offset = "0x21E8940", VA = "0x21E8940")]
		public void UserProfileViewProfile(string trigger, string userId)
		{
		}

		// Token: 0x06012D15 RID: 77077 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D15")]
		[Address(RVA = "0x21E8BE4", Offset = "0x21E8BE4", VA = "0x21E8BE4")]
		public void UserProfileEditProfileChangeName(string trigger, string visualConfig)
		{
		}

		// Token: 0x06012D16 RID: 77078 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D16")]
		[Address(RVA = "0x21E8E88", Offset = "0x21E8E88", VA = "0x21E8E88")]
		public void UserProfileEditProfileSave(string trigger, string visualConfig)
		{
		}

		// Token: 0x06012D17 RID: 77079 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D17")]
		[Address(RVA = "0x21E912C", Offset = "0x21E912C", VA = "0x21E912C")]
		public void UserProfileUnlockItem(string trigger, int itemType, int itemId)
		{
		}

		// Token: 0x06012D18 RID: 77080 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D18")]
		[Address(RVA = "0x21E93DC", Offset = "0x21E93DC", VA = "0x21E93DC")]
		public void FriendStateChange(long friendId, FriendRequestSource state)
		{
		}

		// Token: 0x06012D19 RID: 77081 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D19")]
		[Address(RVA = "0x21E95EC", Offset = "0x21E95EC", VA = "0x21E95EC")]
		public void ProductCountNotSame(int parsedProductCount, int savedProductsCount, List<string> missingProducts)
		{
		}

		// Token: 0x06012D1A RID: 77082 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D1A")]
		[Address(RVA = "0x21E9908", Offset = "0x21E9908", VA = "0x21E9908")]
		public void StoredProductCountNotSame(int parsedProductCount, int savedProductsCount, List<string> missingProducts)
		{
		}

		// Token: 0x06012D1B RID: 77083 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D1B")]
		[Address(RVA = "0x21E9C24", Offset = "0x21E9C24", VA = "0x21E9C24")]
		public void SendMetricEvent(object[] metricData)
		{
		}

		// Token: 0x06012D1C RID: 77084 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D1C")]
		[Address(RVA = "0x21E9DB8", Offset = "0x21E9DB8", VA = "0x21E9DB8")]
		public void SendCrashEvent(int lastAppStatus, int lastSceneIndex, int lastExitReason, int backgroundFetchAmount)
		{
		}

		// Token: 0x06012D1D RID: 77085 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D1D")]
		[Address(RVA = "0x21EA124", Offset = "0x21EA124", VA = "0x21EA124")]
		public void UserStatsCollectionStarted()
		{
		}

		// Token: 0x06012D1E RID: 77086 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D1E")]
		[Address(RVA = "0x21EA2A4", Offset = "0x21EA2A4", VA = "0x21EA2A4")]
		public void NetworkMetricsEvent(BackendEndpointTypes endpointType, ServerMetricData metricData, float sessionDurationInSec, SessionNetworkType networkType)
		{
		}

		// Token: 0x06012D1F RID: 77087 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D1F")]
		[Address(RVA = "0x21B8EFC", Offset = "0x21B8EFC", VA = "0x21B8EFC")]
		private void SendScreenParameters()
		{
		}

		// Token: 0x06012D20 RID: 77088 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D20")]
		[Address(RVA = "0x21EAA04", Offset = "0x21EAA04", VA = "0x21EAA04")]
		public void TrySendTechnicalSpecifications()
		{
		}

		// Token: 0x06012D21 RID: 77089 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D21")]
		[Address(RVA = "0x21EB024", Offset = "0x21EB024", VA = "0x21EB024")]
		public void InteractedNotification(int eventKey, int notificationType)
		{
		}

		// Token: 0x06012D22 RID: 77090 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D22")]
		[Address(RVA = "0x21EAFB0", Offset = "0x21EAFB0", VA = "0x21EAFB0")]
		private static string CheckAndLogSupportedFormat(TextureFormat format)
		{
			return null;
		}

		// Token: 0x06012D23 RID: 77091 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D23")]
		[Address(RVA = "0x21BD88C", Offset = "0x21BD88C", VA = "0x21BD88C")]
		private List<EventParameter> GetDefaultParameters(int level = 0, [Optional] UserActiveLevelData levelData)
		{
			return null;
		}

		// Token: 0x06012D24 RID: 77092 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D24")]
		[Address(RVA = "0x21EB234", Offset = "0x21EB234", VA = "0x21EB234")]
		private static Inventory1 GetInventory1Parameters()
		{
			return null;
		}

		// Token: 0x06012D25 RID: 77093 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D25")]
		[Address(RVA = "0x21EB398", Offset = "0x21EB398", VA = "0x21EB398")]
		private Inventory2 GetInventory2Parameters([Optional] UserActiveLevelData levelData)
		{
			return null;
		}

		// Token: 0x06012D26 RID: 77094 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D26")]
		[Address(RVA = "0x21C1930", Offset = "0x21C1930", VA = "0x21C1930")]
		private EventInventory GetSpecialRewardInventoryParameters()
		{
			return null;
		}

		// Token: 0x06012D27 RID: 77095 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D27")]
		[Address(RVA = "0x21C1A04", Offset = "0x21C1A04", VA = "0x21C1A04")]
		private static EventRewardInventory GetSpecialRewardParameters(InventoryPackage package)
		{
			return null;
		}

		// Token: 0x06012D28 RID: 77096 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D28")]
		[Address(RVA = "0x21C34F4", Offset = "0x21C34F4", VA = "0x21C34F4")]
		private static EventRewardInventory GetSpecialRewardParameters(ShopPackageConfig config)
		{
			return null;
		}

		// Token: 0x06012D29 RID: 77097 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D29")]
		[Address(RVA = "0x21C5F50", Offset = "0x21C5F50", VA = "0x21C5F50")]
		private static RewardInventory GetRewardInventoryParameters(InventoryPackage package)
		{
			return null;
		}

		// Token: 0x06012D2A RID: 77098 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D2A")]
		[Address(RVA = "0x21C24C4", Offset = "0x21C24C4", VA = "0x21C24C4")]
		private List<EventParameter> GetPurchaseParameters(ShopPackageConfig config, string purchaseType)
		{
			return null;
		}

		// Token: 0x06012D2B RID: 77099 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D2B")]
		[Address(RVA = "0x21EB508", Offset = "0x21EB508", VA = "0x21EB508")]
		public void OldCardCollectionFinish(int wildCardCount, InventoryPackage package)
		{
		}

		// Token: 0x06012D2C RID: 77100 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D2C")]
		[Address(RVA = "0x21EB7C8", Offset = "0x21EB7C8", VA = "0x21EB7C8")]
		public void SeasonalCardCollectionStart(int seasonId, int step)
		{
		}

		// Token: 0x06012D2D RID: 77101 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D2D")]
		[Address(RVA = "0x21EB9D8", Offset = "0x21EB9D8", VA = "0x21EB9D8")]
		public void SeasonalCardCollectionCardClaim(int seasonId, int packId, int setId, int cardId, bool cardType, int cardStar, bool isNew, string source, long sourceId, long duplicateStars, int eventStage)
		{
		}

		// Token: 0x06012D2E RID: 77102 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D2E")]
		[Address(RVA = "0x21EC194", Offset = "0x21EC194", VA = "0x21EC194")]
		public void SeasonalCardCollectionDuplicateStarUse(int seasonId, int chestType, long requiredStars, long duplicateStars, InventoryPackage package)
		{
		}

		// Token: 0x06012D2F RID: 77103 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D2F")]
		[Address(RVA = "0x21EC58C", Offset = "0x21EC58C", VA = "0x21EC58C")]
		public void SeasonalCardCollectionSetComplete(int seasonId, int lastClaimedCardId, int completedSetId, int step, InventoryPackage package)
		{
		}

		// Token: 0x06012D30 RID: 77104 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D30")]
		[Address(RVA = "0x21ECA54", Offset = "0x21ECA54", VA = "0x21ECA54")]
		public void SeasonalCardCollectionCollectionComplete(int seasonId, int lastClaimedCardId, int lastCompletedSetId, int step, int badgeId, InventoryPackage package)
		{
		}

		// Token: 0x06012D31 RID: 77105 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D31")]
		[Address(RVA = "0x21ECFBC", Offset = "0x21ECFBC", VA = "0x21ECFBC")]
		public void SeasonalCardCollectionFinish(int seasonId, int step, int cardProgress)
		{
		}

		// Token: 0x06012D32 RID: 77106 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D32")]
		[Address(RVA = "0x21ED26C", Offset = "0x21ED26C", VA = "0x21ED26C")]
		public void SeasonalCardCollectionSendCard(int seasonId, int setId, int cardId, bool cardType, int cardStar, int duplicateAmount, int sendType, long receiverId, long duplicateStars, int eventStage)
		{
		}

		// Token: 0x06012D33 RID: 77107 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D33")]
		[Address(RVA = "0x21ED990", Offset = "0x21ED990", VA = "0x21ED990")]
		public void SeasonalCardCollectionCardRequest(int seasonId, long teamId, int setId, int cardId, int cardStar, int eventStage)
		{
		}

		// Token: 0x06012D34 RID: 77108 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D34")]
		[Address(RVA = "0x21EDE48", Offset = "0x21EDE48", VA = "0x21EDE48")]
		public void AddKillEvent(string killEvent)
		{
		}

		// Token: 0x06012D35 RID: 77109 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D35")]
		[Address(RVA = "0x21EDE64", Offset = "0x21EDE64", VA = "0x21EDE64")]
		public AnalyticsManager()
		{
		}

		// Token: 0x0400EC97 RID: 60567
		[Token(Token = "0x400EC97")]
		public const int AnalyticsFacebookId = 1;

		// Token: 0x0400EC98 RID: 60568
		[Token(Token = "0x400EC98")]
		public const int AnalyticsInstagramId = 2;

		// Token: 0x0400EC99 RID: 60569
		[Token(Token = "0x400EC99")]
		public const int AnalyticsTriggerHomeScene = 1;

		// Token: 0x0400EC9A RID: 60570
		[Token(Token = "0x400EC9A")]
		public const int AnalyticsTriggerSettings = 2;

		// Token: 0x0400EC9B RID: 60571
		[Token(Token = "0x400EC9B")]
		public const string AnalyticsStart = "start";

		// Token: 0x0400EC9C RID: 60572
		[Token(Token = "0x400EC9C")]
		public const string AnalyticsEnd = "end";

		// Token: 0x0400EC9D RID: 60573
		[Token(Token = "0x400EC9D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private static string InstallId;

		// Token: 0x0400EC9E RID: 60574
		[Token(Token = "0x400EC9E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		private MarketingHelper marketingHelper;

		// Token: 0x0400EC9F RID: 60575
		[Token(Token = "0x400EC9F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		private LeagueManager leagueManager;

		// Token: 0x0400ECA0 RID: 60576
		[Token(Token = "0x400ECA0")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		private CameraManager cameraManager;

		// Token: 0x0400ECA1 RID: 60577
		[Token(Token = "0x400ECA1")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		private LifeHelper lifeHelper;

		// Token: 0x0400ECA2 RID: 60578
		[Token(Token = "0x400ECA2")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
		private EventSender eventSender;

		// Token: 0x0400ECA3 RID: 60579
		[Token(Token = "0x400ECA3")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x38")]
		private LevelManager levelManager;

		// Token: 0x0400ECA4 RID: 60580
		[Token(Token = "0x400ECA4")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x40")]
		private WelcomeBackGiftManager welcomeBackGiftManager;

		// Token: 0x0400ECA5 RID: 60581
		[Token(Token = "0x400ECA5")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x48")]
		private SuperBoosterManager superBoosterManager;

		// Token: 0x0400ECA6 RID: 60582
		[Token(Token = "0x400ECA6")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x50")]
		private MagicDukeManager magicDukeManager;

		// Token: 0x0400ECA7 RID: 60583
		[Token(Token = "0x400ECA7")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x58")]
		private HiddenTempleManager hiddenTempleManager;

		// Token: 0x0400ECA8 RID: 60584
		[Token(Token = "0x400ECA8")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x60")]
		private MagicCauldronManager magicCauldronManager;

		// Token: 0x0400ECA9 RID: 60585
		[Token(Token = "0x400ECA9")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x68")]
		private AudioManager audioManager;

		// Token: 0x0400ECAA RID: 60586
		[Token(Token = "0x400ECAA")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x70")]
		private HapticManager hapticManager;

		// Token: 0x0400ECAB RID: 60587
		[Token(Token = "0x400ECAB")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x78")]
		private SuperDukeManager superDukeManager;

		// Token: 0x0400ECAC RID: 60588
		[Token(Token = "0x400ECAC")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x80")]
		private float lastSessionEventSentTime;

		// Token: 0x0400ECAD RID: 60589
		[Token(Token = "0x400ECAD")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x88")]
		private readonly List<EventData> abTestList;

		// Token: 0x0400ECAE RID: 60590
		[Token(Token = "0x400ECAE")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x90")]
		private readonly BatteryUsageAnalyticsHelper batteryUsageAnalyticsHelper;

		// Token: 0x0400ECAF RID: 60591
		[Token(Token = "0x400ECAF")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x98")]
		private string <AppsFlyerId>k__BackingField;

		// Token: 0x0400ECB0 RID: 60592
		[Token(Token = "0x400ECB0")]
		[Il2CppDummyDll.FieldOffset(Offset = "0xA0")]
		private int <OnlineStatus>k__BackingField;

		// Token: 0x0200258F RID: 9615
		[Token(Token = "0x200258F")]
		private sealed class <CheckForInit>d__31 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012D36 RID: 77110 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012D36")]
			[Address(RVA = "0x2439B84", Offset = "0x2439B84", VA = "0x2439B84")]
			[DebuggerHidden]
			public <CheckForInit>d__31(int <>1__state)
			{
			}

			// Token: 0x06012D37 RID: 77111 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012D37")]
			[Address(RVA = "0x2439BAC", Offset = "0x2439BAC", VA = "0x2439BAC", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012D38 RID: 77112 RVA: 0x00079938 File Offset: 0x00077B38
			[Token(Token = "0x6012D38")]
			[Address(RVA = "0x2439BB0", Offset = "0x2439BB0", VA = "0x2439BB0", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x170027D6 RID: 10198
			// (get) Token: 0x06012D39 RID: 77113 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170027D6")]
			private object Current
			{
				[Token(Token = "0x6012D39")]
				[Address(RVA = "0x243A1BC", Offset = "0x243A1BC", VA = "0x243A1BC", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012D3A RID: 77114 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012D3A")]
			[Address(RVA = "0x243A1C4", Offset = "0x243A1C4", VA = "0x243A1C4", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x170027D7 RID: 10199
			// (get) Token: 0x06012D3B RID: 77115 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170027D7")]
			private object Current
			{
				[Token(Token = "0x6012D3B")]
				[Address(RVA = "0x243A204", Offset = "0x243A204", VA = "0x243A204", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400ECB1 RID: 60593
			[Token(Token = "0x400ECB1")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400ECB2 RID: 60594
			[Token(Token = "0x400ECB2")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400ECB3 RID: 60595
			[Token(Token = "0x400ECB3")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
			public AnalyticsManager <>4__this;
		}
	}
}
