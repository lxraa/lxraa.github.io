﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D5 RID: 9173
	[Token(Token = "0x20023D5")]
	public struct GetFacebookIdsResponse : IFlatbufferObject
	{
		// Token: 0x170020F7 RID: 8439
		// (get) Token: 0x060113BD RID: 70589 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020F7")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60113BD")]
			[Address(RVA = "0x1CAFF14", Offset = "0x1CAFF14", VA = "0x1CAFF14", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060113BE RID: 70590 RVA: 0x00066A98 File Offset: 0x00064C98
		[Token(Token = "0x60113BE")]
		[Address(RVA = "0x1CAFF1C", Offset = "0x1CAFF1C", VA = "0x1CAFF1C")]
		public static GetFacebookIdsResponse GetRootAsGetFacebookIdsResponse(ByteBuffer _bb)
		{
			return default(GetFacebookIdsResponse);
		}

		// Token: 0x060113BF RID: 70591 RVA: 0x00066AB0 File Offset: 0x00064CB0
		[Token(Token = "0x60113BF")]
		[Address(RVA = "0x1CAFF28", Offset = "0x1CAFF28", VA = "0x1CAFF28")]
		public static GetFacebookIdsResponse GetRootAsGetFacebookIdsResponse(ByteBuffer _bb, GetFacebookIdsResponse obj)
		{
			return default(GetFacebookIdsResponse);
		}

		// Token: 0x060113C0 RID: 70592 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113C0")]
		[Address(RVA = "0x1CAFFD8", Offset = "0x1CAFFD8", VA = "0x1CAFFD8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060113C1 RID: 70593 RVA: 0x00066AC8 File Offset: 0x00064CC8
		[Token(Token = "0x60113C1")]
		[Address(RVA = "0x1CAFFA0", Offset = "0x1CAFFA0", VA = "0x1CAFFA0")]
		public GetFacebookIdsResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetFacebookIdsResponse);
		}

		// Token: 0x060113C2 RID: 70594 RVA: 0x00066AE0 File Offset: 0x00064CE0
		[Token(Token = "0x60113C2")]
		[Address(RVA = "0x1CAFFE8", Offset = "0x1CAFFE8", VA = "0x1CAFFE8")]
		public long FacebookIds(int j)
		{
			return 0L;
		}

		// Token: 0x170020F8 RID: 8440
		// (get) Token: 0x060113C3 RID: 70595 RVA: 0x00066AF8 File Offset: 0x00064CF8
		[Token(Token = "0x170020F8")]
		public int FacebookIdsLength
		{
			[Token(Token = "0x60113C3")]
			[Address(RVA = "0x1CB004C", Offset = "0x1CB004C", VA = "0x1CB004C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060113C4 RID: 70596 RVA: 0x00066B10 File Offset: 0x00064D10
		[Token(Token = "0x60113C4")]
		[Address(RVA = "0x1CB0080", Offset = "0x1CB0080", VA = "0x1CB0080")]
		public ArraySegment<byte>? GetFacebookIdsBytes()
		{
			return null;
		}

		// Token: 0x060113C5 RID: 70597 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60113C5")]
		[Address(RVA = "0x1CB00B8", Offset = "0x1CB00B8", VA = "0x1CB00B8")]
		public long[] GetFacebookIdsArray()
		{
			return null;
		}

		// Token: 0x170020F9 RID: 8441
		// (get) Token: 0x060113C6 RID: 70598 RVA: 0x00066B28 File Offset: 0x00064D28
		[Token(Token = "0x170020F9")]
		public int Version
		{
			[Token(Token = "0x60113C6")]
			[Address(RVA = "0x1CB0104", Offset = "0x1CB0104", VA = "0x1CB0104")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060113C7 RID: 70599 RVA: 0x00066B40 File Offset: 0x00064D40
		[Token(Token = "0x60113C7")]
		[Address(RVA = "0x1CB0148", Offset = "0x1CB0148", VA = "0x1CB0148")]
		public int FrameIds(int j)
		{
			return 0;
		}

		// Token: 0x170020FA RID: 8442
		// (get) Token: 0x060113C8 RID: 70600 RVA: 0x00066B58 File Offset: 0x00064D58
		[Token(Token = "0x170020FA")]
		public int FrameIdsLength
		{
			[Token(Token = "0x60113C8")]
			[Address(RVA = "0x1CB01A8", Offset = "0x1CB01A8", VA = "0x1CB01A8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060113C9 RID: 70601 RVA: 0x00066B70 File Offset: 0x00064D70
		[Token(Token = "0x60113C9")]
		[Address(RVA = "0x1CB01DC", Offset = "0x1CB01DC", VA = "0x1CB01DC")]
		public ArraySegment<byte>? GetFrameIdsBytes()
		{
			return null;
		}

		// Token: 0x060113CA RID: 70602 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60113CA")]
		[Address(RVA = "0x1CB0214", Offset = "0x1CB0214", VA = "0x1CB0214")]
		public int[] GetFrameIdsArray()
		{
			return null;
		}

		// Token: 0x060113CB RID: 70603 RVA: 0x00066B88 File Offset: 0x00064D88
		[Token(Token = "0x60113CB")]
		[Address(RVA = "0x1CB0260", Offset = "0x1CB0260", VA = "0x1CB0260")]
		public static Offset<GetFacebookIdsResponse> CreateGetFacebookIdsResponse(FlatBufferBuilder builder, [Optional] VectorOffset facebook_idsOffset, int version = 0, [Optional] VectorOffset frame_idsOffset)
		{
			return default(Offset<GetFacebookIdsResponse>);
		}

		// Token: 0x060113CC RID: 70604 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113CC")]
		[Address(RVA = "0x1CB039C", Offset = "0x1CB039C", VA = "0x1CB039C")]
		public static void StartGetFacebookIdsResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060113CD RID: 70605 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113CD")]
		[Address(RVA = "0x1CB0310", Offset = "0x1CB0310", VA = "0x1CB0310")]
		public static void AddFacebookIds(FlatBufferBuilder builder, VectorOffset facebookIdsOffset)
		{
		}

		// Token: 0x060113CE RID: 70606 RVA: 0x00066BA0 File Offset: 0x00064DA0
		[Token(Token = "0x60113CE")]
		[Address(RVA = "0x1CB03B4", Offset = "0x1CB03B4", VA = "0x1CB03B4")]
		public static VectorOffset CreateFacebookIdsVector(FlatBufferBuilder builder, long[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113CF RID: 70607 RVA: 0x00066BB8 File Offset: 0x00064DB8
		[Token(Token = "0x60113CF")]
		[Address(RVA = "0x1CB045C", Offset = "0x1CB045C", VA = "0x1CB045C")]
		public static VectorOffset CreateFacebookIdsVectorBlock(FlatBufferBuilder builder, long[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113D0 RID: 70608 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113D0")]
		[Address(RVA = "0x1CB04E4", Offset = "0x1CB04E4", VA = "0x1CB04E4")]
		public static void StartFacebookIdsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x060113D1 RID: 70609 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113D1")]
		[Address(RVA = "0x1CB02F0", Offset = "0x1CB02F0", VA = "0x1CB02F0")]
		public static void AddVersion(FlatBufferBuilder builder, int version)
		{
		}

		// Token: 0x060113D2 RID: 70610 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113D2")]
		[Address(RVA = "0x1CB02D0", Offset = "0x1CB02D0", VA = "0x1CB02D0")]
		public static void AddFrameIds(FlatBufferBuilder builder, VectorOffset frameIdsOffset)
		{
		}

		// Token: 0x060113D3 RID: 70611 RVA: 0x00066BD0 File Offset: 0x00064DD0
		[Token(Token = "0x60113D3")]
		[Address(RVA = "0x1CB0504", Offset = "0x1CB0504", VA = "0x1CB0504")]
		public static VectorOffset CreateFrameIdsVector(FlatBufferBuilder builder, int[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113D4 RID: 70612 RVA: 0x00066BE8 File Offset: 0x00064DE8
		[Token(Token = "0x60113D4")]
		[Address(RVA = "0x1CB05AC", Offset = "0x1CB05AC", VA = "0x1CB05AC")]
		public static VectorOffset CreateFrameIdsVectorBlock(FlatBufferBuilder builder, int[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113D5 RID: 70613 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113D5")]
		[Address(RVA = "0x1CB0634", Offset = "0x1CB0634", VA = "0x1CB0634")]
		public static void StartFrameIdsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x060113D6 RID: 70614 RVA: 0x00066C00 File Offset: 0x00064E00
		[Token(Token = "0x60113D6")]
		[Address(RVA = "0x1CB0330", Offset = "0x1CB0330", VA = "0x1CB0330")]
		public static Offset<GetFacebookIdsResponse> EndGetFacebookIdsResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetFacebookIdsResponse>);
		}

		// Token: 0x0400E745 RID: 59205
		[Token(Token = "0x400E745")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
