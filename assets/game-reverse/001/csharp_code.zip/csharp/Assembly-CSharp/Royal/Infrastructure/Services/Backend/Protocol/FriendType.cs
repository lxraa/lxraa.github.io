﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023BB RID: 9147
	[Token(Token = "0x20023BB")]
	public enum FriendType
	{
		// Token: 0x0400E6F3 RID: 59123
		[Token(Token = "0x400E6F3")]
		Requested,
		// Token: 0x0400E6F4 RID: 59124
		[Token(Token = "0x400E6F4")]
		Friend,
		// Token: 0x0400E6F5 RID: 59125
		[Token(Token = "0x400E6F5")]
		Pending,
		// Token: 0x0400E6F6 RID: 59126
		[Token(Token = "0x400E6F6")]
		Removed,
		// Token: 0x0400E6F7 RID: 59127
		[Token(Token = "0x400E6F7")]
		Blocked
	}
}
