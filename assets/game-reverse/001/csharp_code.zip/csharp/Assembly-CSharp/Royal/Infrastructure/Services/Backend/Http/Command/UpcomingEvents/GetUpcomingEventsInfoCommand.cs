﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.UpcomingEvents
{
	// Token: 0x0200252E RID: 9518
	[Token(Token = "0x200252E")]
	public class GetUpcomingEventsInfoCommand : BaseHttpCommand
	{
		// Token: 0x17002710 RID: 10000
		// (get) Token: 0x060129C8 RID: 76232 RVA: 0x00077D00 File Offset: 0x00075F00
		[Token(Token = "0x17002710")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129C8")]
			[Address(RVA = "0x1CFAE60", Offset = "0x1CFAE60", VA = "0x1CFAE60", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002711 RID: 10001
		// (get) Token: 0x060129C9 RID: 76233 RVA: 0x00077D18 File Offset: 0x00075F18
		[Token(Token = "0x17002711")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129C9")]
			[Address(RVA = "0x1CFAE68", Offset = "0x1CFAE68", VA = "0x1CFAE68", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060129CA RID: 76234 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129CA")]
		[Address(RVA = "0x1CFAE70", Offset = "0x1CFAE70", VA = "0x1CFAE70")]
		public GetUpcomingEventsInfoCommand()
		{
		}

		// Token: 0x060129CB RID: 76235 RVA: 0x00077D30 File Offset: 0x00075F30
		[Token(Token = "0x60129CB")]
		[Address(RVA = "0x1CFAE90", Offset = "0x1CFAE90", VA = "0x1CFAE90", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129CC RID: 76236 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129CC")]
		[Address(RVA = "0x1CFAEB8", Offset = "0x1CFAEB8", VA = "0x1CFAEB8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129CD RID: 76237 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129CD")]
		[Address(RVA = "0x1CFAF8C", Offset = "0x1CFAF8C", VA = "0x1CFAF8C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x060129CE RID: 76238 RVA: 0x00077D48 File Offset: 0x00075F48
		[Token(Token = "0x60129CE")]
		[Address(RVA = "0x1CFAF90", Offset = "0x1CFAF90", VA = "0x1CFAF90", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}
	}
}
