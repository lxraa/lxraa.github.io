﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002363 RID: 9059
	[Token(Token = "0x2002363")]
	public struct ClaimSpaceMissionRewardResponse : IFlatbufferObject
	{
		// Token: 0x17001F48 RID: 8008
		// (get) Token: 0x06010D72 RID: 68978 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F48")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D72")]
			[Address(RVA = "0x214A130", Offset = "0x214A130", VA = "0x214A130", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D73 RID: 68979 RVA: 0x00061770 File Offset: 0x0005F970
		[Token(Token = "0x6010D73")]
		[Address(RVA = "0x214A138", Offset = "0x214A138", VA = "0x214A138")]
		public static ClaimSpaceMissionRewardResponse GetRootAsClaimSpaceMissionRewardResponse(ByteBuffer _bb)
		{
			return default(ClaimSpaceMissionRewardResponse);
		}

		// Token: 0x06010D74 RID: 68980 RVA: 0x00061788 File Offset: 0x0005F988
		[Token(Token = "0x6010D74")]
		[Address(RVA = "0x214A144", Offset = "0x214A144", VA = "0x214A144")]
		public static ClaimSpaceMissionRewardResponse GetRootAsClaimSpaceMissionRewardResponse(ByteBuffer _bb, ClaimSpaceMissionRewardResponse obj)
		{
			return default(ClaimSpaceMissionRewardResponse);
		}

		// Token: 0x06010D75 RID: 68981 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D75")]
		[Address(RVA = "0x214A1F4", Offset = "0x214A1F4", VA = "0x214A1F4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D76 RID: 68982 RVA: 0x000617A0 File Offset: 0x0005F9A0
		[Token(Token = "0x6010D76")]
		[Address(RVA = "0x214A1BC", Offset = "0x214A1BC", VA = "0x214A1BC")]
		public ClaimSpaceMissionRewardResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimSpaceMissionRewardResponse);
		}

		// Token: 0x06010D77 RID: 68983 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D77")]
		[Address(RVA = "0x214A204", Offset = "0x214A204", VA = "0x214A204")]
		public static void StartClaimSpaceMissionRewardResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D78 RID: 68984 RVA: 0x000617B8 File Offset: 0x0005F9B8
		[Token(Token = "0x6010D78")]
		[Address(RVA = "0x214A21C", Offset = "0x214A21C", VA = "0x214A21C")]
		public static Offset<ClaimSpaceMissionRewardResponse> EndClaimSpaceMissionRewardResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimSpaceMissionRewardResponse>);
		}

		// Token: 0x0400E669 RID: 58985
		[Token(Token = "0x400E669")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
