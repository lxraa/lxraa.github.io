﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002335 RID: 9013
	[Token(Token = "0x2002335")]
	public struct ABTestContent : IFlatbufferObject
	{
		// Token: 0x17001EA9 RID: 7849
		// (get) Token: 0x06010B07 RID: 68359 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EA9")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B07")]
			[Address(RVA = "0x2141244", Offset = "0x2141244", VA = "0x2141244", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B08 RID: 68360 RVA: 0x0005F838 File Offset: 0x0005DA38
		[Token(Token = "0x6010B08")]
		[Address(RVA = "0x214124C", Offset = "0x214124C", VA = "0x214124C")]
		public static ABTestContent GetRootAsABTestContent(ByteBuffer _bb)
		{
			return default(ABTestContent);
		}

		// Token: 0x06010B09 RID: 68361 RVA: 0x0005F850 File Offset: 0x0005DA50
		[Token(Token = "0x6010B09")]
		[Address(RVA = "0x2141258", Offset = "0x2141258", VA = "0x2141258")]
		public static ABTestContent GetRootAsABTestContent(ByteBuffer _bb, ABTestContent obj)
		{
			return default(ABTestContent);
		}

		// Token: 0x06010B0A RID: 68362 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B0A")]
		[Address(RVA = "0x2141308", Offset = "0x2141308", VA = "0x2141308", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B0B RID: 68363 RVA: 0x0005F868 File Offset: 0x0005DA68
		[Token(Token = "0x6010B0B")]
		[Address(RVA = "0x21412D0", Offset = "0x21412D0", VA = "0x21412D0")]
		public ABTestContent __assign(int _i, ByteBuffer _bb)
		{
			return default(ABTestContent);
		}

		// Token: 0x06010B0C RID: 68364 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010B0C")]
		[Address(RVA = "0x2141318", Offset = "0x2141318", VA = "0x2141318")]
		public string Data(int j)
		{
			return null;
		}

		// Token: 0x17001EAA RID: 7850
		// (get) Token: 0x06010B0D RID: 68365 RVA: 0x0005F880 File Offset: 0x0005DA80
		[Token(Token = "0x17001EAA")]
		public int DataLength
		{
			[Token(Token = "0x6010B0D")]
			[Address(RVA = "0x2141370", Offset = "0x2141370", VA = "0x2141370")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010B0E RID: 68366 RVA: 0x0005F898 File Offset: 0x0005DA98
		[Token(Token = "0x6010B0E")]
		[Address(RVA = "0x21413A4", Offset = "0x21413A4", VA = "0x21413A4")]
		public static Offset<ABTestContent> CreateABTestContent(FlatBufferBuilder builder, [Optional] VectorOffset dataOffset)
		{
			return default(Offset<ABTestContent>);
		}

		// Token: 0x06010B0F RID: 68367 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B0F")]
		[Address(RVA = "0x2141478", Offset = "0x2141478", VA = "0x2141478")]
		public static void StartABTestContent(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B10 RID: 68368 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B10")]
		[Address(RVA = "0x21413EC", Offset = "0x21413EC", VA = "0x21413EC")]
		public static void AddData(FlatBufferBuilder builder, VectorOffset dataOffset)
		{
		}

		// Token: 0x06010B11 RID: 68369 RVA: 0x0005F8B0 File Offset: 0x0005DAB0
		[Token(Token = "0x6010B11")]
		[Address(RVA = "0x2141490", Offset = "0x2141490", VA = "0x2141490")]
		public static VectorOffset CreateDataVector(FlatBufferBuilder builder, StringOffset[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010B12 RID: 68370 RVA: 0x0005F8C8 File Offset: 0x0005DAC8
		[Token(Token = "0x6010B12")]
		[Address(RVA = "0x2141538", Offset = "0x2141538", VA = "0x2141538")]
		public static VectorOffset CreateDataVectorBlock(FlatBufferBuilder builder, StringOffset[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010B13 RID: 68371 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B13")]
		[Address(RVA = "0x21415C0", Offset = "0x21415C0", VA = "0x21415C0")]
		public static void StartDataVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010B14 RID: 68372 RVA: 0x0005F8E0 File Offset: 0x0005DAE0
		[Token(Token = "0x6010B14")]
		[Address(RVA = "0x214140C", Offset = "0x214140C", VA = "0x214140C")]
		public static Offset<ABTestContent> EndABTestContent(FlatBufferBuilder builder)
		{
			return default(Offset<ABTestContent>);
		}

		// Token: 0x0400E60F RID: 58895
		[Token(Token = "0x400E60F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
