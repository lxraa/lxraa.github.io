﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts
{
	// Token: 0x020025AB RID: 9643
	[Token(Token = "0x20025AB")]
	public class ContextContainer<T> where T : IContextUnit
	{
		// Token: 0x06012DA0 RID: 77216 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DA0")]
		public ContextContainer(int contextUnitCount)
		{
		}

		// Token: 0x06012DA1 RID: 77217 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DA1")]
		public void Add(T unit)
		{
		}

		// Token: 0x06012DA2 RID: 77218 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012DA2")]
		public T GetLate<T2>(int id) where T2 : T, ILateContextUnit, new()
		{
			return null;
		}

		// Token: 0x06012DA3 RID: 77219 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DA3")]
		public void AddToFirst(T unit)
		{
		}

		// Token: 0x06012DA4 RID: 77220 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DA4")]
		public void Replace(T unit)
		{
		}

		// Token: 0x06012DA5 RID: 77221 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DA5")]
		public void Remove(int id)
		{
		}

		// Token: 0x06012DA6 RID: 77222 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012DA6")]
		public T2 Get<T2>(int id) where T2 : T
		{
			return null;
		}

		// Token: 0x06012DA7 RID: 77223 RVA: 0x00079A10 File Offset: 0x00077C10
		[Token(Token = "0x6012DA7")]
		public bool Has(int id)
		{
			return default(bool);
		}

		// Token: 0x06012DA8 RID: 77224 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DA8")]
		public void Clear()
		{
		}

		// Token: 0x06012DA9 RID: 77225 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DA9")]
		public void RemoveLateUnits()
		{
		}

		// Token: 0x06012DAA RID: 77226 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DAA")]
		public void ManualUpdate()
		{
		}

		// Token: 0x06012DAB RID: 77227 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012DAB")]
		public T[] GetAllUnits()
		{
			return null;
		}

		// Token: 0x06012DAC RID: 77228 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012DAC")]
		public void BindAll()
		{
		}

		// Token: 0x0400ED82 RID: 60802
		[Token(Token = "0x400ED82")]
		[FieldOffset(Offset = "0x0")]
		private readonly List<IContextBehaviour> behaviours;

		// Token: 0x0400ED83 RID: 60803
		[Token(Token = "0x400ED83")]
		[FieldOffset(Offset = "0x0")]
		private readonly T[] units;

		// Token: 0x020025AC RID: 9644
		[Token(Token = "0x20025AC")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06012DAE RID: 77230 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012DAE")]
			public <>c()
			{
			}

			// Token: 0x06012DAF RID: 77231 RVA: 0x00079A28 File Offset: 0x00077C28
			[Token(Token = "0x6012DAF")]
			internal bool <RemoveLateUnits>b__11_0(IContextBehaviour x)
			{
				return default(bool);
			}

			// Token: 0x0400ED84 RID: 60804
			[Token(Token = "0x400ED84")]
			[FieldOffset(Offset = "0x0")]
			public static readonly ContextContainer<T>.<>c <>9;

			// Token: 0x0400ED85 RID: 60805
			[Token(Token = "0x400ED85")]
			[FieldOffset(Offset = "0x0")]
			public static Predicate<IContextBehaviour> <>9__11_0;
		}
	}
}
