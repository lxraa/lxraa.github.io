﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.AncientAdventure
{
	// Token: 0x0200257A RID: 9594
	[Token(Token = "0x200257A")]
	public class GetAncientAdventureInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027C1 RID: 10177
		// (get) Token: 0x06012BD5 RID: 76757 RVA: 0x00079590 File Offset: 0x00077790
		[Token(Token = "0x170027C1")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012BD5")]
			[Address(RVA = "0x1ED6140", Offset = "0x1ED6140", VA = "0x1ED6140", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027C2 RID: 10178
		// (get) Token: 0x06012BD6 RID: 76758 RVA: 0x000795A8 File Offset: 0x000777A8
		[Token(Token = "0x170027C2")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012BD6")]
			[Address(RVA = "0x1ED6148", Offset = "0x1ED6148", VA = "0x1ED6148", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012BD7 RID: 76759 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BD7")]
		[Address(RVA = "0x1ED6150", Offset = "0x1ED6150", VA = "0x1ED6150")]
		public GetAncientAdventureInfoHttpCommand(int userConfigVersion)
		{
		}

		// Token: 0x06012BD8 RID: 76760 RVA: 0x000795C0 File Offset: 0x000777C0
		[Token(Token = "0x6012BD8")]
		[Address(RVA = "0x1ED6180", Offset = "0x1ED6180", VA = "0x1ED6180", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012BD9 RID: 76761 RVA: 0x000795D8 File Offset: 0x000777D8
		[Token(Token = "0x6012BD9")]
		[Address(RVA = "0x1ED6240", Offset = "0x1ED6240", VA = "0x1ED6240", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BDA RID: 76762 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BDA")]
		[Address(RVA = "0x1ED6260", Offset = "0x1ED6260", VA = "0x1ED6260", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BDB RID: 76763 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BDB")]
		[Address(RVA = "0x1ED6338", Offset = "0x1ED6338", VA = "0x1ED6338", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EC11 RID: 60433
		[Token(Token = "0x400EC11")]
		[FieldOffset(Offset = "0x14")]
		private readonly int userConfigVersion;
	}
}
