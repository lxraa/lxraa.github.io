﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C1 RID: 9153
	[Token(Token = "0x20023C1")]
	public struct GetAncientAdventureInfoRequest : IFlatbufferObject
	{
		// Token: 0x170020BC RID: 8380
		// (get) Token: 0x060112B8 RID: 70328 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020BC")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60112B8")]
			[Address(RVA = "0x1CABB20", Offset = "0x1CABB20", VA = "0x1CABB20", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112B9 RID: 70329 RVA: 0x00065C58 File Offset: 0x00063E58
		[Token(Token = "0x60112B9")]
		[Address(RVA = "0x1CABB28", Offset = "0x1CABB28", VA = "0x1CABB28")]
		public static GetAncientAdventureInfoRequest GetRootAsGetAncientAdventureInfoRequest(ByteBuffer _bb)
		{
			return default(GetAncientAdventureInfoRequest);
		}

		// Token: 0x060112BA RID: 70330 RVA: 0x00065C70 File Offset: 0x00063E70
		[Token(Token = "0x60112BA")]
		[Address(RVA = "0x1CABB34", Offset = "0x1CABB34", VA = "0x1CABB34")]
		public static GetAncientAdventureInfoRequest GetRootAsGetAncientAdventureInfoRequest(ByteBuffer _bb, GetAncientAdventureInfoRequest obj)
		{
			return default(GetAncientAdventureInfoRequest);
		}

		// Token: 0x060112BB RID: 70331 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112BB")]
		[Address(RVA = "0x1CABBE4", Offset = "0x1CABBE4", VA = "0x1CABBE4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060112BC RID: 70332 RVA: 0x00065C88 File Offset: 0x00063E88
		[Token(Token = "0x60112BC")]
		[Address(RVA = "0x1CABBAC", Offset = "0x1CABBAC", VA = "0x1CABBAC")]
		public GetAncientAdventureInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetAncientAdventureInfoRequest);
		}

		// Token: 0x170020BD RID: 8381
		// (get) Token: 0x060112BD RID: 70333 RVA: 0x00065CA0 File Offset: 0x00063EA0
		[Token(Token = "0x170020BD")]
		public int ConfigVersion
		{
			[Token(Token = "0x60112BD")]
			[Address(RVA = "0x1CABBF4", Offset = "0x1CABBF4", VA = "0x1CABBF4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060112BE RID: 70334 RVA: 0x00065CB8 File Offset: 0x00063EB8
		[Token(Token = "0x60112BE")]
		[Address(RVA = "0x1CABC38", Offset = "0x1CABC38", VA = "0x1CABC38")]
		public static Offset<GetAncientAdventureInfoRequest> CreateGetAncientAdventureInfoRequest(FlatBufferBuilder builder, int config_version = 0)
		{
			return default(Offset<GetAncientAdventureInfoRequest>);
		}

		// Token: 0x060112BF RID: 70335 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112BF")]
		[Address(RVA = "0x1CABD0C", Offset = "0x1CABD0C", VA = "0x1CABD0C")]
		public static void StartGetAncientAdventureInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060112C0 RID: 70336 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112C0")]
		[Address(RVA = "0x1CABC80", Offset = "0x1CABC80", VA = "0x1CABC80")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x060112C1 RID: 70337 RVA: 0x00065CD0 File Offset: 0x00063ED0
		[Token(Token = "0x60112C1")]
		[Address(RVA = "0x1CABCA0", Offset = "0x1CABCA0", VA = "0x1CABCA0")]
		public static Offset<GetAncientAdventureInfoRequest> EndGetAncientAdventureInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetAncientAdventureInfoRequest>);
		}

		// Token: 0x0400E72E RID: 59182
		[Token(Token = "0x400E72E")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
