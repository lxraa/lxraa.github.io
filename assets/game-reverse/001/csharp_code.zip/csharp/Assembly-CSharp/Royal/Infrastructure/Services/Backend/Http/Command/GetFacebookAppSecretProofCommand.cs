﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002516 RID: 9494
	[Token(Token = "0x2002516")]
	public class GetFacebookAppSecretProofCommand : BaseHttpCommand
	{
		// Token: 0x170026D2 RID: 9938
		// (get) Token: 0x060128CA RID: 75978 RVA: 0x000774C0 File Offset: 0x000756C0
		[Token(Token = "0x170026D2")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60128CA")]
			[Address(RVA = "0x1CEB428", Offset = "0x1CEB428", VA = "0x1CEB428", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026D3 RID: 9939
		// (get) Token: 0x060128CB RID: 75979 RVA: 0x000774D8 File Offset: 0x000756D8
		[Token(Token = "0x170026D3")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60128CB")]
			[Address(RVA = "0x1CEB430", Offset = "0x1CEB430", VA = "0x1CEB430", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060128CC RID: 75980 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128CC")]
		[Address(RVA = "0x1CEB438", Offset = "0x1CEB438", VA = "0x1CEB438")]
		public GetFacebookAppSecretProofCommand(Action<Action<bool>> onComplete, Action<bool> callback)
		{
		}

		// Token: 0x060128CD RID: 75981 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128CD")]
		[Address(RVA = "0x1CEB47C", Offset = "0x1CEB47C", VA = "0x1CEB47C")]
		public GetFacebookAppSecretProofCommand(Action onComplete)
		{
		}

		// Token: 0x060128CE RID: 75982 RVA: 0x000774F0 File Offset: 0x000756F0
		[Token(Token = "0x60128CE")]
		[Address(RVA = "0x1CEB4AC", Offset = "0x1CEB4AC", VA = "0x1CEB4AC", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060128CF RID: 75983 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128CF")]
		[Address(RVA = "0x1CEB578", Offset = "0x1CEB578", VA = "0x1CEB578", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060128D0 RID: 75984 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128D0")]
		[Address(RVA = "0x1CEB648", Offset = "0x1CEB648", VA = "0x1CEB648", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EAC2 RID: 60098
		[Token(Token = "0x400EAC2")]
		[FieldOffset(Offset = "0x18")]
		private readonly Action<Action<bool>> loginComplete;

		// Token: 0x0400EAC3 RID: 60099
		[Token(Token = "0x400EAC3")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action<bool> loginCallback;

		// Token: 0x0400EAC4 RID: 60100
		[Token(Token = "0x400EAC4")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action initComplete;
	}
}
