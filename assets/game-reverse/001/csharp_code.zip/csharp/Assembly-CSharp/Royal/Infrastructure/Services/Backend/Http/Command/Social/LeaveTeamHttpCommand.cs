﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Social
{
	// Token: 0x02002546 RID: 9542
	[Token(Token = "0x2002546")]
	public class LeaveTeamHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002748 RID: 10056
		// (get) Token: 0x06012A74 RID: 76404 RVA: 0x000784B0 File Offset: 0x000766B0
		[Token(Token = "0x17002748")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A74")]
			[Address(RVA = "0x1ECAE9C", Offset = "0x1ECAE9C", VA = "0x1ECAE9C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002749 RID: 10057
		// (get) Token: 0x06012A75 RID: 76405 RVA: 0x000784C8 File Offset: 0x000766C8
		[Token(Token = "0x17002749")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A75")]
			[Address(RVA = "0x1ECAEA4", Offset = "0x1ECAEA4", VA = "0x1ECAEA4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700274A RID: 10058
		// (get) Token: 0x06012A76 RID: 76406 RVA: 0x000784E0 File Offset: 0x000766E0
		// (set) Token: 0x06012A77 RID: 76407 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700274A")]
		private LeaveTeamResponse Response
		{
			[Token(Token = "0x6012A76")]
			[Address(RVA = "0x1ECAEAC", Offset = "0x1ECAEAC", VA = "0x1ECAEAC")]
			get
			{
				return default(LeaveTeamResponse);
			}
			[Token(Token = "0x6012A77")]
			[Address(RVA = "0x1ECAEB8", Offset = "0x1ECAEB8", VA = "0x1ECAEB8")]
			set
			{
			}
		}

		// Token: 0x06012A78 RID: 76408 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A78")]
		[Address(RVA = "0x1ECAEC8", Offset = "0x1ECAEC8", VA = "0x1ECAEC8")]
		public LeaveTeamHttpCommand(long teamId)
		{
		}

		// Token: 0x06012A79 RID: 76409 RVA: 0x000784F8 File Offset: 0x000766F8
		[Token(Token = "0x6012A79")]
		[Address(RVA = "0x1ECAF78", Offset = "0x1ECAF78", VA = "0x1ECAF78", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A7A RID: 76410 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A7A")]
		[Address(RVA = "0x1ECAF98", Offset = "0x1ECAF98", VA = "0x1ECAF98", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A7B RID: 76411 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A7B")]
		[Address(RVA = "0x1ECB5C8", Offset = "0x1ECB5C8", VA = "0x1ECB5C8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB79 RID: 60281
		[Token(Token = "0x400EB79")]
		[FieldOffset(Offset = "0x18")]
		private LeaveTeamResponse <Response>k__BackingField;

		// Token: 0x0400EB7A RID: 60282
		[Token(Token = "0x400EB7A")]
		[FieldOffset(Offset = "0x28")]
		private readonly long teamId;

		// Token: 0x0400EB7B RID: 60283
		[Token(Token = "0x400EB7B")]
		[FieldOffset(Offset = "0x30")]
		private readonly string teamName;

		// Token: 0x0400EB7C RID: 60284
		[Token(Token = "0x400EB7C")]
		[FieldOffset(Offset = "0x38")]
		private readonly TeamActivityLevel teamActivity;
	}
}
