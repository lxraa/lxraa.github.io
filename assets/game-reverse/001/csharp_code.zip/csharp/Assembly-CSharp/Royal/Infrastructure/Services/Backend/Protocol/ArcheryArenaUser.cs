﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200233D RID: 9021
	[Token(Token = "0x200233D")]
	public struct ArcheryArenaUser : IFlatbufferObject
	{
		// Token: 0x17001EC1 RID: 7873
		// (get) Token: 0x06010B6D RID: 68461 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EC1")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B6D")]
			[Address(RVA = "0x2142A64", Offset = "0x2142A64", VA = "0x2142A64", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B6E RID: 68462 RVA: 0x0005FD90 File Offset: 0x0005DF90
		[Token(Token = "0x6010B6E")]
		[Address(RVA = "0x2142A6C", Offset = "0x2142A6C", VA = "0x2142A6C")]
		public static ArcheryArenaUser GetRootAsArcheryArenaUser(ByteBuffer _bb)
		{
			return default(ArcheryArenaUser);
		}

		// Token: 0x06010B6F RID: 68463 RVA: 0x0005FDA8 File Offset: 0x0005DFA8
		[Token(Token = "0x6010B6F")]
		[Address(RVA = "0x2142A78", Offset = "0x2142A78", VA = "0x2142A78")]
		public static ArcheryArenaUser GetRootAsArcheryArenaUser(ByteBuffer _bb, ArcheryArenaUser obj)
		{
			return default(ArcheryArenaUser);
		}

		// Token: 0x06010B70 RID: 68464 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B70")]
		[Address(RVA = "0x2142AF0", Offset = "0x2142AF0", VA = "0x2142AF0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B71 RID: 68465 RVA: 0x0005FDC0 File Offset: 0x0005DFC0
		[Token(Token = "0x6010B71")]
		[Address(RVA = "0x2142038", Offset = "0x2142038", VA = "0x2142038")]
		public ArcheryArenaUser __assign(int _i, ByteBuffer _bb)
		{
			return default(ArcheryArenaUser);
		}

		// Token: 0x17001EC2 RID: 7874
		// (get) Token: 0x06010B72 RID: 68466 RVA: 0x0005FDD8 File Offset: 0x0005DFD8
		[Token(Token = "0x17001EC2")]
		public long UserId
		{
			[Token(Token = "0x6010B72")]
			[Address(RVA = "0x2142B00", Offset = "0x2142B00", VA = "0x2142B00")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001EC3 RID: 7875
		// (get) Token: 0x06010B73 RID: 68467 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EC3")]
		public string Name
		{
			[Token(Token = "0x6010B73")]
			[Address(RVA = "0x2142B48", Offset = "0x2142B48", VA = "0x2142B48")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B74 RID: 68468 RVA: 0x0005FDF0 File Offset: 0x0005DFF0
		[Token(Token = "0x6010B74")]
		[Address(RVA = "0x2142B84", Offset = "0x2142B84", VA = "0x2142B84")]
		public ArraySegment<byte>? GetNameBytes()
		{
			return null;
		}

		// Token: 0x06010B75 RID: 68469 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010B75")]
		[Address(RVA = "0x2142BBC", Offset = "0x2142BBC", VA = "0x2142BBC")]
		public byte[] GetNameArray()
		{
			return null;
		}

		// Token: 0x17001EC4 RID: 7876
		// (get) Token: 0x06010B76 RID: 68470 RVA: 0x0005FE08 File Offset: 0x0005E008
		[Token(Token = "0x17001EC4")]
		public int Score
		{
			[Token(Token = "0x6010B76")]
			[Address(RVA = "0x2142C08", Offset = "0x2142C08", VA = "0x2142C08")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EC5 RID: 7877
		// (get) Token: 0x06010B77 RID: 68471 RVA: 0x0005FE20 File Offset: 0x0005E020
		[Token(Token = "0x17001EC5")]
		public long LastUpdateDate
		{
			[Token(Token = "0x6010B77")]
			[Address(RVA = "0x2142C4C", Offset = "0x2142C4C", VA = "0x2142C4C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001EC6 RID: 7878
		// (get) Token: 0x06010B78 RID: 68472 RVA: 0x0005FE38 File Offset: 0x0005E038
		[Token(Token = "0x17001EC6")]
		public bool DeprecatedIsGold
		{
			[Token(Token = "0x6010B78")]
			[Address(RVA = "0x2142C94", Offset = "0x2142C94", VA = "0x2142C94")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001EC7 RID: 7879
		// (get) Token: 0x06010B79 RID: 68473 RVA: 0x0005FE50 File Offset: 0x0005E050
		[Token(Token = "0x17001EC7")]
		public bool HasSpecialNameStyle
		{
			[Token(Token = "0x6010B79")]
			[Address(RVA = "0x2142CDC", Offset = "0x2142CDC", VA = "0x2142CDC")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001EC8 RID: 7880
		// (get) Token: 0x06010B7A RID: 68474 RVA: 0x0005FE68 File Offset: 0x0005E068
		[Token(Token = "0x17001EC8")]
		public ProfileSetting? ProfileSetting
		{
			[Token(Token = "0x6010B7A")]
			[Address(RVA = "0x2142D24", Offset = "0x2142D24", VA = "0x2142D24")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B7B RID: 68475 RVA: 0x0005FE80 File Offset: 0x0005E080
		[Token(Token = "0x6010B7B")]
		[Address(RVA = "0x2142DE4", Offset = "0x2142DE4", VA = "0x2142DE4")]
		public static Offset<ArcheryArenaUser> CreateArcheryArenaUser(FlatBufferBuilder builder, long user_id = 0L, [Optional] StringOffset nameOffset, int score = 0, long last_update_date = 0L, bool deprecated_is_gold = false, bool has_special_name_style = false, [Optional] Offset<ProfileSetting> profile_settingOffset)
		{
			return default(Offset<ArcheryArenaUser>);
		}

		// Token: 0x06010B7C RID: 68476 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B7C")]
		[Address(RVA = "0x2142FF0", Offset = "0x2142FF0", VA = "0x2142FF0")]
		public static void StartArcheryArenaUser(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B7D RID: 68477 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B7D")]
		[Address(RVA = "0x2142EC4", Offset = "0x2142EC4", VA = "0x2142EC4")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010B7E RID: 68478 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B7E")]
		[Address(RVA = "0x2142F24", Offset = "0x2142F24", VA = "0x2142F24")]
		public static void AddName(FlatBufferBuilder builder, StringOffset nameOffset)
		{
		}

		// Token: 0x06010B7F RID: 68479 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B7F")]
		[Address(RVA = "0x2142F04", Offset = "0x2142F04", VA = "0x2142F04")]
		public static void AddScore(FlatBufferBuilder builder, int score)
		{
		}

		// Token: 0x06010B80 RID: 68480 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B80")]
		[Address(RVA = "0x2142EA4", Offset = "0x2142EA4", VA = "0x2142EA4")]
		public static void AddLastUpdateDate(FlatBufferBuilder builder, long lastUpdateDate)
		{
		}

		// Token: 0x06010B81 RID: 68481 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B81")]
		[Address(RVA = "0x2142F64", Offset = "0x2142F64", VA = "0x2142F64")]
		public static void AddDeprecatedIsGold(FlatBufferBuilder builder, bool deprecatedIsGold)
		{
		}

		// Token: 0x06010B82 RID: 68482 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B82")]
		[Address(RVA = "0x2142F44", Offset = "0x2142F44", VA = "0x2142F44")]
		public static void AddHasSpecialNameStyle(FlatBufferBuilder builder, bool hasSpecialNameStyle)
		{
		}

		// Token: 0x06010B83 RID: 68483 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B83")]
		[Address(RVA = "0x2142EE4", Offset = "0x2142EE4", VA = "0x2142EE4")]
		public static void AddProfileSetting(FlatBufferBuilder builder, Offset<ProfileSetting> profileSettingOffset)
		{
		}

		// Token: 0x06010B84 RID: 68484 RVA: 0x0005FE98 File Offset: 0x0005E098
		[Token(Token = "0x6010B84")]
		[Address(RVA = "0x2142F84", Offset = "0x2142F84", VA = "0x2142F84")]
		public static Offset<ArcheryArenaUser> EndArcheryArenaUser(FlatBufferBuilder builder)
		{
			return default(Offset<ArcheryArenaUser>);
		}

		// Token: 0x0400E61E RID: 58910
		[Token(Token = "0x400E61E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
