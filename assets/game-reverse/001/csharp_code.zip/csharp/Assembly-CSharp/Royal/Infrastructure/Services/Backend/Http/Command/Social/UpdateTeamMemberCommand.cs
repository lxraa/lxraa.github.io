﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Social
{
	// Token: 0x02002548 RID: 9544
	[Token(Token = "0x2002548")]
	public class UpdateTeamMemberCommand : BaseHttpCommand
	{
		// Token: 0x1700274E RID: 10062
		// (get) Token: 0x06012A84 RID: 76420 RVA: 0x00078570 File Offset: 0x00076770
		[Token(Token = "0x1700274E")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A84")]
			[Address(RVA = "0x1ECB780", Offset = "0x1ECB780", VA = "0x1ECB780", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700274F RID: 10063
		// (get) Token: 0x06012A85 RID: 76421 RVA: 0x00078588 File Offset: 0x00076788
		[Token(Token = "0x1700274F")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A85")]
			[Address(RVA = "0x1ECB788", Offset = "0x1ECB788", VA = "0x1ECB788", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A86 RID: 76422 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A86")]
		[Address(RVA = "0x1ECB790", Offset = "0x1ECB790", VA = "0x1ECB790")]
		public UpdateTeamMemberCommand(long teamId, long userId, TeamMemberOperationType type)
		{
		}

		// Token: 0x06012A87 RID: 76423 RVA: 0x000785A0 File Offset: 0x000767A0
		[Token(Token = "0x6012A87")]
		[Address(RVA = "0x1ECB7CC", Offset = "0x1ECB7CC", VA = "0x1ECB7CC", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A88 RID: 76424 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A88")]
		[Address(RVA = "0x1ECB7F0", Offset = "0x1ECB7F0", VA = "0x1ECB7F0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A89 RID: 76425 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A89")]
		[Address(RVA = "0x1ECB9EC", Offset = "0x1ECB9EC", VA = "0x1ECB9EC", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB7F RID: 60287
		[Token(Token = "0x400EB7F")]
		[FieldOffset(Offset = "0x18")]
		private readonly long teamId;

		// Token: 0x0400EB80 RID: 60288
		[Token(Token = "0x400EB80")]
		[FieldOffset(Offset = "0x20")]
		private readonly long userId;

		// Token: 0x0400EB81 RID: 60289
		[Token(Token = "0x400EB81")]
		[FieldOffset(Offset = "0x28")]
		private readonly TeamMemberOperationType type;
	}
}
