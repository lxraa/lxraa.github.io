﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200239A RID: 9114
	[Token(Token = "0x200239A")]
	public struct EnterArcheryArenaResponse : IFlatbufferObject
	{
		// Token: 0x1700202A RID: 8234
		// (get) Token: 0x060110B6 RID: 69814 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700202A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60110B6")]
			[Address(RVA = "0x1F9BD44", Offset = "0x1F9BD44", VA = "0x1F9BD44", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110B7 RID: 69815 RVA: 0x00064200 File Offset: 0x00062400
		[Token(Token = "0x60110B7")]
		[Address(RVA = "0x1F9BD4C", Offset = "0x1F9BD4C", VA = "0x1F9BD4C")]
		public static EnterArcheryArenaResponse GetRootAsEnterArcheryArenaResponse(ByteBuffer _bb)
		{
			return default(EnterArcheryArenaResponse);
		}

		// Token: 0x060110B8 RID: 69816 RVA: 0x00064218 File Offset: 0x00062418
		[Token(Token = "0x60110B8")]
		[Address(RVA = "0x1F9BD58", Offset = "0x1F9BD58", VA = "0x1F9BD58")]
		public static EnterArcheryArenaResponse GetRootAsEnterArcheryArenaResponse(ByteBuffer _bb, EnterArcheryArenaResponse obj)
		{
			return default(EnterArcheryArenaResponse);
		}

		// Token: 0x060110B9 RID: 69817 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110B9")]
		[Address(RVA = "0x1F9BE08", Offset = "0x1F9BE08", VA = "0x1F9BE08", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060110BA RID: 69818 RVA: 0x00064230 File Offset: 0x00062430
		[Token(Token = "0x60110BA")]
		[Address(RVA = "0x1F9BDD0", Offset = "0x1F9BDD0", VA = "0x1F9BDD0")]
		public EnterArcheryArenaResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterArcheryArenaResponse);
		}

		// Token: 0x1700202B RID: 8235
		// (get) Token: 0x060110BB RID: 69819 RVA: 0x00064248 File Offset: 0x00062448
		[Token(Token = "0x1700202B")]
		public short Segment
		{
			[Token(Token = "0x60110BB")]
			[Address(RVA = "0x1F9BE18", Offset = "0x1F9BE18", VA = "0x1F9BE18")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700202C RID: 8236
		// (get) Token: 0x060110BC RID: 69820 RVA: 0x00064260 File Offset: 0x00062460
		[Token(Token = "0x1700202C")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x60110BC")]
			[Address(RVA = "0x1F9BE5C", Offset = "0x1F9BE5C", VA = "0x1F9BE5C")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x1700202D RID: 8237
		// (get) Token: 0x060110BD RID: 69821 RVA: 0x00064278 File Offset: 0x00062478
		[Token(Token = "0x1700202D")]
		public ArcheryArenaFailReason FailReason
		{
			[Token(Token = "0x60110BD")]
			[Address(RVA = "0x1F9BEA0", Offset = "0x1F9BEA0", VA = "0x1F9BEA0")]
			get
			{
				return ArcheryArenaFailReason.None;
			}
		}

		// Token: 0x1700202E RID: 8238
		// (get) Token: 0x060110BE RID: 69822 RVA: 0x00064290 File Offset: 0x00062490
		[Token(Token = "0x1700202E")]
		public ArcheryArenaInfo? ArcheryArenaInfo
		{
			[Token(Token = "0x60110BE")]
			[Address(RVA = "0x1F9BEE4", Offset = "0x1F9BEE4", VA = "0x1F9BEE4")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700202F RID: 8239
		// (get) Token: 0x060110BF RID: 69823 RVA: 0x000642A8 File Offset: 0x000624A8
		[Token(Token = "0x1700202F")]
		public ArcheryArenaGroupInfo? ArcheryArenaGroupInfo
		{
			[Token(Token = "0x60110BF")]
			[Address(RVA = "0x1F9BFA4", Offset = "0x1F9BFA4", VA = "0x1F9BFA4")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110C0 RID: 69824 RVA: 0x000642C0 File Offset: 0x000624C0
		[Token(Token = "0x60110C0")]
		[Address(RVA = "0x1F9C064", Offset = "0x1F9C064", VA = "0x1F9C064")]
		public static Offset<EnterArcheryArenaResponse> CreateEnterArcheryArenaResponse(FlatBufferBuilder builder, short segment = 0, ResponseStatusCode status = ResponseStatusCode.Success, ArcheryArenaFailReason fail_reason = ArcheryArenaFailReason.None, [Optional] Offset<ArcheryArenaInfo> archery_arena_infoOffset, [Optional] Offset<ArcheryArenaGroupInfo> archery_arena_group_infoOffset)
		{
			return default(Offset<EnterArcheryArenaResponse>);
		}

		// Token: 0x060110C1 RID: 69825 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110C1")]
		[Address(RVA = "0x1F9C208", Offset = "0x1F9C208", VA = "0x1F9C208")]
		public static void StartEnterArcheryArenaResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060110C2 RID: 69826 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110C2")]
		[Address(RVA = "0x1F9C13C", Offset = "0x1F9C13C", VA = "0x1F9C13C")]
		public static void AddSegment(FlatBufferBuilder builder, short segment)
		{
		}

		// Token: 0x060110C3 RID: 69827 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110C3")]
		[Address(RVA = "0x1F9C17C", Offset = "0x1F9C17C", VA = "0x1F9C17C")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x060110C4 RID: 69828 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110C4")]
		[Address(RVA = "0x1F9C15C", Offset = "0x1F9C15C", VA = "0x1F9C15C")]
		public static void AddFailReason(FlatBufferBuilder builder, ArcheryArenaFailReason failReason)
		{
		}

		// Token: 0x060110C5 RID: 69829 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110C5")]
		[Address(RVA = "0x1F9C11C", Offset = "0x1F9C11C", VA = "0x1F9C11C")]
		public static void AddArcheryArenaInfo(FlatBufferBuilder builder, Offset<ArcheryArenaInfo> archeryArenaInfoOffset)
		{
		}

		// Token: 0x060110C6 RID: 69830 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110C6")]
		[Address(RVA = "0x1F9C0FC", Offset = "0x1F9C0FC", VA = "0x1F9C0FC")]
		public static void AddArcheryArenaGroupInfo(FlatBufferBuilder builder, Offset<ArcheryArenaGroupInfo> archeryArenaGroupInfoOffset)
		{
		}

		// Token: 0x060110C7 RID: 69831 RVA: 0x000642D8 File Offset: 0x000624D8
		[Token(Token = "0x60110C7")]
		[Address(RVA = "0x1F9C19C", Offset = "0x1F9C19C", VA = "0x1F9C19C")]
		public static Offset<EnterArcheryArenaResponse> EndEnterArcheryArenaResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterArcheryArenaResponse>);
		}

		// Token: 0x0400E6BB RID: 59067
		[Token(Token = "0x400E6BB")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
