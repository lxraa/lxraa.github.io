﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend
{
	// Token: 0x02002322 RID: 8994
	[Token(Token = "0x2002322")]
	public static class BackendHelper
	{
		// Token: 0x06010A6E RID: 68206 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010A6E")]
		[Address(RVA = "0x2492630", Offset = "0x2492630", VA = "0x2492630")]
		public static void ConfigureBackendCommunicationLogging(ClientSettings clientSettings, object callerClass)
		{
		}

		// Token: 0x06010A6F RID: 68207 RVA: 0x0005F550 File Offset: 0x0005D750
		[Token(Token = "0x6010A6F")]
		[Address(RVA = "0x24927A8", Offset = "0x24927A8", VA = "0x24927A8")]
		public static bool GetBackendCommunicationLoggingEnabledFlag()
		{
			return default(bool);
		}

		// Token: 0x06010A70 RID: 68208 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010A70")]
		[Address(RVA = "0x2492804", Offset = "0x2492804", VA = "0x2492804")]
		private static void FillFromLocal()
		{
		}

		// Token: 0x0400E5BD RID: 58813
		[Token(Token = "0x400E5BD")]
		[FieldOffset(Offset = "0x0")]
		private static bool IsFlagAlreadySet;

		// Token: 0x0400E5BE RID: 58814
		[Token(Token = "0x400E5BE")]
		[FieldOffset(Offset = "0x1")]
		private static bool BackendCommunicationLoggingEnabled;
	}
}
