﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200239E RID: 9118
	[Token(Token = "0x200239E")]
	public enum EnterEventFailReason : sbyte
	{
		// Token: 0x0400E6C4 RID: 59076
		[Token(Token = "0x400E6C4")]
		None,
		// Token: 0x0400E6C5 RID: 59077
		[Token(Token = "0x400E6C5")]
		NotActive,
		// Token: 0x0400E6C6 RID: 59078
		[Token(Token = "0x400E6C6")]
		IsAboutToEnd,
		// Token: 0x0400E6C7 RID: 59079
		[Token(Token = "0x400E6C7")]
		InvalidUser
	}
}
