﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D1 RID: 9169
	[Token(Token = "0x20023D1")]
	public struct GetEventInfoResponse : IFlatbufferObject
	{
		// Token: 0x170020EA RID: 8426
		// (get) Token: 0x06011385 RID: 70533 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020EA")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011385")]
			[Address(RVA = "0x1CAEF74", Offset = "0x1CAEF74", VA = "0x1CAEF74", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011386 RID: 70534 RVA: 0x00066798 File Offset: 0x00064998
		[Token(Token = "0x6011386")]
		[Address(RVA = "0x1CAEF7C", Offset = "0x1CAEF7C", VA = "0x1CAEF7C")]
		public static GetEventInfoResponse GetRootAsGetEventInfoResponse(ByteBuffer _bb)
		{
			return default(GetEventInfoResponse);
		}

		// Token: 0x06011387 RID: 70535 RVA: 0x000667B0 File Offset: 0x000649B0
		[Token(Token = "0x6011387")]
		[Address(RVA = "0x1CAEF88", Offset = "0x1CAEF88", VA = "0x1CAEF88")]
		public static GetEventInfoResponse GetRootAsGetEventInfoResponse(ByteBuffer _bb, GetEventInfoResponse obj)
		{
			return default(GetEventInfoResponse);
		}

		// Token: 0x06011388 RID: 70536 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011388")]
		[Address(RVA = "0x1CAF038", Offset = "0x1CAF038", VA = "0x1CAF038", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011389 RID: 70537 RVA: 0x000667C8 File Offset: 0x000649C8
		[Token(Token = "0x6011389")]
		[Address(RVA = "0x1CAF000", Offset = "0x1CAF000", VA = "0x1CAF000")]
		public GetEventInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetEventInfoResponse);
		}

		// Token: 0x170020EB RID: 8427
		// (get) Token: 0x0601138A RID: 70538 RVA: 0x000667E0 File Offset: 0x000649E0
		[Token(Token = "0x170020EB")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x601138A")]
			[Address(RVA = "0x1CAF048", Offset = "0x1CAF048", VA = "0x1CAF048")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x170020EC RID: 8428
		// (get) Token: 0x0601138B RID: 70539 RVA: 0x000667F8 File Offset: 0x000649F8
		[Token(Token = "0x170020EC")]
		public WorldCupInfo? WorldCupServerEventInfo
		{
			[Token(Token = "0x601138B")]
			[Address(RVA = "0x1CAF08C", Offset = "0x1CAF08C", VA = "0x1CAF08C")]
			get
			{
				return null;
			}
		}

		// Token: 0x170020ED RID: 8429
		// (get) Token: 0x0601138C RID: 70540 RVA: 0x00066810 File Offset: 0x00064A10
		[Token(Token = "0x170020ED")]
		public DynamicOfferInfoOld? DynamicOfferEventInfo
		{
			[Token(Token = "0x601138C")]
			[Address(RVA = "0x1CAF14C", Offset = "0x1CAF14C", VA = "0x1CAF14C")]
			get
			{
				return null;
			}
		}

		// Token: 0x170020EE RID: 8430
		// (get) Token: 0x0601138D RID: 70541 RVA: 0x00066828 File Offset: 0x00064A28
		[Token(Token = "0x170020EE")]
		public LavaQuestInfo? LavaQuestInfo
		{
			[Token(Token = "0x601138D")]
			[Address(RVA = "0x1CAF20C", Offset = "0x1CAF20C", VA = "0x1CAF20C")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601138E RID: 70542 RVA: 0x00066840 File Offset: 0x00064A40
		[Token(Token = "0x601138E")]
		[Address(RVA = "0x1CAF2CC", Offset = "0x1CAF2CC", VA = "0x1CAF2CC")]
		public DynamicOfferInfo? DynamicOfferEventInfoList(int j)
		{
			return null;
		}

		// Token: 0x170020EF RID: 8431
		// (get) Token: 0x0601138F RID: 70543 RVA: 0x00066858 File Offset: 0x00064A58
		[Token(Token = "0x170020EF")]
		public int DynamicOfferEventInfoListLength
		{
			[Token(Token = "0x601138F")]
			[Address(RVA = "0x1CAF3A4", Offset = "0x1CAF3A4", VA = "0x1CAF3A4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011390 RID: 70544 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011390")]
		[Address(RVA = "0x1CAF3D8", Offset = "0x1CAF3D8", VA = "0x1CAF3D8")]
		public string DynamicOfferDisableFlags(int j)
		{
			return null;
		}

		// Token: 0x170020F0 RID: 8432
		// (get) Token: 0x06011391 RID: 70545 RVA: 0x00066870 File Offset: 0x00064A70
		[Token(Token = "0x170020F0")]
		public int DynamicOfferDisableFlagsLength
		{
			[Token(Token = "0x6011391")]
			[Address(RVA = "0x1CAF430", Offset = "0x1CAF430", VA = "0x1CAF430")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020F1 RID: 8433
		// (get) Token: 0x06011392 RID: 70546 RVA: 0x00066888 File Offset: 0x00064A88
		[Token(Token = "0x170020F1")]
		public UserDynamicSegmentInfo? UserDynamicSegmentInfo
		{
			[Token(Token = "0x6011392")]
			[Address(RVA = "0x1CAF464", Offset = "0x1CAF464", VA = "0x1CAF464")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011393 RID: 70547 RVA: 0x000668A0 File Offset: 0x00064AA0
		[Token(Token = "0x6011393")]
		[Address(RVA = "0x1CAF524", Offset = "0x1CAF524", VA = "0x1CAF524")]
		public static Offset<GetEventInfoResponse> CreateGetEventInfoResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, [Optional] Offset<WorldCupInfo> world_cup_server_event_infoOffset, [Optional] Offset<DynamicOfferInfoOld> dynamic_offer_event_infoOffset, [Optional] Offset<LavaQuestInfo> lava_quest_infoOffset, [Optional] VectorOffset dynamic_offer_event_info_listOffset, [Optional] VectorOffset dynamic_offer_disable_flagsOffset, [Optional] Offset<UserDynamicSegmentInfo> user_dynamic_segment_infoOffset)
		{
			return default(Offset<GetEventInfoResponse>);
		}

		// Token: 0x06011394 RID: 70548 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011394")]
		[Address(RVA = "0x1CAF730", Offset = "0x1CAF730", VA = "0x1CAF730")]
		public static void StartGetEventInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011395 RID: 70549 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011395")]
		[Address(RVA = "0x1CAF6A4", Offset = "0x1CAF6A4", VA = "0x1CAF6A4")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06011396 RID: 70550 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011396")]
		[Address(RVA = "0x1CAF684", Offset = "0x1CAF684", VA = "0x1CAF684")]
		public static void AddWorldCupServerEventInfo(FlatBufferBuilder builder, Offset<WorldCupInfo> worldCupServerEventInfoOffset)
		{
		}

		// Token: 0x06011397 RID: 70551 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011397")]
		[Address(RVA = "0x1CAF664", Offset = "0x1CAF664", VA = "0x1CAF664")]
		public static void AddDynamicOfferEventInfo(FlatBufferBuilder builder, Offset<DynamicOfferInfoOld> dynamicOfferEventInfoOffset)
		{
		}

		// Token: 0x06011398 RID: 70552 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011398")]
		[Address(RVA = "0x1CAF644", Offset = "0x1CAF644", VA = "0x1CAF644")]
		public static void AddLavaQuestInfo(FlatBufferBuilder builder, Offset<LavaQuestInfo> lavaQuestInfoOffset)
		{
		}

		// Token: 0x06011399 RID: 70553 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011399")]
		[Address(RVA = "0x1CAF624", Offset = "0x1CAF624", VA = "0x1CAF624")]
		public static void AddDynamicOfferEventInfoList(FlatBufferBuilder builder, VectorOffset dynamicOfferEventInfoListOffset)
		{
		}

		// Token: 0x0601139A RID: 70554 RVA: 0x000668B8 File Offset: 0x00064AB8
		[Token(Token = "0x601139A")]
		[Address(RVA = "0x1CAF748", Offset = "0x1CAF748", VA = "0x1CAF748")]
		public static VectorOffset CreateDynamicOfferEventInfoListVector(FlatBufferBuilder builder, Offset<DynamicOfferInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601139B RID: 70555 RVA: 0x000668D0 File Offset: 0x00064AD0
		[Token(Token = "0x601139B")]
		[Address(RVA = "0x1CAF7F0", Offset = "0x1CAF7F0", VA = "0x1CAF7F0")]
		public static VectorOffset CreateDynamicOfferEventInfoListVectorBlock(FlatBufferBuilder builder, Offset<DynamicOfferInfo>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601139C RID: 70556 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601139C")]
		[Address(RVA = "0x1CAF878", Offset = "0x1CAF878", VA = "0x1CAF878")]
		public static void StartDynamicOfferEventInfoListVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x0601139D RID: 70557 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601139D")]
		[Address(RVA = "0x1CAF604", Offset = "0x1CAF604", VA = "0x1CAF604")]
		public static void AddDynamicOfferDisableFlags(FlatBufferBuilder builder, VectorOffset dynamicOfferDisableFlagsOffset)
		{
		}

		// Token: 0x0601139E RID: 70558 RVA: 0x000668E8 File Offset: 0x00064AE8
		[Token(Token = "0x601139E")]
		[Address(RVA = "0x1CAF898", Offset = "0x1CAF898", VA = "0x1CAF898")]
		public static VectorOffset CreateDynamicOfferDisableFlagsVector(FlatBufferBuilder builder, StringOffset[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x0601139F RID: 70559 RVA: 0x00066900 File Offset: 0x00064B00
		[Token(Token = "0x601139F")]
		[Address(RVA = "0x1CAF940", Offset = "0x1CAF940", VA = "0x1CAF940")]
		public static VectorOffset CreateDynamicOfferDisableFlagsVectorBlock(FlatBufferBuilder builder, StringOffset[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x060113A0 RID: 70560 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113A0")]
		[Address(RVA = "0x1CAF9C8", Offset = "0x1CAF9C8", VA = "0x1CAF9C8")]
		public static void StartDynamicOfferDisableFlagsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x060113A1 RID: 70561 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113A1")]
		[Address(RVA = "0x1CAF5E4", Offset = "0x1CAF5E4", VA = "0x1CAF5E4")]
		public static void AddUserDynamicSegmentInfo(FlatBufferBuilder builder, Offset<UserDynamicSegmentInfo> userDynamicSegmentInfoOffset)
		{
		}

		// Token: 0x060113A2 RID: 70562 RVA: 0x00066918 File Offset: 0x00064B18
		[Token(Token = "0x60113A2")]
		[Address(RVA = "0x1CAF6C4", Offset = "0x1CAF6C4", VA = "0x1CAF6C4")]
		public static Offset<GetEventInfoResponse> EndGetEventInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetEventInfoResponse>);
		}

		// Token: 0x0400E741 RID: 59201
		[Token(Token = "0x400E741")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
