﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025BE RID: 9662
	[Token(Token = "0x20025BE")]
	public static class AppManagerDelegates
	{
		// Token: 0x140000A0 RID: 160
		// (add) Token: 0x06012E70 RID: 77424 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012E71 RID: 77425 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A0")]
		public static event AppManagerDelegates.AppLifecycleDelegate OnApplicationStart
		{
			[Token(Token = "0x6012E70")]
			[Address(RVA = "0x244DB80", Offset = "0x244DB80", VA = "0x244DB80")]
			add
			{
			}
			[Token(Token = "0x6012E71")]
			[Address(RVA = "0x244DCA8", Offset = "0x244DCA8", VA = "0x244DCA8")]
			remove
			{
			}
		}

		// Token: 0x140000A1 RID: 161
		// (add) Token: 0x06012E72 RID: 77426 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012E73 RID: 77427 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A1")]
		public static event AppManagerDelegates.AppLifecycleDelegate OnApplicationQuit
		{
			[Token(Token = "0x6012E72")]
			[Address(RVA = "0x244DD28", Offset = "0x244DD28", VA = "0x244DD28")]
			add
			{
			}
			[Token(Token = "0x6012E73")]
			[Address(RVA = "0x244DE50", Offset = "0x244DE50", VA = "0x244DE50")]
			remove
			{
			}
		}

		// Token: 0x140000A2 RID: 162
		// (add) Token: 0x06012E74 RID: 77428 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012E75 RID: 77429 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A2")]
		public static event AppManagerDelegates.AppLifecycleDelegate OnApplicationPause
		{
			[Token(Token = "0x6012E74")]
			[Address(RVA = "0x244DED0", Offset = "0x244DED0", VA = "0x244DED0")]
			add
			{
			}
			[Token(Token = "0x6012E75")]
			[Address(RVA = "0x244DFF8", Offset = "0x244DFF8", VA = "0x244DFF8")]
			remove
			{
			}
		}

		// Token: 0x140000A3 RID: 163
		// (add) Token: 0x06012E76 RID: 77430 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012E77 RID: 77431 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A3")]
		public static event AppManagerDelegates.AppLifecycleDelegate OnApplicationResume
		{
			[Token(Token = "0x6012E76")]
			[Address(RVA = "0x2441EA0", Offset = "0x2441EA0", VA = "0x2441EA0")]
			add
			{
			}
			[Token(Token = "0x6012E77")]
			[Address(RVA = "0x244E078", Offset = "0x244E078", VA = "0x244E078")]
			remove
			{
			}
		}

		// Token: 0x06012E78 RID: 77432 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E78")]
		[Address(RVA = "0x244C154", Offset = "0x244C154", VA = "0x244C154")]
		public static void CallStartListeners()
		{
		}

		// Token: 0x06012E79 RID: 77433 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E79")]
		[Address(RVA = "0x244D130", Offset = "0x244D130", VA = "0x244D130")]
		public static void CallPauseListeners()
		{
		}

		// Token: 0x06012E7A RID: 77434 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E7A")]
		[Address(RVA = "0x244D738", Offset = "0x244D738", VA = "0x244D738")]
		public static void CallResumeListeners()
		{
		}

		// Token: 0x06012E7B RID: 77435 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E7B")]
		[Address(RVA = "0x244C7E8", Offset = "0x244C7E8", VA = "0x244C7E8")]
		public static void CallQuitListeners()
		{
		}

		// Token: 0x06012E7C RID: 77436 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E7C")]
		[Address(RVA = "0x244C858", Offset = "0x244C858", VA = "0x244C858")]
		public static void Clear()
		{
		}

		// Token: 0x06012E7D RID: 77437 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E7D")]
		[Address(RVA = "0x244E0F8", Offset = "0x244E0F8", VA = "0x244E0F8")]
		private static void InvokeListenerMethod(List<AppManagerDelegates.AppLifecycleDelegate> listeners, string eventName)
		{
		}

		// Token: 0x06012E7E RID: 77438 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E7E")]
		[Address(RVA = "0x244E738", Offset = "0x244E738", VA = "0x244E738")]
		private static void MoveMethodsToTempList(List<AppManagerDelegates.AppLifecycleDelegate> orgListener)
		{
		}

		// Token: 0x0400EE95 RID: 61077
		[Token(Token = "0x400EE95")]
		[FieldOffset(Offset = "0x0")]
		private static readonly List<AppManagerDelegates.AppLifecycleDelegate> StartListeners;

		// Token: 0x0400EE96 RID: 61078
		[Token(Token = "0x400EE96")]
		[FieldOffset(Offset = "0x8")]
		private static readonly List<AppManagerDelegates.AppLifecycleDelegate> ResumeListeners;

		// Token: 0x0400EE97 RID: 61079
		[Token(Token = "0x400EE97")]
		[FieldOffset(Offset = "0x10")]
		private static readonly List<AppManagerDelegates.AppLifecycleDelegate> PauseListeners;

		// Token: 0x0400EE98 RID: 61080
		[Token(Token = "0x400EE98")]
		[FieldOffset(Offset = "0x18")]
		private static readonly List<AppManagerDelegates.AppLifecycleDelegate> QuitListeners;

		// Token: 0x0400EE99 RID: 61081
		[Token(Token = "0x400EE99")]
		[FieldOffset(Offset = "0x20")]
		private static readonly List<AppManagerDelegates.AppLifecycleDelegate> MissingMethods;

		// Token: 0x0400EE9A RID: 61082
		[Token(Token = "0x400EE9A")]
		[FieldOffset(Offset = "0x28")]
		private static readonly List<AppManagerDelegates.AppLifecycleDelegate> TemporaryListHolder;

		// Token: 0x020025BF RID: 9663
		// (Invoke) Token: 0x06012E81 RID: 77441
		[Token(Token = "0x20025BF")]
		public delegate void AppLifecycleDelegate();
	}
}
