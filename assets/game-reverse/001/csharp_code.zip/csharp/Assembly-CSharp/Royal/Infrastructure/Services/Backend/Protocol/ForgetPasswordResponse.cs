﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B8 RID: 9144
	[Token(Token = "0x20023B8")]
	public struct ForgetPasswordResponse : IFlatbufferObject
	{
		// Token: 0x17002094 RID: 8340
		// (get) Token: 0x0601123B RID: 70203 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002094")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601123B")]
			[Address(RVA = "0x1CA9D84", Offset = "0x1CA9D84", VA = "0x1CA9D84", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601123C RID: 70204 RVA: 0x00065670 File Offset: 0x00063870
		[Token(Token = "0x601123C")]
		[Address(RVA = "0x1CA9D8C", Offset = "0x1CA9D8C", VA = "0x1CA9D8C")]
		public static ForgetPasswordResponse GetRootAsForgetPasswordResponse(ByteBuffer _bb)
		{
			return default(ForgetPasswordResponse);
		}

		// Token: 0x0601123D RID: 70205 RVA: 0x00065688 File Offset: 0x00063888
		[Token(Token = "0x601123D")]
		[Address(RVA = "0x1CA9D98", Offset = "0x1CA9D98", VA = "0x1CA9D98")]
		public static ForgetPasswordResponse GetRootAsForgetPasswordResponse(ByteBuffer _bb, ForgetPasswordResponse obj)
		{
			return default(ForgetPasswordResponse);
		}

		// Token: 0x0601123E RID: 70206 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601123E")]
		[Address(RVA = "0x1CA9E48", Offset = "0x1CA9E48", VA = "0x1CA9E48", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601123F RID: 70207 RVA: 0x000656A0 File Offset: 0x000638A0
		[Token(Token = "0x601123F")]
		[Address(RVA = "0x1CA9E10", Offset = "0x1CA9E10", VA = "0x1CA9E10")]
		public ForgetPasswordResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ForgetPasswordResponse);
		}

		// Token: 0x17002095 RID: 8341
		// (get) Token: 0x06011240 RID: 70208 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002095")]
		public string Email
		{
			[Token(Token = "0x6011240")]
			[Address(RVA = "0x1CA9E58", Offset = "0x1CA9E58", VA = "0x1CA9E58")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011241 RID: 70209 RVA: 0x000656B8 File Offset: 0x000638B8
		[Token(Token = "0x6011241")]
		[Address(RVA = "0x1CA9E94", Offset = "0x1CA9E94", VA = "0x1CA9E94")]
		public ArraySegment<byte>? GetEmailBytes()
		{
			return null;
		}

		// Token: 0x06011242 RID: 70210 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011242")]
		[Address(RVA = "0x1CA9ECC", Offset = "0x1CA9ECC", VA = "0x1CA9ECC")]
		public byte[] GetEmailArray()
		{
			return null;
		}

		// Token: 0x17002096 RID: 8342
		// (get) Token: 0x06011243 RID: 70211 RVA: 0x000656D0 File Offset: 0x000638D0
		[Token(Token = "0x17002096")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6011243")]
			[Address(RVA = "0x1CA9F18", Offset = "0x1CA9F18", VA = "0x1CA9F18")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x06011244 RID: 70212 RVA: 0x000656E8 File Offset: 0x000638E8
		[Token(Token = "0x6011244")]
		[Address(RVA = "0x1CA9F5C", Offset = "0x1CA9F5C", VA = "0x1CA9F5C")]
		public static Offset<ForgetPasswordResponse> CreateForgetPasswordResponse(FlatBufferBuilder builder, [Optional] StringOffset emailOffset, ResponseStatusCode status = ResponseStatusCode.Success)
		{
			return default(Offset<ForgetPasswordResponse>);
		}

		// Token: 0x06011245 RID: 70213 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011245")]
		[Address(RVA = "0x1CAA060", Offset = "0x1CAA060", VA = "0x1CAA060")]
		public static void StartForgetPasswordResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011246 RID: 70214 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011246")]
		[Address(RVA = "0x1CA9FB4", Offset = "0x1CA9FB4", VA = "0x1CA9FB4")]
		public static void AddEmail(FlatBufferBuilder builder, StringOffset emailOffset)
		{
		}

		// Token: 0x06011247 RID: 70215 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011247")]
		[Address(RVA = "0x1CA9FD4", Offset = "0x1CA9FD4", VA = "0x1CA9FD4")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06011248 RID: 70216 RVA: 0x00065700 File Offset: 0x00063900
		[Token(Token = "0x6011248")]
		[Address(RVA = "0x1CA9FF4", Offset = "0x1CA9FF4", VA = "0x1CA9FF4")]
		public static Offset<ForgetPasswordResponse> EndForgetPasswordResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ForgetPasswordResponse>);
		}

		// Token: 0x0400E6EF RID: 59119
		[Token(Token = "0x400E6EF")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
