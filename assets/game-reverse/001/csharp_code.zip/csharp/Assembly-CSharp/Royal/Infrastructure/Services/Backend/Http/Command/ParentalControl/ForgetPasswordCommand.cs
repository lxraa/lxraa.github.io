﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.ParentalControl
{
	// Token: 0x02002553 RID: 9555
	[Token(Token = "0x2002553")]
	public class ForgetPasswordCommand : BaseHttpCommand
	{
		// Token: 0x17002767 RID: 10087
		// (get) Token: 0x06012ACD RID: 76493 RVA: 0x000788E8 File Offset: 0x00076AE8
		[Token(Token = "0x17002767")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012ACD")]
			[Address(RVA = "0x1ECDC14", Offset = "0x1ECDC14", VA = "0x1ECDC14", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002768 RID: 10088
		// (get) Token: 0x06012ACE RID: 76494 RVA: 0x00078900 File Offset: 0x00076B00
		[Token(Token = "0x17002768")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012ACE")]
			[Address(RVA = "0x1ECDC1C", Offset = "0x1ECDC1C", VA = "0x1ECDC1C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012ACF RID: 76495 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ACF")]
		[Address(RVA = "0x1ECDC24", Offset = "0x1ECDC24", VA = "0x1ECDC24")]
		public ForgetPasswordCommand(Action<ForgetPasswordResponse> onSuccess, Action onFail)
		{
		}

		// Token: 0x06012AD0 RID: 76496 RVA: 0x00078918 File Offset: 0x00076B18
		[Token(Token = "0x6012AD0")]
		[Address(RVA = "0x1ECDC68", Offset = "0x1ECDC68", VA = "0x1ECDC68", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AD1 RID: 76497 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AD1")]
		[Address(RVA = "0x1ECDC90", Offset = "0x1ECDC90", VA = "0x1ECDC90", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AD2 RID: 76498 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AD2")]
		[Address(RVA = "0x1ECDD5C", Offset = "0x1ECDD5C", VA = "0x1ECDD5C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBA3 RID: 60323
		[Token(Token = "0x400EBA3")]
		[FieldOffset(Offset = "0x18")]
		private readonly Action<ForgetPasswordResponse> onSuccess;

		// Token: 0x0400EBA4 RID: 60324
		[Token(Token = "0x400EBA4")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action onFail;
	}
}
