﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TrainJourney
{
	// Token: 0x0200252F RID: 9519
	[Token(Token = "0x200252F")]
	public class GetTrainJourneyInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002712 RID: 10002
		// (get) Token: 0x060129CF RID: 76239 RVA: 0x00077D60 File Offset: 0x00075F60
		[Token(Token = "0x17002712")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129CF")]
			[Address(RVA = "0x1CFAFDC", Offset = "0x1CFAFDC", VA = "0x1CFAFDC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002713 RID: 10003
		// (get) Token: 0x060129D0 RID: 76240 RVA: 0x00077D78 File Offset: 0x00075F78
		[Token(Token = "0x17002713")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129D0")]
			[Address(RVA = "0x1CFAFE4", Offset = "0x1CFAFE4", VA = "0x1CFAFE4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060129D1 RID: 76241 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129D1")]
		[Address(RVA = "0x1CFAFEC", Offset = "0x1CFAFEC", VA = "0x1CFAFEC")]
		public GetTrainJourneyInfoHttpCommand(int eventId, int configVersion, bool fromRefresh)
		{
		}

		// Token: 0x060129D2 RID: 76242 RVA: 0x00077D90 File Offset: 0x00075F90
		[Token(Token = "0x60129D2")]
		[Address(RVA = "0x1CFB0D4", Offset = "0x1CFB0D4", VA = "0x1CFB0D4", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x060129D3 RID: 76243 RVA: 0x00077DA8 File Offset: 0x00075FA8
		[Token(Token = "0x60129D3")]
		[Address(RVA = "0x1CFB1B4", Offset = "0x1CFB1B4", VA = "0x1CFB1B4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129D4 RID: 76244 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129D4")]
		[Address(RVA = "0x1CFB280", Offset = "0x1CFB280", VA = "0x1CFB280", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129D5 RID: 76245 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129D5")]
		[Address(RVA = "0x1CFB398", Offset = "0x1CFB398", VA = "0x1CFB398", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB2C RID: 60204
		[Token(Token = "0x400EB2C")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;

		// Token: 0x0400EB2D RID: 60205
		[Token(Token = "0x400EB2D")]
		[FieldOffset(Offset = "0x18")]
		private readonly int configVersion;

		// Token: 0x0400EB2E RID: 60206
		[Token(Token = "0x400EB2E")]
		[FieldOffset(Offset = "0x1C")]
		private readonly bool fromRefresh;
	}
}
