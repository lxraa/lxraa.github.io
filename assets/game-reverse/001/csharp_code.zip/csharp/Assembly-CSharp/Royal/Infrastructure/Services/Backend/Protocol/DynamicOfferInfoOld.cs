﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002396 RID: 9110
	[Token(Token = "0x2002396")]
	public struct DynamicOfferInfoOld : IFlatbufferObject
	{
		// Token: 0x1700201D RID: 8221
		// (get) Token: 0x06011084 RID: 69764 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700201D")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011084")]
			[Address(RVA = "0x1F9B2C8", Offset = "0x1F9B2C8", VA = "0x1F9B2C8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011085 RID: 69765 RVA: 0x00063F78 File Offset: 0x00062178
		[Token(Token = "0x6011085")]
		[Address(RVA = "0x1F9B2D0", Offset = "0x1F9B2D0", VA = "0x1F9B2D0")]
		public static DynamicOfferInfoOld GetRootAsDynamicOfferInfoOld(ByteBuffer _bb)
		{
			return default(DynamicOfferInfoOld);
		}

		// Token: 0x06011086 RID: 69766 RVA: 0x00063F90 File Offset: 0x00062190
		[Token(Token = "0x6011086")]
		[Address(RVA = "0x1F9B2DC", Offset = "0x1F9B2DC", VA = "0x1F9B2DC")]
		public static DynamicOfferInfoOld GetRootAsDynamicOfferInfoOld(ByteBuffer _bb, DynamicOfferInfoOld obj)
		{
			return default(DynamicOfferInfoOld);
		}

		// Token: 0x06011087 RID: 69767 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011087")]
		[Address(RVA = "0x1F9B38C", Offset = "0x1F9B38C", VA = "0x1F9B38C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011088 RID: 69768 RVA: 0x00063FA8 File Offset: 0x000621A8
		[Token(Token = "0x6011088")]
		[Address(RVA = "0x1F9B354", Offset = "0x1F9B354", VA = "0x1F9B354")]
		public DynamicOfferInfoOld __assign(int _i, ByteBuffer _bb)
		{
			return default(DynamicOfferInfoOld);
		}

		// Token: 0x1700201E RID: 8222
		// (get) Token: 0x06011089 RID: 69769 RVA: 0x00063FC0 File Offset: 0x000621C0
		[Token(Token = "0x1700201E")]
		public int Id
		{
			[Token(Token = "0x6011089")]
			[Address(RVA = "0x1F9B39C", Offset = "0x1F9B39C", VA = "0x1F9B39C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700201F RID: 8223
		// (get) Token: 0x0601108A RID: 69770 RVA: 0x00063FD8 File Offset: 0x000621D8
		[Token(Token = "0x1700201F")]
		public long RemainingTime
		{
			[Token(Token = "0x601108A")]
			[Address(RVA = "0x1F9B3E0", Offset = "0x1F9B3E0", VA = "0x1F9B3E0")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17002020 RID: 8224
		// (get) Token: 0x0601108B RID: 69771 RVA: 0x00063FF0 File Offset: 0x000621F0
		[Token(Token = "0x17002020")]
		public short ConfigVersion
		{
			[Token(Token = "0x601108B")]
			[Address(RVA = "0x1F9B428", Offset = "0x1F9B428", VA = "0x1F9B428")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002021 RID: 8225
		// (get) Token: 0x0601108C RID: 69772 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002021")]
		public string Config
		{
			[Token(Token = "0x601108C")]
			[Address(RVA = "0x1F9B46C", Offset = "0x1F9B46C", VA = "0x1F9B46C")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601108D RID: 69773 RVA: 0x00064008 File Offset: 0x00062208
		[Token(Token = "0x601108D")]
		[Address(RVA = "0x1F9B4A8", Offset = "0x1F9B4A8", VA = "0x1F9B4A8")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x0601108E RID: 69774 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601108E")]
		[Address(RVA = "0x1F9B4E0", Offset = "0x1F9B4E0", VA = "0x1F9B4E0")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x17002022 RID: 8226
		// (get) Token: 0x0601108F RID: 69775 RVA: 0x00064020 File Offset: 0x00062220
		[Token(Token = "0x17002022")]
		public short UserSegmentVersion
		{
			[Token(Token = "0x601108F")]
			[Address(RVA = "0x1F9B52C", Offset = "0x1F9B52C", VA = "0x1F9B52C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002023 RID: 8227
		// (get) Token: 0x06011090 RID: 69776 RVA: 0x00064038 File Offset: 0x00062238
		[Token(Token = "0x17002023")]
		public sbyte UserSegment
		{
			[Token(Token = "0x6011090")]
			[Address(RVA = "0x1F9B570", Offset = "0x1F9B570", VA = "0x1F9B570")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011091 RID: 69777 RVA: 0x00064050 File Offset: 0x00062250
		[Token(Token = "0x6011091")]
		[Address(RVA = "0x1F9B5B4", Offset = "0x1F9B5B4", VA = "0x1F9B5B4")]
		public static Offset<DynamicOfferInfoOld> CreateDynamicOfferInfoOld(FlatBufferBuilder builder, int id = 0, long remaining_time = 0L, short config_version = 0, [Optional] StringOffset configOffset, short user_segment_version = 0, sbyte user_segment = 0)
		{
			return default(Offset<DynamicOfferInfoOld>);
		}

		// Token: 0x06011092 RID: 69778 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011092")]
		[Address(RVA = "0x1F9B788", Offset = "0x1F9B788", VA = "0x1F9B788")]
		public static void StartDynamicOfferInfoOld(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011093 RID: 69779 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011093")]
		[Address(RVA = "0x1F9B69C", Offset = "0x1F9B69C", VA = "0x1F9B69C")]
		public static void AddId(FlatBufferBuilder builder, int id)
		{
		}

		// Token: 0x06011094 RID: 69780 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011094")]
		[Address(RVA = "0x1F9B65C", Offset = "0x1F9B65C", VA = "0x1F9B65C")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06011095 RID: 69781 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011095")]
		[Address(RVA = "0x1F9B6DC", Offset = "0x1F9B6DC", VA = "0x1F9B6DC")]
		public static void AddConfigVersion(FlatBufferBuilder builder, short configVersion)
		{
		}

		// Token: 0x06011096 RID: 69782 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011096")]
		[Address(RVA = "0x1F9B67C", Offset = "0x1F9B67C", VA = "0x1F9B67C")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06011097 RID: 69783 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011097")]
		[Address(RVA = "0x1F9B6BC", Offset = "0x1F9B6BC", VA = "0x1F9B6BC")]
		public static void AddUserSegmentVersion(FlatBufferBuilder builder, short userSegmentVersion)
		{
		}

		// Token: 0x06011098 RID: 69784 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011098")]
		[Address(RVA = "0x1F9B6FC", Offset = "0x1F9B6FC", VA = "0x1F9B6FC")]
		public static void AddUserSegment(FlatBufferBuilder builder, sbyte userSegment)
		{
		}

		// Token: 0x06011099 RID: 69785 RVA: 0x00064068 File Offset: 0x00062268
		[Token(Token = "0x6011099")]
		[Address(RVA = "0x1F9B71C", Offset = "0x1F9B71C", VA = "0x1F9B71C")]
		public static Offset<DynamicOfferInfoOld> EndDynamicOfferInfoOld(FlatBufferBuilder builder)
		{
			return default(Offset<DynamicOfferInfoOld>);
		}

		// Token: 0x0400E6B7 RID: 59063
		[Token(Token = "0x400E6B7")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
