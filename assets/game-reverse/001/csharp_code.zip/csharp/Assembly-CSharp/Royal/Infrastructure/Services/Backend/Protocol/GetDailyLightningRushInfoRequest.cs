﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023CA RID: 9162
	[Token(Token = "0x20023CA")]
	public struct GetDailyLightningRushInfoRequest : IFlatbufferObject
	{
		// Token: 0x170020D1 RID: 8401
		// (get) Token: 0x06011317 RID: 70423 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020D1")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011317")]
			[Address(RVA = "0x1CAD168", Offset = "0x1CAD168", VA = "0x1CAD168", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011318 RID: 70424 RVA: 0x00066180 File Offset: 0x00064380
		[Token(Token = "0x6011318")]
		[Address(RVA = "0x1CAD170", Offset = "0x1CAD170", VA = "0x1CAD170")]
		public static GetDailyLightningRushInfoRequest GetRootAsGetDailyLightningRushInfoRequest(ByteBuffer _bb)
		{
			return default(GetDailyLightningRushInfoRequest);
		}

		// Token: 0x06011319 RID: 70425 RVA: 0x00066198 File Offset: 0x00064398
		[Token(Token = "0x6011319")]
		[Address(RVA = "0x1CAD17C", Offset = "0x1CAD17C", VA = "0x1CAD17C")]
		public static GetDailyLightningRushInfoRequest GetRootAsGetDailyLightningRushInfoRequest(ByteBuffer _bb, GetDailyLightningRushInfoRequest obj)
		{
			return default(GetDailyLightningRushInfoRequest);
		}

		// Token: 0x0601131A RID: 70426 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601131A")]
		[Address(RVA = "0x1CAD22C", Offset = "0x1CAD22C", VA = "0x1CAD22C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601131B RID: 70427 RVA: 0x000661B0 File Offset: 0x000643B0
		[Token(Token = "0x601131B")]
		[Address(RVA = "0x1CAD1F4", Offset = "0x1CAD1F4", VA = "0x1CAD1F4")]
		public GetDailyLightningRushInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetDailyLightningRushInfoRequest);
		}

		// Token: 0x170020D2 RID: 8402
		// (get) Token: 0x0601131C RID: 70428 RVA: 0x000661C8 File Offset: 0x000643C8
		[Token(Token = "0x170020D2")]
		public int EventId
		{
			[Token(Token = "0x601131C")]
			[Address(RVA = "0x1CAD23C", Offset = "0x1CAD23C", VA = "0x1CAD23C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020D3 RID: 8403
		// (get) Token: 0x0601131D RID: 70429 RVA: 0x000661E0 File Offset: 0x000643E0
		[Token(Token = "0x170020D3")]
		public long GroupId
		{
			[Token(Token = "0x601131D")]
			[Address(RVA = "0x1CAD280", Offset = "0x1CAD280", VA = "0x1CAD280")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x170020D4 RID: 8404
		// (get) Token: 0x0601131E RID: 70430 RVA: 0x000661F8 File Offset: 0x000643F8
		[Token(Token = "0x170020D4")]
		public int ConfigVersion
		{
			[Token(Token = "0x601131E")]
			[Address(RVA = "0x1CAD2C8", Offset = "0x1CAD2C8", VA = "0x1CAD2C8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020D5 RID: 8405
		// (get) Token: 0x0601131F RID: 70431 RVA: 0x00066210 File Offset: 0x00064410
		[Token(Token = "0x170020D5")]
		public LeaderboardInfoType LeaderboardInfoType
		{
			[Token(Token = "0x601131F")]
			[Address(RVA = "0x1CAD30C", Offset = "0x1CAD30C", VA = "0x1CAD30C")]
			get
			{
				return LeaderboardInfoType.None;
			}
		}

		// Token: 0x06011320 RID: 70432 RVA: 0x00066228 File Offset: 0x00064428
		[Token(Token = "0x6011320")]
		[Address(RVA = "0x1CAD350", Offset = "0x1CAD350", VA = "0x1CAD350")]
		public static Offset<GetDailyLightningRushInfoRequest> CreateGetDailyLightningRushInfoRequest(FlatBufferBuilder builder, int event_id = 0, long group_id = 0L, int config_version = 0, LeaderboardInfoType leaderboard_info_type = LeaderboardInfoType.None)
		{
			return default(Offset<GetDailyLightningRushInfoRequest>);
		}

		// Token: 0x06011321 RID: 70433 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011321")]
		[Address(RVA = "0x1CAD4BC", Offset = "0x1CAD4BC", VA = "0x1CAD4BC")]
		public static void StartGetDailyLightningRushInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011322 RID: 70434 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011322")]
		[Address(RVA = "0x1CAD410", Offset = "0x1CAD410", VA = "0x1CAD410")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x06011323 RID: 70435 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011323")]
		[Address(RVA = "0x1CAD3D0", Offset = "0x1CAD3D0", VA = "0x1CAD3D0")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06011324 RID: 70436 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011324")]
		[Address(RVA = "0x1CAD3F0", Offset = "0x1CAD3F0", VA = "0x1CAD3F0")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06011325 RID: 70437 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011325")]
		[Address(RVA = "0x1CAD430", Offset = "0x1CAD430", VA = "0x1CAD430")]
		public static void AddLeaderboardInfoType(FlatBufferBuilder builder, LeaderboardInfoType leaderboardInfoType)
		{
		}

		// Token: 0x06011326 RID: 70438 RVA: 0x00066240 File Offset: 0x00064440
		[Token(Token = "0x6011326")]
		[Address(RVA = "0x1CAD450", Offset = "0x1CAD450", VA = "0x1CAD450")]
		public static Offset<GetDailyLightningRushInfoRequest> EndGetDailyLightningRushInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetDailyLightningRushInfoRequest>);
		}

		// Token: 0x0400E73A RID: 59194
		[Token(Token = "0x400E73A")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
