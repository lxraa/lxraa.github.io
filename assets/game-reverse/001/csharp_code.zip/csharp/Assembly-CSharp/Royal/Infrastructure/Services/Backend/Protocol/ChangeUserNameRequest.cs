﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002351 RID: 9041
	[Token(Token = "0x2002351")]
	public struct ChangeUserNameRequest : IFlatbufferObject
	{
		// Token: 0x17001F03 RID: 7939
		// (get) Token: 0x06010C79 RID: 68729 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F03")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C79")]
			[Address(RVA = "0x21468A8", Offset = "0x21468A8", VA = "0x21468A8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C7A RID: 68730 RVA: 0x00060B10 File Offset: 0x0005ED10
		[Token(Token = "0x6010C7A")]
		[Address(RVA = "0x21468B0", Offset = "0x21468B0", VA = "0x21468B0")]
		public static ChangeUserNameRequest GetRootAsChangeUserNameRequest(ByteBuffer _bb)
		{
			return default(ChangeUserNameRequest);
		}

		// Token: 0x06010C7B RID: 68731 RVA: 0x00060B28 File Offset: 0x0005ED28
		[Token(Token = "0x6010C7B")]
		[Address(RVA = "0x21468BC", Offset = "0x21468BC", VA = "0x21468BC")]
		public static ChangeUserNameRequest GetRootAsChangeUserNameRequest(ByteBuffer _bb, ChangeUserNameRequest obj)
		{
			return default(ChangeUserNameRequest);
		}

		// Token: 0x06010C7C RID: 68732 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C7C")]
		[Address(RVA = "0x214696C", Offset = "0x214696C", VA = "0x214696C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C7D RID: 68733 RVA: 0x00060B40 File Offset: 0x0005ED40
		[Token(Token = "0x6010C7D")]
		[Address(RVA = "0x2146934", Offset = "0x2146934", VA = "0x2146934")]
		public ChangeUserNameRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ChangeUserNameRequest);
		}

		// Token: 0x17001F04 RID: 7940
		// (get) Token: 0x06010C7E RID: 68734 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F04")]
		public string NewName
		{
			[Token(Token = "0x6010C7E")]
			[Address(RVA = "0x214697C", Offset = "0x214697C", VA = "0x214697C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C7F RID: 68735 RVA: 0x00060B58 File Offset: 0x0005ED58
		[Token(Token = "0x6010C7F")]
		[Address(RVA = "0x21469B8", Offset = "0x21469B8", VA = "0x21469B8")]
		public ArraySegment<byte>? GetNewNameBytes()
		{
			return null;
		}

		// Token: 0x06010C80 RID: 68736 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010C80")]
		[Address(RVA = "0x21469F0", Offset = "0x21469F0", VA = "0x21469F0")]
		public byte[] GetNewNameArray()
		{
			return null;
		}

		// Token: 0x17001F05 RID: 7941
		// (get) Token: 0x06010C81 RID: 68737 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F05")]
		public string Language
		{
			[Token(Token = "0x6010C81")]
			[Address(RVA = "0x2146A3C", Offset = "0x2146A3C", VA = "0x2146A3C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C82 RID: 68738 RVA: 0x00060B70 File Offset: 0x0005ED70
		[Token(Token = "0x6010C82")]
		[Address(RVA = "0x2146A78", Offset = "0x2146A78", VA = "0x2146A78")]
		public ArraySegment<byte>? GetLanguageBytes()
		{
			return null;
		}

		// Token: 0x06010C83 RID: 68739 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010C83")]
		[Address(RVA = "0x2146AB0", Offset = "0x2146AB0", VA = "0x2146AB0")]
		public byte[] GetLanguageArray()
		{
			return null;
		}

		// Token: 0x17001F06 RID: 7942
		// (get) Token: 0x06010C84 RID: 68740 RVA: 0x00060B88 File Offset: 0x0005ED88
		[Token(Token = "0x17001F06")]
		public long TeamId
		{
			[Token(Token = "0x6010C84")]
			[Address(RVA = "0x2146AFC", Offset = "0x2146AFC", VA = "0x2146AFC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F07 RID: 7943
		// (get) Token: 0x06010C85 RID: 68741 RVA: 0x00060BA0 File Offset: 0x0005EDA0
		[Token(Token = "0x17001F07")]
		public ChatProfile? OwnerChatProfile
		{
			[Token(Token = "0x6010C85")]
			[Address(RVA = "0x2146B44", Offset = "0x2146B44", VA = "0x2146B44")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F08 RID: 7944
		// (get) Token: 0x06010C86 RID: 68742 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F08")]
		public string DeviceLanguage
		{
			[Token(Token = "0x6010C86")]
			[Address(RVA = "0x2146BFC", Offset = "0x2146BFC", VA = "0x2146BFC")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C87 RID: 68743 RVA: 0x00060BB8 File Offset: 0x0005EDB8
		[Token(Token = "0x6010C87")]
		[Address(RVA = "0x2146C38", Offset = "0x2146C38", VA = "0x2146C38")]
		public ArraySegment<byte>? GetDeviceLanguageBytes()
		{
			return null;
		}

		// Token: 0x06010C88 RID: 68744 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010C88")]
		[Address(RVA = "0x2146C70", Offset = "0x2146C70", VA = "0x2146C70")]
		public byte[] GetDeviceLanguageArray()
		{
			return null;
		}

		// Token: 0x17001F09 RID: 7945
		// (get) Token: 0x06010C89 RID: 68745 RVA: 0x00060BD0 File Offset: 0x0005EDD0
		[Token(Token = "0x17001F09")]
		public SpecialChatProfile? OwnerSpecialChatProfile
		{
			[Token(Token = "0x6010C89")]
			[Address(RVA = "0x2146CBC", Offset = "0x2146CBC", VA = "0x2146CBC")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C8A RID: 68746 RVA: 0x00060BE8 File Offset: 0x0005EDE8
		[Token(Token = "0x6010C8A")]
		[Address(RVA = "0x2146D7C", Offset = "0x2146D7C", VA = "0x2146D7C")]
		public static Offset<ChangeUserNameRequest> CreateChangeUserNameRequest(FlatBufferBuilder builder, [Optional] StringOffset new_nameOffset, [Optional] StringOffset languageOffset, long team_id = 0L, [Optional] Offset<ChatProfile> owner_chat_profileOffset, [Optional] StringOffset device_languageOffset, [Optional] Offset<SpecialChatProfile> owner_special_chat_profileOffset)
		{
			return default(Offset<ChangeUserNameRequest>);
		}

		// Token: 0x06010C8B RID: 68747 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C8B")]
		[Address(RVA = "0x2146F50", Offset = "0x2146F50", VA = "0x2146F50")]
		public static void StartChangeUserNameRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C8C RID: 68748 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C8C")]
		[Address(RVA = "0x2146EC4", Offset = "0x2146EC4", VA = "0x2146EC4")]
		public static void AddNewName(FlatBufferBuilder builder, StringOffset newNameOffset)
		{
		}

		// Token: 0x06010C8D RID: 68749 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C8D")]
		[Address(RVA = "0x2146EA4", Offset = "0x2146EA4", VA = "0x2146EA4")]
		public static void AddLanguage(FlatBufferBuilder builder, StringOffset languageOffset)
		{
		}

		// Token: 0x06010C8E RID: 68750 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C8E")]
		[Address(RVA = "0x2146E24", Offset = "0x2146E24", VA = "0x2146E24")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x06010C8F RID: 68751 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C8F")]
		[Address(RVA = "0x2146E84", Offset = "0x2146E84", VA = "0x2146E84")]
		public static void AddOwnerChatProfile(FlatBufferBuilder builder, Offset<ChatProfile> ownerChatProfileOffset)
		{
		}

		// Token: 0x06010C90 RID: 68752 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C90")]
		[Address(RVA = "0x2146E64", Offset = "0x2146E64", VA = "0x2146E64")]
		public static void AddDeviceLanguage(FlatBufferBuilder builder, StringOffset deviceLanguageOffset)
		{
		}

		// Token: 0x06010C91 RID: 68753 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C91")]
		[Address(RVA = "0x2146E44", Offset = "0x2146E44", VA = "0x2146E44")]
		public static void AddOwnerSpecialChatProfile(FlatBufferBuilder builder, Offset<SpecialChatProfile> ownerSpecialChatProfileOffset)
		{
		}

		// Token: 0x06010C92 RID: 68754 RVA: 0x00060C00 File Offset: 0x0005EE00
		[Token(Token = "0x6010C92")]
		[Address(RVA = "0x2146EE4", Offset = "0x2146EE4", VA = "0x2146EE4")]
		public static Offset<ChangeUserNameRequest> EndChangeUserNameRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ChangeUserNameRequest>);
		}

		// Token: 0x0400E643 RID: 58947
		[Token(Token = "0x400E643")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
