﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025C4 RID: 9668
	[Token(Token = "0x20025C4")]
	public enum VersionState
	{
		// Token: 0x0400EEB9 RID: 61113
		[Token(Token = "0x400EEB9")]
		Same,
		// Token: 0x0400EEBA RID: 61114
		[Token(Token = "0x400EEBA")]
		NewInstall,
		// Token: 0x0400EEBB RID: 61115
		[Token(Token = "0x400EEBB")]
		Update,
		// Token: 0x0400EEBC RID: 61116
		[Token(Token = "0x400EEBC")]
		Downgrade
	}
}
