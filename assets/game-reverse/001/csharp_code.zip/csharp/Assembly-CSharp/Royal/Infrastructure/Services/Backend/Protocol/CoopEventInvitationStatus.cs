﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002370 RID: 9072
	[Token(Token = "0x2002370")]
	public enum CoopEventInvitationStatus : sbyte
	{
		// Token: 0x0400E682 RID: 59010
		[Token(Token = "0x400E682")]
		Requested,
		// Token: 0x0400E683 RID: 59011
		[Token(Token = "0x400E683")]
		Pending,
		// Token: 0x0400E684 RID: 59012
		[Token(Token = "0x400E684")]
		Matched,
		// Token: 0x0400E685 RID: 59013
		[Token(Token = "0x400E685")]
		Rejected
	}
}
