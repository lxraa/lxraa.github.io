﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200235D RID: 9053
	[Token(Token = "0x200235D")]
	public struct ClaimLeagueRewardResponse : IFlatbufferObject
	{
		// Token: 0x17001F31 RID: 7985
		// (get) Token: 0x06010D1C RID: 68892 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F31")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D1C")]
			[Address(RVA = "0x2148DD0", Offset = "0x2148DD0", VA = "0x2148DD0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D1D RID: 68893 RVA: 0x00061308 File Offset: 0x0005F508
		[Token(Token = "0x6010D1D")]
		[Address(RVA = "0x2148DD8", Offset = "0x2148DD8", VA = "0x2148DD8")]
		public static ClaimLeagueRewardResponse GetRootAsClaimLeagueRewardResponse(ByteBuffer _bb)
		{
			return default(ClaimLeagueRewardResponse);
		}

		// Token: 0x06010D1E RID: 68894 RVA: 0x00061320 File Offset: 0x0005F520
		[Token(Token = "0x6010D1E")]
		[Address(RVA = "0x2148DE4", Offset = "0x2148DE4", VA = "0x2148DE4")]
		public static ClaimLeagueRewardResponse GetRootAsClaimLeagueRewardResponse(ByteBuffer _bb, ClaimLeagueRewardResponse obj)
		{
			return default(ClaimLeagueRewardResponse);
		}

		// Token: 0x06010D1F RID: 68895 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D1F")]
		[Address(RVA = "0x2148E94", Offset = "0x2148E94", VA = "0x2148E94", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D20 RID: 68896 RVA: 0x00061338 File Offset: 0x0005F538
		[Token(Token = "0x6010D20")]
		[Address(RVA = "0x2148E5C", Offset = "0x2148E5C", VA = "0x2148E5C")]
		public ClaimLeagueRewardResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimLeagueRewardResponse);
		}

		// Token: 0x17001F32 RID: 7986
		// (get) Token: 0x06010D21 RID: 68897 RVA: 0x00061350 File Offset: 0x0005F550
		[Token(Token = "0x17001F32")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010D21")]
			[Address(RVA = "0x2148EA4", Offset = "0x2148EA4", VA = "0x2148EA4")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001F33 RID: 7987
		// (get) Token: 0x06010D22 RID: 68898 RVA: 0x00061368 File Offset: 0x0005F568
		[Token(Token = "0x17001F33")]
		public UserProgress? DeprecatedUserProgress
		{
			[Token(Token = "0x6010D22")]
			[Address(RVA = "0x2148EE8", Offset = "0x2148EE8", VA = "0x2148EE8")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F34 RID: 7988
		// (get) Token: 0x06010D23 RID: 68899 RVA: 0x00061380 File Offset: 0x0005F580
		[Token(Token = "0x17001F34")]
		public int DeprecatedCoinRewardAmount
		{
			[Token(Token = "0x6010D23")]
			[Address(RVA = "0x2148FA8", Offset = "0x2148FA8", VA = "0x2148FA8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F35 RID: 7989
		// (get) Token: 0x06010D24 RID: 68900 RVA: 0x00061398 File Offset: 0x0005F598
		[Token(Token = "0x17001F35")]
		public int DeprecatedBoosterRewardAmount
		{
			[Token(Token = "0x6010D24")]
			[Address(RVA = "0x2148FEC", Offset = "0x2148FEC", VA = "0x2148FEC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010D25 RID: 68901 RVA: 0x000613B0 File Offset: 0x0005F5B0
		[Token(Token = "0x6010D25")]
		[Address(RVA = "0x2149030", Offset = "0x2149030", VA = "0x2149030")]
		public static Offset<ClaimLeagueRewardResponse> CreateClaimLeagueRewardResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, [Optional] Offset<UserProgress> deprecated_user_progressOffset, int deprecated_coin_reward_amount = 0, int deprecated_booster_reward_amount = 0)
		{
			return default(Offset<ClaimLeagueRewardResponse>);
		}

		// Token: 0x06010D26 RID: 68902 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D26")]
		[Address(RVA = "0x214919C", Offset = "0x214919C", VA = "0x214919C")]
		public static void StartClaimLeagueRewardResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D27 RID: 68903 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D27")]
		[Address(RVA = "0x2149110", Offset = "0x2149110", VA = "0x2149110")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010D28 RID: 68904 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D28")]
		[Address(RVA = "0x21490F0", Offset = "0x21490F0", VA = "0x21490F0")]
		public static void AddDeprecatedUserProgress(FlatBufferBuilder builder, Offset<UserProgress> deprecatedUserProgressOffset)
		{
		}

		// Token: 0x06010D29 RID: 68905 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D29")]
		[Address(RVA = "0x21490D0", Offset = "0x21490D0", VA = "0x21490D0")]
		public static void AddDeprecatedCoinRewardAmount(FlatBufferBuilder builder, int deprecatedCoinRewardAmount)
		{
		}

		// Token: 0x06010D2A RID: 68906 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D2A")]
		[Address(RVA = "0x21490B0", Offset = "0x21490B0", VA = "0x21490B0")]
		public static void AddDeprecatedBoosterRewardAmount(FlatBufferBuilder builder, int deprecatedBoosterRewardAmount)
		{
		}

		// Token: 0x06010D2B RID: 68907 RVA: 0x000613C8 File Offset: 0x0005F5C8
		[Token(Token = "0x6010D2B")]
		[Address(RVA = "0x2149130", Offset = "0x2149130", VA = "0x2149130")]
		public static Offset<ClaimLeagueRewardResponse> EndClaimLeagueRewardResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimLeagueRewardResponse>);
		}

		// Token: 0x0400E663 RID: 58979
		[Token(Token = "0x400E663")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
