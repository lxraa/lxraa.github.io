﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x0200251C RID: 9500
	[Token(Token = "0x200251C")]
	public class RegisterHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026E3 RID: 9955
		// (get) Token: 0x06012922 RID: 76066 RVA: 0x000776E8 File Offset: 0x000758E8
		[Token(Token = "0x170026E3")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012922")]
			[Address(RVA = "0x1CF068C", Offset = "0x1CF068C", VA = "0x1CF068C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026E4 RID: 9956
		// (get) Token: 0x06012923 RID: 76067 RVA: 0x00077700 File Offset: 0x00075900
		[Token(Token = "0x170026E4")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012923")]
			[Address(RVA = "0x1CF0694", Offset = "0x1CF0694", VA = "0x1CF0694", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026E5 RID: 9957
		// (get) Token: 0x06012924 RID: 76068 RVA: 0x00077718 File Offset: 0x00075918
		// (set) Token: 0x06012925 RID: 76069 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026E5")]
		private RegisterResponse Response
		{
			[Token(Token = "0x6012924")]
			[Address(RVA = "0x1CF069C", Offset = "0x1CF069C", VA = "0x1CF069C")]
			get
			{
				return default(RegisterResponse);
			}
			[Token(Token = "0x6012925")]
			[Address(RVA = "0x1CF06A8", Offset = "0x1CF06A8", VA = "0x1CF06A8")]
			set
			{
			}
		}

		// Token: 0x06012926 RID: 76070 RVA: 0x00077730 File Offset: 0x00075930
		[Token(Token = "0x6012926")]
		[Address(RVA = "0x1CF06B8", Offset = "0x1CF06B8", VA = "0x1CF06B8", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012927 RID: 76071 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012927")]
		[Address(RVA = "0x1CF07E8", Offset = "0x1CF07E8", VA = "0x1CF07E8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012928 RID: 76072 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012928")]
		[Address(RVA = "0x1CF10C4", Offset = "0x1CF10C4", VA = "0x1CF10C4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012929 RID: 76073 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012929")]
		[Address(RVA = "0x1CF08F4", Offset = "0x1CF08F4", VA = "0x1CF08F4")]
		private void UpdateUserData(ResponsePackage package)
		{
		}

		// Token: 0x0601292A RID: 76074 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601292A")]
		[Address(RVA = "0x1CF0D64", Offset = "0x1CF0D64", VA = "0x1CF0D64")]
		private void UpdateLocationData()
		{
		}

		// Token: 0x0601292B RID: 76075 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601292B")]
		[Address(RVA = "0x1CF101C", Offset = "0x1CF101C", VA = "0x1CF101C")]
		private void UpdateOfferSegment()
		{
		}

		// Token: 0x0601292C RID: 76076 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601292C")]
		[Address(RVA = "0x1CF10C8", Offset = "0x1CF10C8", VA = "0x1CF10C8")]
		public RegisterHttpCommand()
		{
		}

		// Token: 0x0400EAF0 RID: 60144
		[Token(Token = "0x400EAF0")]
		[FieldOffset(Offset = "0x18")]
		private RegisterResponse <Response>k__BackingField;
	}
}
