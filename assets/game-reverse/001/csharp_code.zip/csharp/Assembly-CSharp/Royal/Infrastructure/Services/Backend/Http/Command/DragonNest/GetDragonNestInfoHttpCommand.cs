﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.DragonNest
{
	// Token: 0x0200256D RID: 9581
	[Token(Token = "0x200256D")]
	public class GetDragonNestInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027A4 RID: 10148
		// (get) Token: 0x06012B7E RID: 76670 RVA: 0x00079158 File Offset: 0x00077358
		[Token(Token = "0x170027A4")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B7E")]
			[Address(RVA = "0x1ED2C34", Offset = "0x1ED2C34", VA = "0x1ED2C34", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027A5 RID: 10149
		// (get) Token: 0x06012B7F RID: 76671 RVA: 0x00079170 File Offset: 0x00077370
		[Token(Token = "0x170027A5")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B7F")]
			[Address(RVA = "0x1ED2C3C", Offset = "0x1ED2C3C", VA = "0x1ED2C3C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B80 RID: 76672 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B80")]
		[Address(RVA = "0x1ED2C44", Offset = "0x1ED2C44", VA = "0x1ED2C44")]
		public GetDragonNestInfoHttpCommand(int eventId, int configVersion, bool fromRefresh)
		{
		}

		// Token: 0x06012B81 RID: 76673 RVA: 0x00079188 File Offset: 0x00077388
		[Token(Token = "0x6012B81")]
		[Address(RVA = "0x1ED2D2C", Offset = "0x1ED2D2C", VA = "0x1ED2D2C", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012B82 RID: 76674 RVA: 0x000791A0 File Offset: 0x000773A0
		[Token(Token = "0x6012B82")]
		[Address(RVA = "0x1ED2E18", Offset = "0x1ED2E18", VA = "0x1ED2E18", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B83 RID: 76675 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B83")]
		[Address(RVA = "0x1ED2EE4", Offset = "0x1ED2EE4", VA = "0x1ED2EE4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B84 RID: 76676 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B84")]
		[Address(RVA = "0x1ED2FFC", Offset = "0x1ED2FFC", VA = "0x1ED2FFC", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBE6 RID: 60390
		[Token(Token = "0x400EBE6")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;

		// Token: 0x0400EBE7 RID: 60391
		[Token(Token = "0x400EBE7")]
		[FieldOffset(Offset = "0x18")]
		private readonly int configVersion;

		// Token: 0x0400EBE8 RID: 60392
		[Token(Token = "0x400EBE8")]
		[FieldOffset(Offset = "0x1C")]
		private readonly bool fromRefresh;
	}
}
