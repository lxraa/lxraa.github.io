﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D0 RID: 9168
	[Token(Token = "0x20023D0")]
	public struct GetEventInfoRequest : IFlatbufferObject
	{
		// Token: 0x170020E6 RID: 8422
		// (get) Token: 0x06011375 RID: 70517 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020E6")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011375")]
			[Address(RVA = "0x1CAEB88", Offset = "0x1CAEB88", VA = "0x1CAEB88", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011376 RID: 70518 RVA: 0x000666D8 File Offset: 0x000648D8
		[Token(Token = "0x6011376")]
		[Address(RVA = "0x1CAEB90", Offset = "0x1CAEB90", VA = "0x1CAEB90")]
		public static GetEventInfoRequest GetRootAsGetEventInfoRequest(ByteBuffer _bb)
		{
			return default(GetEventInfoRequest);
		}

		// Token: 0x06011377 RID: 70519 RVA: 0x000666F0 File Offset: 0x000648F0
		[Token(Token = "0x6011377")]
		[Address(RVA = "0x1CAEB9C", Offset = "0x1CAEB9C", VA = "0x1CAEB9C")]
		public static GetEventInfoRequest GetRootAsGetEventInfoRequest(ByteBuffer _bb, GetEventInfoRequest obj)
		{
			return default(GetEventInfoRequest);
		}

		// Token: 0x06011378 RID: 70520 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011378")]
		[Address(RVA = "0x1CAEC4C", Offset = "0x1CAEC4C", VA = "0x1CAEC4C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011379 RID: 70521 RVA: 0x00066708 File Offset: 0x00064908
		[Token(Token = "0x6011379")]
		[Address(RVA = "0x1CAEC14", Offset = "0x1CAEC14", VA = "0x1CAEC14")]
		public GetEventInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetEventInfoRequest);
		}

		// Token: 0x170020E7 RID: 8423
		// (get) Token: 0x0601137A RID: 70522 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020E7")]
		public string Country
		{
			[Token(Token = "0x601137A")]
			[Address(RVA = "0x1CAEC5C", Offset = "0x1CAEC5C", VA = "0x1CAEC5C")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601137B RID: 70523 RVA: 0x00066720 File Offset: 0x00064920
		[Token(Token = "0x601137B")]
		[Address(RVA = "0x1CAEC98", Offset = "0x1CAEC98", VA = "0x1CAEC98")]
		public ArraySegment<byte>? GetCountryBytes()
		{
			return null;
		}

		// Token: 0x0601137C RID: 70524 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601137C")]
		[Address(RVA = "0x1CAECD0", Offset = "0x1CAECD0", VA = "0x1CAECD0")]
		public byte[] GetCountryArray()
		{
			return null;
		}

		// Token: 0x170020E8 RID: 8424
		// (get) Token: 0x0601137D RID: 70525 RVA: 0x00066738 File Offset: 0x00064938
		[Token(Token = "0x170020E8")]
		public int Level
		{
			[Token(Token = "0x601137D")]
			[Address(RVA = "0x1CAED1C", Offset = "0x1CAED1C", VA = "0x1CAED1C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020E9 RID: 8425
		// (get) Token: 0x0601137E RID: 70526 RVA: 0x00066750 File Offset: 0x00064950
		[Token(Token = "0x170020E9")]
		public ConfigVersions? ConfigVersions
		{
			[Token(Token = "0x601137E")]
			[Address(RVA = "0x1CAED60", Offset = "0x1CAED60", VA = "0x1CAED60")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601137F RID: 70527 RVA: 0x00066768 File Offset: 0x00064968
		[Token(Token = "0x601137F")]
		[Address(RVA = "0x1CAEE20", Offset = "0x1CAEE20", VA = "0x1CAEE20")]
		public static Offset<GetEventInfoRequest> CreateGetEventInfoRequest(FlatBufferBuilder builder, [Optional] StringOffset countryOffset, int level = 0, [Optional] Offset<ConfigVersions> config_versionsOffset)
		{
			return default(Offset<GetEventInfoRequest>);
		}

		// Token: 0x06011380 RID: 70528 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011380")]
		[Address(RVA = "0x1CAEF5C", Offset = "0x1CAEF5C", VA = "0x1CAEF5C")]
		public static void StartGetEventInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011381 RID: 70529 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011381")]
		[Address(RVA = "0x1CAEED0", Offset = "0x1CAEED0", VA = "0x1CAEED0")]
		public static void AddCountry(FlatBufferBuilder builder, StringOffset countryOffset)
		{
		}

		// Token: 0x06011382 RID: 70530 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011382")]
		[Address(RVA = "0x1CAEEB0", Offset = "0x1CAEEB0", VA = "0x1CAEEB0")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x06011383 RID: 70531 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011383")]
		[Address(RVA = "0x1CAEE90", Offset = "0x1CAEE90", VA = "0x1CAEE90")]
		public static void AddConfigVersions(FlatBufferBuilder builder, Offset<ConfigVersions> configVersionsOffset)
		{
		}

		// Token: 0x06011384 RID: 70532 RVA: 0x00066780 File Offset: 0x00064980
		[Token(Token = "0x6011384")]
		[Address(RVA = "0x1CAEEF0", Offset = "0x1CAEEF0", VA = "0x1CAEEF0")]
		public static Offset<GetEventInfoRequest> EndGetEventInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetEventInfoRequest>);
		}

		// Token: 0x0400E740 RID: 59200
		[Token(Token = "0x400E740")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
