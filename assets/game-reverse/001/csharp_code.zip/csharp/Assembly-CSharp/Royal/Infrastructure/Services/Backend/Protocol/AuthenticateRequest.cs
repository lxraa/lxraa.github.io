﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002345 RID: 9029
	[Token(Token = "0x2002345")]
	public struct AuthenticateRequest : IFlatbufferObject
	{
		// Token: 0x17001EDD RID: 7901
		// (get) Token: 0x06010BD3 RID: 68563 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EDD")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010BD3")]
			[Address(RVA = "0x21442C8", Offset = "0x21442C8", VA = "0x21442C8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BD4 RID: 68564 RVA: 0x000602D0 File Offset: 0x0005E4D0
		[Token(Token = "0x6010BD4")]
		[Address(RVA = "0x21442D0", Offset = "0x21442D0", VA = "0x21442D0")]
		public static AuthenticateRequest GetRootAsAuthenticateRequest(ByteBuffer _bb)
		{
			return default(AuthenticateRequest);
		}

		// Token: 0x06010BD5 RID: 68565 RVA: 0x000602E8 File Offset: 0x0005E4E8
		[Token(Token = "0x6010BD5")]
		[Address(RVA = "0x21442DC", Offset = "0x21442DC", VA = "0x21442DC")]
		public static AuthenticateRequest GetRootAsAuthenticateRequest(ByteBuffer _bb, AuthenticateRequest obj)
		{
			return default(AuthenticateRequest);
		}

		// Token: 0x06010BD6 RID: 68566 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BD6")]
		[Address(RVA = "0x214438C", Offset = "0x214438C", VA = "0x214438C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010BD7 RID: 68567 RVA: 0x00060300 File Offset: 0x0005E500
		[Token(Token = "0x6010BD7")]
		[Address(RVA = "0x2144354", Offset = "0x2144354", VA = "0x2144354")]
		public AuthenticateRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(AuthenticateRequest);
		}

		// Token: 0x17001EDE RID: 7902
		// (get) Token: 0x06010BD8 RID: 68568 RVA: 0x00060318 File Offset: 0x0005E518
		[Token(Token = "0x17001EDE")]
		public long UserId
		{
			[Token(Token = "0x6010BD8")]
			[Address(RVA = "0x214439C", Offset = "0x214439C", VA = "0x214439C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001EDF RID: 7903
		// (get) Token: 0x06010BD9 RID: 68569 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EDF")]
		public string Token
		{
			[Token(Token = "0x6010BD9")]
			[Address(RVA = "0x21443E4", Offset = "0x21443E4", VA = "0x21443E4")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BDA RID: 68570 RVA: 0x00060330 File Offset: 0x0005E530
		[Token(Token = "0x6010BDA")]
		[Address(RVA = "0x2144420", Offset = "0x2144420", VA = "0x2144420")]
		public ArraySegment<byte>? GetTokenBytes()
		{
			return null;
		}

		// Token: 0x06010BDB RID: 68571 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010BDB")]
		[Address(RVA = "0x2144458", Offset = "0x2144458", VA = "0x2144458")]
		public byte[] GetTokenArray()
		{
			return null;
		}

		// Token: 0x17001EE0 RID: 7904
		// (get) Token: 0x06010BDC RID: 68572 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EE0")]
		public string DeviceId
		{
			[Token(Token = "0x6010BDC")]
			[Address(RVA = "0x21444A4", Offset = "0x21444A4", VA = "0x21444A4")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BDD RID: 68573 RVA: 0x00060348 File Offset: 0x0005E548
		[Token(Token = "0x6010BDD")]
		[Address(RVA = "0x21444E0", Offset = "0x21444E0", VA = "0x21444E0")]
		public ArraySegment<byte>? GetDeviceIdBytes()
		{
			return null;
		}

		// Token: 0x06010BDE RID: 68574 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010BDE")]
		[Address(RVA = "0x2144518", Offset = "0x2144518", VA = "0x2144518")]
		public byte[] GetDeviceIdArray()
		{
			return null;
		}

		// Token: 0x17001EE1 RID: 7905
		// (get) Token: 0x06010BDF RID: 68575 RVA: 0x00060360 File Offset: 0x0005E560
		[Token(Token = "0x17001EE1")]
		public int Version
		{
			[Token(Token = "0x6010BDF")]
			[Address(RVA = "0x2144564", Offset = "0x2144564", VA = "0x2144564")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EE2 RID: 7906
		// (get) Token: 0x06010BE0 RID: 68576 RVA: 0x00060378 File Offset: 0x0005E578
		[Token(Token = "0x17001EE2")]
		public bool MayHaveTeam
		{
			[Token(Token = "0x6010BE0")]
			[Address(RVA = "0x21445A8", Offset = "0x21445A8", VA = "0x21445A8")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001EE3 RID: 7907
		// (get) Token: 0x06010BE1 RID: 68577 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EE3")]
		public string Name
		{
			[Token(Token = "0x6010BE1")]
			[Address(RVA = "0x21445F0", Offset = "0x21445F0", VA = "0x21445F0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BE2 RID: 68578 RVA: 0x00060390 File Offset: 0x0005E590
		[Token(Token = "0x6010BE2")]
		[Address(RVA = "0x214462C", Offset = "0x214462C", VA = "0x214462C")]
		public ArraySegment<byte>? GetNameBytes()
		{
			return null;
		}

		// Token: 0x06010BE3 RID: 68579 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010BE3")]
		[Address(RVA = "0x2144664", Offset = "0x2144664", VA = "0x2144664")]
		public byte[] GetNameArray()
		{
			return null;
		}

		// Token: 0x17001EE4 RID: 7908
		// (get) Token: 0x06010BE4 RID: 68580 RVA: 0x000603A8 File Offset: 0x0005E5A8
		[Token(Token = "0x17001EE4")]
		public RequestPlatform Platform
		{
			[Token(Token = "0x6010BE4")]
			[Address(RVA = "0x21446B0", Offset = "0x21446B0", VA = "0x21446B0")]
			get
			{
				return RequestPlatform.DefaultValueFromOldClients;
			}
		}

		// Token: 0x06010BE5 RID: 68581 RVA: 0x000603C0 File Offset: 0x0005E5C0
		[Token(Token = "0x6010BE5")]
		[Address(RVA = "0x2140AD0", Offset = "0x2140AD0", VA = "0x2140AD0")]
		public static Offset<AuthenticateRequest> CreateAuthenticateRequest(FlatBufferBuilder builder, long user_id = 0L, [Optional] StringOffset tokenOffset, [Optional] StringOffset device_idOffset, int version = 0, bool may_have_team = false, [Optional] StringOffset nameOffset, RequestPlatform platform = RequestPlatform.DefaultValueFromOldClients)
		{
			return default(Offset<AuthenticateRequest>);
		}

		// Token: 0x06010BE6 RID: 68582 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BE6")]
		[Address(RVA = "0x2144840", Offset = "0x2144840", VA = "0x2144840")]
		public static void StartAuthenticateRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010BE7 RID: 68583 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BE7")]
		[Address(RVA = "0x21446F4", Offset = "0x21446F4", VA = "0x21446F4")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010BE8 RID: 68584 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BE8")]
		[Address(RVA = "0x2144774", Offset = "0x2144774", VA = "0x2144774")]
		public static void AddToken(FlatBufferBuilder builder, StringOffset tokenOffset)
		{
		}

		// Token: 0x06010BE9 RID: 68585 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BE9")]
		[Address(RVA = "0x2144754", Offset = "0x2144754", VA = "0x2144754")]
		public static void AddDeviceId(FlatBufferBuilder builder, StringOffset deviceIdOffset)
		{
		}

		// Token: 0x06010BEA RID: 68586 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BEA")]
		[Address(RVA = "0x2144734", Offset = "0x2144734", VA = "0x2144734")]
		public static void AddVersion(FlatBufferBuilder builder, int version)
		{
		}

		// Token: 0x06010BEB RID: 68587 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BEB")]
		[Address(RVA = "0x21447B4", Offset = "0x21447B4", VA = "0x21447B4")]
		public static void AddMayHaveTeam(FlatBufferBuilder builder, bool mayHaveTeam)
		{
		}

		// Token: 0x06010BEC RID: 68588 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BEC")]
		[Address(RVA = "0x2144714", Offset = "0x2144714", VA = "0x2144714")]
		public static void AddName(FlatBufferBuilder builder, StringOffset nameOffset)
		{
		}

		// Token: 0x06010BED RID: 68589 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BED")]
		[Address(RVA = "0x2144794", Offset = "0x2144794", VA = "0x2144794")]
		public static void AddPlatform(FlatBufferBuilder builder, RequestPlatform platform)
		{
		}

		// Token: 0x06010BEE RID: 68590 RVA: 0x000603D8 File Offset: 0x0005E5D8
		[Token(Token = "0x6010BEE")]
		[Address(RVA = "0x21447D4", Offset = "0x21447D4", VA = "0x21447D4")]
		public static Offset<AuthenticateRequest> EndAuthenticateRequest(FlatBufferBuilder builder)
		{
			return default(Offset<AuthenticateRequest>);
		}

		// Token: 0x0400E629 RID: 58921
		[Token(Token = "0x400E629")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
