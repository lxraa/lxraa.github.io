﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002512 RID: 9490
	[Token(Token = "0x2002512")]
	public class DeleteUserHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026C8 RID: 9928
		// (get) Token: 0x060128AD RID: 75949 RVA: 0x00077370 File Offset: 0x00075570
		[Token(Token = "0x170026C8")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60128AD")]
			[Address(RVA = "0x1CEA8E8", Offset = "0x1CEA8E8", VA = "0x1CEA8E8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026C9 RID: 9929
		// (get) Token: 0x060128AE RID: 75950 RVA: 0x00077388 File Offset: 0x00075588
		[Token(Token = "0x170026C9")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60128AE")]
			[Address(RVA = "0x1CEA8F0", Offset = "0x1CEA8F0", VA = "0x1CEA8F0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026CA RID: 9930
		// (get) Token: 0x060128AF RID: 75951 RVA: 0x000773A0 File Offset: 0x000755A0
		// (set) Token: 0x060128B0 RID: 75952 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026CA")]
		private DeleteUserResponse Response
		{
			[Token(Token = "0x60128AF")]
			[Address(RVA = "0x1CEA8F8", Offset = "0x1CEA8F8", VA = "0x1CEA8F8")]
			get
			{
				return default(DeleteUserResponse);
			}
			[Token(Token = "0x60128B0")]
			[Address(RVA = "0x1CEA904", Offset = "0x1CEA904", VA = "0x1CEA904")]
			set
			{
			}
		}

		// Token: 0x060128B1 RID: 75953 RVA: 0x000773B8 File Offset: 0x000755B8
		[Token(Token = "0x60128B1")]
		[Address(RVA = "0x1CEA914", Offset = "0x1CEA914", VA = "0x1CEA914", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060128B2 RID: 75954 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128B2")]
		[Address(RVA = "0x1CEA93C", Offset = "0x1CEA93C", VA = "0x1CEA93C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060128B3 RID: 75955 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128B3")]
		[Address(RVA = "0x1CEAAAC", Offset = "0x1CEAAAC", VA = "0x1CEAAAC", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x060128B4 RID: 75956 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128B4")]
		[Address(RVA = "0x1CEAAB0", Offset = "0x1CEAAB0", VA = "0x1CEAAB0")]
		public DeleteUserHttpCommand()
		{
		}

		// Token: 0x0400EABB RID: 60091
		[Token(Token = "0x400EABB")]
		[FieldOffset(Offset = "0x18")]
		private DeleteUserResponse <Response>k__BackingField;
	}
}
