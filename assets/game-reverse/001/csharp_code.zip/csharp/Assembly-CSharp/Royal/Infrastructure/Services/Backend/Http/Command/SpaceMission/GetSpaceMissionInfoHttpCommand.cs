﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SpaceMission
{
	// Token: 0x02002540 RID: 9536
	[Token(Token = "0x2002540")]
	public class GetSpaceMissionInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002738 RID: 10040
		// (get) Token: 0x06012A3E RID: 76350 RVA: 0x000782A0 File Offset: 0x000764A0
		[Token(Token = "0x17002738")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A3E")]
			[Address(RVA = "0x1CFF338", Offset = "0x1CFF338", VA = "0x1CFF338", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002739 RID: 10041
		// (get) Token: 0x06012A3F RID: 76351 RVA: 0x000782B8 File Offset: 0x000764B8
		[Token(Token = "0x17002739")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A3F")]
			[Address(RVA = "0x1CFF340", Offset = "0x1CFF340", VA = "0x1CFF340", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A40 RID: 76352 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A40")]
		[Address(RVA = "0x1CFF348", Offset = "0x1CFF348", VA = "0x1CFF348")]
		public GetSpaceMissionInfoHttpCommand(long group)
		{
		}

		// Token: 0x06012A41 RID: 76353 RVA: 0x000782D0 File Offset: 0x000764D0
		[Token(Token = "0x6012A41")]
		[Address(RVA = "0x1CFF370", Offset = "0x1CFF370", VA = "0x1CFF370", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A42 RID: 76354 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A42")]
		[Address(RVA = "0x1CFF518", Offset = "0x1CFF518", VA = "0x1CFF518", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A43 RID: 76355 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A43")]
		[Address(RVA = "0x1CFF688", Offset = "0x1CFF688", VA = "0x1CFF688", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB5F RID: 60255
		[Token(Token = "0x400EB5F")]
		[FieldOffset(Offset = "0x18")]
		private readonly long groupId;
	}
}
