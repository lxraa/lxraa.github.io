﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Scenes.Home.Ui.Sections.Home.UserProfile;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Friends
{
	// Token: 0x0200256C RID: 9580
	[Token(Token = "0x200256C")]
	public class SearchFriendHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027A2 RID: 10146
		// (get) Token: 0x06012B78 RID: 76664 RVA: 0x00079110 File Offset: 0x00077310
		[Token(Token = "0x170027A2")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B78")]
			[Address(RVA = "0x1ED2678", Offset = "0x1ED2678", VA = "0x1ED2678", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027A3 RID: 10147
		// (get) Token: 0x06012B79 RID: 76665 RVA: 0x00079128 File Offset: 0x00077328
		[Token(Token = "0x170027A3")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B79")]
			[Address(RVA = "0x1ED2680", Offset = "0x1ED2680", VA = "0x1ED2680", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B7A RID: 76666 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B7A")]
		[Address(RVA = "0x1ED2688", Offset = "0x1ED2688", VA = "0x1ED2688")]
		public SearchFriendHttpCommand(long userId, Action<UserProfileInfo> onCompleted, Action<bool> onFailed)
		{
		}

		// Token: 0x06012B7B RID: 76667 RVA: 0x00079140 File Offset: 0x00077340
		[Token(Token = "0x6012B7B")]
		[Address(RVA = "0x1ED26E0", Offset = "0x1ED26E0", VA = "0x1ED26E0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B7C RID: 76668 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B7C")]
		[Address(RVA = "0x1ED2700", Offset = "0x1ED2700", VA = "0x1ED2700", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B7D RID: 76669 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B7D")]
		[Address(RVA = "0x1ED2C14", Offset = "0x1ED2C14", VA = "0x1ED2C14", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBE3 RID: 60387
		[Token(Token = "0x400EBE3")]
		[FieldOffset(Offset = "0x18")]
		private readonly long userId;

		// Token: 0x0400EBE4 RID: 60388
		[Token(Token = "0x400EBE4")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action<UserProfileInfo> onCompleted;

		// Token: 0x0400EBE5 RID: 60389
		[Token(Token = "0x400EBE5")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action<bool> onFailed;
	}
}
