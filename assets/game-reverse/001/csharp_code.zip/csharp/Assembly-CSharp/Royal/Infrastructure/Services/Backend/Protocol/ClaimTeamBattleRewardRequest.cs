﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002364 RID: 9060
	[Token(Token = "0x2002364")]
	public struct ClaimTeamBattleRewardRequest : IFlatbufferObject
	{
		// Token: 0x17001F49 RID: 8009
		// (get) Token: 0x06010D79 RID: 68985 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F49")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D79")]
			[Address(RVA = "0x214A288", Offset = "0x214A288", VA = "0x214A288", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D7A RID: 68986 RVA: 0x000617D0 File Offset: 0x0005F9D0
		[Token(Token = "0x6010D7A")]
		[Address(RVA = "0x214A290", Offset = "0x214A290", VA = "0x214A290")]
		public static ClaimTeamBattleRewardRequest GetRootAsClaimTeamBattleRewardRequest(ByteBuffer _bb)
		{
			return default(ClaimTeamBattleRewardRequest);
		}

		// Token: 0x06010D7B RID: 68987 RVA: 0x000617E8 File Offset: 0x0005F9E8
		[Token(Token = "0x6010D7B")]
		[Address(RVA = "0x214A29C", Offset = "0x214A29C", VA = "0x214A29C")]
		public static ClaimTeamBattleRewardRequest GetRootAsClaimTeamBattleRewardRequest(ByteBuffer _bb, ClaimTeamBattleRewardRequest obj)
		{
			return default(ClaimTeamBattleRewardRequest);
		}

		// Token: 0x06010D7C RID: 68988 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D7C")]
		[Address(RVA = "0x214A34C", Offset = "0x214A34C", VA = "0x214A34C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D7D RID: 68989 RVA: 0x00061800 File Offset: 0x0005FA00
		[Token(Token = "0x6010D7D")]
		[Address(RVA = "0x214A314", Offset = "0x214A314", VA = "0x214A314")]
		public ClaimTeamBattleRewardRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimTeamBattleRewardRequest);
		}

		// Token: 0x17001F4A RID: 8010
		// (get) Token: 0x06010D7E RID: 68990 RVA: 0x00061818 File Offset: 0x0005FA18
		[Token(Token = "0x17001F4A")]
		public long GroupId
		{
			[Token(Token = "0x6010D7E")]
			[Address(RVA = "0x214A35C", Offset = "0x214A35C", VA = "0x214A35C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F4B RID: 8011
		// (get) Token: 0x06010D7F RID: 68991 RVA: 0x00061830 File Offset: 0x0005FA30
		[Token(Token = "0x17001F4B")]
		public long TeamId
		{
			[Token(Token = "0x6010D7F")]
			[Address(RVA = "0x214A3A4", Offset = "0x214A3A4", VA = "0x214A3A4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F4C RID: 8012
		// (get) Token: 0x06010D80 RID: 68992 RVA: 0x00061848 File Offset: 0x0005FA48
		[Token(Token = "0x17001F4C")]
		public CurrentUserInventory? DeprecatedCurrentUserInventory
		{
			[Token(Token = "0x6010D80")]
			[Address(RVA = "0x214A3EC", Offset = "0x214A3EC", VA = "0x214A3EC")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D81 RID: 68993 RVA: 0x00061860 File Offset: 0x0005FA60
		[Token(Token = "0x6010D81")]
		[Address(RVA = "0x214A4AC", Offset = "0x214A4AC", VA = "0x214A4AC")]
		public static Offset<ClaimTeamBattleRewardRequest> CreateClaimTeamBattleRewardRequest(FlatBufferBuilder builder, long group_id = 0L, long team_id = 0L, [Optional] Offset<CurrentUserInventory> deprecated_current_user_inventoryOffset)
		{
			return default(Offset<ClaimTeamBattleRewardRequest>);
		}

		// Token: 0x06010D82 RID: 68994 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D82")]
		[Address(RVA = "0x214A5E8", Offset = "0x214A5E8", VA = "0x214A5E8")]
		public static void StartClaimTeamBattleRewardRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D83 RID: 68995 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D83")]
		[Address(RVA = "0x214A53C", Offset = "0x214A53C", VA = "0x214A53C")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06010D84 RID: 68996 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D84")]
		[Address(RVA = "0x214A51C", Offset = "0x214A51C", VA = "0x214A51C")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x06010D85 RID: 68997 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D85")]
		[Address(RVA = "0x214A55C", Offset = "0x214A55C", VA = "0x214A55C")]
		public static void AddDeprecatedCurrentUserInventory(FlatBufferBuilder builder, Offset<CurrentUserInventory> deprecatedCurrentUserInventoryOffset)
		{
		}

		// Token: 0x06010D86 RID: 68998 RVA: 0x00061878 File Offset: 0x0005FA78
		[Token(Token = "0x6010D86")]
		[Address(RVA = "0x214A57C", Offset = "0x214A57C", VA = "0x214A57C")]
		public static Offset<ClaimTeamBattleRewardRequest> EndClaimTeamBattleRewardRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimTeamBattleRewardRequest>);
		}

		// Token: 0x0400E66A RID: 58986
		[Token(Token = "0x400E66A")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
