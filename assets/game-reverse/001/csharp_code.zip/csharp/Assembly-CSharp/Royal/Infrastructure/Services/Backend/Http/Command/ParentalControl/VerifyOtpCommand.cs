﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.ParentalControl
{
	// Token: 0x02002555 RID: 9557
	[Token(Token = "0x2002555")]
	public class VerifyOtpCommand : BaseHttpCommand
	{
		// Token: 0x1700276B RID: 10091
		// (get) Token: 0x06012AD9 RID: 76505 RVA: 0x00078978 File Offset: 0x00076B78
		[Token(Token = "0x1700276B")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AD9")]
			[Address(RVA = "0x1ECDF08", Offset = "0x1ECDF08", VA = "0x1ECDF08", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700276C RID: 10092
		// (get) Token: 0x06012ADA RID: 76506 RVA: 0x00078990 File Offset: 0x00076B90
		[Token(Token = "0x1700276C")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012ADA")]
			[Address(RVA = "0x1ECDF10", Offset = "0x1ECDF10", VA = "0x1ECDF10", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012ADB RID: 76507 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ADB")]
		[Address(RVA = "0x1ECDF18", Offset = "0x1ECDF18", VA = "0x1ECDF18")]
		public VerifyOtpCommand(int verificationCode, OTPVerificationType otpVerificationType, string email, Action<VerifyOTPResponse> onSuccess, Action<VerifyOTPResponse?> onFail)
		{
		}

		// Token: 0x06012ADC RID: 76508 RVA: 0x000789A8 File Offset: 0x00076BA8
		[Token(Token = "0x6012ADC")]
		[Address(RVA = "0x1ECDF90", Offset = "0x1ECDF90", VA = "0x1ECDF90", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012ADD RID: 76509 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ADD")]
		[Address(RVA = "0x1ECDFDC", Offset = "0x1ECDFDC", VA = "0x1ECDFDC", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012ADE RID: 76510 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ADE")]
		[Address(RVA = "0x1ECE0E8", Offset = "0x1ECE0E8", VA = "0x1ECE0E8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBA8 RID: 60328
		[Token(Token = "0x400EBA8")]
		[FieldOffset(Offset = "0x14")]
		private readonly int verificationCode;

		// Token: 0x0400EBA9 RID: 60329
		[Token(Token = "0x400EBA9")]
		[FieldOffset(Offset = "0x18")]
		private readonly OTPVerificationType otpVerificationType;

		// Token: 0x0400EBAA RID: 60330
		[Token(Token = "0x400EBAA")]
		[FieldOffset(Offset = "0x20")]
		private readonly string email;

		// Token: 0x0400EBAB RID: 60331
		[Token(Token = "0x400EBAB")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action<VerifyOTPResponse> onSuccess;

		// Token: 0x0400EBAC RID: 60332
		[Token(Token = "0x400EBAC")]
		[FieldOffset(Offset = "0x30")]
		private readonly Action<VerifyOTPResponse?> onFail;
	}
}
