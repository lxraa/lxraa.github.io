﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Social
{
	// Token: 0x02002543 RID: 9539
	[Token(Token = "0x2002543")]
	public class DismissFriendSuggestionHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002740 RID: 10048
		// (get) Token: 0x06012A5C RID: 76380 RVA: 0x000783A8 File Offset: 0x000765A8
		[Token(Token = "0x17002740")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A5C")]
			[Address(RVA = "0x1ECA048", Offset = "0x1ECA048", VA = "0x1ECA048", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002741 RID: 10049
		// (get) Token: 0x06012A5D RID: 76381 RVA: 0x000783C0 File Offset: 0x000765C0
		[Token(Token = "0x17002741")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A5D")]
			[Address(RVA = "0x1ECA050", Offset = "0x1ECA050", VA = "0x1ECA050", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A5E RID: 76382 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A5E")]
		[Address(RVA = "0x1ECA058", Offset = "0x1ECA058", VA = "0x1ECA058")]
		public DismissFriendSuggestionHttpCommand(long userId, Action<bool> onCompleted)
		{
		}

		// Token: 0x06012A5F RID: 76383 RVA: 0x000783D8 File Offset: 0x000765D8
		[Token(Token = "0x6012A5F")]
		[Address(RVA = "0x1ECA090", Offset = "0x1ECA090", VA = "0x1ECA090", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A60 RID: 76384 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A60")]
		[Address(RVA = "0x1ECA0B0", Offset = "0x1ECA0B0", VA = "0x1ECA0B0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A61 RID: 76385 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A61")]
		[Address(RVA = "0x1ECA344", Offset = "0x1ECA344", VA = "0x1ECA344", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB71 RID: 60273
		[Token(Token = "0x400EB71")]
		[FieldOffset(Offset = "0x18")]
		private readonly long userId;

		// Token: 0x0400EB72 RID: 60274
		[Token(Token = "0x400EB72")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action<bool> onCompleted;
	}
}
