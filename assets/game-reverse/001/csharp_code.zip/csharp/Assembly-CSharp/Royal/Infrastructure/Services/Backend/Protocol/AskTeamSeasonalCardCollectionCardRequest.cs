﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002343 RID: 9027
	[Token(Token = "0x2002343")]
	public struct AskTeamSeasonalCardCollectionCardRequest : IFlatbufferObject
	{
		// Token: 0x17001ED5 RID: 7893
		// (get) Token: 0x06010BB5 RID: 68533 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001ED5")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010BB5")]
			[Address(RVA = "0x2143AC4", Offset = "0x2143AC4", VA = "0x2143AC4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BB6 RID: 68534 RVA: 0x00060150 File Offset: 0x0005E350
		[Token(Token = "0x6010BB6")]
		[Address(RVA = "0x2143ACC", Offset = "0x2143ACC", VA = "0x2143ACC")]
		public static AskTeamSeasonalCardCollectionCardRequest GetRootAsAskTeamSeasonalCardCollectionCardRequest(ByteBuffer _bb)
		{
			return default(AskTeamSeasonalCardCollectionCardRequest);
		}

		// Token: 0x06010BB7 RID: 68535 RVA: 0x00060168 File Offset: 0x0005E368
		[Token(Token = "0x6010BB7")]
		[Address(RVA = "0x2143AD8", Offset = "0x2143AD8", VA = "0x2143AD8")]
		public static AskTeamSeasonalCardCollectionCardRequest GetRootAsAskTeamSeasonalCardCollectionCardRequest(ByteBuffer _bb, AskTeamSeasonalCardCollectionCardRequest obj)
		{
			return default(AskTeamSeasonalCardCollectionCardRequest);
		}

		// Token: 0x06010BB8 RID: 68536 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BB8")]
		[Address(RVA = "0x2143B88", Offset = "0x2143B88", VA = "0x2143B88", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010BB9 RID: 68537 RVA: 0x00060180 File Offset: 0x0005E380
		[Token(Token = "0x6010BB9")]
		[Address(RVA = "0x2143B50", Offset = "0x2143B50", VA = "0x2143B50")]
		public AskTeamSeasonalCardCollectionCardRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(AskTeamSeasonalCardCollectionCardRequest);
		}

		// Token: 0x17001ED6 RID: 7894
		// (get) Token: 0x06010BBA RID: 68538 RVA: 0x00060198 File Offset: 0x0005E398
		[Token(Token = "0x17001ED6")]
		public long TeamId
		{
			[Token(Token = "0x6010BBA")]
			[Address(RVA = "0x2143B98", Offset = "0x2143B98", VA = "0x2143B98")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001ED7 RID: 7895
		// (get) Token: 0x06010BBB RID: 68539 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001ED7")]
		public string UserName
		{
			[Token(Token = "0x6010BBB")]
			[Address(RVA = "0x2143BE0", Offset = "0x2143BE0", VA = "0x2143BE0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BBC RID: 68540 RVA: 0x000601B0 File Offset: 0x0005E3B0
		[Token(Token = "0x6010BBC")]
		[Address(RVA = "0x2143C1C", Offset = "0x2143C1C", VA = "0x2143C1C")]
		public ArraySegment<byte>? GetUserNameBytes()
		{
			return null;
		}

		// Token: 0x06010BBD RID: 68541 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010BBD")]
		[Address(RVA = "0x2143C54", Offset = "0x2143C54", VA = "0x2143C54")]
		public byte[] GetUserNameArray()
		{
			return null;
		}

		// Token: 0x17001ED8 RID: 7896
		// (get) Token: 0x06010BBE RID: 68542 RVA: 0x000601C8 File Offset: 0x0005E3C8
		[Token(Token = "0x17001ED8")]
		public ChatProfile? Profile
		{
			[Token(Token = "0x6010BBE")]
			[Address(RVA = "0x2143CA0", Offset = "0x2143CA0", VA = "0x2143CA0")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001ED9 RID: 7897
		// (get) Token: 0x06010BBF RID: 68543 RVA: 0x000601E0 File Offset: 0x0005E3E0
		[Token(Token = "0x17001ED9")]
		public SpecialChatProfile? SpecialProfile
		{
			[Token(Token = "0x6010BBF")]
			[Address(RVA = "0x2143D58", Offset = "0x2143D58", VA = "0x2143D58")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001EDA RID: 7898
		// (get) Token: 0x06010BC0 RID: 68544 RVA: 0x000601F8 File Offset: 0x0005E3F8
		[Token(Token = "0x17001EDA")]
		public CardInfo? CardInfo
		{
			[Token(Token = "0x6010BC0")]
			[Address(RVA = "0x2143E18", Offset = "0x2143E18", VA = "0x2143E18")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BC1 RID: 68545 RVA: 0x00060210 File Offset: 0x0005E410
		[Token(Token = "0x6010BC1")]
		[Address(RVA = "0x2143F08", Offset = "0x2143F08", VA = "0x2143F08")]
		public static Offset<AskTeamSeasonalCardCollectionCardRequest> CreateAskTeamSeasonalCardCollectionCardRequest(FlatBufferBuilder builder, long team_id = 0L, [Optional] StringOffset user_nameOffset, [Optional] Offset<ChatProfile> profileOffset, [Optional] Offset<SpecialChatProfile> special_profileOffset, [Optional] Offset<CardInfo> card_infoOffset)
		{
			return default(Offset<AskTeamSeasonalCardCollectionCardRequest>);
		}

		// Token: 0x06010BC2 RID: 68546 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BC2")]
		[Address(RVA = "0x21440AC", Offset = "0x21440AC", VA = "0x21440AC")]
		public static void StartAskTeamSeasonalCardCollectionCardRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010BC3 RID: 68547 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BC3")]
		[Address(RVA = "0x2143FA0", Offset = "0x2143FA0", VA = "0x2143FA0")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x06010BC4 RID: 68548 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BC4")]
		[Address(RVA = "0x2144020", Offset = "0x2144020", VA = "0x2144020")]
		public static void AddUserName(FlatBufferBuilder builder, StringOffset userNameOffset)
		{
		}

		// Token: 0x06010BC5 RID: 68549 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BC5")]
		[Address(RVA = "0x2144000", Offset = "0x2144000", VA = "0x2144000")]
		public static void AddProfile(FlatBufferBuilder builder, Offset<ChatProfile> profileOffset)
		{
		}

		// Token: 0x06010BC6 RID: 68550 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BC6")]
		[Address(RVA = "0x2143FE0", Offset = "0x2143FE0", VA = "0x2143FE0")]
		public static void AddSpecialProfile(FlatBufferBuilder builder, Offset<SpecialChatProfile> specialProfileOffset)
		{
		}

		// Token: 0x06010BC7 RID: 68551 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BC7")]
		[Address(RVA = "0x2143FC0", Offset = "0x2143FC0", VA = "0x2143FC0")]
		public static void AddCardInfo(FlatBufferBuilder builder, Offset<CardInfo> cardInfoOffset)
		{
		}

		// Token: 0x06010BC8 RID: 68552 RVA: 0x00060228 File Offset: 0x0005E428
		[Token(Token = "0x6010BC8")]
		[Address(RVA = "0x2144040", Offset = "0x2144040", VA = "0x2144040")]
		public static Offset<AskTeamSeasonalCardCollectionCardRequest> EndAskTeamSeasonalCardCollectionCardRequest(FlatBufferBuilder builder)
		{
			return default(Offset<AskTeamSeasonalCardCollectionCardRequest>);
		}

		// Token: 0x0400E627 RID: 58919
		[Token(Token = "0x400E627")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
