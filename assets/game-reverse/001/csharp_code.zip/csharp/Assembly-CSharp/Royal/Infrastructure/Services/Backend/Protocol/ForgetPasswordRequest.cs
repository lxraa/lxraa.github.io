﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B7 RID: 9143
	[Token(Token = "0x20023B7")]
	public struct ForgetPasswordRequest : IFlatbufferObject
	{
		// Token: 0x17002093 RID: 8339
		// (get) Token: 0x06011234 RID: 70196 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002093")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011234")]
			[Address(RVA = "0x1CA9C2C", Offset = "0x1CA9C2C", VA = "0x1CA9C2C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011235 RID: 70197 RVA: 0x00065610 File Offset: 0x00063810
		[Token(Token = "0x6011235")]
		[Address(RVA = "0x1CA9C34", Offset = "0x1CA9C34", VA = "0x1CA9C34")]
		public static ForgetPasswordRequest GetRootAsForgetPasswordRequest(ByteBuffer _bb)
		{
			return default(ForgetPasswordRequest);
		}

		// Token: 0x06011236 RID: 70198 RVA: 0x00065628 File Offset: 0x00063828
		[Token(Token = "0x6011236")]
		[Address(RVA = "0x1CA9C40", Offset = "0x1CA9C40", VA = "0x1CA9C40")]
		public static ForgetPasswordRequest GetRootAsForgetPasswordRequest(ByteBuffer _bb, ForgetPasswordRequest obj)
		{
			return default(ForgetPasswordRequest);
		}

		// Token: 0x06011237 RID: 70199 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011237")]
		[Address(RVA = "0x1CA9CF0", Offset = "0x1CA9CF0", VA = "0x1CA9CF0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011238 RID: 70200 RVA: 0x00065640 File Offset: 0x00063840
		[Token(Token = "0x6011238")]
		[Address(RVA = "0x1CA9CB8", Offset = "0x1CA9CB8", VA = "0x1CA9CB8")]
		public ForgetPasswordRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ForgetPasswordRequest);
		}

		// Token: 0x06011239 RID: 70201 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011239")]
		[Address(RVA = "0x1CA9D00", Offset = "0x1CA9D00", VA = "0x1CA9D00")]
		public static void StartForgetPasswordRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601123A RID: 70202 RVA: 0x00065658 File Offset: 0x00063858
		[Token(Token = "0x601123A")]
		[Address(RVA = "0x1CA9D18", Offset = "0x1CA9D18", VA = "0x1CA9D18")]
		public static Offset<ForgetPasswordRequest> EndForgetPasswordRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ForgetPasswordRequest>);
		}

		// Token: 0x0400E6EE RID: 59118
		[Token(Token = "0x400E6EE")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
