﻿using System;
using System.Collections.Generic;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Infrastructure.Services.Storage.Tables;

namespace Royal.Infrastructure.Services.Backend.Http.Command.UserProfile
{
	// Token: 0x0200252D RID: 9517
	[Token(Token = "0x200252D")]
	public class SetUserStatsHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700270D RID: 9997
		// (get) Token: 0x060129C0 RID: 76224 RVA: 0x00077CA0 File Offset: 0x00075EA0
		[Token(Token = "0x1700270D")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129C0")]
			[Address(RVA = "0x1CFA880", Offset = "0x1CFA880", VA = "0x1CFA880", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700270E RID: 9998
		// (get) Token: 0x060129C1 RID: 76225 RVA: 0x00077CB8 File Offset: 0x00075EB8
		[Token(Token = "0x1700270E")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129C1")]
			[Address(RVA = "0x1CFA888", Offset = "0x1CFA888", VA = "0x1CFA888", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700270F RID: 9999
		// (get) Token: 0x060129C2 RID: 76226 RVA: 0x00077CD0 File Offset: 0x00075ED0
		// (set) Token: 0x060129C3 RID: 76227 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700270F")]
		private SetStatResponse Response
		{
			[Token(Token = "0x60129C2")]
			[Address(RVA = "0x1CFA890", Offset = "0x1CFA890", VA = "0x1CFA890")]
			get
			{
				return default(SetStatResponse);
			}
			[Token(Token = "0x60129C3")]
			[Address(RVA = "0x1CFA89C", Offset = "0x1CFA89C", VA = "0x1CFA89C")]
			set
			{
			}
		}

		// Token: 0x060129C4 RID: 76228 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129C4")]
		[Address(RVA = "0x1CFA8AC", Offset = "0x1CFA8AC", VA = "0x1CFA8AC")]
		public SetUserStatsHttpCommand(List<UserStatsKeyValue> changedUserStats, Action<List<UserStatsKeyValue>> onSuccess, Action<List<UserStatsKeyValue>> onFail)
		{
		}

		// Token: 0x060129C5 RID: 76229 RVA: 0x00077CE8 File Offset: 0x00075EE8
		[Token(Token = "0x60129C5")]
		[Address(RVA = "0x1CFA90C", Offset = "0x1CFA90C", VA = "0x1CFA90C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129C6 RID: 76230 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129C6")]
		[Address(RVA = "0x1CFACA0", Offset = "0x1CFACA0", VA = "0x1CFACA0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129C7 RID: 76231 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129C7")]
		[Address(RVA = "0x1CFADD0", Offset = "0x1CFADD0", VA = "0x1CFADD0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB27 RID: 60199
		[Token(Token = "0x400EB27")]
		[FieldOffset(Offset = "0x18")]
		private SetStatResponse <Response>k__BackingField;

		// Token: 0x0400EB28 RID: 60200
		[Token(Token = "0x400EB28")]
		[FieldOffset(Offset = "0x28")]
		private readonly List<UserStatsKeyValue> changedUserStats;

		// Token: 0x0400EB29 RID: 60201
		[Token(Token = "0x400EB29")]
		[FieldOffset(Offset = "0x30")]
		private long requestUserId;

		// Token: 0x0400EB2A RID: 60202
		[Token(Token = "0x400EB2A")]
		[FieldOffset(Offset = "0x38")]
		private Action<List<UserStatsKeyValue>> onSuccess;

		// Token: 0x0400EB2B RID: 60203
		[Token(Token = "0x400EB2B")]
		[FieldOffset(Offset = "0x40")]
		private Action<List<UserStatsKeyValue>> onFail;
	}
}
