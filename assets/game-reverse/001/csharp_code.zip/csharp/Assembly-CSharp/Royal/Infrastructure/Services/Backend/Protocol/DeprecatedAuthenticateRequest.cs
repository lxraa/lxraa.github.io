﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200237C RID: 9084
	[Token(Token = "0x200237C")]
	public struct DeprecatedAuthenticateRequest : IFlatbufferObject
	{
		// Token: 0x17001FB9 RID: 8121
		// (get) Token: 0x06010EF1 RID: 69361 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FB9")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010EF1")]
			[Address(RVA = "0x1F94EEC", Offset = "0x1F94EEC", VA = "0x1F94EEC", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EF2 RID: 69362 RVA: 0x00062A90 File Offset: 0x00060C90
		[Token(Token = "0x6010EF2")]
		[Address(RVA = "0x1F94EF4", Offset = "0x1F94EF4", VA = "0x1F94EF4")]
		public static DeprecatedAuthenticateRequest GetRootAsDeprecatedAuthenticateRequest(ByteBuffer _bb)
		{
			return default(DeprecatedAuthenticateRequest);
		}

		// Token: 0x06010EF3 RID: 69363 RVA: 0x00062AA8 File Offset: 0x00060CA8
		[Token(Token = "0x6010EF3")]
		[Address(RVA = "0x1F94F00", Offset = "0x1F94F00", VA = "0x1F94F00")]
		public static DeprecatedAuthenticateRequest GetRootAsDeprecatedAuthenticateRequest(ByteBuffer _bb, DeprecatedAuthenticateRequest obj)
		{
			return default(DeprecatedAuthenticateRequest);
		}

		// Token: 0x06010EF4 RID: 69364 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EF4")]
		[Address(RVA = "0x1F94FB0", Offset = "0x1F94FB0", VA = "0x1F94FB0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010EF5 RID: 69365 RVA: 0x00062AC0 File Offset: 0x00060CC0
		[Token(Token = "0x6010EF5")]
		[Address(RVA = "0x1F94F78", Offset = "0x1F94F78", VA = "0x1F94F78")]
		public DeprecatedAuthenticateRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(DeprecatedAuthenticateRequest);
		}

		// Token: 0x17001FBA RID: 8122
		// (get) Token: 0x06010EF6 RID: 69366 RVA: 0x00062AD8 File Offset: 0x00060CD8
		[Token(Token = "0x17001FBA")]
		public long UserId
		{
			[Token(Token = "0x6010EF6")]
			[Address(RVA = "0x1F94FC0", Offset = "0x1F94FC0", VA = "0x1F94FC0")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FBB RID: 8123
		// (get) Token: 0x06010EF7 RID: 69367 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FBB")]
		public string Token
		{
			[Token(Token = "0x6010EF7")]
			[Address(RVA = "0x1F95008", Offset = "0x1F95008", VA = "0x1F95008")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EF8 RID: 69368 RVA: 0x00062AF0 File Offset: 0x00060CF0
		[Token(Token = "0x6010EF8")]
		[Address(RVA = "0x1F95044", Offset = "0x1F95044", VA = "0x1F95044")]
		public ArraySegment<byte>? GetTokenBytes()
		{
			return null;
		}

		// Token: 0x06010EF9 RID: 69369 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010EF9")]
		[Address(RVA = "0x1F9507C", Offset = "0x1F9507C", VA = "0x1F9507C")]
		public byte[] GetTokenArray()
		{
			return null;
		}

		// Token: 0x17001FBC RID: 8124
		// (get) Token: 0x06010EFA RID: 69370 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FBC")]
		public string DeviceId
		{
			[Token(Token = "0x6010EFA")]
			[Address(RVA = "0x1F950C8", Offset = "0x1F950C8", VA = "0x1F950C8")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EFB RID: 69371 RVA: 0x00062B08 File Offset: 0x00060D08
		[Token(Token = "0x6010EFB")]
		[Address(RVA = "0x1F95104", Offset = "0x1F95104", VA = "0x1F95104")]
		public ArraySegment<byte>? GetDeviceIdBytes()
		{
			return null;
		}

		// Token: 0x06010EFC RID: 69372 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010EFC")]
		[Address(RVA = "0x1F9513C", Offset = "0x1F9513C", VA = "0x1F9513C")]
		public byte[] GetDeviceIdArray()
		{
			return null;
		}

		// Token: 0x17001FBD RID: 8125
		// (get) Token: 0x06010EFD RID: 69373 RVA: 0x00062B20 File Offset: 0x00060D20
		[Token(Token = "0x17001FBD")]
		public int Version
		{
			[Token(Token = "0x6010EFD")]
			[Address(RVA = "0x1F95188", Offset = "0x1F95188", VA = "0x1F95188")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010EFE RID: 69374 RVA: 0x00062B38 File Offset: 0x00060D38
		[Token(Token = "0x6010EFE")]
		[Address(RVA = "0x1F951CC", Offset = "0x1F951CC", VA = "0x1F951CC")]
		public static Offset<DeprecatedAuthenticateRequest> CreateDeprecatedAuthenticateRequest(FlatBufferBuilder builder, long user_id = 0L, [Optional] StringOffset tokenOffset, [Optional] StringOffset device_idOffset, int version = 0)
		{
			return default(Offset<DeprecatedAuthenticateRequest>);
		}

		// Token: 0x06010EFF RID: 69375 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EFF")]
		[Address(RVA = "0x1F95338", Offset = "0x1F95338", VA = "0x1F95338")]
		public static void StartDeprecatedAuthenticateRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F00 RID: 69376 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F00")]
		[Address(RVA = "0x1F9524C", Offset = "0x1F9524C", VA = "0x1F9524C")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010F01 RID: 69377 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F01")]
		[Address(RVA = "0x1F952AC", Offset = "0x1F952AC", VA = "0x1F952AC")]
		public static void AddToken(FlatBufferBuilder builder, StringOffset tokenOffset)
		{
		}

		// Token: 0x06010F02 RID: 69378 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F02")]
		[Address(RVA = "0x1F9528C", Offset = "0x1F9528C", VA = "0x1F9528C")]
		public static void AddDeviceId(FlatBufferBuilder builder, StringOffset deviceIdOffset)
		{
		}

		// Token: 0x06010F03 RID: 69379 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F03")]
		[Address(RVA = "0x1F9526C", Offset = "0x1F9526C", VA = "0x1F9526C")]
		public static void AddVersion(FlatBufferBuilder builder, int version)
		{
		}

		// Token: 0x06010F04 RID: 69380 RVA: 0x00062B50 File Offset: 0x00060D50
		[Token(Token = "0x6010F04")]
		[Address(RVA = "0x1F952CC", Offset = "0x1F952CC", VA = "0x1F952CC")]
		public static Offset<DeprecatedAuthenticateRequest> EndDeprecatedAuthenticateRequest(FlatBufferBuilder builder)
		{
			return default(Offset<DeprecatedAuthenticateRequest>);
		}

		// Token: 0x0400E695 RID: 59029
		[Token(Token = "0x400E695")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
