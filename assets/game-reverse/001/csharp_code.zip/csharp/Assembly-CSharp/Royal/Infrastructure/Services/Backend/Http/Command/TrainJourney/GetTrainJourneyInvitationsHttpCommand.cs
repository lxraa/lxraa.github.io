﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TrainJourney
{
	// Token: 0x02002530 RID: 9520
	[Token(Token = "0x2002530")]
	public class GetTrainJourneyInvitationsHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002714 RID: 10004
		// (get) Token: 0x060129D6 RID: 76246 RVA: 0x00077DC0 File Offset: 0x00075FC0
		[Token(Token = "0x17002714")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129D6")]
			[Address(RVA = "0x1CFB39C", Offset = "0x1CFB39C", VA = "0x1CFB39C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002715 RID: 10005
		// (get) Token: 0x060129D7 RID: 76247 RVA: 0x00077DD8 File Offset: 0x00075FD8
		[Token(Token = "0x17002715")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129D7")]
			[Address(RVA = "0x1CFB3A4", Offset = "0x1CFB3A4", VA = "0x1CFB3A4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060129D8 RID: 76248 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129D8")]
		[Address(RVA = "0x1CFB3AC", Offset = "0x1CFB3AC", VA = "0x1CFB3AC")]
		public GetTrainJourneyInvitationsHttpCommand(bool sendTutorialInvite)
		{
		}

		// Token: 0x060129D9 RID: 76249 RVA: 0x00077DF0 File Offset: 0x00075FF0
		[Token(Token = "0x60129D9")]
		[Address(RVA = "0x1CFB3D4", Offset = "0x1CFB3D4", VA = "0x1CFB3D4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129DA RID: 76250 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129DA")]
		[Address(RVA = "0x1CFB3F4", Offset = "0x1CFB3F4", VA = "0x1CFB3F4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129DB RID: 76251 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129DB")]
		[Address(RVA = "0x1CFB520", Offset = "0x1CFB520", VA = "0x1CFB520", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB2F RID: 60207
		[Token(Token = "0x400EB2F")]
		[FieldOffset(Offset = "0x13")]
		private readonly bool tutorialInvite;
	}
}
