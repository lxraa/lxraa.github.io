﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002594 RID: 9620
	[Token(Token = "0x2002594")]
	public class Inventory1
	{
		// Token: 0x06012D4C RID: 77132 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D4C")]
		[Address(RVA = "0x243A9EC", Offset = "0x243A9EC", VA = "0x243A9EC")]
		public Inventory1()
		{
		}

		// Token: 0x0400ECCA RID: 60618
		[Token(Token = "0x400ECCA")]
		[FieldOffset(Offset = "0x10")]
		public int rck;

		// Token: 0x0400ECCB RID: 60619
		[Token(Token = "0x400ECCB")]
		[FieldOffset(Offset = "0x14")]
		public int tnt;

		// Token: 0x0400ECCC RID: 60620
		[Token(Token = "0x400ECCC")]
		[FieldOffset(Offset = "0x18")]
		public int lb;

		// Token: 0x0400ECCD RID: 60621
		[Token(Token = "0x400ECCD")]
		[FieldOffset(Offset = "0x1C")]
		public int rh;

		// Token: 0x0400ECCE RID: 60622
		[Token(Token = "0x400ECCE")]
		[FieldOffset(Offset = "0x20")]
		public int ar;

		// Token: 0x0400ECCF RID: 60623
		[Token(Token = "0x400ECCF")]
		[FieldOffset(Offset = "0x24")]
		public int ca;

		// Token: 0x0400ECD0 RID: 60624
		[Token(Token = "0x400ECD0")]
		[FieldOffset(Offset = "0x28")]
		public int jh;

		// Token: 0x0400ECD1 RID: 60625
		[Token(Token = "0x400ECD1")]
		[FieldOffset(Offset = "0x2C")]
		public int u_rck;

		// Token: 0x0400ECD2 RID: 60626
		[Token(Token = "0x400ECD2")]
		[FieldOffset(Offset = "0x30")]
		public int u_tnt;

		// Token: 0x0400ECD3 RID: 60627
		[Token(Token = "0x400ECD3")]
		[FieldOffset(Offset = "0x34")]
		public int u_lb;
	}
}
