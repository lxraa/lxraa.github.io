﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Social
{
	// Token: 0x02002542 RID: 9538
	[Token(Token = "0x2002542")]
	public class CreateTeamHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700273D RID: 10045
		// (get) Token: 0x06012A53 RID: 76371 RVA: 0x00078348 File Offset: 0x00076548
		[Token(Token = "0x1700273D")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A53")]
			[Address(RVA = "0x1EC9458", Offset = "0x1EC9458", VA = "0x1EC9458", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700273E RID: 10046
		// (get) Token: 0x06012A54 RID: 76372 RVA: 0x00078360 File Offset: 0x00076560
		[Token(Token = "0x1700273E")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A54")]
			[Address(RVA = "0x1EC9460", Offset = "0x1EC9460", VA = "0x1EC9460", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700273F RID: 10047
		// (get) Token: 0x06012A55 RID: 76373 RVA: 0x00078378 File Offset: 0x00076578
		// (set) Token: 0x06012A56 RID: 76374 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700273F")]
		private CreateTeamResponse Response
		{
			[Token(Token = "0x6012A55")]
			[Address(RVA = "0x1EC9468", Offset = "0x1EC9468", VA = "0x1EC9468")]
			get
			{
				return default(CreateTeamResponse);
			}
			[Token(Token = "0x6012A56")]
			[Address(RVA = "0x1EC9474", Offset = "0x1EC9474", VA = "0x1EC9474")]
			set
			{
			}
		}

		// Token: 0x06012A57 RID: 76375 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A57")]
		[Address(RVA = "0x1EC9484", Offset = "0x1EC9484", VA = "0x1EC9484")]
		public CreateTeamHttpCommand(long teamId, string teamName, string userName, int logo, string description, int minLevel, int minCrown, bool isOpen)
		{
		}

		// Token: 0x06012A58 RID: 76376 RVA: 0x00078390 File Offset: 0x00076590
		[Token(Token = "0x6012A58")]
		[Address(RVA = "0x1EC9520", Offset = "0x1EC9520", VA = "0x1EC9520", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A59 RID: 76377 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A59")]
		[Address(RVA = "0x1EC9670", Offset = "0x1EC9670", VA = "0x1EC9670", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A5A RID: 76378 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A5A")]
		[Address(RVA = "0x1ECA044", Offset = "0x1ECA044", VA = "0x1ECA044", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012A5B RID: 76379 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A5B")]
		[Address(RVA = "0x1EC9EB0", Offset = "0x1EC9EB0", VA = "0x1EC9EB0")]
		private static void UpdateSections()
		{
		}

		// Token: 0x0400EB68 RID: 60264
		[Token(Token = "0x400EB68")]
		[FieldOffset(Offset = "0x18")]
		private CreateTeamResponse <Response>k__BackingField;

		// Token: 0x0400EB69 RID: 60265
		[Token(Token = "0x400EB69")]
		[FieldOffset(Offset = "0x28")]
		private readonly long teamId;

		// Token: 0x0400EB6A RID: 60266
		[Token(Token = "0x400EB6A")]
		[FieldOffset(Offset = "0x30")]
		private readonly string teamName;

		// Token: 0x0400EB6B RID: 60267
		[Token(Token = "0x400EB6B")]
		[FieldOffset(Offset = "0x38")]
		private readonly string userName;

		// Token: 0x0400EB6C RID: 60268
		[Token(Token = "0x400EB6C")]
		[FieldOffset(Offset = "0x40")]
		private readonly int logo;

		// Token: 0x0400EB6D RID: 60269
		[Token(Token = "0x400EB6D")]
		[FieldOffset(Offset = "0x48")]
		private readonly string description;

		// Token: 0x0400EB6E RID: 60270
		[Token(Token = "0x400EB6E")]
		[FieldOffset(Offset = "0x50")]
		private readonly int minLevel;

		// Token: 0x0400EB6F RID: 60271
		[Token(Token = "0x400EB6F")]
		[FieldOffset(Offset = "0x54")]
		private readonly int minCrown;

		// Token: 0x0400EB70 RID: 60272
		[Token(Token = "0x400EB70")]
		[FieldOffset(Offset = "0x58")]
		private readonly bool isOpen;
	}
}
