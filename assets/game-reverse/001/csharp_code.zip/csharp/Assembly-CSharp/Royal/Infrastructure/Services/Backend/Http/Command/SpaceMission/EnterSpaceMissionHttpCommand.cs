﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SpaceMission
{
	// Token: 0x0200253F RID: 9535
	[Token(Token = "0x200253F")]
	public class EnterSpaceMissionHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002735 RID: 10037
		// (get) Token: 0x06012A36 RID: 76342 RVA: 0x00078240 File Offset: 0x00076440
		[Token(Token = "0x17002735")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A36")]
			[Address(RVA = "0x1CFED88", Offset = "0x1CFED88", VA = "0x1CFED88", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002736 RID: 10038
		// (get) Token: 0x06012A37 RID: 76343 RVA: 0x00078258 File Offset: 0x00076458
		[Token(Token = "0x17002736")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A37")]
			[Address(RVA = "0x1CFED90", Offset = "0x1CFED90", VA = "0x1CFED90", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002737 RID: 10039
		// (get) Token: 0x06012A38 RID: 76344 RVA: 0x00078270 File Offset: 0x00076470
		// (set) Token: 0x06012A39 RID: 76345 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002737")]
		public EnterSpaceMissionResponse Response
		{
			[Token(Token = "0x6012A38")]
			[Address(RVA = "0x1CFED98", Offset = "0x1CFED98", VA = "0x1CFED98")]
			get
			{
				return default(EnterSpaceMissionResponse);
			}
			[Token(Token = "0x6012A39")]
			[Address(RVA = "0x1CFEDA4", Offset = "0x1CFEDA4", VA = "0x1CFEDA4")]
			private set
			{
			}
		}

		// Token: 0x06012A3A RID: 76346 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A3A")]
		[Address(RVA = "0x1CFEDB4", Offset = "0x1CFEDB4", VA = "0x1CFEDB4")]
		public EnterSpaceMissionHttpCommand(int step, EventInteractionOrigin eventInteractionOrigin)
		{
		}

		// Token: 0x06012A3B RID: 76347 RVA: 0x00078288 File Offset: 0x00076488
		[Token(Token = "0x6012A3B")]
		[Address(RVA = "0x1CFEDE0", Offset = "0x1CFEDE0", VA = "0x1CFEDE0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A3C RID: 76348 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A3C")]
		[Address(RVA = "0x1CFEFD0", Offset = "0x1CFEFD0", VA = "0x1CFEFD0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A3D RID: 76349 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A3D")]
		[Address(RVA = "0x1CFF334", Offset = "0x1CFF334", VA = "0x1CFF334", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB5C RID: 60252
		[Token(Token = "0x400EB5C")]
		[FieldOffset(Offset = "0x18")]
		private EnterSpaceMissionResponse <Response>k__BackingField;

		// Token: 0x0400EB5D RID: 60253
		[Token(Token = "0x400EB5D")]
		[FieldOffset(Offset = "0x28")]
		private readonly int step;

		// Token: 0x0400EB5E RID: 60254
		[Token(Token = "0x400EB5E")]
		[FieldOffset(Offset = "0x2C")]
		private readonly EventInteractionOrigin eventInteractionOrigin;
	}
}
