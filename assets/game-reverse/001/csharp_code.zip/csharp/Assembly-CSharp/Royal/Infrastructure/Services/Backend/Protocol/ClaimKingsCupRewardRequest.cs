﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200235A RID: 9050
	[Token(Token = "0x200235A")]
	public struct ClaimKingsCupRewardRequest : IFlatbufferObject
	{
		// Token: 0x17001F27 RID: 7975
		// (get) Token: 0x06010CF6 RID: 68854 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F27")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010CF6")]
			[Address(RVA = "0x2148470", Offset = "0x2148470", VA = "0x2148470", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CF7 RID: 68855 RVA: 0x000610F8 File Offset: 0x0005F2F8
		[Token(Token = "0x6010CF7")]
		[Address(RVA = "0x2148478", Offset = "0x2148478", VA = "0x2148478")]
		public static ClaimKingsCupRewardRequest GetRootAsClaimKingsCupRewardRequest(ByteBuffer _bb)
		{
			return default(ClaimKingsCupRewardRequest);
		}

		// Token: 0x06010CF8 RID: 68856 RVA: 0x00061110 File Offset: 0x0005F310
		[Token(Token = "0x6010CF8")]
		[Address(RVA = "0x2148484", Offset = "0x2148484", VA = "0x2148484")]
		public static ClaimKingsCupRewardRequest GetRootAsClaimKingsCupRewardRequest(ByteBuffer _bb, ClaimKingsCupRewardRequest obj)
		{
			return default(ClaimKingsCupRewardRequest);
		}

		// Token: 0x06010CF9 RID: 68857 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CF9")]
		[Address(RVA = "0x2148534", Offset = "0x2148534", VA = "0x2148534", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010CFA RID: 68858 RVA: 0x00061128 File Offset: 0x0005F328
		[Token(Token = "0x6010CFA")]
		[Address(RVA = "0x21484FC", Offset = "0x21484FC", VA = "0x21484FC")]
		public ClaimKingsCupRewardRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimKingsCupRewardRequest);
		}

		// Token: 0x17001F28 RID: 7976
		// (get) Token: 0x06010CFB RID: 68859 RVA: 0x00061140 File Offset: 0x0005F340
		[Token(Token = "0x17001F28")]
		public long GroupId
		{
			[Token(Token = "0x6010CFB")]
			[Address(RVA = "0x2148544", Offset = "0x2148544", VA = "0x2148544")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F29 RID: 7977
		// (get) Token: 0x06010CFC RID: 68860 RVA: 0x00061158 File Offset: 0x0005F358
		[Token(Token = "0x17001F29")]
		public CurrentUserInventory? DeprecatedCurrentUserInventory
		{
			[Token(Token = "0x6010CFC")]
			[Address(RVA = "0x214858C", Offset = "0x214858C", VA = "0x214858C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CFD RID: 68861 RVA: 0x00061170 File Offset: 0x0005F370
		[Token(Token = "0x6010CFD")]
		[Address(RVA = "0x214864C", Offset = "0x214864C", VA = "0x214864C")]
		public static Offset<ClaimKingsCupRewardRequest> CreateClaimKingsCupRewardRequest(FlatBufferBuilder builder, long group_id = 0L, [Optional] Offset<CurrentUserInventory> deprecated_current_user_inventoryOffset)
		{
			return default(Offset<ClaimKingsCupRewardRequest>);
		}

		// Token: 0x06010CFE RID: 68862 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CFE")]
		[Address(RVA = "0x2148750", Offset = "0x2148750", VA = "0x2148750")]
		public static void StartClaimKingsCupRewardRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010CFF RID: 68863 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CFF")]
		[Address(RVA = "0x21486A4", Offset = "0x21486A4", VA = "0x21486A4")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06010D00 RID: 68864 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D00")]
		[Address(RVA = "0x21486C4", Offset = "0x21486C4", VA = "0x21486C4")]
		public static void AddDeprecatedCurrentUserInventory(FlatBufferBuilder builder, Offset<CurrentUserInventory> deprecatedCurrentUserInventoryOffset)
		{
		}

		// Token: 0x06010D01 RID: 68865 RVA: 0x00061188 File Offset: 0x0005F388
		[Token(Token = "0x6010D01")]
		[Address(RVA = "0x21486E4", Offset = "0x21486E4", VA = "0x21486E4")]
		public static Offset<ClaimKingsCupRewardRequest> EndClaimKingsCupRewardRequest(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimKingsCupRewardRequest>);
		}

		// Token: 0x0400E660 RID: 58976
		[Token(Token = "0x400E660")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
