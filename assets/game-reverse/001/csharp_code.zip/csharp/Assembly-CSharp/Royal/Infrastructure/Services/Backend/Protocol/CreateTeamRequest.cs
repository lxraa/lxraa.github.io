﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002372 RID: 9074
	[Token(Token = "0x2002372")]
	public struct CreateTeamRequest : IFlatbufferObject
	{
		// Token: 0x17001F79 RID: 8057
		// (get) Token: 0x06010E20 RID: 69152 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F79")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010E20")]
			[Address(RVA = "0x1F91CF4", Offset = "0x1F91CF4", VA = "0x1F91CF4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E21 RID: 69153 RVA: 0x000620A0 File Offset: 0x000602A0
		[Token(Token = "0x6010E21")]
		[Address(RVA = "0x1F91CFC", Offset = "0x1F91CFC", VA = "0x1F91CFC")]
		public static CreateTeamRequest GetRootAsCreateTeamRequest(ByteBuffer _bb)
		{
			return default(CreateTeamRequest);
		}

		// Token: 0x06010E22 RID: 69154 RVA: 0x000620B8 File Offset: 0x000602B8
		[Token(Token = "0x6010E22")]
		[Address(RVA = "0x1F91D08", Offset = "0x1F91D08", VA = "0x1F91D08")]
		public static CreateTeamRequest GetRootAsCreateTeamRequest(ByteBuffer _bb, CreateTeamRequest obj)
		{
			return default(CreateTeamRequest);
		}

		// Token: 0x06010E23 RID: 69155 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E23")]
		[Address(RVA = "0x1F91DB8", Offset = "0x1F91DB8", VA = "0x1F91DB8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010E24 RID: 69156 RVA: 0x000620D0 File Offset: 0x000602D0
		[Token(Token = "0x6010E24")]
		[Address(RVA = "0x1F91D80", Offset = "0x1F91D80", VA = "0x1F91D80")]
		public CreateTeamRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(CreateTeamRequest);
		}

		// Token: 0x17001F7A RID: 8058
		// (get) Token: 0x06010E25 RID: 69157 RVA: 0x000620E8 File Offset: 0x000602E8
		[Token(Token = "0x17001F7A")]
		public long TeamId
		{
			[Token(Token = "0x6010E25")]
			[Address(RVA = "0x1F91DC8", Offset = "0x1F91DC8", VA = "0x1F91DC8")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F7B RID: 8059
		// (get) Token: 0x06010E26 RID: 69158 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F7B")]
		public string NickName
		{
			[Token(Token = "0x6010E26")]
			[Address(RVA = "0x1F91E10", Offset = "0x1F91E10", VA = "0x1F91E10")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E27 RID: 69159 RVA: 0x00062100 File Offset: 0x00060300
		[Token(Token = "0x6010E27")]
		[Address(RVA = "0x1F91E4C", Offset = "0x1F91E4C", VA = "0x1F91E4C")]
		public ArraySegment<byte>? GetNickNameBytes()
		{
			return null;
		}

		// Token: 0x06010E28 RID: 69160 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010E28")]
		[Address(RVA = "0x1F91E84", Offset = "0x1F91E84", VA = "0x1F91E84")]
		public byte[] GetNickNameArray()
		{
			return null;
		}

		// Token: 0x17001F7C RID: 8060
		// (get) Token: 0x06010E29 RID: 69161 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F7C")]
		public string TeamName
		{
			[Token(Token = "0x6010E29")]
			[Address(RVA = "0x1F91ED0", Offset = "0x1F91ED0", VA = "0x1F91ED0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E2A RID: 69162 RVA: 0x00062118 File Offset: 0x00060318
		[Token(Token = "0x6010E2A")]
		[Address(RVA = "0x1F91F0C", Offset = "0x1F91F0C", VA = "0x1F91F0C")]
		public ArraySegment<byte>? GetTeamNameBytes()
		{
			return null;
		}

		// Token: 0x06010E2B RID: 69163 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010E2B")]
		[Address(RVA = "0x1F91F44", Offset = "0x1F91F44", VA = "0x1F91F44")]
		public byte[] GetTeamNameArray()
		{
			return null;
		}

		// Token: 0x17001F7D RID: 8061
		// (get) Token: 0x06010E2C RID: 69164 RVA: 0x00062130 File Offset: 0x00060330
		[Token(Token = "0x17001F7D")]
		public int Logo
		{
			[Token(Token = "0x6010E2C")]
			[Address(RVA = "0x1F91F90", Offset = "0x1F91F90", VA = "0x1F91F90")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F7E RID: 8062
		// (get) Token: 0x06010E2D RID: 69165 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F7E")]
		public string Description
		{
			[Token(Token = "0x6010E2D")]
			[Address(RVA = "0x1F91FD4", Offset = "0x1F91FD4", VA = "0x1F91FD4")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E2E RID: 69166 RVA: 0x00062148 File Offset: 0x00060348
		[Token(Token = "0x6010E2E")]
		[Address(RVA = "0x1F92010", Offset = "0x1F92010", VA = "0x1F92010")]
		public ArraySegment<byte>? GetDescriptionBytes()
		{
			return null;
		}

		// Token: 0x06010E2F RID: 69167 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010E2F")]
		[Address(RVA = "0x1F92048", Offset = "0x1F92048", VA = "0x1F92048")]
		public byte[] GetDescriptionArray()
		{
			return null;
		}

		// Token: 0x17001F7F RID: 8063
		// (get) Token: 0x06010E30 RID: 69168 RVA: 0x00062160 File Offset: 0x00060360
		[Token(Token = "0x17001F7F")]
		public int MinLevel
		{
			[Token(Token = "0x6010E30")]
			[Address(RVA = "0x1F92094", Offset = "0x1F92094", VA = "0x1F92094")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F80 RID: 8064
		// (get) Token: 0x06010E31 RID: 69169 RVA: 0x00062178 File Offset: 0x00060378
		[Token(Token = "0x17001F80")]
		public bool Type
		{
			[Token(Token = "0x6010E31")]
			[Address(RVA = "0x1F920D8", Offset = "0x1F920D8", VA = "0x1F920D8")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F81 RID: 8065
		// (get) Token: 0x06010E32 RID: 69170 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F81")]
		public string Language
		{
			[Token(Token = "0x6010E32")]
			[Address(RVA = "0x1F92120", Offset = "0x1F92120", VA = "0x1F92120")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E33 RID: 69171 RVA: 0x00062190 File Offset: 0x00060390
		[Token(Token = "0x6010E33")]
		[Address(RVA = "0x1F9215C", Offset = "0x1F9215C", VA = "0x1F9215C")]
		public ArraySegment<byte>? GetLanguageBytes()
		{
			return null;
		}

		// Token: 0x06010E34 RID: 69172 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010E34")]
		[Address(RVA = "0x1F92194", Offset = "0x1F92194", VA = "0x1F92194")]
		public byte[] GetLanguageArray()
		{
			return null;
		}

		// Token: 0x17001F82 RID: 8066
		// (get) Token: 0x06010E35 RID: 69173 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F82")]
		public string DeviceLanguage
		{
			[Token(Token = "0x6010E35")]
			[Address(RVA = "0x1F921E0", Offset = "0x1F921E0", VA = "0x1F921E0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E36 RID: 69174 RVA: 0x000621A8 File Offset: 0x000603A8
		[Token(Token = "0x6010E36")]
		[Address(RVA = "0x1F9221C", Offset = "0x1F9221C", VA = "0x1F9221C")]
		public ArraySegment<byte>? GetDeviceLanguageBytes()
		{
			return null;
		}

		// Token: 0x06010E37 RID: 69175 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010E37")]
		[Address(RVA = "0x1F92254", Offset = "0x1F92254", VA = "0x1F92254")]
		public byte[] GetDeviceLanguageArray()
		{
			return null;
		}

		// Token: 0x17001F83 RID: 8067
		// (get) Token: 0x06010E38 RID: 69176 RVA: 0x000621C0 File Offset: 0x000603C0
		[Token(Token = "0x17001F83")]
		public int MinCrown
		{
			[Token(Token = "0x6010E38")]
			[Address(RVA = "0x1F922A0", Offset = "0x1F922A0", VA = "0x1F922A0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010E39 RID: 69177 RVA: 0x000621D8 File Offset: 0x000603D8
		[Token(Token = "0x6010E39")]
		[Address(RVA = "0x1F922E4", Offset = "0x1F922E4", VA = "0x1F922E4")]
		public static Offset<CreateTeamRequest> CreateCreateTeamRequest(FlatBufferBuilder builder, long team_id = 0L, [Optional] StringOffset nick_nameOffset, [Optional] StringOffset team_nameOffset, int logo = 0, [Optional] StringOffset descriptionOffset, int min_level = 0, bool type = false, [Optional] StringOffset languageOffset, [Optional] StringOffset device_languageOffset, int min_crown = 0)
		{
			return default(Offset<CreateTeamRequest>);
		}

		// Token: 0x06010E3A RID: 69178 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E3A")]
		[Address(RVA = "0x1F92584", Offset = "0x1F92584", VA = "0x1F92584")]
		public static void StartCreateTeamRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010E3B RID: 69179 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E3B")]
		[Address(RVA = "0x1F923D8", Offset = "0x1F923D8", VA = "0x1F923D8")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x06010E3C RID: 69180 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E3C")]
		[Address(RVA = "0x1F924D8", Offset = "0x1F924D8", VA = "0x1F924D8")]
		public static void AddNickName(FlatBufferBuilder builder, StringOffset nickNameOffset)
		{
		}

		// Token: 0x06010E3D RID: 69181 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E3D")]
		[Address(RVA = "0x1F924B8", Offset = "0x1F924B8", VA = "0x1F924B8")]
		public static void AddTeamName(FlatBufferBuilder builder, StringOffset teamNameOffset)
		{
		}

		// Token: 0x06010E3E RID: 69182 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E3E")]
		[Address(RVA = "0x1F92498", Offset = "0x1F92498", VA = "0x1F92498")]
		public static void AddLogo(FlatBufferBuilder builder, int logo)
		{
		}

		// Token: 0x06010E3F RID: 69183 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E3F")]
		[Address(RVA = "0x1F92478", Offset = "0x1F92478", VA = "0x1F92478")]
		public static void AddDescription(FlatBufferBuilder builder, StringOffset descriptionOffset)
		{
		}

		// Token: 0x06010E40 RID: 69184 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E40")]
		[Address(RVA = "0x1F92458", Offset = "0x1F92458", VA = "0x1F92458")]
		public static void AddMinLevel(FlatBufferBuilder builder, int minLevel)
		{
		}

		// Token: 0x06010E41 RID: 69185 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E41")]
		[Address(RVA = "0x1F924F8", Offset = "0x1F924F8", VA = "0x1F924F8")]
		public static void AddType(FlatBufferBuilder builder, bool type)
		{
		}

		// Token: 0x06010E42 RID: 69186 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E42")]
		[Address(RVA = "0x1F92438", Offset = "0x1F92438", VA = "0x1F92438")]
		public static void AddLanguage(FlatBufferBuilder builder, StringOffset languageOffset)
		{
		}

		// Token: 0x06010E43 RID: 69187 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E43")]
		[Address(RVA = "0x1F92418", Offset = "0x1F92418", VA = "0x1F92418")]
		public static void AddDeviceLanguage(FlatBufferBuilder builder, StringOffset deviceLanguageOffset)
		{
		}

		// Token: 0x06010E44 RID: 69188 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E44")]
		[Address(RVA = "0x1F923F8", Offset = "0x1F923F8", VA = "0x1F923F8")]
		public static void AddMinCrown(FlatBufferBuilder builder, int minCrown)
		{
		}

		// Token: 0x06010E45 RID: 69189 RVA: 0x000621F0 File Offset: 0x000603F0
		[Token(Token = "0x6010E45")]
		[Address(RVA = "0x1F92518", Offset = "0x1F92518", VA = "0x1F92518")]
		public static Offset<CreateTeamRequest> EndCreateTeamRequest(FlatBufferBuilder builder)
		{
			return default(Offset<CreateTeamRequest>);
		}

		// Token: 0x0400E68B RID: 59019
		[Token(Token = "0x400E68B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
