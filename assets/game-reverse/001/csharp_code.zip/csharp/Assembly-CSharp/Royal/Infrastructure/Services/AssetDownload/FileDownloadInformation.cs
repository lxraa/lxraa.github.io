﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002585 RID: 9605
	[Token(Token = "0x2002585")]
	public class FileDownloadInformation
	{
		// Token: 0x06012C48 RID: 76872 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C48")]
		[Address(RVA = "0x1EDBCE8", Offset = "0x1EDBCE8", VA = "0x1EDBCE8")]
		public FileDownloadInformation()
		{
		}

		// Token: 0x0400EC49 RID: 60489
		[Token(Token = "0x400EC49")]
		[FieldOffset(Offset = "0x10")]
		public int downloadId;

		// Token: 0x0400EC4A RID: 60490
		[Token(Token = "0x400EC4A")]
		[FieldOffset(Offset = "0x18")]
		public string fileName;

		// Token: 0x0400EC4B RID: 60491
		[Token(Token = "0x400EC4B")]
		[FieldOffset(Offset = "0x20")]
		public string url;

		// Token: 0x0400EC4C RID: 60492
		[Token(Token = "0x400EC4C")]
		[FieldOffset(Offset = "0x28")]
		public string saveDirectory;

		// Token: 0x0400EC4D RID: 60493
		[Token(Token = "0x400EC4D")]
		[FieldOffset(Offset = "0x30")]
		public FileDownloadSettings settings;

		// Token: 0x0400EC4E RID: 60494
		[Token(Token = "0x400EC4E")]
		[FieldOffset(Offset = "0x38")]
		public Action onDownloadStarted;

		// Token: 0x0400EC4F RID: 60495
		[Token(Token = "0x400EC4F")]
		[FieldOffset(Offset = "0x40")]
		public Action<bool, string> onSaveComplete;

		// Token: 0x0400EC50 RID: 60496
		[Token(Token = "0x400EC50")]
		[FieldOffset(Offset = "0x48")]
		public bool isTexture;
	}
}
