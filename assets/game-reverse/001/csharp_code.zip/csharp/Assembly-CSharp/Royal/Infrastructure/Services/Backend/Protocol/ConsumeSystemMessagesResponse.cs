﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200236D RID: 9069
	[Token(Token = "0x200236D")]
	public struct ConsumeSystemMessagesResponse : IFlatbufferObject
	{
		// Token: 0x17001F77 RID: 8055
		// (get) Token: 0x06010E16 RID: 69142 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F77")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010E16")]
			[Address(RVA = "0x1F91AF0", Offset = "0x1F91AF0", VA = "0x1F91AF0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E17 RID: 69143 RVA: 0x00062010 File Offset: 0x00060210
		[Token(Token = "0x6010E17")]
		[Address(RVA = "0x1F91AF8", Offset = "0x1F91AF8", VA = "0x1F91AF8")]
		public static ConsumeSystemMessagesResponse GetRootAsConsumeSystemMessagesResponse(ByteBuffer _bb)
		{
			return default(ConsumeSystemMessagesResponse);
		}

		// Token: 0x06010E18 RID: 69144 RVA: 0x00062028 File Offset: 0x00060228
		[Token(Token = "0x6010E18")]
		[Address(RVA = "0x1F91B04", Offset = "0x1F91B04", VA = "0x1F91B04")]
		public static ConsumeSystemMessagesResponse GetRootAsConsumeSystemMessagesResponse(ByteBuffer _bb, ConsumeSystemMessagesResponse obj)
		{
			return default(ConsumeSystemMessagesResponse);
		}

		// Token: 0x06010E19 RID: 69145 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E19")]
		[Address(RVA = "0x1F91BB4", Offset = "0x1F91BB4", VA = "0x1F91BB4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010E1A RID: 69146 RVA: 0x00062040 File Offset: 0x00060240
		[Token(Token = "0x6010E1A")]
		[Address(RVA = "0x1F91B7C", Offset = "0x1F91B7C", VA = "0x1F91B7C")]
		public ConsumeSystemMessagesResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ConsumeSystemMessagesResponse);
		}

		// Token: 0x17001F78 RID: 8056
		// (get) Token: 0x06010E1B RID: 69147 RVA: 0x00062058 File Offset: 0x00060258
		[Token(Token = "0x17001F78")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010E1B")]
			[Address(RVA = "0x1F91BC4", Offset = "0x1F91BC4", VA = "0x1F91BC4")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x06010E1C RID: 69148 RVA: 0x00062070 File Offset: 0x00060270
		[Token(Token = "0x6010E1C")]
		[Address(RVA = "0x1F91C08", Offset = "0x1F91C08", VA = "0x1F91C08")]
		public static Offset<ConsumeSystemMessagesResponse> CreateConsumeSystemMessagesResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success)
		{
			return default(Offset<ConsumeSystemMessagesResponse>);
		}

		// Token: 0x06010E1D RID: 69149 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E1D")]
		[Address(RVA = "0x1F91CDC", Offset = "0x1F91CDC", VA = "0x1F91CDC")]
		public static void StartConsumeSystemMessagesResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010E1E RID: 69150 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E1E")]
		[Address(RVA = "0x1F91C50", Offset = "0x1F91C50", VA = "0x1F91C50")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010E1F RID: 69151 RVA: 0x00062088 File Offset: 0x00060288
		[Token(Token = "0x6010E1F")]
		[Address(RVA = "0x1F91C70", Offset = "0x1F91C70", VA = "0x1F91C70")]
		public static Offset<ConsumeSystemMessagesResponse> EndConsumeSystemMessagesResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ConsumeSystemMessagesResponse>);
		}

		// Token: 0x0400E673 RID: 58995
		[Token(Token = "0x400E673")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
