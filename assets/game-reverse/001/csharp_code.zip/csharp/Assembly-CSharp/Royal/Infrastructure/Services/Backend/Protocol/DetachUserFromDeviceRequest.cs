﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002380 RID: 9088
	[Token(Token = "0x2002380")]
	public struct DetachUserFromDeviceRequest : IFlatbufferObject
	{
		// Token: 0x17001FD0 RID: 8144
		// (get) Token: 0x06010F52 RID: 69458 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FD0")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F52")]
			[Address(RVA = "0x1F969D4", Offset = "0x1F969D4", VA = "0x1F969D4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F53 RID: 69459 RVA: 0x00062FA0 File Offset: 0x000611A0
		[Token(Token = "0x6010F53")]
		[Address(RVA = "0x1F969DC", Offset = "0x1F969DC", VA = "0x1F969DC")]
		public static DetachUserFromDeviceRequest GetRootAsDetachUserFromDeviceRequest(ByteBuffer _bb)
		{
			return default(DetachUserFromDeviceRequest);
		}

		// Token: 0x06010F54 RID: 69460 RVA: 0x00062FB8 File Offset: 0x000611B8
		[Token(Token = "0x6010F54")]
		[Address(RVA = "0x1F969E8", Offset = "0x1F969E8", VA = "0x1F969E8")]
		public static DetachUserFromDeviceRequest GetRootAsDetachUserFromDeviceRequest(ByteBuffer _bb, DetachUserFromDeviceRequest obj)
		{
			return default(DetachUserFromDeviceRequest);
		}

		// Token: 0x06010F55 RID: 69461 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F55")]
		[Address(RVA = "0x1F96A98", Offset = "0x1F96A98", VA = "0x1F96A98", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F56 RID: 69462 RVA: 0x00062FD0 File Offset: 0x000611D0
		[Token(Token = "0x6010F56")]
		[Address(RVA = "0x1F96A60", Offset = "0x1F96A60", VA = "0x1F96A60")]
		public DetachUserFromDeviceRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(DetachUserFromDeviceRequest);
		}

		// Token: 0x17001FD1 RID: 8145
		// (get) Token: 0x06010F57 RID: 69463 RVA: 0x00062FE8 File Offset: 0x000611E8
		[Token(Token = "0x17001FD1")]
		public long UidToDetach
		{
			[Token(Token = "0x6010F57")]
			[Address(RVA = "0x1F96AA8", Offset = "0x1F96AA8", VA = "0x1F96AA8")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FD2 RID: 8146
		// (get) Token: 0x06010F58 RID: 69464 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FD2")]
		public string UserTokenToDetach
		{
			[Token(Token = "0x6010F58")]
			[Address(RVA = "0x1F96AF0", Offset = "0x1F96AF0", VA = "0x1F96AF0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F59 RID: 69465 RVA: 0x00063000 File Offset: 0x00061200
		[Token(Token = "0x6010F59")]
		[Address(RVA = "0x1F96B2C", Offset = "0x1F96B2C", VA = "0x1F96B2C")]
		public ArraySegment<byte>? GetUserTokenToDetachBytes()
		{
			return null;
		}

		// Token: 0x06010F5A RID: 69466 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010F5A")]
		[Address(RVA = "0x1F96B64", Offset = "0x1F96B64", VA = "0x1F96B64")]
		public byte[] GetUserTokenToDetachArray()
		{
			return null;
		}

		// Token: 0x06010F5B RID: 69467 RVA: 0x00063018 File Offset: 0x00061218
		[Token(Token = "0x6010F5B")]
		[Address(RVA = "0x1F96BB0", Offset = "0x1F96BB0", VA = "0x1F96BB0")]
		public static Offset<DetachUserFromDeviceRequest> CreateDetachUserFromDeviceRequest(FlatBufferBuilder builder, long uid_to_detach = 0L, [Optional] StringOffset user_token_to_detachOffset)
		{
			return default(Offset<DetachUserFromDeviceRequest>);
		}

		// Token: 0x06010F5C RID: 69468 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F5C")]
		[Address(RVA = "0x1F96CB4", Offset = "0x1F96CB4", VA = "0x1F96CB4")]
		public static void StartDetachUserFromDeviceRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F5D RID: 69469 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F5D")]
		[Address(RVA = "0x1F96C08", Offset = "0x1F96C08", VA = "0x1F96C08")]
		public static void AddUidToDetach(FlatBufferBuilder builder, long uidToDetach)
		{
		}

		// Token: 0x06010F5E RID: 69470 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F5E")]
		[Address(RVA = "0x1F96C28", Offset = "0x1F96C28", VA = "0x1F96C28")]
		public static void AddUserTokenToDetach(FlatBufferBuilder builder, StringOffset userTokenToDetachOffset)
		{
		}

		// Token: 0x06010F5F RID: 69471 RVA: 0x00063030 File Offset: 0x00061230
		[Token(Token = "0x6010F5F")]
		[Address(RVA = "0x1F96C48", Offset = "0x1F96C48", VA = "0x1F96C48")]
		public static Offset<DetachUserFromDeviceRequest> EndDetachUserFromDeviceRequest(FlatBufferBuilder builder)
		{
			return default(Offset<DetachUserFromDeviceRequest>);
		}

		// Token: 0x0400E699 RID: 59033
		[Token(Token = "0x400E699")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
