﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Social
{
	// Token: 0x02002545 RID: 9541
	[Token(Token = "0x2002545")]
	public class JoinTeamHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002745 RID: 10053
		// (get) Token: 0x06012A6A RID: 76394 RVA: 0x00078450 File Offset: 0x00076650
		[Token(Token = "0x17002745")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A6A")]
			[Address(RVA = "0x1ECA4DC", Offset = "0x1ECA4DC", VA = "0x1ECA4DC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002746 RID: 10054
		// (get) Token: 0x06012A6B RID: 76395 RVA: 0x00078468 File Offset: 0x00076668
		[Token(Token = "0x17002746")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A6B")]
			[Address(RVA = "0x1ECA4E4", Offset = "0x1ECA4E4", VA = "0x1ECA4E4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002747 RID: 10055
		// (get) Token: 0x06012A6C RID: 76396 RVA: 0x00078480 File Offset: 0x00076680
		// (set) Token: 0x06012A6D RID: 76397 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002747")]
		public JoinTeamResponse Response
		{
			[Token(Token = "0x6012A6C")]
			[Address(RVA = "0x1ECA4EC", Offset = "0x1ECA4EC", VA = "0x1ECA4EC")]
			get
			{
				return default(JoinTeamResponse);
			}
			[Token(Token = "0x6012A6D")]
			[Address(RVA = "0x1ECA4F8", Offset = "0x1ECA4F8", VA = "0x1ECA4F8")]
			private set
			{
			}
		}

		// Token: 0x06012A6E RID: 76398 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A6E")]
		[Address(RVA = "0x1ECA508", Offset = "0x1ECA508", VA = "0x1ECA508")]
		public JoinTeamHttpCommand(long teamId, string userName)
		{
		}

		// Token: 0x06012A6F RID: 76399 RVA: 0x00078498 File Offset: 0x00076698
		[Token(Token = "0x6012A6F")]
		[Address(RVA = "0x1ECA584", Offset = "0x1ECA584", VA = "0x1ECA584", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A70 RID: 76400 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A70")]
		[Address(RVA = "0x1ECA688", Offset = "0x1ECA688", VA = "0x1ECA688", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A71 RID: 76401 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A71")]
		[Address(RVA = "0x1ECADF4", Offset = "0x1ECADF4", VA = "0x1ECADF4")]
		private void CheckTeamStatus()
		{
		}

		// Token: 0x06012A72 RID: 76402 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A72")]
		[Address(RVA = "0x1ECAE98", Offset = "0x1ECAE98", VA = "0x1ECAE98", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012A73 RID: 76403 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A73")]
		[Address(RVA = "0x1ECAC60", Offset = "0x1ECAC60", VA = "0x1ECAC60")]
		private static void UpdateSections()
		{
		}

		// Token: 0x0400EB76 RID: 60278
		[Token(Token = "0x400EB76")]
		[FieldOffset(Offset = "0x18")]
		private JoinTeamResponse <Response>k__BackingField;

		// Token: 0x0400EB77 RID: 60279
		[Token(Token = "0x400EB77")]
		[FieldOffset(Offset = "0x28")]
		private readonly long teamId;

		// Token: 0x0400EB78 RID: 60280
		[Token(Token = "0x400EB78")]
		[FieldOffset(Offset = "0x30")]
		private readonly string userName;
	}
}
