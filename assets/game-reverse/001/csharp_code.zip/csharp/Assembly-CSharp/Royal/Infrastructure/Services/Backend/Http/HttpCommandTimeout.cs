﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Http
{
	// Token: 0x0200250B RID: 9483
	[Token(Token = "0x200250B")]
	public struct HttpCommandTimeout
	{
		// Token: 0x0601285E RID: 75870 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601285E")]
		[Address(RVA = "0x1CE6760", Offset = "0x1CE6760", VA = "0x1CE6760")]
		public HttpCommandTimeout(int totalTimeoutMs)
		{
		}

		// Token: 0x0400EA7A RID: 60026
		[Token(Token = "0x400EA7A")]
		public const float CommandTimeOut = 12f;

		// Token: 0x0400EA7B RID: 60027
		[Token(Token = "0x400EA7B")]
		[FieldOffset(Offset = "0x0")]
		public readonly int totalTimeoutMs;

		// Token: 0x0400EA7C RID: 60028
		[Token(Token = "0x400EA7C")]
		[FieldOffset(Offset = "0x4")]
		public readonly int totalTimeoutSec;

		// Token: 0x0400EA7D RID: 60029
		[Token(Token = "0x400EA7D")]
		[FieldOffset(Offset = "0x8")]
		public readonly int responseTimeoutMs;

		// Token: 0x0400EA7E RID: 60030
		[Token(Token = "0x400EA7E")]
		[FieldOffset(Offset = "0xC")]
		public readonly int connectionTimeoutMs;
	}
}
