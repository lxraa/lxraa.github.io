﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.ArcheryArena
{
	// Token: 0x02002579 RID: 9593
	[Token(Token = "0x2002579")]
	public class UpdateArcheryArenaScoreHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027BE RID: 10174
		// (get) Token: 0x06012BCD RID: 76749 RVA: 0x00079530 File Offset: 0x00077730
		[Token(Token = "0x170027BE")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012BCD")]
			[Address(RVA = "0x1ED5BB8", Offset = "0x1ED5BB8", VA = "0x1ED5BB8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027BF RID: 10175
		// (get) Token: 0x06012BCE RID: 76750 RVA: 0x00079548 File Offset: 0x00077748
		[Token(Token = "0x170027BF")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012BCE")]
			[Address(RVA = "0x1ED5BC0", Offset = "0x1ED5BC0", VA = "0x1ED5BC0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170027C0 RID: 10176
		// (get) Token: 0x06012BCF RID: 76751 RVA: 0x00079560 File Offset: 0x00077760
		// (set) Token: 0x06012BD0 RID: 76752 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027C0")]
		private UpdateArcheryArenaScoreResponse Response
		{
			[Token(Token = "0x6012BCF")]
			[Address(RVA = "0x1ED5BC8", Offset = "0x1ED5BC8", VA = "0x1ED5BC8")]
			get
			{
				return default(UpdateArcheryArenaScoreResponse);
			}
			[Token(Token = "0x6012BD0")]
			[Address(RVA = "0x1ED5BD4", Offset = "0x1ED5BD4", VA = "0x1ED5BD4")]
			set
			{
			}
		}

		// Token: 0x06012BD1 RID: 76753 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BD1")]
		[Address(RVA = "0x1ED5BE4", Offset = "0x1ED5BE4", VA = "0x1ED5BE4")]
		public UpdateArcheryArenaScoreHttpCommand(long groupId, int score, int rank, sbyte usersCount)
		{
		}

		// Token: 0x06012BD2 RID: 76754 RVA: 0x00079578 File Offset: 0x00077778
		[Token(Token = "0x6012BD2")]
		[Address(RVA = "0x1ED5C28", Offset = "0x1ED5C28", VA = "0x1ED5C28", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BD3 RID: 76755 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BD3")]
		[Address(RVA = "0x1ED5EC8", Offset = "0x1ED5EC8", VA = "0x1ED5EC8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BD4 RID: 76756 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BD4")]
		[Address(RVA = "0x1ED60C8", Offset = "0x1ED60C8", VA = "0x1ED60C8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EC0C RID: 60428
		[Token(Token = "0x400EC0C")]
		[FieldOffset(Offset = "0x18")]
		private UpdateArcheryArenaScoreResponse <Response>k__BackingField;

		// Token: 0x0400EC0D RID: 60429
		[Token(Token = "0x400EC0D")]
		[FieldOffset(Offset = "0x28")]
		private readonly long groupId;

		// Token: 0x0400EC0E RID: 60430
		[Token(Token = "0x400EC0E")]
		[FieldOffset(Offset = "0x30")]
		private readonly int score;

		// Token: 0x0400EC0F RID: 60431
		[Token(Token = "0x400EC0F")]
		[FieldOffset(Offset = "0x34")]
		private readonly int rank;

		// Token: 0x0400EC10 RID: 60432
		[Token(Token = "0x400EC10")]
		[FieldOffset(Offset = "0x38")]
		private readonly sbyte usersCount;
	}
}
