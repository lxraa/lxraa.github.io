﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002337 RID: 9015
	[Token(Token = "0x2002337")]
	public struct AnswerFriendshipRequest : IFlatbufferObject
	{
		// Token: 0x17001EB0 RID: 7856
		// (get) Token: 0x06010B27 RID: 68391 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EB0")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B27")]
			[Address(RVA = "0x21419C8", Offset = "0x21419C8", VA = "0x21419C8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B28 RID: 68392 RVA: 0x0005F9D0 File Offset: 0x0005DBD0
		[Token(Token = "0x6010B28")]
		[Address(RVA = "0x21419D0", Offset = "0x21419D0", VA = "0x21419D0")]
		public static AnswerFriendshipRequest GetRootAsAnswerFriendshipRequest(ByteBuffer _bb)
		{
			return default(AnswerFriendshipRequest);
		}

		// Token: 0x06010B29 RID: 68393 RVA: 0x0005F9E8 File Offset: 0x0005DBE8
		[Token(Token = "0x6010B29")]
		[Address(RVA = "0x21419DC", Offset = "0x21419DC", VA = "0x21419DC")]
		public static AnswerFriendshipRequest GetRootAsAnswerFriendshipRequest(ByteBuffer _bb, AnswerFriendshipRequest obj)
		{
			return default(AnswerFriendshipRequest);
		}

		// Token: 0x06010B2A RID: 68394 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B2A")]
		[Address(RVA = "0x2141A8C", Offset = "0x2141A8C", VA = "0x2141A8C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B2B RID: 68395 RVA: 0x0005FA00 File Offset: 0x0005DC00
		[Token(Token = "0x6010B2B")]
		[Address(RVA = "0x2141A54", Offset = "0x2141A54", VA = "0x2141A54")]
		public AnswerFriendshipRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(AnswerFriendshipRequest);
		}

		// Token: 0x17001EB1 RID: 7857
		// (get) Token: 0x06010B2C RID: 68396 RVA: 0x0005FA18 File Offset: 0x0005DC18
		[Token(Token = "0x17001EB1")]
		public bool Approved
		{
			[Token(Token = "0x6010B2C")]
			[Address(RVA = "0x2141A9C", Offset = "0x2141A9C", VA = "0x2141A9C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001EB2 RID: 7858
		// (get) Token: 0x06010B2D RID: 68397 RVA: 0x0005FA30 File Offset: 0x0005DC30
		[Token(Token = "0x17001EB2")]
		public long UserId
		{
			[Token(Token = "0x6010B2D")]
			[Address(RVA = "0x2141AE4", Offset = "0x2141AE4", VA = "0x2141AE4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010B2E RID: 68398 RVA: 0x0005FA48 File Offset: 0x0005DC48
		[Token(Token = "0x6010B2E")]
		[Address(RVA = "0x2141B2C", Offset = "0x2141B2C", VA = "0x2141B2C")]
		public static Offset<AnswerFriendshipRequest> CreateAnswerFriendshipRequest(FlatBufferBuilder builder, bool approved = false, long user_id = 0L)
		{
			return default(Offset<AnswerFriendshipRequest>);
		}

		// Token: 0x06010B2F RID: 68399 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B2F")]
		[Address(RVA = "0x2141C30", Offset = "0x2141C30", VA = "0x2141C30")]
		public static void StartAnswerFriendshipRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B30 RID: 68400 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B30")]
		[Address(RVA = "0x2141BA4", Offset = "0x2141BA4", VA = "0x2141BA4")]
		public static void AddApproved(FlatBufferBuilder builder, bool approved)
		{
		}

		// Token: 0x06010B31 RID: 68401 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B31")]
		[Address(RVA = "0x2141B84", Offset = "0x2141B84", VA = "0x2141B84")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010B32 RID: 68402 RVA: 0x0005FA60 File Offset: 0x0005DC60
		[Token(Token = "0x6010B32")]
		[Address(RVA = "0x2141BC4", Offset = "0x2141BC4", VA = "0x2141BC4")]
		public static Offset<AnswerFriendshipRequest> EndAnswerFriendshipRequest(FlatBufferBuilder builder)
		{
			return default(Offset<AnswerFriendshipRequest>);
		}

		// Token: 0x0400E611 RID: 58897
		[Token(Token = "0x400E611")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
