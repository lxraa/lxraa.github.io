﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A7 RID: 9127
	[Token(Token = "0x20023A7")]
	public struct EnterPropellerRushRequest : IFlatbufferObject
	{
		// Token: 0x17002055 RID: 8277
		// (get) Token: 0x0601114C RID: 69964 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002055")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601114C")]
			[Address(RVA = "0x1F9E27C", Offset = "0x1F9E27C", VA = "0x1F9E27C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601114D RID: 69965 RVA: 0x000649B0 File Offset: 0x00062BB0
		[Token(Token = "0x601114D")]
		[Address(RVA = "0x1F9E284", Offset = "0x1F9E284", VA = "0x1F9E284")]
		public static EnterPropellerRushRequest GetRootAsEnterPropellerRushRequest(ByteBuffer _bb)
		{
			return default(EnterPropellerRushRequest);
		}

		// Token: 0x0601114E RID: 69966 RVA: 0x000649C8 File Offset: 0x00062BC8
		[Token(Token = "0x601114E")]
		[Address(RVA = "0x1F9E290", Offset = "0x1F9E290", VA = "0x1F9E290")]
		public static EnterPropellerRushRequest GetRootAsEnterPropellerRushRequest(ByteBuffer _bb, EnterPropellerRushRequest obj)
		{
			return default(EnterPropellerRushRequest);
		}

		// Token: 0x0601114F RID: 69967 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601114F")]
		[Address(RVA = "0x1F9E340", Offset = "0x1F9E340", VA = "0x1F9E340", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011150 RID: 69968 RVA: 0x000649E0 File Offset: 0x00062BE0
		[Token(Token = "0x6011150")]
		[Address(RVA = "0x1F9E308", Offset = "0x1F9E308", VA = "0x1F9E308")]
		public EnterPropellerRushRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterPropellerRushRequest);
		}

		// Token: 0x17002056 RID: 8278
		// (get) Token: 0x06011151 RID: 69969 RVA: 0x000649F8 File Offset: 0x00062BF8
		[Token(Token = "0x17002056")]
		public int Level
		{
			[Token(Token = "0x6011151")]
			[Address(RVA = "0x1F9E350", Offset = "0x1F9E350", VA = "0x1F9E350")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002057 RID: 8279
		// (get) Token: 0x06011152 RID: 69970 RVA: 0x00064A10 File Offset: 0x00062C10
		[Token(Token = "0x17002057")]
		public int Step
		{
			[Token(Token = "0x6011152")]
			[Address(RVA = "0x1F9E394", Offset = "0x1F9E394", VA = "0x1F9E394")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002058 RID: 8280
		// (get) Token: 0x06011153 RID: 69971 RVA: 0x00064A28 File Offset: 0x00062C28
		[Token(Token = "0x17002058")]
		public int ConfigVersion
		{
			[Token(Token = "0x6011153")]
			[Address(RVA = "0x1F9E3D8", Offset = "0x1F9E3D8", VA = "0x1F9E3D8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011154 RID: 69972 RVA: 0x00064A40 File Offset: 0x00062C40
		[Token(Token = "0x6011154")]
		[Address(RVA = "0x1F9E41C", Offset = "0x1F9E41C", VA = "0x1F9E41C")]
		public static Offset<EnterPropellerRushRequest> CreateEnterPropellerRushRequest(FlatBufferBuilder builder, int level = 0, int step = 0, int config_version = 0)
		{
			return default(Offset<EnterPropellerRushRequest>);
		}

		// Token: 0x06011155 RID: 69973 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011155")]
		[Address(RVA = "0x1F9E558", Offset = "0x1F9E558", VA = "0x1F9E558")]
		public static void StartEnterPropellerRushRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011156 RID: 69974 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011156")]
		[Address(RVA = "0x1F9E4CC", Offset = "0x1F9E4CC", VA = "0x1F9E4CC")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x06011157 RID: 69975 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011157")]
		[Address(RVA = "0x1F9E4AC", Offset = "0x1F9E4AC", VA = "0x1F9E4AC")]
		public static void AddStep(FlatBufferBuilder builder, int step)
		{
		}

		// Token: 0x06011158 RID: 69976 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011158")]
		[Address(RVA = "0x1F9E48C", Offset = "0x1F9E48C", VA = "0x1F9E48C")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06011159 RID: 69977 RVA: 0x00064A58 File Offset: 0x00062C58
		[Token(Token = "0x6011159")]
		[Address(RVA = "0x1F9E4EC", Offset = "0x1F9E4EC", VA = "0x1F9E4EC")]
		public static Offset<EnterPropellerRushRequest> EndEnterPropellerRushRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterPropellerRushRequest>);
		}

		// Token: 0x0400E6D9 RID: 59097
		[Token(Token = "0x400E6D9")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
