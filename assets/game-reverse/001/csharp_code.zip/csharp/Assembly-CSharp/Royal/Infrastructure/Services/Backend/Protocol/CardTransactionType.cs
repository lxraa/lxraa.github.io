﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002350 RID: 9040
	[Token(Token = "0x2002350")]
	public enum CardTransactionType : sbyte
	{
		// Token: 0x0400E640 RID: 58944
		[Token(Token = "0x400E640")]
		FRIEND,
		// Token: 0x0400E641 RID: 58945
		[Token(Token = "0x400E641")]
		TEAM_MEMBER,
		// Token: 0x0400E642 RID: 58946
		[Token(Token = "0x400E642")]
		TEAM_CHAT
	}
}
