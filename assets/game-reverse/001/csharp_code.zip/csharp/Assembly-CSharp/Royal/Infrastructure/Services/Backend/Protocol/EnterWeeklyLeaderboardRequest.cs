﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023AF RID: 9135
	[Token(Token = "0x20023AF")]
	public struct EnterWeeklyLeaderboardRequest : IFlatbufferObject
	{
		// Token: 0x1700207A RID: 8314
		// (get) Token: 0x060111C8 RID: 70088 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700207A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60111C8")]
			[Address(RVA = "0x1F9FF60", Offset = "0x1F9FF60", VA = "0x1F9FF60", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060111C9 RID: 70089 RVA: 0x00065028 File Offset: 0x00063228
		[Token(Token = "0x60111C9")]
		[Address(RVA = "0x1F9FF68", Offset = "0x1F9FF68", VA = "0x1F9FF68")]
		public static EnterWeeklyLeaderboardRequest GetRootAsEnterWeeklyLeaderboardRequest(ByteBuffer _bb)
		{
			return default(EnterWeeklyLeaderboardRequest);
		}

		// Token: 0x060111CA RID: 70090 RVA: 0x00065040 File Offset: 0x00063240
		[Token(Token = "0x60111CA")]
		[Address(RVA = "0x1F9FF74", Offset = "0x1F9FF74", VA = "0x1F9FF74")]
		public static EnterWeeklyLeaderboardRequest GetRootAsEnterWeeklyLeaderboardRequest(ByteBuffer _bb, EnterWeeklyLeaderboardRequest obj)
		{
			return default(EnterWeeklyLeaderboardRequest);
		}

		// Token: 0x060111CB RID: 70091 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111CB")]
		[Address(RVA = "0x1FA0024", Offset = "0x1FA0024", VA = "0x1FA0024", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060111CC RID: 70092 RVA: 0x00065058 File Offset: 0x00063258
		[Token(Token = "0x60111CC")]
		[Address(RVA = "0x1F9FFEC", Offset = "0x1F9FFEC", VA = "0x1F9FFEC")]
		public EnterWeeklyLeaderboardRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterWeeklyLeaderboardRequest);
		}

		// Token: 0x1700207B RID: 8315
		// (get) Token: 0x060111CD RID: 70093 RVA: 0x00065070 File Offset: 0x00063270
		[Token(Token = "0x1700207B")]
		public bool IsSocialLoggedIn
		{
			[Token(Token = "0x60111CD")]
			[Address(RVA = "0x1FA0034", Offset = "0x1FA0034", VA = "0x1FA0034")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x060111CE RID: 70094 RVA: 0x00065088 File Offset: 0x00063288
		[Token(Token = "0x60111CE")]
		[Address(RVA = "0x1FA007C", Offset = "0x1FA007C", VA = "0x1FA007C")]
		public static Offset<EnterWeeklyLeaderboardRequest> CreateEnterWeeklyLeaderboardRequest(FlatBufferBuilder builder, bool is_social_logged_in = false)
		{
			return default(Offset<EnterWeeklyLeaderboardRequest>);
		}

		// Token: 0x060111CF RID: 70095 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111CF")]
		[Address(RVA = "0x1FA0150", Offset = "0x1FA0150", VA = "0x1FA0150")]
		public static void StartEnterWeeklyLeaderboardRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060111D0 RID: 70096 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111D0")]
		[Address(RVA = "0x1FA00C4", Offset = "0x1FA00C4", VA = "0x1FA00C4")]
		public static void AddIsSocialLoggedIn(FlatBufferBuilder builder, bool isSocialLoggedIn)
		{
		}

		// Token: 0x060111D1 RID: 70097 RVA: 0x000650A0 File Offset: 0x000632A0
		[Token(Token = "0x60111D1")]
		[Address(RVA = "0x1FA00E4", Offset = "0x1FA00E4", VA = "0x1FA00E4")]
		public static Offset<EnterWeeklyLeaderboardRequest> EndEnterWeeklyLeaderboardRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterWeeklyLeaderboardRequest>);
		}

		// Token: 0x0400E6E1 RID: 59105
		[Token(Token = "0x400E6E1")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
