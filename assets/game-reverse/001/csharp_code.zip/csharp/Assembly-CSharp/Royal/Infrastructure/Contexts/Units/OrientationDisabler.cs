﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units
{
	// Token: 0x020025B1 RID: 9649
	[Token(Token = "0x20025B1")]
	public enum OrientationDisabler
	{
		// Token: 0x0400ED8B RID: 60811
		[Token(Token = "0x400ED8B")]
		None,
		// Token: 0x0400ED8C RID: 60812
		[Token(Token = "0x400ED8C")]
		PlatformConnect,
		// Token: 0x0400ED8D RID: 60813
		[Token(Token = "0x400ED8D")]
		PlatformDisconnect,
		// Token: 0x0400ED8E RID: 60814
		[Token(Token = "0x400ED8E")]
		Purchase,
		// Token: 0x0400ED8F RID: 60815
		[Token(Token = "0x400ED8F")]
		ClocheAnimationInGame,
		// Token: 0x0400ED90 RID: 60816
		[Token(Token = "0x400ED90")]
		SpecialItemCreator,
		// Token: 0x0400ED91 RID: 60817
		[Token(Token = "0x400ED91")]
		ShuffleManagerShuffle,
		// Token: 0x0400ED92 RID: 60818
		[Token(Token = "0x400ED92")]
		ArrowUse,
		// Token: 0x0400ED93 RID: 60819
		[Token(Token = "0x400ED93")]
		CannonUse,
		// Token: 0x0400ED94 RID: 60820
		[Token(Token = "0x400ED94")]
		HammerUse,
		// Token: 0x0400ED95 RID: 60821
		[Token(Token = "0x400ED95")]
		JesterHatUse,
		// Token: 0x0400ED96 RID: 60822
		[Token(Token = "0x400ED96")]
		BirdCollect,
		// Token: 0x0400ED97 RID: 60823
		[Token(Token = "0x400ED97")]
		BirdNestThrow,
		// Token: 0x0400ED98 RID: 60824
		[Token(Token = "0x400ED98")]
		CaldronThrow,
		// Token: 0x0400ED99 RID: 60825
		[Token(Token = "0x400ED99")]
		CoinGoalCollect,
		// Token: 0x0400ED9A RID: 60826
		[Token(Token = "0x400ED9A")]
		CoinRemainingMovesCollect,
		// Token: 0x0400ED9B RID: 60827
		[Token(Token = "0x400ED9B")]
		DrillMove,
		// Token: 0x0400ED9C RID: 60828
		[Token(Token = "0x400ED9C")]
		DynamiteBoxExplode,
		// Token: 0x0400ED9D RID: 60829
		[Token(Token = "0x400ED9D")]
		FrogCollect,
		// Token: 0x0400ED9E RID: 60830
		[Token(Token = "0x400ED9E")]
		GummyThrow,
		// Token: 0x0400ED9F RID: 60831
		[Token(Token = "0x400ED9F")]
		GummyBarThrow,
		// Token: 0x0400EDA0 RID: 60832
		[Token(Token = "0x400EDA0")]
		GummyCollect,
		// Token: 0x0400EDA1 RID: 60833
		[Token(Token = "0x400EDA1")]
		HatThrow,
		// Token: 0x0400EDA2 RID: 60834
		[Token(Token = "0x400EDA2")]
		MatchItemCollect,
		// Token: 0x0400EDA3 RID: 60835
		[Token(Token = "0x400EDA3")]
		MatchItemManagerCollect,
		// Token: 0x0400EDA4 RID: 60836
		[Token(Token = "0x400EDA4")]
		PearlCollect,
		// Token: 0x0400EDA5 RID: 60837
		[Token(Token = "0x400EDA5")]
		RockCollect,
		// Token: 0x0400EDA6 RID: 60838
		[Token(Token = "0x400EDA6")]
		SeedBoxThrow,
		// Token: 0x0400EDA7 RID: 60839
		[Token(Token = "0x400EDA7")]
		CurtainReveal,
		// Token: 0x0400EDA8 RID: 60840
		[Token(Token = "0x400EDA8")]
		TreasureMapReveal,
		// Token: 0x0400EDA9 RID: 60841
		[Token(Token = "0x400EDA9")]
		TreasureMapFinalCollect,
		// Token: 0x0400EDAA RID: 60842
		[Token(Token = "0x400EDAA")]
		KingNightmareIconTutorial,
		// Token: 0x0400EDAB RID: 60843
		[Token(Token = "0x400EDAB")]
		InGameSettings,
		// Token: 0x0400EDAC RID: 60844
		[Token(Token = "0x400EDAC")]
		EgoDialog,
		// Token: 0x0400EDAD RID: 60845
		[Token(Token = "0x400EDAD")]
		LevelFailDialog,
		// Token: 0x0400EDAE RID: 60846
		[Token(Token = "0x400EDAE")]
		OutOfMovesDialog,
		// Token: 0x0400EDAF RID: 60847
		[Token(Token = "0x400EDAF")]
		LevelEndBottomPanel,
		// Token: 0x0400EDB0 RID: 60848
		[Token(Token = "0x400EDB0")]
		LevelWinDialogStarAnimation,
		// Token: 0x0400EDB1 RID: 60849
		[Token(Token = "0x400EDB1")]
		WinLogoAnimationDialog,
		// Token: 0x0400EDB2 RID: 60850
		[Token(Token = "0x400EDB2")]
		GameUiLoading,
		// Token: 0x0400EDB3 RID: 60851
		[Token(Token = "0x400EDB3")]
		GameUiLevelEntryAnimation,
		// Token: 0x0400EDB4 RID: 60852
		[Token(Token = "0x400EDB4")]
		BuildAreTask,
		// Token: 0x0400EDB5 RID: 60853
		[Token(Token = "0x400EDB5")]
		PlaySpendStarAnimation,
		// Token: 0x0400EDB6 RID: 60854
		[Token(Token = "0x400EDB6")]
		EpisodeCompleteAnimation,
		// Token: 0x0400EDB7 RID: 60855
		[Token(Token = "0x400EDB7")]
		KcClaimPanelAnimate,
		// Token: 0x0400EDB8 RID: 60856
		[Token(Token = "0x400EDB8")]
		EnterLeaguePopupAnimation,
		// Token: 0x0400EDB9 RID: 60857
		[Token(Token = "0x400EDB9")]
		RoyalLeagueClaimPanelAnimate,
		// Token: 0x0400EDBA RID: 60858
		[Token(Token = "0x400EDBA")]
		LrClaimPanelAnimate,
		// Token: 0x0400EDBB RID: 60859
		[Token(Token = "0x400EDBB")]
		PinataPartyCollectAnimation,
		// Token: 0x0400EDBC RID: 60860
		[Token(Token = "0x400EDBC")]
		PreLevelDialogShowAnimation,
		// Token: 0x0400EDBD RID: 60861
		[Token(Token = "0x400EDBD")]
		PreviousAreaMovie,
		// Token: 0x0400EDBE RID: 60862
		[Token(Token = "0x400EDBE")]
		RoyalPassIcon,
		// Token: 0x0400EDBF RID: 60863
		[Token(Token = "0x400EDBF")]
		RoyalPassTutorial,
		// Token: 0x0400EDC0 RID: 60864
		[Token(Token = "0x400EDC0")]
		TeamsTutorial,
		// Token: 0x0400EDC1 RID: 60865
		[Token(Token = "0x400EDC1")]
		RoyalPassStepUpAnimation,
		// Token: 0x0400EDC2 RID: 60866
		[Token(Token = "0x400EDC2")]
		SkyRaceCollectAnimation,
		// Token: 0x0400EDC3 RID: 60867
		[Token(Token = "0x400EDC3")]
		SlidingText,
		// Token: 0x0400EDC4 RID: 60868
		[Token(Token = "0x400EDC4")]
		TbClaimPanelAnimate,
		// Token: 0x0400EDC5 RID: 60869
		[Token(Token = "0x400EDC5")]
		TtForceClaimPanelAnimate,
		// Token: 0x0400EDC6 RID: 60870
		[Token(Token = "0x400EDC6")]
		TtClaimPanelAnimate,
		// Token: 0x0400EDC7 RID: 60871
		[Token(Token = "0x400EDC7")]
		IconsViewAnimation,
		// Token: 0x0400EDC8 RID: 60872
		[Token(Token = "0x400EDC8")]
		CoinInfoView,
		// Token: 0x0400EDC9 RID: 60873
		[Token(Token = "0x400EDC9")]
		CoinCollectAnimation,
		// Token: 0x0400EDCA RID: 60874
		[Token(Token = "0x400EDCA")]
		StarCollectAnimation,
		// Token: 0x0400EDCB RID: 60875
		[Token(Token = "0x400EDCB")]
		KingsCupCollectAnimation,
		// Token: 0x0400EDCC RID: 60876
		[Token(Token = "0x400EDCC")]
		LightningRushCollectAnimation,
		// Token: 0x0400EDCD RID: 60877
		[Token(Token = "0x400EDCD")]
		TeamBattleCollectAnimation,
		// Token: 0x0400EDCE RID: 60878
		[Token(Token = "0x400EDCE")]
		TeamTreasureCollectAnimation,
		// Token: 0x0400EDCF RID: 60879
		[Token(Token = "0x400EDCF")]
		LeagueCrownCollectAnimation,
		// Token: 0x0400EDD0 RID: 60880
		[Token(Token = "0x400EDD0")]
		ChatCoinCollectAnimation,
		// Token: 0x0400EDD1 RID: 60881
		[Token(Token = "0x400EDD1")]
		ChatLifeCollectAnimation,
		// Token: 0x0400EDD2 RID: 60882
		[Token(Token = "0x400EDD2")]
		LoadingFade,
		// Token: 0x0400EDD3 RID: 60883
		[Token(Token = "0x400EDD3")]
		SplashView,
		// Token: 0x0400EDD4 RID: 60884
		[Token(Token = "0x400EDD4")]
		SceneChange,
		// Token: 0x0400EDD5 RID: 60885
		[Token(Token = "0x400EDD5")]
		AdminDialog,
		// Token: 0x0400EDD6 RID: 60886
		[Token(Token = "0x400EDD6")]
		PreLevelPanelShowAnimation,
		// Token: 0x0400EDD7 RID: 60887
		[Token(Token = "0x400EDD7")]
		BonusPreLevelDialogShowAnimation,
		// Token: 0x0400EDD8 RID: 60888
		[Token(Token = "0x400EDD8")]
		BowtieCollect,
		// Token: 0x0400EDD9 RID: 60889
		[Token(Token = "0x400EDD9")]
		CookieCollect,
		// Token: 0x0400EDDA RID: 60890
		[Token(Token = "0x400EDDA")]
		MailCollect,
		// Token: 0x0400EDDB RID: 60891
		[Token(Token = "0x400EDDB")]
		DuckCollect,
		// Token: 0x0400EDDC RID: 60892
		[Token(Token = "0x400EDDC")]
		UfoCollect,
		// Token: 0x0400EDDD RID: 60893
		[Token(Token = "0x400EDDD")]
		StoryOrWallLevelCollect,
		// Token: 0x0400EDDE RID: 60894
		[Token(Token = "0x400EDDE")]
		SkyRacePlaneMove,
		// Token: 0x0400EDDF RID: 60895
		[Token(Token = "0x400EDDF")]
		SkyRaceClaimAnimation,
		// Token: 0x0400EDE0 RID: 60896
		[Token(Token = "0x400EDE0")]
		SettingsCollectAnimation,
		// Token: 0x0400EDE1 RID: 60897
		[Token(Token = "0x400EDE1")]
		ItemTutorial,
		// Token: 0x0400EDE2 RID: 60898
		[Token(Token = "0x400EDE2")]
		RemainingMovesItemReplace,
		// Token: 0x0400EDE3 RID: 60899
		[Token(Token = "0x400EDE3")]
		StoryWinSequence,
		// Token: 0x0400EDE4 RID: 60900
		[Token(Token = "0x400EDE4")]
		StoryWin,
		// Token: 0x0400EDE5 RID: 60901
		[Token(Token = "0x400EDE5")]
		RoyalPassBonusBankHitAnimation,
		// Token: 0x0400EDE6 RID: 60902
		[Token(Token = "0x400EDE6")]
		BearCollect,
		// Token: 0x0400EDE7 RID: 60903
		[Token(Token = "0x400EDE7")]
		LevelWinMadnessCollect,
		// Token: 0x0400EDE8 RID: 60904
		[Token(Token = "0x400EDE8")]
		KnDialogShowAnimation,
		// Token: 0x0400EDE9 RID: 60905
		[Token(Token = "0x400EDE9")]
		KnDialogExitAnimation,
		// Token: 0x0400EDEA RID: 60906
		[Token(Token = "0x400EDEA")]
		WildCardUseAnimation,
		// Token: 0x0400EDEB RID: 60907
		[Token(Token = "0x400EDEB")]
		WildCardClaimAnimation,
		// Token: 0x0400EDEC RID: 60908
		[Token(Token = "0x400EDEC")]
		SeasonalCardCollectionSetDialog,
		// Token: 0x0400EDED RID: 60909
		[Token(Token = "0x400EDED")]
		SlotMachineThrow,
		// Token: 0x0400EDEE RID: 60910
		[Token(Token = "0x400EDEE")]
		CardCollectionTutorial,
		// Token: 0x0400EDEF RID: 60911
		[Token(Token = "0x400EDEF")]
		CardCollectionTokenTutorial,
		// Token: 0x0400EDF0 RID: 60912
		[Token(Token = "0x400EDF0")]
		CardCollectionWildCardTutorial,
		// Token: 0x0400EDF1 RID: 60913
		[Token(Token = "0x400EDF1")]
		SpaceMissionRocketMove,
		// Token: 0x0400EDF2 RID: 60914
		[Token(Token = "0x400EDF2")]
		SpaceMissionClaimAnimation,
		// Token: 0x0400EDF3 RID: 60915
		[Token(Token = "0x400EDF3")]
		SpaceMissionCollectAnimation,
		// Token: 0x0400EDF4 RID: 60916
		[Token(Token = "0x400EDF4")]
		BoardScroll,
		// Token: 0x0400EDF5 RID: 60917
		[Token(Token = "0x400EDF5")]
		BalloonRiseCollectAnimation,
		// Token: 0x0400EDF6 RID: 60918
		[Token(Token = "0x400EDF6")]
		SuperBoosterCollectAnimation,
		// Token: 0x0400EDF7 RID: 60919
		[Token(Token = "0x400EDF7")]
		SuperBoosterTutorial,
		// Token: 0x0400EDF8 RID: 60920
		[Token(Token = "0x400EDF8")]
		WeeklyLeaderboardNewEventListAnimation,
		// Token: 0x0400EDF9 RID: 60921
		[Token(Token = "0x400EDF9")]
		WeeklyLeaderboardTutorial,
		// Token: 0x0400EDFA RID: 60922
		[Token(Token = "0x400EDFA")]
		WorldCupPopupOpeningAnimation,
		// Token: 0x0400EDFB RID: 60923
		[Token(Token = "0x400EDFB")]
		WorldCupPopupRowAnimation,
		// Token: 0x0400EDFC RID: 60924
		[Token(Token = "0x400EDFC")]
		WorldCupCollectAnimation,
		// Token: 0x0400EDFD RID: 60925
		[Token(Token = "0x400EDFD")]
		EgoExtraMovesAnimation,
		// Token: 0x0400EDFE RID: 60926
		[Token(Token = "0x400EDFE")]
		TabletItemCollect,
		// Token: 0x0400EDFF RID: 60927
		[Token(Token = "0x400EDFF")]
		LavaQuestCompetitionScene,
		// Token: 0x0400EE00 RID: 60928
		[Token(Token = "0x400EE00")]
		LavaQuestCoinCollectAnimation,
		// Token: 0x0400EE01 RID: 60929
		[Token(Token = "0x400EE01")]
		GiantPiggyThrow,
		// Token: 0x0400EE02 RID: 60930
		[Token(Token = "0x400EE02")]
		HiddenTempleStageAnimation,
		// Token: 0x0400EE03 RID: 60931
		[Token(Token = "0x400EE03")]
		HiddenTempleCollectAnimation,
		// Token: 0x0400EE04 RID: 60932
		[Token(Token = "0x400EE04")]
		DragonNestCollectAnimation,
		// Token: 0x0400EE05 RID: 60933
		[Token(Token = "0x400EE05")]
		MagicCauldronCollectAnimation,
		// Token: 0x0400EE06 RID: 60934
		[Token(Token = "0x400EE06")]
		VendingMachineItemCanCollect,
		// Token: 0x0400EE07 RID: 60935
		[Token(Token = "0x400EE07")]
		VaseThrow,
		// Token: 0x0400EE08 RID: 60936
		[Token(Token = "0x400EE08")]
		DynamicEventOfferCollectAnimation,
		// Token: 0x0400EE09 RID: 60937
		[Token(Token = "0x400EE09")]
		SuggestedFriendRow,
		// Token: 0x0400EE0A RID: 60938
		[Token(Token = "0x400EE0A")]
		ToyBoxItemCollect,
		// Token: 0x0400EE0B RID: 60939
		[Token(Token = "0x400EE0B")]
		DragonNestDialog,
		// Token: 0x0400EE0C RID: 60940
		[Token(Token = "0x400EE0C")]
		DragonNestClaimAnimation,
		// Token: 0x0400EE0D RID: 60941
		[Token(Token = "0x400EE0D")]
		AncientVaultCollect,
		// Token: 0x0400EE0E RID: 60942
		[Token(Token = "0x400EE0E")]
		ArcheryArenaCollectAnimation,
		// Token: 0x0400EE0F RID: 60943
		[Token(Token = "0x400EE0F")]
		ArcheryArenaClaimAnimation,
		// Token: 0x0400EE10 RID: 60944
		[Token(Token = "0x400EE10")]
		ArcheryArenaIconTooltipAnimation,
		// Token: 0x0400EE11 RID: 60945
		[Token(Token = "0x400EE11")]
		DukesFortuneCollectAnimation,
		// Token: 0x0400EE12 RID: 60946
		[Token(Token = "0x400EE12")]
		DukesFortuneCoinCollectAnimation,
		// Token: 0x0400EE13 RID: 60947
		[Token(Token = "0x400EE13")]
		LogItemExplodeAnimation,
		// Token: 0x0400EE14 RID: 60948
		[Token(Token = "0x400EE14")]
		LogSpikeCollect,
		// Token: 0x0400EE15 RID: 60949
		[Token(Token = "0x400EE15")]
		SeasonalCardCollectionTutorial,
		// Token: 0x0400EE16 RID: 60950
		[Token(Token = "0x400EE16")]
		SeasonalCardCollectionRewardPanel,
		// Token: 0x0400EE17 RID: 60951
		[Token(Token = "0x400EE17")]
		SeasonalCardCollectionReceivedCardsPanel,
		// Token: 0x0400EE18 RID: 60952
		[Token(Token = "0x400EE18")]
		DuplicateCardChestRewardDialog,
		// Token: 0x0400EE19 RID: 60953
		[Token(Token = "0x400EE19")]
		TeamTournamentIconCollectAnimation,
		// Token: 0x0400EE1A RID: 60954
		[Token(Token = "0x400EE1A")]
		TeamTournamentClaimAnimation,
		// Token: 0x0400EE1B RID: 60955
		[Token(Token = "0x400EE1B")]
		CapsuleThrow,
		// Token: 0x0400EE1C RID: 60956
		[Token(Token = "0x400EE1C")]
		MonkeyCollect,
		// Token: 0x0400EE1D RID: 60957
		[Token(Token = "0x400EE1D")]
		ShuttleLaunch,
		// Token: 0x0400EE1E RID: 60958
		[Token(Token = "0x400EE1E")]
		TeamTournamentSceneImageAnimation,
		// Token: 0x0400EE1F RID: 60959
		[Token(Token = "0x400EE1F")]
		CryptexReveal,
		// Token: 0x0400EE20 RID: 60960
		[Token(Token = "0x400EE20")]
		MissionPursuitTutorial,
		// Token: 0x0400EE21 RID: 60961
		[Token(Token = "0x400EE21")]
		KingsCupIconTooltipAnimation,
		// Token: 0x0400EE22 RID: 60962
		[Token(Token = "0x400EE22")]
		MissionControlTutorial,
		// Token: 0x0400EE23 RID: 60963
		[Token(Token = "0x400EE23")]
		GrassBombExplode,
		// Token: 0x0400EE24 RID: 60964
		[Token(Token = "0x400EE24")]
		TrainJourneyIconCollectAnimation,
		// Token: 0x0400EE25 RID: 60965
		[Token(Token = "0x400EE25")]
		TrainJourneyClaimAnimation,
		// Token: 0x0400EE26 RID: 60966
		[Token(Token = "0x400EE26")]
		TrainJourneyTutorial,
		// Token: 0x0400EE27 RID: 60967
		[Token(Token = "0x400EE27")]
		TrainJourneyTileTutorial,
		// Token: 0x0400EE28 RID: 60968
		[Token(Token = "0x400EE28")]
		TrainJourneyAutoSpinTutorial,
		// Token: 0x0400EE29 RID: 60969
		[Token(Token = "0x400EE29")]
		SapphireCollect,
		// Token: 0x0400EE2A RID: 60970
		[Token(Token = "0x400EE2A")]
		OceanOdysseyCollectAnimation,
		// Token: 0x0400EE2B RID: 60971
		[Token(Token = "0x400EE2B")]
		OceanOdysseyStartAnimation,
		// Token: 0x0400EE2C RID: 60972
		[Token(Token = "0x400EE2C")]
		CoinShopTutorial,
		// Token: 0x0400EE2D RID: 60973
		[Token(Token = "0x400EE2D")]
		ChocoThrow,
		// Token: 0x0400EE2E RID: 60974
		[Token(Token = "0x400EE2E")]
		DailyLightningRushCollectAnimation,
		// Token: 0x0400EE2F RID: 60975
		[Token(Token = "0x400EE2F")]
		ChargerThrow,
		// Token: 0x0400EE30 RID: 60976
		[Token(Token = "0x400EE30")]
		RoyalBotCollect,
		// Token: 0x0400EE31 RID: 60977
		[Token(Token = "0x400EE31")]
		PuzzleBreakCollectAnimation,
		// Token: 0x0400EE32 RID: 60978
		[Token(Token = "0x400EE32")]
		PuzzleBreakStartAnimation,
		// Token: 0x0400EE33 RID: 60979
		[Token(Token = "0x400EE33")]
		PuzzleBreakBoardAnimation,
		// Token: 0x0400EE34 RID: 60980
		[Token(Token = "0x400EE34")]
		RoyalBotThrow,
		// Token: 0x0400EE35 RID: 60981
		[Token(Token = "0x400EE35")]
		NewRoyalPassTutorial,
		// Token: 0x0400EE36 RID: 60982
		[Token(Token = "0x400EE36")]
		PropellerMachineThrow,
		// Token: 0x0400EE37 RID: 60983
		[Token(Token = "0x400EE37")]
		PropellerRushCollectAnimation,
		// Token: 0x0400EE38 RID: 60984
		[Token(Token = "0x400EE38")]
		PrClaimPanelAnimate,
		// Token: 0x0400EE39 RID: 60985
		[Token(Token = "0x400EE39")]
		TeamEventIconTutorial,
		// Token: 0x0400EE3A RID: 60986
		[Token(Token = "0x400EE3A")]
		NewLeagueTutorial,
		// Token: 0x0400EE3B RID: 60987
		[Token(Token = "0x400EE3B")]
		NewLeagueTransition,
		// Token: 0x0400EE3C RID: 60988
		[Token(Token = "0x400EE3C")]
		AncientAdventureCoinCollectAnimation,
		// Token: 0x0400EE3D RID: 60989
		[Token(Token = "0x400EE3D")]
		AncientAdventureZoomAnimation,
		// Token: 0x0400EE3E RID: 60990
		[Token(Token = "0x400EE3E")]
		PrelevelPanelRewardClaimAnimation,
		// Token: 0x0400EE3F RID: 60991
		[Token(Token = "0x400EE3F")]
		AncientAdventureLevelEndActions
	}
}
