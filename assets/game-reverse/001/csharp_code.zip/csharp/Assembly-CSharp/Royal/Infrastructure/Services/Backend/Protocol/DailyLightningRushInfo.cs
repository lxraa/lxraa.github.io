﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002377 RID: 9079
	[Token(Token = "0x2002377")]
	public struct DailyLightningRushInfo : IFlatbufferObject
	{
		// Token: 0x17001FA6 RID: 8102
		// (get) Token: 0x06010EAA RID: 69290 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FA6")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010EAA")]
			[Address(RVA = "0x1F93E34", Offset = "0x1F93E34", VA = "0x1F93E34", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EAB RID: 69291 RVA: 0x00062700 File Offset: 0x00060900
		[Token(Token = "0x6010EAB")]
		[Address(RVA = "0x1F93E3C", Offset = "0x1F93E3C", VA = "0x1F93E3C")]
		public static DailyLightningRushInfo GetRootAsDailyLightningRushInfo(ByteBuffer _bb)
		{
			return default(DailyLightningRushInfo);
		}

		// Token: 0x06010EAC RID: 69292 RVA: 0x00062718 File Offset: 0x00060918
		[Token(Token = "0x6010EAC")]
		[Address(RVA = "0x1F93E48", Offset = "0x1F93E48", VA = "0x1F93E48")]
		public static DailyLightningRushInfo GetRootAsDailyLightningRushInfo(ByteBuffer _bb, DailyLightningRushInfo obj)
		{
			return default(DailyLightningRushInfo);
		}

		// Token: 0x06010EAD RID: 69293 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EAD")]
		[Address(RVA = "0x1F93EF8", Offset = "0x1F93EF8", VA = "0x1F93EF8", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010EAE RID: 69294 RVA: 0x00062730 File Offset: 0x00060930
		[Token(Token = "0x6010EAE")]
		[Address(RVA = "0x1F93EC0", Offset = "0x1F93EC0", VA = "0x1F93EC0")]
		public DailyLightningRushInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DailyLightningRushInfo);
		}

		// Token: 0x17001FA7 RID: 8103
		// (get) Token: 0x06010EAF RID: 69295 RVA: 0x00062748 File Offset: 0x00060948
		[Token(Token = "0x17001FA7")]
		public int EventId
		{
			[Token(Token = "0x6010EAF")]
			[Address(RVA = "0x1F93F08", Offset = "0x1F93F08", VA = "0x1F93F08")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FA8 RID: 8104
		// (get) Token: 0x06010EB0 RID: 69296 RVA: 0x00062760 File Offset: 0x00060960
		[Token(Token = "0x17001FA8")]
		public long RemainingTime
		{
			[Token(Token = "0x6010EB0")]
			[Address(RVA = "0x1F93F4C", Offset = "0x1F93F4C", VA = "0x1F93F4C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FA9 RID: 8105
		// (get) Token: 0x06010EB1 RID: 69297 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FA9")]
		public string Config
		{
			[Token(Token = "0x6010EB1")]
			[Address(RVA = "0x1F93F94", Offset = "0x1F93F94", VA = "0x1F93F94")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EB2 RID: 69298 RVA: 0x00062778 File Offset: 0x00060978
		[Token(Token = "0x6010EB2")]
		[Address(RVA = "0x1F93FD0", Offset = "0x1F93FD0", VA = "0x1F93FD0")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06010EB3 RID: 69299 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010EB3")]
		[Address(RVA = "0x1F94008", Offset = "0x1F94008", VA = "0x1F94008")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x17001FAA RID: 8106
		// (get) Token: 0x06010EB4 RID: 69300 RVA: 0x00062790 File Offset: 0x00060990
		[Token(Token = "0x17001FAA")]
		public int ConfigVersion
		{
			[Token(Token = "0x6010EB4")]
			[Address(RVA = "0x1F94054", Offset = "0x1F94054", VA = "0x1F94054")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010EB5 RID: 69301 RVA: 0x000627A8 File Offset: 0x000609A8
		[Token(Token = "0x6010EB5")]
		[Address(RVA = "0x1F94098", Offset = "0x1F94098", VA = "0x1F94098")]
		public static Offset<DailyLightningRushInfo> CreateDailyLightningRushInfo(FlatBufferBuilder builder, int event_id = 0, long remaining_time = 0L, [Optional] StringOffset configOffset, int config_version = 0)
		{
			return default(Offset<DailyLightningRushInfo>);
		}

		// Token: 0x06010EB6 RID: 69302 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EB6")]
		[Address(RVA = "0x1F94204", Offset = "0x1F94204", VA = "0x1F94204")]
		public static void StartDailyLightningRushInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010EB7 RID: 69303 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EB7")]
		[Address(RVA = "0x1F94178", Offset = "0x1F94178", VA = "0x1F94178")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x06010EB8 RID: 69304 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EB8")]
		[Address(RVA = "0x1F94118", Offset = "0x1F94118", VA = "0x1F94118")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010EB9 RID: 69305 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EB9")]
		[Address(RVA = "0x1F94158", Offset = "0x1F94158", VA = "0x1F94158")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06010EBA RID: 69306 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EBA")]
		[Address(RVA = "0x1F94138", Offset = "0x1F94138", VA = "0x1F94138")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06010EBB RID: 69307 RVA: 0x000627C0 File Offset: 0x000609C0
		[Token(Token = "0x6010EBB")]
		[Address(RVA = "0x1F94198", Offset = "0x1F94198", VA = "0x1F94198")]
		public static Offset<DailyLightningRushInfo> EndDailyLightningRushInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DailyLightningRushInfo>);
		}

		// Token: 0x0400E690 RID: 59024
		[Token(Token = "0x400E690")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
