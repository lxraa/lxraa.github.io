﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023DD RID: 9181
	[Token(Token = "0x20023DD")]
	public struct GetKingsCupInfoResponse : IFlatbufferObject
	{
		// Token: 0x17002109 RID: 8457
		// (get) Token: 0x0601142C RID: 70700 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002109")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601142C")]
			[Address(RVA = "0x1CB1C94", Offset = "0x1CB1C94", VA = "0x1CB1C94", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601142D RID: 70701 RVA: 0x000670F8 File Offset: 0x000652F8
		[Token(Token = "0x601142D")]
		[Address(RVA = "0x1CB1C9C", Offset = "0x1CB1C9C", VA = "0x1CB1C9C")]
		public static GetKingsCupInfoResponse GetRootAsGetKingsCupInfoResponse(ByteBuffer _bb)
		{
			return default(GetKingsCupInfoResponse);
		}

		// Token: 0x0601142E RID: 70702 RVA: 0x00067110 File Offset: 0x00065310
		[Token(Token = "0x601142E")]
		[Address(RVA = "0x1CB1CA8", Offset = "0x1CB1CA8", VA = "0x1CB1CA8")]
		public static GetKingsCupInfoResponse GetRootAsGetKingsCupInfoResponse(ByteBuffer _bb, GetKingsCupInfoResponse obj)
		{
			return default(GetKingsCupInfoResponse);
		}

		// Token: 0x0601142F RID: 70703 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601142F")]
		[Address(RVA = "0x1CB1D58", Offset = "0x1CB1D58", VA = "0x1CB1D58", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011430 RID: 70704 RVA: 0x00067128 File Offset: 0x00065328
		[Token(Token = "0x6011430")]
		[Address(RVA = "0x1CB1D20", Offset = "0x1CB1D20", VA = "0x1CB1D20")]
		public GetKingsCupInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetKingsCupInfoResponse);
		}

		// Token: 0x1700210A RID: 8458
		// (get) Token: 0x06011431 RID: 70705 RVA: 0x00067140 File Offset: 0x00065340
		[Token(Token = "0x1700210A")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6011431")]
			[Address(RVA = "0x1CB1D68", Offset = "0x1CB1D68", VA = "0x1CB1D68")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x1700210B RID: 8459
		// (get) Token: 0x06011432 RID: 70706 RVA: 0x00067158 File Offset: 0x00065358
		[Token(Token = "0x1700210B")]
		public KingsCupInfo? KingsCupInfo
		{
			[Token(Token = "0x6011432")]
			[Address(RVA = "0x1CB1DAC", Offset = "0x1CB1DAC", VA = "0x1CB1DAC")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011433 RID: 70707 RVA: 0x00067170 File Offset: 0x00065370
		[Token(Token = "0x6011433")]
		[Address(RVA = "0x1CB1E6C", Offset = "0x1CB1E6C", VA = "0x1CB1E6C")]
		public static Offset<GetKingsCupInfoResponse> CreateGetKingsCupInfoResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, [Optional] Offset<KingsCupInfo> kings_cup_infoOffset)
		{
			return default(Offset<GetKingsCupInfoResponse>);
		}

		// Token: 0x06011434 RID: 70708 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011434")]
		[Address(RVA = "0x1CB1F70", Offset = "0x1CB1F70", VA = "0x1CB1F70")]
		public static void StartGetKingsCupInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011435 RID: 70709 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011435")]
		[Address(RVA = "0x1CB1EE4", Offset = "0x1CB1EE4", VA = "0x1CB1EE4")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06011436 RID: 70710 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011436")]
		[Address(RVA = "0x1CB1EC4", Offset = "0x1CB1EC4", VA = "0x1CB1EC4")]
		public static void AddKingsCupInfo(FlatBufferBuilder builder, Offset<KingsCupInfo> kingsCupInfoOffset)
		{
		}

		// Token: 0x06011437 RID: 70711 RVA: 0x00067188 File Offset: 0x00065388
		[Token(Token = "0x6011437")]
		[Address(RVA = "0x1CB1F04", Offset = "0x1CB1F04", VA = "0x1CB1F04")]
		public static Offset<GetKingsCupInfoResponse> EndGetKingsCupInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetKingsCupInfoResponse>);
		}

		// Token: 0x0400E74D RID: 59213
		[Token(Token = "0x400E74D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
