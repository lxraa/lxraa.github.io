﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023BA RID: 9146
	[Token(Token = "0x20023BA")]
	public struct FriendScore : IFlatbufferObject
	{
		// Token: 0x170020A5 RID: 8357
		// (get) Token: 0x0601126F RID: 70255 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020A5")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601126F")]
			[Address(RVA = "0x1CAAA20", Offset = "0x1CAAA20", VA = "0x1CAAA20", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011270 RID: 70256 RVA: 0x000658C8 File Offset: 0x00063AC8
		[Token(Token = "0x6011270")]
		[Address(RVA = "0x1CAAA28", Offset = "0x1CAAA28", VA = "0x1CAAA28")]
		public static FriendScore GetRootAsFriendScore(ByteBuffer _bb)
		{
			return default(FriendScore);
		}

		// Token: 0x06011271 RID: 70257 RVA: 0x000658E0 File Offset: 0x00063AE0
		[Token(Token = "0x6011271")]
		[Address(RVA = "0x1CAAA34", Offset = "0x1CAAA34", VA = "0x1CAAA34")]
		public static FriendScore GetRootAsFriendScore(ByteBuffer _bb, FriendScore obj)
		{
			return default(FriendScore);
		}

		// Token: 0x06011272 RID: 70258 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011272")]
		[Address(RVA = "0x1CAAAE4", Offset = "0x1CAAAE4", VA = "0x1CAAAE4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011273 RID: 70259 RVA: 0x000658F8 File Offset: 0x00063AF8
		[Token(Token = "0x6011273")]
		[Address(RVA = "0x1CAAAAC", Offset = "0x1CAAAAC", VA = "0x1CAAAAC")]
		public FriendScore __assign(int _i, ByteBuffer _bb)
		{
			return default(FriendScore);
		}

		// Token: 0x170020A6 RID: 8358
		// (get) Token: 0x06011274 RID: 70260 RVA: 0x00065910 File Offset: 0x00063B10
		[Token(Token = "0x170020A6")]
		public long FacebookId
		{
			[Token(Token = "0x6011274")]
			[Address(RVA = "0x1CAAAF4", Offset = "0x1CAAAF4", VA = "0x1CAAAF4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x170020A7 RID: 8359
		// (get) Token: 0x06011275 RID: 70261 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020A7")]
		public string Name
		{
			[Token(Token = "0x6011275")]
			[Address(RVA = "0x1CAAB3C", Offset = "0x1CAAB3C", VA = "0x1CAAB3C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011276 RID: 70262 RVA: 0x00065928 File Offset: 0x00063B28
		[Token(Token = "0x6011276")]
		[Address(RVA = "0x1CAAB78", Offset = "0x1CAAB78", VA = "0x1CAAB78")]
		public ArraySegment<byte>? GetNameBytes()
		{
			return null;
		}

		// Token: 0x06011277 RID: 70263 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011277")]
		[Address(RVA = "0x1CAABB0", Offset = "0x1CAABB0", VA = "0x1CAABB0")]
		public byte[] GetNameArray()
		{
			return null;
		}

		// Token: 0x170020A8 RID: 8360
		// (get) Token: 0x06011278 RID: 70264 RVA: 0x00065940 File Offset: 0x00063B40
		[Token(Token = "0x170020A8")]
		public int Level
		{
			[Token(Token = "0x6011278")]
			[Address(RVA = "0x1CAABFC", Offset = "0x1CAABFC", VA = "0x1CAABFC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020A9 RID: 8361
		// (get) Token: 0x06011279 RID: 70265 RVA: 0x00065958 File Offset: 0x00063B58
		[Token(Token = "0x170020A9")]
		public long LastLevelUpdateDate
		{
			[Token(Token = "0x6011279")]
			[Address(RVA = "0x1CAAC40", Offset = "0x1CAAC40", VA = "0x1CAAC40")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x170020AA RID: 8362
		// (get) Token: 0x0601127A RID: 70266 RVA: 0x00065970 File Offset: 0x00063B70
		[Token(Token = "0x170020AA")]
		public int Crown
		{
			[Token(Token = "0x601127A")]
			[Address(RVA = "0x1CAAC88", Offset = "0x1CAAC88", VA = "0x1CAAC88")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020AB RID: 8363
		// (get) Token: 0x0601127B RID: 70267 RVA: 0x00065988 File Offset: 0x00063B88
		[Token(Token = "0x170020AB")]
		public long TeamId
		{
			[Token(Token = "0x601127B")]
			[Address(RVA = "0x1CAACCC", Offset = "0x1CAACCC", VA = "0x1CAACCC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x170020AC RID: 8364
		// (get) Token: 0x0601127C RID: 70268 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020AC")]
		public string TeamName
		{
			[Token(Token = "0x601127C")]
			[Address(RVA = "0x1CAAD14", Offset = "0x1CAAD14", VA = "0x1CAAD14")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601127D RID: 70269 RVA: 0x000659A0 File Offset: 0x00063BA0
		[Token(Token = "0x601127D")]
		[Address(RVA = "0x1CAAD50", Offset = "0x1CAAD50", VA = "0x1CAAD50")]
		public ArraySegment<byte>? GetTeamNameBytes()
		{
			return null;
		}

		// Token: 0x0601127E RID: 70270 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601127E")]
		[Address(RVA = "0x1CAAD88", Offset = "0x1CAAD88", VA = "0x1CAAD88")]
		public byte[] GetTeamNameArray()
		{
			return null;
		}

		// Token: 0x170020AD RID: 8365
		// (get) Token: 0x0601127F RID: 70271 RVA: 0x000659B8 File Offset: 0x00063BB8
		[Token(Token = "0x170020AD")]
		public int TeamLogo
		{
			[Token(Token = "0x601127F")]
			[Address(RVA = "0x1CAADD4", Offset = "0x1CAADD4", VA = "0x1CAADD4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020AE RID: 8366
		// (get) Token: 0x06011280 RID: 70272 RVA: 0x000659D0 File Offset: 0x00063BD0
		[Token(Token = "0x170020AE")]
		public long UserId
		{
			[Token(Token = "0x6011280")]
			[Address(RVA = "0x1CAAE18", Offset = "0x1CAAE18", VA = "0x1CAAE18")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x170020AF RID: 8367
		// (get) Token: 0x06011281 RID: 70273 RVA: 0x000659E8 File Offset: 0x00063BE8
		[Token(Token = "0x170020AF")]
		public bool DeprecatedIsGold
		{
			[Token(Token = "0x6011281")]
			[Address(RVA = "0x1CAAE60", Offset = "0x1CAAE60", VA = "0x1CAAE60")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170020B0 RID: 8368
		// (get) Token: 0x06011282 RID: 70274 RVA: 0x00065A00 File Offset: 0x00063C00
		[Token(Token = "0x170020B0")]
		public WorldCupBadge? WorldCupBadge
		{
			[Token(Token = "0x6011282")]
			[Address(RVA = "0x1CAAEA8", Offset = "0x1CAAEA8", VA = "0x1CAAEA8")]
			get
			{
				return null;
			}
		}

		// Token: 0x170020B1 RID: 8369
		// (get) Token: 0x06011283 RID: 70275 RVA: 0x00065A18 File Offset: 0x00063C18
		[Token(Token = "0x170020B1")]
		public bool HasSpecialNameStyle
		{
			[Token(Token = "0x6011283")]
			[Address(RVA = "0x1CAAF68", Offset = "0x1CAAF68", VA = "0x1CAAF68")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170020B2 RID: 8370
		// (get) Token: 0x06011284 RID: 70276 RVA: 0x00065A30 File Offset: 0x00063C30
		[Token(Token = "0x170020B2")]
		public bool HasSpecialFrameStyle
		{
			[Token(Token = "0x6011284")]
			[Address(RVA = "0x1CAAFB0", Offset = "0x1CAAFB0", VA = "0x1CAAFB0")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170020B3 RID: 8371
		// (get) Token: 0x06011285 RID: 70277 RVA: 0x00065A48 File Offset: 0x00063C48
		[Token(Token = "0x170020B3")]
		public ProfileSetting? ProfileSetting
		{
			[Token(Token = "0x6011285")]
			[Address(RVA = "0x1CAAFF8", Offset = "0x1CAAFF8", VA = "0x1CAAFF8")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011286 RID: 70278 RVA: 0x00065A60 File Offset: 0x00063C60
		[Token(Token = "0x6011286")]
		[Address(RVA = "0x1CAB0B8", Offset = "0x1CAB0B8", VA = "0x1CAB0B8")]
		public static Offset<FriendScore> CreateFriendScore(FlatBufferBuilder builder, long facebook_id = 0L, [Optional] StringOffset nameOffset, int level = 0, long last_level_update_date = 0L, int crown = 0, long team_id = 0L, [Optional] StringOffset team_nameOffset, int team_logo = 0, long user_id = 0L, bool deprecated_is_gold = false, [Optional] Offset<WorldCupBadge> world_cup_badgeOffset, bool has_special_name_style = false, bool has_special_frame_style = false, [Optional] Offset<ProfileSetting> profile_settingOffset)
		{
			return default(Offset<FriendScore>);
		}

		// Token: 0x06011287 RID: 70279 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011287")]
		[Address(RVA = "0x1CAB440", Offset = "0x1CAB440", VA = "0x1CAB440")]
		public static void StartFriendScore(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011288 RID: 70280 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011288")]
		[Address(RVA = "0x1CAB274", Offset = "0x1CAB274", VA = "0x1CAB274")]
		public static void AddFacebookId(FlatBufferBuilder builder, long facebookId)
		{
		}

		// Token: 0x06011289 RID: 70281 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011289")]
		[Address(RVA = "0x1CAB354", Offset = "0x1CAB354", VA = "0x1CAB354")]
		public static void AddName(FlatBufferBuilder builder, StringOffset nameOffset)
		{
		}

		// Token: 0x0601128A RID: 70282 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601128A")]
		[Address(RVA = "0x1CAB334", Offset = "0x1CAB334", VA = "0x1CAB334")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x0601128B RID: 70283 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601128B")]
		[Address(RVA = "0x1CAB254", Offset = "0x1CAB254", VA = "0x1CAB254")]
		public static void AddLastLevelUpdateDate(FlatBufferBuilder builder, long lastLevelUpdateDate)
		{
		}

		// Token: 0x0601128C RID: 70284 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601128C")]
		[Address(RVA = "0x1CAB314", Offset = "0x1CAB314", VA = "0x1CAB314")]
		public static void AddCrown(FlatBufferBuilder builder, int crown)
		{
		}

		// Token: 0x0601128D RID: 70285 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601128D")]
		[Address(RVA = "0x1CAB234", Offset = "0x1CAB234", VA = "0x1CAB234")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x0601128E RID: 70286 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601128E")]
		[Address(RVA = "0x1CAB2F4", Offset = "0x1CAB2F4", VA = "0x1CAB2F4")]
		public static void AddTeamName(FlatBufferBuilder builder, StringOffset teamNameOffset)
		{
		}

		// Token: 0x0601128F RID: 70287 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601128F")]
		[Address(RVA = "0x1CAB2D4", Offset = "0x1CAB2D4", VA = "0x1CAB2D4")]
		public static void AddTeamLogo(FlatBufferBuilder builder, int teamLogo)
		{
		}

		// Token: 0x06011290 RID: 70288 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011290")]
		[Address(RVA = "0x1CAB214", Offset = "0x1CAB214", VA = "0x1CAB214")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06011291 RID: 70289 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011291")]
		[Address(RVA = "0x1CAB3B4", Offset = "0x1CAB3B4", VA = "0x1CAB3B4")]
		public static void AddDeprecatedIsGold(FlatBufferBuilder builder, bool deprecatedIsGold)
		{
		}

		// Token: 0x06011292 RID: 70290 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011292")]
		[Address(RVA = "0x1CAB2B4", Offset = "0x1CAB2B4", VA = "0x1CAB2B4")]
		public static void AddWorldCupBadge(FlatBufferBuilder builder, Offset<WorldCupBadge> worldCupBadgeOffset)
		{
		}

		// Token: 0x06011293 RID: 70291 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011293")]
		[Address(RVA = "0x1CAB394", Offset = "0x1CAB394", VA = "0x1CAB394")]
		public static void AddHasSpecialNameStyle(FlatBufferBuilder builder, bool hasSpecialNameStyle)
		{
		}

		// Token: 0x06011294 RID: 70292 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011294")]
		[Address(RVA = "0x1CAB374", Offset = "0x1CAB374", VA = "0x1CAB374")]
		public static void AddHasSpecialFrameStyle(FlatBufferBuilder builder, bool hasSpecialFrameStyle)
		{
		}

		// Token: 0x06011295 RID: 70293 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011295")]
		[Address(RVA = "0x1CAB294", Offset = "0x1CAB294", VA = "0x1CAB294")]
		public static void AddProfileSetting(FlatBufferBuilder builder, Offset<ProfileSetting> profileSettingOffset)
		{
		}

		// Token: 0x06011296 RID: 70294 RVA: 0x00065A78 File Offset: 0x00063C78
		[Token(Token = "0x6011296")]
		[Address(RVA = "0x1CAB3D4", Offset = "0x1CAB3D4", VA = "0x1CAB3D4")]
		public static Offset<FriendScore> EndFriendScore(FlatBufferBuilder builder)
		{
			return default(Offset<FriendScore>);
		}

		// Token: 0x0400E6F1 RID: 59121
		[Token(Token = "0x400E6F1")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
