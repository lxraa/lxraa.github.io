﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Firebase.Analytics;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025B5 RID: 9653
	[Token(Token = "0x20025B5")]
	public class ApplicationPrivacyManager
	{
		// Token: 0x170027E3 RID: 10211
		// (get) Token: 0x06012E0F RID: 77327 RVA: 0x00079F80 File Offset: 0x00078180
		// (set) Token: 0x06012E10 RID: 77328 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027E3")]
		public static bool AnalyticsBlockDisabled
		{
			[Token(Token = "0x6012E0F")]
			[Address(RVA = "0x24452E8", Offset = "0x24452E8", VA = "0x24452E8")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E10")]
			[Address(RVA = "0x244533C", Offset = "0x244533C", VA = "0x244533C")]
			set
			{
			}
		}

		// Token: 0x170027E4 RID: 10212
		// (get) Token: 0x06012E11 RID: 77329 RVA: 0x00079F98 File Offset: 0x00078198
		[Token(Token = "0x170027E4")]
		private static ConsentStatus GoogleAdPersonalizationServicesStatus
		{
			[Token(Token = "0x6012E11")]
			[Address(RVA = "0x2445388", Offset = "0x2445388", VA = "0x2445388")]
			get
			{
				return ConsentStatus.Granted;
			}
		}

		// Token: 0x170027E5 RID: 10213
		// (get) Token: 0x06012E12 RID: 77330 RVA: 0x00079FB0 File Offset: 0x000781B0
		[Token(Token = "0x170027E5")]
		private static ConsentStatus GoogleMarketingServicesStatus
		{
			[Token(Token = "0x6012E12")]
			[Address(RVA = "0x24453E8", Offset = "0x24453E8", VA = "0x24453E8")]
			get
			{
				return ConsentStatus.Granted;
			}
		}

		// Token: 0x170027E6 RID: 10214
		// (get) Token: 0x06012E13 RID: 77331 RVA: 0x00079FC8 File Offset: 0x000781C8
		[Token(Token = "0x170027E6")]
		public static ConsentStatus AppsFlyerServicesStatus
		{
			[Token(Token = "0x6012E13")]
			[Address(RVA = "0x243B430", Offset = "0x243B430", VA = "0x243B430")]
			get
			{
				return ConsentStatus.Granted;
			}
		}

		// Token: 0x170027E7 RID: 10215
		// (get) Token: 0x06012E14 RID: 77332 RVA: 0x00079FE0 File Offset: 0x000781E0
		[Token(Token = "0x170027E7")]
		public static ConsentStatus UnityServicesStatus
		{
			[Token(Token = "0x6012E14")]
			[Address(RVA = "0x2445444", Offset = "0x2445444", VA = "0x2445444")]
			get
			{
				return ConsentStatus.Granted;
			}
		}

		// Token: 0x06012E15 RID: 77333 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012E15")]
		[Address(RVA = "0x24454A0", Offset = "0x24454A0", VA = "0x24454A0")]
		public static IDictionary<ConsentType, ConsentStatus> GetFirebaseData()
		{
			return null;
		}

		// Token: 0x06012E16 RID: 77334 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E16")]
		[Address(RVA = "0x24455A8", Offset = "0x24455A8", VA = "0x24455A8")]
		public static void SetServiceConsentStatus(ApplicationPrivacyManager.PrivacySettingsServiceType serviceType, ApplicationPrivacyManager.PrivacyConsentState privacyConsentState)
		{
		}

		// Token: 0x06012E17 RID: 77335 RVA: 0x00079FF8 File Offset: 0x000781F8
		[Token(Token = "0x6012E17")]
		[Address(RVA = "0x2439F5C", Offset = "0x2439F5C", VA = "0x2439F5C")]
		public static ApplicationPrivacyManager.PrivacyConsentState GetServiceConsentStatus(ApplicationPrivacyManager.PrivacySettingsServiceType serviceType)
		{
			return ApplicationPrivacyManager.PrivacyConsentState.Denied;
		}

		// Token: 0x06012E18 RID: 77336 RVA: 0x0007A010 File Offset: 0x00078210
		[Token(Token = "0x6012E18")]
		[Address(RVA = "0x2445800", Offset = "0x2445800", VA = "0x2445800")]
		private static ApplicationPrivacyManager.PrivacyConsentState GetAppsFlyerPlayerPrefsConsentStatus()
		{
			return ApplicationPrivacyManager.PrivacyConsentState.Denied;
		}

		// Token: 0x06012E19 RID: 77337 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E19")]
		[Address(RVA = "0x2445848", Offset = "0x2445848", VA = "0x2445848")]
		public static void CopyAppsFlyerConsentToPlayerPrefs()
		{
		}

		// Token: 0x06012E1A RID: 77338 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E1A")]
		[Address(RVA = "0x24459F0", Offset = "0x24459F0", VA = "0x24459F0")]
		public static void SetAllConsentStatus(ApplicationPrivacyManager.PrivacyConsentState privacyConsentState)
		{
		}

		// Token: 0x06012E1B RID: 77339 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E1B")]
		[Address(RVA = "0x2445AB0", Offset = "0x2445AB0", VA = "0x2445AB0")]
		public static void SaveEssentialConsentValues()
		{
		}

		// Token: 0x06012E1C RID: 77340 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E1C")]
		[Address(RVA = "0x2445B34", Offset = "0x2445B34", VA = "0x2445B34")]
		public static void SaveUnderageConsentValues()
		{
		}

		// Token: 0x06012E1D RID: 77341 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012E1D")]
		[Address(RVA = "0x2445BC4", Offset = "0x2445BC4", VA = "0x2445BC4")]
		public static string GetConsentDetails()
		{
			return null;
		}

		// Token: 0x06012E1E RID: 77342 RVA: 0x0007A028 File Offset: 0x00078228
		[Token(Token = "0x6012E1E")]
		[Address(RVA = "0x243A144", Offset = "0x243A144", VA = "0x243A144")]
		public static bool CanEnableFirebaseAnalytics()
		{
			return default(bool);
		}

		// Token: 0x06012E1F RID: 77343 RVA: 0x0007A040 File Offset: 0x00078240
		[Token(Token = "0x6012E1F")]
		[Address(RVA = "0x243ABAC", Offset = "0x243ABAC", VA = "0x243ABAC")]
		public static bool ShouldInitializeAppsFlyer()
		{
			return default(bool);
		}

		// Token: 0x170027E8 RID: 10216
		// (get) Token: 0x06012E20 RID: 77344 RVA: 0x0007A058 File Offset: 0x00078258
		[Token(Token = "0x170027E8")]
		public static int CurrentAcceptedTermsAndConditionsVersion
		{
			[Token(Token = "0x6012E20")]
			[Address(RVA = "0x244646C", Offset = "0x244646C", VA = "0x244646C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170027E9 RID: 10217
		// (get) Token: 0x06012E21 RID: 77345 RVA: 0x0007A070 File Offset: 0x00078270
		[Token(Token = "0x170027E9")]
		public static bool PrivacySettingsCompleted
		{
			[Token(Token = "0x6012E21")]
			[Address(RVA = "0x243B298", Offset = "0x243B298", VA = "0x243B298")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170027EA RID: 10218
		// (get) Token: 0x06012E22 RID: 77346 RVA: 0x0007A088 File Offset: 0x00078288
		[Token(Token = "0x170027EA")]
		private static bool CanShowAgePopup
		{
			[Token(Token = "0x6012E22")]
			[Address(RVA = "0x24464B4", Offset = "0x24464B4", VA = "0x24464B4")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170027EB RID: 10219
		// (get) Token: 0x06012E23 RID: 77347 RVA: 0x0007A0A0 File Offset: 0x000782A0
		// (set) Token: 0x06012E24 RID: 77348 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027EB")]
		public static bool UserTermsAndConditionAcceptedOnce
		{
			[Token(Token = "0x6012E23")]
			[Address(RVA = "0x24465F8", Offset = "0x24465F8", VA = "0x24465F8")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E24")]
			[Address(RVA = "0x2446640", Offset = "0x2446640", VA = "0x2446640")]
			set
			{
			}
		}

		// Token: 0x170027EC RID: 10220
		// (get) Token: 0x06012E25 RID: 77349 RVA: 0x0007A0B8 File Offset: 0x000782B8
		[Token(Token = "0x170027EC")]
		private static bool UserTermsAndConditionAcceptedLatestVersion
		{
			[Token(Token = "0x6012E25")]
			[Address(RVA = "0x244668C", Offset = "0x244668C", VA = "0x244668C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170027ED RID: 10221
		// (get) Token: 0x06012E26 RID: 77350 RVA: 0x0007A0D0 File Offset: 0x000782D0
		// (set) Token: 0x06012E27 RID: 77351 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027ED")]
		private static bool PingReceivedAtLeastOnce
		{
			[Token(Token = "0x6012E26")]
			[Address(RVA = "0x2446730", Offset = "0x2446730", VA = "0x2446730")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E27")]
			[Address(RVA = "0x2446778", Offset = "0x2446778", VA = "0x2446778")]
			set
			{
			}
		}

		// Token: 0x170027EE RID: 10222
		// (get) Token: 0x06012E28 RID: 77352 RVA: 0x0007A0E8 File Offset: 0x000782E8
		// (set) Token: 0x06012E29 RID: 77353 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027EE")]
		private static bool FlowStartedWithNewInstall
		{
			[Token(Token = "0x6012E28")]
			[Address(RVA = "0x24467C4", Offset = "0x24467C4", VA = "0x24467C4")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E29")]
			[Address(RVA = "0x244680C", Offset = "0x244680C", VA = "0x244680C")]
			set
			{
			}
		}

		// Token: 0x170027EF RID: 10223
		// (get) Token: 0x06012E2A RID: 77354 RVA: 0x0007A100 File Offset: 0x00078300
		// (set) Token: 0x06012E2B RID: 77355 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027EF")]
		public static bool FlowStartedWithUpdate
		{
			[Token(Token = "0x6012E2A")]
			[Address(RVA = "0x2446858", Offset = "0x2446858", VA = "0x2446858")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E2B")]
			[Address(RVA = "0x24468A0", Offset = "0x24468A0", VA = "0x24468A0")]
			set
			{
			}
		}

		// Token: 0x170027F0 RID: 10224
		// (get) Token: 0x06012E2C RID: 77356 RVA: 0x0007A118 File Offset: 0x00078318
		// (set) Token: 0x06012E2D RID: 77357 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027F0")]
		private static bool PingReceivedBeginningOfSession
		{
			[Token(Token = "0x6012E2C")]
			[Address(RVA = "0x24468EC", Offset = "0x24468EC", VA = "0x24468EC")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E2D")]
			[Address(RVA = "0x2446944", Offset = "0x2446944", VA = "0x2446944")]
			set
			{
			}
		}

		// Token: 0x170027F1 RID: 10225
		// (get) Token: 0x06012E2E RID: 77358 RVA: 0x0007A130 File Offset: 0x00078330
		// (set) Token: 0x06012E2F RID: 77359 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027F1")]
		public static bool FlowIsActive
		{
			[Token(Token = "0x6012E2E")]
			[Address(RVA = "0x24469A0", Offset = "0x24469A0", VA = "0x24469A0")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E2F")]
			[Address(RVA = "0x24469F8", Offset = "0x24469F8", VA = "0x24469F8")]
			private set
			{
			}
		}

		// Token: 0x170027F2 RID: 10226
		// (get) Token: 0x06012E30 RID: 77360 RVA: 0x0007A148 File Offset: 0x00078348
		[Token(Token = "0x170027F2")]
		private static bool HasSetConsentState
		{
			[Token(Token = "0x6012E30")]
			[Address(RVA = "0x2446A54", Offset = "0x2446A54", VA = "0x2446A54")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06012E31 RID: 77361 RVA: 0x0007A160 File Offset: 0x00078360
		[Token(Token = "0x6012E31")]
		[Address(RVA = "0x2446AA8", Offset = "0x2446AA8", VA = "0x2446AA8")]
		private static bool IsFirstInstall()
		{
			return default(bool);
		}

		// Token: 0x06012E32 RID: 77362 RVA: 0x0007A178 File Offset: 0x00078378
		[Token(Token = "0x6012E32")]
		[Address(RVA = "0x2446B1C", Offset = "0x2446B1C", VA = "0x2446B1C")]
		private static bool IsVersionUpdate()
		{
			return default(bool);
		}

		// Token: 0x06012E33 RID: 77363 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E33")]
		[Address(RVA = "0x2446B68", Offset = "0x2446B68", VA = "0x2446B68")]
		public static void StartPrivacyFlow()
		{
		}

		// Token: 0x06012E34 RID: 77364 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E34")]
		[Address(RVA = "0x2446F54", Offset = "0x2446F54", VA = "0x2446F54")]
		private static void FinishPrivacyFlow(bool isNewInstall)
		{
		}

		// Token: 0x06012E35 RID: 77365 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E35")]
		[Address(RVA = "0x2446C34", Offset = "0x2446C34", VA = "0x2446C34")]
		public static void OnAppRequestTrackingAuthorizationComplete()
		{
		}

		// Token: 0x06012E36 RID: 77366 RVA: 0x0007A190 File Offset: 0x00078390
		[Token(Token = "0x6012E36")]
		[Address(RVA = "0x2447074", Offset = "0x2447074", VA = "0x2447074")]
		public static bool CheckAgeFlowForAbGroupTransitions()
		{
			return default(bool);
		}

		// Token: 0x06012E37 RID: 77367 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E37")]
		[Address(RVA = "0x24470E8", Offset = "0x24470E8", VA = "0x24470E8")]
		private static void StartTermsAndConditionsOrAgeFlow()
		{
		}

		// Token: 0x06012E38 RID: 77368 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E38")]
		[Address(RVA = "0x2447230", Offset = "0x2447230", VA = "0x2447230")]
		private static void StartRequestAgeFlow()
		{
		}

		// Token: 0x06012E39 RID: 77369 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E39")]
		[Address(RVA = "0x24473F4", Offset = "0x24473F4", VA = "0x24473F4")]
		private static void ShowAgeDialog()
		{
		}

		// Token: 0x06012E3A RID: 77370 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E3A")]
		[Address(RVA = "0x2447864", Offset = "0x2447864", VA = "0x2447864")]
		public static void OnAgeFlowComplete(ApplicationPrivacyManager.AgeGroup ageGroup, bool withTermsAndConditions)
		{
		}

		// Token: 0x06012E3B RID: 77371 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E3B")]
		[Address(RVA = "0x24472B4", Offset = "0x24472B4", VA = "0x24472B4")]
		private static void StartTermsAndConditionsFlow()
		{
		}

		// Token: 0x06012E3C RID: 77372 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012E3C")]
		[Address(RVA = "0x24471D0", Offset = "0x24471D0", VA = "0x24471D0")]
		private static IEnumerator CheckForFirstPing()
		{
			return null;
		}

		// Token: 0x06012E3D RID: 77373 RVA: 0x0007A1A8 File Offset: 0x000783A8
		[Token(Token = "0x6012E3D")]
		[Address(RVA = "0x24465F0", Offset = "0x24465F0", VA = "0x24465F0")]
		private static ApplicationPrivacyManager.AgeGroup GetAgeGroup()
		{
			return ApplicationPrivacyManager.AgeGroup.NotSet;
		}

		// Token: 0x06012E3E RID: 77374 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E3E")]
		[Address(RVA = "0x2447AB0", Offset = "0x2447AB0", VA = "0x2447AB0")]
		private static void SetAgeGroup(ApplicationPrivacyManager.AgeGroup ageGroup)
		{
		}

		// Token: 0x06012E3F RID: 77375 RVA: 0x0007A1C0 File Offset: 0x000783C0
		[Token(Token = "0x6012E3F")]
		[Address(RVA = "0x244573C", Offset = "0x244573C", VA = "0x244573C")]
		public static bool IsUserUnderage()
		{
			return default(bool);
		}

		// Token: 0x06012E40 RID: 77376 RVA: 0x0007A1D8 File Offset: 0x000783D8
		[Token(Token = "0x6012E40")]
		[Address(RVA = "0x243B2E0", Offset = "0x243B2E0", VA = "0x243B2E0")]
		public static bool IsUserInEurope()
		{
			return default(bool);
		}

		// Token: 0x06012E41 RID: 77377 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E41")]
		[Address(RVA = "0x2448274", Offset = "0x2448274", VA = "0x2448274")]
		public static void MigrateOldDmaConsentValues()
		{
		}

		// Token: 0x06012E42 RID: 77378 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E42")]
		[Address(RVA = "0x24483C4", Offset = "0x24483C4", VA = "0x24483C4")]
		public static void PingResponseReceived()
		{
		}

		// Token: 0x06012E43 RID: 77379 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E43")]
		[Address(RVA = "0x2448414", Offset = "0x2448414", VA = "0x2448414")]
		public static void SetPrivacyAndTermsVersion()
		{
		}

		// Token: 0x06012E44 RID: 77380 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E44")]
		[Address(RVA = "0x244769C", Offset = "0x244769C", VA = "0x244769C")]
		public static void OnConsentFinished(bool newInstall)
		{
		}

		// Token: 0x06012E45 RID: 77381 RVA: 0x0007A1F0 File Offset: 0x000783F0
		[Token(Token = "0x6012E45")]
		[Address(RVA = "0x244845C", Offset = "0x244845C", VA = "0x244845C")]
		private static bool TryShowPrivacyDialog(bool newInstall)
		{
			return default(bool);
		}

		// Token: 0x06012E46 RID: 77382 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E46")]
		[Address(RVA = "0x24484D8", Offset = "0x24484D8", VA = "0x24484D8")]
		private static void ShowPrivacyDialog(bool newInstall)
		{
		}

		// Token: 0x06012E47 RID: 77383 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E47")]
		[Address(RVA = "0x24485C0", Offset = "0x24485C0", VA = "0x24485C0")]
		public static void PrivacyFlowComplete(bool newInstall)
		{
		}

		// Token: 0x06012E48 RID: 77384 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E48")]
		[Address(RVA = "0x2448840", Offset = "0x2448840", VA = "0x2448840")]
		public static void OnTermsAndConditionsVersionReceived(TermsAndConditions terms)
		{
		}

		// Token: 0x06012E49 RID: 77385 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E49")]
		[Address(RVA = "0x2448C60", Offset = "0x2448C60", VA = "0x2448C60")]
		public static void ClearConsentUpdateFields()
		{
		}

		// Token: 0x06012E4A RID: 77386 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E4A")]
		[Address(RVA = "0x2448D88", Offset = "0x2448D88", VA = "0x2448D88")]
		public static void TryMigrateOldAgeGroupBits()
		{
		}

		// Token: 0x06012E4B RID: 77387 RVA: 0x0007A208 File Offset: 0x00078408
		[Token(Token = "0x6012E4B")]
		[Address(RVA = "0x244657C", Offset = "0x244657C", VA = "0x244657C")]
		private static bool IsAgePopupEnabled()
		{
			return default(bool);
		}

		// Token: 0x06012E4C RID: 77388 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E4C")]
		[Address(RVA = "0x2448DFC", Offset = "0x2448DFC", VA = "0x2448DFC")]
		public static void TrySetOldUserConsentToUnknown()
		{
		}

		// Token: 0x06012E4D RID: 77389 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E4D")]
		[Address(RVA = "0x2449254", Offset = "0x2449254", VA = "0x2449254")]
		public ApplicationPrivacyManager()
		{
		}

		// Token: 0x0400EE5D RID: 61021
		[Token(Token = "0x400EE5D")]
		[FieldOffset(Offset = "0x0")]
		public static AppManager appManager;

		// Token: 0x0400EE5E RID: 61022
		[Token(Token = "0x400EE5E")]
		private const float MaxWaitTimeForFirstPing = 2f;

		// Token: 0x0400EE5F RID: 61023
		[Token(Token = "0x400EE5F")]
		public const long LastDateBeforeExplicitConsentRequired = 1735516800000L;

		// Token: 0x0400EE60 RID: 61024
		[Token(Token = "0x400EE60")]
		[FieldOffset(Offset = "0x8")]
		private static readonly string[] AutoPrivacyDialogEnabledCountries;

		// Token: 0x0400EE61 RID: 61025
		[Token(Token = "0x400EE61")]
		[FieldOffset(Offset = "0x10")]
		private static bool <PingReceivedBeginningOfSession>k__BackingField;

		// Token: 0x0400EE62 RID: 61026
		[Token(Token = "0x400EE62")]
		[FieldOffset(Offset = "0x11")]
		private static bool <FlowIsActive>k__BackingField;

		// Token: 0x020025B6 RID: 9654
		[Token(Token = "0x20025B6")]
		public enum PrivacyConsentState
		{
			// Token: 0x0400EE64 RID: 61028
			[Token(Token = "0x400EE64")]
			Denied,
			// Token: 0x0400EE65 RID: 61029
			[Token(Token = "0x400EE65")]
			Granted,
			// Token: 0x0400EE66 RID: 61030
			[Token(Token = "0x400EE66")]
			NonDecided,
			// Token: 0x0400EE67 RID: 61031
			[Token(Token = "0x400EE67")]
			Unknown
		}

		// Token: 0x020025B7 RID: 9655
		[Token(Token = "0x20025B7")]
		public enum AgeGroup
		{
			// Token: 0x0400EE69 RID: 61033
			[Token(Token = "0x400EE69")]
			NotSet,
			// Token: 0x0400EE6A RID: 61034
			[Token(Token = "0x400EE6A")]
			Under13,
			// Token: 0x0400EE6B RID: 61035
			[Token(Token = "0x400EE6B")]
			Between13And18,
			// Token: 0x0400EE6C RID: 61036
			[Token(Token = "0x400EE6C")]
			Over18,
			// Token: 0x0400EE6D RID: 61037
			[Token(Token = "0x400EE6D")]
			Under18
		}

		// Token: 0x020025B8 RID: 9656
		[Token(Token = "0x20025B8")]
		public enum PrivacySettingsServiceType
		{
			// Token: 0x0400EE6F RID: 61039
			[Token(Token = "0x400EE6F")]
			FCM,
			// Token: 0x0400EE70 RID: 61040
			[Token(Token = "0x400EE70")]
			Helpshift,
			// Token: 0x0400EE71 RID: 61041
			[Token(Token = "0x400EE71")]
			GoogleSignIn,
			// Token: 0x0400EE72 RID: 61042
			[Token(Token = "0x400EE72")]
			FacebookLogin,
			// Token: 0x0400EE73 RID: 61043
			[Token(Token = "0x400EE73")]
			AppleSignIn,
			// Token: 0x0400EE74 RID: 61044
			[Token(Token = "0x400EE74")]
			Appsflyer,
			// Token: 0x0400EE75 RID: 61045
			[Token(Token = "0x400EE75")]
			Pecan,
			// Token: 0x0400EE76 RID: 61046
			[Token(Token = "0x400EE76")]
			GoogleMarketing,
			// Token: 0x0400EE77 RID: 61047
			[Token(Token = "0x400EE77")]
			FacebookMarketing,
			// Token: 0x0400EE78 RID: 61048
			[Token(Token = "0x400EE78")]
			UnityMarketing,
			// Token: 0x0400EE79 RID: 61049
			[Token(Token = "0x400EE79")]
			Mistplay
		}

		// Token: 0x020025B9 RID: 9657
		[Token(Token = "0x20025B9")]
		public enum PrivacySettingsCategoryType
		{
			// Token: 0x0400EE7B RID: 61051
			[Token(Token = "0x400EE7B")]
			Marketing,
			// Token: 0x0400EE7C RID: 61052
			[Token(Token = "0x400EE7C")]
			Performance,
			// Token: 0x0400EE7D RID: 61053
			[Token(Token = "0x400EE7D")]
			Essential
		}

		// Token: 0x020025BA RID: 9658
		[Token(Token = "0x20025BA")]
		private sealed class <CheckForFirstPing>d__71 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012E4F RID: 77391 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012E4F")]
			[Address(RVA = "0x244824C", Offset = "0x244824C", VA = "0x244824C")]
			[DebuggerHidden]
			public <CheckForFirstPing>d__71(int <>1__state)
			{
			}

			// Token: 0x06012E50 RID: 77392 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012E50")]
			[Address(RVA = "0x2449EC0", Offset = "0x2449EC0", VA = "0x2449EC0", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012E51 RID: 77393 RVA: 0x0007A220 File Offset: 0x00078420
			[Token(Token = "0x6012E51")]
			[Address(RVA = "0x2449EC4", Offset = "0x2449EC4", VA = "0x2449EC4", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x170027F3 RID: 10227
			// (get) Token: 0x06012E52 RID: 77394 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170027F3")]
			private object Current
			{
				[Token(Token = "0x6012E52")]
				[Address(RVA = "0x244A2BC", Offset = "0x244A2BC", VA = "0x244A2BC", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012E53 RID: 77395 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012E53")]
			[Address(RVA = "0x244A2C4", Offset = "0x244A2C4", VA = "0x244A2C4", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x170027F4 RID: 10228
			// (get) Token: 0x06012E54 RID: 77396 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170027F4")]
			private object Current
			{
				[Token(Token = "0x6012E54")]
				[Address(RVA = "0x244A304", Offset = "0x244A304", VA = "0x244A304", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EE7E RID: 61054
			[Token(Token = "0x400EE7E")]
			[FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EE7F RID: 61055
			[Token(Token = "0x400EE7F")]
			[FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EE80 RID: 61056
			[Token(Token = "0x400EE80")]
			[FieldOffset(Offset = "0x20")]
			private float <elapsedTime>5__2;
		}
	}
}
