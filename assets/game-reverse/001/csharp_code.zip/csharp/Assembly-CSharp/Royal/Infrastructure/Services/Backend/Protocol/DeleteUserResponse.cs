﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200237B RID: 9083
	[Token(Token = "0x200237B")]
	public struct DeleteUserResponse : IFlatbufferObject
	{
		// Token: 0x17001FB7 RID: 8119
		// (get) Token: 0x06010EE7 RID: 69351 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FB7")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010EE7")]
			[Address(RVA = "0x1F94CE8", Offset = "0x1F94CE8", VA = "0x1F94CE8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EE8 RID: 69352 RVA: 0x00062A00 File Offset: 0x00060C00
		[Token(Token = "0x6010EE8")]
		[Address(RVA = "0x1F94CF0", Offset = "0x1F94CF0", VA = "0x1F94CF0")]
		public static DeleteUserResponse GetRootAsDeleteUserResponse(ByteBuffer _bb)
		{
			return default(DeleteUserResponse);
		}

		// Token: 0x06010EE9 RID: 69353 RVA: 0x00062A18 File Offset: 0x00060C18
		[Token(Token = "0x6010EE9")]
		[Address(RVA = "0x1F94CFC", Offset = "0x1F94CFC", VA = "0x1F94CFC")]
		public static DeleteUserResponse GetRootAsDeleteUserResponse(ByteBuffer _bb, DeleteUserResponse obj)
		{
			return default(DeleteUserResponse);
		}

		// Token: 0x06010EEA RID: 69354 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EEA")]
		[Address(RVA = "0x1F94DAC", Offset = "0x1F94DAC", VA = "0x1F94DAC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010EEB RID: 69355 RVA: 0x00062A30 File Offset: 0x00060C30
		[Token(Token = "0x6010EEB")]
		[Address(RVA = "0x1F94D74", Offset = "0x1F94D74", VA = "0x1F94D74")]
		public DeleteUserResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(DeleteUserResponse);
		}

		// Token: 0x17001FB8 RID: 8120
		// (get) Token: 0x06010EEC RID: 69356 RVA: 0x00062A48 File Offset: 0x00060C48
		[Token(Token = "0x17001FB8")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010EEC")]
			[Address(RVA = "0x1F94DBC", Offset = "0x1F94DBC", VA = "0x1F94DBC")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x06010EED RID: 69357 RVA: 0x00062A60 File Offset: 0x00060C60
		[Token(Token = "0x6010EED")]
		[Address(RVA = "0x1F94E00", Offset = "0x1F94E00", VA = "0x1F94E00")]
		public static Offset<DeleteUserResponse> CreateDeleteUserResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success)
		{
			return default(Offset<DeleteUserResponse>);
		}

		// Token: 0x06010EEE RID: 69358 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EEE")]
		[Address(RVA = "0x1F94ED4", Offset = "0x1F94ED4", VA = "0x1F94ED4")]
		public static void StartDeleteUserResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010EEF RID: 69359 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EEF")]
		[Address(RVA = "0x1F94E48", Offset = "0x1F94E48", VA = "0x1F94E48")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010EF0 RID: 69360 RVA: 0x00062A78 File Offset: 0x00060C78
		[Token(Token = "0x6010EF0")]
		[Address(RVA = "0x1F94E68", Offset = "0x1F94E68", VA = "0x1F94E68")]
		public static Offset<DeleteUserResponse> EndDeleteUserResponse(FlatBufferBuilder builder)
		{
			return default(Offset<DeleteUserResponse>);
		}

		// Token: 0x0400E694 RID: 59028
		[Token(Token = "0x400E694")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
