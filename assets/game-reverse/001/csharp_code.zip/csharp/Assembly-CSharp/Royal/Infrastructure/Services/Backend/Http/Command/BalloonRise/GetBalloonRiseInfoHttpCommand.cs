﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.BalloonRise
{
	// Token: 0x02002576 RID: 9590
	[Token(Token = "0x2002576")]
	public class GetBalloonRiseInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027B6 RID: 10166
		// (get) Token: 0x06012BB5 RID: 76725 RVA: 0x000793F8 File Offset: 0x000775F8
		[Token(Token = "0x170027B6")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012BB5")]
			[Address(RVA = "0x1ED4BA8", Offset = "0x1ED4BA8", VA = "0x1ED4BA8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027B7 RID: 10167
		// (get) Token: 0x06012BB6 RID: 76726 RVA: 0x00079410 File Offset: 0x00077610
		[Token(Token = "0x170027B7")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012BB6")]
			[Address(RVA = "0x1ED4BB0", Offset = "0x1ED4BB0", VA = "0x1ED4BB0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012BB7 RID: 76727 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BB7")]
		[Address(RVA = "0x1ED4BB8", Offset = "0x1ED4BB8", VA = "0x1ED4BB8")]
		public GetBalloonRiseInfoHttpCommand(int eventId)
		{
		}

		// Token: 0x06012BB8 RID: 76728 RVA: 0x00079428 File Offset: 0x00077628
		[Token(Token = "0x6012BB8")]
		[Address(RVA = "0x1ED4BE8", Offset = "0x1ED4BE8", VA = "0x1ED4BE8", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012BB9 RID: 76729 RVA: 0x00079440 File Offset: 0x00077640
		[Token(Token = "0x6012BB9")]
		[Address(RVA = "0x1ED4CA8", Offset = "0x1ED4CA8", VA = "0x1ED4CA8", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BBA RID: 76730 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BBA")]
		[Address(RVA = "0x1ED4CC8", Offset = "0x1ED4CC8", VA = "0x1ED4CC8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BBB RID: 76731 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BBB")]
		[Address(RVA = "0x1ED4DA4", Offset = "0x1ED4DA4", VA = "0x1ED4DA4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EC01 RID: 60417
		[Token(Token = "0x400EC01")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;
	}
}
