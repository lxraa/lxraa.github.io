﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023CB RID: 9163
	[Token(Token = "0x20023CB")]
	public struct GetDailyLightningRushInfoResponse : IFlatbufferObject
	{
		// Token: 0x170020D6 RID: 8406
		// (get) Token: 0x06011327 RID: 70439 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020D6")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011327")]
			[Address(RVA = "0x1CAD4D4", Offset = "0x1CAD4D4", VA = "0x1CAD4D4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011328 RID: 70440 RVA: 0x00066258 File Offset: 0x00064458
		[Token(Token = "0x6011328")]
		[Address(RVA = "0x1CAD4DC", Offset = "0x1CAD4DC", VA = "0x1CAD4DC")]
		public static GetDailyLightningRushInfoResponse GetRootAsGetDailyLightningRushInfoResponse(ByteBuffer _bb)
		{
			return default(GetDailyLightningRushInfoResponse);
		}

		// Token: 0x06011329 RID: 70441 RVA: 0x00066270 File Offset: 0x00064470
		[Token(Token = "0x6011329")]
		[Address(RVA = "0x1CAD4E8", Offset = "0x1CAD4E8", VA = "0x1CAD4E8")]
		public static GetDailyLightningRushInfoResponse GetRootAsGetDailyLightningRushInfoResponse(ByteBuffer _bb, GetDailyLightningRushInfoResponse obj)
		{
			return default(GetDailyLightningRushInfoResponse);
		}

		// Token: 0x0601132A RID: 70442 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601132A")]
		[Address(RVA = "0x1CAD598", Offset = "0x1CAD598", VA = "0x1CAD598", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601132B RID: 70443 RVA: 0x00066288 File Offset: 0x00064488
		[Token(Token = "0x601132B")]
		[Address(RVA = "0x1CAD560", Offset = "0x1CAD560", VA = "0x1CAD560")]
		public GetDailyLightningRushInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetDailyLightningRushInfoResponse);
		}

		// Token: 0x170020D7 RID: 8407
		// (get) Token: 0x0601132C RID: 70444 RVA: 0x000662A0 File Offset: 0x000644A0
		[Token(Token = "0x170020D7")]
		public GetDailyLightningRushInfoFailReason FailReason
		{
			[Token(Token = "0x601132C")]
			[Address(RVA = "0x1CAD5A8", Offset = "0x1CAD5A8", VA = "0x1CAD5A8")]
			get
			{
				return GetDailyLightningRushInfoFailReason.None;
			}
		}

		// Token: 0x170020D8 RID: 8408
		// (get) Token: 0x0601132D RID: 70445 RVA: 0x000662B8 File Offset: 0x000644B8
		[Token(Token = "0x170020D8")]
		public DailyLightningRushInfo? UserDailyLightningRushInfo
		{
			[Token(Token = "0x601132D")]
			[Address(RVA = "0x1CAD5EC", Offset = "0x1CAD5EC", VA = "0x1CAD5EC")]
			get
			{
				return null;
			}
		}

		// Token: 0x170020D9 RID: 8409
		// (get) Token: 0x0601132E RID: 70446 RVA: 0x000662D0 File Offset: 0x000644D0
		[Token(Token = "0x170020D9")]
		public DailyLightningRushGroupInfo? DailyLightningRushGroupInfo
		{
			[Token(Token = "0x601132E")]
			[Address(RVA = "0x1CAD6AC", Offset = "0x1CAD6AC", VA = "0x1CAD6AC")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601132F RID: 70447 RVA: 0x000662E8 File Offset: 0x000644E8
		[Token(Token = "0x601132F")]
		[Address(RVA = "0x1CAD76C", Offset = "0x1CAD76C", VA = "0x1CAD76C")]
		public static Offset<GetDailyLightningRushInfoResponse> CreateGetDailyLightningRushInfoResponse(FlatBufferBuilder builder, GetDailyLightningRushInfoFailReason fail_reason = GetDailyLightningRushInfoFailReason.None, [Optional] Offset<DailyLightningRushInfo> user_daily_lightning_rush_infoOffset, [Optional] Offset<DailyLightningRushGroupInfo> daily_lightning_rush_group_infoOffset)
		{
			return default(Offset<GetDailyLightningRushInfoResponse>);
		}

		// Token: 0x06011330 RID: 70448 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011330")]
		[Address(RVA = "0x1CAD8A8", Offset = "0x1CAD8A8", VA = "0x1CAD8A8")]
		public static void StartGetDailyLightningRushInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011331 RID: 70449 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011331")]
		[Address(RVA = "0x1CAD81C", Offset = "0x1CAD81C", VA = "0x1CAD81C")]
		public static void AddFailReason(FlatBufferBuilder builder, GetDailyLightningRushInfoFailReason failReason)
		{
		}

		// Token: 0x06011332 RID: 70450 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011332")]
		[Address(RVA = "0x1CAD7FC", Offset = "0x1CAD7FC", VA = "0x1CAD7FC")]
		public static void AddUserDailyLightningRushInfo(FlatBufferBuilder builder, Offset<DailyLightningRushInfo> userDailyLightningRushInfoOffset)
		{
		}

		// Token: 0x06011333 RID: 70451 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011333")]
		[Address(RVA = "0x1CAD7DC", Offset = "0x1CAD7DC", VA = "0x1CAD7DC")]
		public static void AddDailyLightningRushGroupInfo(FlatBufferBuilder builder, Offset<DailyLightningRushGroupInfo> dailyLightningRushGroupInfoOffset)
		{
		}

		// Token: 0x06011334 RID: 70452 RVA: 0x00066300 File Offset: 0x00064500
		[Token(Token = "0x6011334")]
		[Address(RVA = "0x1CAD83C", Offset = "0x1CAD83C", VA = "0x1CAD83C")]
		public static Offset<GetDailyLightningRushInfoResponse> EndGetDailyLightningRushInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetDailyLightningRushInfoResponse>);
		}

		// Token: 0x0400E73B RID: 59195
		[Token(Token = "0x400E73B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
