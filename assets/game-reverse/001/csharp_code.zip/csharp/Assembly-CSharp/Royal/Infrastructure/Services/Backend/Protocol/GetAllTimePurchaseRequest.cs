﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023BF RID: 9151
	[Token(Token = "0x20023BF")]
	public struct GetAllTimePurchaseRequest : IFlatbufferObject
	{
		// Token: 0x170020B7 RID: 8375
		// (get) Token: 0x060112A3 RID: 70307 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020B7")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60112A3")]
			[Address(RVA = "0x1CAB6D0", Offset = "0x1CAB6D0", VA = "0x1CAB6D0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112A4 RID: 70308 RVA: 0x00065B38 File Offset: 0x00063D38
		[Token(Token = "0x60112A4")]
		[Address(RVA = "0x1CAB6D8", Offset = "0x1CAB6D8", VA = "0x1CAB6D8")]
		public static GetAllTimePurchaseRequest GetRootAsGetAllTimePurchaseRequest(ByteBuffer _bb)
		{
			return default(GetAllTimePurchaseRequest);
		}

		// Token: 0x060112A5 RID: 70309 RVA: 0x00065B50 File Offset: 0x00063D50
		[Token(Token = "0x60112A5")]
		[Address(RVA = "0x1CAB6E4", Offset = "0x1CAB6E4", VA = "0x1CAB6E4")]
		public static GetAllTimePurchaseRequest GetRootAsGetAllTimePurchaseRequest(ByteBuffer _bb, GetAllTimePurchaseRequest obj)
		{
			return default(GetAllTimePurchaseRequest);
		}

		// Token: 0x060112A6 RID: 70310 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112A6")]
		[Address(RVA = "0x1CAB794", Offset = "0x1CAB794", VA = "0x1CAB794", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060112A7 RID: 70311 RVA: 0x00065B68 File Offset: 0x00063D68
		[Token(Token = "0x60112A7")]
		[Address(RVA = "0x1CAB75C", Offset = "0x1CAB75C", VA = "0x1CAB75C")]
		public GetAllTimePurchaseRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetAllTimePurchaseRequest);
		}

		// Token: 0x060112A8 RID: 70312 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112A8")]
		[Address(RVA = "0x1CAB7A4", Offset = "0x1CAB7A4", VA = "0x1CAB7A4")]
		public static void StartGetAllTimePurchaseRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060112A9 RID: 70313 RVA: 0x00065B80 File Offset: 0x00063D80
		[Token(Token = "0x60112A9")]
		[Address(RVA = "0x1CAB7BC", Offset = "0x1CAB7BC", VA = "0x1CAB7BC")]
		public static Offset<GetAllTimePurchaseRequest> EndGetAllTimePurchaseRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetAllTimePurchaseRequest>);
		}

		// Token: 0x0400E72C RID: 59180
		[Token(Token = "0x400E72C")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
