﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C8 RID: 9160
	[Token(Token = "0x20023C8")]
	public struct GetByteArrayKeyValuesResponse : IFlatbufferObject
	{
		// Token: 0x170020CF RID: 8399
		// (get) Token: 0x06011309 RID: 70409 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020CF")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011309")]
			[Address(RVA = "0x1CACD4C", Offset = "0x1CACD4C", VA = "0x1CACD4C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601130A RID: 70410 RVA: 0x000660A8 File Offset: 0x000642A8
		[Token(Token = "0x601130A")]
		[Address(RVA = "0x1CACD54", Offset = "0x1CACD54", VA = "0x1CACD54")]
		public static GetByteArrayKeyValuesResponse GetRootAsGetByteArrayKeyValuesResponse(ByteBuffer _bb)
		{
			return default(GetByteArrayKeyValuesResponse);
		}

		// Token: 0x0601130B RID: 70411 RVA: 0x000660C0 File Offset: 0x000642C0
		[Token(Token = "0x601130B")]
		[Address(RVA = "0x1CACD60", Offset = "0x1CACD60", VA = "0x1CACD60")]
		public static GetByteArrayKeyValuesResponse GetRootAsGetByteArrayKeyValuesResponse(ByteBuffer _bb, GetByteArrayKeyValuesResponse obj)
		{
			return default(GetByteArrayKeyValuesResponse);
		}

		// Token: 0x0601130C RID: 70412 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601130C")]
		[Address(RVA = "0x1CACE10", Offset = "0x1CACE10", VA = "0x1CACE10", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601130D RID: 70413 RVA: 0x000660D8 File Offset: 0x000642D8
		[Token(Token = "0x601130D")]
		[Address(RVA = "0x1CACDD8", Offset = "0x1CACDD8", VA = "0x1CACDD8")]
		public GetByteArrayKeyValuesResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetByteArrayKeyValuesResponse);
		}

		// Token: 0x0601130E RID: 70414 RVA: 0x000660F0 File Offset: 0x000642F0
		[Token(Token = "0x601130E")]
		[Address(RVA = "0x1CACE20", Offset = "0x1CACE20", VA = "0x1CACE20")]
		public ByteArrayKeyValue? ByteArrayKeyValueList(int j)
		{
			return null;
		}

		// Token: 0x170020D0 RID: 8400
		// (get) Token: 0x0601130F RID: 70415 RVA: 0x00066108 File Offset: 0x00064308
		[Token(Token = "0x170020D0")]
		public int ByteArrayKeyValueListLength
		{
			[Token(Token = "0x601130F")]
			[Address(RVA = "0x1CACEF8", Offset = "0x1CACEF8", VA = "0x1CACEF8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011310 RID: 70416 RVA: 0x00066120 File Offset: 0x00064320
		[Token(Token = "0x6011310")]
		[Address(RVA = "0x1CACF2C", Offset = "0x1CACF2C", VA = "0x1CACF2C")]
		public static Offset<GetByteArrayKeyValuesResponse> CreateGetByteArrayKeyValuesResponse(FlatBufferBuilder builder, [Optional] VectorOffset byteArrayKeyValueListOffset)
		{
			return default(Offset<GetByteArrayKeyValuesResponse>);
		}

		// Token: 0x06011311 RID: 70417 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011311")]
		[Address(RVA = "0x1CAD000", Offset = "0x1CAD000", VA = "0x1CAD000")]
		public static void StartGetByteArrayKeyValuesResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011312 RID: 70418 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011312")]
		[Address(RVA = "0x1CACF74", Offset = "0x1CACF74", VA = "0x1CACF74")]
		public static void AddByteArrayKeyValueList(FlatBufferBuilder builder, VectorOffset byteArrayKeyValueListOffset)
		{
		}

		// Token: 0x06011313 RID: 70419 RVA: 0x00066138 File Offset: 0x00064338
		[Token(Token = "0x6011313")]
		[Address(RVA = "0x1CAD018", Offset = "0x1CAD018", VA = "0x1CAD018")]
		public static VectorOffset CreateByteArrayKeyValueListVector(FlatBufferBuilder builder, Offset<ByteArrayKeyValue>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011314 RID: 70420 RVA: 0x00066150 File Offset: 0x00064350
		[Token(Token = "0x6011314")]
		[Address(RVA = "0x1CAD0C0", Offset = "0x1CAD0C0", VA = "0x1CAD0C0")]
		public static VectorOffset CreateByteArrayKeyValueListVectorBlock(FlatBufferBuilder builder, Offset<ByteArrayKeyValue>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011315 RID: 70421 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011315")]
		[Address(RVA = "0x1CAD148", Offset = "0x1CAD148", VA = "0x1CAD148")]
		public static void StartByteArrayKeyValueListVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011316 RID: 70422 RVA: 0x00066168 File Offset: 0x00064368
		[Token(Token = "0x6011316")]
		[Address(RVA = "0x1CACF94", Offset = "0x1CACF94", VA = "0x1CACF94")]
		public static Offset<GetByteArrayKeyValuesResponse> EndGetByteArrayKeyValuesResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetByteArrayKeyValuesResponse>);
		}

		// Token: 0x0400E735 RID: 59189
		[Token(Token = "0x400E735")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
