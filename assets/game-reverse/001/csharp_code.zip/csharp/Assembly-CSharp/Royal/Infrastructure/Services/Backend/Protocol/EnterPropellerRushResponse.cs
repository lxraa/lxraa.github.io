﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A8 RID: 9128
	[Token(Token = "0x20023A8")]
	public struct EnterPropellerRushResponse : IFlatbufferObject
	{
		// Token: 0x17002059 RID: 8281
		// (get) Token: 0x0601115A RID: 69978 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002059")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601115A")]
			[Address(RVA = "0x1F9E570", Offset = "0x1F9E570", VA = "0x1F9E570", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601115B RID: 69979 RVA: 0x00064A70 File Offset: 0x00062C70
		[Token(Token = "0x601115B")]
		[Address(RVA = "0x1F9E578", Offset = "0x1F9E578", VA = "0x1F9E578")]
		public static EnterPropellerRushResponse GetRootAsEnterPropellerRushResponse(ByteBuffer _bb)
		{
			return default(EnterPropellerRushResponse);
		}

		// Token: 0x0601115C RID: 69980 RVA: 0x00064A88 File Offset: 0x00062C88
		[Token(Token = "0x601115C")]
		[Address(RVA = "0x1F9E584", Offset = "0x1F9E584", VA = "0x1F9E584")]
		public static EnterPropellerRushResponse GetRootAsEnterPropellerRushResponse(ByteBuffer _bb, EnterPropellerRushResponse obj)
		{
			return default(EnterPropellerRushResponse);
		}

		// Token: 0x0601115D RID: 69981 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601115D")]
		[Address(RVA = "0x1F9E634", Offset = "0x1F9E634", VA = "0x1F9E634", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601115E RID: 69982 RVA: 0x00064AA0 File Offset: 0x00062CA0
		[Token(Token = "0x601115E")]
		[Address(RVA = "0x1F9E5FC", Offset = "0x1F9E5FC", VA = "0x1F9E5FC")]
		public EnterPropellerRushResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterPropellerRushResponse);
		}

		// Token: 0x1700205A RID: 8282
		// (get) Token: 0x0601115F RID: 69983 RVA: 0x00064AB8 File Offset: 0x00062CB8
		[Token(Token = "0x1700205A")]
		public EnterPropellerRushFailReason FailReason
		{
			[Token(Token = "0x601115F")]
			[Address(RVA = "0x1F9E644", Offset = "0x1F9E644", VA = "0x1F9E644")]
			get
			{
				return EnterPropellerRushFailReason.None;
			}
		}

		// Token: 0x1700205B RID: 8283
		// (get) Token: 0x06011160 RID: 69984 RVA: 0x00064AD0 File Offset: 0x00062CD0
		[Token(Token = "0x1700205B")]
		public PropellerRushInfo? PropellerRushInfo
		{
			[Token(Token = "0x6011160")]
			[Address(RVA = "0x1F9E688", Offset = "0x1F9E688", VA = "0x1F9E688")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700205C RID: 8284
		// (get) Token: 0x06011161 RID: 69985 RVA: 0x00064AE8 File Offset: 0x00062CE8
		[Token(Token = "0x1700205C")]
		public PropellerRushGroupInfo? PropellerRushGroupInfo
		{
			[Token(Token = "0x6011161")]
			[Address(RVA = "0x1F9E748", Offset = "0x1F9E748", VA = "0x1F9E748")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700205D RID: 8285
		// (get) Token: 0x06011162 RID: 69986 RVA: 0x00064B00 File Offset: 0x00062D00
		[Token(Token = "0x1700205D")]
		public PropellerRushGroupType GroupType
		{
			[Token(Token = "0x6011162")]
			[Address(RVA = "0x1F9E808", Offset = "0x1F9E808", VA = "0x1F9E808")]
			get
			{
				return PropellerRushGroupType.None;
			}
		}

		// Token: 0x06011163 RID: 69987 RVA: 0x00064B18 File Offset: 0x00062D18
		[Token(Token = "0x6011163")]
		[Address(RVA = "0x1F9E84C", Offset = "0x1F9E84C", VA = "0x1F9E84C")]
		public static Offset<EnterPropellerRushResponse> CreateEnterPropellerRushResponse(FlatBufferBuilder builder, EnterPropellerRushFailReason fail_reason = EnterPropellerRushFailReason.None, [Optional] Offset<PropellerRushInfo> propeller_rush_infoOffset, [Optional] Offset<PropellerRushGroupInfo> propeller_rush_group_infoOffset, PropellerRushGroupType group_type = PropellerRushGroupType.None)
		{
			return default(Offset<EnterPropellerRushResponse>);
		}

		// Token: 0x06011164 RID: 69988 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011164")]
		[Address(RVA = "0x1F9E9B8", Offset = "0x1F9E9B8", VA = "0x1F9E9B8")]
		public static void StartEnterPropellerRushResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011165 RID: 69989 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011165")]
		[Address(RVA = "0x1F9E92C", Offset = "0x1F9E92C", VA = "0x1F9E92C")]
		public static void AddFailReason(FlatBufferBuilder builder, EnterPropellerRushFailReason failReason)
		{
		}

		// Token: 0x06011166 RID: 69990 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011166")]
		[Address(RVA = "0x1F9E8EC", Offset = "0x1F9E8EC", VA = "0x1F9E8EC")]
		public static void AddPropellerRushInfo(FlatBufferBuilder builder, Offset<PropellerRushInfo> propellerRushInfoOffset)
		{
		}

		// Token: 0x06011167 RID: 69991 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011167")]
		[Address(RVA = "0x1F9E8CC", Offset = "0x1F9E8CC", VA = "0x1F9E8CC")]
		public static void AddPropellerRushGroupInfo(FlatBufferBuilder builder, Offset<PropellerRushGroupInfo> propellerRushGroupInfoOffset)
		{
		}

		// Token: 0x06011168 RID: 69992 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011168")]
		[Address(RVA = "0x1F9E90C", Offset = "0x1F9E90C", VA = "0x1F9E90C")]
		public static void AddGroupType(FlatBufferBuilder builder, PropellerRushGroupType groupType)
		{
		}

		// Token: 0x06011169 RID: 69993 RVA: 0x00064B30 File Offset: 0x00062D30
		[Token(Token = "0x6011169")]
		[Address(RVA = "0x1F9E94C", Offset = "0x1F9E94C", VA = "0x1F9E94C")]
		public static Offset<EnterPropellerRushResponse> EndEnterPropellerRushResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterPropellerRushResponse>);
		}

		// Token: 0x0400E6DA RID: 59098
		[Token(Token = "0x400E6DA")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
