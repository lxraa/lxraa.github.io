﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Social
{
	// Token: 0x02002541 RID: 9537
	[Token(Token = "0x2002541")]
	public class ChangeUserNameHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700273A RID: 10042
		// (get) Token: 0x06012A44 RID: 76356 RVA: 0x000782E8 File Offset: 0x000764E8
		[Token(Token = "0x1700273A")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A44")]
			[Address(RVA = "0x1CFF68C", Offset = "0x1CFF68C", VA = "0x1CFF68C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700273B RID: 10043
		// (get) Token: 0x06012A45 RID: 76357 RVA: 0x00078300 File Offset: 0x00076500
		[Token(Token = "0x1700273B")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A45")]
			[Address(RVA = "0x1CFF694", Offset = "0x1CFF694", VA = "0x1CFF694", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700273C RID: 10044
		// (get) Token: 0x06012A46 RID: 76358 RVA: 0x00078318 File Offset: 0x00076518
		// (set) Token: 0x06012A47 RID: 76359 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700273C")]
		public ChangeUserNameResponse Response
		{
			[Token(Token = "0x6012A46")]
			[Address(RVA = "0x1CFF69C", Offset = "0x1CFF69C", VA = "0x1CFF69C")]
			get
			{
				return default(ChangeUserNameResponse);
			}
			[Token(Token = "0x6012A47")]
			[Address(RVA = "0x1CFF6A8", Offset = "0x1CFF6A8", VA = "0x1CFF6A8")]
			private set
			{
			}
		}

		// Token: 0x1400009C RID: 156
		// (add) Token: 0x06012A48 RID: 76360 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012A49 RID: 76361 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1400009C")]
		public static event Action OnChangeUserName
		{
			[Token(Token = "0x6012A48")]
			[Address(RVA = "0x1CFF6B8", Offset = "0x1CFF6B8", VA = "0x1CFF6B8")]
			add
			{
			}
			[Token(Token = "0x6012A49")]
			[Address(RVA = "0x1CFF770", Offset = "0x1CFF770", VA = "0x1CFF770")]
			remove
			{
			}
		}

		// Token: 0x1400009D RID: 157
		// (add) Token: 0x06012A4A RID: 76362 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012A4B RID: 76363 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1400009D")]
		public static event Action OnInvalidNameChange
		{
			[Token(Token = "0x6012A4A")]
			[Address(RVA = "0x1CFF828", Offset = "0x1CFF828", VA = "0x1CFF828")]
			add
			{
			}
			[Token(Token = "0x6012A4B")]
			[Address(RVA = "0x1CFF8E4", Offset = "0x1CFF8E4", VA = "0x1CFF8E4")]
			remove
			{
			}
		}

		// Token: 0x06012A4C RID: 76364 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A4C")]
		[Address(RVA = "0x1CFF9A0", Offset = "0x1CFF9A0", VA = "0x1CFF9A0")]
		public ChangeUserNameHttpCommand(string newName, UserProfileSetting userProfileSetting, [Optional] string trigger)
		{
		}

		// Token: 0x06012A4D RID: 76365 RVA: 0x00078330 File Offset: 0x00076530
		[Token(Token = "0x6012A4D")]
		[Address(RVA = "0x1CFFA78", Offset = "0x1CFFA78", VA = "0x1CFFA78", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A4E RID: 76366 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A4E")]
		[Address(RVA = "0x1CFFC68", Offset = "0x1CFFC68", VA = "0x1CFFC68", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A4F RID: 76367 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A4F")]
		[Address(RVA = "0x1CFFF04", Offset = "0x1CFFF04", VA = "0x1CFFF04")]
		private void ShowSlidingText(string text)
		{
		}

		// Token: 0x06012A50 RID: 76368 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A50")]
		[Address(RVA = "0x1D00188", Offset = "0x1D00188", VA = "0x1D00188", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012A51 RID: 76369 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A51")]
		[Address(RVA = "0x1CFFFF0", Offset = "0x1CFFFF0", VA = "0x1CFFFF0")]
		private static void UpdateSections()
		{
		}

		// Token: 0x06012A52 RID: 76370 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A52")]
		[Address(RVA = "0x1D0018C", Offset = "0x1D0018C", VA = "0x1D0018C")]
		public static void NameChanged()
		{
		}

		// Token: 0x0400EB60 RID: 60256
		[Token(Token = "0x400EB60")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		private ChangeUserNameResponse <Response>k__BackingField;

		// Token: 0x0400EB63 RID: 60259
		[Token(Token = "0x400EB63")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		private readonly string oldName;

		// Token: 0x0400EB64 RID: 60260
		[Token(Token = "0x400EB64")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
		private readonly string newName;

		// Token: 0x0400EB65 RID: 60261
		[Token(Token = "0x400EB65")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x38")]
		private readonly string trigger;

		// Token: 0x0400EB66 RID: 60262
		[Token(Token = "0x400EB66")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x40")]
		private readonly bool isFirstEnter;

		// Token: 0x0400EB67 RID: 60263
		[Token(Token = "0x400EB67")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x48")]
		private readonly UserProfileSetting userProfileSetting;
	}
}
