﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SeasonalCardCollection
{
	// Token: 0x0200254C RID: 9548
	[Token(Token = "0x200254C")]
	public class AskTeamSeasonalCardCollectionCardHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002759 RID: 10073
		// (get) Token: 0x06012AA2 RID: 76450 RVA: 0x000786D8 File Offset: 0x000768D8
		[Token(Token = "0x17002759")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AA2")]
			[Address(RVA = "0x1ECC324", Offset = "0x1ECC324", VA = "0x1ECC324", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700275A RID: 10074
		// (get) Token: 0x06012AA3 RID: 76451 RVA: 0x000786F0 File Offset: 0x000768F0
		[Token(Token = "0x1700275A")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AA3")]
			[Address(RVA = "0x1ECC32C", Offset = "0x1ECC32C", VA = "0x1ECC32C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AA4 RID: 76452 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AA4")]
		[Address(RVA = "0x1ECC334", Offset = "0x1ECC334", VA = "0x1ECC334")]
		public AskTeamSeasonalCardCollectionCardHttpCommand(long teamId, string userName, int setId, int cardId, UserProfileSetting userProfile)
		{
		}

		// Token: 0x06012AA5 RID: 76453 RVA: 0x00078708 File Offset: 0x00076908
		[Token(Token = "0x6012AA5")]
		[Address(RVA = "0x1ECC558", Offset = "0x1ECC558", VA = "0x1ECC558", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AA6 RID: 76454 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AA6")]
		[Address(RVA = "0x1ECC658", Offset = "0x1ECC658", VA = "0x1ECC658", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AA7 RID: 76455 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AA7")]
		[Address(RVA = "0x1ECC840", Offset = "0x1ECC840", VA = "0x1ECC840", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB85 RID: 60293
		[Token(Token = "0x400EB85")]
		[FieldOffset(Offset = "0x18")]
		private readonly UserProfileSetting userProfile;

		// Token: 0x0400EB86 RID: 60294
		[Token(Token = "0x400EB86")]
		[FieldOffset(Offset = "0x38")]
		private readonly string userName;

		// Token: 0x0400EB87 RID: 60295
		[Token(Token = "0x400EB87")]
		[FieldOffset(Offset = "0x40")]
		private readonly long teamId;

		// Token: 0x0400EB88 RID: 60296
		[Token(Token = "0x400EB88")]
		[FieldOffset(Offset = "0x48")]
		private readonly int setId;

		// Token: 0x0400EB89 RID: 60297
		[Token(Token = "0x400EB89")]
		[FieldOffset(Offset = "0x4C")]
		private readonly int cardId;

		// Token: 0x0400EB8A RID: 60298
		[Token(Token = "0x400EB8A")]
		[FieldOffset(Offset = "0x50")]
		private readonly bool isTeamInvite;
	}
}
