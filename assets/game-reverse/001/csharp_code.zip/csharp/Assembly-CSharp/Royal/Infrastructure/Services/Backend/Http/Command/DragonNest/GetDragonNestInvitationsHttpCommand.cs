﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.DragonNest
{
	// Token: 0x0200256E RID: 9582
	[Token(Token = "0x200256E")]
	public class GetDragonNestInvitationsHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027A6 RID: 10150
		// (get) Token: 0x06012B85 RID: 76677 RVA: 0x000791B8 File Offset: 0x000773B8
		[Token(Token = "0x170027A6")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B85")]
			[Address(RVA = "0x1ED3000", Offset = "0x1ED3000", VA = "0x1ED3000", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027A7 RID: 10151
		// (get) Token: 0x06012B86 RID: 76678 RVA: 0x000791D0 File Offset: 0x000773D0
		[Token(Token = "0x170027A7")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B86")]
			[Address(RVA = "0x1ED3008", Offset = "0x1ED3008", VA = "0x1ED3008", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B87 RID: 76679 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B87")]
		[Address(RVA = "0x1ED3010", Offset = "0x1ED3010", VA = "0x1ED3010")]
		public GetDragonNestInvitationsHttpCommand(bool sendTutorialInvite)
		{
		}

		// Token: 0x06012B88 RID: 76680 RVA: 0x000791E8 File Offset: 0x000773E8
		[Token(Token = "0x6012B88")]
		[Address(RVA = "0x1ED3038", Offset = "0x1ED3038", VA = "0x1ED3038", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B89 RID: 76681 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B89")]
		[Address(RVA = "0x1ED3058", Offset = "0x1ED3058", VA = "0x1ED3058", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B8A RID: 76682 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B8A")]
		[Address(RVA = "0x1ED3188", Offset = "0x1ED3188", VA = "0x1ED3188", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBE9 RID: 60393
		[Token(Token = "0x400EBE9")]
		[FieldOffset(Offset = "0x13")]
		private readonly bool tutorialInvite;
	}
}
