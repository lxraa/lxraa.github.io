﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002390 RID: 9104
	[Token(Token = "0x2002390")]
	public enum DragonType : sbyte
	{
		// Token: 0x0400E6AA RID: 59050
		[Token(Token = "0x400E6AA")]
		None,
		// Token: 0x0400E6AB RID: 59051
		[Token(Token = "0x400E6AB")]
		Fire,
		// Token: 0x0400E6AC RID: 59052
		[Token(Token = "0x400E6AC")]
		Ice,
		// Token: 0x0400E6AD RID: 59053
		[Token(Token = "0x400E6AD")]
		Water,
		// Token: 0x0400E6AE RID: 59054
		[Token(Token = "0x400E6AE")]
		Earth,
		// Token: 0x0400E6AF RID: 59055
		[Token(Token = "0x400E6AF")]
		Electric,
		// Token: 0x0400E6B0 RID: 59056
		[Token(Token = "0x400E6B0")]
		Magic,
		// Token: 0x0400E6B1 RID: 59057
		[Token(Token = "0x400E6B1")]
		Nature
	}
}
