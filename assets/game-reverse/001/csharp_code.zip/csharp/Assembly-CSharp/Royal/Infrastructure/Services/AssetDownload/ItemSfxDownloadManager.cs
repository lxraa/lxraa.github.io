﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using Royal.Infrastructure.Contexts;
using Royal.Scenes.Start.Context.Units.Audio;
using Royal.Scenes.Start.Context.Units.MusicBundle;
using UnityEngine;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x0200258D RID: 9613
	[Token(Token = "0x200258D")]
	public class ItemSfxDownloadManager : IContextBehaviour, IContextUnit
	{
		// Token: 0x170027D2 RID: 10194
		// (get) Token: 0x06012C68 RID: 76904 RVA: 0x00079890 File Offset: 0x00077A90
		[Token(Token = "0x170027D2")]
		public int Id
		{
			[Token(Token = "0x6012C68")]
			[Address(RVA = "0x1EDD3F8", Offset = "0x1EDD3F8", VA = "0x1EDD3F8", Slot = "5")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06012C69 RID: 76905 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C69")]
		[Address(RVA = "0x1EDD400", Offset = "0x1EDD400", VA = "0x1EDD400", Slot = "6")]
		public void Bind()
		{
		}

		// Token: 0x06012C6A RID: 76906 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C6A")]
		[Address(RVA = "0x1EDD404", Offset = "0x1EDD404", VA = "0x1EDD404", Slot = "4")]
		public void ManualUpdate()
		{
		}

		// Token: 0x06012C6B RID: 76907 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C6B")]
		[Address(RVA = "0x1EDD408", Offset = "0x1EDD408", VA = "0x1EDD408")]
		public static AudioClip GetAudioClipFromAssetBundle(AudioClipType audioClipType)
		{
			return null;
		}

		// Token: 0x06012C6C RID: 76908 RVA: 0x000798A8 File Offset: 0x00077AA8
		[Token(Token = "0x6012C6C")]
		[Address(RVA = "0x1EDD4AC", Offset = "0x1EDD4AC", VA = "0x1EDD4AC")]
		private static MusicBundleType GetBundle(int audioClipTypeIndex)
		{
			return MusicBundleType.None;
		}

		// Token: 0x06012C6D RID: 76909 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C6D")]
		[Address(RVA = "0x1EDD4D0", Offset = "0x1EDD4D0", VA = "0x1EDD4D0")]
		public static AudioClip GetAudioClipFromAssetBundle(MusicBundleType featureBundleType, string fileName)
		{
			return null;
		}

		// Token: 0x06012C6E RID: 76910 RVA: 0x000798C0 File Offset: 0x00077AC0
		[Token(Token = "0x6012C6E")]
		[Address(RVA = "0x1EDD59C", Offset = "0x1EDD59C", VA = "0x1EDD59C")]
		public static bool IsBundleLoaded(MusicBundleType featureBundleType)
		{
			return default(bool);
		}

		// Token: 0x06012C6F RID: 76911 RVA: 0x000798D8 File Offset: 0x00077AD8
		[Token(Token = "0x6012C6F")]
		[Address(RVA = "0x1EDD62C", Offset = "0x1EDD62C", VA = "0x1EDD62C")]
		private static AudioType GetAudioTypeFromFileExtension(string filePath)
		{
			return AudioType.UNKNOWN;
		}

		// Token: 0x06012C70 RID: 76912 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C70")]
		[Address(RVA = "0x1EDD770", Offset = "0x1EDD770", VA = "0x1EDD770")]
		public ItemSfxDownloadManager()
		{
		}

		// Token: 0x0400EC96 RID: 60566
		[Token(Token = "0x400EC96")]
		[FieldOffset(Offset = "0x0")]
		private static readonly Dictionary<AudioClipType, string> DownloadableItemSfxDictionary;
	}
}
