﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200236B RID: 9067
	[Token(Token = "0x200236B")]
	public struct ConsumeLifeResponse : IFlatbufferObject
	{
		// Token: 0x17001F73 RID: 8051
		// (get) Token: 0x06010E02 RID: 69122 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F73")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010E02")]
			[Address(RVA = "0x214C25C", Offset = "0x214C25C", VA = "0x214C25C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E03 RID: 69123 RVA: 0x00061EF0 File Offset: 0x000600F0
		[Token(Token = "0x6010E03")]
		[Address(RVA = "0x214C264", Offset = "0x214C264", VA = "0x214C264")]
		public static ConsumeLifeResponse GetRootAsConsumeLifeResponse(ByteBuffer _bb)
		{
			return default(ConsumeLifeResponse);
		}

		// Token: 0x06010E04 RID: 69124 RVA: 0x00061F08 File Offset: 0x00060108
		[Token(Token = "0x6010E04")]
		[Address(RVA = "0x214C270", Offset = "0x214C270", VA = "0x214C270")]
		public static ConsumeLifeResponse GetRootAsConsumeLifeResponse(ByteBuffer _bb, ConsumeLifeResponse obj)
		{
			return default(ConsumeLifeResponse);
		}

		// Token: 0x06010E05 RID: 69125 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E05")]
		[Address(RVA = "0x214C320", Offset = "0x214C320", VA = "0x214C320", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010E06 RID: 69126 RVA: 0x00061F20 File Offset: 0x00060120
		[Token(Token = "0x6010E06")]
		[Address(RVA = "0x214C2E8", Offset = "0x214C2E8", VA = "0x214C2E8")]
		public ConsumeLifeResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ConsumeLifeResponse);
		}

		// Token: 0x17001F74 RID: 8052
		// (get) Token: 0x06010E07 RID: 69127 RVA: 0x00061F38 File Offset: 0x00060138
		[Token(Token = "0x17001F74")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010E07")]
			[Address(RVA = "0x214C330", Offset = "0x214C330", VA = "0x214C330")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x06010E08 RID: 69128 RVA: 0x00061F50 File Offset: 0x00060150
		[Token(Token = "0x6010E08")]
		[Address(RVA = "0x214C374", Offset = "0x214C374", VA = "0x214C374")]
		public static Offset<ConsumeLifeResponse> CreateConsumeLifeResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success)
		{
			return default(Offset<ConsumeLifeResponse>);
		}

		// Token: 0x06010E09 RID: 69129 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E09")]
		[Address(RVA = "0x214C448", Offset = "0x214C448", VA = "0x214C448")]
		public static void StartConsumeLifeResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010E0A RID: 69130 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E0A")]
		[Address(RVA = "0x214C3BC", Offset = "0x214C3BC", VA = "0x214C3BC")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010E0B RID: 69131 RVA: 0x00061F68 File Offset: 0x00060168
		[Token(Token = "0x6010E0B")]
		[Address(RVA = "0x214C3DC", Offset = "0x214C3DC", VA = "0x214C3DC")]
		public static Offset<ConsumeLifeResponse> EndConsumeLifeResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ConsumeLifeResponse>);
		}

		// Token: 0x0400E671 RID: 58993
		[Token(Token = "0x400E671")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
