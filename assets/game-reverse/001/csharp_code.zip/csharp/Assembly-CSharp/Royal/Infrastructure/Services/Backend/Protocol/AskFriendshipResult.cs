﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002340 RID: 9024
	[Token(Token = "0x2002340")]
	public enum AskFriendshipResult : sbyte
	{
		// Token: 0x0400E622 RID: 58914
		[Token(Token = "0x400E622")]
		Success,
		// Token: 0x0400E623 RID: 58915
		[Token(Token = "0x400E623")]
		AlreadyRequested,
		// Token: 0x0400E624 RID: 58916
		[Token(Token = "0x400E624")]
		FriendOrRequestLimitExceeded
	}
}
