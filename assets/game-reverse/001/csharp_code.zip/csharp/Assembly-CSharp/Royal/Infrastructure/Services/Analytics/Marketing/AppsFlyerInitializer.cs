﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics.Marketing
{
	// Token: 0x020025A2 RID: 9634
	[Token(Token = "0x20025A2")]
	public static class AppsFlyerInitializer
	{
		// Token: 0x06012D5B RID: 77147 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D5B")]
		[Address(RVA = "0x243AAE8", Offset = "0x243AAE8", VA = "0x243AAE8")]
		public static void Initialize()
		{
		}

		// Token: 0x06012D5C RID: 77148 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D5C")]
		[Address(RVA = "0x243AC20", Offset = "0x243AC20", VA = "0x243AC20")]
		public static void Start()
		{
		}

		// Token: 0x06012D5D RID: 77149 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D5D")]
		[Address(RVA = "0x243B134", Offset = "0x243B134", VA = "0x243B134")]
		private static void AppTrackingRequestCallback(object sender, EventArgs e)
		{
		}

		// Token: 0x06012D5E RID: 77150 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D5E")]
		[Address(RVA = "0x243B074", Offset = "0x243B074", VA = "0x243B074")]
		private static void TryInitializeConsentData()
		{
		}

		// Token: 0x06012D5F RID: 77151 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D5F")]
		[Address(RVA = "0x243B388", Offset = "0x243B388", VA = "0x243B388")]
		public static void InitializeConsentDataForEligible()
		{
		}

		// Token: 0x0400ED31 RID: 60721
		[Token(Token = "0x400ED31")]
		private const string DevKey = "B27HnbGEcbWC2fv79DDhcb";

		// Token: 0x0400ED32 RID: 60722
		[Token(Token = "0x400ED32")]
		private const string AppID = "1482155847";
	}
}
