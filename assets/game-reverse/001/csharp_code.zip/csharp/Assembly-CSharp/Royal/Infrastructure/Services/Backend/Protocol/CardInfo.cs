﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200234F RID: 9039
	[Token(Token = "0x200234F")]
	public struct CardInfo : IFlatbufferObject
	{
		// Token: 0x17001F00 RID: 7936
		// (get) Token: 0x06010C6D RID: 68717 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F00")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C6D")]
			[Address(RVA = "0x2146668", Offset = "0x2146668", VA = "0x2146668", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C6E RID: 68718 RVA: 0x00060A68 File Offset: 0x0005EC68
		[Token(Token = "0x6010C6E")]
		[Address(RVA = "0x2146670", Offset = "0x2146670", VA = "0x2146670")]
		public static CardInfo GetRootAsCardInfo(ByteBuffer _bb)
		{
			return default(CardInfo);
		}

		// Token: 0x06010C6F RID: 68719 RVA: 0x00060A80 File Offset: 0x0005EC80
		[Token(Token = "0x6010C6F")]
		[Address(RVA = "0x214667C", Offset = "0x214667C", VA = "0x214667C")]
		public static CardInfo GetRootAsCardInfo(ByteBuffer _bb, CardInfo obj)
		{
			return default(CardInfo);
		}

		// Token: 0x06010C70 RID: 68720 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C70")]
		[Address(RVA = "0x21466F4", Offset = "0x21466F4", VA = "0x21466F4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C71 RID: 68721 RVA: 0x00060A98 File Offset: 0x0005EC98
		[Token(Token = "0x6010C71")]
		[Address(RVA = "0x2143ED0", Offset = "0x2143ED0", VA = "0x2143ED0")]
		public CardInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(CardInfo);
		}

		// Token: 0x17001F01 RID: 7937
		// (get) Token: 0x06010C72 RID: 68722 RVA: 0x00060AB0 File Offset: 0x0005ECB0
		[Token(Token = "0x17001F01")]
		public int CardId
		{
			[Token(Token = "0x6010C72")]
			[Address(RVA = "0x2146704", Offset = "0x2146704", VA = "0x2146704")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F02 RID: 7938
		// (get) Token: 0x06010C73 RID: 68723 RVA: 0x00060AC8 File Offset: 0x0005ECC8
		[Token(Token = "0x17001F02")]
		public int SetId
		{
			[Token(Token = "0x6010C73")]
			[Address(RVA = "0x2146748", Offset = "0x2146748", VA = "0x2146748")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010C74 RID: 68724 RVA: 0x00060AE0 File Offset: 0x0005ECE0
		[Token(Token = "0x6010C74")]
		[Address(RVA = "0x214678C", Offset = "0x214678C", VA = "0x214678C")]
		public static Offset<CardInfo> CreateCardInfo(FlatBufferBuilder builder, int card_id = 0, int set_id = 0)
		{
			return default(Offset<CardInfo>);
		}

		// Token: 0x06010C75 RID: 68725 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C75")]
		[Address(RVA = "0x2146890", Offset = "0x2146890", VA = "0x2146890")]
		public static void StartCardInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C76 RID: 68726 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C76")]
		[Address(RVA = "0x2146804", Offset = "0x2146804", VA = "0x2146804")]
		public static void AddCardId(FlatBufferBuilder builder, int cardId)
		{
		}

		// Token: 0x06010C77 RID: 68727 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C77")]
		[Address(RVA = "0x21467E4", Offset = "0x21467E4", VA = "0x21467E4")]
		public static void AddSetId(FlatBufferBuilder builder, int setId)
		{
		}

		// Token: 0x06010C78 RID: 68728 RVA: 0x00060AF8 File Offset: 0x0005ECF8
		[Token(Token = "0x6010C78")]
		[Address(RVA = "0x2146824", Offset = "0x2146824", VA = "0x2146824")]
		public static Offset<CardInfo> EndCardInfo(FlatBufferBuilder builder)
		{
			return default(Offset<CardInfo>);
		}

		// Token: 0x0400E63E RID: 58942
		[Token(Token = "0x400E63E")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
