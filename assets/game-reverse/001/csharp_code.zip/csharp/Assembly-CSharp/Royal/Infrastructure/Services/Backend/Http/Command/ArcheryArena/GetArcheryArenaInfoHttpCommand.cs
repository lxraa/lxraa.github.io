﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.ArcheryArena
{
	// Token: 0x02002578 RID: 9592
	[Token(Token = "0x2002578")]
	public class GetArcheryArenaInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027BB RID: 10171
		// (get) Token: 0x06012BC4 RID: 76740 RVA: 0x000794B8 File Offset: 0x000776B8
		[Token(Token = "0x170027BB")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012BC4")]
			[Address(RVA = "0x1ED52D8", Offset = "0x1ED52D8", VA = "0x1ED52D8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027BC RID: 10172
		// (get) Token: 0x06012BC5 RID: 76741 RVA: 0x000794D0 File Offset: 0x000776D0
		[Token(Token = "0x170027BC")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012BC5")]
			[Address(RVA = "0x1ED52E0", Offset = "0x1ED52E0", VA = "0x1ED52E0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170027BD RID: 10173
		// (get) Token: 0x06012BC6 RID: 76742 RVA: 0x000794E8 File Offset: 0x000776E8
		// (set) Token: 0x06012BC7 RID: 76743 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027BD")]
		private GetArcheryArenaInfoResponse Response
		{
			[Token(Token = "0x6012BC6")]
			[Address(RVA = "0x1ED52E8", Offset = "0x1ED52E8", VA = "0x1ED52E8")]
			get
			{
				return default(GetArcheryArenaInfoResponse);
			}
			[Token(Token = "0x6012BC7")]
			[Address(RVA = "0x1ED52F4", Offset = "0x1ED52F4", VA = "0x1ED52F4")]
			set
			{
			}
		}

		// Token: 0x06012BC8 RID: 76744 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BC8")]
		[Address(RVA = "0x1ED5304", Offset = "0x1ED5304", VA = "0x1ED5304")]
		public GetArcheryArenaInfoHttpCommand(long groupId, int configVersion, LeaderboardInfoType infoType, bool fromRefresh, int eventId)
		{
		}

		// Token: 0x06012BC9 RID: 76745 RVA: 0x00079500 File Offset: 0x00077700
		[Token(Token = "0x6012BC9")]
		[Address(RVA = "0x1ED5364", Offset = "0x1ED5364", VA = "0x1ED5364", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012BCA RID: 76746 RVA: 0x00079518 File Offset: 0x00077718
		[Token(Token = "0x6012BCA")]
		[Address(RVA = "0x1ED5454", Offset = "0x1ED5454", VA = "0x1ED5454", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BCB RID: 76747 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BCB")]
		[Address(RVA = "0x1ED5744", Offset = "0x1ED5744", VA = "0x1ED5744", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BCC RID: 76748 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BCC")]
		[Address(RVA = "0x1ED5B40", Offset = "0x1ED5B40", VA = "0x1ED5B40", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EC06 RID: 60422
		[Token(Token = "0x400EC06")]
		[FieldOffset(Offset = "0x18")]
		private GetArcheryArenaInfoResponse <Response>k__BackingField;

		// Token: 0x0400EC07 RID: 60423
		[Token(Token = "0x400EC07")]
		[FieldOffset(Offset = "0x28")]
		private readonly long groupId;

		// Token: 0x0400EC08 RID: 60424
		[Token(Token = "0x400EC08")]
		[FieldOffset(Offset = "0x30")]
		private readonly int configVersion;

		// Token: 0x0400EC09 RID: 60425
		[Token(Token = "0x400EC09")]
		[FieldOffset(Offset = "0x34")]
		private readonly LeaderboardInfoType infoType;

		// Token: 0x0400EC0A RID: 60426
		[Token(Token = "0x400EC0A")]
		[FieldOffset(Offset = "0x35")]
		private readonly bool fromRefresh;

		// Token: 0x0400EC0B RID: 60427
		[Token(Token = "0x400EC0B")]
		[FieldOffset(Offset = "0x38")]
		private readonly int eventId;
	}
}
