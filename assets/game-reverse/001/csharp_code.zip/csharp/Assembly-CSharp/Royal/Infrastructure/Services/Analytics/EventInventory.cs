﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002596 RID: 9622
	[Token(Token = "0x2002596")]
	public class EventInventory
	{
		// Token: 0x06012D4E RID: 77134 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D4E")]
		[Address(RVA = "0x243A9FC", Offset = "0x243A9FC", VA = "0x243A9FC")]
		public EventInventory()
		{
		}

		// Token: 0x0400ECDA RID: 60634
		[Token(Token = "0x400ECDA")]
		[FieldOffset(Offset = "0x10")]
		public int pickaxe;

		// Token: 0x0400ECDB RID: 60635
		[Token(Token = "0x400ECDB")]
		[FieldOffset(Offset = "0x14")]
		public int elixir;
	}
}
