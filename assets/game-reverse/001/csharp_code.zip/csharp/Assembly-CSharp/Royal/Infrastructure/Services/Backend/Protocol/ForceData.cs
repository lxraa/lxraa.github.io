﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B6 RID: 9142
	[Token(Token = "0x20023B6")]
	public struct ForceData : IFlatbufferObject
	{
		// Token: 0x1700208F RID: 8335
		// (get) Token: 0x06011226 RID: 70182 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700208F")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011226")]
			[Address(RVA = "0x1CA9938", Offset = "0x1CA9938", VA = "0x1CA9938", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011227 RID: 70183 RVA: 0x00065550 File Offset: 0x00063750
		[Token(Token = "0x6011227")]
		[Address(RVA = "0x1CA9940", Offset = "0x1CA9940", VA = "0x1CA9940")]
		public static ForceData GetRootAsForceData(ByteBuffer _bb)
		{
			return default(ForceData);
		}

		// Token: 0x06011228 RID: 70184 RVA: 0x00065568 File Offset: 0x00063768
		[Token(Token = "0x6011228")]
		[Address(RVA = "0x1CA994C", Offset = "0x1CA994C", VA = "0x1CA994C")]
		public static ForceData GetRootAsForceData(ByteBuffer _bb, ForceData obj)
		{
			return default(ForceData);
		}

		// Token: 0x06011229 RID: 70185 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011229")]
		[Address(RVA = "0x1CA99FC", Offset = "0x1CA99FC", VA = "0x1CA99FC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601122A RID: 70186 RVA: 0x00065580 File Offset: 0x00063780
		[Token(Token = "0x601122A")]
		[Address(RVA = "0x1CA99C4", Offset = "0x1CA99C4", VA = "0x1CA99C4")]
		public ForceData __assign(int _i, ByteBuffer _bb)
		{
			return default(ForceData);
		}

		// Token: 0x17002090 RID: 8336
		// (get) Token: 0x0601122B RID: 70187 RVA: 0x00065598 File Offset: 0x00063798
		[Token(Token = "0x17002090")]
		public int ForceLeagueScore
		{
			[Token(Token = "0x601122B")]
			[Address(RVA = "0x1CA9A0C", Offset = "0x1CA9A0C", VA = "0x1CA9A0C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002091 RID: 8337
		// (get) Token: 0x0601122C RID: 70188 RVA: 0x000655B0 File Offset: 0x000637B0
		[Token(Token = "0x17002091")]
		public int ForceKingsCupScore
		{
			[Token(Token = "0x601122C")]
			[Address(RVA = "0x1CA9A50", Offset = "0x1CA9A50", VA = "0x1CA9A50")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002092 RID: 8338
		// (get) Token: 0x0601122D RID: 70189 RVA: 0x000655C8 File Offset: 0x000637C8
		[Token(Token = "0x17002092")]
		public int ForceTeamBattleScore
		{
			[Token(Token = "0x601122D")]
			[Address(RVA = "0x1CA9A94", Offset = "0x1CA9A94", VA = "0x1CA9A94")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601122E RID: 70190 RVA: 0x000655E0 File Offset: 0x000637E0
		[Token(Token = "0x601122E")]
		[Address(RVA = "0x1CA9AD8", Offset = "0x1CA9AD8", VA = "0x1CA9AD8")]
		public static Offset<ForceData> CreateForceData(FlatBufferBuilder builder, int forceLeagueScore = 0, int forceKingsCupScore = 0, int forceTeamBattleScore = 0)
		{
			return default(Offset<ForceData>);
		}

		// Token: 0x0601122F RID: 70191 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601122F")]
		[Address(RVA = "0x1CA9C14", Offset = "0x1CA9C14", VA = "0x1CA9C14")]
		public static void StartForceData(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011230 RID: 70192 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011230")]
		[Address(RVA = "0x1CA9B88", Offset = "0x1CA9B88", VA = "0x1CA9B88")]
		public static void AddForceLeagueScore(FlatBufferBuilder builder, int forceLeagueScore)
		{
		}

		// Token: 0x06011231 RID: 70193 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011231")]
		[Address(RVA = "0x1CA9B68", Offset = "0x1CA9B68", VA = "0x1CA9B68")]
		public static void AddForceKingsCupScore(FlatBufferBuilder builder, int forceKingsCupScore)
		{
		}

		// Token: 0x06011232 RID: 70194 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011232")]
		[Address(RVA = "0x1CA9B48", Offset = "0x1CA9B48", VA = "0x1CA9B48")]
		public static void AddForceTeamBattleScore(FlatBufferBuilder builder, int forceTeamBattleScore)
		{
		}

		// Token: 0x06011233 RID: 70195 RVA: 0x000655F8 File Offset: 0x000637F8
		[Token(Token = "0x6011233")]
		[Address(RVA = "0x1CA9BA8", Offset = "0x1CA9BA8", VA = "0x1CA9BA8")]
		public static Offset<ForceData> EndForceData(FlatBufferBuilder builder)
		{
			return default(Offset<ForceData>);
		}

		// Token: 0x0400E6ED RID: 59117
		[Token(Token = "0x400E6ED")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
