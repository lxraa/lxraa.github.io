﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Infrastructure.Services.Native.Purchase;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x0200251B RID: 9499
	[Token(Token = "0x200251B")]
	public class PurchaseVerificationHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026E0 RID: 9952
		// (get) Token: 0x0601291A RID: 76058 RVA: 0x00077688 File Offset: 0x00075888
		[Token(Token = "0x170026E0")]
		public override RequestType RequestType
		{
			[Token(Token = "0x601291A")]
			[Address(RVA = "0x1CF03CC", Offset = "0x1CF03CC", VA = "0x1CF03CC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026E1 RID: 9953
		// (get) Token: 0x0601291B RID: 76059 RVA: 0x000776A0 File Offset: 0x000758A0
		[Token(Token = "0x170026E1")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x601291B")]
			[Address(RVA = "0x1CF03D4", Offset = "0x1CF03D4", VA = "0x1CF03D4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026E2 RID: 9954
		// (get) Token: 0x0601291C RID: 76060 RVA: 0x000776B8 File Offset: 0x000758B8
		// (set) Token: 0x0601291D RID: 76061 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026E2")]
		public PurchaseVerificationResponse Response
		{
			[Token(Token = "0x601291C")]
			[Address(RVA = "0x1CF03DC", Offset = "0x1CF03DC", VA = "0x1CF03DC")]
			get
			{
				return default(PurchaseVerificationResponse);
			}
			[Token(Token = "0x601291D")]
			[Address(RVA = "0x1CF03E8", Offset = "0x1CF03E8", VA = "0x1CF03E8")]
			private set
			{
			}
		}

		// Token: 0x0601291E RID: 76062 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601291E")]
		[Address(RVA = "0x1CF03F8", Offset = "0x1CF03F8", VA = "0x1CF03F8")]
		public PurchaseVerificationHttpCommand(TransactionInfo transactionInfo)
		{
		}

		// Token: 0x0601291F RID: 76063 RVA: 0x000776D0 File Offset: 0x000758D0
		[Token(Token = "0x601291F")]
		[Address(RVA = "0x1CF0450", Offset = "0x1CF0450", VA = "0x1CF0450", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012920 RID: 76064 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012920")]
		[Address(RVA = "0x1CF0548", Offset = "0x1CF0548", VA = "0x1CF0548", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012921 RID: 76065 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012921")]
		[Address(RVA = "0x1CF0688", Offset = "0x1CF0688", VA = "0x1CF0688", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EAEC RID: 60140
		[Token(Token = "0x400EAEC")]
		[FieldOffset(Offset = "0x18")]
		private PurchaseVerificationResponse <Response>k__BackingField;

		// Token: 0x0400EAED RID: 60141
		[Token(Token = "0x400EAED")]
		[FieldOffset(Offset = "0x28")]
		public readonly string productId;

		// Token: 0x0400EAEE RID: 60142
		[Token(Token = "0x400EAEE")]
		[FieldOffset(Offset = "0x30")]
		public readonly string transactionId;

		// Token: 0x0400EAEF RID: 60143
		[Token(Token = "0x400EAEF")]
		[FieldOffset(Offset = "0x38")]
		private readonly string receipt;
	}
}
