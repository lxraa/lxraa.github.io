﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SkyRace
{
	// Token: 0x0200254B RID: 9547
	[Token(Token = "0x200254B")]
	public class GetSkyRaceInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002756 RID: 10070
		// (get) Token: 0x06012A9A RID: 76442 RVA: 0x00078678 File Offset: 0x00076878
		[Token(Token = "0x17002756")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A9A")]
			[Address(RVA = "0x1ECC0C4", Offset = "0x1ECC0C4", VA = "0x1ECC0C4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002757 RID: 10071
		// (get) Token: 0x06012A9B RID: 76443 RVA: 0x00078690 File Offset: 0x00076890
		[Token(Token = "0x17002757")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A9B")]
			[Address(RVA = "0x1ECC0CC", Offset = "0x1ECC0CC", VA = "0x1ECC0CC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002758 RID: 10072
		// (get) Token: 0x06012A9C RID: 76444 RVA: 0x000786A8 File Offset: 0x000768A8
		// (set) Token: 0x06012A9D RID: 76445 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002758")]
		public GetSkyRaceInfoResponse Response
		{
			[Token(Token = "0x6012A9C")]
			[Address(RVA = "0x1ECC0D4", Offset = "0x1ECC0D4", VA = "0x1ECC0D4")]
			get
			{
				return default(GetSkyRaceInfoResponse);
			}
			[Token(Token = "0x6012A9D")]
			[Address(RVA = "0x1ECC0E0", Offset = "0x1ECC0E0", VA = "0x1ECC0E0")]
			set
			{
			}
		}

		// Token: 0x06012A9E RID: 76446 RVA: 0x000786C0 File Offset: 0x000768C0
		[Token(Token = "0x6012A9E")]
		[Address(RVA = "0x1ECC0F0", Offset = "0x1ECC0F0", VA = "0x1ECC0F0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A9F RID: 76447 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A9F")]
		[Address(RVA = "0x1ECC1A0", Offset = "0x1ECC1A0", VA = "0x1ECC1A0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AA0 RID: 76448 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AA0")]
		[Address(RVA = "0x1ECC318", Offset = "0x1ECC318", VA = "0x1ECC318", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012AA1 RID: 76449 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AA1")]
		[Address(RVA = "0x1ECC31C", Offset = "0x1ECC31C", VA = "0x1ECC31C")]
		public GetSkyRaceInfoHttpCommand()
		{
		}

		// Token: 0x0400EB84 RID: 60292
		[Token(Token = "0x400EB84")]
		[FieldOffset(Offset = "0x18")]
		private GetSkyRaceInfoResponse <Response>k__BackingField;
	}
}
