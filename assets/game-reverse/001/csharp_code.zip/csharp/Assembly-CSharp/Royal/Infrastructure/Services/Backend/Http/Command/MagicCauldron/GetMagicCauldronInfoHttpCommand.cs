﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.MagicCauldron
{
	// Token: 0x02002559 RID: 9561
	[Token(Token = "0x2002559")]
	public class GetMagicCauldronInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002773 RID: 10099
		// (get) Token: 0x06012AF4 RID: 76532 RVA: 0x00078AE0 File Offset: 0x00076CE0
		[Token(Token = "0x17002773")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AF4")]
			[Address(RVA = "0x1ECE7A0", Offset = "0x1ECE7A0", VA = "0x1ECE7A0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002774 RID: 10100
		// (get) Token: 0x06012AF5 RID: 76533 RVA: 0x00078AF8 File Offset: 0x00076CF8
		[Token(Token = "0x17002774")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AF5")]
			[Address(RVA = "0x1ECE7A8", Offset = "0x1ECE7A8", VA = "0x1ECE7A8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AF6 RID: 76534 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AF6")]
		[Address(RVA = "0x1ECE7B0", Offset = "0x1ECE7B0", VA = "0x1ECE7B0")]
		public GetMagicCauldronInfoHttpCommand(int eventId)
		{
		}

		// Token: 0x06012AF7 RID: 76535 RVA: 0x00078B10 File Offset: 0x00076D10
		[Token(Token = "0x6012AF7")]
		[Address(RVA = "0x1ECE7E0", Offset = "0x1ECE7E0", VA = "0x1ECE7E0", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012AF8 RID: 76536 RVA: 0x00078B28 File Offset: 0x00076D28
		[Token(Token = "0x6012AF8")]
		[Address(RVA = "0x1ECE8A0", Offset = "0x1ECE8A0", VA = "0x1ECE8A0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AF9 RID: 76537 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AF9")]
		[Address(RVA = "0x1ECE8C0", Offset = "0x1ECE8C0", VA = "0x1ECE8C0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AFA RID: 76538 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AFA")]
		[Address(RVA = "0x1ECE998", Offset = "0x1ECE998", VA = "0x1ECE998", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBB0 RID: 60336
		[Token(Token = "0x400EBB0")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;
	}
}
