﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023AB RID: 9131
	[Token(Token = "0x20023AB")]
	public struct EnterSpaceMissionRequest : IFlatbufferObject
	{
		// Token: 0x17002066 RID: 8294
		// (get) Token: 0x06011186 RID: 70022 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002066")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011186")]
			[Address(RVA = "0x1F9F03C", Offset = "0x1F9F03C", VA = "0x1F9F03C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011187 RID: 70023 RVA: 0x00064CC8 File Offset: 0x00062EC8
		[Token(Token = "0x6011187")]
		[Address(RVA = "0x1F9F044", Offset = "0x1F9F044", VA = "0x1F9F044")]
		public static EnterSpaceMissionRequest GetRootAsEnterSpaceMissionRequest(ByteBuffer _bb)
		{
			return default(EnterSpaceMissionRequest);
		}

		// Token: 0x06011188 RID: 70024 RVA: 0x00064CE0 File Offset: 0x00062EE0
		[Token(Token = "0x6011188")]
		[Address(RVA = "0x1F9F050", Offset = "0x1F9F050", VA = "0x1F9F050")]
		public static EnterSpaceMissionRequest GetRootAsEnterSpaceMissionRequest(ByteBuffer _bb, EnterSpaceMissionRequest obj)
		{
			return default(EnterSpaceMissionRequest);
		}

		// Token: 0x06011189 RID: 70025 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011189")]
		[Address(RVA = "0x1F9F100", Offset = "0x1F9F100", VA = "0x1F9F100", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601118A RID: 70026 RVA: 0x00064CF8 File Offset: 0x00062EF8
		[Token(Token = "0x601118A")]
		[Address(RVA = "0x1F9F0C8", Offset = "0x1F9F0C8", VA = "0x1F9F0C8")]
		public EnterSpaceMissionRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterSpaceMissionRequest);
		}

		// Token: 0x17002067 RID: 8295
		// (get) Token: 0x0601118B RID: 70027 RVA: 0x00064D10 File Offset: 0x00062F10
		[Token(Token = "0x17002067")]
		public int Level
		{
			[Token(Token = "0x601118B")]
			[Address(RVA = "0x1F9F110", Offset = "0x1F9F110", VA = "0x1F9F110")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002068 RID: 8296
		// (get) Token: 0x0601118C RID: 70028 RVA: 0x00064D28 File Offset: 0x00062F28
		[Token(Token = "0x17002068")]
		public int Step
		{
			[Token(Token = "0x601118C")]
			[Address(RVA = "0x1F9F154", Offset = "0x1F9F154", VA = "0x1F9F154")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002069 RID: 8297
		// (get) Token: 0x0601118D RID: 70029 RVA: 0x00064D40 File Offset: 0x00062F40
		[Token(Token = "0x17002069")]
		public int SpaceMissionConfigVersion
		{
			[Token(Token = "0x601118D")]
			[Address(RVA = "0x1F9F198", Offset = "0x1F9F198", VA = "0x1F9F198")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601118E RID: 70030 RVA: 0x00064D58 File Offset: 0x00062F58
		[Token(Token = "0x601118E")]
		[Address(RVA = "0x1F9F1DC", Offset = "0x1F9F1DC", VA = "0x1F9F1DC")]
		public static Offset<EnterSpaceMissionRequest> CreateEnterSpaceMissionRequest(FlatBufferBuilder builder, int level = 0, int step = 0, int space_mission_config_version = 0)
		{
			return default(Offset<EnterSpaceMissionRequest>);
		}

		// Token: 0x0601118F RID: 70031 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601118F")]
		[Address(RVA = "0x1F9F318", Offset = "0x1F9F318", VA = "0x1F9F318")]
		public static void StartEnterSpaceMissionRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011190 RID: 70032 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011190")]
		[Address(RVA = "0x1F9F28C", Offset = "0x1F9F28C", VA = "0x1F9F28C")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x06011191 RID: 70033 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011191")]
		[Address(RVA = "0x1F9F26C", Offset = "0x1F9F26C", VA = "0x1F9F26C")]
		public static void AddStep(FlatBufferBuilder builder, int step)
		{
		}

		// Token: 0x06011192 RID: 70034 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011192")]
		[Address(RVA = "0x1F9F24C", Offset = "0x1F9F24C", VA = "0x1F9F24C")]
		public static void AddSpaceMissionConfigVersion(FlatBufferBuilder builder, int spaceMissionConfigVersion)
		{
		}

		// Token: 0x06011193 RID: 70035 RVA: 0x00064D70 File Offset: 0x00062F70
		[Token(Token = "0x6011193")]
		[Address(RVA = "0x1F9F2AC", Offset = "0x1F9F2AC", VA = "0x1F9F2AC")]
		public static Offset<EnterSpaceMissionRequest> EndEnterSpaceMissionRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterSpaceMissionRequest>);
		}

		// Token: 0x0400E6DD RID: 59101
		[Token(Token = "0x400E6DD")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
