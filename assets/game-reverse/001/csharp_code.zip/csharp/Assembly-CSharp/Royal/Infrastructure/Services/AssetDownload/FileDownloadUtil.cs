﻿using System;
using System.IO;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Logs;
using Royal.Infrastructure.Services.Remote;
using UnityEngine;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x0200258C RID: 9612
	[Token(Token = "0x200258C")]
	public static class FileDownloadUtil
	{
		// Token: 0x06012C5F RID: 76895 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C5F")]
		[Address(RVA = "0x1ED9F90", Offset = "0x1ED9F90", VA = "0x1ED9F90")]
		public static string GetStreamingAssetsDir()
		{
			return null;
		}

		// Token: 0x06012C60 RID: 76896 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012C60")]
		[Address(RVA = "0x1EDCC9C", Offset = "0x1EDCC9C", VA = "0x1EDCC9C")]
		public static string GetStreamingAssetsOtherPlatformDir()
		{
			return null;
		}

		// Token: 0x06012C61 RID: 76897 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C61")]
		[Address(RVA = "0x1ED7738", Offset = "0x1ED7738", VA = "0x1ED7738")]
		public static void CopyFileFromStreamingAssetsDir(string fileName, string destinationPath)
		{
		}

		// Token: 0x06012C62 RID: 76898 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C62")]
		[Address(RVA = "0x1EDD134", Offset = "0x1EDD134", VA = "0x1EDD134")]
		public static void CopyFileToStreamingAssetsDir(string fileName, string sourcePath)
		{
		}

		// Token: 0x06012C63 RID: 76899 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C63")]
		[Address(RVA = "0x1EDCD18", Offset = "0x1EDCD18", VA = "0x1EDCD18")]
		private static void CopyFile(string sourcePath, string destinationPath)
		{
		}

		// Token: 0x06012C64 RID: 76900 RVA: 0x00079860 File Offset: 0x00077A60
		[Token(Token = "0x6012C64")]
		[Address(RVA = "0x1EDAF7C", Offset = "0x1EDAF7C", VA = "0x1EDAF7C")]
		public static bool IsFileExists(string path)
		{
			return default(bool);
		}

		// Token: 0x06012C65 RID: 76901 RVA: 0x00079878 File Offset: 0x00077A78
		[Token(Token = "0x6012C65")]
		[Address(RVA = "0x1EDB69C", Offset = "0x1EDB69C", VA = "0x1EDB69C")]
		public static bool MoveTempFile(string filePath, string tempPrefix)
		{
			return default(bool);
		}

		// Token: 0x06012C66 RID: 76902 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C66")]
		[Address(RVA = "0x1ED7830", Offset = "0x1ED7830", VA = "0x1ED7830")]
		public static void RemoveFile(string path)
		{
			try
			{
				if (File.Exists(path))
				{
					File.Delete(path);
					Log.Debug(typeof(FileDownloadUtil), LogTag.Download, "File deleted successfully: " + path, new object[0]);
				}
			}
			catch (Exception exception)
			{
				FirebaseHelper.LogException(LogTag.Download, "Failed to delete file: " + path, exception);
			}
		}

		// Token: 0x06012C67 RID: 76903 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012C67")]
		[Address(RVA = "0x1EDD1B0", Offset = "0x1EDD1B0", VA = "0x1EDD1B0")]
		public static void SaveTextureToFile(Texture2D texture, string name, string path)
		{
		}
	}
}
