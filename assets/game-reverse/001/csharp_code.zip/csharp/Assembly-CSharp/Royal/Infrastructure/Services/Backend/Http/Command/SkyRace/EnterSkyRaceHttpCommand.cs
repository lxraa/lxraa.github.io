﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SkyRace
{
	// Token: 0x0200254A RID: 9546
	[Token(Token = "0x200254A")]
	public class EnterSkyRaceHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002753 RID: 10067
		// (get) Token: 0x06012A92 RID: 76434 RVA: 0x00078618 File Offset: 0x00076818
		[Token(Token = "0x17002753")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A92")]
			[Address(RVA = "0x1ECBCF4", Offset = "0x1ECBCF4", VA = "0x1ECBCF4", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002754 RID: 10068
		// (get) Token: 0x06012A93 RID: 76435 RVA: 0x00078630 File Offset: 0x00076830
		[Token(Token = "0x17002754")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A93")]
			[Address(RVA = "0x1ECBCFC", Offset = "0x1ECBCFC", VA = "0x1ECBCFC", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002755 RID: 10069
		// (get) Token: 0x06012A94 RID: 76436 RVA: 0x00078648 File Offset: 0x00076848
		// (set) Token: 0x06012A95 RID: 76437 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002755")]
		public EnterSkyRaceResponse Response
		{
			[Token(Token = "0x6012A94")]
			[Address(RVA = "0x1ECBD04", Offset = "0x1ECBD04", VA = "0x1ECBD04")]
			get
			{
				return default(EnterSkyRaceResponse);
			}
			[Token(Token = "0x6012A95")]
			[Address(RVA = "0x1ECBD10", Offset = "0x1ECBD10", VA = "0x1ECBD10")]
			set
			{
			}
		}

		// Token: 0x06012A96 RID: 76438 RVA: 0x00078660 File Offset: 0x00076860
		[Token(Token = "0x6012A96")]
		[Address(RVA = "0x1ECBD20", Offset = "0x1ECBD20", VA = "0x1ECBD20", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A97 RID: 76439 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A97")]
		[Address(RVA = "0x1ECBDCC", Offset = "0x1ECBDCC", VA = "0x1ECBDCC", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A98 RID: 76440 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A98")]
		[Address(RVA = "0x1ECC0B8", Offset = "0x1ECC0B8", VA = "0x1ECC0B8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012A99 RID: 76441 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A99")]
		[Address(RVA = "0x1ECC0BC", Offset = "0x1ECC0BC", VA = "0x1ECC0BC")]
		public EnterSkyRaceHttpCommand()
		{
		}

		// Token: 0x0400EB83 RID: 60291
		[Token(Token = "0x400EB83")]
		[FieldOffset(Offset = "0x18")]
		private EnterSkyRaceResponse <Response>k__BackingField;
	}
}
