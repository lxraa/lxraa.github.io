﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts
{
	// Token: 0x020025AF RID: 9647
	[Token(Token = "0x20025AF")]
	public interface IContextUnit
	{
		// Token: 0x170027DD RID: 10205
		// (get) Token: 0x06012DB1 RID: 77233
		[Token(Token = "0x170027DD")]
		int Id { [Token(Token = "0x6012DB1")] get; }

		// Token: 0x06012DB2 RID: 77234
		[Token(Token = "0x6012DB2")]
		void Bind();
	}
}
