﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x0200259E RID: 9630
	[Token(Token = "0x200259E")]
	public class SpecialRewardJson
	{
		// Token: 0x06012D56 RID: 77142 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D56")]
		[Address(RVA = "0x243AA3C", Offset = "0x243AA3C", VA = "0x243AA3C")]
		public SpecialRewardJson()
		{
		}

		// Token: 0x0400ED26 RID: 60710
		[Token(Token = "0x400ED26")]
		[FieldOffset(Offset = "0x10")]
		public string type;

		// Token: 0x0400ED27 RID: 60711
		[Token(Token = "0x400ED27")]
		[FieldOffset(Offset = "0x18")]
		public int amount;

		// Token: 0x0400ED28 RID: 60712
		[Token(Token = "0x400ED28")]
		[FieldOffset(Offset = "0x1C")]
		public int inventory;
	}
}
