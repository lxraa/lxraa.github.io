﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023DE RID: 9182
	[Token(Token = "0x20023DE")]
	public struct GetLavaQuestInfoRequest : IFlatbufferObject
	{
		// Token: 0x1700210C RID: 8460
		// (get) Token: 0x06011438 RID: 70712 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700210C")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011438")]
			[Address(RVA = "0x1CB1F88", Offset = "0x1CB1F88", VA = "0x1CB1F88", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011439 RID: 70713 RVA: 0x000671A0 File Offset: 0x000653A0
		[Token(Token = "0x6011439")]
		[Address(RVA = "0x1CB1F90", Offset = "0x1CB1F90", VA = "0x1CB1F90")]
		public static GetLavaQuestInfoRequest GetRootAsGetLavaQuestInfoRequest(ByteBuffer _bb)
		{
			return default(GetLavaQuestInfoRequest);
		}

		// Token: 0x0601143A RID: 70714 RVA: 0x000671B8 File Offset: 0x000653B8
		[Token(Token = "0x601143A")]
		[Address(RVA = "0x1CB1F9C", Offset = "0x1CB1F9C", VA = "0x1CB1F9C")]
		public static GetLavaQuestInfoRequest GetRootAsGetLavaQuestInfoRequest(ByteBuffer _bb, GetLavaQuestInfoRequest obj)
		{
			return default(GetLavaQuestInfoRequest);
		}

		// Token: 0x0601143B RID: 70715 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601143B")]
		[Address(RVA = "0x1CB204C", Offset = "0x1CB204C", VA = "0x1CB204C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601143C RID: 70716 RVA: 0x000671D0 File Offset: 0x000653D0
		[Token(Token = "0x601143C")]
		[Address(RVA = "0x1CB2014", Offset = "0x1CB2014", VA = "0x1CB2014")]
		public GetLavaQuestInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetLavaQuestInfoRequest);
		}

		// Token: 0x1700210D RID: 8461
		// (get) Token: 0x0601143D RID: 70717 RVA: 0x000671E8 File Offset: 0x000653E8
		[Token(Token = "0x1700210D")]
		public int StartLevel
		{
			[Token(Token = "0x601143D")]
			[Address(RVA = "0x1CB205C", Offset = "0x1CB205C", VA = "0x1CB205C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700210E RID: 8462
		// (get) Token: 0x0601143E RID: 70718 RVA: 0x00067200 File Offset: 0x00065400
		[Token(Token = "0x1700210E")]
		public bool IsLeagueLevel
		{
			[Token(Token = "0x601143E")]
			[Address(RVA = "0x1CB20A0", Offset = "0x1CB20A0", VA = "0x1CB20A0")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x1700210F RID: 8463
		// (get) Token: 0x0601143F RID: 70719 RVA: 0x00067218 File Offset: 0x00065418
		[Token(Token = "0x1700210F")]
		public int Scenario
		{
			[Token(Token = "0x601143F")]
			[Address(RVA = "0x1CB20E8", Offset = "0x1CB20E8", VA = "0x1CB20E8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002110 RID: 8464
		// (get) Token: 0x06011440 RID: 70720 RVA: 0x00067230 File Offset: 0x00065430
		[Token(Token = "0x17002110")]
		public int WinnerCount
		{
			[Token(Token = "0x6011440")]
			[Address(RVA = "0x1CB212C", Offset = "0x1CB212C", VA = "0x1CB212C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002111 RID: 8465
		// (get) Token: 0x06011441 RID: 70721 RVA: 0x00067248 File Offset: 0x00065448
		[Token(Token = "0x17002111")]
		public int EventId
		{
			[Token(Token = "0x6011441")]
			[Address(RVA = "0x1CB2170", Offset = "0x1CB2170", VA = "0x1CB2170")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011442 RID: 70722 RVA: 0x00067260 File Offset: 0x00065460
		[Token(Token = "0x6011442")]
		[Address(RVA = "0x1CB21B4", Offset = "0x1CB21B4", VA = "0x1CB21B4")]
		public static Offset<GetLavaQuestInfoRequest> CreateGetLavaQuestInfoRequest(FlatBufferBuilder builder, int start_level = 0, bool is_league_level = false, int scenario = 0, int winner_count = 0, int event_id = 0)
		{
			return default(Offset<GetLavaQuestInfoRequest>);
		}

		// Token: 0x06011443 RID: 70723 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011443")]
		[Address(RVA = "0x1CB2358", Offset = "0x1CB2358", VA = "0x1CB2358")]
		public static void StartGetLavaQuestInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011444 RID: 70724 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011444")]
		[Address(RVA = "0x1CB22AC", Offset = "0x1CB22AC", VA = "0x1CB22AC")]
		public static void AddStartLevel(FlatBufferBuilder builder, int startLevel)
		{
		}

		// Token: 0x06011445 RID: 70725 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011445")]
		[Address(RVA = "0x1CB22CC", Offset = "0x1CB22CC", VA = "0x1CB22CC")]
		public static void AddIsLeagueLevel(FlatBufferBuilder builder, bool isLeagueLevel)
		{
		}

		// Token: 0x06011446 RID: 70726 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011446")]
		[Address(RVA = "0x1CB228C", Offset = "0x1CB228C", VA = "0x1CB228C")]
		public static void AddScenario(FlatBufferBuilder builder, int scenario)
		{
		}

		// Token: 0x06011447 RID: 70727 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011447")]
		[Address(RVA = "0x1CB226C", Offset = "0x1CB226C", VA = "0x1CB226C")]
		public static void AddWinnerCount(FlatBufferBuilder builder, int winnerCount)
		{
		}

		// Token: 0x06011448 RID: 70728 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011448")]
		[Address(RVA = "0x1CB224C", Offset = "0x1CB224C", VA = "0x1CB224C")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x06011449 RID: 70729 RVA: 0x00067278 File Offset: 0x00065478
		[Token(Token = "0x6011449")]
		[Address(RVA = "0x1CB22EC", Offset = "0x1CB22EC", VA = "0x1CB22EC")]
		public static Offset<GetLavaQuestInfoRequest> EndGetLavaQuestInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetLavaQuestInfoRequest>);
		}

		// Token: 0x0400E74E RID: 59214
		[Token(Token = "0x400E74E")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
