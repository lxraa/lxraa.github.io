﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023E2 RID: 9186
	[Token(Token = "0x20023E2")]
	public struct GetLightningRushInfoRequest : IFlatbufferObject
	{
		// Token: 0x1700211E RID: 8478
		// (get) Token: 0x0601147A RID: 70778 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700211E")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601147A")]
			[Address(RVA = "0x1CB3054", Offset = "0x1CB3054", VA = "0x1CB3054", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601147B RID: 70779 RVA: 0x00067518 File Offset: 0x00065718
		[Token(Token = "0x601147B")]
		[Address(RVA = "0x1CB305C", Offset = "0x1CB305C", VA = "0x1CB305C")]
		public static GetLightningRushInfoRequest GetRootAsGetLightningRushInfoRequest(ByteBuffer _bb)
		{
			return default(GetLightningRushInfoRequest);
		}

		// Token: 0x0601147C RID: 70780 RVA: 0x00067530 File Offset: 0x00065730
		[Token(Token = "0x601147C")]
		[Address(RVA = "0x1CB3068", Offset = "0x1CB3068", VA = "0x1CB3068")]
		public static GetLightningRushInfoRequest GetRootAsGetLightningRushInfoRequest(ByteBuffer _bb, GetLightningRushInfoRequest obj)
		{
			return default(GetLightningRushInfoRequest);
		}

		// Token: 0x0601147D RID: 70781 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601147D")]
		[Address(RVA = "0x1CB3118", Offset = "0x1CB3118", VA = "0x1CB3118", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601147E RID: 70782 RVA: 0x00067548 File Offset: 0x00065748
		[Token(Token = "0x601147E")]
		[Address(RVA = "0x1CB30E0", Offset = "0x1CB30E0", VA = "0x1CB30E0")]
		public GetLightningRushInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetLightningRushInfoRequest);
		}

		// Token: 0x1700211F RID: 8479
		// (get) Token: 0x0601147F RID: 70783 RVA: 0x00067560 File Offset: 0x00065760
		[Token(Token = "0x1700211F")]
		public long GroupId
		{
			[Token(Token = "0x601147F")]
			[Address(RVA = "0x1CB3128", Offset = "0x1CB3128", VA = "0x1CB3128")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06011480 RID: 70784 RVA: 0x00067578 File Offset: 0x00065778
		[Token(Token = "0x6011480")]
		[Address(RVA = "0x1CB3170", Offset = "0x1CB3170", VA = "0x1CB3170")]
		public static Offset<GetLightningRushInfoRequest> CreateGetLightningRushInfoRequest(FlatBufferBuilder builder, long group_id = 0L)
		{
			return default(Offset<GetLightningRushInfoRequest>);
		}

		// Token: 0x06011481 RID: 70785 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011481")]
		[Address(RVA = "0x1CB3244", Offset = "0x1CB3244", VA = "0x1CB3244")]
		public static void StartGetLightningRushInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011482 RID: 70786 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011482")]
		[Address(RVA = "0x1CB31B8", Offset = "0x1CB31B8", VA = "0x1CB31B8")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06011483 RID: 70787 RVA: 0x00067590 File Offset: 0x00065790
		[Token(Token = "0x6011483")]
		[Address(RVA = "0x1CB31D8", Offset = "0x1CB31D8", VA = "0x1CB31D8")]
		public static Offset<GetLightningRushInfoRequest> EndGetLightningRushInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetLightningRushInfoRequest>);
		}

		// Token: 0x0400E752 RID: 59218
		[Token(Token = "0x400E752")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
