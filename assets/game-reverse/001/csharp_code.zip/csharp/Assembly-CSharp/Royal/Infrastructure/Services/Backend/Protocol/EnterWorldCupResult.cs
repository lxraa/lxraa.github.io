﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B3 RID: 9139
	[Token(Token = "0x20023B3")]
	public enum EnterWorldCupResult : sbyte
	{
		// Token: 0x0400E6E6 RID: 59110
		[Token(Token = "0x400E6E6")]
		Success,
		// Token: 0x0400E6E7 RID: 59111
		[Token(Token = "0x400E6E7")]
		PreEntered,
		// Token: 0x0400E6E8 RID: 59112
		[Token(Token = "0x400E6E8")]
		AlreadyEntered,
		// Token: 0x0400E6E9 RID: 59113
		[Token(Token = "0x400E6E9")]
		StageClosed,
		// Token: 0x0400E6EA RID: 59114
		[Token(Token = "0x400E6EA")]
		EventClosed
	}
}
