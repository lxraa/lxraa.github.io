﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025C0 RID: 9664
	[Token(Token = "0x20025C0")]
	public class AppTerminationHelper
	{
		// Token: 0x06012E84 RID: 77444 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E84")]
		[Address(RVA = "0x244C1C4", Offset = "0x244C1C4", VA = "0x244C1C4")]
		public void OnStart()
		{
		}

		// Token: 0x06012E85 RID: 77445 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E85")]
		[Address(RVA = "0x244D1D4", Offset = "0x244D1D4", VA = "0x244D1D4")]
		public void OnPause()
		{
		}

		// Token: 0x06012E86 RID: 77446 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E86")]
		[Address(RVA = "0x244D6BC", Offset = "0x244D6BC", VA = "0x244D6BC")]
		public void OnResume()
		{
		}

		// Token: 0x06012E87 RID: 77447 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E87")]
		[Address(RVA = "0x244C98C", Offset = "0x244C98C", VA = "0x244C98C")]
		public void OnQuit()
		{
		}

		// Token: 0x06012E88 RID: 77448 RVA: 0x0007A328 File Offset: 0x00078528
		[Token(Token = "0x6012E88")]
		[Address(RVA = "0x244ED58", Offset = "0x244ED58", VA = "0x244ED58")]
		public static bool IsCrashedInGame()
		{
			return default(bool);
		}

		// Token: 0x06012E89 RID: 77449 RVA: 0x0007A340 File Offset: 0x00078540
		[Token(Token = "0x6012E89")]
		[Address(RVA = "0x244EE58", Offset = "0x244EE58", VA = "0x244EE58")]
		public static bool IsCrashed(out bool isCrashedInGame)
		{
			return default(bool);
		}

		// Token: 0x06012E8A RID: 77450 RVA: 0x0007A358 File Offset: 0x00078558
		[Token(Token = "0x6012E8A")]
		[Address(RVA = "0x244EDB0", Offset = "0x244EDB0", VA = "0x244EDB0")]
		private static int GetCrashedSceneIndex()
		{
			return 0;
		}

		// Token: 0x06012E8B RID: 77451 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012E8B")]
		[Address(RVA = "0x244EF74", Offset = "0x244EF74", VA = "0x244EF74")]
		public static string GetCrashedSceneName()
		{
			return null;
		}

		// Token: 0x06012E8C RID: 77452 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E8C")]
		[Address(RVA = "0x244EB28", Offset = "0x244EB28", VA = "0x244EB28")]
		private void CheckCrash()
		{
		}

		// Token: 0x06012E8D RID: 77453 RVA: 0x0007A370 File Offset: 0x00078570
		[Token(Token = "0x6012E8D")]
		[Address(RVA = "0x244F024", Offset = "0x244F024", VA = "0x244F024")]
		private static int GetLastExitReason()
		{
			return 0;
		}

		// Token: 0x06012E8E RID: 77454 RVA: 0x0007A388 File Offset: 0x00078588
		[Token(Token = "0x6012E8E")]
		[Address(RVA = "0x244F100", Offset = "0x244F100", VA = "0x244F100")]
		private static int GetLastExitReasonForIOS()
		{
			return 0;
		}

		// Token: 0x06012E8F RID: 77455 RVA: 0x0007A3A0 File Offset: 0x000785A0
		[Token(Token = "0x6012E8F")]
		[Address(RVA = "0x244F1CC", Offset = "0x244F1CC", VA = "0x244F1CC")]
		private static bool IsTerminatedDueToLowMemory(int exitReason)
		{
			return default(bool);
		}

		// Token: 0x06012E90 RID: 77456 RVA: 0x0007A3B8 File Offset: 0x000785B8
		[Token(Token = "0x6012E90")]
		[Address(RVA = "0x244EEC0", Offset = "0x244EEC0", VA = "0x244EEC0")]
		private static bool IsAppCrashed(int exitReason)
		{
			return default(bool);
		}

		// Token: 0x06012E91 RID: 77457 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E91")]
		[Address(RVA = "0x244F264", Offset = "0x244F264", VA = "0x244F264")]
		public static void SaveLastSceneIndex()
		{
		}

		// Token: 0x06012E92 RID: 77458 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E92")]
		[Address(RVA = "0x244ED04", Offset = "0x244ED04", VA = "0x244ED04")]
		private static void UpdateAppStatus(int lastStatus)
		{
		}

		// Token: 0x06012E93 RID: 77459 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E93")]
		[Address(RVA = "0x244E9B4", Offset = "0x244E9B4", VA = "0x244E9B4")]
		private static void TrySetLastExitData()
		{
		}

		// Token: 0x06012E94 RID: 77460 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E94")]
		[Address(RVA = "0x244DB78", Offset = "0x244DB78", VA = "0x244DB78")]
		public AppTerminationHelper()
		{
		}

		// Token: 0x0400EE9B RID: 61083
		[Token(Token = "0x400EE9B")]
		private const int NoApp = 0;

		// Token: 0x0400EE9C RID: 61084
		[Token(Token = "0x400EE9C")]
		private const int Background = 1;

		// Token: 0x0400EE9D RID: 61085
		[Token(Token = "0x400EE9D")]
		private const int Foreground = 2;

		// Token: 0x0400EE9E RID: 61086
		[Token(Token = "0x400EE9E")]
		private const int StartScene = 0;

		// Token: 0x0400EE9F RID: 61087
		[Token(Token = "0x400EE9F")]
		private const int ReasonNotDetected = -1;

		// Token: 0x0400EEA0 RID: 61088
		[Token(Token = "0x400EEA0")]
		private const int ReasonUnknown = 0;

		// Token: 0x0400EEA1 RID: 61089
		[Token(Token = "0x400EEA1")]
		private const int ReasonExitSelf = 1;

		// Token: 0x0400EEA2 RID: 61090
		[Token(Token = "0x400EEA2")]
		private const int ReasonLowMemory = 3;

		// Token: 0x0400EEA3 RID: 61091
		[Token(Token = "0x400EEA3")]
		private const int ReasonUserRequested = 10;

		// Token: 0x0400EEA4 RID: 61092
		[Token(Token = "0x400EEA4")]
		private const int ReasonUserStopped = 11;

		// Token: 0x0400EEA5 RID: 61093
		[Token(Token = "0x400EEA5")]
		private const int ReasonOther = 13;

		// Token: 0x0400EEA6 RID: 61094
		[Token(Token = "0x400EEA6")]
		private const int ReasonPackageUpdated = 16;

		// Token: 0x0400EEA7 RID: 61095
		[Token(Token = "0x400EEA7")]
		[FieldOffset(Offset = "0x0")]
		private static int LastAppStatus;

		// Token: 0x0400EEA8 RID: 61096
		[Token(Token = "0x400EEA8")]
		[FieldOffset(Offset = "0x4")]
		private static int LastSceneIndex;

		// Token: 0x0400EEA9 RID: 61097
		[Token(Token = "0x400EEA9")]
		[FieldOffset(Offset = "0x8")]
		private static int LastExitReason;

		// Token: 0x0400EEAA RID: 61098
		[Token(Token = "0x400EEAA")]
		[FieldOffset(Offset = "0xC")]
		private static int BackgroundFetchAmount;

		// Token: 0x0400EEAB RID: 61099
		[Token(Token = "0x400EEAB")]
		[FieldOffset(Offset = "0x10")]
		private static bool FirstTry;
	}
}
