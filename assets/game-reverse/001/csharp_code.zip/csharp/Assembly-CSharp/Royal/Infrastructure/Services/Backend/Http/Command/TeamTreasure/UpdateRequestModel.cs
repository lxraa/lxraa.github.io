﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TeamTreasure
{
	// Token: 0x02002535 RID: 9525
	[Token(Token = "0x2002535")]
	public class UpdateRequestModel
	{
		// Token: 0x060129F6 RID: 76278 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129F6")]
		[Address(RVA = "0x1CFC644", Offset = "0x1CFC644", VA = "0x1CFC644")]
		public UpdateRequestModel()
		{
		}

		// Token: 0x0400EB3D RID: 60221
		[Token(Token = "0x400EB3D")]
		[FieldOffset(Offset = "0x10")]
		public int eventId;

		// Token: 0x0400EB3E RID: 60222
		[Token(Token = "0x400EB3E")]
		[FieldOffset(Offset = "0x14")]
		public int progress;

		// Token: 0x0400EB3F RID: 60223
		[Token(Token = "0x400EB3F")]
		[FieldOffset(Offset = "0x18")]
		public bool isValid;

		// Token: 0x0400EB40 RID: 60224
		[Token(Token = "0x400EB40")]
		[FieldOffset(Offset = "0x19")]
		public bool isClaim;

		// Token: 0x0400EB41 RID: 60225
		[Token(Token = "0x400EB41")]
		[FieldOffset(Offset = "0x1A")]
		public bool isEligible;
	}
}
