﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200237D RID: 9085
	[Token(Token = "0x200237D")]
	public struct DeprecatedAuthenticateResponse : IFlatbufferObject
	{
		// Token: 0x17001FBE RID: 8126
		// (get) Token: 0x06010F05 RID: 69381 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FBE")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F05")]
			[Address(RVA = "0x1F95350", Offset = "0x1F95350", VA = "0x1F95350", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F06 RID: 69382 RVA: 0x00062B68 File Offset: 0x00060D68
		[Token(Token = "0x6010F06")]
		[Address(RVA = "0x1F95358", Offset = "0x1F95358", VA = "0x1F95358")]
		public static DeprecatedAuthenticateResponse GetRootAsDeprecatedAuthenticateResponse(ByteBuffer _bb)
		{
			return default(DeprecatedAuthenticateResponse);
		}

		// Token: 0x06010F07 RID: 69383 RVA: 0x00062B80 File Offset: 0x00060D80
		[Token(Token = "0x6010F07")]
		[Address(RVA = "0x1F95364", Offset = "0x1F95364", VA = "0x1F95364")]
		public static DeprecatedAuthenticateResponse GetRootAsDeprecatedAuthenticateResponse(ByteBuffer _bb, DeprecatedAuthenticateResponse obj)
		{
			return default(DeprecatedAuthenticateResponse);
		}

		// Token: 0x06010F08 RID: 69384 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F08")]
		[Address(RVA = "0x1F95414", Offset = "0x1F95414", VA = "0x1F95414", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F09 RID: 69385 RVA: 0x00062B98 File Offset: 0x00060D98
		[Token(Token = "0x6010F09")]
		[Address(RVA = "0x1F953DC", Offset = "0x1F953DC", VA = "0x1F953DC")]
		public DeprecatedAuthenticateResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(DeprecatedAuthenticateResponse);
		}

		// Token: 0x17001FBF RID: 8127
		// (get) Token: 0x06010F0A RID: 69386 RVA: 0x00062BB0 File Offset: 0x00060DB0
		[Token(Token = "0x17001FBF")]
		public long TeamId
		{
			[Token(Token = "0x6010F0A")]
			[Address(RVA = "0x1F95424", Offset = "0x1F95424", VA = "0x1F95424")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FC0 RID: 8128
		// (get) Token: 0x06010F0B RID: 69387 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FC0")]
		public string TeamName
		{
			[Token(Token = "0x6010F0B")]
			[Address(RVA = "0x1F9546C", Offset = "0x1F9546C", VA = "0x1F9546C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F0C RID: 69388 RVA: 0x00062BC8 File Offset: 0x00060DC8
		[Token(Token = "0x6010F0C")]
		[Address(RVA = "0x1F954A8", Offset = "0x1F954A8", VA = "0x1F954A8")]
		public ArraySegment<byte>? GetTeamNameBytes()
		{
			return null;
		}

		// Token: 0x06010F0D RID: 69389 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010F0D")]
		[Address(RVA = "0x1F954E0", Offset = "0x1F954E0", VA = "0x1F954E0")]
		public byte[] GetTeamNameArray()
		{
			return null;
		}

		// Token: 0x17001FC1 RID: 8129
		// (get) Token: 0x06010F0E RID: 69390 RVA: 0x00062BE0 File Offset: 0x00060DE0
		[Token(Token = "0x17001FC1")]
		public int Logo
		{
			[Token(Token = "0x6010F0E")]
			[Address(RVA = "0x1F9552C", Offset = "0x1F9552C", VA = "0x1F9552C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FC2 RID: 8130
		// (get) Token: 0x06010F0F RID: 69391 RVA: 0x00062BF8 File Offset: 0x00060DF8
		[Token(Token = "0x17001FC2")]
		public long Leader
		{
			[Token(Token = "0x6010F0F")]
			[Address(RVA = "0x1F95570", Offset = "0x1F95570", VA = "0x1F95570")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010F10 RID: 69392 RVA: 0x00062C10 File Offset: 0x00060E10
		[Token(Token = "0x6010F10")]
		[Address(RVA = "0x1F955B8", Offset = "0x1F955B8", VA = "0x1F955B8")]
		public long CoLeaders(int j)
		{
			return 0L;
		}

		// Token: 0x17001FC3 RID: 8131
		// (get) Token: 0x06010F11 RID: 69393 RVA: 0x00062C28 File Offset: 0x00060E28
		[Token(Token = "0x17001FC3")]
		public int CoLeadersLength
		{
			[Token(Token = "0x6010F11")]
			[Address(RVA = "0x1F9561C", Offset = "0x1F9561C", VA = "0x1F9561C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010F12 RID: 69394 RVA: 0x00062C40 File Offset: 0x00060E40
		[Token(Token = "0x6010F12")]
		[Address(RVA = "0x1F95650", Offset = "0x1F95650", VA = "0x1F95650")]
		public ArraySegment<byte>? GetCoLeadersBytes()
		{
			return null;
		}

		// Token: 0x06010F13 RID: 69395 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010F13")]
		[Address(RVA = "0x1F95688", Offset = "0x1F95688", VA = "0x1F95688")]
		public long[] GetCoLeadersArray()
		{
			return null;
		}

		// Token: 0x06010F14 RID: 69396 RVA: 0x00062C58 File Offset: 0x00060E58
		[Token(Token = "0x6010F14")]
		[Address(RVA = "0x1F956D4", Offset = "0x1F956D4", VA = "0x1F956D4")]
		public ChatMessage? Messages(int j)
		{
			return null;
		}

		// Token: 0x17001FC4 RID: 8132
		// (get) Token: 0x06010F15 RID: 69397 RVA: 0x00062C70 File Offset: 0x00060E70
		[Token(Token = "0x17001FC4")]
		public int MessagesLength
		{
			[Token(Token = "0x6010F15")]
			[Address(RVA = "0x1F957AC", Offset = "0x1F957AC", VA = "0x1F957AC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FC5 RID: 8133
		// (get) Token: 0x06010F16 RID: 69398 RVA: 0x00062C88 File Offset: 0x00060E88
		[Token(Token = "0x17001FC5")]
		public long AskLifeRemainingTime
		{
			[Token(Token = "0x6010F16")]
			[Address(RVA = "0x1F957E0", Offset = "0x1F957E0", VA = "0x1F957E0")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010F17 RID: 69399 RVA: 0x00062CA0 File Offset: 0x00060EA0
		[Token(Token = "0x6010F17")]
		[Address(RVA = "0x1F95828", Offset = "0x1F95828", VA = "0x1F95828")]
		public LifeChangeResponse? LifeChanges(int j)
		{
			return null;
		}

		// Token: 0x17001FC6 RID: 8134
		// (get) Token: 0x06010F18 RID: 69400 RVA: 0x00062CB8 File Offset: 0x00060EB8
		[Token(Token = "0x17001FC6")]
		public int LifeChangesLength
		{
			[Token(Token = "0x6010F18")]
			[Address(RVA = "0x1F95900", Offset = "0x1F95900", VA = "0x1F95900")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FC7 RID: 8135
		// (get) Token: 0x06010F19 RID: 69401 RVA: 0x00062CD0 File Offset: 0x00060ED0
		[Token(Token = "0x17001FC7")]
		public int TeamUserCount
		{
			[Token(Token = "0x6010F19")]
			[Address(RVA = "0x1F95934", Offset = "0x1F95934", VA = "0x1F95934")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FC8 RID: 8136
		// (get) Token: 0x06010F1A RID: 69402 RVA: 0x00062CE8 File Offset: 0x00060EE8
		[Token(Token = "0x17001FC8")]
		public long HelpBanRemainingTime
		{
			[Token(Token = "0x6010F1A")]
			[Address(RVA = "0x1F95978", Offset = "0x1F95978", VA = "0x1F95978")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FC9 RID: 8137
		// (get) Token: 0x06010F1B RID: 69403 RVA: 0x00062D00 File Offset: 0x00060F00
		[Token(Token = "0x17001FC9")]
		public long JoinTeamDate
		{
			[Token(Token = "0x6010F1B")]
			[Address(RVA = "0x1F959C0", Offset = "0x1F959C0", VA = "0x1F959C0")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010F1C RID: 69404 RVA: 0x00062D18 File Offset: 0x00060F18
		[Token(Token = "0x6010F1C")]
		[Address(RVA = "0x1F95A08", Offset = "0x1F95A08", VA = "0x1F95A08")]
		public RoyalPassDataResponse? RoyalPassClaims(int j)
		{
			return null;
		}

		// Token: 0x17001FCA RID: 8138
		// (get) Token: 0x06010F1D RID: 69405 RVA: 0x00062D30 File Offset: 0x00060F30
		[Token(Token = "0x17001FCA")]
		public int RoyalPassClaimsLength
		{
			[Token(Token = "0x6010F1D")]
			[Address(RVA = "0x1F95AE0", Offset = "0x1F95AE0", VA = "0x1F95AE0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010F1E RID: 69406 RVA: 0x00062D48 File Offset: 0x00060F48
		[Token(Token = "0x6010F1E")]
		[Address(RVA = "0x1F95B14", Offset = "0x1F95B14", VA = "0x1F95B14")]
		public TeamGiftOfferDataResponse? TeamGiftOfferClaims(int j)
		{
			return null;
		}

		// Token: 0x17001FCB RID: 8139
		// (get) Token: 0x06010F1F RID: 69407 RVA: 0x00062D60 File Offset: 0x00060F60
		[Token(Token = "0x17001FCB")]
		public int TeamGiftOfferClaimsLength
		{
			[Token(Token = "0x6010F1F")]
			[Address(RVA = "0x1F95BEC", Offset = "0x1F95BEC", VA = "0x1F95BEC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010F20 RID: 69408 RVA: 0x00062D78 File Offset: 0x00060F78
		[Token(Token = "0x6010F20")]
		[Address(RVA = "0x1F95C20", Offset = "0x1F95C20", VA = "0x1F95C20")]
		public static Offset<DeprecatedAuthenticateResponse> CreateDeprecatedAuthenticateResponse(FlatBufferBuilder builder, long team_id = 0L, [Optional] StringOffset team_nameOffset, int logo = 0, long leader = 0L, [Optional] VectorOffset co_leadersOffset, [Optional] VectorOffset messagesOffset, long ask_life_remaining_time = 0L, [Optional] VectorOffset life_changesOffset, int team_user_count = 0, long help_ban_remaining_time = 0L, long join_team_date = 0L, [Optional] VectorOffset royal_pass_claimsOffset, [Optional] VectorOffset team_gift_offer_claimsOffset)
		{
			return default(Offset<DeprecatedAuthenticateResponse>);
		}

		// Token: 0x06010F21 RID: 69409 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F21")]
		[Address(RVA = "0x1F95F5C", Offset = "0x1F95F5C", VA = "0x1F95F5C")]
		public static void StartDeprecatedAuthenticateResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F22 RID: 69410 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F22")]
		[Address(RVA = "0x1F95DD0", Offset = "0x1F95DD0", VA = "0x1F95DD0")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x06010F23 RID: 69411 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F23")]
		[Address(RVA = "0x1F95ED0", Offset = "0x1F95ED0", VA = "0x1F95ED0")]
		public static void AddTeamName(FlatBufferBuilder builder, StringOffset teamNameOffset)
		{
		}

		// Token: 0x06010F24 RID: 69412 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F24")]
		[Address(RVA = "0x1F95EB0", Offset = "0x1F95EB0", VA = "0x1F95EB0")]
		public static void AddLogo(FlatBufferBuilder builder, int logo)
		{
		}

		// Token: 0x06010F25 RID: 69413 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F25")]
		[Address(RVA = "0x1F95DB0", Offset = "0x1F95DB0", VA = "0x1F95DB0")]
		public static void AddLeader(FlatBufferBuilder builder, long leader)
		{
		}

		// Token: 0x06010F26 RID: 69414 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F26")]
		[Address(RVA = "0x1F95E90", Offset = "0x1F95E90", VA = "0x1F95E90")]
		public static void AddCoLeaders(FlatBufferBuilder builder, VectorOffset coLeadersOffset)
		{
		}

		// Token: 0x06010F27 RID: 69415 RVA: 0x00062D90 File Offset: 0x00060F90
		[Token(Token = "0x6010F27")]
		[Address(RVA = "0x1F95F74", Offset = "0x1F95F74", VA = "0x1F95F74")]
		public static VectorOffset CreateCoLeadersVector(FlatBufferBuilder builder, long[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F28 RID: 69416 RVA: 0x00062DA8 File Offset: 0x00060FA8
		[Token(Token = "0x6010F28")]
		[Address(RVA = "0x1F9601C", Offset = "0x1F9601C", VA = "0x1F9601C")]
		public static VectorOffset CreateCoLeadersVectorBlock(FlatBufferBuilder builder, long[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F29 RID: 69417 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F29")]
		[Address(RVA = "0x1F960A4", Offset = "0x1F960A4", VA = "0x1F960A4")]
		public static void StartCoLeadersVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010F2A RID: 69418 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F2A")]
		[Address(RVA = "0x1F95E70", Offset = "0x1F95E70", VA = "0x1F95E70")]
		public static void AddMessages(FlatBufferBuilder builder, VectorOffset messagesOffset)
		{
		}

		// Token: 0x06010F2B RID: 69419 RVA: 0x00062DC0 File Offset: 0x00060FC0
		[Token(Token = "0x6010F2B")]
		[Address(RVA = "0x1F960C4", Offset = "0x1F960C4", VA = "0x1F960C4")]
		public static VectorOffset CreateMessagesVector(FlatBufferBuilder builder, Offset<ChatMessage>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F2C RID: 69420 RVA: 0x00062DD8 File Offset: 0x00060FD8
		[Token(Token = "0x6010F2C")]
		[Address(RVA = "0x1F9616C", Offset = "0x1F9616C", VA = "0x1F9616C")]
		public static VectorOffset CreateMessagesVectorBlock(FlatBufferBuilder builder, Offset<ChatMessage>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F2D RID: 69421 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F2D")]
		[Address(RVA = "0x1F961F4", Offset = "0x1F961F4", VA = "0x1F961F4")]
		public static void StartMessagesVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010F2E RID: 69422 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F2E")]
		[Address(RVA = "0x1F95D90", Offset = "0x1F95D90", VA = "0x1F95D90")]
		public static void AddAskLifeRemainingTime(FlatBufferBuilder builder, long askLifeRemainingTime)
		{
		}

		// Token: 0x06010F2F RID: 69423 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F2F")]
		[Address(RVA = "0x1F95E50", Offset = "0x1F95E50", VA = "0x1F95E50")]
		public static void AddLifeChanges(FlatBufferBuilder builder, VectorOffset lifeChangesOffset)
		{
		}

		// Token: 0x06010F30 RID: 69424 RVA: 0x00062DF0 File Offset: 0x00060FF0
		[Token(Token = "0x6010F30")]
		[Address(RVA = "0x1F96214", Offset = "0x1F96214", VA = "0x1F96214")]
		public static VectorOffset CreateLifeChangesVector(FlatBufferBuilder builder, Offset<LifeChangeResponse>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F31 RID: 69425 RVA: 0x00062E08 File Offset: 0x00061008
		[Token(Token = "0x6010F31")]
		[Address(RVA = "0x1F962BC", Offset = "0x1F962BC", VA = "0x1F962BC")]
		public static VectorOffset CreateLifeChangesVectorBlock(FlatBufferBuilder builder, Offset<LifeChangeResponse>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F32 RID: 69426 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F32")]
		[Address(RVA = "0x1F96344", Offset = "0x1F96344", VA = "0x1F96344")]
		public static void StartLifeChangesVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010F33 RID: 69427 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F33")]
		[Address(RVA = "0x1F95E30", Offset = "0x1F95E30", VA = "0x1F95E30")]
		public static void AddTeamUserCount(FlatBufferBuilder builder, int teamUserCount)
		{
		}

		// Token: 0x06010F34 RID: 69428 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F34")]
		[Address(RVA = "0x1F95D70", Offset = "0x1F95D70", VA = "0x1F95D70")]
		public static void AddHelpBanRemainingTime(FlatBufferBuilder builder, long helpBanRemainingTime)
		{
		}

		// Token: 0x06010F35 RID: 69429 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F35")]
		[Address(RVA = "0x1F95D50", Offset = "0x1F95D50", VA = "0x1F95D50")]
		public static void AddJoinTeamDate(FlatBufferBuilder builder, long joinTeamDate)
		{
		}

		// Token: 0x06010F36 RID: 69430 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F36")]
		[Address(RVA = "0x1F95E10", Offset = "0x1F95E10", VA = "0x1F95E10")]
		public static void AddRoyalPassClaims(FlatBufferBuilder builder, VectorOffset royalPassClaimsOffset)
		{
		}

		// Token: 0x06010F37 RID: 69431 RVA: 0x00062E20 File Offset: 0x00061020
		[Token(Token = "0x6010F37")]
		[Address(RVA = "0x1F96364", Offset = "0x1F96364", VA = "0x1F96364")]
		public static VectorOffset CreateRoyalPassClaimsVector(FlatBufferBuilder builder, Offset<RoyalPassDataResponse>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F38 RID: 69432 RVA: 0x00062E38 File Offset: 0x00061038
		[Token(Token = "0x6010F38")]
		[Address(RVA = "0x1F9640C", Offset = "0x1F9640C", VA = "0x1F9640C")]
		public static VectorOffset CreateRoyalPassClaimsVectorBlock(FlatBufferBuilder builder, Offset<RoyalPassDataResponse>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F39 RID: 69433 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F39")]
		[Address(RVA = "0x1F96494", Offset = "0x1F96494", VA = "0x1F96494")]
		public static void StartRoyalPassClaimsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010F3A RID: 69434 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F3A")]
		[Address(RVA = "0x1F95DF0", Offset = "0x1F95DF0", VA = "0x1F95DF0")]
		public static void AddTeamGiftOfferClaims(FlatBufferBuilder builder, VectorOffset teamGiftOfferClaimsOffset)
		{
		}

		// Token: 0x06010F3B RID: 69435 RVA: 0x00062E50 File Offset: 0x00061050
		[Token(Token = "0x6010F3B")]
		[Address(RVA = "0x1F964B4", Offset = "0x1F964B4", VA = "0x1F964B4")]
		public static VectorOffset CreateTeamGiftOfferClaimsVector(FlatBufferBuilder builder, Offset<TeamGiftOfferDataResponse>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F3C RID: 69436 RVA: 0x00062E68 File Offset: 0x00061068
		[Token(Token = "0x6010F3C")]
		[Address(RVA = "0x1F9655C", Offset = "0x1F9655C", VA = "0x1F9655C")]
		public static VectorOffset CreateTeamGiftOfferClaimsVectorBlock(FlatBufferBuilder builder, Offset<TeamGiftOfferDataResponse>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010F3D RID: 69437 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F3D")]
		[Address(RVA = "0x1F965E4", Offset = "0x1F965E4", VA = "0x1F965E4")]
		public static void StartTeamGiftOfferClaimsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010F3E RID: 69438 RVA: 0x00062E80 File Offset: 0x00061080
		[Token(Token = "0x6010F3E")]
		[Address(RVA = "0x1F95EF0", Offset = "0x1F95EF0", VA = "0x1F95EF0")]
		public static Offset<DeprecatedAuthenticateResponse> EndDeprecatedAuthenticateResponse(FlatBufferBuilder builder)
		{
			return default(Offset<DeprecatedAuthenticateResponse>);
		}

		// Token: 0x0400E696 RID: 59030
		[Token(Token = "0x400E696")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
