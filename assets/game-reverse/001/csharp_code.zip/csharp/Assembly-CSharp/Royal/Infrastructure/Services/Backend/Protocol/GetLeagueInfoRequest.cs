﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023E0 RID: 9184
	[Token(Token = "0x20023E0")]
	public struct GetLeagueInfoRequest : IFlatbufferObject
	{
		// Token: 0x17002115 RID: 8469
		// (get) Token: 0x06011458 RID: 70744 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002115")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011458")]
			[Address(RVA = "0x1CB26E0", Offset = "0x1CB26E0", VA = "0x1CB26E0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011459 RID: 70745 RVA: 0x00067338 File Offset: 0x00065538
		[Token(Token = "0x6011459")]
		[Address(RVA = "0x1CB26E8", Offset = "0x1CB26E8", VA = "0x1CB26E8")]
		public static GetLeagueInfoRequest GetRootAsGetLeagueInfoRequest(ByteBuffer _bb)
		{
			return default(GetLeagueInfoRequest);
		}

		// Token: 0x0601145A RID: 70746 RVA: 0x00067350 File Offset: 0x00065550
		[Token(Token = "0x601145A")]
		[Address(RVA = "0x1CB26F4", Offset = "0x1CB26F4", VA = "0x1CB26F4")]
		public static GetLeagueInfoRequest GetRootAsGetLeagueInfoRequest(ByteBuffer _bb, GetLeagueInfoRequest obj)
		{
			return default(GetLeagueInfoRequest);
		}

		// Token: 0x0601145B RID: 70747 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601145B")]
		[Address(RVA = "0x1CB27A4", Offset = "0x1CB27A4", VA = "0x1CB27A4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601145C RID: 70748 RVA: 0x00067368 File Offset: 0x00065568
		[Token(Token = "0x601145C")]
		[Address(RVA = "0x1CB276C", Offset = "0x1CB276C", VA = "0x1CB276C")]
		public GetLeagueInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetLeagueInfoRequest);
		}

		// Token: 0x17002116 RID: 8470
		// (get) Token: 0x0601145D RID: 70749 RVA: 0x00067380 File Offset: 0x00065580
		[Token(Token = "0x17002116")]
		public long GroupId
		{
			[Token(Token = "0x601145D")]
			[Address(RVA = "0x1CB27B4", Offset = "0x1CB27B4", VA = "0x1CB27B4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17002117 RID: 8471
		// (get) Token: 0x0601145E RID: 70750 RVA: 0x00067398 File Offset: 0x00065598
		[Token(Token = "0x17002117")]
		public int ConfigVersion
		{
			[Token(Token = "0x601145E")]
			[Address(RVA = "0x1CB27FC", Offset = "0x1CB27FC", VA = "0x1CB27FC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601145F RID: 70751 RVA: 0x000673B0 File Offset: 0x000655B0
		[Token(Token = "0x601145F")]
		[Address(RVA = "0x1CB2840", Offset = "0x1CB2840", VA = "0x1CB2840")]
		public static Offset<GetLeagueInfoRequest> CreateGetLeagueInfoRequest(FlatBufferBuilder builder, long group_id = 0L, int config_version = 0)
		{
			return default(Offset<GetLeagueInfoRequest>);
		}

		// Token: 0x06011460 RID: 70752 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011460")]
		[Address(RVA = "0x1CB2944", Offset = "0x1CB2944", VA = "0x1CB2944")]
		public static void StartGetLeagueInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011461 RID: 70753 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011461")]
		[Address(RVA = "0x1CB2898", Offset = "0x1CB2898", VA = "0x1CB2898")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06011462 RID: 70754 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011462")]
		[Address(RVA = "0x1CB28B8", Offset = "0x1CB28B8", VA = "0x1CB28B8")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06011463 RID: 70755 RVA: 0x000673C8 File Offset: 0x000655C8
		[Token(Token = "0x6011463")]
		[Address(RVA = "0x1CB28D8", Offset = "0x1CB28D8", VA = "0x1CB28D8")]
		public static Offset<GetLeagueInfoRequest> EndGetLeagueInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetLeagueInfoRequest>);
		}

		// Token: 0x0400E750 RID: 59216
		[Token(Token = "0x400E750")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
