﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023BE RID: 9150
	[Token(Token = "0x20023BE")]
	public enum GameRewardType : sbyte
	{
		// Token: 0x0400E713 RID: 59155
		[Token(Token = "0x400E713")]
		NONE,
		// Token: 0x0400E714 RID: 59156
		[Token(Token = "0x400E714")]
		COIN,
		// Token: 0x0400E715 RID: 59157
		[Token(Token = "0x400E715")]
		UNLIMITED_LIVES,
		// Token: 0x0400E716 RID: 59158
		[Token(Token = "0x400E716")]
		HAMMER,
		// Token: 0x0400E717 RID: 59159
		[Token(Token = "0x400E717")]
		ARROW,
		// Token: 0x0400E718 RID: 59160
		[Token(Token = "0x400E718")]
		CANNON,
		// Token: 0x0400E719 RID: 59161
		[Token(Token = "0x400E719")]
		JESTERHAT,
		// Token: 0x0400E71A RID: 59162
		[Token(Token = "0x400E71A")]
		ROCKET,
		// Token: 0x0400E71B RID: 59163
		[Token(Token = "0x400E71B")]
		TNT,
		// Token: 0x0400E71C RID: 59164
		[Token(Token = "0x400E71C")]
		LIGHTBALL,
		// Token: 0x0400E71D RID: 59165
		[Token(Token = "0x400E71D")]
		UNLIMITED_ROCKET,
		// Token: 0x0400E71E RID: 59166
		[Token(Token = "0x400E71E")]
		UNLIMITED_TNT,
		// Token: 0x0400E71F RID: 59167
		[Token(Token = "0x400E71F")]
		UNLIMITED_LIGHTBALL,
		// Token: 0x0400E720 RID: 59168
		[Token(Token = "0x400E720")]
		MULTIPLIER,
		// Token: 0x0400E721 RID: 59169
		[Token(Token = "0x400E721")]
		COLLECTION_WILD_CARD,
		// Token: 0x0400E722 RID: 59170
		[Token(Token = "0x400E722")]
		COLLECTION_WILD_CARD_TOKEN,
		// Token: 0x0400E723 RID: 59171
		[Token(Token = "0x400E723")]
		COLLECTION_CARD,
		// Token: 0x0400E724 RID: 59172
		[Token(Token = "0x400E724")]
		HIDDEN_TEMPLE_PICKAXE,
		// Token: 0x0400E725 RID: 59173
		[Token(Token = "0x400E725")]
		MAGIC_CAULDRON_ELIXIR,
		// Token: 0x0400E726 RID: 59174
		[Token(Token = "0x400E726")]
		DUKES_FORTUNE_TOKEN,
		// Token: 0x0400E727 RID: 59175
		[Token(Token = "0x400E727")]
		SEASONAL_CARD_PACK_2,
		// Token: 0x0400E728 RID: 59176
		[Token(Token = "0x400E728")]
		SEASONAL_CARD_PACK_3,
		// Token: 0x0400E729 RID: 59177
		[Token(Token = "0x400E729")]
		SEASONAL_CARD_PACK_4,
		// Token: 0x0400E72A RID: 59178
		[Token(Token = "0x400E72A")]
		SEASONAL_CARD_PACK_6,
		// Token: 0x0400E72B RID: 59179
		[Token(Token = "0x400E72B")]
		SEASONAL_CARD_PACK_GUARANTEED
	}
}
