﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x02002595 RID: 9621
	[Token(Token = "0x2002595")]
	public class Inventory2
	{
		// Token: 0x06012D4D RID: 77133 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D4D")]
		[Address(RVA = "0x243A9F4", Offset = "0x243A9F4", VA = "0x243A9F4")]
		public Inventory2()
		{
		}

		// Token: 0x0400ECD4 RID: 60628
		[Token(Token = "0x400ECD4")]
		[FieldOffset(Offset = "0x10")]
		public int lf;

		// Token: 0x0400ECD5 RID: 60629
		[Token(Token = "0x400ECD5")]
		[FieldOffset(Offset = "0x18")]
		public long ulf;

		// Token: 0x0400ECD6 RID: 60630
		[Token(Token = "0x400ECD6")]
		[FieldOffset(Offset = "0x20")]
		public int st;

		// Token: 0x0400ECD7 RID: 60631
		[Token(Token = "0x400ECD7")]
		[FieldOffset(Offset = "0x24")]
		public int il;

		// Token: 0x0400ECD8 RID: 60632
		[Token(Token = "0x400ECD8")]
		[FieldOffset(Offset = "0x28")]
		public int cl;

		// Token: 0x0400ECD9 RID: 60633
		[Token(Token = "0x400ECD9")]
		[FieldOffset(Offset = "0x2C")]
		public int u_mlt_evt;
	}
}
