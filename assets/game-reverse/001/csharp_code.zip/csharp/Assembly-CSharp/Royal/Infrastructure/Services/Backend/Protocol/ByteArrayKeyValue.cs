﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200234C RID: 9036
	[Token(Token = "0x200234C")]
	public struct ByteArrayKeyValue : IFlatbufferObject
	{
		// Token: 0x17001EF6 RID: 7926
		// (get) Token: 0x06010C3D RID: 68669 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EF6")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C3D")]
			[Address(RVA = "0x2145A50", Offset = "0x2145A50", VA = "0x2145A50", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C3E RID: 68670 RVA: 0x000607B0 File Offset: 0x0005E9B0
		[Token(Token = "0x6010C3E")]
		[Address(RVA = "0x2145A58", Offset = "0x2145A58", VA = "0x2145A58")]
		public static ByteArrayKeyValue GetRootAsByteArrayKeyValue(ByteBuffer _bb)
		{
			return default(ByteArrayKeyValue);
		}

		// Token: 0x06010C3F RID: 68671 RVA: 0x000607C8 File Offset: 0x0005E9C8
		[Token(Token = "0x6010C3F")]
		[Address(RVA = "0x2145A64", Offset = "0x2145A64", VA = "0x2145A64")]
		public static ByteArrayKeyValue GetRootAsByteArrayKeyValue(ByteBuffer _bb, ByteArrayKeyValue obj)
		{
			return default(ByteArrayKeyValue);
		}

		// Token: 0x06010C40 RID: 68672 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C40")]
		[Address(RVA = "0x2145B14", Offset = "0x2145B14", VA = "0x2145B14", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C41 RID: 68673 RVA: 0x000607E0 File Offset: 0x0005E9E0
		[Token(Token = "0x6010C41")]
		[Address(RVA = "0x2145ADC", Offset = "0x2145ADC", VA = "0x2145ADC")]
		public ByteArrayKeyValue __assign(int _i, ByteBuffer _bb)
		{
			return default(ByteArrayKeyValue);
		}

		// Token: 0x17001EF7 RID: 7927
		// (get) Token: 0x06010C42 RID: 68674 RVA: 0x000607F8 File Offset: 0x0005E9F8
		[Token(Token = "0x17001EF7")]
		public ByteArrayKeyType Key
		{
			[Token(Token = "0x6010C42")]
			[Address(RVA = "0x2145B24", Offset = "0x2145B24", VA = "0x2145B24")]
			get
			{
				return ByteArrayKeyType.None;
			}
		}

		// Token: 0x06010C43 RID: 68675 RVA: 0x00060810 File Offset: 0x0005EA10
		[Token(Token = "0x6010C43")]
		[Address(RVA = "0x2145B68", Offset = "0x2145B68", VA = "0x2145B68")]
		public sbyte Value(int j)
		{
			return 0;
		}

		// Token: 0x17001EF8 RID: 7928
		// (get) Token: 0x06010C44 RID: 68676 RVA: 0x00060828 File Offset: 0x0005EA28
		[Token(Token = "0x17001EF8")]
		public int ValueLength
		{
			[Token(Token = "0x6010C44")]
			[Address(RVA = "0x2145BC8", Offset = "0x2145BC8", VA = "0x2145BC8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010C45 RID: 68677 RVA: 0x00060840 File Offset: 0x0005EA40
		[Token(Token = "0x6010C45")]
		[Address(RVA = "0x2145BFC", Offset = "0x2145BFC", VA = "0x2145BFC")]
		public ArraySegment<byte>? GetValueBytes()
		{
			return null;
		}

		// Token: 0x06010C46 RID: 68678 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010C46")]
		[Address(RVA = "0x2145C34", Offset = "0x2145C34", VA = "0x2145C34")]
		public sbyte[] GetValueArray()
		{
			return null;
		}

		// Token: 0x06010C47 RID: 68679 RVA: 0x00060858 File Offset: 0x0005EA58
		[Token(Token = "0x6010C47")]
		[Address(RVA = "0x2145C80", Offset = "0x2145C80", VA = "0x2145C80")]
		public static Offset<ByteArrayKeyValue> CreateByteArrayKeyValue(FlatBufferBuilder builder, ByteArrayKeyType key = ByteArrayKeyType.None, [Optional] VectorOffset valueOffset)
		{
			return default(Offset<ByteArrayKeyValue>);
		}

		// Token: 0x06010C48 RID: 68680 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C48")]
		[Address(RVA = "0x2145D84", Offset = "0x2145D84", VA = "0x2145D84")]
		public static void StartByteArrayKeyValue(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C49 RID: 68681 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C49")]
		[Address(RVA = "0x2145CF8", Offset = "0x2145CF8", VA = "0x2145CF8")]
		public static void AddKey(FlatBufferBuilder builder, ByteArrayKeyType key)
		{
		}

		// Token: 0x06010C4A RID: 68682 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C4A")]
		[Address(RVA = "0x2145CD8", Offset = "0x2145CD8", VA = "0x2145CD8")]
		public static void AddValue(FlatBufferBuilder builder, VectorOffset valueOffset)
		{
		}

		// Token: 0x06010C4B RID: 68683 RVA: 0x00060870 File Offset: 0x0005EA70
		[Token(Token = "0x6010C4B")]
		[Address(RVA = "0x2145D9C", Offset = "0x2145D9C", VA = "0x2145D9C")]
		public static VectorOffset CreateValueVector(FlatBufferBuilder builder, sbyte[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010C4C RID: 68684 RVA: 0x00060888 File Offset: 0x0005EA88
		[Token(Token = "0x6010C4C")]
		[Address(RVA = "0x2145E44", Offset = "0x2145E44", VA = "0x2145E44")]
		public static VectorOffset CreateValueVectorBlock(FlatBufferBuilder builder, sbyte[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010C4D RID: 68685 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C4D")]
		[Address(RVA = "0x2145ECC", Offset = "0x2145ECC", VA = "0x2145ECC")]
		public static void StartValueVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010C4E RID: 68686 RVA: 0x000608A0 File Offset: 0x0005EAA0
		[Token(Token = "0x6010C4E")]
		[Address(RVA = "0x2145D18", Offset = "0x2145D18", VA = "0x2145D18")]
		public static Offset<ByteArrayKeyValue> EndByteArrayKeyValue(FlatBufferBuilder builder)
		{
			return default(Offset<ByteArrayKeyValue>);
		}

		// Token: 0x0400E63B RID: 58939
		[Token(Token = "0x400E63B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
