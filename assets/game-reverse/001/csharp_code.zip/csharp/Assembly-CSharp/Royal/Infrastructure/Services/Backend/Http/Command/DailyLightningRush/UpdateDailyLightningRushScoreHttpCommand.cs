﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.DailyLightningRush
{
	// Token: 0x02002574 RID: 9588
	[Token(Token = "0x2002574")]
	public class UpdateDailyLightningRushScoreHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027B2 RID: 10162
		// (get) Token: 0x06012BA9 RID: 76713 RVA: 0x00079368 File Offset: 0x00077568
		[Token(Token = "0x170027B2")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012BA9")]
			[Address(RVA = "0x1ED4800", Offset = "0x1ED4800", VA = "0x1ED4800", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027B3 RID: 10163
		// (get) Token: 0x06012BAA RID: 76714 RVA: 0x00079380 File Offset: 0x00077580
		[Token(Token = "0x170027B3")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012BAA")]
			[Address(RVA = "0x1ED4808", Offset = "0x1ED4808", VA = "0x1ED4808", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012BAB RID: 76715 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BAB")]
		[Address(RVA = "0x1ED4810", Offset = "0x1ED4810", VA = "0x1ED4810")]
		public UpdateDailyLightningRushScoreHttpCommand(long groupId, int score)
		{
		}

		// Token: 0x06012BAC RID: 76716 RVA: 0x00079398 File Offset: 0x00077598
		[Token(Token = "0x6012BAC")]
		[Address(RVA = "0x1ED4840", Offset = "0x1ED4840", VA = "0x1ED4840", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012BAD RID: 76717 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BAD")]
		[Address(RVA = "0x1ED49B4", Offset = "0x1ED49B4", VA = "0x1ED49B4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012BAE RID: 76718 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012BAE")]
		[Address(RVA = "0x1ED49B8", Offset = "0x1ED49B8", VA = "0x1ED49B8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBFE RID: 60414
		[Token(Token = "0x400EBFE")]
		[FieldOffset(Offset = "0x18")]
		private readonly long groupId;

		// Token: 0x0400EBFF RID: 60415
		[Token(Token = "0x400EBFF")]
		[FieldOffset(Offset = "0x20")]
		private readonly int score;

		// Token: 0x0400EC00 RID: 60416
		[Token(Token = "0x400EC00")]
		[FieldOffset(Offset = "0x24")]
		private readonly LeaderboardInfoType infoType;
	}
}
