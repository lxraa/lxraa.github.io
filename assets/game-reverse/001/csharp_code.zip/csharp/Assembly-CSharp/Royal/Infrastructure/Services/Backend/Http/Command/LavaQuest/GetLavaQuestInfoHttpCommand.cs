﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.LavaQuest
{
	// Token: 0x02002563 RID: 9571
	[Token(Token = "0x2002563")]
	public class GetLavaQuestInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700278F RID: 10127
		// (get) Token: 0x06012B42 RID: 76610 RVA: 0x00078E88 File Offset: 0x00077088
		[Token(Token = "0x1700278F")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B42")]
			[Address(RVA = "0x1ED0D98", Offset = "0x1ED0D98", VA = "0x1ED0D98", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002790 RID: 10128
		// (get) Token: 0x06012B43 RID: 76611 RVA: 0x00078EA0 File Offset: 0x000770A0
		[Token(Token = "0x17002790")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B43")]
			[Address(RVA = "0x1ED0DA0", Offset = "0x1ED0DA0", VA = "0x1ED0DA0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002791 RID: 10129
		// (get) Token: 0x06012B44 RID: 76612 RVA: 0x00078EB8 File Offset: 0x000770B8
		// (set) Token: 0x06012B45 RID: 76613 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002791")]
		private GetLavaQuestInfoResponse Response
		{
			[Token(Token = "0x6012B44")]
			[Address(RVA = "0x1ED0DA8", Offset = "0x1ED0DA8", VA = "0x1ED0DA8")]
			get
			{
				return default(GetLavaQuestInfoResponse);
			}
			[Token(Token = "0x6012B45")]
			[Address(RVA = "0x1ED0DB4", Offset = "0x1ED0DB4", VA = "0x1ED0DB4")]
			set
			{
			}
		}

		// Token: 0x06012B46 RID: 76614 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B46")]
		[Address(RVA = "0x1ED0DC4", Offset = "0x1ED0DC4", VA = "0x1ED0DC4")]
		public GetLavaQuestInfoHttpCommand(int startLevel, bool isLeagueLevel, int scenario, int winnerCount, int eventId)
		{
		}

		// Token: 0x06012B47 RID: 76615 RVA: 0x00078ED0 File Offset: 0x000770D0
		[Token(Token = "0x6012B47")]
		[Address(RVA = "0x1ED0E18", Offset = "0x1ED0E18", VA = "0x1ED0E18", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B48 RID: 76616 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B48")]
		[Address(RVA = "0x1ED10F4", Offset = "0x1ED10F4", VA = "0x1ED10F4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B49 RID: 76617 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B49")]
		[Address(RVA = "0x1ED1230", Offset = "0x1ED1230", VA = "0x1ED1230", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBC4 RID: 60356
		[Token(Token = "0x400EBC4")]
		[FieldOffset(Offset = "0x18")]
		private GetLavaQuestInfoResponse <Response>k__BackingField;

		// Token: 0x0400EBC5 RID: 60357
		[Token(Token = "0x400EBC5")]
		[FieldOffset(Offset = "0x28")]
		private readonly int startLevel;

		// Token: 0x0400EBC6 RID: 60358
		[Token(Token = "0x400EBC6")]
		[FieldOffset(Offset = "0x2C")]
		private readonly bool isLeagueLevel;

		// Token: 0x0400EBC7 RID: 60359
		[Token(Token = "0x400EBC7")]
		[FieldOffset(Offset = "0x30")]
		private readonly int scenario;

		// Token: 0x0400EBC8 RID: 60360
		[Token(Token = "0x400EBC8")]
		[FieldOffset(Offset = "0x34")]
		private readonly int winnerCount;

		// Token: 0x0400EBC9 RID: 60361
		[Token(Token = "0x400EBC9")]
		[FieldOffset(Offset = "0x38")]
		private readonly int eventId;
	}
}
