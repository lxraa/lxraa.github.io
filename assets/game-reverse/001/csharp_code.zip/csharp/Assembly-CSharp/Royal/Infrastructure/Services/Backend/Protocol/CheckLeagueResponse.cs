﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002358 RID: 9048
	[Token(Token = "0x2002358")]
	public struct CheckLeagueResponse : IFlatbufferObject
	{
		// Token: 0x17001F21 RID: 7969
		// (get) Token: 0x06010CDE RID: 68830 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F21")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010CDE")]
			[Address(RVA = "0x2147F80", Offset = "0x2147F80", VA = "0x2147F80", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CDF RID: 68831 RVA: 0x00060FA8 File Offset: 0x0005F1A8
		[Token(Token = "0x6010CDF")]
		[Address(RVA = "0x2147F88", Offset = "0x2147F88", VA = "0x2147F88")]
		public static CheckLeagueResponse GetRootAsCheckLeagueResponse(ByteBuffer _bb)
		{
			return default(CheckLeagueResponse);
		}

		// Token: 0x06010CE0 RID: 68832 RVA: 0x00060FC0 File Offset: 0x0005F1C0
		[Token(Token = "0x6010CE0")]
		[Address(RVA = "0x2147F94", Offset = "0x2147F94", VA = "0x2147F94")]
		public static CheckLeagueResponse GetRootAsCheckLeagueResponse(ByteBuffer _bb, CheckLeagueResponse obj)
		{
			return default(CheckLeagueResponse);
		}

		// Token: 0x06010CE1 RID: 68833 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CE1")]
		[Address(RVA = "0x2148044", Offset = "0x2148044", VA = "0x2148044", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010CE2 RID: 68834 RVA: 0x00060FD8 File Offset: 0x0005F1D8
		[Token(Token = "0x6010CE2")]
		[Address(RVA = "0x214800C", Offset = "0x214800C", VA = "0x214800C")]
		public CheckLeagueResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(CheckLeagueResponse);
		}

		// Token: 0x17001F22 RID: 7970
		// (get) Token: 0x06010CE3 RID: 68835 RVA: 0x00060FF0 File Offset: 0x0005F1F0
		[Token(Token = "0x17001F22")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010CE3")]
			[Address(RVA = "0x2148054", Offset = "0x2148054", VA = "0x2148054")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001F23 RID: 7971
		// (get) Token: 0x06010CE4 RID: 68836 RVA: 0x00061008 File Offset: 0x0005F208
		[Token(Token = "0x17001F23")]
		public int LeagueId
		{
			[Token(Token = "0x6010CE4")]
			[Address(RVA = "0x2148098", Offset = "0x2148098", VA = "0x2148098")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010CE5 RID: 68837 RVA: 0x00061020 File Offset: 0x0005F220
		[Token(Token = "0x6010CE5")]
		[Address(RVA = "0x21480DC", Offset = "0x21480DC", VA = "0x21480DC")]
		public static Offset<CheckLeagueResponse> CreateCheckLeagueResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, int league_id = 0)
		{
			return default(Offset<CheckLeagueResponse>);
		}

		// Token: 0x06010CE6 RID: 68838 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CE6")]
		[Address(RVA = "0x21481E0", Offset = "0x21481E0", VA = "0x21481E0")]
		public static void StartCheckLeagueResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010CE7 RID: 68839 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CE7")]
		[Address(RVA = "0x2148154", Offset = "0x2148154", VA = "0x2148154")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010CE8 RID: 68840 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CE8")]
		[Address(RVA = "0x2148134", Offset = "0x2148134", VA = "0x2148134")]
		public static void AddLeagueId(FlatBufferBuilder builder, int leagueId)
		{
		}

		// Token: 0x06010CE9 RID: 68841 RVA: 0x00061038 File Offset: 0x0005F238
		[Token(Token = "0x6010CE9")]
		[Address(RVA = "0x2148174", Offset = "0x2148174", VA = "0x2148174")]
		public static Offset<CheckLeagueResponse> EndCheckLeagueResponse(FlatBufferBuilder builder)
		{
			return default(Offset<CheckLeagueResponse>);
		}

		// Token: 0x0400E65E RID: 58974
		[Token(Token = "0x400E65E")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
