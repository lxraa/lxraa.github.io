﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Friends
{
	// Token: 0x02002567 RID: 9575
	[Token(Token = "0x2002567")]
	public class AskFriendshipRequestHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700279A RID: 10138
		// (get) Token: 0x06012B60 RID: 76640 RVA: 0x00078FF0 File Offset: 0x000771F0
		[Token(Token = "0x1700279A")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B60")]
			[Address(RVA = "0x1ED1AC0", Offset = "0x1ED1AC0", VA = "0x1ED1AC0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700279B RID: 10139
		// (get) Token: 0x06012B61 RID: 76641 RVA: 0x00079008 File Offset: 0x00077208
		[Token(Token = "0x1700279B")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B61")]
			[Address(RVA = "0x1ED1AC8", Offset = "0x1ED1AC8", VA = "0x1ED1AC8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B62 RID: 76642 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B62")]
		[Address(RVA = "0x1ED1AD0", Offset = "0x1ED1AD0", VA = "0x1ED1AD0")]
		public AskFriendshipRequestHttpCommand(long userId, FriendRequestSource friendRequestSource, Action<long, AskFriendshipResult> onCompleted, Action<long, AskFriendshipResult> onFailed, Action onPackageFailed)
		{
		}

		// Token: 0x06012B63 RID: 76643 RVA: 0x00079020 File Offset: 0x00077220
		[Token(Token = "0x6012B63")]
		[Address(RVA = "0x1ED1B4C", Offset = "0x1ED1B4C", VA = "0x1ED1B4C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B64 RID: 76644 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B64")]
		[Address(RVA = "0x1ED1B78", Offset = "0x1ED1B78", VA = "0x1ED1B78", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B65 RID: 76645 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B65")]
		[Address(RVA = "0x1ED1E98", Offset = "0x1ED1E98", VA = "0x1ED1E98", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBD0 RID: 60368
		[Token(Token = "0x400EBD0")]
		[FieldOffset(Offset = "0x18")]
		private readonly long userId;

		// Token: 0x0400EBD1 RID: 60369
		[Token(Token = "0x400EBD1")]
		[FieldOffset(Offset = "0x20")]
		private readonly FriendRequestSource friendRequestSource;

		// Token: 0x0400EBD2 RID: 60370
		[Token(Token = "0x400EBD2")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action<long, AskFriendshipResult> onCompleted;

		// Token: 0x0400EBD3 RID: 60371
		[Token(Token = "0x400EBD3")]
		[FieldOffset(Offset = "0x30")]
		private readonly Action<long, AskFriendshipResult> onFailed;

		// Token: 0x0400EBD4 RID: 60372
		[Token(Token = "0x400EBD4")]
		[FieldOffset(Offset = "0x38")]
		private readonly Action onPackageFailed;
	}
}
