﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts
{
	// Token: 0x020025AD RID: 9645
	[Token(Token = "0x20025AD")]
	public enum ContextInitializationExceptionType
	{
		// Token: 0x0400ED87 RID: 60807
		[Token(Token = "0x400ED87")]
		None,
		// Token: 0x0400ED88 RID: 60808
		[Token(Token = "0x400ED88")]
		Construction,
		// Token: 0x0400ED89 RID: 60809
		[Token(Token = "0x400ED89")]
		Bind
	}
}
