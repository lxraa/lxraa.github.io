﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002336 RID: 9014
	[Token(Token = "0x2002336")]
	public struct AncientAdventureInfo : IFlatbufferObject
	{
		// Token: 0x17001EAB RID: 7851
		// (get) Token: 0x06010B15 RID: 68373 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EAB")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B15")]
			[Address(RVA = "0x21415E0", Offset = "0x21415E0", VA = "0x21415E0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B16 RID: 68374 RVA: 0x0005F8F8 File Offset: 0x0005DAF8
		[Token(Token = "0x6010B16")]
		[Address(RVA = "0x21415E8", Offset = "0x21415E8", VA = "0x21415E8")]
		public static AncientAdventureInfo GetRootAsAncientAdventureInfo(ByteBuffer _bb)
		{
			return default(AncientAdventureInfo);
		}

		// Token: 0x06010B17 RID: 68375 RVA: 0x0005F910 File Offset: 0x0005DB10
		[Token(Token = "0x6010B17")]
		[Address(RVA = "0x21415F4", Offset = "0x21415F4", VA = "0x21415F4")]
		public static AncientAdventureInfo GetRootAsAncientAdventureInfo(ByteBuffer _bb, AncientAdventureInfo obj)
		{
			return default(AncientAdventureInfo);
		}

		// Token: 0x06010B18 RID: 68376 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B18")]
		[Address(RVA = "0x21416A4", Offset = "0x21416A4", VA = "0x21416A4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B19 RID: 68377 RVA: 0x0005F928 File Offset: 0x0005DB28
		[Token(Token = "0x6010B19")]
		[Address(RVA = "0x214166C", Offset = "0x214166C", VA = "0x214166C")]
		public AncientAdventureInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(AncientAdventureInfo);
		}

		// Token: 0x17001EAC RID: 7852
		// (get) Token: 0x06010B1A RID: 68378 RVA: 0x0005F940 File Offset: 0x0005DB40
		[Token(Token = "0x17001EAC")]
		public int ServerEventId
		{
			[Token(Token = "0x6010B1A")]
			[Address(RVA = "0x21416B4", Offset = "0x21416B4", VA = "0x21416B4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EAD RID: 7853
		// (get) Token: 0x06010B1B RID: 68379 RVA: 0x0005F958 File Offset: 0x0005DB58
		[Token(Token = "0x17001EAD")]
		public long RemainingTime
		{
			[Token(Token = "0x6010B1B")]
			[Address(RVA = "0x21416F8", Offset = "0x21416F8", VA = "0x21416F8")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001EAE RID: 7854
		// (get) Token: 0x06010B1C RID: 68380 RVA: 0x0005F970 File Offset: 0x0005DB70
		[Token(Token = "0x17001EAE")]
		public int ConfigVersion
		{
			[Token(Token = "0x6010B1C")]
			[Address(RVA = "0x2141740", Offset = "0x2141740", VA = "0x2141740")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EAF RID: 7855
		// (get) Token: 0x06010B1D RID: 68381 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EAF")]
		public string Config
		{
			[Token(Token = "0x6010B1D")]
			[Address(RVA = "0x2141784", Offset = "0x2141784", VA = "0x2141784")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B1E RID: 68382 RVA: 0x0005F988 File Offset: 0x0005DB88
		[Token(Token = "0x6010B1E")]
		[Address(RVA = "0x21417C0", Offset = "0x21417C0", VA = "0x21417C0")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06010B1F RID: 68383 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010B1F")]
		[Address(RVA = "0x21417F8", Offset = "0x21417F8", VA = "0x21417F8")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x06010B20 RID: 68384 RVA: 0x0005F9A0 File Offset: 0x0005DBA0
		[Token(Token = "0x6010B20")]
		[Address(RVA = "0x2141844", Offset = "0x2141844", VA = "0x2141844")]
		public static Offset<AncientAdventureInfo> CreateAncientAdventureInfo(FlatBufferBuilder builder, int server_event_id = 0, long remaining_time = 0L, int config_version = 0, [Optional] StringOffset configOffset)
		{
			return default(Offset<AncientAdventureInfo>);
		}

		// Token: 0x06010B21 RID: 68385 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B21")]
		[Address(RVA = "0x21419B0", Offset = "0x21419B0", VA = "0x21419B0")]
		public static void StartAncientAdventureInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B22 RID: 68386 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B22")]
		[Address(RVA = "0x2141924", Offset = "0x2141924", VA = "0x2141924")]
		public static void AddServerEventId(FlatBufferBuilder builder, int serverEventId)
		{
		}

		// Token: 0x06010B23 RID: 68387 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B23")]
		[Address(RVA = "0x21418C4", Offset = "0x21418C4", VA = "0x21418C4")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06010B24 RID: 68388 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B24")]
		[Address(RVA = "0x2141904", Offset = "0x2141904", VA = "0x2141904")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06010B25 RID: 68389 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B25")]
		[Address(RVA = "0x21418E4", Offset = "0x21418E4", VA = "0x21418E4")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06010B26 RID: 68390 RVA: 0x0005F9B8 File Offset: 0x0005DBB8
		[Token(Token = "0x6010B26")]
		[Address(RVA = "0x2141944", Offset = "0x2141944", VA = "0x2141944")]
		public static Offset<AncientAdventureInfo> EndAncientAdventureInfo(FlatBufferBuilder builder)
		{
			return default(Offset<AncientAdventureInfo>);
		}

		// Token: 0x0400E610 RID: 58896
		[Token(Token = "0x400E610")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
