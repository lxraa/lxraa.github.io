﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.UserProfile
{
	// Token: 0x0200252A RID: 9514
	[Token(Token = "0x200252A")]
	public class GetUserHelpsReceivedFixHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002705 RID: 9989
		// (get) Token: 0x060129AA RID: 76202 RVA: 0x00077B98 File Offset: 0x00075D98
		[Token(Token = "0x17002705")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129AA")]
			[Address(RVA = "0x1CF9DC0", Offset = "0x1CF9DC0", VA = "0x1CF9DC0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002706 RID: 9990
		// (get) Token: 0x060129AB RID: 76203 RVA: 0x00077BB0 File Offset: 0x00075DB0
		[Token(Token = "0x17002706")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129AB")]
			[Address(RVA = "0x1CF9DC8", Offset = "0x1CF9DC8", VA = "0x1CF9DC8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002707 RID: 9991
		// (get) Token: 0x060129AC RID: 76204 RVA: 0x00077BC8 File Offset: 0x00075DC8
		// (set) Token: 0x060129AD RID: 76205 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002707")]
		private GetStatHelpsReceivedFixResponse Response
		{
			[Token(Token = "0x60129AC")]
			[Address(RVA = "0x1CF9DD0", Offset = "0x1CF9DD0", VA = "0x1CF9DD0")]
			get
			{
				return default(GetStatHelpsReceivedFixResponse);
			}
			[Token(Token = "0x60129AD")]
			[Address(RVA = "0x1CF9DDC", Offset = "0x1CF9DDC", VA = "0x1CF9DDC")]
			set
			{
			}
		}

		// Token: 0x060129AE RID: 76206 RVA: 0x00077BE0 File Offset: 0x00075DE0
		[Token(Token = "0x60129AE")]
		[Address(RVA = "0x1CF9DEC", Offset = "0x1CF9DEC", VA = "0x1CF9DEC", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129AF RID: 76207 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129AF")]
		[Address(RVA = "0x1CF9E6C", Offset = "0x1CF9E6C", VA = "0x1CF9E6C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129B0 RID: 76208 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129B0")]
		[Address(RVA = "0x1CF9FF8", Offset = "0x1CF9FF8", VA = "0x1CF9FF8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x060129B1 RID: 76209 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129B1")]
		[Address(RVA = "0x1CF9FFC", Offset = "0x1CF9FFC", VA = "0x1CF9FFC")]
		public GetUserHelpsReceivedFixHttpCommand()
		{
		}

		// Token: 0x0400EB20 RID: 60192
		[Token(Token = "0x400EB20")]
		[FieldOffset(Offset = "0x18")]
		private GetStatHelpsReceivedFixResponse <Response>k__BackingField;

		// Token: 0x0400EB21 RID: 60193
		[Token(Token = "0x400EB21")]
		[FieldOffset(Offset = "0x28")]
		private long requestUserId;
	}
}
