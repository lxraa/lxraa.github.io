﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200234A RID: 9034
	[Token(Token = "0x200234A")]
	public struct BalloonRiseUserConfigInfo : IFlatbufferObject
	{
		// Token: 0x17001EF3 RID: 7923
		// (get) Token: 0x06010C2F RID: 68655 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EF3")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C2F")]
			[Address(RVA = "0x214575C", Offset = "0x214575C", VA = "0x214575C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C30 RID: 68656 RVA: 0x00060708 File Offset: 0x0005E908
		[Token(Token = "0x6010C30")]
		[Address(RVA = "0x2145764", Offset = "0x2145764", VA = "0x2145764")]
		public static BalloonRiseUserConfigInfo GetRootAsBalloonRiseUserConfigInfo(ByteBuffer _bb)
		{
			return default(BalloonRiseUserConfigInfo);
		}

		// Token: 0x06010C31 RID: 68657 RVA: 0x00060720 File Offset: 0x0005E920
		[Token(Token = "0x6010C31")]
		[Address(RVA = "0x2145770", Offset = "0x2145770", VA = "0x2145770")]
		public static BalloonRiseUserConfigInfo GetRootAsBalloonRiseUserConfigInfo(ByteBuffer _bb, BalloonRiseUserConfigInfo obj)
		{
			return default(BalloonRiseUserConfigInfo);
		}

		// Token: 0x06010C32 RID: 68658 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C32")]
		[Address(RVA = "0x2145820", Offset = "0x2145820", VA = "0x2145820", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C33 RID: 68659 RVA: 0x00060738 File Offset: 0x0005E938
		[Token(Token = "0x6010C33")]
		[Address(RVA = "0x21457E8", Offset = "0x21457E8", VA = "0x21457E8")]
		public BalloonRiseUserConfigInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(BalloonRiseUserConfigInfo);
		}

		// Token: 0x17001EF4 RID: 7924
		// (get) Token: 0x06010C34 RID: 68660 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EF4")]
		public string UserConfig
		{
			[Token(Token = "0x6010C34")]
			[Address(RVA = "0x2145830", Offset = "0x2145830", VA = "0x2145830")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C35 RID: 68661 RVA: 0x00060750 File Offset: 0x0005E950
		[Token(Token = "0x6010C35")]
		[Address(RVA = "0x214586C", Offset = "0x214586C", VA = "0x214586C")]
		public ArraySegment<byte>? GetUserConfigBytes()
		{
			return null;
		}

		// Token: 0x06010C36 RID: 68662 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010C36")]
		[Address(RVA = "0x21458A4", Offset = "0x21458A4", VA = "0x21458A4")]
		public byte[] GetUserConfigArray()
		{
			return null;
		}

		// Token: 0x17001EF5 RID: 7925
		// (get) Token: 0x06010C37 RID: 68663 RVA: 0x00060768 File Offset: 0x0005E968
		[Token(Token = "0x17001EF5")]
		public int UserConfigVersion
		{
			[Token(Token = "0x6010C37")]
			[Address(RVA = "0x21458F0", Offset = "0x21458F0", VA = "0x21458F0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010C38 RID: 68664 RVA: 0x00060780 File Offset: 0x0005E980
		[Token(Token = "0x6010C38")]
		[Address(RVA = "0x2145934", Offset = "0x2145934", VA = "0x2145934")]
		public static Offset<BalloonRiseUserConfigInfo> CreateBalloonRiseUserConfigInfo(FlatBufferBuilder builder, [Optional] StringOffset user_configOffset, int user_config_version = 0)
		{
			return default(Offset<BalloonRiseUserConfigInfo>);
		}

		// Token: 0x06010C39 RID: 68665 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C39")]
		[Address(RVA = "0x2145A38", Offset = "0x2145A38", VA = "0x2145A38")]
		public static void StartBalloonRiseUserConfigInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C3A RID: 68666 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C3A")]
		[Address(RVA = "0x21459AC", Offset = "0x21459AC", VA = "0x21459AC")]
		public static void AddUserConfig(FlatBufferBuilder builder, StringOffset userConfigOffset)
		{
		}

		// Token: 0x06010C3B RID: 68667 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C3B")]
		[Address(RVA = "0x214598C", Offset = "0x214598C", VA = "0x214598C")]
		public static void AddUserConfigVersion(FlatBufferBuilder builder, int userConfigVersion)
		{
		}

		// Token: 0x06010C3C RID: 68668 RVA: 0x00060798 File Offset: 0x0005E998
		[Token(Token = "0x6010C3C")]
		[Address(RVA = "0x21459CC", Offset = "0x21459CC", VA = "0x21459CC")]
		public static Offset<BalloonRiseUserConfigInfo> EndBalloonRiseUserConfigInfo(FlatBufferBuilder builder)
		{
			return default(Offset<BalloonRiseUserConfigInfo>);
		}

		// Token: 0x0400E62E RID: 58926
		[Token(Token = "0x400E62E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
