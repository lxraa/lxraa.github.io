﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.Utils.Metrics;

namespace Royal.Infrastructure.Services.Analytics
{
	// Token: 0x020025A1 RID: 9633
	[Token(Token = "0x20025A1")]
	public class MetricDataJson
	{
		// Token: 0x06012D59 RID: 77145 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D59")]
		[Address(RVA = "0x243AA54", Offset = "0x243AA54", VA = "0x243AA54")]
		public MetricDataJson(string key, string value)
		{
		}

		// Token: 0x06012D5A RID: 77146 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D5A")]
		[Address(RVA = "0x243AA98", Offset = "0x243AA98", VA = "0x243AA98")]
		public MetricDataJson(MetricType key, string value)
		{
		}

		// Token: 0x0400ED2F RID: 60719
		[Token(Token = "0x400ED2F")]
		[FieldOffset(Offset = "0x10")]
		public string k;

		// Token: 0x0400ED30 RID: 60720
		[Token(Token = "0x400ED30")]
		[FieldOffset(Offset = "0x18")]
		public string v;
	}
}
