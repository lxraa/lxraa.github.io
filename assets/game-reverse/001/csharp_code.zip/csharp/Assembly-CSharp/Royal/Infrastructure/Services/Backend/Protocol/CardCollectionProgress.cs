﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200234D RID: 9037
	[Token(Token = "0x200234D")]
	public struct CardCollectionProgress : IFlatbufferObject
	{
		// Token: 0x17001EF9 RID: 7929
		// (get) Token: 0x06010C4F RID: 68687 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EF9")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C4F")]
			[Address(RVA = "0x2145EEC", Offset = "0x2145EEC", VA = "0x2145EEC", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C50 RID: 68688 RVA: 0x000608B8 File Offset: 0x0005EAB8
		[Token(Token = "0x6010C50")]
		[Address(RVA = "0x2145EF4", Offset = "0x2145EF4", VA = "0x2145EF4")]
		public static CardCollectionProgress GetRootAsCardCollectionProgress(ByteBuffer _bb)
		{
			return default(CardCollectionProgress);
		}

		// Token: 0x06010C51 RID: 68689 RVA: 0x000608D0 File Offset: 0x0005EAD0
		[Token(Token = "0x6010C51")]
		[Address(RVA = "0x2145F00", Offset = "0x2145F00", VA = "0x2145F00")]
		public static CardCollectionProgress GetRootAsCardCollectionProgress(ByteBuffer _bb, CardCollectionProgress obj)
		{
			return default(CardCollectionProgress);
		}

		// Token: 0x06010C52 RID: 68690 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C52")]
		[Address(RVA = "0x2145FB0", Offset = "0x2145FB0", VA = "0x2145FB0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C53 RID: 68691 RVA: 0x000608E8 File Offset: 0x0005EAE8
		[Token(Token = "0x6010C53")]
		[Address(RVA = "0x2145F78", Offset = "0x2145F78", VA = "0x2145F78")]
		public CardCollectionProgress __assign(int _i, ByteBuffer _bb)
		{
			return default(CardCollectionProgress);
		}

		// Token: 0x06010C54 RID: 68692 RVA: 0x00060900 File Offset: 0x0005EB00
		[Token(Token = "0x6010C54")]
		[Address(RVA = "0x2145FC0", Offset = "0x2145FC0", VA = "0x2145FC0")]
		public CardCollectionSetProgress? Sets(int j)
		{
			return null;
		}

		// Token: 0x17001EFA RID: 7930
		// (get) Token: 0x06010C55 RID: 68693 RVA: 0x00060918 File Offset: 0x0005EB18
		[Token(Token = "0x17001EFA")]
		public int SetsLength
		{
			[Token(Token = "0x6010C55")]
			[Address(RVA = "0x21460C8", Offset = "0x21460C8", VA = "0x21460C8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EFB RID: 7931
		// (get) Token: 0x06010C56 RID: 68694 RVA: 0x00060930 File Offset: 0x0005EB30
		[Token(Token = "0x17001EFB")]
		public int WildCards
		{
			[Token(Token = "0x6010C56")]
			[Address(RVA = "0x21460FC", Offset = "0x21460FC", VA = "0x21460FC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EFC RID: 7932
		// (get) Token: 0x06010C57 RID: 68695 RVA: 0x00060948 File Offset: 0x0005EB48
		[Token(Token = "0x17001EFC")]
		public int Tokens
		{
			[Token(Token = "0x6010C57")]
			[Address(RVA = "0x2146140", Offset = "0x2146140", VA = "0x2146140")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010C58 RID: 68696 RVA: 0x00060960 File Offset: 0x0005EB60
		[Token(Token = "0x6010C58")]
		[Address(RVA = "0x2146184", Offset = "0x2146184", VA = "0x2146184")]
		public static Offset<CardCollectionProgress> CreateCardCollectionProgress(FlatBufferBuilder builder, [Optional] VectorOffset setsOffset, int wild_cards = 0, int tokens = 0)
		{
			return default(Offset<CardCollectionProgress>);
		}

		// Token: 0x06010C59 RID: 68697 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C59")]
		[Address(RVA = "0x21462C0", Offset = "0x21462C0", VA = "0x21462C0")]
		public static void StartCardCollectionProgress(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C5A RID: 68698 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C5A")]
		[Address(RVA = "0x2146234", Offset = "0x2146234", VA = "0x2146234")]
		public static void AddSets(FlatBufferBuilder builder, VectorOffset setsOffset)
		{
		}

		// Token: 0x06010C5B RID: 68699 RVA: 0x00060978 File Offset: 0x0005EB78
		[Token(Token = "0x6010C5B")]
		[Address(RVA = "0x21462D8", Offset = "0x21462D8", VA = "0x21462D8")]
		public static VectorOffset CreateSetsVector(FlatBufferBuilder builder, Offset<CardCollectionSetProgress>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010C5C RID: 68700 RVA: 0x00060990 File Offset: 0x0005EB90
		[Token(Token = "0x6010C5C")]
		[Address(RVA = "0x2146380", Offset = "0x2146380", VA = "0x2146380")]
		public static VectorOffset CreateSetsVectorBlock(FlatBufferBuilder builder, Offset<CardCollectionSetProgress>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010C5D RID: 68701 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C5D")]
		[Address(RVA = "0x2146408", Offset = "0x2146408", VA = "0x2146408")]
		public static void StartSetsVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010C5E RID: 68702 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C5E")]
		[Address(RVA = "0x2146214", Offset = "0x2146214", VA = "0x2146214")]
		public static void AddWildCards(FlatBufferBuilder builder, int wildCards)
		{
		}

		// Token: 0x06010C5F RID: 68703 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C5F")]
		[Address(RVA = "0x21461F4", Offset = "0x21461F4", VA = "0x21461F4")]
		public static void AddTokens(FlatBufferBuilder builder, int tokens)
		{
		}

		// Token: 0x06010C60 RID: 68704 RVA: 0x000609A8 File Offset: 0x0005EBA8
		[Token(Token = "0x6010C60")]
		[Address(RVA = "0x2146254", Offset = "0x2146254", VA = "0x2146254")]
		public static Offset<CardCollectionProgress> EndCardCollectionProgress(FlatBufferBuilder builder)
		{
			return default(Offset<CardCollectionProgress>);
		}

		// Token: 0x0400E63C RID: 58940
		[Token(Token = "0x400E63C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
