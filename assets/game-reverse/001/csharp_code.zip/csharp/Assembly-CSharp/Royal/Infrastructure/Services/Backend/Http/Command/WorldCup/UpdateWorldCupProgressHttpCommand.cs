﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.WorldCup
{
	// Token: 0x02002524 RID: 9508
	[Token(Token = "0x2002524")]
	public class UpdateWorldCupProgressHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026F8 RID: 9976
		// (get) Token: 0x06012982 RID: 76162 RVA: 0x000779A0 File Offset: 0x00075BA0
		[Token(Token = "0x170026F8")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012982")]
			[Address(RVA = "0x1CF82D8", Offset = "0x1CF82D8", VA = "0x1CF82D8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026F9 RID: 9977
		// (get) Token: 0x06012983 RID: 76163 RVA: 0x000779B8 File Offset: 0x00075BB8
		[Token(Token = "0x170026F9")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012983")]
			[Address(RVA = "0x1CF82E0", Offset = "0x1CF82E0", VA = "0x1CF82E0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012984 RID: 76164 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012984")]
		[Address(RVA = "0x1CF82E8", Offset = "0x1CF82E8", VA = "0x1CF82E8")]
		public UpdateWorldCupProgressHttpCommand(int eventID, WorldCupStage stage, int userScore, string country)
		{
		}

		// Token: 0x06012985 RID: 76165 RVA: 0x000779D0 File Offset: 0x00075BD0
		[Token(Token = "0x6012985")]
		[Address(RVA = "0x1CF8338", Offset = "0x1CF8338", VA = "0x1CF8338", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012986 RID: 76166 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012986")]
		[Address(RVA = "0x1CF85D4", Offset = "0x1CF85D4", VA = "0x1CF85D4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012987 RID: 76167 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012987")]
		[Address(RVA = "0x1CF88A0", Offset = "0x1CF88A0", VA = "0x1CF88A0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB14 RID: 60180
		[Token(Token = "0x400EB14")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventID;

		// Token: 0x0400EB15 RID: 60181
		[Token(Token = "0x400EB15")]
		[FieldOffset(Offset = "0x18")]
		private readonly WorldCupStage stage;

		// Token: 0x0400EB16 RID: 60182
		[Token(Token = "0x400EB16")]
		[FieldOffset(Offset = "0x1C")]
		private readonly int userScore;

		// Token: 0x0400EB17 RID: 60183
		[Token(Token = "0x400EB17")]
		[FieldOffset(Offset = "0x20")]
		private readonly string country;
	}
}
