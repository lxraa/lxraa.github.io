﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023AE RID: 9134
	[Token(Token = "0x20023AE")]
	public struct EnterTeamTournamentResponse : IFlatbufferObject
	{
		// Token: 0x17002074 RID: 8308
		// (get) Token: 0x060111B4 RID: 70068 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002074")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60111B4")]
			[Address(RVA = "0x1F9FA84", Offset = "0x1F9FA84", VA = "0x1F9FA84", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060111B5 RID: 70069 RVA: 0x00064F38 File Offset: 0x00063138
		[Token(Token = "0x60111B5")]
		[Address(RVA = "0x1F9FA8C", Offset = "0x1F9FA8C", VA = "0x1F9FA8C")]
		public static EnterTeamTournamentResponse GetRootAsEnterTeamTournamentResponse(ByteBuffer _bb)
		{
			return default(EnterTeamTournamentResponse);
		}

		// Token: 0x060111B6 RID: 70070 RVA: 0x00064F50 File Offset: 0x00063150
		[Token(Token = "0x60111B6")]
		[Address(RVA = "0x1F9FA98", Offset = "0x1F9FA98", VA = "0x1F9FA98")]
		public static EnterTeamTournamentResponse GetRootAsEnterTeamTournamentResponse(ByteBuffer _bb, EnterTeamTournamentResponse obj)
		{
			return default(EnterTeamTournamentResponse);
		}

		// Token: 0x060111B7 RID: 70071 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111B7")]
		[Address(RVA = "0x1F9FB48", Offset = "0x1F9FB48", VA = "0x1F9FB48", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060111B8 RID: 70072 RVA: 0x00064F68 File Offset: 0x00063168
		[Token(Token = "0x60111B8")]
		[Address(RVA = "0x1F9FB10", Offset = "0x1F9FB10", VA = "0x1F9FB10")]
		public EnterTeamTournamentResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterTeamTournamentResponse);
		}

		// Token: 0x17002075 RID: 8309
		// (get) Token: 0x060111B9 RID: 70073 RVA: 0x00064F80 File Offset: 0x00063180
		[Token(Token = "0x17002075")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x60111B9")]
			[Address(RVA = "0x1F9FB58", Offset = "0x1F9FB58", VA = "0x1F9FB58")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17002076 RID: 8310
		// (get) Token: 0x060111BA RID: 70074 RVA: 0x00064F98 File Offset: 0x00063198
		[Token(Token = "0x17002076")]
		public TeamTournamentFailReason FailReason
		{
			[Token(Token = "0x60111BA")]
			[Address(RVA = "0x1F9FB9C", Offset = "0x1F9FB9C", VA = "0x1F9FB9C")]
			get
			{
				return TeamTournamentFailReason.None;
			}
		}

		// Token: 0x17002077 RID: 8311
		// (get) Token: 0x060111BB RID: 70075 RVA: 0x00064FB0 File Offset: 0x000631B0
		[Token(Token = "0x17002077")]
		public TeamTournamentGroupInfo? TeamTournamentGroupInfo
		{
			[Token(Token = "0x60111BB")]
			[Address(RVA = "0x1F9FBE0", Offset = "0x1F9FBE0", VA = "0x1F9FBE0")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002078 RID: 8312
		// (get) Token: 0x060111BC RID: 70076 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002078")]
		public string UsersHash
		{
			[Token(Token = "0x60111BC")]
			[Address(RVA = "0x1F9FCA0", Offset = "0x1F9FCA0", VA = "0x1F9FCA0")]
			get
			{
				return null;
			}
		}

		// Token: 0x060111BD RID: 70077 RVA: 0x00064FC8 File Offset: 0x000631C8
		[Token(Token = "0x60111BD")]
		[Address(RVA = "0x1F9FCDC", Offset = "0x1F9FCDC", VA = "0x1F9FCDC")]
		public ArraySegment<byte>? GetUsersHashBytes()
		{
			return null;
		}

		// Token: 0x060111BE RID: 70078 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60111BE")]
		[Address(RVA = "0x1F9FD14", Offset = "0x1F9FD14", VA = "0x1F9FD14")]
		public byte[] GetUsersHashArray()
		{
			return null;
		}

		// Token: 0x17002079 RID: 8313
		// (get) Token: 0x060111BF RID: 70079 RVA: 0x00064FE0 File Offset: 0x000631E0
		[Token(Token = "0x17002079")]
		public int Segment
		{
			[Token(Token = "0x60111BF")]
			[Address(RVA = "0x1F9FD60", Offset = "0x1F9FD60", VA = "0x1F9FD60")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060111C0 RID: 70080 RVA: 0x00064FF8 File Offset: 0x000631F8
		[Token(Token = "0x60111C0")]
		[Address(RVA = "0x1F9FDA4", Offset = "0x1F9FDA4", VA = "0x1F9FDA4")]
		public static Offset<EnterTeamTournamentResponse> CreateEnterTeamTournamentResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, TeamTournamentFailReason fail_reason = TeamTournamentFailReason.None, [Optional] Offset<TeamTournamentGroupInfo> team_tournament_group_infoOffset, [Optional] StringOffset users_hashOffset, int segment = 0)
		{
			return default(Offset<EnterTeamTournamentResponse>);
		}

		// Token: 0x060111C1 RID: 70081 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111C1")]
		[Address(RVA = "0x1F9FF48", Offset = "0x1F9FF48", VA = "0x1F9FF48")]
		public static void StartEnterTeamTournamentResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060111C2 RID: 70082 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111C2")]
		[Address(RVA = "0x1F9FEBC", Offset = "0x1F9FEBC", VA = "0x1F9FEBC")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x060111C3 RID: 70083 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111C3")]
		[Address(RVA = "0x1F9FE9C", Offset = "0x1F9FE9C", VA = "0x1F9FE9C")]
		public static void AddFailReason(FlatBufferBuilder builder, TeamTournamentFailReason failReason)
		{
		}

		// Token: 0x060111C4 RID: 70084 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111C4")]
		[Address(RVA = "0x1F9FE7C", Offset = "0x1F9FE7C", VA = "0x1F9FE7C")]
		public static void AddTeamTournamentGroupInfo(FlatBufferBuilder builder, Offset<TeamTournamentGroupInfo> teamTournamentGroupInfoOffset)
		{
		}

		// Token: 0x060111C5 RID: 70085 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111C5")]
		[Address(RVA = "0x1F9FE5C", Offset = "0x1F9FE5C", VA = "0x1F9FE5C")]
		public static void AddUsersHash(FlatBufferBuilder builder, StringOffset usersHashOffset)
		{
		}

		// Token: 0x060111C6 RID: 70086 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60111C6")]
		[Address(RVA = "0x1F9FE3C", Offset = "0x1F9FE3C", VA = "0x1F9FE3C")]
		public static void AddSegment(FlatBufferBuilder builder, int segment)
		{
		}

		// Token: 0x060111C7 RID: 70087 RVA: 0x00065010 File Offset: 0x00063210
		[Token(Token = "0x60111C7")]
		[Address(RVA = "0x1F9FEDC", Offset = "0x1F9FEDC", VA = "0x1F9FEDC")]
		public static Offset<EnterTeamTournamentResponse> EndEnterTeamTournamentResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterTeamTournamentResponse>);
		}

		// Token: 0x0400E6E0 RID: 59104
		[Token(Token = "0x400E6E0")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
