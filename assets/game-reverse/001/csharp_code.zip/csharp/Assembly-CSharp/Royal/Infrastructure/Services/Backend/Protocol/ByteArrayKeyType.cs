﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200234B RID: 9035
	[Token(Token = "0x200234B")]
	public enum ByteArrayKeyType
	{
		// Token: 0x0400E630 RID: 58928
		[Token(Token = "0x400E630")]
		None,
		// Token: 0x0400E631 RID: 58929
		[Token(Token = "0x400E631")]
		MagicCauldron,
		// Token: 0x0400E632 RID: 58930
		[Token(Token = "0x400E632")]
		SeasonalCardCollection,
		// Token: 0x0400E633 RID: 58931
		[Token(Token = "0x400E633")]
		MissionPursuit,
		// Token: 0x0400E634 RID: 58932
		[Token(Token = "0x400E634")]
		MissionControl,
		// Token: 0x0400E635 RID: 58933
		[Token(Token = "0x400E635")]
		TrainJourney,
		// Token: 0x0400E636 RID: 58934
		[Token(Token = "0x400E636")]
		OceanOdyssey,
		// Token: 0x0400E637 RID: 58935
		[Token(Token = "0x400E637")]
		PuzzleBreak,
		// Token: 0x0400E638 RID: 58936
		[Token(Token = "0x400E638")]
		NewRoyalPass,
		// Token: 0x0400E639 RID: 58937
		[Token(Token = "0x400E639")]
		NewMagicCauldron,
		// Token: 0x0400E63A RID: 58938
		[Token(Token = "0x400E63A")]
		AncientAdventure
	}
}
