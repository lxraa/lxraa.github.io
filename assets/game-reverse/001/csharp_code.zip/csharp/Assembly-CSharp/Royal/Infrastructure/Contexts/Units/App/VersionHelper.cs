﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025C5 RID: 9669
	[Token(Token = "0x20025C5")]
	public class VersionHelper
	{
		// Token: 0x140000A4 RID: 164
		// (add) Token: 0x06012EA9 RID: 77481 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012EAA RID: 77482 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A4")]
		public event Action OnNewInstall
		{
			[Token(Token = "0x6012EA9")]
			[Address(RVA = "0x244F6E8", Offset = "0x244F6E8", VA = "0x244F6E8")]
			add
			{
			}
			[Token(Token = "0x6012EAA")]
			[Address(RVA = "0x244F784", Offset = "0x244F784", VA = "0x244F784")]
			remove
			{
			}
		}

		// Token: 0x17002801 RID: 10241
		// (get) Token: 0x06012EAB RID: 77483 RVA: 0x0007A400 File Offset: 0x00078600
		// (set) Token: 0x06012EAC RID: 77484 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002801")]
		public bool ForceAlertActive
		{
			[Token(Token = "0x6012EAB")]
			[Address(RVA = "0x244F820", Offset = "0x244F820", VA = "0x244F820")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012EAC")]
			[Address(RVA = "0x244F828", Offset = "0x244F828", VA = "0x244F828")]
			private set
			{
			}
		}

		// Token: 0x06012EAD RID: 77485 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EAD")]
		[Address(RVA = "0x244A904", Offset = "0x244A904", VA = "0x244A904")]
		public void UpdateVersion()
		{
		}

		// Token: 0x06012EAE RID: 77486 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EAE")]
		[Address(RVA = "0x244D7D0", Offset = "0x244D7D0", VA = "0x244D7D0")]
		public void UpdateForceVersion(int version)
		{
		}

		// Token: 0x06012EAF RID: 77487 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EAF")]
		[Address(RVA = "0x244D854", Offset = "0x244D854", VA = "0x244D854")]
		public void CheckForceUpdate()
		{
		}

		// Token: 0x06012EB0 RID: 77488 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EB0")]
		[Address(RVA = "0x244FA28", Offset = "0x244FA28", VA = "0x244FA28")]
		private void ShowForceUpdate()
		{
		}

		// Token: 0x06012EB1 RID: 77489 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EB1")]
		[Address(RVA = "0x244F834", Offset = "0x244F834", VA = "0x244F834")]
		private void ShowDowngradedAlertMessage()
		{
		}

		// Token: 0x06012EB2 RID: 77490 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EB2")]
		[Address(RVA = "0x244CEE4", Offset = "0x244CEE4", VA = "0x244CEE4")]
		public void TryCloseForceAlert()
		{
		}

		// Token: 0x06012EB3 RID: 77491 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EB3")]
		[Address(RVA = "0x244ADB0", Offset = "0x244ADB0", VA = "0x244ADB0")]
		public void TryInvokeOnNewInstall()
		{
		}

		// Token: 0x06012EB4 RID: 77492 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EB4")]
		[Address(RVA = "0x244ADD8", Offset = "0x244ADD8", VA = "0x244ADD8")]
		public void Migrate()
		{
		}

		// Token: 0x06012EB5 RID: 77493 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EB5")]
		[Address(RVA = "0x244FD24", Offset = "0x244FD24", VA = "0x244FD24")]
		private void ResetAllOfferConfigs()
		{
		}

		// Token: 0x06012EB6 RID: 77494 RVA: 0x0007A418 File Offset: 0x00078618
		[Token(Token = "0x6012EB6")]
		[Address(RVA = "0x244FE4C", Offset = "0x244FE4C", VA = "0x244FE4C")]
		public bool IsUpdateFromBeforeVersion(int version)
		{
			return default(bool);
		}

		// Token: 0x06012EB7 RID: 77495 RVA: 0x0007A430 File Offset: 0x00078630
		[Token(Token = "0x6012EB7")]
		[Address(RVA = "0x244FE70", Offset = "0x244FE70", VA = "0x244FE70")]
		public int GetPreviousSyncedClientVersion()
		{
			return 0;
		}

		// Token: 0x06012EB8 RID: 77496 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EB8")]
		[Address(RVA = "0x244FEB8", Offset = "0x244FEB8", VA = "0x244FEB8")]
		public void UpdatePreviousSyncedClientVersion()
		{
		}

		// Token: 0x06012EB9 RID: 77497 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EB9")]
		[Address(RVA = "0x244FD20", Offset = "0x244FD20", VA = "0x244FD20")]
		private void OnDevVersionUpdate()
		{
		}

		// Token: 0x06012EBA RID: 77498 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EBA")]
		[Address(RVA = "0x244DB68", Offset = "0x244DB68", VA = "0x244DB68")]
		public VersionHelper()
		{
		}

		// Token: 0x0400EEBE RID: 61118
		[Token(Token = "0x400EEBE")]
		[FieldOffset(Offset = "0x18")]
		public VersionState versionState;

		// Token: 0x0400EEBF RID: 61119
		[Token(Token = "0x400EEBF")]
		[FieldOffset(Offset = "0x1C")]
		public int currentVersion;

		// Token: 0x0400EEC0 RID: 61120
		[Token(Token = "0x400EEC0")]
		[FieldOffset(Offset = "0x20")]
		private int oldVersion;

		// Token: 0x0400EEC1 RID: 61121
		[Token(Token = "0x400EEC1")]
		[FieldOffset(Offset = "0x24")]
		private int forceVersion;

		// Token: 0x0400EEC2 RID: 61122
		[Token(Token = "0x400EEC2")]
		[FieldOffset(Offset = "0x28")]
		private bool <ForceAlertActive>k__BackingField;
	}
}
