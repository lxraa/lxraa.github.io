﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200238B RID: 9099
	[Token(Token = "0x200238B")]
	public struct DragonNestReachedFullSlotResponse : IFlatbufferObject
	{
		// Token: 0x17001FF5 RID: 8181
		// (get) Token: 0x06010FE2 RID: 69602 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FF5")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010FE2")]
			[Address(RVA = "0x1F98B18", Offset = "0x1F98B18", VA = "0x1F98B18", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010FE3 RID: 69603 RVA: 0x00063738 File Offset: 0x00061938
		[Token(Token = "0x6010FE3")]
		[Address(RVA = "0x1F98B20", Offset = "0x1F98B20", VA = "0x1F98B20")]
		public static DragonNestReachedFullSlotResponse GetRootAsDragonNestReachedFullSlotResponse(ByteBuffer _bb)
		{
			return default(DragonNestReachedFullSlotResponse);
		}

		// Token: 0x06010FE4 RID: 69604 RVA: 0x00063750 File Offset: 0x00061950
		[Token(Token = "0x6010FE4")]
		[Address(RVA = "0x1F98B2C", Offset = "0x1F98B2C", VA = "0x1F98B2C")]
		public static DragonNestReachedFullSlotResponse GetRootAsDragonNestReachedFullSlotResponse(ByteBuffer _bb, DragonNestReachedFullSlotResponse obj)
		{
			return default(DragonNestReachedFullSlotResponse);
		}

		// Token: 0x06010FE5 RID: 69605 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FE5")]
		[Address(RVA = "0x1F98BDC", Offset = "0x1F98BDC", VA = "0x1F98BDC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010FE6 RID: 69606 RVA: 0x00063768 File Offset: 0x00061968
		[Token(Token = "0x6010FE6")]
		[Address(RVA = "0x1F98BA4", Offset = "0x1F98BA4", VA = "0x1F98BA4")]
		public DragonNestReachedFullSlotResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(DragonNestReachedFullSlotResponse);
		}

		// Token: 0x17001FF6 RID: 8182
		// (get) Token: 0x06010FE7 RID: 69607 RVA: 0x00063780 File Offset: 0x00061980
		[Token(Token = "0x17001FF6")]
		public long UserId
		{
			[Token(Token = "0x6010FE7")]
			[Address(RVA = "0x1F98BEC", Offset = "0x1F98BEC", VA = "0x1F98BEC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010FE8 RID: 69608 RVA: 0x00063798 File Offset: 0x00061998
		[Token(Token = "0x6010FE8")]
		[Address(RVA = "0x1F98C34", Offset = "0x1F98C34", VA = "0x1F98C34")]
		public static Offset<DragonNestReachedFullSlotResponse> CreateDragonNestReachedFullSlotResponse(FlatBufferBuilder builder, long user_id = 0L)
		{
			return default(Offset<DragonNestReachedFullSlotResponse>);
		}

		// Token: 0x06010FE9 RID: 69609 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FE9")]
		[Address(RVA = "0x1F98D08", Offset = "0x1F98D08", VA = "0x1F98D08")]
		public static void StartDragonNestReachedFullSlotResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010FEA RID: 69610 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010FEA")]
		[Address(RVA = "0x1F98C7C", Offset = "0x1F98C7C", VA = "0x1F98C7C")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010FEB RID: 69611 RVA: 0x000637B0 File Offset: 0x000619B0
		[Token(Token = "0x6010FEB")]
		[Address(RVA = "0x1F98C9C", Offset = "0x1F98C9C", VA = "0x1F98C9C")]
		public static Offset<DragonNestReachedFullSlotResponse> EndDragonNestReachedFullSlotResponse(FlatBufferBuilder builder)
		{
			return default(Offset<DragonNestReachedFullSlotResponse>);
		}

		// Token: 0x0400E6A4 RID: 59044
		[Token(Token = "0x400E6A4")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
