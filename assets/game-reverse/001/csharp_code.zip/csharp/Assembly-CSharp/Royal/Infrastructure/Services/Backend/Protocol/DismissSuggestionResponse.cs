﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002383 RID: 9091
	[Token(Token = "0x2002383")]
	public struct DismissSuggestionResponse : IFlatbufferObject
	{
		// Token: 0x17001FD8 RID: 8152
		// (get) Token: 0x06010F76 RID: 69494 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FD8")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010F76")]
			[Address(RVA = "0x1F97150", Offset = "0x1F97150", VA = "0x1F97150", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010F77 RID: 69495 RVA: 0x00063180 File Offset: 0x00061380
		[Token(Token = "0x6010F77")]
		[Address(RVA = "0x1F97158", Offset = "0x1F97158", VA = "0x1F97158")]
		public static DismissSuggestionResponse GetRootAsDismissSuggestionResponse(ByteBuffer _bb)
		{
			return default(DismissSuggestionResponse);
		}

		// Token: 0x06010F78 RID: 69496 RVA: 0x00063198 File Offset: 0x00061398
		[Token(Token = "0x6010F78")]
		[Address(RVA = "0x1F97164", Offset = "0x1F97164", VA = "0x1F97164")]
		public static DismissSuggestionResponse GetRootAsDismissSuggestionResponse(ByteBuffer _bb, DismissSuggestionResponse obj)
		{
			return default(DismissSuggestionResponse);
		}

		// Token: 0x06010F79 RID: 69497 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F79")]
		[Address(RVA = "0x1F97214", Offset = "0x1F97214", VA = "0x1F97214", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010F7A RID: 69498 RVA: 0x000631B0 File Offset: 0x000613B0
		[Token(Token = "0x6010F7A")]
		[Address(RVA = "0x1F971DC", Offset = "0x1F971DC", VA = "0x1F971DC")]
		public DismissSuggestionResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(DismissSuggestionResponse);
		}

		// Token: 0x17001FD9 RID: 8153
		// (get) Token: 0x06010F7B RID: 69499 RVA: 0x000631C8 File Offset: 0x000613C8
		[Token(Token = "0x17001FD9")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010F7B")]
			[Address(RVA = "0x1F97224", Offset = "0x1F97224", VA = "0x1F97224")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x06010F7C RID: 69500 RVA: 0x000631E0 File Offset: 0x000613E0
		[Token(Token = "0x6010F7C")]
		[Address(RVA = "0x1F97268", Offset = "0x1F97268", VA = "0x1F97268")]
		public static Offset<DismissSuggestionResponse> CreateDismissSuggestionResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success)
		{
			return default(Offset<DismissSuggestionResponse>);
		}

		// Token: 0x06010F7D RID: 69501 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F7D")]
		[Address(RVA = "0x1F9733C", Offset = "0x1F9733C", VA = "0x1F9733C")]
		public static void StartDismissSuggestionResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010F7E RID: 69502 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010F7E")]
		[Address(RVA = "0x1F972B0", Offset = "0x1F972B0", VA = "0x1F972B0")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010F7F RID: 69503 RVA: 0x000631F8 File Offset: 0x000613F8
		[Token(Token = "0x6010F7F")]
		[Address(RVA = "0x1F972D0", Offset = "0x1F972D0", VA = "0x1F972D0")]
		public static Offset<DismissSuggestionResponse> EndDismissSuggestionResponse(FlatBufferBuilder builder)
		{
			return default(Offset<DismissSuggestionResponse>);
		}

		// Token: 0x0400E69C RID: 59036
		[Token(Token = "0x400E69C")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
