﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002353 RID: 9043
	[Token(Token = "0x2002353")]
	public struct ChatMessage : IFlatbufferObject
	{
		// Token: 0x17001F0E RID: 7950
		// (get) Token: 0x06010CA1 RID: 68769 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F0E")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010CA1")]
			[Address(RVA = "0x2147260", Offset = "0x2147260", VA = "0x2147260", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CA2 RID: 68770 RVA: 0x00060CD8 File Offset: 0x0005EED8
		[Token(Token = "0x6010CA2")]
		[Address(RVA = "0x2147268", Offset = "0x2147268", VA = "0x2147268")]
		public static ChatMessage GetRootAsChatMessage(ByteBuffer _bb)
		{
			return default(ChatMessage);
		}

		// Token: 0x06010CA3 RID: 68771 RVA: 0x00060CF0 File Offset: 0x0005EEF0
		[Token(Token = "0x6010CA3")]
		[Address(RVA = "0x2147274", Offset = "0x2147274", VA = "0x2147274")]
		public static ChatMessage GetRootAsChatMessage(ByteBuffer _bb, ChatMessage obj)
		{
			return default(ChatMessage);
		}

		// Token: 0x06010CA4 RID: 68772 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CA4")]
		[Address(RVA = "0x2147324", Offset = "0x2147324", VA = "0x2147324", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010CA5 RID: 68773 RVA: 0x00060D08 File Offset: 0x0005EF08
		[Token(Token = "0x6010CA5")]
		[Address(RVA = "0x21472EC", Offset = "0x21472EC", VA = "0x21472EC")]
		public ChatMessage __assign(int _i, ByteBuffer _bb)
		{
			return default(ChatMessage);
		}

		// Token: 0x17001F0F RID: 7951
		// (get) Token: 0x06010CA6 RID: 68774 RVA: 0x00060D20 File Offset: 0x0005EF20
		[Token(Token = "0x17001F0F")]
		public ChatMessageType ChatMessageType
		{
			[Token(Token = "0x6010CA6")]
			[Address(RVA = "0x2147334", Offset = "0x2147334", VA = "0x2147334")]
			get
			{
				return ChatMessageType.TextMessage;
			}
		}

		// Token: 0x17001F10 RID: 7952
		// (get) Token: 0x06010CA7 RID: 68775 RVA: 0x00060D38 File Offset: 0x0005EF38
		[Token(Token = "0x17001F10")]
		public long UserId
		{
			[Token(Token = "0x6010CA7")]
			[Address(RVA = "0x2147378", Offset = "0x2147378", VA = "0x2147378")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F11 RID: 7953
		// (get) Token: 0x06010CA8 RID: 68776 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F11")]
		public string Name
		{
			[Token(Token = "0x6010CA8")]
			[Address(RVA = "0x21473C0", Offset = "0x21473C0", VA = "0x21473C0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CA9 RID: 68777 RVA: 0x00060D50 File Offset: 0x0005EF50
		[Token(Token = "0x6010CA9")]
		[Address(RVA = "0x21473FC", Offset = "0x21473FC", VA = "0x21473FC")]
		public ArraySegment<byte>? GetNameBytes()
		{
			return null;
		}

		// Token: 0x06010CAA RID: 68778 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010CAA")]
		[Address(RVA = "0x2147434", Offset = "0x2147434", VA = "0x2147434")]
		public byte[] GetNameArray()
		{
			return null;
		}

		// Token: 0x17001F12 RID: 7954
		// (get) Token: 0x06010CAB RID: 68779 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F12")]
		public string Text
		{
			[Token(Token = "0x6010CAB")]
			[Address(RVA = "0x2147480", Offset = "0x2147480", VA = "0x2147480")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CAC RID: 68780 RVA: 0x00060D68 File Offset: 0x0005EF68
		[Token(Token = "0x6010CAC")]
		[Address(RVA = "0x21474BC", Offset = "0x21474BC", VA = "0x21474BC")]
		public ArraySegment<byte>? GetTextBytes()
		{
			return null;
		}

		// Token: 0x06010CAD RID: 68781 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010CAD")]
		[Address(RVA = "0x21474F4", Offset = "0x21474F4", VA = "0x21474F4")]
		public byte[] GetTextArray()
		{
			return null;
		}

		// Token: 0x17001F13 RID: 7955
		// (get) Token: 0x06010CAE RID: 68782 RVA: 0x00060D80 File Offset: 0x0005EF80
		[Token(Token = "0x17001F13")]
		public long CreateDate
		{
			[Token(Token = "0x6010CAE")]
			[Address(RVA = "0x2147540", Offset = "0x2147540", VA = "0x2147540")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F14 RID: 7956
		// (get) Token: 0x06010CAF RID: 68783 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F14")]
		public string ActionOwner
		{
			[Token(Token = "0x6010CAF")]
			[Address(RVA = "0x2147588", Offset = "0x2147588", VA = "0x2147588")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CB0 RID: 68784 RVA: 0x00060D98 File Offset: 0x0005EF98
		[Token(Token = "0x6010CB0")]
		[Address(RVA = "0x21475C4", Offset = "0x21475C4", VA = "0x21475C4")]
		public ArraySegment<byte>? GetActionOwnerBytes()
		{
			return null;
		}

		// Token: 0x06010CB1 RID: 68785 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010CB1")]
		[Address(RVA = "0x21475FC", Offset = "0x21475FC", VA = "0x21475FC")]
		public byte[] GetActionOwnerArray()
		{
			return null;
		}

		// Token: 0x17001F15 RID: 7957
		// (get) Token: 0x06010CB2 RID: 68786 RVA: 0x00060DB0 File Offset: 0x0005EFB0
		[Token(Token = "0x17001F15")]
		public bool IsGold
		{
			[Token(Token = "0x6010CB2")]
			[Address(RVA = "0x2147648", Offset = "0x2147648", VA = "0x2147648")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F16 RID: 7958
		// (get) Token: 0x06010CB3 RID: 68787 RVA: 0x00060DC8 File Offset: 0x0005EFC8
		[Token(Token = "0x17001F16")]
		public bool HasSpecialNameStyle
		{
			[Token(Token = "0x6010CB3")]
			[Address(RVA = "0x2147690", Offset = "0x2147690", VA = "0x2147690")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17001F17 RID: 7959
		// (get) Token: 0x06010CB4 RID: 68788 RVA: 0x00060DE0 File Offset: 0x0005EFE0
		[Token(Token = "0x17001F17")]
		public ChatProfile? ChatProfile
		{
			[Token(Token = "0x6010CB4")]
			[Address(RVA = "0x21476D8", Offset = "0x21476D8", VA = "0x21476D8")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001F18 RID: 7960
		// (get) Token: 0x06010CB5 RID: 68789 RVA: 0x00060DF8 File Offset: 0x0005EFF8
		[Token(Token = "0x17001F18")]
		public KnightType KnightType
		{
			[Token(Token = "0x6010CB5")]
			[Address(RVA = "0x2147790", Offset = "0x2147790", VA = "0x2147790")]
			get
			{
				return KnightType.None;
			}
		}

		// Token: 0x17001F19 RID: 7961
		// (get) Token: 0x06010CB6 RID: 68790 RVA: 0x00060E10 File Offset: 0x0005F010
		[Token(Token = "0x17001F19")]
		public bool IsPremium
		{
			[Token(Token = "0x6010CB6")]
			[Address(RVA = "0x21477D4", Offset = "0x21477D4", VA = "0x21477D4")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06010CB7 RID: 68791 RVA: 0x00060E28 File Offset: 0x0005F028
		[Token(Token = "0x6010CB7")]
		[Address(RVA = "0x214781C", Offset = "0x214781C", VA = "0x214781C")]
		public static Offset<ChatMessage> CreateChatMessage(FlatBufferBuilder builder, ChatMessageType chat_message_type = ChatMessageType.TextMessage, long user_id = 0L, [Optional] StringOffset nameOffset, [Optional] StringOffset textOffset, long create_date = 0L, [Optional] StringOffset action_ownerOffset, bool is_gold = false, bool has_special_name_style = false, [Optional] Offset<ChatProfile> chat_profileOffset, KnightType knight_type = KnightType.None, bool is_premium = false)
		{
			return default(Offset<ChatMessage>);
		}

		// Token: 0x06010CB8 RID: 68792 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CB8")]
		[Address(RVA = "0x2147AF8", Offset = "0x2147AF8", VA = "0x2147AF8")]
		public static void StartChatMessage(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010CB9 RID: 68793 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CB9")]
		[Address(RVA = "0x2147A6C", Offset = "0x2147A6C", VA = "0x2147A6C")]
		public static void AddChatMessageType(FlatBufferBuilder builder, ChatMessageType chatMessageType)
		{
		}

		// Token: 0x06010CBA RID: 68794 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CBA")]
		[Address(RVA = "0x214794C", Offset = "0x214794C", VA = "0x214794C")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06010CBB RID: 68795 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CBB")]
		[Address(RVA = "0x21479CC", Offset = "0x21479CC", VA = "0x21479CC")]
		public static void AddName(FlatBufferBuilder builder, StringOffset nameOffset)
		{
		}

		// Token: 0x06010CBC RID: 68796 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CBC")]
		[Address(RVA = "0x21479AC", Offset = "0x21479AC", VA = "0x21479AC")]
		public static void AddText(FlatBufferBuilder builder, StringOffset textOffset)
		{
		}

		// Token: 0x06010CBD RID: 68797 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CBD")]
		[Address(RVA = "0x214792C", Offset = "0x214792C", VA = "0x214792C")]
		public static void AddCreateDate(FlatBufferBuilder builder, long createDate)
		{
		}

		// Token: 0x06010CBE RID: 68798 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CBE")]
		[Address(RVA = "0x214798C", Offset = "0x214798C", VA = "0x214798C")]
		public static void AddActionOwner(FlatBufferBuilder builder, StringOffset actionOwnerOffset)
		{
		}

		// Token: 0x06010CBF RID: 68799 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CBF")]
		[Address(RVA = "0x2147A4C", Offset = "0x2147A4C", VA = "0x2147A4C")]
		public static void AddIsGold(FlatBufferBuilder builder, bool isGold)
		{
		}

		// Token: 0x06010CC0 RID: 68800 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CC0")]
		[Address(RVA = "0x2147A2C", Offset = "0x2147A2C", VA = "0x2147A2C")]
		public static void AddHasSpecialNameStyle(FlatBufferBuilder builder, bool hasSpecialNameStyle)
		{
		}

		// Token: 0x06010CC1 RID: 68801 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CC1")]
		[Address(RVA = "0x214796C", Offset = "0x214796C", VA = "0x214796C")]
		public static void AddChatProfile(FlatBufferBuilder builder, Offset<ChatProfile> chatProfileOffset)
		{
		}

		// Token: 0x06010CC2 RID: 68802 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CC2")]
		[Address(RVA = "0x2147A0C", Offset = "0x2147A0C", VA = "0x2147A0C")]
		public static void AddKnightType(FlatBufferBuilder builder, KnightType knightType)
		{
		}

		// Token: 0x06010CC3 RID: 68803 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CC3")]
		[Address(RVA = "0x21479EC", Offset = "0x21479EC", VA = "0x21479EC")]
		public static void AddIsPremium(FlatBufferBuilder builder, bool isPremium)
		{
		}

		// Token: 0x06010CC4 RID: 68804 RVA: 0x00060E40 File Offset: 0x0005F040
		[Token(Token = "0x6010CC4")]
		[Address(RVA = "0x2147A8C", Offset = "0x2147A8C", VA = "0x2147A8C")]
		public static Offset<ChatMessage> EndChatMessage(FlatBufferBuilder builder)
		{
			return default(Offset<ChatMessage>);
		}

		// Token: 0x0400E645 RID: 58949
		[Token(Token = "0x400E645")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
