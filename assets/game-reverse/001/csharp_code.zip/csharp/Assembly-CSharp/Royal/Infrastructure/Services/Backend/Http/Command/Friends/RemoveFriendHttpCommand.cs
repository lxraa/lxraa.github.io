﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Friends
{
	// Token: 0x0200256B RID: 9579
	[Token(Token = "0x200256B")]
	public class RemoveFriendHttpCommand : BaseHttpCommand
	{
		// Token: 0x170027A0 RID: 10144
		// (get) Token: 0x06012B72 RID: 76658 RVA: 0x000790C8 File Offset: 0x000772C8
		[Token(Token = "0x170027A0")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B72")]
			[Address(RVA = "0x1ED23F8", Offset = "0x1ED23F8", VA = "0x1ED23F8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170027A1 RID: 10145
		// (get) Token: 0x06012B73 RID: 76659 RVA: 0x000790E0 File Offset: 0x000772E0
		[Token(Token = "0x170027A1")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B73")]
			[Address(RVA = "0x1ED2400", Offset = "0x1ED2400", VA = "0x1ED2400", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B74 RID: 76660 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B74")]
		[Address(RVA = "0x1ED2408", Offset = "0x1ED2408", VA = "0x1ED2408")]
		public RemoveFriendHttpCommand(long userId, Action<bool> onCompleted)
		{
		}

		// Token: 0x06012B75 RID: 76661 RVA: 0x000790F8 File Offset: 0x000772F8
		[Token(Token = "0x6012B75")]
		[Address(RVA = "0x1ED2444", Offset = "0x1ED2444", VA = "0x1ED2444", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B76 RID: 76662 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B76")]
		[Address(RVA = "0x1ED2464", Offset = "0x1ED2464", VA = "0x1ED2464", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B77 RID: 76663 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B77")]
		[Address(RVA = "0x1ED2658", Offset = "0x1ED2658", VA = "0x1ED2658", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBE1 RID: 60385
		[Token(Token = "0x400EBE1")]
		[FieldOffset(Offset = "0x18")]
		private readonly long userId;

		// Token: 0x0400EBE2 RID: 60386
		[Token(Token = "0x400EBE2")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action<bool> onCompleted;
	}
}
