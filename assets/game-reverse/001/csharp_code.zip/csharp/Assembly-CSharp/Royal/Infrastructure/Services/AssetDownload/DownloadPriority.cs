﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x0200258B RID: 9611
	[Token(Token = "0x200258B")]
	public enum DownloadPriority
	{
		// Token: 0x0400EC72 RID: 60530
		[Token(Token = "0x400EC72")]
		RequiredForOpenGame = 2147483647,
		// Token: 0x0400EC73 RID: 60531
		[Token(Token = "0x400EC73")]
		DownloadImmediately = 2147483646,
		// Token: 0x0400EC74 RID: 60532
		[Token(Token = "0x400EC74")]
		RequiredForTutorials = 2147483645,
		// Token: 0x0400EC75 RID: 60533
		[Token(Token = "0x400EC75")]
		UserProfileBundles = 2147483644,
		// Token: 0x0400EC76 RID: 60534
		[Token(Token = "0x400EC76")]
		FriendsBundle = 2147483643,
		// Token: 0x0400EC77 RID: 60535
		[Token(Token = "0x400EC77")]
		EmojiBundle = 12000,
		// Token: 0x0400EC78 RID: 60536
		[Token(Token = "0x400EC78")]
		WinLogo = 9400,
		// Token: 0x0400EC79 RID: 60537
		[Token(Token = "0x400EC79")]
		AreaImageBundle = 9000,
		// Token: 0x0400EC7A RID: 60538
		[Token(Token = "0x400EC7A")]
		SeasonalCardCollectionCommonBundle = 8000,
		// Token: 0x0400EC7B RID: 60539
		[Token(Token = "0x400EC7B")]
		SeasonalCardCollectionBundle = 6000,
		// Token: 0x0400EC7C RID: 60540
		[Token(Token = "0x400EC7C")]
		NextSeasonalCardCollectionBundle = 1000,
		// Token: 0x0400EC7D RID: 60541
		[Token(Token = "0x400EC7D")]
		ShopBundle = 5000,
		// Token: 0x0400EC7E RID: 60542
		[Token(Token = "0x400EC7E")]
		GameplayMusicBundle = 3000,
		// Token: 0x0400EC7F RID: 60543
		[Token(Token = "0x400EC7F")]
		ExtraEventContent = 6500,
		// Token: 0x0400EC80 RID: 60544
		[Token(Token = "0x400EC80")]
		MissionEvents = 7001,
		// Token: 0x0400EC81 RID: 60545
		[Token(Token = "0x400EC81")]
		VeryHigh = 10000,
		// Token: 0x0400EC82 RID: 60546
		[Token(Token = "0x400EC82")]
		High = 9500,
		// Token: 0x0400EC83 RID: 60547
		[Token(Token = "0x400EC83")]
		Medium = 7000,
		// Token: 0x0400EC84 RID: 60548
		[Token(Token = "0x400EC84")]
		Low = 4000,
		// Token: 0x0400EC85 RID: 60549
		[Token(Token = "0x400EC85")]
		VeryLow = 2000,
		// Token: 0x0400EC86 RID: 60550
		[Token(Token = "0x400EC86")]
		FacebookPictureSelf = 7051,
		// Token: 0x0400EC87 RID: 60551
		[Token(Token = "0x400EC87")]
		FacebookPictureHigh = 7050,
		// Token: 0x0400EC88 RID: 60552
		[Token(Token = "0x400EC88")]
		FacebookPicture = 6950,
		// Token: 0x0400EC89 RID: 60553
		[Token(Token = "0x400EC89")]
		DefaultTheme = 7000,
		// Token: 0x0400EC8A RID: 60554
		[Token(Token = "0x400EC8A")]
		HalloweenTheme = 6999,
		// Token: 0x0400EC8B RID: 60555
		[Token(Token = "0x400EC8B")]
		ChristmasTheme = 6998,
		// Token: 0x0400EC8C RID: 60556
		[Token(Token = "0x400EC8C")]
		ValentinesDayTheme = 6997,
		// Token: 0x0400EC8D RID: 60557
		[Token(Token = "0x400EC8D")]
		EasterTheme = 6996,
		// Token: 0x0400EC8E RID: 60558
		[Token(Token = "0x400EC8E")]
		SummerTheme = 6995,
		// Token: 0x0400EC8F RID: 60559
		[Token(Token = "0x400EC8F")]
		KingNightmareIconHigh = 9503,
		// Token: 0x0400EC90 RID: 60560
		[Token(Token = "0x400EC90")]
		KingNightmareIconLow = 2003,
		// Token: 0x0400EC91 RID: 60561
		[Token(Token = "0x400EC91")]
		KingNightmareCommonHigh = 9502,
		// Token: 0x0400EC92 RID: 60562
		[Token(Token = "0x400EC92")]
		KingNightmareCommonLow = 2002,
		// Token: 0x0400EC93 RID: 60563
		[Token(Token = "0x400EC93")]
		KingNightmareExtraHigh = 9501,
		// Token: 0x0400EC94 RID: 60564
		[Token(Token = "0x400EC94")]
		KingNightmareExtraLow = 2001,
		// Token: 0x0400EC95 RID: 60565
		[Token(Token = "0x400EC95")]
		None = -2147483648
	}
}
