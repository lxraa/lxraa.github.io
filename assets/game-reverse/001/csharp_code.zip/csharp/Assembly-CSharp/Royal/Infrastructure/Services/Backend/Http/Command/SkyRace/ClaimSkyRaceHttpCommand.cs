﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.SkyRace
{
	// Token: 0x02002549 RID: 9545
	[Token(Token = "0x2002549")]
	public class ClaimSkyRaceHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002750 RID: 10064
		// (get) Token: 0x06012A8A RID: 76426 RVA: 0x000785B8 File Offset: 0x000767B8
		[Token(Token = "0x17002750")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A8A")]
			[Address(RVA = "0x1ECB9F0", Offset = "0x1ECB9F0", VA = "0x1ECB9F0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002751 RID: 10065
		// (get) Token: 0x06012A8B RID: 76427 RVA: 0x000785D0 File Offset: 0x000767D0
		[Token(Token = "0x17002751")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A8B")]
			[Address(RVA = "0x1ECB9F8", Offset = "0x1ECB9F8", VA = "0x1ECB9F8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002752 RID: 10066
		// (get) Token: 0x06012A8C RID: 76428 RVA: 0x000785E8 File Offset: 0x000767E8
		// (set) Token: 0x06012A8D RID: 76429 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002752")]
		public ClaimSkyRaceRewardResponse Response
		{
			[Token(Token = "0x6012A8C")]
			[Address(RVA = "0x1ECBA00", Offset = "0x1ECBA00", VA = "0x1ECBA00")]
			get
			{
				return default(ClaimSkyRaceRewardResponse);
			}
			[Token(Token = "0x6012A8D")]
			[Address(RVA = "0x1ECBA0C", Offset = "0x1ECBA0C", VA = "0x1ECBA0C")]
			set
			{
			}
		}

		// Token: 0x06012A8E RID: 76430 RVA: 0x00078600 File Offset: 0x00076800
		[Token(Token = "0x6012A8E")]
		[Address(RVA = "0x1ECBA1C", Offset = "0x1ECBA1C", VA = "0x1ECBA1C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A8F RID: 76431 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A8F")]
		[Address(RVA = "0x1ECBAD0", Offset = "0x1ECBAD0", VA = "0x1ECBAD0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A90 RID: 76432 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A90")]
		[Address(RVA = "0x1ECBCE8", Offset = "0x1ECBCE8", VA = "0x1ECBCE8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012A91 RID: 76433 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A91")]
		[Address(RVA = "0x1ECBCEC", Offset = "0x1ECBCEC", VA = "0x1ECBCEC")]
		public ClaimSkyRaceHttpCommand()
		{
		}

		// Token: 0x0400EB82 RID: 60290
		[Token(Token = "0x400EB82")]
		[FieldOffset(Offset = "0x18")]
		private ClaimSkyRaceRewardResponse <Response>k__BackingField;
	}
}
