﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002367 RID: 9063
	[Token(Token = "0x2002367")]
	public struct ClaimWeeklyLeaderboardResponse : IFlatbufferObject
	{
		// Token: 0x17001F54 RID: 8020
		// (get) Token: 0x06010DA1 RID: 69025 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F54")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010DA1")]
			[Address(RVA = "0x214ABEC", Offset = "0x214ABEC", VA = "0x214ABEC", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010DA2 RID: 69026 RVA: 0x000619F8 File Offset: 0x0005FBF8
		[Token(Token = "0x6010DA2")]
		[Address(RVA = "0x214ABF4", Offset = "0x214ABF4", VA = "0x214ABF4")]
		public static ClaimWeeklyLeaderboardResponse GetRootAsClaimWeeklyLeaderboardResponse(ByteBuffer _bb)
		{
			return default(ClaimWeeklyLeaderboardResponse);
		}

		// Token: 0x06010DA3 RID: 69027 RVA: 0x00061A10 File Offset: 0x0005FC10
		[Token(Token = "0x6010DA3")]
		[Address(RVA = "0x214AC00", Offset = "0x214AC00", VA = "0x214AC00")]
		public static ClaimWeeklyLeaderboardResponse GetRootAsClaimWeeklyLeaderboardResponse(ByteBuffer _bb, ClaimWeeklyLeaderboardResponse obj)
		{
			return default(ClaimWeeklyLeaderboardResponse);
		}

		// Token: 0x06010DA4 RID: 69028 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DA4")]
		[Address(RVA = "0x214ACB0", Offset = "0x214ACB0", VA = "0x214ACB0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010DA5 RID: 69029 RVA: 0x00061A28 File Offset: 0x0005FC28
		[Token(Token = "0x6010DA5")]
		[Address(RVA = "0x214AC78", Offset = "0x214AC78", VA = "0x214AC78")]
		public ClaimWeeklyLeaderboardResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimWeeklyLeaderboardResponse);
		}

		// Token: 0x06010DA6 RID: 69030 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010DA6")]
		[Address(RVA = "0x214ACC0", Offset = "0x214ACC0", VA = "0x214ACC0")]
		public static void StartClaimWeeklyLeaderboardResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010DA7 RID: 69031 RVA: 0x00061A40 File Offset: 0x0005FC40
		[Token(Token = "0x6010DA7")]
		[Address(RVA = "0x214ACD8", Offset = "0x214ACD8", VA = "0x214ACD8")]
		public static Offset<ClaimWeeklyLeaderboardResponse> EndClaimWeeklyLeaderboardResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimWeeklyLeaderboardResponse>);
		}

		// Token: 0x0400E66D RID: 58989
		[Token(Token = "0x400E66D")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
