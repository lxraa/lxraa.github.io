﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023DA RID: 9178
	[Token(Token = "0x20023DA")]
	public struct GetKeyValueRequest : IFlatbufferObject
	{
		// Token: 0x17002103 RID: 8451
		// (get) Token: 0x06011406 RID: 70662 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002103")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011406")]
			[Address(RVA = "0x1CB12D4", Offset = "0x1CB12D4", VA = "0x1CB12D4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011407 RID: 70663 RVA: 0x00066ED0 File Offset: 0x000650D0
		[Token(Token = "0x6011407")]
		[Address(RVA = "0x1CB12DC", Offset = "0x1CB12DC", VA = "0x1CB12DC")]
		public static GetKeyValueRequest GetRootAsGetKeyValueRequest(ByteBuffer _bb)
		{
			return default(GetKeyValueRequest);
		}

		// Token: 0x06011408 RID: 70664 RVA: 0x00066EE8 File Offset: 0x000650E8
		[Token(Token = "0x6011408")]
		[Address(RVA = "0x1CB12E8", Offset = "0x1CB12E8", VA = "0x1CB12E8")]
		public static GetKeyValueRequest GetRootAsGetKeyValueRequest(ByteBuffer _bb, GetKeyValueRequest obj)
		{
			return default(GetKeyValueRequest);
		}

		// Token: 0x06011409 RID: 70665 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011409")]
		[Address(RVA = "0x1CB1398", Offset = "0x1CB1398", VA = "0x1CB1398", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601140A RID: 70666 RVA: 0x00066F00 File Offset: 0x00065100
		[Token(Token = "0x601140A")]
		[Address(RVA = "0x1CB1360", Offset = "0x1CB1360", VA = "0x1CB1360")]
		public GetKeyValueRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetKeyValueRequest);
		}

		// Token: 0x0601140B RID: 70667 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601140B")]
		[Address(RVA = "0x1CB13A8", Offset = "0x1CB13A8", VA = "0x1CB13A8")]
		public string Keys(int j)
		{
			return null;
		}

		// Token: 0x17002104 RID: 8452
		// (get) Token: 0x0601140C RID: 70668 RVA: 0x00066F18 File Offset: 0x00065118
		[Token(Token = "0x17002104")]
		public int KeysLength
		{
			[Token(Token = "0x601140C")]
			[Address(RVA = "0x1CB1400", Offset = "0x1CB1400", VA = "0x1CB1400")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601140D RID: 70669 RVA: 0x00066F30 File Offset: 0x00065130
		[Token(Token = "0x601140D")]
		[Address(RVA = "0x1CB1434", Offset = "0x1CB1434", VA = "0x1CB1434")]
		public static Offset<GetKeyValueRequest> CreateGetKeyValueRequest(FlatBufferBuilder builder, [Optional] VectorOffset keysOffset)
		{
			return default(Offset<GetKeyValueRequest>);
		}

		// Token: 0x0601140E RID: 70670 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601140E")]
		[Address(RVA = "0x1CB1508", Offset = "0x1CB1508", VA = "0x1CB1508")]
		public static void StartGetKeyValueRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x0601140F RID: 70671 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601140F")]
		[Address(RVA = "0x1CB147C", Offset = "0x1CB147C", VA = "0x1CB147C")]
		public static void AddKeys(FlatBufferBuilder builder, VectorOffset keysOffset)
		{
		}

		// Token: 0x06011410 RID: 70672 RVA: 0x00066F48 File Offset: 0x00065148
		[Token(Token = "0x6011410")]
		[Address(RVA = "0x1CB1520", Offset = "0x1CB1520", VA = "0x1CB1520")]
		public static VectorOffset CreateKeysVector(FlatBufferBuilder builder, StringOffset[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011411 RID: 70673 RVA: 0x00066F60 File Offset: 0x00065160
		[Token(Token = "0x6011411")]
		[Address(RVA = "0x1CB15C8", Offset = "0x1CB15C8", VA = "0x1CB15C8")]
		public static VectorOffset CreateKeysVectorBlock(FlatBufferBuilder builder, StringOffset[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011412 RID: 70674 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011412")]
		[Address(RVA = "0x1CB1650", Offset = "0x1CB1650", VA = "0x1CB1650")]
		public static void StartKeysVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011413 RID: 70675 RVA: 0x00066F78 File Offset: 0x00065178
		[Token(Token = "0x6011413")]
		[Address(RVA = "0x1CB149C", Offset = "0x1CB149C", VA = "0x1CB149C")]
		public static Offset<GetKeyValueRequest> EndGetKeyValueRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetKeyValueRequest>);
		}

		// Token: 0x0400E74A RID: 59210
		[Token(Token = "0x400E74A")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
