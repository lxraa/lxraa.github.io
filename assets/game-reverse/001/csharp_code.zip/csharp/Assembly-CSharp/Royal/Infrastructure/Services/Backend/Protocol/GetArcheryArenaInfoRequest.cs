﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C3 RID: 9155
	[Token(Token = "0x20023C3")]
	public struct GetArcheryArenaInfoRequest : IFlatbufferObject
	{
		// Token: 0x170020C0 RID: 8384
		// (get) Token: 0x060112CE RID: 70350 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020C0")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60112CE")]
			[Address(RVA = "0x1CABFA4", Offset = "0x1CABFA4", VA = "0x1CABFA4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112CF RID: 70351 RVA: 0x00065D78 File Offset: 0x00063F78
		[Token(Token = "0x60112CF")]
		[Address(RVA = "0x1CABFAC", Offset = "0x1CABFAC", VA = "0x1CABFAC")]
		public static GetArcheryArenaInfoRequest GetRootAsGetArcheryArenaInfoRequest(ByteBuffer _bb)
		{
			return default(GetArcheryArenaInfoRequest);
		}

		// Token: 0x060112D0 RID: 70352 RVA: 0x00065D90 File Offset: 0x00063F90
		[Token(Token = "0x60112D0")]
		[Address(RVA = "0x1CABFB8", Offset = "0x1CABFB8", VA = "0x1CABFB8")]
		public static GetArcheryArenaInfoRequest GetRootAsGetArcheryArenaInfoRequest(ByteBuffer _bb, GetArcheryArenaInfoRequest obj)
		{
			return default(GetArcheryArenaInfoRequest);
		}

		// Token: 0x060112D1 RID: 70353 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112D1")]
		[Address(RVA = "0x1CAC068", Offset = "0x1CAC068", VA = "0x1CAC068", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060112D2 RID: 70354 RVA: 0x00065DA8 File Offset: 0x00063FA8
		[Token(Token = "0x60112D2")]
		[Address(RVA = "0x1CAC030", Offset = "0x1CAC030", VA = "0x1CAC030")]
		public GetArcheryArenaInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetArcheryArenaInfoRequest);
		}

		// Token: 0x170020C1 RID: 8385
		// (get) Token: 0x060112D3 RID: 70355 RVA: 0x00065DC0 File Offset: 0x00063FC0
		[Token(Token = "0x170020C1")]
		public long GroupId
		{
			[Token(Token = "0x60112D3")]
			[Address(RVA = "0x1CAC078", Offset = "0x1CAC078", VA = "0x1CAC078")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x170020C2 RID: 8386
		// (get) Token: 0x060112D4 RID: 70356 RVA: 0x00065DD8 File Offset: 0x00063FD8
		[Token(Token = "0x170020C2")]
		public int ConfigVersion
		{
			[Token(Token = "0x60112D4")]
			[Address(RVA = "0x1CAC0C0", Offset = "0x1CAC0C0", VA = "0x1CAC0C0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170020C3 RID: 8387
		// (get) Token: 0x060112D5 RID: 70357 RVA: 0x00065DF0 File Offset: 0x00063FF0
		[Token(Token = "0x170020C3")]
		public LeaderboardInfoType LeaderboardInfoType
		{
			[Token(Token = "0x60112D5")]
			[Address(RVA = "0x1CAC104", Offset = "0x1CAC104", VA = "0x1CAC104")]
			get
			{
				return LeaderboardInfoType.None;
			}
		}

		// Token: 0x170020C4 RID: 8388
		// (get) Token: 0x060112D6 RID: 70358 RVA: 0x00065E08 File Offset: 0x00064008
		[Token(Token = "0x170020C4")]
		public int EventId
		{
			[Token(Token = "0x60112D6")]
			[Address(RVA = "0x1CAC148", Offset = "0x1CAC148", VA = "0x1CAC148")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060112D7 RID: 70359 RVA: 0x00065E20 File Offset: 0x00064020
		[Token(Token = "0x60112D7")]
		[Address(RVA = "0x1CAC18C", Offset = "0x1CAC18C", VA = "0x1CAC18C")]
		public static Offset<GetArcheryArenaInfoRequest> CreateGetArcheryArenaInfoRequest(FlatBufferBuilder builder, long group_id = 0L, int config_version = 0, LeaderboardInfoType leaderboard_info_type = LeaderboardInfoType.None, int event_id = 0)
		{
			return default(Offset<GetArcheryArenaInfoRequest>);
		}

		// Token: 0x060112D8 RID: 70360 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112D8")]
		[Address(RVA = "0x1CAC2F8", Offset = "0x1CAC2F8", VA = "0x1CAC2F8")]
		public static void StartGetArcheryArenaInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060112D9 RID: 70361 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112D9")]
		[Address(RVA = "0x1CAC20C", Offset = "0x1CAC20C", VA = "0x1CAC20C")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x060112DA RID: 70362 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112DA")]
		[Address(RVA = "0x1CAC24C", Offset = "0x1CAC24C", VA = "0x1CAC24C")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x060112DB RID: 70363 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112DB")]
		[Address(RVA = "0x1CAC26C", Offset = "0x1CAC26C", VA = "0x1CAC26C")]
		public static void AddLeaderboardInfoType(FlatBufferBuilder builder, LeaderboardInfoType leaderboardInfoType)
		{
		}

		// Token: 0x060112DC RID: 70364 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112DC")]
		[Address(RVA = "0x1CAC22C", Offset = "0x1CAC22C", VA = "0x1CAC22C")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x060112DD RID: 70365 RVA: 0x00065E38 File Offset: 0x00064038
		[Token(Token = "0x60112DD")]
		[Address(RVA = "0x1CAC28C", Offset = "0x1CAC28C", VA = "0x1CAC28C")]
		public static Offset<GetArcheryArenaInfoRequest> EndGetArcheryArenaInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetArcheryArenaInfoRequest>);
		}

		// Token: 0x0400E730 RID: 59184
		[Token(Token = "0x400E730")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
