﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.AssetDownload
{
	// Token: 0x02002588 RID: 9608
	[Token(Token = "0x2002588")]
	public enum SceneType
	{
		// Token: 0x0400EC60 RID: 60512
		[Token(Token = "0x400EC60")]
		None,
		// Token: 0x0400EC61 RID: 60513
		[Token(Token = "0x400EC61")]
		All,
		// Token: 0x0400EC62 RID: 60514
		[Token(Token = "0x400EC62")]
		Home,
		// Token: 0x0400EC63 RID: 60515
		[Token(Token = "0x400EC63")]
		Game
	}
}
