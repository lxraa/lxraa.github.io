﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002513 RID: 9491
	[Token(Token = "0x2002513")]
	public class DetachUserFromDeviceHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026CB RID: 9931
		// (get) Token: 0x060128B5 RID: 75957 RVA: 0x000773D0 File Offset: 0x000755D0
		[Token(Token = "0x170026CB")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60128B5")]
			[Address(RVA = "0x1CEAAB8", Offset = "0x1CEAAB8", VA = "0x1CEAAB8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026CC RID: 9932
		// (get) Token: 0x060128B6 RID: 75958 RVA: 0x000773E8 File Offset: 0x000755E8
		[Token(Token = "0x170026CC")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60128B6")]
			[Address(RVA = "0x1CEAAC0", Offset = "0x1CEAAC0", VA = "0x1CEAAC0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026CD RID: 9933
		// (get) Token: 0x060128B7 RID: 75959 RVA: 0x00077400 File Offset: 0x00075600
		// (set) Token: 0x060128B8 RID: 75960 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026CD")]
		private DetachUserFromDeviceResponse Response
		{
			[Token(Token = "0x60128B7")]
			[Address(RVA = "0x1CEAAC8", Offset = "0x1CEAAC8", VA = "0x1CEAAC8")]
			get
			{
				return default(DetachUserFromDeviceResponse);
			}
			[Token(Token = "0x60128B8")]
			[Address(RVA = "0x1CEAAD4", Offset = "0x1CEAAD4", VA = "0x1CEAAD4")]
			set
			{
			}
		}

		// Token: 0x060128B9 RID: 75961 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128B9")]
		[Address(RVA = "0x1CEAAE4", Offset = "0x1CEAAE4", VA = "0x1CEAAE4")]
		public DetachUserFromDeviceHttpCommand(long uidToDetach, string tokenOfUserToBeDetached)
		{
		}

		// Token: 0x060128BA RID: 75962 RVA: 0x00077418 File Offset: 0x00075618
		[Token(Token = "0x60128BA")]
		[Address(RVA = "0x1CEAB1C", Offset = "0x1CEAB1C", VA = "0x1CEAB1C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060128BB RID: 75963 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128BB")]
		[Address(RVA = "0x1CEAB64", Offset = "0x1CEAB64", VA = "0x1CEAB64", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060128BC RID: 75964 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128BC")]
		[Address(RVA = "0x1CEAD34", Offset = "0x1CEAD34", VA = "0x1CEAD34", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EABC RID: 60092
		[Token(Token = "0x400EABC")]
		[FieldOffset(Offset = "0x18")]
		private DetachUserFromDeviceResponse <Response>k__BackingField;

		// Token: 0x0400EABD RID: 60093
		[Token(Token = "0x400EABD")]
		[FieldOffset(Offset = "0x28")]
		private readonly long uidToDetach;

		// Token: 0x0400EABE RID: 60094
		[Token(Token = "0x400EABE")]
		[FieldOffset(Offset = "0x30")]
		private readonly string tokenOfUserToBeDetached;
	}
}
