﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Friends
{
	// Token: 0x02002568 RID: 9576
	[Token(Token = "0x2002568")]
	public enum FriendRequestSource
	{
		// Token: 0x0400EBD6 RID: 60374
		[Token(Token = "0x400EBD6")]
		CodeInvite = 1,
		// Token: 0x0400EBD7 RID: 60375
		[Token(Token = "0x400EBD7")]
		DeepLink,
		// Token: 0x0400EBD8 RID: 60376
		[Token(Token = "0x400EBD8")]
		AcceptRequest,
		// Token: 0x0400EBD9 RID: 60377
		[Token(Token = "0x400EBD9")]
		RejectRequest,
		// Token: 0x0400EBDA RID: 60378
		[Token(Token = "0x400EBDA")]
		RemoveFriend,
		// Token: 0x0400EBDB RID: 60379
		[Token(Token = "0x400EBDB")]
		UserProfile,
		// Token: 0x0400EBDC RID: 60380
		[Token(Token = "0x400EBDC")]
		Suggested,
		// Token: 0x0400EBDD RID: 60381
		[Token(Token = "0x400EBDD")]
		SuggestedDismiss
	}
}
