﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.Social
{
	// Token: 0x02002544 RID: 9540
	[Token(Token = "0x2002544")]
	public class GetTeamHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002742 RID: 10050
		// (get) Token: 0x06012A62 RID: 76386 RVA: 0x000783F0 File Offset: 0x000765F0
		[Token(Token = "0x17002742")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012A62")]
			[Address(RVA = "0x1ECA364", Offset = "0x1ECA364", VA = "0x1ECA364", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002743 RID: 10051
		// (get) Token: 0x06012A63 RID: 76387 RVA: 0x00078408 File Offset: 0x00076608
		[Token(Token = "0x17002743")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A63")]
			[Address(RVA = "0x1ECA36C", Offset = "0x1ECA36C", VA = "0x1ECA36C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002744 RID: 10052
		// (get) Token: 0x06012A64 RID: 76388 RVA: 0x00078420 File Offset: 0x00076620
		// (set) Token: 0x06012A65 RID: 76389 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002744")]
		public GetTeamInfoResponse Response
		{
			[Token(Token = "0x6012A64")]
			[Address(RVA = "0x1ECA374", Offset = "0x1ECA374", VA = "0x1ECA374")]
			get
			{
				return default(GetTeamInfoResponse);
			}
			[Token(Token = "0x6012A65")]
			[Address(RVA = "0x1ECA380", Offset = "0x1ECA380", VA = "0x1ECA380")]
			private set
			{
			}
		}

		// Token: 0x06012A66 RID: 76390 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A66")]
		[Address(RVA = "0x1ECA390", Offset = "0x1ECA390", VA = "0x1ECA390")]
		public GetTeamHttpCommand(long teamId, bool includeMembers)
		{
		}

		// Token: 0x06012A67 RID: 76391 RVA: 0x00078438 File Offset: 0x00076638
		[Token(Token = "0x6012A67")]
		[Address(RVA = "0x1ECA3C0", Offset = "0x1ECA3C0", VA = "0x1ECA3C0", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A68 RID: 76392 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A68")]
		[Address(RVA = "0x1ECA3E4", Offset = "0x1ECA3E4", VA = "0x1ECA3E4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A69 RID: 76393 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A69")]
		[Address(RVA = "0x1ECA4D8", Offset = "0x1ECA4D8", VA = "0x1ECA4D8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB73 RID: 60275
		[Token(Token = "0x400EB73")]
		[FieldOffset(Offset = "0x18")]
		private GetTeamInfoResponse <Response>k__BackingField;

		// Token: 0x0400EB74 RID: 60276
		[Token(Token = "0x400EB74")]
		[FieldOffset(Offset = "0x28")]
		private readonly long teamId;

		// Token: 0x0400EB75 RID: 60277
		[Token(Token = "0x400EB75")]
		[FieldOffset(Offset = "0x30")]
		private readonly bool includeMembers;
	}
}
