﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.UserProfile
{
	// Token: 0x02002529 RID: 9513
	[Token(Token = "0x2002529")]
	public class GetStatHistoryHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002702 RID: 9986
		// (get) Token: 0x060129A2 RID: 76194 RVA: 0x00077B38 File Offset: 0x00075D38
		[Token(Token = "0x17002702")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129A2")]
			[Address(RVA = "0x1CF9A78", Offset = "0x1CF9A78", VA = "0x1CF9A78", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002703 RID: 9987
		// (get) Token: 0x060129A3 RID: 76195 RVA: 0x00077B50 File Offset: 0x00075D50
		[Token(Token = "0x17002703")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129A3")]
			[Address(RVA = "0x1CF9A80", Offset = "0x1CF9A80", VA = "0x1CF9A80", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002704 RID: 9988
		// (get) Token: 0x060129A4 RID: 76196 RVA: 0x00077B68 File Offset: 0x00075D68
		// (set) Token: 0x060129A5 RID: 76197 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002704")]
		private GetStatHistoryResponse Response
		{
			[Token(Token = "0x60129A4")]
			[Address(RVA = "0x1CF9A88", Offset = "0x1CF9A88", VA = "0x1CF9A88")]
			get
			{
				return default(GetStatHistoryResponse);
			}
			[Token(Token = "0x60129A5")]
			[Address(RVA = "0x1CF9A94", Offset = "0x1CF9A94", VA = "0x1CF9A94")]
			set
			{
			}
		}

		// Token: 0x060129A6 RID: 76198 RVA: 0x00077B80 File Offset: 0x00075D80
		[Token(Token = "0x60129A6")]
		[Address(RVA = "0x1CF9AA4", Offset = "0x1CF9AA4", VA = "0x1CF9AA4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129A7 RID: 76199 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129A7")]
		[Address(RVA = "0x1CF9B24", Offset = "0x1CF9B24", VA = "0x1CF9B24", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129A8 RID: 76200 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129A8")]
		[Address(RVA = "0x1CF9DB4", Offset = "0x1CF9DB4", VA = "0x1CF9DB4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x060129A9 RID: 76201 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129A9")]
		[Address(RVA = "0x1CF9DB8", Offset = "0x1CF9DB8", VA = "0x1CF9DB8")]
		public GetStatHistoryHttpCommand()
		{
		}

		// Token: 0x0400EB1E RID: 60190
		[Token(Token = "0x400EB1E")]
		[FieldOffset(Offset = "0x18")]
		private GetStatHistoryResponse <Response>k__BackingField;

		// Token: 0x0400EB1F RID: 60191
		[Token(Token = "0x400EB1F")]
		[FieldOffset(Offset = "0x28")]
		private long requestUserId;
	}
}
