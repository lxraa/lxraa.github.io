﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Infrastructure.Services.Storage.Tables;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TrainJourney
{
	// Token: 0x02002531 RID: 9521
	[Token(Token = "0x2002531")]
	public class SendTrainJourneyInvitationHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002716 RID: 10006
		// (get) Token: 0x060129DC RID: 76252 RVA: 0x00077E08 File Offset: 0x00076008
		[Token(Token = "0x17002716")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129DC")]
			[Address(RVA = "0x1CFB524", Offset = "0x1CFB524", VA = "0x1CFB524", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002717 RID: 10007
		// (get) Token: 0x060129DD RID: 76253 RVA: 0x00077E20 File Offset: 0x00076020
		[Token(Token = "0x17002717")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129DD")]
			[Address(RVA = "0x1CFB52C", Offset = "0x1CFB52C", VA = "0x1CFB52C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060129DE RID: 76254 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129DE")]
		[Address(RVA = "0x1CFB534", Offset = "0x1CFB534", VA = "0x1CFB534")]
		public SendTrainJourneyInvitationHttpCommand(TrainJourneyUserProfileTableItem invitedUserProfile, CoopEventInvitationType type, bool isTeamInvite, bool isFriend, Action onCommandFinished)
		{
		}

		// Token: 0x060129DF RID: 76255 RVA: 0x00077E38 File Offset: 0x00076038
		[Token(Token = "0x60129DF")]
		[Address(RVA = "0x1CFB810", Offset = "0x1CFB810", VA = "0x1CFB810", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129E0 RID: 76256 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129E0")]
		[Address(RVA = "0x1CFB844", Offset = "0x1CFB844", VA = "0x1CFB844", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129E1 RID: 76257 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129E1")]
		[Address(RVA = "0x1CFBCC8", Offset = "0x1CFBCC8", VA = "0x1CFBCC8", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB30 RID: 60208
		[Token(Token = "0x400EB30")]
		[FieldOffset(Offset = "0x18")]
		private readonly TrainJourneyUserProfileTableItem invitedUserProfile;

		// Token: 0x0400EB31 RID: 60209
		[Token(Token = "0x400EB31")]
		[FieldOffset(Offset = "0x20")]
		private readonly CoopEventInvitationType invitationType;

		// Token: 0x0400EB32 RID: 60210
		[Token(Token = "0x400EB32")]
		[FieldOffset(Offset = "0x21")]
		private readonly bool isFriend;

		// Token: 0x0400EB33 RID: 60211
		[Token(Token = "0x400EB33")]
		[FieldOffset(Offset = "0x22")]
		private readonly bool isTeamInvite;

		// Token: 0x0400EB34 RID: 60212
		[Token(Token = "0x400EB34")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action onCommandFinished;
	}
}
