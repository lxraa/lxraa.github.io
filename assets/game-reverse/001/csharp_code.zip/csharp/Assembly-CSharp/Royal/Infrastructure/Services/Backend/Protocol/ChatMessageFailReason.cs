﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002354 RID: 9044
	[Token(Token = "0x2002354")]
	public enum ChatMessageFailReason : sbyte
	{
		// Token: 0x0400E647 RID: 58951
		[Token(Token = "0x400E647")]
		None,
		// Token: 0x0400E648 RID: 58952
		[Token(Token = "0x400E648")]
		USER_NAME_CONTAINS_SLANG,
		// Token: 0x0400E649 RID: 58953
		[Token(Token = "0x400E649")]
		TEAM_NAME_CONTAINS_SLANG,
		// Token: 0x0400E64A RID: 58954
		[Token(Token = "0x400E64A")]
		TEAM_DESCRIPTION_CONTAINS_SLANG,
		// Token: 0x0400E64B RID: 58955
		[Token(Token = "0x400E64B")]
		CHAT_MESSAGE_CONTAINS_SLANG,
		// Token: 0x0400E64C RID: 58956
		[Token(Token = "0x400E64C")]
		CHAT_MESSAGE_CONTAINS_SLANG_WARN,
		// Token: 0x0400E64D RID: 58957
		[Token(Token = "0x400E64D")]
		CHAT_MESSAGE_CONTAINS_SLANG_BAN,
		// Token: 0x0400E64E RID: 58958
		[Token(Token = "0x400E64E")]
		HAS_TEAM_HOPPING_BAN,
		// Token: 0x0400E64F RID: 58959
		[Token(Token = "0x400E64F")]
		TEXT_REJECTED_FOR_PROFANITY_CHECK
	}
}
