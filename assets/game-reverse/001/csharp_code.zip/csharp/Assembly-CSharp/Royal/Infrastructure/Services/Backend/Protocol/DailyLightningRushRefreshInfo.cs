﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002378 RID: 9080
	[Token(Token = "0x2002378")]
	public struct DailyLightningRushRefreshInfo : IFlatbufferObject
	{
		// Token: 0x17001FAB RID: 8107
		// (get) Token: 0x06010EBC RID: 69308 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FAB")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010EBC")]
			[Address(RVA = "0x1F9421C", Offset = "0x1F9421C", VA = "0x1F9421C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EBD RID: 69309 RVA: 0x000627D8 File Offset: 0x000609D8
		[Token(Token = "0x6010EBD")]
		[Address(RVA = "0x1F94224", Offset = "0x1F94224", VA = "0x1F94224")]
		public static DailyLightningRushRefreshInfo GetRootAsDailyLightningRushRefreshInfo(ByteBuffer _bb)
		{
			return default(DailyLightningRushRefreshInfo);
		}

		// Token: 0x06010EBE RID: 69310 RVA: 0x000627F0 File Offset: 0x000609F0
		[Token(Token = "0x6010EBE")]
		[Address(RVA = "0x1F94230", Offset = "0x1F94230", VA = "0x1F94230")]
		public static DailyLightningRushRefreshInfo GetRootAsDailyLightningRushRefreshInfo(ByteBuffer _bb, DailyLightningRushRefreshInfo obj)
		{
			return default(DailyLightningRushRefreshInfo);
		}

		// Token: 0x06010EBF RID: 69311 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EBF")]
		[Address(RVA = "0x1F942E0", Offset = "0x1F942E0", VA = "0x1F942E0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010EC0 RID: 69312 RVA: 0x00062808 File Offset: 0x00060A08
		[Token(Token = "0x6010EC0")]
		[Address(RVA = "0x1F942A8", Offset = "0x1F942A8", VA = "0x1F942A8")]
		public DailyLightningRushRefreshInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DailyLightningRushRefreshInfo);
		}

		// Token: 0x17001FAC RID: 8108
		// (get) Token: 0x06010EC1 RID: 69313 RVA: 0x00062820 File Offset: 0x00060A20
		[Token(Token = "0x17001FAC")]
		public DailyLightningRushInfo? ServerDailyLightningRushInfo
		{
			[Token(Token = "0x6010EC1")]
			[Address(RVA = "0x1F942F0", Offset = "0x1F942F0", VA = "0x1F942F0")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FAD RID: 8109
		// (get) Token: 0x06010EC2 RID: 69314 RVA: 0x00062838 File Offset: 0x00060A38
		[Token(Token = "0x17001FAD")]
		public DailyLightningRushInfo? UserDailyLightningRushInfo
		{
			[Token(Token = "0x6010EC2")]
			[Address(RVA = "0x1F943A8", Offset = "0x1F943A8", VA = "0x1F943A8")]
			get
			{
				return null;
			}
		}

		// Token: 0x17001FAE RID: 8110
		// (get) Token: 0x06010EC3 RID: 69315 RVA: 0x00062850 File Offset: 0x00060A50
		[Token(Token = "0x17001FAE")]
		public DailyLightningRushGroupInfo? DailyLightningRushGroupInfo
		{
			[Token(Token = "0x6010EC3")]
			[Address(RVA = "0x1F94460", Offset = "0x1F94460", VA = "0x1F94460")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010EC4 RID: 69316 RVA: 0x00062868 File Offset: 0x00060A68
		[Token(Token = "0x6010EC4")]
		[Address(RVA = "0x1F94518", Offset = "0x1F94518", VA = "0x1F94518")]
		public static Offset<DailyLightningRushRefreshInfo> CreateDailyLightningRushRefreshInfo(FlatBufferBuilder builder, [Optional] Offset<DailyLightningRushInfo> server_daily_lightning_rush_infoOffset, [Optional] Offset<DailyLightningRushInfo> user_daily_lightning_rush_infoOffset, [Optional] Offset<DailyLightningRushGroupInfo> daily_lightning_rush_group_infoOffset)
		{
			return default(Offset<DailyLightningRushRefreshInfo>);
		}

		// Token: 0x06010EC5 RID: 69317 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EC5")]
		[Address(RVA = "0x1F94654", Offset = "0x1F94654", VA = "0x1F94654")]
		public static void StartDailyLightningRushRefreshInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010EC6 RID: 69318 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EC6")]
		[Address(RVA = "0x1F945C8", Offset = "0x1F945C8", VA = "0x1F945C8")]
		public static void AddServerDailyLightningRushInfo(FlatBufferBuilder builder, Offset<DailyLightningRushInfo> serverDailyLightningRushInfoOffset)
		{
		}

		// Token: 0x06010EC7 RID: 69319 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EC7")]
		[Address(RVA = "0x1F945A8", Offset = "0x1F945A8", VA = "0x1F945A8")]
		public static void AddUserDailyLightningRushInfo(FlatBufferBuilder builder, Offset<DailyLightningRushInfo> userDailyLightningRushInfoOffset)
		{
		}

		// Token: 0x06010EC8 RID: 69320 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EC8")]
		[Address(RVA = "0x1F94588", Offset = "0x1F94588", VA = "0x1F94588")]
		public static void AddDailyLightningRushGroupInfo(FlatBufferBuilder builder, Offset<DailyLightningRushGroupInfo> dailyLightningRushGroupInfoOffset)
		{
		}

		// Token: 0x06010EC9 RID: 69321 RVA: 0x00062880 File Offset: 0x00060A80
		[Token(Token = "0x6010EC9")]
		[Address(RVA = "0x1F945E8", Offset = "0x1F945E8", VA = "0x1F945E8")]
		public static Offset<DailyLightningRushRefreshInfo> EndDailyLightningRushRefreshInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DailyLightningRushRefreshInfo>);
		}

		// Token: 0x0400E691 RID: 59025
		[Token(Token = "0x400E691")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
