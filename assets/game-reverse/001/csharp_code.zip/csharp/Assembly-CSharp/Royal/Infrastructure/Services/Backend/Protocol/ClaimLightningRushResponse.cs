﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200235F RID: 9055
	[Token(Token = "0x200235F")]
	public struct ClaimLightningRushResponse : IFlatbufferObject
	{
		// Token: 0x17001F38 RID: 7992
		// (get) Token: 0x06010D36 RID: 68918 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F38")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010D36")]
			[Address(RVA = "0x21493BC", Offset = "0x21493BC", VA = "0x21493BC", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010D37 RID: 68919 RVA: 0x00061470 File Offset: 0x0005F670
		[Token(Token = "0x6010D37")]
		[Address(RVA = "0x21493C4", Offset = "0x21493C4", VA = "0x21493C4")]
		public static ClaimLightningRushResponse GetRootAsClaimLightningRushResponse(ByteBuffer _bb)
		{
			return default(ClaimLightningRushResponse);
		}

		// Token: 0x06010D38 RID: 68920 RVA: 0x00061488 File Offset: 0x0005F688
		[Token(Token = "0x6010D38")]
		[Address(RVA = "0x21493D0", Offset = "0x21493D0", VA = "0x21493D0")]
		public static ClaimLightningRushResponse GetRootAsClaimLightningRushResponse(ByteBuffer _bb, ClaimLightningRushResponse obj)
		{
			return default(ClaimLightningRushResponse);
		}

		// Token: 0x06010D39 RID: 68921 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D39")]
		[Address(RVA = "0x2149480", Offset = "0x2149480", VA = "0x2149480", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010D3A RID: 68922 RVA: 0x000614A0 File Offset: 0x0005F6A0
		[Token(Token = "0x6010D3A")]
		[Address(RVA = "0x2149448", Offset = "0x2149448", VA = "0x2149448")]
		public ClaimLightningRushResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(ClaimLightningRushResponse);
		}

		// Token: 0x17001F39 RID: 7993
		// (get) Token: 0x06010D3B RID: 68923 RVA: 0x000614B8 File Offset: 0x0005F6B8
		[Token(Token = "0x17001F39")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010D3B")]
			[Address(RVA = "0x2149490", Offset = "0x2149490", VA = "0x2149490")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x06010D3C RID: 68924 RVA: 0x000614D0 File Offset: 0x0005F6D0
		[Token(Token = "0x6010D3C")]
		[Address(RVA = "0x21494D4", Offset = "0x21494D4", VA = "0x21494D4")]
		public static Offset<ClaimLightningRushResponse> CreateClaimLightningRushResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success)
		{
			return default(Offset<ClaimLightningRushResponse>);
		}

		// Token: 0x06010D3D RID: 68925 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D3D")]
		[Address(RVA = "0x21495A8", Offset = "0x21495A8", VA = "0x21495A8")]
		public static void StartClaimLightningRushResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010D3E RID: 68926 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D3E")]
		[Address(RVA = "0x214951C", Offset = "0x214951C", VA = "0x214951C")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010D3F RID: 68927 RVA: 0x000614E8 File Offset: 0x0005F6E8
		[Token(Token = "0x6010D3F")]
		[Address(RVA = "0x214953C", Offset = "0x214953C", VA = "0x214953C")]
		public static Offset<ClaimLightningRushResponse> EndClaimLightningRushResponse(FlatBufferBuilder builder)
		{
			return default(Offset<ClaimLightningRushResponse>);
		}

		// Token: 0x06010D40 RID: 68928 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D40")]
		[Address(RVA = "0x21495C0", Offset = "0x21495C0", VA = "0x21495C0")]
		public static void FinishClaimLightningRushResponseBuffer(FlatBufferBuilder builder, Offset<ClaimLightningRushResponse> offset)
		{
		}

		// Token: 0x06010D41 RID: 68929 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010D41")]
		[Address(RVA = "0x21495D4", Offset = "0x21495D4", VA = "0x21495D4")]
		public static void FinishSizePrefixedClaimLightningRushResponseBuffer(FlatBufferBuilder builder, Offset<ClaimLightningRushResponse> offset)
		{
		}

		// Token: 0x0400E665 RID: 58981
		[Token(Token = "0x400E665")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
