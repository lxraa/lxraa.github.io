﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D6 RID: 9174
	[Token(Token = "0x20023D6")]
	public struct GetFriendsRequest : IFlatbufferObject
	{
		// Token: 0x170020FB RID: 8443
		// (get) Token: 0x060113D7 RID: 70615 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020FB")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60113D7")]
			[Address(RVA = "0x1CB0654", Offset = "0x1CB0654", VA = "0x1CB0654", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060113D8 RID: 70616 RVA: 0x00066C18 File Offset: 0x00064E18
		[Token(Token = "0x60113D8")]
		[Address(RVA = "0x1CB065C", Offset = "0x1CB065C", VA = "0x1CB065C")]
		public static GetFriendsRequest GetRootAsGetFriendsRequest(ByteBuffer _bb)
		{
			return default(GetFriendsRequest);
		}

		// Token: 0x060113D9 RID: 70617 RVA: 0x00066C30 File Offset: 0x00064E30
		[Token(Token = "0x60113D9")]
		[Address(RVA = "0x1CB0668", Offset = "0x1CB0668", VA = "0x1CB0668")]
		public static GetFriendsRequest GetRootAsGetFriendsRequest(ByteBuffer _bb, GetFriendsRequest obj)
		{
			return default(GetFriendsRequest);
		}

		// Token: 0x060113DA RID: 70618 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113DA")]
		[Address(RVA = "0x1CB0718", Offset = "0x1CB0718", VA = "0x1CB0718", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060113DB RID: 70619 RVA: 0x00066C48 File Offset: 0x00064E48
		[Token(Token = "0x60113DB")]
		[Address(RVA = "0x1CB06E0", Offset = "0x1CB06E0", VA = "0x1CB06E0")]
		public GetFriendsRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetFriendsRequest);
		}

		// Token: 0x170020FC RID: 8444
		// (get) Token: 0x060113DC RID: 70620 RVA: 0x00066C60 File Offset: 0x00064E60
		[Token(Token = "0x170020FC")]
		public bool IsSuggestionRequired
		{
			[Token(Token = "0x60113DC")]
			[Address(RVA = "0x1CB0728", Offset = "0x1CB0728", VA = "0x1CB0728")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x060113DD RID: 70621 RVA: 0x00066C78 File Offset: 0x00064E78
		[Token(Token = "0x60113DD")]
		[Address(RVA = "0x1CB0770", Offset = "0x1CB0770", VA = "0x1CB0770")]
		public static Offset<GetFriendsRequest> CreateGetFriendsRequest(FlatBufferBuilder builder, bool is_suggestion_required = false)
		{
			return default(Offset<GetFriendsRequest>);
		}

		// Token: 0x060113DE RID: 70622 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113DE")]
		[Address(RVA = "0x1CB0844", Offset = "0x1CB0844", VA = "0x1CB0844")]
		public static void StartGetFriendsRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060113DF RID: 70623 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113DF")]
		[Address(RVA = "0x1CB07B8", Offset = "0x1CB07B8", VA = "0x1CB07B8")]
		public static void AddIsSuggestionRequired(FlatBufferBuilder builder, bool isSuggestionRequired)
		{
		}

		// Token: 0x060113E0 RID: 70624 RVA: 0x00066C90 File Offset: 0x00064E90
		[Token(Token = "0x60113E0")]
		[Address(RVA = "0x1CB07D8", Offset = "0x1CB07D8", VA = "0x1CB07D8")]
		public static Offset<GetFriendsRequest> EndGetFriendsRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetFriendsRequest>);
		}

		// Token: 0x0400E746 RID: 59206
		[Token(Token = "0x400E746")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
