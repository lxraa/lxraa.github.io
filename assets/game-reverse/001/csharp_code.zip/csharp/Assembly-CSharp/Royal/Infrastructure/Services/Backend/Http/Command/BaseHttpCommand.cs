﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002511 RID: 9489
	[Token(Token = "0x2002511")]
	public abstract class BaseHttpCommand
	{
		// Token: 0x170026C3 RID: 9923
		// (get) Token: 0x0601289D RID: 75933
		[Token(Token = "0x170026C3")]
		public abstract RequestType RequestType { [Token(Token = "0x601289D")] get; }

		// Token: 0x170026C4 RID: 9924
		// (get) Token: 0x0601289E RID: 75934
		[Token(Token = "0x170026C4")]
		public abstract ResponseType ResponseType { [Token(Token = "0x601289E")] get; }

		// Token: 0x170026C5 RID: 9925
		// (get) Token: 0x0601289F RID: 75935 RVA: 0x000772F8 File Offset: 0x000754F8
		// (set) Token: 0x060128A0 RID: 75936 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026C5")]
		public bool PreventAnyCommandCheck
		{
			[Token(Token = "0x601289F")]
			[Address(RVA = "0x1CEA7C8", Offset = "0x1CEA7C8", VA = "0x1CEA7C8")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x60128A0")]
			[Address(RVA = "0x1CEA7D0", Offset = "0x1CEA7D0", VA = "0x1CEA7D0")]
			protected set
			{
			}
		}

		// Token: 0x170026C6 RID: 9926
		// (get) Token: 0x060128A1 RID: 75937 RVA: 0x00077310 File Offset: 0x00075510
		// (set) Token: 0x060128A2 RID: 75938 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026C6")]
		public bool ShouldDismissSameCommand
		{
			[Token(Token = "0x60128A1")]
			[Address(RVA = "0x1CEA7DC", Offset = "0x1CEA7DC", VA = "0x1CEA7DC")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x60128A2")]
			[Address(RVA = "0x1CEA7E4", Offset = "0x1CEA7E4", VA = "0x1CEA7E4")]
			protected set
			{
			}
		}

		// Token: 0x170026C7 RID: 9927
		// (get) Token: 0x060128A3 RID: 75939 RVA: 0x00077328 File Offset: 0x00075528
		// (set) Token: 0x060128A4 RID: 75940 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026C7")]
		public bool IsSuccess
		{
			[Token(Token = "0x60128A3")]
			[Address(RVA = "0x1CEA7F0", Offset = "0x1CEA7F0", VA = "0x1CEA7F0")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x60128A4")]
			[Address(RVA = "0x1CEA7F8", Offset = "0x1CEA7F8", VA = "0x1CEA7F8")]
			private set
			{
			}
		}

		// Token: 0x060128A5 RID: 75941
		[Token(Token = "0x60128A5")]
		public abstract int Build(FlatBufferBuilder builder);

		// Token: 0x060128A6 RID: 75942
		[Token(Token = "0x60128A6")]
		public abstract void Finish(int packageId, ResponsePackage package, int index);

		// Token: 0x060128A7 RID: 75943
		[Token(Token = "0x60128A7")]
		public abstract void PackageFail();

		// Token: 0x060128A8 RID: 75944 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128A8")]
		[Address(RVA = "0x1CEA804", Offset = "0x1CEA804", VA = "0x1CEA804")]
		protected void UpdateResponseStatus(ResponseStatusCode responseStatus)
		{
		}

		// Token: 0x060128A9 RID: 75945 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60128A9")]
		protected T ParseResponse<T>(ResponsePackage package, int index) where T : struct, IFlatbufferObject
		{
			return null;
		}

		// Token: 0x060128AA RID: 75946 RVA: 0x00077340 File Offset: 0x00075540
		[Token(Token = "0x60128AA")]
		[Address(RVA = "0x1CEA814", Offset = "0x1CEA814", VA = "0x1CEA814")]
		protected Offset<CurrentUserInventory> CreateCurrentUserInventory(FlatBufferBuilder builder)
		{
			return default(Offset<CurrentUserInventory>);
		}

		// Token: 0x060128AB RID: 75947 RVA: 0x00077358 File Offset: 0x00075558
		[Token(Token = "0x60128AB")]
		[Address(RVA = "0x1CEA8D8", Offset = "0x1CEA8D8", VA = "0x1CEA8D8", Slot = "9")]
		public virtual bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x060128AC RID: 75948 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128AC")]
		[Address(RVA = "0x1CEA8E0", Offset = "0x1CEA8E0", VA = "0x1CEA8E0")]
		protected BaseHttpCommand()
		{
		}

		// Token: 0x0400EAB8 RID: 60088
		[Token(Token = "0x400EAB8")]
		[FieldOffset(Offset = "0x10")]
		private bool <PreventAnyCommandCheck>k__BackingField;

		// Token: 0x0400EAB9 RID: 60089
		[Token(Token = "0x400EAB9")]
		[FieldOffset(Offset = "0x11")]
		private bool <ShouldDismissSameCommand>k__BackingField;

		// Token: 0x0400EABA RID: 60090
		[Token(Token = "0x400EABA")]
		[FieldOffset(Offset = "0x12")]
		private bool <IsSuccess>k__BackingField;
	}
}
