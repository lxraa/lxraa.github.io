﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Contexts.Units.App
{
	// Token: 0x020025BD RID: 9661
	[Token(Token = "0x20025BD")]
	public class AppManager : IContextUnit
	{
		// Token: 0x170027F5 RID: 10229
		// (get) Token: 0x06012E56 RID: 77398 RVA: 0x0007A238 File Offset: 0x00078438
		[Token(Token = "0x170027F5")]
		public int Id
		{
			[Token(Token = "0x6012E56")]
			[Address(RVA = "0x244A314", Offset = "0x244A314", VA = "0x244A314", Slot = "4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170027F6 RID: 10230
		// (get) Token: 0x06012E57 RID: 77399 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170027F6")]
		public static string StoreUrl
		{
			[Token(Token = "0x6012E57")]
			[Address(RVA = "0x244A31C", Offset = "0x244A31C", VA = "0x244A31C")]
			get
			{
				return null;
			}
		}

		// Token: 0x170027F7 RID: 10231
		// (get) Token: 0x06012E58 RID: 77400 RVA: 0x0007A250 File Offset: 0x00078450
		// (set) Token: 0x06012E59 RID: 77401 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027F7")]
		public static float CurrentSessionTime
		{
			[Token(Token = "0x6012E58")]
			[Address(RVA = "0x244A35C", Offset = "0x244A35C", VA = "0x244A35C")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6012E59")]
			[Address(RVA = "0x244A3A4", Offset = "0x244A3A4", VA = "0x244A3A4")]
			private set
			{
			}
		}

		// Token: 0x170027F8 RID: 10232
		// (get) Token: 0x06012E5A RID: 77402 RVA: 0x0007A268 File Offset: 0x00078468
		// (set) Token: 0x06012E5B RID: 77403 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027F8")]
		public static float CurrentPausedTime
		{
			[Token(Token = "0x6012E5A")]
			[Address(RVA = "0x244A3F8", Offset = "0x244A3F8", VA = "0x244A3F8")]
			get
			{
				return 0f;
			}
			[Token(Token = "0x6012E5B")]
			[Address(RVA = "0x244A440", Offset = "0x244A440", VA = "0x244A440")]
			private set
			{
			}
		}

		// Token: 0x170027F9 RID: 10233
		// (get) Token: 0x06012E5C RID: 77404 RVA: 0x0007A280 File Offset: 0x00078480
		// (set) Token: 0x06012E5D RID: 77405 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027F9")]
		public static int FocusCount
		{
			[Token(Token = "0x6012E5C")]
			[Address(RVA = "0x244A494", Offset = "0x244A494", VA = "0x244A494")]
			get
			{
				return 0;
			}
			[Token(Token = "0x6012E5D")]
			[Address(RVA = "0x244A4DC", Offset = "0x244A4DC", VA = "0x244A4DC")]
			private set
			{
			}
		}

		// Token: 0x170027FA RID: 10234
		// (get) Token: 0x06012E5E RID: 77406 RVA: 0x0007A298 File Offset: 0x00078498
		// (set) Token: 0x06012E5F RID: 77407 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027FA")]
		public static bool IsPaused
		{
			[Token(Token = "0x6012E5E")]
			[Address(RVA = "0x244A528", Offset = "0x244A528", VA = "0x244A528")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012E5F")]
			[Address(RVA = "0x244A570", Offset = "0x244A570", VA = "0x244A570")]
			private set
			{
			}
		}

		// Token: 0x170027FB RID: 10235
		// (get) Token: 0x06012E60 RID: 77408 RVA: 0x0007A2B0 File Offset: 0x000784B0
		[Token(Token = "0x170027FB")]
		public bool AfterPaused
		{
			[Token(Token = "0x6012E60")]
			[Address(RVA = "0x244A5BC", Offset = "0x244A5BC", VA = "0x244A5BC")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170027FC RID: 10236
		// (get) Token: 0x06012E61 RID: 77409 RVA: 0x0007A2C8 File Offset: 0x000784C8
		// (set) Token: 0x06012E62 RID: 77410 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027FC")]
		public static long SessionCount
		{
			[Token(Token = "0x6012E61")]
			[Address(RVA = "0x244A5E4", Offset = "0x244A5E4", VA = "0x244A5E4")]
			get
			{
				return 0L;
			}
			[Token(Token = "0x6012E62")]
			[Address(RVA = "0x244A62C", Offset = "0x244A62C", VA = "0x244A62C")]
			private set
			{
			}
		}

		// Token: 0x170027FD RID: 10237
		// (get) Token: 0x06012E63 RID: 77411 RVA: 0x0007A2E0 File Offset: 0x000784E0
		// (set) Token: 0x06012E64 RID: 77412 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170027FD")]
		public static long AppInstallTime
		{
			[Token(Token = "0x6012E63")]
			[Address(RVA = "0x244A678", Offset = "0x244A678", VA = "0x244A678")]
			get
			{
				return 0L;
			}
			[Token(Token = "0x6012E64")]
			[Address(RVA = "0x244A6C0", Offset = "0x244A6C0", VA = "0x244A6C0")]
			set
			{
			}
		}

		// Token: 0x06012E65 RID: 77413 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E65")]
		[Address(RVA = "0x244A70C", Offset = "0x244A70C", VA = "0x244A70C", Slot = "5")]
		public void Bind()
		{
		}

		// Token: 0x06012E66 RID: 77414 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E66")]
		[Address(RVA = "0x244ABD4", Offset = "0x244ABD4", VA = "0x244ABD4")]
		public void Start()
		{
		}

		// Token: 0x06012E67 RID: 77415 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E67")]
		[Address(RVA = "0x244C21C", Offset = "0x244C21C", VA = "0x244C21C")]
		public void Clear()
		{
		}

		// Token: 0x06012E68 RID: 77416 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E68")]
		[Address(RVA = "0x244C9DC", Offset = "0x244C9DC", VA = "0x244C9DC")]
		public void ApplicationPaused()
		{
		}

		// Token: 0x06012E69 RID: 77417 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E69")]
		[Address(RVA = "0x244D224", Offset = "0x244D224", VA = "0x244D224")]
		public void ApplicationResumed()
		{
		}

		// Token: 0x06012E6A RID: 77418 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E6A")]
		[Address(RVA = "0x244D7A8", Offset = "0x244D7A8", VA = "0x244D7A8")]
		public void UpdateForceVersion(int version)
		{
		}

		// Token: 0x06012E6B RID: 77419 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E6B")]
		[Address(RVA = "0x244D83C", Offset = "0x244D83C", VA = "0x244D83C")]
		public void CheckForceUpdate()
		{
		}

		// Token: 0x06012E6C RID: 77420 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E6C")]
		[Address(RVA = "0x244D980", Offset = "0x244D980", VA = "0x244D980")]
		public void CheckForceUpdateAfterSceneContextsLoad(int oldScene, int newScene)
		{
		}

		// Token: 0x06012E6D RID: 77421 RVA: 0x0007A2F8 File Offset: 0x000784F8
		[Token(Token = "0x6012E6D")]
		[Address(RVA = "0x244D9BC", Offset = "0x244D9BC", VA = "0x244D9BC")]
		public bool IsShowingNativePopUpShouldNotFocusOut()
		{
			return default(bool);
		}

		// Token: 0x06012E6E RID: 77422 RVA: 0x0007A310 File Offset: 0x00078510
		[Token(Token = "0x6012E6E")]
		[Address(RVA = "0x244C7B0", Offset = "0x244C7B0", VA = "0x244C7B0")]
		private float CalculateCurrentSessionTime()
		{
			return 0f;
		}

		// Token: 0x06012E6F RID: 77423 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012E6F")]
		[Address(RVA = "0x244DA7C", Offset = "0x244DA7C", VA = "0x244DA7C")]
		public AppManager()
		{
		}

		// Token: 0x0400EE8A RID: 61066
		[Token(Token = "0x400EE8A")]
		[FieldOffset(Offset = "0x0")]
		private static float <CurrentSessionTime>k__BackingField;

		// Token: 0x0400EE8B RID: 61067
		[Token(Token = "0x400EE8B")]
		[FieldOffset(Offset = "0x4")]
		private static float <CurrentPausedTime>k__BackingField;

		// Token: 0x0400EE8C RID: 61068
		[Token(Token = "0x400EE8C")]
		[FieldOffset(Offset = "0x8")]
		private static int <FocusCount>k__BackingField;

		// Token: 0x0400EE8D RID: 61069
		[Token(Token = "0x400EE8D")]
		[FieldOffset(Offset = "0xC")]
		private static bool <IsPaused>k__BackingField;

		// Token: 0x0400EE8E RID: 61070
		[Token(Token = "0x400EE8E")]
		[FieldOffset(Offset = "0x10")]
		private static long <SessionCount>k__BackingField;

		// Token: 0x0400EE8F RID: 61071
		[Token(Token = "0x400EE8F")]
		[FieldOffset(Offset = "0x18")]
		private static long <AppInstallTime>k__BackingField;

		// Token: 0x0400EE90 RID: 61072
		[Token(Token = "0x400EE90")]
		[FieldOffset(Offset = "0x10")]
		public readonly VersionHelper versionHelper;

		// Token: 0x0400EE91 RID: 61073
		[Token(Token = "0x400EE91")]
		[FieldOffset(Offset = "0x18")]
		public readonly ConsentHelper consentHelper;

		// Token: 0x0400EE92 RID: 61074
		[Token(Token = "0x400EE92")]
		[FieldOffset(Offset = "0x20")]
		private readonly AppTerminationHelper terminationHelper;

		// Token: 0x0400EE93 RID: 61075
		[Token(Token = "0x400EE93")]
		[FieldOffset(Offset = "0x28")]
		private float pauseTime;

		// Token: 0x0400EE94 RID: 61076
		[Token(Token = "0x400EE94")]
		[FieldOffset(Offset = "0x2C")]
		private float sessionTime;
	}
}
