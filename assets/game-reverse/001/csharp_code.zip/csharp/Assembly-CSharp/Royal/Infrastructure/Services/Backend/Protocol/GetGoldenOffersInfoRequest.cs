﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023D8 RID: 9176
	[Token(Token = "0x20023D8")]
	public struct GetGoldenOffersInfoRequest : IFlatbufferObject
	{
		// Token: 0x17002100 RID: 8448
		// (get) Token: 0x060113F5 RID: 70645 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002100")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60113F5")]
			[Address(RVA = "0x1CB0EFC", Offset = "0x1CB0EFC", VA = "0x1CB0EFC", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060113F6 RID: 70646 RVA: 0x00066DE0 File Offset: 0x00064FE0
		[Token(Token = "0x60113F6")]
		[Address(RVA = "0x1CB0F04", Offset = "0x1CB0F04", VA = "0x1CB0F04")]
		public static GetGoldenOffersInfoRequest GetRootAsGetGoldenOffersInfoRequest(ByteBuffer _bb)
		{
			return default(GetGoldenOffersInfoRequest);
		}

		// Token: 0x060113F7 RID: 70647 RVA: 0x00066DF8 File Offset: 0x00064FF8
		[Token(Token = "0x60113F7")]
		[Address(RVA = "0x1CB0F10", Offset = "0x1CB0F10", VA = "0x1CB0F10")]
		public static GetGoldenOffersInfoRequest GetRootAsGetGoldenOffersInfoRequest(ByteBuffer _bb, GetGoldenOffersInfoRequest obj)
		{
			return default(GetGoldenOffersInfoRequest);
		}

		// Token: 0x060113F8 RID: 70648 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113F8")]
		[Address(RVA = "0x1CB0FC0", Offset = "0x1CB0FC0", VA = "0x1CB0FC0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060113F9 RID: 70649 RVA: 0x00066E10 File Offset: 0x00065010
		[Token(Token = "0x60113F9")]
		[Address(RVA = "0x1CB0F88", Offset = "0x1CB0F88", VA = "0x1CB0F88")]
		public GetGoldenOffersInfoRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetGoldenOffersInfoRequest);
		}

		// Token: 0x060113FA RID: 70650 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60113FA")]
		[Address(RVA = "0x1CB0FD0", Offset = "0x1CB0FD0", VA = "0x1CB0FD0")]
		public static void StartGetGoldenOffersInfoRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060113FB RID: 70651 RVA: 0x00066E28 File Offset: 0x00065028
		[Token(Token = "0x60113FB")]
		[Address(RVA = "0x1CB0FE8", Offset = "0x1CB0FE8", VA = "0x1CB0FE8")]
		public static Offset<GetGoldenOffersInfoRequest> EndGetGoldenOffersInfoRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetGoldenOffersInfoRequest>);
		}

		// Token: 0x0400E748 RID: 59208
		[Token(Token = "0x400E748")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
