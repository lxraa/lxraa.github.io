﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A3 RID: 9123
	[Token(Token = "0x20023A3")]
	public struct EnterLeagueResponse : IFlatbufferObject
	{
		// Token: 0x17002043 RID: 8259
		// (get) Token: 0x06011112 RID: 69906 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002043")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011112")]
			[Address(RVA = "0x1F9D33C", Offset = "0x1F9D33C", VA = "0x1F9D33C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011113 RID: 69907 RVA: 0x00064698 File Offset: 0x00062898
		[Token(Token = "0x6011113")]
		[Address(RVA = "0x1F9D344", Offset = "0x1F9D344", VA = "0x1F9D344")]
		public static EnterLeagueResponse GetRootAsEnterLeagueResponse(ByteBuffer _bb)
		{
			return default(EnterLeagueResponse);
		}

		// Token: 0x06011114 RID: 69908 RVA: 0x000646B0 File Offset: 0x000628B0
		[Token(Token = "0x6011114")]
		[Address(RVA = "0x1F9D350", Offset = "0x1F9D350", VA = "0x1F9D350")]
		public static EnterLeagueResponse GetRootAsEnterLeagueResponse(ByteBuffer _bb, EnterLeagueResponse obj)
		{
			return default(EnterLeagueResponse);
		}

		// Token: 0x06011115 RID: 69909 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011115")]
		[Address(RVA = "0x1F9D400", Offset = "0x1F9D400", VA = "0x1F9D400", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011116 RID: 69910 RVA: 0x000646C8 File Offset: 0x000628C8
		[Token(Token = "0x6011116")]
		[Address(RVA = "0x1F9D3C8", Offset = "0x1F9D3C8", VA = "0x1F9D3C8")]
		public EnterLeagueResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterLeagueResponse);
		}

		// Token: 0x17002044 RID: 8260
		// (get) Token: 0x06011117 RID: 69911 RVA: 0x000646E0 File Offset: 0x000628E0
		[Token(Token = "0x17002044")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6011117")]
			[Address(RVA = "0x1F9D410", Offset = "0x1F9D410", VA = "0x1F9D410")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17002045 RID: 8261
		// (get) Token: 0x06011118 RID: 69912 RVA: 0x000646F8 File Offset: 0x000628F8
		[Token(Token = "0x17002045")]
		public EnterLeagueFailReason FailReason
		{
			[Token(Token = "0x6011118")]
			[Address(RVA = "0x1F9D454", Offset = "0x1F9D454", VA = "0x1F9D454")]
			get
			{
				return EnterLeagueFailReason.None;
			}
		}

		// Token: 0x17002046 RID: 8262
		// (get) Token: 0x06011119 RID: 69913 RVA: 0x00064710 File Offset: 0x00062910
		[Token(Token = "0x17002046")]
		public long GroupId
		{
			[Token(Token = "0x6011119")]
			[Address(RVA = "0x1F9D498", Offset = "0x1F9D498", VA = "0x1F9D498")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x0601111A RID: 69914 RVA: 0x00064728 File Offset: 0x00062928
		[Token(Token = "0x601111A")]
		[Address(RVA = "0x1F9D4E0", Offset = "0x1F9D4E0", VA = "0x1F9D4E0")]
		public LeagueMember? Members(int j)
		{
			return null;
		}

		// Token: 0x17002047 RID: 8263
		// (get) Token: 0x0601111B RID: 69915 RVA: 0x00064740 File Offset: 0x00062940
		[Token(Token = "0x17002047")]
		public int MembersLength
		{
			[Token(Token = "0x601111B")]
			[Address(RVA = "0x1F9D5B8", Offset = "0x1F9D5B8", VA = "0x1F9D5B8")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002048 RID: 8264
		// (get) Token: 0x0601111C RID: 69916 RVA: 0x00064758 File Offset: 0x00062958
		[Token(Token = "0x17002048")]
		public LeagueConfig? DepreciatedLeagueConfig
		{
			[Token(Token = "0x601111C")]
			[Address(RVA = "0x1F9D5EC", Offset = "0x1F9D5EC", VA = "0x1F9D5EC")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002049 RID: 8265
		// (get) Token: 0x0601111D RID: 69917 RVA: 0x00064770 File Offset: 0x00062970
		[Token(Token = "0x17002049")]
		public long UserData
		{
			[Token(Token = "0x601111D")]
			[Address(RVA = "0x1F9D6AC", Offset = "0x1F9D6AC", VA = "0x1F9D6AC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x1700204A RID: 8266
		// (get) Token: 0x0601111E RID: 69918 RVA: 0x00064788 File Offset: 0x00062988
		[Token(Token = "0x1700204A")]
		public LeagueConfig? LeagueConfig
		{
			[Token(Token = "0x601111E")]
			[Address(RVA = "0x1F9D6F4", Offset = "0x1F9D6F4", VA = "0x1F9D6F4")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700204B RID: 8267
		// (get) Token: 0x0601111F RID: 69919 RVA: 0x000647A0 File Offset: 0x000629A0
		[Token(Token = "0x1700204B")]
		public int LeagueLevel
		{
			[Token(Token = "0x601111F")]
			[Address(RVA = "0x1F9D7B4", Offset = "0x1F9D7B4", VA = "0x1F9D7B4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011120 RID: 69920 RVA: 0x000647B8 File Offset: 0x000629B8
		[Token(Token = "0x6011120")]
		[Address(RVA = "0x1F9D7F8", Offset = "0x1F9D7F8", VA = "0x1F9D7F8")]
		public static Offset<EnterLeagueResponse> CreateEnterLeagueResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, EnterLeagueFailReason fail_reason = EnterLeagueFailReason.None, long group_id = 0L, [Optional] VectorOffset membersOffset, [Optional] Offset<LeagueConfig> depreciated_league_configOffset, long userData = 0L, [Optional] Offset<LeagueConfig> league_configOffset, int league_level = 0)
		{
			return default(Offset<EnterLeagueResponse>);
		}

		// Token: 0x06011121 RID: 69921 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011121")]
		[Address(RVA = "0x1F9DA34", Offset = "0x1F9DA34", VA = "0x1F9DA34")]
		public static void StartEnterLeagueResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011122 RID: 69922 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011122")]
		[Address(RVA = "0x1F9D9A8", Offset = "0x1F9D9A8", VA = "0x1F9D9A8")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06011123 RID: 69923 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011123")]
		[Address(RVA = "0x1F9D988", Offset = "0x1F9D988", VA = "0x1F9D988")]
		public static void AddFailReason(FlatBufferBuilder builder, EnterLeagueFailReason failReason)
		{
		}

		// Token: 0x06011124 RID: 69924 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011124")]
		[Address(RVA = "0x1F9D8E8", Offset = "0x1F9D8E8", VA = "0x1F9D8E8")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06011125 RID: 69925 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011125")]
		[Address(RVA = "0x1F9D968", Offset = "0x1F9D968", VA = "0x1F9D968")]
		public static void AddMembers(FlatBufferBuilder builder, VectorOffset membersOffset)
		{
		}

		// Token: 0x06011126 RID: 69926 RVA: 0x000647D0 File Offset: 0x000629D0
		[Token(Token = "0x6011126")]
		[Address(RVA = "0x1F9DA4C", Offset = "0x1F9DA4C", VA = "0x1F9DA4C")]
		public static VectorOffset CreateMembersVector(FlatBufferBuilder builder, Offset<LeagueMember>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011127 RID: 69927 RVA: 0x000647E8 File Offset: 0x000629E8
		[Token(Token = "0x6011127")]
		[Address(RVA = "0x1F9DAF4", Offset = "0x1F9DAF4", VA = "0x1F9DAF4")]
		public static VectorOffset CreateMembersVectorBlock(FlatBufferBuilder builder, Offset<LeagueMember>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011128 RID: 69928 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011128")]
		[Address(RVA = "0x1F9DB7C", Offset = "0x1F9DB7C", VA = "0x1F9DB7C")]
		public static void StartMembersVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011129 RID: 69929 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011129")]
		[Address(RVA = "0x1F9D948", Offset = "0x1F9D948", VA = "0x1F9D948")]
		public static void AddDepreciatedLeagueConfig(FlatBufferBuilder builder, Offset<LeagueConfig> depreciatedLeagueConfigOffset)
		{
		}

		// Token: 0x0601112A RID: 69930 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601112A")]
		[Address(RVA = "0x1F9D8C8", Offset = "0x1F9D8C8", VA = "0x1F9D8C8")]
		public static void AddUserData(FlatBufferBuilder builder, long userData)
		{
		}

		// Token: 0x0601112B RID: 69931 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601112B")]
		[Address(RVA = "0x1F9D928", Offset = "0x1F9D928", VA = "0x1F9D928")]
		public static void AddLeagueConfig(FlatBufferBuilder builder, Offset<LeagueConfig> leagueConfigOffset)
		{
		}

		// Token: 0x0601112C RID: 69932 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601112C")]
		[Address(RVA = "0x1F9D908", Offset = "0x1F9D908", VA = "0x1F9D908")]
		public static void AddLeagueLevel(FlatBufferBuilder builder, int leagueLevel)
		{
		}

		// Token: 0x0601112D RID: 69933 RVA: 0x00064800 File Offset: 0x00062A00
		[Token(Token = "0x601112D")]
		[Address(RVA = "0x1F9D9C8", Offset = "0x1F9D9C8", VA = "0x1F9D9C8")]
		public static Offset<EnterLeagueResponse> EndEnterLeagueResponse(FlatBufferBuilder builder)
		{
			return default(Offset<EnterLeagueResponse>);
		}

		// Token: 0x0400E6D1 RID: 59089
		[Token(Token = "0x400E6D1")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
