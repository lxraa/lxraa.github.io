﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x02002519 RID: 9497
	[Token(Token = "0x2002519")]
	public class PingHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026DA RID: 9946
		// (get) Token: 0x060128E1 RID: 76001 RVA: 0x000775C8 File Offset: 0x000757C8
		[Token(Token = "0x170026DA")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60128E1")]
			[Address(RVA = "0x1CEBA40", Offset = "0x1CEBA40", VA = "0x1CEBA40", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026DB RID: 9947
		// (get) Token: 0x060128E2 RID: 76002 RVA: 0x000775E0 File Offset: 0x000757E0
		[Token(Token = "0x170026DB")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60128E2")]
			[Address(RVA = "0x1CEBA48", Offset = "0x1CEBA48", VA = "0x1CEBA48", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060128E3 RID: 76003 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128E3")]
		[Address(RVA = "0x1CE8264", Offset = "0x1CE8264", VA = "0x1CE8264")]
		public PingHttpCommand(bool afterLogout = false)
		{
		}

		// Token: 0x170026DC RID: 9948
		// (get) Token: 0x060128E4 RID: 76004 RVA: 0x000775F8 File Offset: 0x000757F8
		// (set) Token: 0x060128E5 RID: 76005 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026DC")]
		private PingResponse Response
		{
			[Token(Token = "0x60128E4")]
			[Address(RVA = "0x1CEBA50", Offset = "0x1CEBA50", VA = "0x1CEBA50")]
			get
			{
				return default(PingResponse);
			}
			[Token(Token = "0x60128E5")]
			[Address(RVA = "0x1CEBA5C", Offset = "0x1CEBA5C", VA = "0x1CEBA5C")]
			set
			{
			}
		}

		// Token: 0x060128E6 RID: 76006 RVA: 0x00077610 File Offset: 0x00075810
		[Token(Token = "0x60128E6")]
		[Address(RVA = "0x1CEBA6C", Offset = "0x1CEBA6C", VA = "0x1CEBA6C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060128E7 RID: 76007 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128E7")]
		[Address(RVA = "0x1CEC5C8", Offset = "0x1CEC5C8", VA = "0x1CEC5C8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060128E8 RID: 76008 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128E8")]
		[Address(RVA = "0x1CED8A4", Offset = "0x1CED8A4", VA = "0x1CED8A4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x060128E9 RID: 76009 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128E9")]
		[Address(RVA = "0x1CEC884", Offset = "0x1CEC884", VA = "0x1CEC884")]
		private void ProcessSettings()
		{
		}

		// Token: 0x060128EA RID: 76010 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128EA")]
		[Address(RVA = "0x1CED42C", Offset = "0x1CED42C", VA = "0x1CED42C")]
		private void ProcessUserData(int syncId)
		{
		}

		// Token: 0x060128EB RID: 76011 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128EB")]
		[Address(RVA = "0x1CEDB9C", Offset = "0x1CEDB9C", VA = "0x1CEDB9C")]
		private void UpdateLeagueData()
		{
		}

		// Token: 0x060128EC RID: 76012 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128EC")]
		[Address(RVA = "0x1CEDE5C", Offset = "0x1CEDE5C", VA = "0x1CEDE5C")]
		private void UpdateKingsCupData()
		{
		}

		// Token: 0x060128ED RID: 76013 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128ED")]
		[Address(RVA = "0x1CEDD2C", Offset = "0x1CEDD2C", VA = "0x1CEDD2C")]
		private void UpdateTeamBattleData()
		{
		}

		// Token: 0x060128EE RID: 76014 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128EE")]
		[Address(RVA = "0x1CEE440", Offset = "0x1CEE440", VA = "0x1CEE440")]
		private void UpdateTeamTreasureData()
		{
		}

		// Token: 0x060128EF RID: 76015 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128EF")]
		[Address(RVA = "0x1CEE570", Offset = "0x1CEE570", VA = "0x1CEE570")]
		private void UpdateLightningRushData()
		{
		}

		// Token: 0x060128F0 RID: 76016 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F0")]
		[Address(RVA = "0x1CEE69C", Offset = "0x1CEE69C", VA = "0x1CEE69C")]
		private void UpdateSpaceMissionData()
		{
		}

		// Token: 0x060128F1 RID: 76017 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F1")]
		[Address(RVA = "0x1CEE7CC", Offset = "0x1CEE7CC", VA = "0x1CEE7CC")]
		private void UpdateWeeklyLeaderboard()
		{
		}

		// Token: 0x060128F2 RID: 76018 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F2")]
		[Address(RVA = "0x1CEE9C4", Offset = "0x1CEE9C4", VA = "0x1CEE9C4")]
		private void UpdateDragonNestData()
		{
		}

		// Token: 0x060128F3 RID: 76019 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F3")]
		[Address(RVA = "0x1CEEB28", Offset = "0x1CEEB28", VA = "0x1CEEB28")]
		private void UpdateTrainJourneyData()
		{
		}

		// Token: 0x060128F4 RID: 76020 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F4")]
		[Address(RVA = "0x1CEE948", Offset = "0x1CEE948", VA = "0x1CEE948")]
		private void UpdateWelcomeBackGiftData()
		{
		}

		// Token: 0x060128F5 RID: 76021 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F5")]
		[Address(RVA = "0x1CEDF88", Offset = "0x1CEDF88", VA = "0x1CEDF88")]
		private void UpdateMadnessData()
		{
		}

		// Token: 0x060128F6 RID: 76022 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F6")]
		[Address(RVA = "0x1CEE100", Offset = "0x1CEE100", VA = "0x1CEE100")]
		private void UpdateLadderOfferData()
		{
		}

		// Token: 0x060128F7 RID: 76023 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F7")]
		[Address(RVA = "0x1CEE1D0", Offset = "0x1CEE1D0", VA = "0x1CEE1D0")]
		private void UpdateRoyalPassData()
		{
		}

		// Token: 0x060128F8 RID: 76024 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F8")]
		[Address(RVA = "0x1CEE2A0", Offset = "0x1CEE2A0", VA = "0x1CEE2A0")]
		private void UpdateSkyRace()
		{
		}

		// Token: 0x060128F9 RID: 76025 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128F9")]
		[Address(RVA = "0x1CEF7D0", Offset = "0x1CEF7D0", VA = "0x1CEF7D0")]
		private void UpdateDynamicOfferData()
		{
		}

		// Token: 0x060128FA RID: 76026 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128FA")]
		[Address(RVA = "0x1CF0034", Offset = "0x1CF0034", VA = "0x1CF0034")]
		private void UpdateEventDependency()
		{
		}

		// Token: 0x060128FB RID: 76027 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128FB")]
		[Address(RVA = "0x1CEEC74", Offset = "0x1CEEC74", VA = "0x1CEEC74")]
		private void UpdateArcheryArenaData()
		{
		}

		// Token: 0x060128FC RID: 76028 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128FC")]
		[Address(RVA = "0x1CEED50", Offset = "0x1CEED50", VA = "0x1CEED50")]
		private void UpdateTeamTournamentData()
		{
		}

		// Token: 0x060128FD RID: 76029 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128FD")]
		[Address(RVA = "0x1CEEE30", Offset = "0x1CEEE30", VA = "0x1CEEE30")]
		private void UpdateDukesFortuneData()
		{
		}

		// Token: 0x060128FE RID: 76030 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128FE")]
		[Address(RVA = "0x1CEEF5C", Offset = "0x1CEEF5C", VA = "0x1CEEF5C")]
		private void UpdateLavaQuestData()
		{
		}

		// Token: 0x060128FF RID: 76031 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60128FF")]
		[Address(RVA = "0x1CEF054", Offset = "0x1CEF054", VA = "0x1CEF054")]
		private void UpdateHiddenTemple()
		{
		}

		// Token: 0x06012900 RID: 76032 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012900")]
		[Address(RVA = "0x1CEF124", Offset = "0x1CEF124", VA = "0x1CEF124")]
		private void UpdatePinataParty()
		{
		}

		// Token: 0x06012901 RID: 76033 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012901")]
		[Address(RVA = "0x1CEF1F4", Offset = "0x1CEF1F4", VA = "0x1CEF1F4")]
		private void UpdateBalloonRise()
		{
		}

		// Token: 0x06012902 RID: 76034 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012902")]
		[Address(RVA = "0x1CEF320", Offset = "0x1CEF320", VA = "0x1CEF320")]
		private void UpdateMagicCauldron()
		{
		}

		// Token: 0x06012903 RID: 76035 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012903")]
		[Address(RVA = "0x1CEF578", Offset = "0x1CEF578", VA = "0x1CEF578")]
		private void UpdateMissionPursuit()
		{
		}

		// Token: 0x06012904 RID: 76036 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012904")]
		[Address(RVA = "0x1CEF6A4", Offset = "0x1CEF6A4", VA = "0x1CEF6A4")]
		private void UpdateMissionControl()
		{
		}

		// Token: 0x06012905 RID: 76037 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012905")]
		[Address(RVA = "0x1CEF44C", Offset = "0x1CEF44C", VA = "0x1CEF44C")]
		private void UpdateOceanOdyssey()
		{
		}

		// Token: 0x06012906 RID: 76038 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012906")]
		[Address(RVA = "0x1CEFA40", Offset = "0x1CEFA40", VA = "0x1CEFA40")]
		private void UpdateDailyLightningRushData()
		{
		}

		// Token: 0x06012907 RID: 76039 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012907")]
		[Address(RVA = "0x1CEFB78", Offset = "0x1CEFB78", VA = "0x1CEFB78")]
		private void UpdatePuzzleBreak()
		{
		}

		// Token: 0x06012908 RID: 76040 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012908")]
		[Address(RVA = "0x1CEFDD0", Offset = "0x1CEFDD0", VA = "0x1CEFDD0")]
		private void UpdatePropellerRush()
		{
		}

		// Token: 0x06012909 RID: 76041 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012909")]
		[Address(RVA = "0x1CEFF08", Offset = "0x1CEFF08", VA = "0x1CEFF08")]
		private void UpdateAncientAdventure()
		{
		}

		// Token: 0x0601290A RID: 76042 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601290A")]
		[Address(RVA = "0x1CEE370", Offset = "0x1CEE370", VA = "0x1CEE370")]
		private void UpdateOfferData()
		{
		}

		// Token: 0x0601290B RID: 76043 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601290B")]
		[Address(RVA = "0x1CEE878", Offset = "0x1CEE878", VA = "0x1CEE878")]
		private void UpdateTeamOfferData()
		{
		}

		// Token: 0x0601290C RID: 76044 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601290C")]
		[Address(RVA = "0x1CEF8A0", Offset = "0x1CEF8A0", VA = "0x1CEF8A0")]
		private void UpdateSeasonalCardCollectionData()
		{
		}

		// Token: 0x0601290D RID: 76045 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601290D")]
		[Address(RVA = "0x1CEF970", Offset = "0x1CEF970", VA = "0x1CEF970")]
		private void UpdateCoinShopData()
		{
		}

		// Token: 0x0601290E RID: 76046 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601290E")]
		[Address(RVA = "0x1CEFCA4", Offset = "0x1CEFCA4", VA = "0x1CEFCA4")]
		private void UpdateNewRoyalPassData()
		{
		}

		// Token: 0x0601290F RID: 76047 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601290F")]
		[Address(RVA = "0x1CEE058", Offset = "0x1CEE058", VA = "0x1CEE058")]
		private void UpdateOfferSegment()
		{
		}

		// Token: 0x06012910 RID: 76048 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012910")]
		[Address(RVA = "0x1CED91C", Offset = "0x1CED91C", VA = "0x1CED91C")]
		private void ConfigureClientSettings(ClientSettings? clientSettings)
		{
		}

		// Token: 0x06012911 RID: 76049 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012911")]
		[Address(RVA = "0x1CEDAF8", Offset = "0x1CEDAF8", VA = "0x1CEDAF8")]
		private static void ConfigureTermsAndConditions(TermsAndConditions? termsAndConditions)
		{
		}

		// Token: 0x0400EAC9 RID: 60105
		[Token(Token = "0x400EAC9")]
		private const byte LifeHackControlEnabledBit = 0;

		// Token: 0x0400EACA RID: 60106
		[Token(Token = "0x400EACA")]
		private const byte MadnessEventDisabledBit = 1;

		// Token: 0x0400EACB RID: 60107
		[Token(Token = "0x400EACB")]
		private const byte RoyalPassDisabledBit = 2;

		// Token: 0x0400EACC RID: 60108
		[Token(Token = "0x400EACC")]
		private const byte LadderOfferDisabledBit = 3;

		// Token: 0x0400EACD RID: 60109
		[Token(Token = "0x400EACD")]
		private const byte LightningRushDisabledBit = 5;

		// Token: 0x0400EACE RID: 60110
		[Token(Token = "0x400EACE")]
		private const byte SpaceMissionDisabledBit = 8;

		// Token: 0x0400EACF RID: 60111
		[Token(Token = "0x400EACF")]
		private const byte BalloonRiseDisabledBit = 9;

		// Token: 0x0400EAD0 RID: 60112
		[Token(Token = "0x400EAD0")]
		private const byte WeeklyLeaderboardDisabledBit = 10;

		// Token: 0x0400EAD1 RID: 60113
		[Token(Token = "0x400EAD1")]
		private const byte WorldCupDisabledBit = 12;

		// Token: 0x0400EAD2 RID: 60114
		[Token(Token = "0x400EAD2")]
		private const byte CorruptedDBFixDisabledBit = 15;

		// Token: 0x0400EAD3 RID: 60115
		[Token(Token = "0x400EAD3")]
		private const byte DynamicOfferDisabledBit = 16;

		// Token: 0x0400EAD4 RID: 60116
		[Token(Token = "0x400EAD4")]
		private const byte LavaQuestDisabledBit = 19;

		// Token: 0x0400EAD5 RID: 60117
		[Token(Token = "0x400EAD5")]
		private const byte HiddenTempleDisabledBit = 20;

		// Token: 0x0400EAD6 RID: 60118
		[Token(Token = "0x400EAD6")]
		private const byte MagicCauldronDisabledBit = 21;

		// Token: 0x0400EAD7 RID: 60119
		[Token(Token = "0x400EAD7")]
		private const byte DragonNestDisabledBit = 23;

		// Token: 0x0400EAD8 RID: 60120
		[Token(Token = "0x400EAD8")]
		private const byte LogUploadInThreadDisabledBit = 24;

		// Token: 0x0400EAD9 RID: 60121
		[Token(Token = "0x400EAD9")]
		private const byte ArcheryArenaDisabledBit = 25;

		// Token: 0x0400EADA RID: 60122
		[Token(Token = "0x400EADA")]
		private const byte DukesFortuneDisabledBit = 26;

		// Token: 0x0400EADB RID: 60123
		[Token(Token = "0x400EADB")]
		private const byte SeasonalCardCollectionDisabledBit = 27;

		// Token: 0x0400EADC RID: 60124
		[Token(Token = "0x400EADC")]
		private const byte TeamTournamentDisabledBit = 28;

		// Token: 0x0400EADD RID: 60125
		[Token(Token = "0x400EADD")]
		private const byte MissionPursuitDisabledBit = 29;

		// Token: 0x0400EADE RID: 60126
		[Token(Token = "0x400EADE")]
		private const byte MissionControlDisabledBit = 31;

		// Token: 0x0400EADF RID: 60127
		[Token(Token = "0x400EADF")]
		private const byte TrainJourneyDisabledBit = 32;

		// Token: 0x0400EAE0 RID: 60128
		[Token(Token = "0x400EAE0")]
		private const byte OceanOdysseyDisabledBit = 33;

		// Token: 0x0400EAE1 RID: 60129
		[Token(Token = "0x400EAE1")]
		private const byte CoinShopDisabledBit = 34;

		// Token: 0x0400EAE2 RID: 60130
		[Token(Token = "0x400EAE2")]
		private const byte DailyLightningRushDisabledBit = 35;

		// Token: 0x0400EAE3 RID: 60131
		[Token(Token = "0x400EAE3")]
		private const byte PuzzleBreakDisabledBit = 36;

		// Token: 0x0400EAE4 RID: 60132
		[Token(Token = "0x400EAE4")]
		private const byte NewRoyalPassDisabledBit = 37;

		// Token: 0x0400EAE5 RID: 60133
		[Token(Token = "0x400EAE5")]
		private const byte PropellerRushDisabledBit = 38;

		// Token: 0x0400EAE6 RID: 60134
		[Token(Token = "0x400EAE6")]
		private const byte AncientAdventureDisabledBit = 39;

		// Token: 0x0400EAE7 RID: 60135
		[Token(Token = "0x400EAE7")]
		[FieldOffset(Offset = "0x0")]
		private static int LastProcessedPingPackageId;

		// Token: 0x0400EAE8 RID: 60136
		[Token(Token = "0x400EAE8")]
		[FieldOffset(Offset = "0x13")]
		private readonly bool sendingAfterLogout;

		// Token: 0x0400EAE9 RID: 60137
		[Token(Token = "0x400EAE9")]
		[FieldOffset(Offset = "0x18")]
		private PingResponse <Response>k__BackingField;
	}
}
