﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.UserProfile
{
	// Token: 0x0200252B RID: 9515
	[Token(Token = "0x200252B")]
	public class GetUserStatsHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002708 RID: 9992
		// (get) Token: 0x060129B2 RID: 76210 RVA: 0x00077BF8 File Offset: 0x00075DF8
		[Token(Token = "0x17002708")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129B2")]
			[Address(RVA = "0x1CFA004", Offset = "0x1CFA004", VA = "0x1CFA004", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002709 RID: 9993
		// (get) Token: 0x060129B3 RID: 76211 RVA: 0x00077C10 File Offset: 0x00075E10
		[Token(Token = "0x17002709")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129B3")]
			[Address(RVA = "0x1CFA00C", Offset = "0x1CFA00C", VA = "0x1CFA00C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700270A RID: 9994
		// (get) Token: 0x060129B4 RID: 76212 RVA: 0x00077C28 File Offset: 0x00075E28
		// (set) Token: 0x060129B5 RID: 76213 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700270A")]
		private GetStatResponse Response
		{
			[Token(Token = "0x60129B4")]
			[Address(RVA = "0x1CFA014", Offset = "0x1CFA014", VA = "0x1CFA014")]
			get
			{
				return default(GetStatResponse);
			}
			[Token(Token = "0x60129B5")]
			[Address(RVA = "0x1CFA020", Offset = "0x1CFA020", VA = "0x1CFA020")]
			set
			{
			}
		}

		// Token: 0x060129B6 RID: 76214 RVA: 0x00077C40 File Offset: 0x00075E40
		[Token(Token = "0x60129B6")]
		[Address(RVA = "0x1CFA030", Offset = "0x1CFA030", VA = "0x1CFA030", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129B7 RID: 76215 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129B7")]
		[Address(RVA = "0x1CFA0B0", Offset = "0x1CFA0B0", VA = "0x1CFA0B0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129B8 RID: 76216 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129B8")]
		[Address(RVA = "0x1CFA3C4", Offset = "0x1CFA3C4", VA = "0x1CFA3C4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x060129B9 RID: 76217 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129B9")]
		[Address(RVA = "0x1CFA3C8", Offset = "0x1CFA3C8", VA = "0x1CFA3C8")]
		public GetUserStatsHttpCommand()
		{
		}

		// Token: 0x0400EB22 RID: 60194
		[Token(Token = "0x400EB22")]
		[FieldOffset(Offset = "0x18")]
		private GetStatResponse <Response>k__BackingField;

		// Token: 0x0400EB23 RID: 60195
		[Token(Token = "0x400EB23")]
		[FieldOffset(Offset = "0x28")]
		private long requestUserId;
	}
}
