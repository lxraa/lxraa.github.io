﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.LightningRush
{
	// Token: 0x0200255B RID: 9563
	[Token(Token = "0x200255B")]
	public class EnterLightningRushHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002778 RID: 10104
		// (get) Token: 0x06012B03 RID: 76547 RVA: 0x00078BA0 File Offset: 0x00076DA0
		[Token(Token = "0x17002778")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B03")]
			[Address(RVA = "0x1ECED9C", Offset = "0x1ECED9C", VA = "0x1ECED9C", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002779 RID: 10105
		// (get) Token: 0x06012B04 RID: 76548 RVA: 0x00078BB8 File Offset: 0x00076DB8
		[Token(Token = "0x17002779")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B04")]
			[Address(RVA = "0x1ECEDA4", Offset = "0x1ECEDA4", VA = "0x1ECEDA4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B05 RID: 76549 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B05")]
		[Address(RVA = "0x1ECEDAC", Offset = "0x1ECEDAC", VA = "0x1ECEDAC")]
		public EnterLightningRushHttpCommand(int day, EventInteractionOrigin eventInteractionOrigin)
		{
		}

		// Token: 0x1700277A RID: 10106
		// (get) Token: 0x06012B06 RID: 76550 RVA: 0x00078BD0 File Offset: 0x00076DD0
		// (set) Token: 0x06012B07 RID: 76551 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700277A")]
		public EnterLightningRushResponse Response
		{
			[Token(Token = "0x6012B06")]
			[Address(RVA = "0x1ECEDD8", Offset = "0x1ECEDD8", VA = "0x1ECEDD8")]
			get
			{
				return default(EnterLightningRushResponse);
			}
			[Token(Token = "0x6012B07")]
			[Address(RVA = "0x1ECEDE4", Offset = "0x1ECEDE4", VA = "0x1ECEDE4")]
			set
			{
			}
		}

		// Token: 0x06012B08 RID: 76552 RVA: 0x00078BE8 File Offset: 0x00076DE8
		[Token(Token = "0x6012B08")]
		[Address(RVA = "0x1ECEDF4", Offset = "0x1ECEDF4", VA = "0x1ECEDF4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B09 RID: 76553 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B09")]
		[Address(RVA = "0x1ECEFC8", Offset = "0x1ECEFC8", VA = "0x1ECEFC8", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B0A RID: 76554 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B0A")]
		[Address(RVA = "0x1ECF314", Offset = "0x1ECF314", VA = "0x1ECF314", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBB3 RID: 60339
		[Token(Token = "0x400EBB3")]
		[FieldOffset(Offset = "0x14")]
		private readonly int enterDay;

		// Token: 0x0400EBB4 RID: 60340
		[Token(Token = "0x400EBB4")]
		[FieldOffset(Offset = "0x18")]
		private readonly EventInteractionOrigin eventInteractionOrigin;

		// Token: 0x0400EBB5 RID: 60341
		[Token(Token = "0x400EBB5")]
		[FieldOffset(Offset = "0x20")]
		private EnterLightningRushResponse <Response>k__BackingField;
	}
}
