﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B5 RID: 9141
	[Token(Token = "0x20023B5")]
	public struct EventDependencyInfo : IFlatbufferObject
	{
		// Token: 0x1700208C RID: 8332
		// (get) Token: 0x06011216 RID: 70166 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700208C")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011216")]
			[Address(RVA = "0x1CA94A8", Offset = "0x1CA94A8", VA = "0x1CA94A8", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011217 RID: 70167 RVA: 0x00065460 File Offset: 0x00063660
		[Token(Token = "0x6011217")]
		[Address(RVA = "0x1CA94B0", Offset = "0x1CA94B0", VA = "0x1CA94B0")]
		public static EventDependencyInfo GetRootAsEventDependencyInfo(ByteBuffer _bb)
		{
			return default(EventDependencyInfo);
		}

		// Token: 0x06011218 RID: 70168 RVA: 0x00065478 File Offset: 0x00063678
		[Token(Token = "0x6011218")]
		[Address(RVA = "0x1CA94BC", Offset = "0x1CA94BC", VA = "0x1CA94BC")]
		public static EventDependencyInfo GetRootAsEventDependencyInfo(ByteBuffer _bb, EventDependencyInfo obj)
		{
			return default(EventDependencyInfo);
		}

		// Token: 0x06011219 RID: 70169 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011219")]
		[Address(RVA = "0x1CA956C", Offset = "0x1CA956C", VA = "0x1CA956C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601121A RID: 70170 RVA: 0x00065490 File Offset: 0x00063690
		[Token(Token = "0x601121A")]
		[Address(RVA = "0x1CA9534", Offset = "0x1CA9534", VA = "0x1CA9534")]
		public EventDependencyInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(EventDependencyInfo);
		}

		// Token: 0x1700208D RID: 8333
		// (get) Token: 0x0601121B RID: 70171 RVA: 0x000654A8 File Offset: 0x000636A8
		[Token(Token = "0x1700208D")]
		public int ConfigVersion
		{
			[Token(Token = "0x601121B")]
			[Address(RVA = "0x1CA957C", Offset = "0x1CA957C", VA = "0x1CA957C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601121C RID: 70172 RVA: 0x000654C0 File Offset: 0x000636C0
		[Token(Token = "0x601121C")]
		[Address(RVA = "0x1CA95C0", Offset = "0x1CA95C0", VA = "0x1CA95C0")]
		public EventDependencyGroup? Config(int j)
		{
			return null;
		}

		// Token: 0x1700208E RID: 8334
		// (get) Token: 0x0601121D RID: 70173 RVA: 0x000654D8 File Offset: 0x000636D8
		[Token(Token = "0x1700208E")]
		public int ConfigLength
		{
			[Token(Token = "0x601121D")]
			[Address(RVA = "0x1CA9698", Offset = "0x1CA9698", VA = "0x1CA9698")]
			get
			{
				return 0;
			}
		}

		// Token: 0x0601121E RID: 70174 RVA: 0x000654F0 File Offset: 0x000636F0
		[Token(Token = "0x601121E")]
		[Address(RVA = "0x1CA96CC", Offset = "0x1CA96CC", VA = "0x1CA96CC")]
		public static Offset<EventDependencyInfo> CreateEventDependencyInfo(FlatBufferBuilder builder, int config_version = 0, [Optional] VectorOffset configOffset)
		{
			return default(Offset<EventDependencyInfo>);
		}

		// Token: 0x0601121F RID: 70175 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601121F")]
		[Address(RVA = "0x1CA97D0", Offset = "0x1CA97D0", VA = "0x1CA97D0")]
		public static void StartEventDependencyInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011220 RID: 70176 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011220")]
		[Address(RVA = "0x1CA9744", Offset = "0x1CA9744", VA = "0x1CA9744")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06011221 RID: 70177 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011221")]
		[Address(RVA = "0x1CA9724", Offset = "0x1CA9724", VA = "0x1CA9724")]
		public static void AddConfig(FlatBufferBuilder builder, VectorOffset configOffset)
		{
		}

		// Token: 0x06011222 RID: 70178 RVA: 0x00065508 File Offset: 0x00063708
		[Token(Token = "0x6011222")]
		[Address(RVA = "0x1CA97E8", Offset = "0x1CA97E8", VA = "0x1CA97E8")]
		public static VectorOffset CreateConfigVector(FlatBufferBuilder builder, Offset<EventDependencyGroup>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011223 RID: 70179 RVA: 0x00065520 File Offset: 0x00063720
		[Token(Token = "0x6011223")]
		[Address(RVA = "0x1CA9890", Offset = "0x1CA9890", VA = "0x1CA9890")]
		public static VectorOffset CreateConfigVectorBlock(FlatBufferBuilder builder, Offset<EventDependencyGroup>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06011224 RID: 70180 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011224")]
		[Address(RVA = "0x1CA9918", Offset = "0x1CA9918", VA = "0x1CA9918")]
		public static void StartConfigVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06011225 RID: 70181 RVA: 0x00065538 File Offset: 0x00063738
		[Token(Token = "0x6011225")]
		[Address(RVA = "0x1CA9764", Offset = "0x1CA9764", VA = "0x1CA9764")]
		public static Offset<EventDependencyInfo> EndEventDependencyInfo(FlatBufferBuilder builder)
		{
			return default(Offset<EventDependencyInfo>);
		}

		// Token: 0x0400E6EC RID: 59116
		[Token(Token = "0x400E6EC")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
