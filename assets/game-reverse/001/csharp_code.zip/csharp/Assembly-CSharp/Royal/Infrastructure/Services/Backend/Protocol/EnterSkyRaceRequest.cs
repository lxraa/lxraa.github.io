﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A9 RID: 9129
	[Token(Token = "0x20023A9")]
	public struct EnterSkyRaceRequest : IFlatbufferObject
	{
		// Token: 0x1700205E RID: 8286
		// (get) Token: 0x0601116A RID: 69994 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700205E")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x601116A")]
			[Address(RVA = "0x1F9E9D0", Offset = "0x1F9E9D0", VA = "0x1F9E9D0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601116B RID: 69995 RVA: 0x00064B48 File Offset: 0x00062D48
		[Token(Token = "0x601116B")]
		[Address(RVA = "0x1F9E9D8", Offset = "0x1F9E9D8", VA = "0x1F9E9D8")]
		public static EnterSkyRaceRequest GetRootAsEnterSkyRaceRequest(ByteBuffer _bb)
		{
			return default(EnterSkyRaceRequest);
		}

		// Token: 0x0601116C RID: 69996 RVA: 0x00064B60 File Offset: 0x00062D60
		[Token(Token = "0x601116C")]
		[Address(RVA = "0x1F9E9E4", Offset = "0x1F9E9E4", VA = "0x1F9E9E4")]
		public static EnterSkyRaceRequest GetRootAsEnterSkyRaceRequest(ByteBuffer _bb, EnterSkyRaceRequest obj)
		{
			return default(EnterSkyRaceRequest);
		}

		// Token: 0x0601116D RID: 69997 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601116D")]
		[Address(RVA = "0x1F9EA94", Offset = "0x1F9EA94", VA = "0x1F9EA94", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601116E RID: 69998 RVA: 0x00064B78 File Offset: 0x00062D78
		[Token(Token = "0x601116E")]
		[Address(RVA = "0x1F9EA5C", Offset = "0x1F9EA5C", VA = "0x1F9EA5C")]
		public EnterSkyRaceRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterSkyRaceRequest);
		}

		// Token: 0x1700205F RID: 8287
		// (get) Token: 0x0601116F RID: 69999 RVA: 0x00064B90 File Offset: 0x00062D90
		[Token(Token = "0x1700205F")]
		public int SkyRaceConfigVersion
		{
			[Token(Token = "0x601116F")]
			[Address(RVA = "0x1F9EAA4", Offset = "0x1F9EAA4", VA = "0x1F9EAA4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06011170 RID: 70000 RVA: 0x00064BA8 File Offset: 0x00062DA8
		[Token(Token = "0x6011170")]
		[Address(RVA = "0x1F9EAE8", Offset = "0x1F9EAE8", VA = "0x1F9EAE8")]
		public static Offset<EnterSkyRaceRequest> CreateEnterSkyRaceRequest(FlatBufferBuilder builder, int sky_race_config_version = 0)
		{
			return default(Offset<EnterSkyRaceRequest>);
		}

		// Token: 0x06011171 RID: 70001 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011171")]
		[Address(RVA = "0x1F9EBBC", Offset = "0x1F9EBBC", VA = "0x1F9EBBC")]
		public static void StartEnterSkyRaceRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011172 RID: 70002 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011172")]
		[Address(RVA = "0x1F9EB30", Offset = "0x1F9EB30", VA = "0x1F9EB30")]
		public static void AddSkyRaceConfigVersion(FlatBufferBuilder builder, int skyRaceConfigVersion)
		{
		}

		// Token: 0x06011173 RID: 70003 RVA: 0x00064BC0 File Offset: 0x00062DC0
		[Token(Token = "0x6011173")]
		[Address(RVA = "0x1F9EB50", Offset = "0x1F9EB50", VA = "0x1F9EB50")]
		public static Offset<EnterSkyRaceRequest> EndEnterSkyRaceRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterSkyRaceRequest>);
		}

		// Token: 0x0400E6DB RID: 59099
		[Token(Token = "0x400E6DB")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
