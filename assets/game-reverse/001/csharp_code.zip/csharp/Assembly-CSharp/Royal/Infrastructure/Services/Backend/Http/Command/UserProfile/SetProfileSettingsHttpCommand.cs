﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.UserProfile
{
	// Token: 0x0200252C RID: 9516
	[Token(Token = "0x200252C")]
	public class SetProfileSettingsHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700270B RID: 9995
		// (get) Token: 0x060129BA RID: 76218 RVA: 0x00077C58 File Offset: 0x00075E58
		[Token(Token = "0x1700270B")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129BA")]
			[Address(RVA = "0x1CFA3D0", Offset = "0x1CFA3D0", VA = "0x1CFA3D0", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700270C RID: 9996
		// (get) Token: 0x060129BB RID: 76219 RVA: 0x00077C70 File Offset: 0x00075E70
		[Token(Token = "0x1700270C")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129BB")]
			[Address(RVA = "0x1CFA3D8", Offset = "0x1CFA3D8", VA = "0x1CFA3D8", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x060129BC RID: 76220 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129BC")]
		[Address(RVA = "0x1CFA3E0", Offset = "0x1CFA3E0", VA = "0x1CFA3E0")]
		public SetProfileSettingsHttpCommand(UserProfileSetting profileSetting, Action<bool> onComplete)
		{
		}

		// Token: 0x060129BD RID: 76221 RVA: 0x00077C88 File Offset: 0x00075E88
		[Token(Token = "0x60129BD")]
		[Address(RVA = "0x1CFA41C", Offset = "0x1CFA41C", VA = "0x1CFA41C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129BE RID: 76222 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129BE")]
		[Address(RVA = "0x1CFA5E4", Offset = "0x1CFA5E4", VA = "0x1CFA5E4", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129BF RID: 76223 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129BF")]
		[Address(RVA = "0x1CFA7B4", Offset = "0x1CFA7B4", VA = "0x1CFA7B4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB24 RID: 60196
		[Token(Token = "0x400EB24")]
		[FieldOffset(Offset = "0x18")]
		private readonly UserProfileSetting profileSetting;

		// Token: 0x0400EB25 RID: 60197
		[Token(Token = "0x400EB25")]
		[FieldOffset(Offset = "0x38")]
		private readonly Action<bool> onComplete;

		// Token: 0x0400EB26 RID: 60198
		[Token(Token = "0x400EB26")]
		[FieldOffset(Offset = "0x40")]
		private long requestUserId;
	}
}
