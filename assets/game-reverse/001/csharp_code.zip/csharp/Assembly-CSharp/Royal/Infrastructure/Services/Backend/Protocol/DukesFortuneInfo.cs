﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002391 RID: 9105
	[Token(Token = "0x2002391")]
	public struct DukesFortuneInfo : IFlatbufferObject
	{
		// Token: 0x17002007 RID: 8199
		// (get) Token: 0x06011026 RID: 69670 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002007")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011026")]
			[Address(RVA = "0x1F99AF0", Offset = "0x1F99AF0", VA = "0x1F99AF0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011027 RID: 69671 RVA: 0x00063AC8 File Offset: 0x00061CC8
		[Token(Token = "0x6011027")]
		[Address(RVA = "0x1F99AF8", Offset = "0x1F99AF8", VA = "0x1F99AF8")]
		public static DukesFortuneInfo GetRootAsDukesFortuneInfo(ByteBuffer _bb)
		{
			return default(DukesFortuneInfo);
		}

		// Token: 0x06011028 RID: 69672 RVA: 0x00063AE0 File Offset: 0x00061CE0
		[Token(Token = "0x6011028")]
		[Address(RVA = "0x1F99B04", Offset = "0x1F99B04", VA = "0x1F99B04")]
		public static DukesFortuneInfo GetRootAsDukesFortuneInfo(ByteBuffer _bb, DukesFortuneInfo obj)
		{
			return default(DukesFortuneInfo);
		}

		// Token: 0x06011029 RID: 69673 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011029")]
		[Address(RVA = "0x1F99BB4", Offset = "0x1F99BB4", VA = "0x1F99BB4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601102A RID: 69674 RVA: 0x00063AF8 File Offset: 0x00061CF8
		[Token(Token = "0x601102A")]
		[Address(RVA = "0x1F99B7C", Offset = "0x1F99B7C", VA = "0x1F99B7C")]
		public DukesFortuneInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DukesFortuneInfo);
		}

		// Token: 0x17002008 RID: 8200
		// (get) Token: 0x0601102B RID: 69675 RVA: 0x00063B10 File Offset: 0x00061D10
		[Token(Token = "0x17002008")]
		public int EventId
		{
			[Token(Token = "0x601102B")]
			[Address(RVA = "0x1F99BC4", Offset = "0x1F99BC4", VA = "0x1F99BC4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002009 RID: 8201
		// (get) Token: 0x0601102C RID: 69676 RVA: 0x00063B28 File Offset: 0x00061D28
		[Token(Token = "0x17002009")]
		public long RemainingTime
		{
			[Token(Token = "0x601102C")]
			[Address(RVA = "0x1F99C08", Offset = "0x1F99C08", VA = "0x1F99C08")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x1700200A RID: 8202
		// (get) Token: 0x0601102D RID: 69677 RVA: 0x00063B40 File Offset: 0x00061D40
		[Token(Token = "0x1700200A")]
		public int ConfigVersion
		{
			[Token(Token = "0x601102D")]
			[Address(RVA = "0x1F99C50", Offset = "0x1F99C50", VA = "0x1F99C50")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700200B RID: 8203
		// (get) Token: 0x0601102E RID: 69678 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700200B")]
		public string Config
		{
			[Token(Token = "0x601102E")]
			[Address(RVA = "0x1F99C94", Offset = "0x1F99C94", VA = "0x1F99C94")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601102F RID: 69679 RVA: 0x00063B58 File Offset: 0x00061D58
		[Token(Token = "0x601102F")]
		[Address(RVA = "0x1F99CD0", Offset = "0x1F99CD0", VA = "0x1F99CD0")]
		public ArraySegment<byte>? GetConfigBytes()
		{
			return null;
		}

		// Token: 0x06011030 RID: 69680 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011030")]
		[Address(RVA = "0x1F99D08", Offset = "0x1F99D08", VA = "0x1F99D08")]
		public byte[] GetConfigArray()
		{
			return null;
		}

		// Token: 0x06011031 RID: 69681 RVA: 0x00063B70 File Offset: 0x00061D70
		[Token(Token = "0x6011031")]
		[Address(RVA = "0x1F99D54", Offset = "0x1F99D54", VA = "0x1F99D54")]
		public static Offset<DukesFortuneInfo> CreateDukesFortuneInfo(FlatBufferBuilder builder, int event_id = 0, long remaining_time = 0L, int config_version = 0, [Optional] StringOffset configOffset)
		{
			return default(Offset<DukesFortuneInfo>);
		}

		// Token: 0x06011032 RID: 69682 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011032")]
		[Address(RVA = "0x1F99EC0", Offset = "0x1F99EC0", VA = "0x1F99EC0")]
		public static void StartDukesFortuneInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011033 RID: 69683 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011033")]
		[Address(RVA = "0x1F99E34", Offset = "0x1F99E34", VA = "0x1F99E34")]
		public static void AddEventId(FlatBufferBuilder builder, int eventId)
		{
		}

		// Token: 0x06011034 RID: 69684 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011034")]
		[Address(RVA = "0x1F99DD4", Offset = "0x1F99DD4", VA = "0x1F99DD4")]
		public static void AddRemainingTime(FlatBufferBuilder builder, long remainingTime)
		{
		}

		// Token: 0x06011035 RID: 69685 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011035")]
		[Address(RVA = "0x1F99E14", Offset = "0x1F99E14", VA = "0x1F99E14")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x06011036 RID: 69686 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011036")]
		[Address(RVA = "0x1F99DF4", Offset = "0x1F99DF4", VA = "0x1F99DF4")]
		public static void AddConfig(FlatBufferBuilder builder, StringOffset configOffset)
		{
		}

		// Token: 0x06011037 RID: 69687 RVA: 0x00063B88 File Offset: 0x00061D88
		[Token(Token = "0x6011037")]
		[Address(RVA = "0x1F99E54", Offset = "0x1F99E54", VA = "0x1F99E54")]
		public static Offset<DukesFortuneInfo> EndDukesFortuneInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DukesFortuneInfo>);
		}

		// Token: 0x0400E6B2 RID: 59058
		[Token(Token = "0x400E6B2")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
