﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Player.Context.Units;

namespace Royal.Infrastructure.Services.Backend.Http.Command.PropellerRush
{
	// Token: 0x02002550 RID: 9552
	[Token(Token = "0x2002550")]
	public class EnterPropellerRushHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002761 RID: 10081
		// (get) Token: 0x06012ABB RID: 76475 RVA: 0x00078810 File Offset: 0x00076A10
		[Token(Token = "0x17002761")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012ABB")]
			[Address(RVA = "0x1ECD2E8", Offset = "0x1ECD2E8", VA = "0x1ECD2E8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002762 RID: 10082
		// (get) Token: 0x06012ABC RID: 76476 RVA: 0x00078828 File Offset: 0x00076A28
		[Token(Token = "0x17002762")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012ABC")]
			[Address(RVA = "0x1ECD2F0", Offset = "0x1ECD2F0", VA = "0x1ECD2F0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012ABD RID: 76477 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ABD")]
		[Address(RVA = "0x1ECD2F8", Offset = "0x1ECD2F8", VA = "0x1ECD2F8")]
		public EnterPropellerRushHttpCommand(int step, int configVersion, EventInteractionOrigin origin, bool shouldOpenPrelevel)
		{
		}

		// Token: 0x06012ABE RID: 76478 RVA: 0x00078840 File Offset: 0x00076A40
		[Token(Token = "0x6012ABE")]
		[Address(RVA = "0x1ECD33C", Offset = "0x1ECD33C", VA = "0x1ECD33C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012ABF RID: 76479 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ABF")]
		[Address(RVA = "0x1ECD3B0", Offset = "0x1ECD3B0", VA = "0x1ECD3B0", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AC0 RID: 76480 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AC0")]
		[Address(RVA = "0x1ECD668", Offset = "0x1ECD668", VA = "0x1ECD668", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB97 RID: 60311
		[Token(Token = "0x400EB97")]
		[FieldOffset(Offset = "0x14")]
		private readonly int step;

		// Token: 0x0400EB98 RID: 60312
		[Token(Token = "0x400EB98")]
		[FieldOffset(Offset = "0x18")]
		private readonly int configVersion;

		// Token: 0x0400EB99 RID: 60313
		[Token(Token = "0x400EB99")]
		[FieldOffset(Offset = "0x1C")]
		private readonly EventInteractionOrigin origin;

		// Token: 0x0400EB9A RID: 60314
		[Token(Token = "0x400EB9A")]
		[FieldOffset(Offset = "0x20")]
		private readonly bool shouldOpenPrelevel;
	}
}
