﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002376 RID: 9078
	[Token(Token = "0x2002376")]
	public struct DailyLightningRushGroupInfo : IFlatbufferObject
	{
		// Token: 0x17001FA2 RID: 8098
		// (get) Token: 0x06010E98 RID: 69272 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FA2")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010E98")]
			[Address(RVA = "0x1F938F0", Offset = "0x1F938F0", VA = "0x1F938F0", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E99 RID: 69273 RVA: 0x000625F8 File Offset: 0x000607F8
		[Token(Token = "0x6010E99")]
		[Address(RVA = "0x1F938F8", Offset = "0x1F938F8", VA = "0x1F938F8")]
		public static DailyLightningRushGroupInfo GetRootAsDailyLightningRushGroupInfo(ByteBuffer _bb)
		{
			return default(DailyLightningRushGroupInfo);
		}

		// Token: 0x06010E9A RID: 69274 RVA: 0x00062610 File Offset: 0x00060810
		[Token(Token = "0x6010E9A")]
		[Address(RVA = "0x1F93904", Offset = "0x1F93904", VA = "0x1F93904")]
		public static DailyLightningRushGroupInfo GetRootAsDailyLightningRushGroupInfo(ByteBuffer _bb, DailyLightningRushGroupInfo obj)
		{
			return default(DailyLightningRushGroupInfo);
		}

		// Token: 0x06010E9B RID: 69275 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E9B")]
		[Address(RVA = "0x1F939B4", Offset = "0x1F939B4", VA = "0x1F939B4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010E9C RID: 69276 RVA: 0x00062628 File Offset: 0x00060828
		[Token(Token = "0x6010E9C")]
		[Address(RVA = "0x1F9397C", Offset = "0x1F9397C", VA = "0x1F9397C")]
		public DailyLightningRushGroupInfo __assign(int _i, ByteBuffer _bb)
		{
			return default(DailyLightningRushGroupInfo);
		}

		// Token: 0x17001FA3 RID: 8099
		// (get) Token: 0x06010E9D RID: 69277 RVA: 0x00062640 File Offset: 0x00060840
		[Token(Token = "0x17001FA3")]
		public long GroupId
		{
			[Token(Token = "0x6010E9D")]
			[Address(RVA = "0x1F939C4", Offset = "0x1F939C4", VA = "0x1F939C4")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010E9E RID: 69278 RVA: 0x00062658 File Offset: 0x00060858
		[Token(Token = "0x6010E9E")]
		[Address(RVA = "0x1F93A0C", Offset = "0x1F93A0C", VA = "0x1F93A0C")]
		public DailyLightningRushUser? Users(int j)
		{
			return null;
		}

		// Token: 0x17001FA4 RID: 8100
		// (get) Token: 0x06010E9F RID: 69279 RVA: 0x00062670 File Offset: 0x00060870
		[Token(Token = "0x17001FA4")]
		public int UsersLength
		{
			[Token(Token = "0x6010E9F")]
			[Address(RVA = "0x1F93B14", Offset = "0x1F93B14", VA = "0x1F93B14")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001FA5 RID: 8101
		// (get) Token: 0x06010EA0 RID: 69280 RVA: 0x00062688 File Offset: 0x00060888
		[Token(Token = "0x17001FA5")]
		public long GroupRemainingTime
		{
			[Token(Token = "0x6010EA0")]
			[Address(RVA = "0x1F93B48", Offset = "0x1F93B48", VA = "0x1F93B48")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x06010EA1 RID: 69281 RVA: 0x000626A0 File Offset: 0x000608A0
		[Token(Token = "0x6010EA1")]
		[Address(RVA = "0x1F93B90", Offset = "0x1F93B90", VA = "0x1F93B90")]
		public static Offset<DailyLightningRushGroupInfo> CreateDailyLightningRushGroupInfo(FlatBufferBuilder builder, long group_id = 0L, [Optional] VectorOffset usersOffset, long group_remaining_time = 0L)
		{
			return default(Offset<DailyLightningRushGroupInfo>);
		}

		// Token: 0x06010EA2 RID: 69282 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EA2")]
		[Address(RVA = "0x1F93CCC", Offset = "0x1F93CCC", VA = "0x1F93CCC")]
		public static void StartDailyLightningRushGroupInfo(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010EA3 RID: 69283 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EA3")]
		[Address(RVA = "0x1F93C20", Offset = "0x1F93C20", VA = "0x1F93C20")]
		public static void AddGroupId(FlatBufferBuilder builder, long groupId)
		{
		}

		// Token: 0x06010EA4 RID: 69284 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EA4")]
		[Address(RVA = "0x1F93C40", Offset = "0x1F93C40", VA = "0x1F93C40")]
		public static void AddUsers(FlatBufferBuilder builder, VectorOffset usersOffset)
		{
		}

		// Token: 0x06010EA5 RID: 69285 RVA: 0x000626B8 File Offset: 0x000608B8
		[Token(Token = "0x6010EA5")]
		[Address(RVA = "0x1F93CE4", Offset = "0x1F93CE4", VA = "0x1F93CE4")]
		public static VectorOffset CreateUsersVector(FlatBufferBuilder builder, Offset<DailyLightningRushUser>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010EA6 RID: 69286 RVA: 0x000626D0 File Offset: 0x000608D0
		[Token(Token = "0x6010EA6")]
		[Address(RVA = "0x1F93D8C", Offset = "0x1F93D8C", VA = "0x1F93D8C")]
		public static VectorOffset CreateUsersVectorBlock(FlatBufferBuilder builder, Offset<DailyLightningRushUser>[] data)
		{
			return default(VectorOffset);
		}

		// Token: 0x06010EA7 RID: 69287 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EA7")]
		[Address(RVA = "0x1F93E14", Offset = "0x1F93E14", VA = "0x1F93E14")]
		public static void StartUsersVector(FlatBufferBuilder builder, int numElems)
		{
		}

		// Token: 0x06010EA8 RID: 69288 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010EA8")]
		[Address(RVA = "0x1F93C00", Offset = "0x1F93C00", VA = "0x1F93C00")]
		public static void AddGroupRemainingTime(FlatBufferBuilder builder, long groupRemainingTime)
		{
		}

		// Token: 0x06010EA9 RID: 69289 RVA: 0x000626E8 File Offset: 0x000608E8
		[Token(Token = "0x6010EA9")]
		[Address(RVA = "0x1F93C60", Offset = "0x1F93C60", VA = "0x1F93C60")]
		public static Offset<DailyLightningRushGroupInfo> EndDailyLightningRushGroupInfo(FlatBufferBuilder builder)
		{
			return default(Offset<DailyLightningRushGroupInfo>);
		}

		// Token: 0x0400E68F RID: 59023
		[Token(Token = "0x400E68F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
