﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.League
{
	// Token: 0x0200255D RID: 9565
	[Token(Token = "0x200255D")]
	public class CheckLeagueHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700277E RID: 10110
		// (get) Token: 0x06012B13 RID: 76563 RVA: 0x00078C60 File Offset: 0x00076E60
		[Token(Token = "0x1700277E")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B13")]
			[Address(RVA = "0x1ECF740", Offset = "0x1ECF740", VA = "0x1ECF740", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700277F RID: 10111
		// (get) Token: 0x06012B14 RID: 76564 RVA: 0x00078C78 File Offset: 0x00076E78
		[Token(Token = "0x1700277F")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B14")]
			[Address(RVA = "0x1ECF748", Offset = "0x1ECF748", VA = "0x1ECF748", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002780 RID: 10112
		// (get) Token: 0x06012B15 RID: 76565 RVA: 0x00078C90 File Offset: 0x00076E90
		// (set) Token: 0x06012B16 RID: 76566 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002780")]
		public CheckLeagueResponse Response
		{
			[Token(Token = "0x6012B15")]
			[Address(RVA = "0x1ECF750", Offset = "0x1ECF750", VA = "0x1ECF750")]
			get
			{
				return default(CheckLeagueResponse);
			}
			[Token(Token = "0x6012B16")]
			[Address(RVA = "0x1ECF75C", Offset = "0x1ECF75C", VA = "0x1ECF75C")]
			set
			{
			}
		}

		// Token: 0x06012B17 RID: 76567 RVA: 0x00078CA8 File Offset: 0x00076EA8
		[Token(Token = "0x6012B17")]
		[Address(RVA = "0x1ECF76C", Offset = "0x1ECF76C", VA = "0x1ECF76C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B18 RID: 76568 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B18")]
		[Address(RVA = "0x1ECF794", Offset = "0x1ECF794", VA = "0x1ECF794", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B19 RID: 76569 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B19")]
		[Address(RVA = "0x1ECF8C0", Offset = "0x1ECF8C0", VA = "0x1ECF8C0", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012B1A RID: 76570 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B1A")]
		[Address(RVA = "0x1ECF8C4", Offset = "0x1ECF8C4", VA = "0x1ECF8C4")]
		public CheckLeagueHttpCommand()
		{
		}

		// Token: 0x0400EBB8 RID: 60344
		[Token(Token = "0x400EBB8")]
		[FieldOffset(Offset = "0x18")]
		private CheckLeagueResponse <Response>k__BackingField;
	}
}
