﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TeamTreasure
{
	// Token: 0x02002534 RID: 9524
	[Token(Token = "0x2002534")]
	public class GetTeamTreasureInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700271C RID: 10012
		// (get) Token: 0x060129EE RID: 76270 RVA: 0x00077EE0 File Offset: 0x000760E0
		[Token(Token = "0x1700271C")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129EE")]
			[Address(RVA = "0x1CFC180", Offset = "0x1CFC180", VA = "0x1CFC180", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700271D RID: 10013
		// (get) Token: 0x060129EF RID: 76271 RVA: 0x00077EF8 File Offset: 0x000760F8
		[Token(Token = "0x1700271D")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x60129EF")]
			[Address(RVA = "0x1CFC188", Offset = "0x1CFC188", VA = "0x1CFC188", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x1700271E RID: 10014
		// (get) Token: 0x060129F0 RID: 76272 RVA: 0x00077F10 File Offset: 0x00076110
		// (set) Token: 0x060129F1 RID: 76273 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700271E")]
		public GetTeamTreasureInfoResponse Response
		{
			[Token(Token = "0x60129F0")]
			[Address(RVA = "0x1CFC190", Offset = "0x1CFC190", VA = "0x1CFC190")]
			get
			{
				return default(GetTeamTreasureInfoResponse);
			}
			[Token(Token = "0x60129F1")]
			[Address(RVA = "0x1CFC19C", Offset = "0x1CFC19C", VA = "0x1CFC19C")]
			set
			{
			}
		}

		// Token: 0x060129F2 RID: 76274 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129F2")]
		[Address(RVA = "0x1CFC1AC", Offset = "0x1CFC1AC", VA = "0x1CFC1AC")]
		public GetTeamTreasureInfoHttpCommand(int eventID)
		{
		}

		// Token: 0x060129F3 RID: 76275 RVA: 0x00077F28 File Offset: 0x00076128
		[Token(Token = "0x60129F3")]
		[Address(RVA = "0x1CFC1D4", Offset = "0x1CFC1D4", VA = "0x1CFC1D4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129F4 RID: 76276 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129F4")]
		[Address(RVA = "0x1CFC490", Offset = "0x1CFC490", VA = "0x1CFC490", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129F5 RID: 76277 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129F5")]
		[Address(RVA = "0x1CFC640", Offset = "0x1CFC640", VA = "0x1CFC640", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB3B RID: 60219
		[Token(Token = "0x400EB3B")]
		[FieldOffset(Offset = "0x18")]
		private GetTeamTreasureInfoResponse <Response>k__BackingField;

		// Token: 0x0400EB3C RID: 60220
		[Token(Token = "0x400EB3C")]
		[FieldOffset(Offset = "0x28")]
		private int eventId;
	}
}
