﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200234E RID: 9038
	[Token(Token = "0x200234E")]
	public struct CardCollectionSetProgress : IFlatbufferObject
	{
		// Token: 0x17001EFD RID: 7933
		// (get) Token: 0x06010C61 RID: 68705 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EFD")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010C61")]
			[Address(RVA = "0x2146428", Offset = "0x2146428", VA = "0x2146428", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010C62 RID: 68706 RVA: 0x000609C0 File Offset: 0x0005EBC0
		[Token(Token = "0x6010C62")]
		[Address(RVA = "0x2146430", Offset = "0x2146430", VA = "0x2146430")]
		public static CardCollectionSetProgress GetRootAsCardCollectionSetProgress(ByteBuffer _bb)
		{
			return default(CardCollectionSetProgress);
		}

		// Token: 0x06010C63 RID: 68707 RVA: 0x000609D8 File Offset: 0x0005EBD8
		[Token(Token = "0x6010C63")]
		[Address(RVA = "0x214643C", Offset = "0x214643C", VA = "0x214643C")]
		public static CardCollectionSetProgress GetRootAsCardCollectionSetProgress(ByteBuffer _bb, CardCollectionSetProgress obj)
		{
			return default(CardCollectionSetProgress);
		}

		// Token: 0x06010C64 RID: 68708 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C64")]
		[Address(RVA = "0x21464B4", Offset = "0x21464B4", VA = "0x21464B4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010C65 RID: 68709 RVA: 0x000609F0 File Offset: 0x0005EBF0
		[Token(Token = "0x6010C65")]
		[Address(RVA = "0x2146090", Offset = "0x2146090", VA = "0x2146090")]
		public CardCollectionSetProgress __assign(int _i, ByteBuffer _bb)
		{
			return default(CardCollectionSetProgress);
		}

		// Token: 0x17001EFE RID: 7934
		// (get) Token: 0x06010C66 RID: 68710 RVA: 0x00060A08 File Offset: 0x0005EC08
		[Token(Token = "0x17001EFE")]
		public int Id
		{
			[Token(Token = "0x6010C66")]
			[Address(RVA = "0x21464C4", Offset = "0x21464C4", VA = "0x21464C4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001EFF RID: 7935
		// (get) Token: 0x06010C67 RID: 68711 RVA: 0x00060A20 File Offset: 0x0005EC20
		[Token(Token = "0x17001EFF")]
		public int Value
		{
			[Token(Token = "0x6010C67")]
			[Address(RVA = "0x2146508", Offset = "0x2146508", VA = "0x2146508")]
			get
			{
				return 0;
			}
		}

		// Token: 0x06010C68 RID: 68712 RVA: 0x00060A38 File Offset: 0x0005EC38
		[Token(Token = "0x6010C68")]
		[Address(RVA = "0x214654C", Offset = "0x214654C", VA = "0x214654C")]
		public static Offset<CardCollectionSetProgress> CreateCardCollectionSetProgress(FlatBufferBuilder builder, int id = 0, int value = 0)
		{
			return default(Offset<CardCollectionSetProgress>);
		}

		// Token: 0x06010C69 RID: 68713 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C69")]
		[Address(RVA = "0x2146650", Offset = "0x2146650", VA = "0x2146650")]
		public static void StartCardCollectionSetProgress(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010C6A RID: 68714 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C6A")]
		[Address(RVA = "0x21465C4", Offset = "0x21465C4", VA = "0x21465C4")]
		public static void AddId(FlatBufferBuilder builder, int id)
		{
		}

		// Token: 0x06010C6B RID: 68715 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010C6B")]
		[Address(RVA = "0x21465A4", Offset = "0x21465A4", VA = "0x21465A4")]
		public static void AddValue(FlatBufferBuilder builder, int value)
		{
		}

		// Token: 0x06010C6C RID: 68716 RVA: 0x00060A50 File Offset: 0x0005EC50
		[Token(Token = "0x6010C6C")]
		[Address(RVA = "0x21465E4", Offset = "0x21465E4", VA = "0x21465E4")]
		public static Offset<CardCollectionSetProgress> EndCardCollectionSetProgress(FlatBufferBuilder builder)
		{
			return default(Offset<CardCollectionSetProgress>);
		}

		// Token: 0x0400E63D RID: 58941
		[Token(Token = "0x400E63D")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
