﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200239C RID: 9116
	[Token(Token = "0x200239C")]
	public struct EnterDailyLightningRushRequest : IFlatbufferObject
	{
		// Token: 0x17002030 RID: 8240
		// (get) Token: 0x060110C8 RID: 69832 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002030")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60110C8")]
			[Address(RVA = "0x1F9C220", Offset = "0x1F9C220", VA = "0x1F9C220", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110C9 RID: 69833 RVA: 0x000642F0 File Offset: 0x000624F0
		[Token(Token = "0x60110C9")]
		[Address(RVA = "0x1F9C228", Offset = "0x1F9C228", VA = "0x1F9C228")]
		public static EnterDailyLightningRushRequest GetRootAsEnterDailyLightningRushRequest(ByteBuffer _bb)
		{
			return default(EnterDailyLightningRushRequest);
		}

		// Token: 0x060110CA RID: 69834 RVA: 0x00064308 File Offset: 0x00062508
		[Token(Token = "0x60110CA")]
		[Address(RVA = "0x1F9C234", Offset = "0x1F9C234", VA = "0x1F9C234")]
		public static EnterDailyLightningRushRequest GetRootAsEnterDailyLightningRushRequest(ByteBuffer _bb, EnterDailyLightningRushRequest obj)
		{
			return default(EnterDailyLightningRushRequest);
		}

		// Token: 0x060110CB RID: 69835 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110CB")]
		[Address(RVA = "0x1F9C2E4", Offset = "0x1F9C2E4", VA = "0x1F9C2E4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060110CC RID: 69836 RVA: 0x00064320 File Offset: 0x00062520
		[Token(Token = "0x60110CC")]
		[Address(RVA = "0x1F9C2AC", Offset = "0x1F9C2AC", VA = "0x1F9C2AC")]
		public EnterDailyLightningRushRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterDailyLightningRushRequest);
		}

		// Token: 0x17002031 RID: 8241
		// (get) Token: 0x060110CD RID: 69837 RVA: 0x00064338 File Offset: 0x00062538
		[Token(Token = "0x17002031")]
		public int Level
		{
			[Token(Token = "0x60110CD")]
			[Address(RVA = "0x1F9C2F4", Offset = "0x1F9C2F4", VA = "0x1F9C2F4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002032 RID: 8242
		// (get) Token: 0x060110CE RID: 69838 RVA: 0x00064350 File Offset: 0x00062550
		[Token(Token = "0x17002032")]
		public int Step
		{
			[Token(Token = "0x60110CE")]
			[Address(RVA = "0x1F9C338", Offset = "0x1F9C338", VA = "0x1F9C338")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002033 RID: 8243
		// (get) Token: 0x060110CF RID: 69839 RVA: 0x00064368 File Offset: 0x00062568
		[Token(Token = "0x17002033")]
		public int ConfigVersion
		{
			[Token(Token = "0x60110CF")]
			[Address(RVA = "0x1F9C37C", Offset = "0x1F9C37C", VA = "0x1F9C37C")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060110D0 RID: 69840 RVA: 0x00064380 File Offset: 0x00062580
		[Token(Token = "0x60110D0")]
		[Address(RVA = "0x1F9C3C0", Offset = "0x1F9C3C0", VA = "0x1F9C3C0")]
		public static Offset<EnterDailyLightningRushRequest> CreateEnterDailyLightningRushRequest(FlatBufferBuilder builder, int level = 0, int step = 0, int config_version = 0)
		{
			return default(Offset<EnterDailyLightningRushRequest>);
		}

		// Token: 0x060110D1 RID: 69841 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110D1")]
		[Address(RVA = "0x1F9C4FC", Offset = "0x1F9C4FC", VA = "0x1F9C4FC")]
		public static void StartEnterDailyLightningRushRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060110D2 RID: 69842 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110D2")]
		[Address(RVA = "0x1F9C470", Offset = "0x1F9C470", VA = "0x1F9C470")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x060110D3 RID: 69843 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110D3")]
		[Address(RVA = "0x1F9C450", Offset = "0x1F9C450", VA = "0x1F9C450")]
		public static void AddStep(FlatBufferBuilder builder, int step)
		{
		}

		// Token: 0x060110D4 RID: 69844 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110D4")]
		[Address(RVA = "0x1F9C430", Offset = "0x1F9C430", VA = "0x1F9C430")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x060110D5 RID: 69845 RVA: 0x00064398 File Offset: 0x00062598
		[Token(Token = "0x60110D5")]
		[Address(RVA = "0x1F9C490", Offset = "0x1F9C490", VA = "0x1F9C490")]
		public static Offset<EnterDailyLightningRushRequest> EndEnterDailyLightningRushRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterDailyLightningRushRequest>);
		}

		// Token: 0x0400E6C1 RID: 59073
		[Token(Token = "0x400E6C1")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
