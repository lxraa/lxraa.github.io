﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002375 RID: 9077
	[Token(Token = "0x2002375")]
	public struct CustomPopup : IFlatbufferObject
	{
		// Token: 0x17001F9A RID: 8090
		// (get) Token: 0x06010E7E RID: 69246 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F9A")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010E7E")]
			[Address(RVA = "0x1F9331C", Offset = "0x1F9331C", VA = "0x1F9331C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E7F RID: 69247 RVA: 0x000624D8 File Offset: 0x000606D8
		[Token(Token = "0x6010E7F")]
		[Address(RVA = "0x1F93324", Offset = "0x1F93324", VA = "0x1F93324")]
		public static CustomPopup GetRootAsCustomPopup(ByteBuffer _bb)
		{
			return default(CustomPopup);
		}

		// Token: 0x06010E80 RID: 69248 RVA: 0x000624F0 File Offset: 0x000606F0
		[Token(Token = "0x6010E80")]
		[Address(RVA = "0x1F93330", Offset = "0x1F93330", VA = "0x1F93330")]
		public static CustomPopup GetRootAsCustomPopup(ByteBuffer _bb, CustomPopup obj)
		{
			return default(CustomPopup);
		}

		// Token: 0x06010E81 RID: 69249 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E81")]
		[Address(RVA = "0x1F933E0", Offset = "0x1F933E0", VA = "0x1F933E0", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010E82 RID: 69250 RVA: 0x00062508 File Offset: 0x00060708
		[Token(Token = "0x6010E82")]
		[Address(RVA = "0x1F933A8", Offset = "0x1F933A8", VA = "0x1F933A8")]
		public CustomPopup __assign(int _i, ByteBuffer _bb)
		{
			return default(CustomPopup);
		}

		// Token: 0x17001F9B RID: 8091
		// (get) Token: 0x06010E83 RID: 69251 RVA: 0x00062520 File Offset: 0x00060720
		[Token(Token = "0x17001F9B")]
		public int Id
		{
			[Token(Token = "0x6010E83")]
			[Address(RVA = "0x1F933F0", Offset = "0x1F933F0", VA = "0x1F933F0")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F9C RID: 8092
		// (get) Token: 0x06010E84 RID: 69252 RVA: 0x00062538 File Offset: 0x00060738
		[Token(Token = "0x17001F9C")]
		public int Version
		{
			[Token(Token = "0x6010E84")]
			[Address(RVA = "0x1F93434", Offset = "0x1F93434", VA = "0x1F93434")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F9D RID: 8093
		// (get) Token: 0x06010E85 RID: 69253 RVA: 0x00062550 File Offset: 0x00060750
		[Token(Token = "0x17001F9D")]
		public int Level
		{
			[Token(Token = "0x6010E85")]
			[Address(RVA = "0x1F93478", Offset = "0x1F93478", VA = "0x1F93478")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17001F9E RID: 8094
		// (get) Token: 0x06010E86 RID: 69254 RVA: 0x00062568 File Offset: 0x00060768
		[Token(Token = "0x17001F9E")]
		public long StartDate
		{
			[Token(Token = "0x6010E86")]
			[Address(RVA = "0x1F934BC", Offset = "0x1F934BC", VA = "0x1F934BC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001F9F RID: 8095
		// (get) Token: 0x06010E87 RID: 69255 RVA: 0x00062580 File Offset: 0x00060780
		[Token(Token = "0x17001F9F")]
		public long EndDate
		{
			[Token(Token = "0x6010E87")]
			[Address(RVA = "0x1F93504", Offset = "0x1F93504", VA = "0x1F93504")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17001FA0 RID: 8096
		// (get) Token: 0x06010E88 RID: 69256 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FA0")]
		public string ImageUrl
		{
			[Token(Token = "0x6010E88")]
			[Address(RVA = "0x1F9354C", Offset = "0x1F9354C", VA = "0x1F9354C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E89 RID: 69257 RVA: 0x00062598 File Offset: 0x00060798
		[Token(Token = "0x6010E89")]
		[Address(RVA = "0x1F93588", Offset = "0x1F93588", VA = "0x1F93588")]
		public ArraySegment<byte>? GetImageUrlBytes()
		{
			return null;
		}

		// Token: 0x06010E8A RID: 69258 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010E8A")]
		[Address(RVA = "0x1F935C0", Offset = "0x1F935C0", VA = "0x1F935C0")]
		public byte[] GetImageUrlArray()
		{
			return null;
		}

		// Token: 0x17001FA1 RID: 8097
		// (get) Token: 0x06010E8B RID: 69259 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001FA1")]
		public string Text
		{
			[Token(Token = "0x6010E8B")]
			[Address(RVA = "0x1F9360C", Offset = "0x1F9360C", VA = "0x1F9360C")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010E8C RID: 69260 RVA: 0x000625B0 File Offset: 0x000607B0
		[Token(Token = "0x6010E8C")]
		[Address(RVA = "0x1F93648", Offset = "0x1F93648", VA = "0x1F93648")]
		public ArraySegment<byte>? GetTextBytes()
		{
			return null;
		}

		// Token: 0x06010E8D RID: 69261 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6010E8D")]
		[Address(RVA = "0x1F93680", Offset = "0x1F93680", VA = "0x1F93680")]
		public byte[] GetTextArray()
		{
			return null;
		}

		// Token: 0x06010E8E RID: 69262 RVA: 0x000625C8 File Offset: 0x000607C8
		[Token(Token = "0x6010E8E")]
		[Address(RVA = "0x1F936CC", Offset = "0x1F936CC", VA = "0x1F936CC")]
		public static Offset<CustomPopup> CreateCustomPopup(FlatBufferBuilder builder, int id = 0, int version = 0, int level = 0, long startDate = 0L, long endDate = 0L, [Optional] StringOffset imageUrlOffset, [Optional] StringOffset textOffset)
		{
			return default(Offset<CustomPopup>);
		}

		// Token: 0x06010E8F RID: 69263 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E8F")]
		[Address(RVA = "0x1F938D8", Offset = "0x1F938D8", VA = "0x1F938D8")]
		public static void StartCustomPopup(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010E90 RID: 69264 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E90")]
		[Address(RVA = "0x1F9384C", Offset = "0x1F9384C", VA = "0x1F9384C")]
		public static void AddId(FlatBufferBuilder builder, int id)
		{
		}

		// Token: 0x06010E91 RID: 69265 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E91")]
		[Address(RVA = "0x1F9382C", Offset = "0x1F9382C", VA = "0x1F9382C")]
		public static void AddVersion(FlatBufferBuilder builder, int version)
		{
		}

		// Token: 0x06010E92 RID: 69266 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E92")]
		[Address(RVA = "0x1F9380C", Offset = "0x1F9380C", VA = "0x1F9380C")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x06010E93 RID: 69267 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E93")]
		[Address(RVA = "0x1F937AC", Offset = "0x1F937AC", VA = "0x1F937AC")]
		public static void AddStartDate(FlatBufferBuilder builder, long startDate)
		{
		}

		// Token: 0x06010E94 RID: 69268 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E94")]
		[Address(RVA = "0x1F9378C", Offset = "0x1F9378C", VA = "0x1F9378C")]
		public static void AddEndDate(FlatBufferBuilder builder, long endDate)
		{
		}

		// Token: 0x06010E95 RID: 69269 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E95")]
		[Address(RVA = "0x1F937EC", Offset = "0x1F937EC", VA = "0x1F937EC")]
		public static void AddImageUrl(FlatBufferBuilder builder, StringOffset imageUrlOffset)
		{
		}

		// Token: 0x06010E96 RID: 69270 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010E96")]
		[Address(RVA = "0x1F937CC", Offset = "0x1F937CC", VA = "0x1F937CC")]
		public static void AddText(FlatBufferBuilder builder, StringOffset textOffset)
		{
		}

		// Token: 0x06010E97 RID: 69271 RVA: 0x000625E0 File Offset: 0x000607E0
		[Token(Token = "0x6010E97")]
		[Address(RVA = "0x1F9386C", Offset = "0x1F9386C", VA = "0x1F9386C")]
		public static Offset<CustomPopup> EndCustomPopup(FlatBufferBuilder builder)
		{
			return default(Offset<CustomPopup>);
		}

		// Token: 0x0400E68E RID: 59022
		[Token(Token = "0x400E68E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
