﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.TeamTournament
{
	// Token: 0x02002537 RID: 9527
	[Token(Token = "0x2002537")]
	public class EnterTeamTournamentHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002722 RID: 10018
		// (get) Token: 0x060129FF RID: 76287 RVA: 0x00077FA0 File Offset: 0x000761A0
		[Token(Token = "0x17002722")]
		public override RequestType RequestType
		{
			[Token(Token = "0x60129FF")]
			[Address(RVA = "0x1CFCD70", Offset = "0x1CFCD70", VA = "0x1CFCD70", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002723 RID: 10019
		// (get) Token: 0x06012A00 RID: 76288 RVA: 0x00077FB8 File Offset: 0x000761B8
		[Token(Token = "0x17002723")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012A00")]
			[Address(RVA = "0x1CFCD78", Offset = "0x1CFCD78", VA = "0x1CFCD78", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012A01 RID: 76289 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A01")]
		[Address(RVA = "0x1CFCD80", Offset = "0x1CFCD80", VA = "0x1CFCD80")]
		public EnterTeamTournamentHttpCommand(long teamId, int tokenCount, int level, int eventId)
		{
		}

		// Token: 0x06012A02 RID: 76290 RVA: 0x00077FD0 File Offset: 0x000761D0
		[Token(Token = "0x6012A02")]
		[Address(RVA = "0x1CFCDC4", Offset = "0x1CFCDC4", VA = "0x1CFCDC4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012A03 RID: 76291 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A03")]
		[Address(RVA = "0x1CFCF38", Offset = "0x1CFCF38", VA = "0x1CFCF38", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012A04 RID: 76292 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012A04")]
		[Address(RVA = "0x1CFD168", Offset = "0x1CFD168", VA = "0x1CFD168", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB44 RID: 60228
		[Token(Token = "0x400EB44")]
		[FieldOffset(Offset = "0x18")]
		private readonly long teamId;

		// Token: 0x0400EB45 RID: 60229
		[Token(Token = "0x400EB45")]
		[FieldOffset(Offset = "0x20")]
		private readonly int tokenCount;

		// Token: 0x0400EB46 RID: 60230
		[Token(Token = "0x400EB46")]
		[FieldOffset(Offset = "0x24")]
		private readonly int level;

		// Token: 0x0400EB47 RID: 60231
		[Token(Token = "0x400EB47")]
		[FieldOffset(Offset = "0x28")]
		private readonly int eventId;
	}
}
