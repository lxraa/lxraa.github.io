﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Analytics.Event
{
	// Token: 0x020025A7 RID: 9639
	[Token(Token = "0x20025A7")]
	public class EventWriter
	{
		// Token: 0x06012D81 RID: 77185 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D81")]
		[Address(RVA = "0x243D308", Offset = "0x243D308", VA = "0x243D308")]
		public EventWriter()
		{
		}

		// Token: 0x06012D82 RID: 77186 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012D82")]
		[Address(RVA = "0x243D980", Offset = "0x243D980", VA = "0x243D980")]
		private static HttpClient CreateHttpClient()
		{
			return null;
		}

		// Token: 0x06012D83 RID: 77187 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D83")]
		[Address(RVA = "0x243D554", Offset = "0x243D554", VA = "0x243D554")]
		public void Start()
		{
		}

		// Token: 0x06012D84 RID: 77188 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D84")]
		[Address(RVA = "0x243D904", Offset = "0x243D904", VA = "0x243D904")]
		public void CallClear()
		{
		}

		// Token: 0x06012D85 RID: 77189 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D85")]
		[Address(RVA = "0x243D788", Offset = "0x243D788", VA = "0x243D788")]
		public void Stop()
		{
		}

		// Token: 0x06012D86 RID: 77190 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D86")]
		[Address(RVA = "0x243DDA4", Offset = "0x243DDA4", VA = "0x243DDA4")]
		private void Pause()
		{
		}

		// Token: 0x06012D87 RID: 77191 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D87")]
		[Address(RVA = "0x243D844", Offset = "0x243D844", VA = "0x243D844")]
		public void CallPause()
		{
		}

		// Token: 0x06012D88 RID: 77192 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D88")]
		[Address(RVA = "0x243D6F4", Offset = "0x243D6F4", VA = "0x243D6F4")]
		public void AddEventData(EventData data)
		{
		}

		// Token: 0x06012D89 RID: 77193 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D89")]
		[Address(RVA = "0x243E004", Offset = "0x243E004", VA = "0x243E004")]
		private void WriterLoop()
		{
		}

		// Token: 0x06012D8A RID: 77194 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D8A")]
		[Address(RVA = "0x243DE5C", Offset = "0x243DE5C", VA = "0x243DE5C")]
		private void Write()
		{
		}

		// Token: 0x06012D8B RID: 77195 RVA: 0x000799C8 File Offset: 0x00077BC8
		[Token(Token = "0x6012D8B")]
		[Address(RVA = "0x243E984", Offset = "0x243E984", VA = "0x243E984")]
		private bool BuildString(bool isOnPause)
		{
			return default(bool);
		}

		// Token: 0x06012D8C RID: 77196 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D8C")]
		[Address(RVA = "0x243F0AC", Offset = "0x243F0AC", VA = "0x243F0AC")]
		private void WriteToStream(StreamWriter streamWriter, string buffer, int state)
		{
		}

		// Token: 0x06012D8D RID: 77197 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D8D")]
		[Address(RVA = "0x243EA90", Offset = "0x243EA90", VA = "0x243EA90")]
		private void WriteToFile(bool shouldMoveFile)
		{
		}

		// Token: 0x06012D8E RID: 77198 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D8E")]
		[Address(RVA = "0x243F0E4", Offset = "0x243F0E4", VA = "0x243F0E4")]
		private void MoveFile(string path, bool isOnException = false)
		{
		}

		// Token: 0x06012D8F RID: 77199 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D8F")]
		[Address(RVA = "0x243F468", Offset = "0x243F468", VA = "0x243F468")]
		private void DeleteFile(string path)
		{
		}

		// Token: 0x06012D90 RID: 77200 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D90")]
		[Address(RVA = "0x243E0D4", Offset = "0x243E0D4", VA = "0x243E0D4")]
		private void Send()
		{
		}

		// Token: 0x06012D91 RID: 77201 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D91")]
		[Address(RVA = "0x243FCFC", Offset = "0x243FCFC", VA = "0x243FCFC")]
		private void UploadFile(string filePath)
		{
		}

		// Token: 0x06012D92 RID: 77202 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D92")]
		[Address(RVA = "0x243FDD8", Offset = "0x243FDD8", VA = "0x243FDD8")]
		private void CheckJson(ref string text)
		{
		}

		// Token: 0x06012D93 RID: 77203 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D93")]
		[Address(RVA = "0x2440024", Offset = "0x2440024", VA = "0x2440024")]
		private void CheckTempTrackingId(ref string text)
		{
		}

		// Token: 0x06012D94 RID: 77204 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D94")]
		[Address(RVA = "0x243F880", Offset = "0x243F880", VA = "0x243F880")]
		private static void SwitchUriScheme()
		{
		}

		// Token: 0x06012D95 RID: 77205 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D95")]
		[Address(RVA = "0x243F9F8", Offset = "0x243F9F8", VA = "0x243F9F8")]
		private static void SwitchToForbiddenUrl(EventWriter.ChangeToForbiddenUrlReason reason)
		{
		}

		// Token: 0x06012D96 RID: 77206 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D96")]
		[Address(RVA = "0x243F674", Offset = "0x243F674", VA = "0x243F674")]
		private static void SwitchToDefaultUrl()
		{
		}

		// Token: 0x06012D97 RID: 77207 RVA: 0x000799E0 File Offset: 0x00077BE0
		[Token(Token = "0x6012D97")]
		[Address(RVA = "0x243F998", Offset = "0x243F998", VA = "0x243F998")]
		private static bool IsDefaultUrl()
		{
			return default(bool);
		}

		// Token: 0x06012D98 RID: 77208 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012D98")]
		[Address(RVA = "0x243DBD8", Offset = "0x243DBD8", VA = "0x243DBD8")]
		private static void PrepareAnalyticsUri(string uriScheme)
		{
		}

		// Token: 0x06012D99 RID: 77209 RVA: 0x000799F8 File Offset: 0x00077BF8
		[Token(Token = "0x6012D99")]
		[Address(RVA = "0x243FBE0", Offset = "0x243FBE0", VA = "0x243FBE0")]
		private bool InternetAvailability()
		{
			return default(bool);
		}

		// Token: 0x0400ED54 RID: 60756
		[Token(Token = "0x400ED54")]
		[FieldOffset(Offset = "0x0")]
		private static string DefaultUrl;

		// Token: 0x0400ED55 RID: 60757
		[Token(Token = "0x400ED55")]
		[FieldOffset(Offset = "0x8")]
		private static string ForbiddenUrl;

		// Token: 0x0400ED56 RID: 60758
		[Token(Token = "0x400ED56")]
		[FieldOffset(Offset = "0x10")]
		private static string AnalyticsUrl;

		// Token: 0x0400ED57 RID: 60759
		[Token(Token = "0x400ED57")]
		[FieldOffset(Offset = "0x18")]
		private static string ResponseSuccess;

		// Token: 0x0400ED58 RID: 60760
		[Token(Token = "0x400ED58")]
		[FieldOffset(Offset = "0x20")]
		private static int MaxFileSize;

		// Token: 0x0400ED59 RID: 60761
		[Token(Token = "0x400ED59")]
		[FieldOffset(Offset = "0x28")]
		private static string WriterThreadName;

		// Token: 0x0400ED5A RID: 60762
		[Token(Token = "0x400ED5A")]
		[FieldOffset(Offset = "0x30")]
		private static string EventsFileName;

		// Token: 0x0400ED5B RID: 60763
		[Token(Token = "0x400ED5B")]
		[FieldOffset(Offset = "0x38")]
		private static string DateFormat;

		// Token: 0x0400ED5C RID: 60764
		[Token(Token = "0x400ED5C")]
		[FieldOffset(Offset = "0x40")]
		private static string Prefix;

		// Token: 0x0400ED5D RID: 60765
		[Token(Token = "0x400ED5D")]
		[FieldOffset(Offset = "0x48")]
		private static string Concat;

		// Token: 0x0400ED5E RID: 60766
		[Token(Token = "0x400ED5E")]
		[FieldOffset(Offset = "0x50")]
		private static string Suffix;

		// Token: 0x0400ED5F RID: 60767
		[Token(Token = "0x400ED5F")]
		[FieldOffset(Offset = "0x58")]
		private static string skippedEventsFileName;

		// Token: 0x0400ED60 RID: 60768
		[Token(Token = "0x400ED60")]
		[FieldOffset(Offset = "0x10")]
		private readonly string path1;

		// Token: 0x0400ED61 RID: 60769
		[Token(Token = "0x400ED61")]
		[FieldOffset(Offset = "0x60")]
		private static readonly string DirectoryPath;

		// Token: 0x0400ED62 RID: 60770
		[Token(Token = "0x400ED62")]
		[FieldOffset(Offset = "0x68")]
		private static Uri AnalyticsUri;

		// Token: 0x0400ED63 RID: 60771
		[Token(Token = "0x400ED63")]
		[FieldOffset(Offset = "0x18")]
		private Thread writerThread;

		// Token: 0x0400ED64 RID: 60772
		[Token(Token = "0x400ED64")]
		[FieldOffset(Offset = "0x20")]
		private bool shouldCheckTempUser;

		// Token: 0x0400ED65 RID: 60773
		[Token(Token = "0x400ED65")]
		[FieldOffset(Offset = "0x21")]
		private bool isRunning;

		// Token: 0x0400ED66 RID: 60774
		[Token(Token = "0x400ED66")]
		[FieldOffset(Offset = "0x22")]
		private bool isWriting;

		// Token: 0x0400ED67 RID: 60775
		[Token(Token = "0x400ED67")]
		[FieldOffset(Offset = "0x23")]
		private bool shouldPause;

		// Token: 0x0400ED68 RID: 60776
		[Token(Token = "0x400ED68")]
		[FieldOffset(Offset = "0x24")]
		private bool shouldClear;

		// Token: 0x0400ED69 RID: 60777
		[Token(Token = "0x400ED69")]
		[FieldOffset(Offset = "0x25")]
		private bool isWriteError;

		// Token: 0x0400ED6A RID: 60778
		[Token(Token = "0x400ED6A")]
		[FieldOffset(Offset = "0x28")]
		private int writeState;

		// Token: 0x0400ED6B RID: 60779
		[Token(Token = "0x400ED6B")]
		[FieldOffset(Offset = "0x2C")]
		private int sendTryCount;

		// Token: 0x0400ED6C RID: 60780
		[Token(Token = "0x400ED6C")]
		[FieldOffset(Offset = "0x30")]
		private string sendingFile;

		// Token: 0x0400ED6D RID: 60781
		[Token(Token = "0x400ED6D")]
		[FieldOffset(Offset = "0x38")]
		public string killEvent;

		// Token: 0x0400ED6E RID: 60782
		[Token(Token = "0x400ED6E")]
		[FieldOffset(Offset = "0x40")]
		private readonly StringBuilder eventBuilder;

		// Token: 0x0400ED6F RID: 60783
		[Token(Token = "0x400ED6F")]
		[FieldOffset(Offset = "0x48")]
		private readonly ConcurrentQueue<EventData> eventQueue;

		// Token: 0x0400ED70 RID: 60784
		[Token(Token = "0x400ED70")]
		[FieldOffset(Offset = "0x50")]
		private readonly HttpClient httpClient;

		// Token: 0x0400ED71 RID: 60785
		[Token(Token = "0x400ED71")]
		[FieldOffset(Offset = "0x58")]
		private readonly Ping ping;

		// Token: 0x0400ED72 RID: 60786
		[Token(Token = "0x400ED72")]
		[FieldOffset(Offset = "0x70")]
		private static EventWriter.ChangeToForbiddenUrlReason _changeToForbiddenUrlReason;

		// Token: 0x0400ED73 RID: 60787
		[Token(Token = "0x400ED73")]
		[FieldOffset(Offset = "0x74")]
		private static int countAfterUrlChangeToForbidden;

		// Token: 0x020025A8 RID: 9640
		[Token(Token = "0x20025A8")]
		private enum ChangeToForbiddenUrlReason
		{
			// Token: 0x0400ED75 RID: 60789
			[Token(Token = "0x400ED75")]
			GotForbiddenError,
			// Token: 0x0400ED76 RID: 60790
			[Token(Token = "0x400ED76")]
			DefaultUrlNotReachableAfterSeveralTries,
			// Token: 0x0400ED77 RID: 60791
			[Token(Token = "0x400ED77")]
			NoUrlChange
		}

		// Token: 0x020025A9 RID: 9641
		[Token(Token = "0x20025A9")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06012D9C RID: 77212 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012D9C")]
			[Address(RVA = "0x2440484", Offset = "0x2440484", VA = "0x2440484")]
			public <>c()
			{
			}

			// Token: 0x06012D9D RID: 77213 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012D9D")]
			[Address(RVA = "0x244048C", Offset = "0x244048C", VA = "0x244048C")]
			internal string <Send>b__48_0(string name)
			{
				return null;
			}

			// Token: 0x0400ED78 RID: 60792
			[Token(Token = "0x400ED78")]
			[FieldOffset(Offset = "0x0")]
			public static readonly EventWriter.<>c <>9;

			// Token: 0x0400ED79 RID: 60793
			[Token(Token = "0x400ED79")]
			[FieldOffset(Offset = "0x8")]
			public static Func<string, string> <>9__48_0;
		}
	}
}
