﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023CE RID: 9166
	[Token(Token = "0x20023CE")]
	public struct GetDragonNestSuggestionsAndInvitationsRequest : IFlatbufferObject
	{
		// Token: 0x170020E0 RID: 8416
		// (get) Token: 0x06011351 RID: 70481 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020E0")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011351")]
			[Address(RVA = "0x1CAE044", Offset = "0x1CAE044", VA = "0x1CAE044", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011352 RID: 70482 RVA: 0x000664B0 File Offset: 0x000646B0
		[Token(Token = "0x6011352")]
		[Address(RVA = "0x1CAE04C", Offset = "0x1CAE04C", VA = "0x1CAE04C")]
		public static GetDragonNestSuggestionsAndInvitationsRequest GetRootAsGetDragonNestSuggestionsAndInvitationsRequest(ByteBuffer _bb)
		{
			return default(GetDragonNestSuggestionsAndInvitationsRequest);
		}

		// Token: 0x06011353 RID: 70483 RVA: 0x000664C8 File Offset: 0x000646C8
		[Token(Token = "0x6011353")]
		[Address(RVA = "0x1CAE058", Offset = "0x1CAE058", VA = "0x1CAE058")]
		public static GetDragonNestSuggestionsAndInvitationsRequest GetRootAsGetDragonNestSuggestionsAndInvitationsRequest(ByteBuffer _bb, GetDragonNestSuggestionsAndInvitationsRequest obj)
		{
			return default(GetDragonNestSuggestionsAndInvitationsRequest);
		}

		// Token: 0x06011354 RID: 70484 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011354")]
		[Address(RVA = "0x1CAE108", Offset = "0x1CAE108", VA = "0x1CAE108", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06011355 RID: 70485 RVA: 0x000664E0 File Offset: 0x000646E0
		[Token(Token = "0x6011355")]
		[Address(RVA = "0x1CAE0D0", Offset = "0x1CAE0D0", VA = "0x1CAE0D0")]
		public GetDragonNestSuggestionsAndInvitationsRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(GetDragonNestSuggestionsAndInvitationsRequest);
		}

		// Token: 0x170020E1 RID: 8417
		// (get) Token: 0x06011356 RID: 70486 RVA: 0x000664F8 File Offset: 0x000646F8
		[Token(Token = "0x170020E1")]
		public bool IsTutorial
		{
			[Token(Token = "0x6011356")]
			[Address(RVA = "0x1CAE118", Offset = "0x1CAE118", VA = "0x1CAE118")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06011357 RID: 70487 RVA: 0x00066510 File Offset: 0x00064710
		[Token(Token = "0x6011357")]
		[Address(RVA = "0x1CAE160", Offset = "0x1CAE160", VA = "0x1CAE160")]
		public static Offset<GetDragonNestSuggestionsAndInvitationsRequest> CreateGetDragonNestSuggestionsAndInvitationsRequest(FlatBufferBuilder builder, bool is_tutorial = false)
		{
			return default(Offset<GetDragonNestSuggestionsAndInvitationsRequest>);
		}

		// Token: 0x06011358 RID: 70488 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011358")]
		[Address(RVA = "0x1CAE234", Offset = "0x1CAE234", VA = "0x1CAE234")]
		public static void StartGetDragonNestSuggestionsAndInvitationsRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011359 RID: 70489 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011359")]
		[Address(RVA = "0x1CAE1A8", Offset = "0x1CAE1A8", VA = "0x1CAE1A8")]
		public static void AddIsTutorial(FlatBufferBuilder builder, bool isTutorial)
		{
		}

		// Token: 0x0601135A RID: 70490 RVA: 0x00066528 File Offset: 0x00064728
		[Token(Token = "0x601135A")]
		[Address(RVA = "0x1CAE1C8", Offset = "0x1CAE1C8", VA = "0x1CAE1C8")]
		public static Offset<GetDragonNestSuggestionsAndInvitationsRequest> EndGetDragonNestSuggestionsAndInvitationsRequest(FlatBufferBuilder builder)
		{
			return default(Offset<GetDragonNestSuggestionsAndInvitationsRequest>);
		}

		// Token: 0x0400E73E RID: 59198
		[Token(Token = "0x400E73E")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
