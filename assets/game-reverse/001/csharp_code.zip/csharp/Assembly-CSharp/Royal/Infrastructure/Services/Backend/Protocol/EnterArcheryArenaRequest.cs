﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002399 RID: 9113
	[Token(Token = "0x2002399")]
	public struct EnterArcheryArenaRequest : IFlatbufferObject
	{
		// Token: 0x17002026 RID: 8230
		// (get) Token: 0x060110A8 RID: 69800 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002026")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60110A8")]
			[Address(RVA = "0x1F9BA50", Offset = "0x1F9BA50", VA = "0x1F9BA50", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060110A9 RID: 69801 RVA: 0x00064140 File Offset: 0x00062340
		[Token(Token = "0x60110A9")]
		[Address(RVA = "0x1F9BA58", Offset = "0x1F9BA58", VA = "0x1F9BA58")]
		public static EnterArcheryArenaRequest GetRootAsEnterArcheryArenaRequest(ByteBuffer _bb)
		{
			return default(EnterArcheryArenaRequest);
		}

		// Token: 0x060110AA RID: 69802 RVA: 0x00064158 File Offset: 0x00062358
		[Token(Token = "0x60110AA")]
		[Address(RVA = "0x1F9BA64", Offset = "0x1F9BA64", VA = "0x1F9BA64")]
		public static EnterArcheryArenaRequest GetRootAsEnterArcheryArenaRequest(ByteBuffer _bb, EnterArcheryArenaRequest obj)
		{
			return default(EnterArcheryArenaRequest);
		}

		// Token: 0x060110AB RID: 69803 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110AB")]
		[Address(RVA = "0x1F9BB14", Offset = "0x1F9BB14", VA = "0x1F9BB14", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060110AC RID: 69804 RVA: 0x00064170 File Offset: 0x00062370
		[Token(Token = "0x60110AC")]
		[Address(RVA = "0x1F9BADC", Offset = "0x1F9BADC", VA = "0x1F9BADC")]
		public EnterArcheryArenaRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(EnterArcheryArenaRequest);
		}

		// Token: 0x17002027 RID: 8231
		// (get) Token: 0x060110AD RID: 69805 RVA: 0x00064188 File Offset: 0x00062388
		[Token(Token = "0x17002027")]
		public int Level
		{
			[Token(Token = "0x60110AD")]
			[Address(RVA = "0x1F9BB24", Offset = "0x1F9BB24", VA = "0x1F9BB24")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002028 RID: 8232
		// (get) Token: 0x060110AE RID: 69806 RVA: 0x000641A0 File Offset: 0x000623A0
		[Token(Token = "0x17002028")]
		public int Score
		{
			[Token(Token = "0x60110AE")]
			[Address(RVA = "0x1F9BB68", Offset = "0x1F9BB68", VA = "0x1F9BB68")]
			get
			{
				return 0;
			}
		}

		// Token: 0x17002029 RID: 8233
		// (get) Token: 0x060110AF RID: 69807 RVA: 0x000641B8 File Offset: 0x000623B8
		[Token(Token = "0x17002029")]
		public int ConfigVersion
		{
			[Token(Token = "0x60110AF")]
			[Address(RVA = "0x1F9BBAC", Offset = "0x1F9BBAC", VA = "0x1F9BBAC")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060110B0 RID: 69808 RVA: 0x000641D0 File Offset: 0x000623D0
		[Token(Token = "0x60110B0")]
		[Address(RVA = "0x1F9BBF0", Offset = "0x1F9BBF0", VA = "0x1F9BBF0")]
		public static Offset<EnterArcheryArenaRequest> CreateEnterArcheryArenaRequest(FlatBufferBuilder builder, int level = 0, int score = 0, int config_version = 0)
		{
			return default(Offset<EnterArcheryArenaRequest>);
		}

		// Token: 0x060110B1 RID: 69809 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110B1")]
		[Address(RVA = "0x1F9BD2C", Offset = "0x1F9BD2C", VA = "0x1F9BD2C")]
		public static void StartEnterArcheryArenaRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060110B2 RID: 69810 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110B2")]
		[Address(RVA = "0x1F9BCA0", Offset = "0x1F9BCA0", VA = "0x1F9BCA0")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x060110B3 RID: 69811 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110B3")]
		[Address(RVA = "0x1F9BC80", Offset = "0x1F9BC80", VA = "0x1F9BC80")]
		public static void AddScore(FlatBufferBuilder builder, int score)
		{
		}

		// Token: 0x060110B4 RID: 69812 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60110B4")]
		[Address(RVA = "0x1F9BC60", Offset = "0x1F9BC60", VA = "0x1F9BC60")]
		public static void AddConfigVersion(FlatBufferBuilder builder, int configVersion)
		{
		}

		// Token: 0x060110B5 RID: 69813 RVA: 0x000641E8 File Offset: 0x000623E8
		[Token(Token = "0x60110B5")]
		[Address(RVA = "0x1F9BCC0", Offset = "0x1F9BCC0", VA = "0x1F9BCC0")]
		public static Offset<EnterArcheryArenaRequest> EndEnterArcheryArenaRequest(FlatBufferBuilder builder)
		{
			return default(Offset<EnterArcheryArenaRequest>);
		}

		// Token: 0x0400E6BA RID: 59066
		[Token(Token = "0x400E6BA")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
