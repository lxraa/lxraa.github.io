﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.OceanOdyssey
{
	// Token: 0x02002556 RID: 9558
	[Token(Token = "0x2002556")]
	public class GetOceanOdysseyInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700276D RID: 10093
		// (get) Token: 0x06012ADF RID: 76511 RVA: 0x000789C0 File Offset: 0x00076BC0
		[Token(Token = "0x1700276D")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012ADF")]
			[Address(RVA = "0x1ECE120", Offset = "0x1ECE120", VA = "0x1ECE120", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700276E RID: 10094
		// (get) Token: 0x06012AE0 RID: 76512 RVA: 0x000789D8 File Offset: 0x00076BD8
		[Token(Token = "0x1700276E")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AE0")]
			[Address(RVA = "0x1ECE128", Offset = "0x1ECE128", VA = "0x1ECE128", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AE1 RID: 76513 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AE1")]
		[Address(RVA = "0x1ECE130", Offset = "0x1ECE130", VA = "0x1ECE130")]
		public GetOceanOdysseyInfoHttpCommand(int eventId)
		{
		}

		// Token: 0x06012AE2 RID: 76514 RVA: 0x000789F0 File Offset: 0x00076BF0
		[Token(Token = "0x6012AE2")]
		[Address(RVA = "0x1ECE160", Offset = "0x1ECE160", VA = "0x1ECE160", Slot = "9")]
		public override bool IsSameCommand(BaseHttpCommand other)
		{
			return default(bool);
		}

		// Token: 0x06012AE3 RID: 76515 RVA: 0x00078A08 File Offset: 0x00076C08
		[Token(Token = "0x6012AE3")]
		[Address(RVA = "0x1ECE220", Offset = "0x1ECE220", VA = "0x1ECE220", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AE4 RID: 76516 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AE4")]
		[Address(RVA = "0x1ECE240", Offset = "0x1ECE240", VA = "0x1ECE240", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AE5 RID: 76517 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AE5")]
		[Address(RVA = "0x1ECE318", Offset = "0x1ECE318", VA = "0x1ECE318", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBAD RID: 60333
		[Token(Token = "0x400EBAD")]
		[FieldOffset(Offset = "0x14")]
		private readonly int eventId;
	}
}
