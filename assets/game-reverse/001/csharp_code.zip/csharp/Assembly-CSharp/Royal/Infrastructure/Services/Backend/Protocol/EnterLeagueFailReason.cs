﻿using System;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023A1 RID: 9121
	[Token(Token = "0x20023A1")]
	public enum EnterLeagueFailReason : sbyte
	{
		// Token: 0x0400E6CB RID: 59083
		[Token(Token = "0x400E6CB")]
		None,
		// Token: 0x0400E6CC RID: 59084
		[Token(Token = "0x400E6CC")]
		LeagueIsNotActive,
		// Token: 0x0400E6CD RID: 59085
		[Token(Token = "0x400E6CD")]
		LeagueIsAboutToEnd,
		// Token: 0x0400E6CE RID: 59086
		[Token(Token = "0x400E6CE")]
		InvalidName,
		// Token: 0x0400E6CF RID: 59087
		[Token(Token = "0x400E6CF")]
		NameContainsSlang
	}
}
