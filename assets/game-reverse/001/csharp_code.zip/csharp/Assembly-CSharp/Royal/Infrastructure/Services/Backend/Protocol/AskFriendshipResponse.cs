﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x0200233F RID: 9023
	[Token(Token = "0x200233F")]
	public struct AskFriendshipResponse : IFlatbufferObject
	{
		// Token: 0x17001ECC RID: 7884
		// (get) Token: 0x06010B91 RID: 68497 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001ECC")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010B91")]
			[Address(RVA = "0x2143288", Offset = "0x2143288", VA = "0x2143288", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010B92 RID: 68498 RVA: 0x0005FF58 File Offset: 0x0005E158
		[Token(Token = "0x6010B92")]
		[Address(RVA = "0x2143290", Offset = "0x2143290", VA = "0x2143290")]
		public static AskFriendshipResponse GetRootAsAskFriendshipResponse(ByteBuffer _bb)
		{
			return default(AskFriendshipResponse);
		}

		// Token: 0x06010B93 RID: 68499 RVA: 0x0005FF70 File Offset: 0x0005E170
		[Token(Token = "0x6010B93")]
		[Address(RVA = "0x214329C", Offset = "0x214329C", VA = "0x214329C")]
		public static AskFriendshipResponse GetRootAsAskFriendshipResponse(ByteBuffer _bb, AskFriendshipResponse obj)
		{
			return default(AskFriendshipResponse);
		}

		// Token: 0x06010B94 RID: 68500 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B94")]
		[Address(RVA = "0x214334C", Offset = "0x214334C", VA = "0x214334C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010B95 RID: 68501 RVA: 0x0005FF88 File Offset: 0x0005E188
		[Token(Token = "0x6010B95")]
		[Address(RVA = "0x2143314", Offset = "0x2143314", VA = "0x2143314")]
		public AskFriendshipResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(AskFriendshipResponse);
		}

		// Token: 0x17001ECD RID: 7885
		// (get) Token: 0x06010B96 RID: 68502 RVA: 0x0005FFA0 File Offset: 0x0005E1A0
		[Token(Token = "0x17001ECD")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x6010B96")]
			[Address(RVA = "0x214335C", Offset = "0x214335C", VA = "0x214335C")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x17001ECE RID: 7886
		// (get) Token: 0x06010B97 RID: 68503 RVA: 0x0005FFB8 File Offset: 0x0005E1B8
		[Token(Token = "0x17001ECE")]
		public AskFriendshipResult Result
		{
			[Token(Token = "0x6010B97")]
			[Address(RVA = "0x21433A0", Offset = "0x21433A0", VA = "0x21433A0")]
			get
			{
				return AskFriendshipResult.Success;
			}
		}

		// Token: 0x06010B98 RID: 68504 RVA: 0x0005FFD0 File Offset: 0x0005E1D0
		[Token(Token = "0x6010B98")]
		[Address(RVA = "0x21433E4", Offset = "0x21433E4", VA = "0x21433E4")]
		public static Offset<AskFriendshipResponse> CreateAskFriendshipResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, AskFriendshipResult result = AskFriendshipResult.Success)
		{
			return default(Offset<AskFriendshipResponse>);
		}

		// Token: 0x06010B99 RID: 68505 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B99")]
		[Address(RVA = "0x21434E8", Offset = "0x21434E8", VA = "0x21434E8")]
		public static void StartAskFriendshipResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010B9A RID: 68506 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B9A")]
		[Address(RVA = "0x214345C", Offset = "0x214345C", VA = "0x214345C")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x06010B9B RID: 68507 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010B9B")]
		[Address(RVA = "0x214343C", Offset = "0x214343C", VA = "0x214343C")]
		public static void AddResult(FlatBufferBuilder builder, AskFriendshipResult result)
		{
		}

		// Token: 0x06010B9C RID: 68508 RVA: 0x0005FFE8 File Offset: 0x0005E1E8
		[Token(Token = "0x6010B9C")]
		[Address(RVA = "0x214347C", Offset = "0x214347C", VA = "0x214347C")]
		public static Offset<AskFriendshipResponse> EndAskFriendshipResponse(FlatBufferBuilder builder)
		{
			return default(Offset<AskFriendshipResponse>);
		}

		// Token: 0x0400E620 RID: 58912
		[Token(Token = "0x400E620")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
