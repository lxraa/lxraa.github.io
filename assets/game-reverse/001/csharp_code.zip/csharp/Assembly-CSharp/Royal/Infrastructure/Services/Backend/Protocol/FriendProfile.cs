﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023B9 RID: 9145
	[Token(Token = "0x20023B9")]
	public struct FriendProfile : IFlatbufferObject
	{
		// Token: 0x17002097 RID: 8343
		// (get) Token: 0x06011249 RID: 70217 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002097")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6011249")]
			[Address(RVA = "0x1CAA078", Offset = "0x1CAA078", VA = "0x1CAA078", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601124A RID: 70218 RVA: 0x00065718 File Offset: 0x00063918
		[Token(Token = "0x601124A")]
		[Address(RVA = "0x1CAA080", Offset = "0x1CAA080", VA = "0x1CAA080")]
		public static FriendProfile GetRootAsFriendProfile(ByteBuffer _bb)
		{
			return default(FriendProfile);
		}

		// Token: 0x0601124B RID: 70219 RVA: 0x00065730 File Offset: 0x00063930
		[Token(Token = "0x601124B")]
		[Address(RVA = "0x1CAA08C", Offset = "0x1CAA08C", VA = "0x1CAA08C")]
		public static FriendProfile GetRootAsFriendProfile(ByteBuffer _bb, FriendProfile obj)
		{
			return default(FriendProfile);
		}

		// Token: 0x0601124C RID: 70220 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601124C")]
		[Address(RVA = "0x1CAA13C", Offset = "0x1CAA13C", VA = "0x1CAA13C", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x0601124D RID: 70221 RVA: 0x00065748 File Offset: 0x00063948
		[Token(Token = "0x601124D")]
		[Address(RVA = "0x1CAA104", Offset = "0x1CAA104", VA = "0x1CAA104")]
		public FriendProfile __assign(int _i, ByteBuffer _bb)
		{
			return default(FriendProfile);
		}

		// Token: 0x17002098 RID: 8344
		// (get) Token: 0x0601124E RID: 70222 RVA: 0x00065760 File Offset: 0x00063960
		[Token(Token = "0x17002098")]
		public long UserId
		{
			[Token(Token = "0x601124E")]
			[Address(RVA = "0x1CAA14C", Offset = "0x1CAA14C", VA = "0x1CAA14C")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x17002099 RID: 8345
		// (get) Token: 0x0601124F RID: 70223 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002099")]
		public string Name
		{
			[Token(Token = "0x601124F")]
			[Address(RVA = "0x1CAA194", Offset = "0x1CAA194", VA = "0x1CAA194")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011250 RID: 70224 RVA: 0x00065778 File Offset: 0x00063978
		[Token(Token = "0x6011250")]
		[Address(RVA = "0x1CAA1D0", Offset = "0x1CAA1D0", VA = "0x1CAA1D0")]
		public ArraySegment<byte>? GetNameBytes()
		{
			return null;
		}

		// Token: 0x06011251 RID: 70225 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011251")]
		[Address(RVA = "0x1CAA208", Offset = "0x1CAA208", VA = "0x1CAA208")]
		public byte[] GetNameArray()
		{
			return null;
		}

		// Token: 0x1700209A RID: 8346
		// (get) Token: 0x06011252 RID: 70226 RVA: 0x00065790 File Offset: 0x00063990
		[Token(Token = "0x1700209A")]
		public int Level
		{
			[Token(Token = "0x6011252")]
			[Address(RVA = "0x1CAA254", Offset = "0x1CAA254", VA = "0x1CAA254")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700209B RID: 8347
		// (get) Token: 0x06011253 RID: 70227 RVA: 0x000657A8 File Offset: 0x000639A8
		[Token(Token = "0x1700209B")]
		public int Crown
		{
			[Token(Token = "0x6011253")]
			[Address(RVA = "0x1CAA298", Offset = "0x1CAA298", VA = "0x1CAA298")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700209C RID: 8348
		// (get) Token: 0x06011254 RID: 70228 RVA: 0x000657C0 File Offset: 0x000639C0
		[Token(Token = "0x1700209C")]
		public long TeamId
		{
			[Token(Token = "0x6011254")]
			[Address(RVA = "0x1CAA2DC", Offset = "0x1CAA2DC", VA = "0x1CAA2DC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x1700209D RID: 8349
		// (get) Token: 0x06011255 RID: 70229 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700209D")]
		public string TeamName
		{
			[Token(Token = "0x6011255")]
			[Address(RVA = "0x1CAA324", Offset = "0x1CAA324", VA = "0x1CAA324")]
			get
			{
				return null;
			}
		}

		// Token: 0x06011256 RID: 70230 RVA: 0x000657D8 File Offset: 0x000639D8
		[Token(Token = "0x6011256")]
		[Address(RVA = "0x1CAA360", Offset = "0x1CAA360", VA = "0x1CAA360")]
		public ArraySegment<byte>? GetTeamNameBytes()
		{
			return null;
		}

		// Token: 0x06011257 RID: 70231 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6011257")]
		[Address(RVA = "0x1CAA398", Offset = "0x1CAA398", VA = "0x1CAA398")]
		public byte[] GetTeamNameArray()
		{
			return null;
		}

		// Token: 0x1700209E RID: 8350
		// (get) Token: 0x06011258 RID: 70232 RVA: 0x000657F0 File Offset: 0x000639F0
		[Token(Token = "0x1700209E")]
		public int TeamLogo
		{
			[Token(Token = "0x6011258")]
			[Address(RVA = "0x1CAA3E4", Offset = "0x1CAA3E4", VA = "0x1CAA3E4")]
			get
			{
				return 0;
			}
		}

		// Token: 0x1700209F RID: 8351
		// (get) Token: 0x06011259 RID: 70233 RVA: 0x00065808 File Offset: 0x00063A08
		[Token(Token = "0x1700209F")]
		public bool DeprecatedIsGold
		{
			[Token(Token = "0x6011259")]
			[Address(RVA = "0x1CAA428", Offset = "0x1CAA428", VA = "0x1CAA428")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170020A0 RID: 8352
		// (get) Token: 0x0601125A RID: 70234 RVA: 0x00065820 File Offset: 0x00063A20
		[Token(Token = "0x170020A0")]
		public bool HasSpecialNameStyle
		{
			[Token(Token = "0x601125A")]
			[Address(RVA = "0x1CAA470", Offset = "0x1CAA470", VA = "0x1CAA470")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x170020A1 RID: 8353
		// (get) Token: 0x0601125B RID: 70235 RVA: 0x00065838 File Offset: 0x00063A38
		[Token(Token = "0x170020A1")]
		public ProfileSetting? ProfileSetting
		{
			[Token(Token = "0x601125B")]
			[Address(RVA = "0x1CAA4B8", Offset = "0x1CAA4B8", VA = "0x1CAA4B8")]
			get
			{
				return null;
			}
		}

		// Token: 0x170020A2 RID: 8354
		// (get) Token: 0x0601125C RID: 70236 RVA: 0x00065850 File Offset: 0x00063A50
		[Token(Token = "0x170020A2")]
		public FriendType Type
		{
			[Token(Token = "0x601125C")]
			[Address(RVA = "0x1CAA578", Offset = "0x1CAA578", VA = "0x1CAA578")]
			get
			{
				return FriendType.Requested;
			}
		}

		// Token: 0x170020A3 RID: 8355
		// (get) Token: 0x0601125D RID: 70237 RVA: 0x00065868 File Offset: 0x00063A68
		[Token(Token = "0x170020A3")]
		public long LastLevelUpdateDate
		{
			[Token(Token = "0x601125D")]
			[Address(RVA = "0x1CAA5BC", Offset = "0x1CAA5BC", VA = "0x1CAA5BC")]
			get
			{
				return 0L;
			}
		}

		// Token: 0x170020A4 RID: 8356
		// (get) Token: 0x0601125E RID: 70238 RVA: 0x00065880 File Offset: 0x00063A80
		[Token(Token = "0x170020A4")]
		public WorldCupBadge? WorldCupBadge
		{
			[Token(Token = "0x601125E")]
			[Address(RVA = "0x1CAA604", Offset = "0x1CAA604", VA = "0x1CAA604")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601125F RID: 70239 RVA: 0x00065898 File Offset: 0x00063A98
		[Token(Token = "0x601125F")]
		[Address(RVA = "0x1CAA6C4", Offset = "0x1CAA6C4", VA = "0x1CAA6C4")]
		public static Offset<FriendProfile> CreateFriendProfile(FlatBufferBuilder builder, long user_id = 0L, [Optional] StringOffset nameOffset, int level = 0, int crown = 0, long team_id = 0L, [Optional] StringOffset team_nameOffset, int team_logo = 0, bool deprecated_is_gold = false, bool has_special_name_style = false, [Optional] Offset<ProfileSetting> profile_settingOffset, FriendType type = FriendType.Requested, long last_level_update_date = 0L, [Optional] Offset<WorldCupBadge> world_cup_badgeOffset)
		{
			return default(Offset<FriendProfile>);
		}

		// Token: 0x06011260 RID: 70240 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011260")]
		[Address(RVA = "0x1CAAA08", Offset = "0x1CAAA08", VA = "0x1CAAA08")]
		public static void StartFriendProfile(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06011261 RID: 70241 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011261")]
		[Address(RVA = "0x1CAA83C", Offset = "0x1CAA83C", VA = "0x1CAA83C")]
		public static void AddUserId(FlatBufferBuilder builder, long userId)
		{
		}

		// Token: 0x06011262 RID: 70242 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011262")]
		[Address(RVA = "0x1CAA93C", Offset = "0x1CAA93C", VA = "0x1CAA93C")]
		public static void AddName(FlatBufferBuilder builder, StringOffset nameOffset)
		{
		}

		// Token: 0x06011263 RID: 70243 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011263")]
		[Address(RVA = "0x1CAA91C", Offset = "0x1CAA91C", VA = "0x1CAA91C")]
		public static void AddLevel(FlatBufferBuilder builder, int level)
		{
		}

		// Token: 0x06011264 RID: 70244 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011264")]
		[Address(RVA = "0x1CAA8FC", Offset = "0x1CAA8FC", VA = "0x1CAA8FC")]
		public static void AddCrown(FlatBufferBuilder builder, int crown)
		{
		}

		// Token: 0x06011265 RID: 70245 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011265")]
		[Address(RVA = "0x1CAA81C", Offset = "0x1CAA81C", VA = "0x1CAA81C")]
		public static void AddTeamId(FlatBufferBuilder builder, long teamId)
		{
		}

		// Token: 0x06011266 RID: 70246 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011266")]
		[Address(RVA = "0x1CAA8DC", Offset = "0x1CAA8DC", VA = "0x1CAA8DC")]
		public static void AddTeamName(FlatBufferBuilder builder, StringOffset teamNameOffset)
		{
		}

		// Token: 0x06011267 RID: 70247 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011267")]
		[Address(RVA = "0x1CAA8BC", Offset = "0x1CAA8BC", VA = "0x1CAA8BC")]
		public static void AddTeamLogo(FlatBufferBuilder builder, int teamLogo)
		{
		}

		// Token: 0x06011268 RID: 70248 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011268")]
		[Address(RVA = "0x1CAA97C", Offset = "0x1CAA97C", VA = "0x1CAA97C")]
		public static void AddDeprecatedIsGold(FlatBufferBuilder builder, bool deprecatedIsGold)
		{
		}

		// Token: 0x06011269 RID: 70249 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6011269")]
		[Address(RVA = "0x1CAA95C", Offset = "0x1CAA95C", VA = "0x1CAA95C")]
		public static void AddHasSpecialNameStyle(FlatBufferBuilder builder, bool hasSpecialNameStyle)
		{
		}

		// Token: 0x0601126A RID: 70250 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601126A")]
		[Address(RVA = "0x1CAA89C", Offset = "0x1CAA89C", VA = "0x1CAA89C")]
		public static void AddProfileSetting(FlatBufferBuilder builder, Offset<ProfileSetting> profileSettingOffset)
		{
		}

		// Token: 0x0601126B RID: 70251 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601126B")]
		[Address(RVA = "0x1CAA87C", Offset = "0x1CAA87C", VA = "0x1CAA87C")]
		public static void AddType(FlatBufferBuilder builder, FriendType type)
		{
		}

		// Token: 0x0601126C RID: 70252 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601126C")]
		[Address(RVA = "0x1CAA7FC", Offset = "0x1CAA7FC", VA = "0x1CAA7FC")]
		public static void AddLastLevelUpdateDate(FlatBufferBuilder builder, long lastLevelUpdateDate)
		{
		}

		// Token: 0x0601126D RID: 70253 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601126D")]
		[Address(RVA = "0x1CAA85C", Offset = "0x1CAA85C", VA = "0x1CAA85C")]
		public static void AddWorldCupBadge(FlatBufferBuilder builder, Offset<WorldCupBadge> worldCupBadgeOffset)
		{
		}

		// Token: 0x0601126E RID: 70254 RVA: 0x000658B0 File Offset: 0x00063AB0
		[Token(Token = "0x601126E")]
		[Address(RVA = "0x1CAA99C", Offset = "0x1CAA99C", VA = "0x1CAA99C")]
		public static Offset<FriendProfile> EndFriendProfile(FlatBufferBuilder builder)
		{
			return default(Offset<FriendProfile>);
		}

		// Token: 0x0400E6F0 RID: 59120
		[Token(Token = "0x400E6F0")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
