﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;
using Royal.Scenes.Home.Ui.Sections.Home.UserProfile;

namespace Royal.Infrastructure.Services.Backend.Http.Command.UserProfile
{
	// Token: 0x02002528 RID: 9512
	[Token(Token = "0x2002528")]
	public class GetProfileHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002700 RID: 9984
		// (get) Token: 0x0601299C RID: 76188 RVA: 0x00077AF0 File Offset: 0x00075CF0
		[Token(Token = "0x17002700")]
		public override RequestType RequestType
		{
			[Token(Token = "0x601299C")]
			[Address(RVA = "0x1CF9404", Offset = "0x1CF9404", VA = "0x1CF9404", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002701 RID: 9985
		// (get) Token: 0x0601299D RID: 76189 RVA: 0x00077B08 File Offset: 0x00075D08
		[Token(Token = "0x17002701")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x601299D")]
			[Address(RVA = "0x1CF940C", Offset = "0x1CF940C", VA = "0x1CF940C", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x0601299E RID: 76190 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601299E")]
		[Address(RVA = "0x1CF9414", Offset = "0x1CF9414", VA = "0x1CF9414")]
		public GetProfileHttpCommand(long userId, Action<UserProfileInfo> onCompleted, Action onFailed)
		{
		}

		// Token: 0x0601299F RID: 76191 RVA: 0x00077B20 File Offset: 0x00075D20
		[Token(Token = "0x601299F")]
		[Address(RVA = "0x1CF946C", Offset = "0x1CF946C", VA = "0x1CF946C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x060129A0 RID: 76192 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129A0")]
		[Address(RVA = "0x1CF948C", Offset = "0x1CF948C", VA = "0x1CF948C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x060129A1 RID: 76193 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60129A1")]
		[Address(RVA = "0x1CF9A5C", Offset = "0x1CF9A5C", VA = "0x1CF9A5C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EB1B RID: 60187
		[Token(Token = "0x400EB1B")]
		[FieldOffset(Offset = "0x18")]
		private readonly long userId;

		// Token: 0x0400EB1C RID: 60188
		[Token(Token = "0x400EB1C")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action<UserProfileInfo> onCompleted;

		// Token: 0x0400EB1D RID: 60189
		[Token(Token = "0x400EB1D")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action onFailed;
	}
}
