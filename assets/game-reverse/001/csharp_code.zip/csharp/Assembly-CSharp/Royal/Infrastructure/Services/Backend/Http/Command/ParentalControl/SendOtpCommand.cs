﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.ParentalControl
{
	// Token: 0x02002554 RID: 9556
	[Token(Token = "0x2002554")]
	public class SendOtpCommand : BaseHttpCommand
	{
		// Token: 0x17002769 RID: 10089
		// (get) Token: 0x06012AD3 RID: 76499 RVA: 0x00078930 File Offset: 0x00076B30
		[Token(Token = "0x17002769")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012AD3")]
			[Address(RVA = "0x1ECDD78", Offset = "0x1ECDD78", VA = "0x1ECDD78", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700276A RID: 10090
		// (get) Token: 0x06012AD4 RID: 76500 RVA: 0x00078948 File Offset: 0x00076B48
		[Token(Token = "0x1700276A")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012AD4")]
			[Address(RVA = "0x1ECDD80", Offset = "0x1ECDD80", VA = "0x1ECDD80", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012AD5 RID: 76501 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AD5")]
		[Address(RVA = "0x1ECDD88", Offset = "0x1ECDD88", VA = "0x1ECDD88")]
		public SendOtpCommand(string emailAddress, Action<SendOTPResponse> onSuccess, Action onFail)
		{
		}

		// Token: 0x06012AD6 RID: 76502 RVA: 0x00078960 File Offset: 0x00076B60
		[Token(Token = "0x6012AD6")]
		[Address(RVA = "0x1ECDDE8", Offset = "0x1ECDDE8", VA = "0x1ECDDE8", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012AD7 RID: 76503 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AD7")]
		[Address(RVA = "0x1ECDE20", Offset = "0x1ECDE20", VA = "0x1ECDE20", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012AD8 RID: 76504 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012AD8")]
		[Address(RVA = "0x1ECDEEC", Offset = "0x1ECDEEC", VA = "0x1ECDEEC", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBA5 RID: 60325
		[Token(Token = "0x400EBA5")]
		[FieldOffset(Offset = "0x18")]
		private readonly string emailAddress;

		// Token: 0x0400EBA6 RID: 60326
		[Token(Token = "0x400EBA6")]
		[FieldOffset(Offset = "0x20")]
		private readonly Action<SendOTPResponse> onSuccess;

		// Token: 0x0400EBA7 RID: 60327
		[Token(Token = "0x400EBA7")]
		[FieldOffset(Offset = "0x28")]
		private readonly Action onFail;
	}
}
