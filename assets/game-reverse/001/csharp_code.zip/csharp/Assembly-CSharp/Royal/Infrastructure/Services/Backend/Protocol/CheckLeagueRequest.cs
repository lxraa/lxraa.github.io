﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002357 RID: 9047
	[Token(Token = "0x2002357")]
	public struct CheckLeagueRequest : IFlatbufferObject
	{
		// Token: 0x17001F20 RID: 7968
		// (get) Token: 0x06010CD7 RID: 68823 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001F20")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010CD7")]
			[Address(RVA = "0x2147E28", Offset = "0x2147E28", VA = "0x2147E28", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010CD8 RID: 68824 RVA: 0x00060F48 File Offset: 0x0005F148
		[Token(Token = "0x6010CD8")]
		[Address(RVA = "0x2147E30", Offset = "0x2147E30", VA = "0x2147E30")]
		public static CheckLeagueRequest GetRootAsCheckLeagueRequest(ByteBuffer _bb)
		{
			return default(CheckLeagueRequest);
		}

		// Token: 0x06010CD9 RID: 68825 RVA: 0x00060F60 File Offset: 0x0005F160
		[Token(Token = "0x6010CD9")]
		[Address(RVA = "0x2147E3C", Offset = "0x2147E3C", VA = "0x2147E3C")]
		public static CheckLeagueRequest GetRootAsCheckLeagueRequest(ByteBuffer _bb, CheckLeagueRequest obj)
		{
			return default(CheckLeagueRequest);
		}

		// Token: 0x06010CDA RID: 68826 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CDA")]
		[Address(RVA = "0x2147EEC", Offset = "0x2147EEC", VA = "0x2147EEC", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010CDB RID: 68827 RVA: 0x00060F78 File Offset: 0x0005F178
		[Token(Token = "0x6010CDB")]
		[Address(RVA = "0x2147EB4", Offset = "0x2147EB4", VA = "0x2147EB4")]
		public CheckLeagueRequest __assign(int _i, ByteBuffer _bb)
		{
			return default(CheckLeagueRequest);
		}

		// Token: 0x06010CDC RID: 68828 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010CDC")]
		[Address(RVA = "0x2147EFC", Offset = "0x2147EFC", VA = "0x2147EFC")]
		public static void StartCheckLeagueRequest(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010CDD RID: 68829 RVA: 0x00060F90 File Offset: 0x0005F190
		[Token(Token = "0x6010CDD")]
		[Address(RVA = "0x2147F14", Offset = "0x2147F14", VA = "0x2147F14")]
		public static Offset<CheckLeagueRequest> EndCheckLeagueRequest(FlatBufferBuilder builder)
		{
			return default(Offset<CheckLeagueRequest>);
		}

		// Token: 0x0400E65D RID: 58973
		[Token(Token = "0x400E65D")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
