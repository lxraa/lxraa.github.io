﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.KingsCup
{
	// Token: 0x02002565 RID: 9573
	[Token(Token = "0x2002565")]
	public class GetKingsCupInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x17002795 RID: 10133
		// (get) Token: 0x06012B52 RID: 76626 RVA: 0x00078F48 File Offset: 0x00077148
		[Token(Token = "0x17002795")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B52")]
			[Address(RVA = "0x1ED15B8", Offset = "0x1ED15B8", VA = "0x1ED15B8", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x17002796 RID: 10134
		// (get) Token: 0x06012B53 RID: 76627 RVA: 0x00078F60 File Offset: 0x00077160
		[Token(Token = "0x17002796")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B53")]
			[Address(RVA = "0x1ED15C0", Offset = "0x1ED15C0", VA = "0x1ED15C0", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x17002797 RID: 10135
		// (get) Token: 0x06012B54 RID: 76628 RVA: 0x00078F78 File Offset: 0x00077178
		// (set) Token: 0x06012B55 RID: 76629 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002797")]
		public GetKingsCupInfoResponse Response
		{
			[Token(Token = "0x6012B54")]
			[Address(RVA = "0x1ED15C8", Offset = "0x1ED15C8", VA = "0x1ED15C8")]
			get
			{
				return default(GetKingsCupInfoResponse);
			}
			[Token(Token = "0x6012B55")]
			[Address(RVA = "0x1ED15D4", Offset = "0x1ED15D4", VA = "0x1ED15D4")]
			set
			{
			}
		}

		// Token: 0x06012B56 RID: 76630 RVA: 0x00078F90 File Offset: 0x00077190
		[Token(Token = "0x6012B56")]
		[Address(RVA = "0x1ED15E4", Offset = "0x1ED15E4", VA = "0x1ED15E4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B57 RID: 76631 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B57")]
		[Address(RVA = "0x1ED166C", Offset = "0x1ED166C", VA = "0x1ED166C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B58 RID: 76632 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B58")]
		[Address(RVA = "0x1ED17E4", Offset = "0x1ED17E4", VA = "0x1ED17E4", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x06012B59 RID: 76633 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B59")]
		[Address(RVA = "0x1ED17E8", Offset = "0x1ED17E8", VA = "0x1ED17E8")]
		public GetKingsCupInfoHttpCommand()
		{
		}

		// Token: 0x0400EBCC RID: 60364
		[Token(Token = "0x400EBCC")]
		[FieldOffset(Offset = "0x18")]
		private GetKingsCupInfoResponse <Response>k__BackingField;
	}
}
