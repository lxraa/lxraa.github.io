﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Il2CppDummyDll;
using Royal.Infrastructure.Contexts;
using Royal.Infrastructure.Services.Backend.Http.Command;
using Royal.Infrastructure.Services.Backend.Http.CommandHandler;
using UnityEngine.Networking;

namespace Royal.Infrastructure.Services.Backend.Http
{
	// Token: 0x02002503 RID: 9475
	[Token(Token = "0x2002503")]
	public class BackendHttpService : IContextBehaviour, IContextUnit
	{
		// Token: 0x14000096 RID: 150
		// (add) Token: 0x06012800 RID: 75776 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012801 RID: 75777 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x14000096")]
		public event Action OnBackendManualUpdate
		{
			[Token(Token = "0x6012800")]
			[Address(RVA = "0x1F8AC20", Offset = "0x1F8AC20", VA = "0x1F8AC20")]
			add
			{
			}
			[Token(Token = "0x6012801")]
			[Address(RVA = "0x1F8ACBC", Offset = "0x1F8ACBC", VA = "0x1F8ACBC")]
			remove
			{
			}
		}

		// Token: 0x170026B1 RID: 9905
		// (get) Token: 0x06012802 RID: 75778 RVA: 0x00077028 File Offset: 0x00075228
		// (set) Token: 0x06012803 RID: 75779 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026B1")]
		public int TotalSyncRequiredCommandsCount
		{
			[Token(Token = "0x6012802")]
			[Address(RVA = "0x1F8AD58", Offset = "0x1F8AD58", VA = "0x1F8AD58")]
			get
			{
				return 0;
			}
			[Token(Token = "0x6012803")]
			[Address(RVA = "0x1F8AD60", Offset = "0x1F8AD60", VA = "0x1F8AD60")]
			private set
			{
			}
		}

		// Token: 0x170026B2 RID: 9906
		// (get) Token: 0x06012804 RID: 75780 RVA: 0x00077040 File Offset: 0x00075240
		// (set) Token: 0x06012805 RID: 75781 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026B2")]
		public bool ShouldSendKeyValuesSeparately
		{
			[Token(Token = "0x6012804")]
			[Address(RVA = "0x1F8AD68", Offset = "0x1F8AD68", VA = "0x1F8AD68")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x6012805")]
			[Address(RVA = "0x1F8AD70", Offset = "0x1F8AD70", VA = "0x1F8AD70")]
			private set
			{
			}
		}

		// Token: 0x170026B3 RID: 9907
		// (get) Token: 0x06012806 RID: 75782 RVA: 0x00077058 File Offset: 0x00075258
		[Token(Token = "0x170026B3")]
		public int Id
		{
			[Token(Token = "0x6012806")]
			[Address(RVA = "0x1F8AD7C", Offset = "0x1F8AD7C", VA = "0x1F8AD7C", Slot = "5")]
			get
			{
				return 0;
			}
		}

		// Token: 0x170026B4 RID: 9908
		// (get) Token: 0x06012807 RID: 75783 RVA: 0x00077070 File Offset: 0x00075270
		[Token(Token = "0x170026B4")]
		public bool HasRunningSyncRequiredCommand
		{
			[Token(Token = "0x6012807")]
			[Address(RVA = "0x1F8AD84", Offset = "0x1F8AD84", VA = "0x1F8AD84")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x06012808 RID: 75784 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012808")]
		[Address(RVA = "0x1F8AD94", Offset = "0x1F8AD94", VA = "0x1F8AD94")]
		public BackendHttpService()
		{
		}

		// Token: 0x06012809 RID: 75785 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012809")]
		[Address(RVA = "0x1F8B530", Offset = "0x1F8B530", VA = "0x1F8B530")]
		public static void SwitchUriScheme()
		{
		}

		// Token: 0x0601280A RID: 75786 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601280A")]
		[Address(RVA = "0x1F8AF80", Offset = "0x1F8AF80", VA = "0x1F8AF80")]
		private static void PrepareBackendEndpoints(string uriScheme)
		{
		}

		// Token: 0x0601280B RID: 75787 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601280B")]
		[Address(RVA = "0x1F8B31C", Offset = "0x1F8B31C", VA = "0x1F8B31C")]
		private static Uri GetEndPoint(BackendEndpointTypes endpointType)
		{
			return null;
		}

		// Token: 0x0601280C RID: 75788 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601280C")]
		[Address(RVA = "0x1F8B624", Offset = "0x1F8B624", VA = "0x1F8B624", Slot = "6")]
		public void Bind()
		{
		}

		// Token: 0x0601280D RID: 75789 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601280D")]
		[Address(RVA = "0x1F8B6B0", Offset = "0x1F8B6B0", VA = "0x1F8B6B0")]
		private IEnumerator LateBind()
		{
			return null;
		}

		// Token: 0x0601280E RID: 75790 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601280E")]
		[Address(RVA = "0x1F8B74C", Offset = "0x1F8B74C", VA = "0x1F8B74C")]
		private void OnUserChanged()
		{
		}

		// Token: 0x0601280F RID: 75791 RVA: 0x00077088 File Offset: 0x00075288
		[Token(Token = "0x601280F")]
		[Address(RVA = "0x1F8B75C", Offset = "0x1F8B75C", VA = "0x1F8B75C")]
		public bool Send(BaseHttpCommand httpCommand, [Optional] HttpCommands.ConnectionComplete onComplete, bool syncRequired = false)
		{
			return default(bool);
		}

		// Token: 0x06012810 RID: 75792 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012810")]
		[Address(RVA = "0x1F8C43C", Offset = "0x1F8C43C", VA = "0x1F8C43C")]
		public void SendImmediately(HttpCommands commandsToSend, float timeOut = 12f)
		{
		}

		// Token: 0x06012811 RID: 75793 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012811")]
		[Address(RVA = "0x1F8C7D4", Offset = "0x1F8C7D4", VA = "0x1F8C7D4")]
		public void SendImmediately(BaseHttpCommand commandsToSend, float timeOut = 12f, bool syncRequired = false, [Optional] HttpCommands.ConnectionComplete onCommandsComplete)
		{
		}

		// Token: 0x06012812 RID: 75794 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012812")]
		[Address(RVA = "0x1F8C884", Offset = "0x1F8C884", VA = "0x1F8C884")]
		public void SendToPurchaseServer(HttpCommands commandsToSend)
		{
		}

		// Token: 0x06012813 RID: 75795 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012813")]
		[Address(RVA = "0x1F8C890", Offset = "0x1F8C890", VA = "0x1F8C890")]
		public HttpCommands SendToGameServer(BaseHttpCommand command)
		{
			return null;
		}

		// Token: 0x06012814 RID: 75796 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012814")]
		[Address(RVA = "0x1F8C920", Offset = "0x1F8C920", VA = "0x1F8C920")]
		public void SendToGameServer(HttpCommands commandsToSend)
		{
		}

		// Token: 0x06012815 RID: 75797 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012815")]
		[Address(RVA = "0x1F8C92C", Offset = "0x1F8C92C", VA = "0x1F8C92C")]
		public void SendToStatsServer(HttpCommands commandsToSend)
		{
		}

		// Token: 0x06012816 RID: 75798 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012816")]
		[Address(RVA = "0x1F8C63C", Offset = "0x1F8C63C", VA = "0x1F8C63C")]
		private void SendToEndpoint(HttpCommands commandsToSend, BackendEndpointTypes endPointType, float timeOut = 12f)
		{
		}

		// Token: 0x06012817 RID: 75799 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012817")]
		[Address(RVA = "0x1F8C938", Offset = "0x1F8C938", VA = "0x1F8C938")]
		private void RemoveHandler(HttpCommandsHandler handler)
		{
		}

		// Token: 0x06012818 RID: 75800 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012818")]
		[Address(RVA = "0x1F8C990", Offset = "0x1F8C990", VA = "0x1F8C990")]
		public void SeparateKeyValueRequests()
		{
		}

		// Token: 0x06012819 RID: 75801 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012819")]
		[Address(RVA = "0x1F8CB70", Offset = "0x1F8CB70", VA = "0x1F8CB70")]
		public void SendKeyValueRequest()
		{
		}

		// Token: 0x0601281A RID: 75802 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601281A")]
		[Address(RVA = "0x1F8CAFC", Offset = "0x1F8CAFC", VA = "0x1F8CAFC")]
		private IEnumerator JoinKeyValueRequests()
		{
			return null;
		}

		// Token: 0x0601281B RID: 75803 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601281B")]
		[Address(RVA = "0x1F8CBA4", Offset = "0x1F8CBA4", VA = "0x1F8CBA4", Slot = "4")]
		public void ManualUpdate()
		{
		}

		// Token: 0x0601281C RID: 75804 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601281C")]
		[Address(RVA = "0x1F8CCAC", Offset = "0x1F8CCAC", VA = "0x1F8CCAC")]
		private void CheckForUnityWebRequests()
		{
		}

		// Token: 0x0601281D RID: 75805 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601281D")]
		[Address(RVA = "0x1F8D0D4", Offset = "0x1F8D0D4", VA = "0x1F8D0D4")]
		private void SendKeyValueCommands()
		{
		}

		// Token: 0x0601281E RID: 75806 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601281E")]
		[Address(RVA = "0x1F8CD40", Offset = "0x1F8CD40", VA = "0x1F8CD40")]
		private void SendGameServerCommands()
		{
		}

		// Token: 0x0601281F RID: 75807 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601281F")]
		[Address(RVA = "0x1F8CC18", Offset = "0x1F8CC18", VA = "0x1F8CC18")]
		private void CheckForTimeout()
		{
		}

		// Token: 0x06012820 RID: 75808 RVA: 0x000770A0 File Offset: 0x000752A0
		[Token(Token = "0x6012820")]
		[Address(RVA = "0x1F8D610", Offset = "0x1F8D610", VA = "0x1F8D610")]
		public bool IsInMaintenance(bool checkAgain = true)
		{
			return default(bool);
		}

		// Token: 0x06012821 RID: 75809 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012821")]
		[Address(RVA = "0x1F8D630", Offset = "0x1F8D630", VA = "0x1F8D630")]
		private void CheckWithUnityWebRequest()
		{
		}

		// Token: 0x06012822 RID: 75810 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012822")]
		[Address(RVA = "0x1F8D6B4", Offset = "0x1F8D6B4", VA = "0x1F8D6B4")]
		private IEnumerator CheckWithUnityWebRequestCoroutine()
		{
			return null;
		}

		// Token: 0x06012823 RID: 75811 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012823")]
		[Address(RVA = "0x1F8C484", Offset = "0x1F8C484", VA = "0x1F8C484")]
		private void IncrementSyncRequiredCommandsCount(HttpCommands commandsToSend, bool syncRequired)
		{
		}

		// Token: 0x06012825 RID: 75813 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012825")]
		[Address(RVA = "0x1F8D86C", Offset = "0x1F8D86C", VA = "0x1F8D86C")]
		private void <SendKeyValueCommands>b__63_0(bool success, HttpCommands container)
		{
		}

		// Token: 0x06012826 RID: 75814 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012826")]
		[Address(RVA = "0x1F8D914", Offset = "0x1F8D914", VA = "0x1F8D914")]
		private void <IncrementSyncRequiredCommandsCount>b__69_0(bool success, HttpCommands container)
		{
		}

		// Token: 0x0400EA3C RID: 59964
		[Token(Token = "0x400EA3C")]
		private const float CommandSendPeriod = 1f;

		// Token: 0x0400EA3D RID: 59965
		[Token(Token = "0x400EA3D")]
		private const float KeyValueCommandMaxSendPeriod = 5f;

		// Token: 0x0400EA3E RID: 59966
		[Token(Token = "0x400EA3E")]
		private const string maintenanceUrl = "https://us-central1-royal-match-prod-cce6d.cloudfunctions.net/backendMaintenanceMode";

		// Token: 0x0400EA3F RID: 59967
		[Token(Token = "0x400EA3F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		public static string BackendUrl;

		// Token: 0x0400EA40 RID: 59968
		[Token(Token = "0x400EA40")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
		public static string BackendPurchaseUrl;

		// Token: 0x0400EA41 RID: 59969
		[Token(Token = "0x400EA41")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		public static string BackendEventsUrl;

		// Token: 0x0400EA42 RID: 59970
		[Token(Token = "0x400EA42")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		public static string BackendStatsUrl;

		// Token: 0x0400EA43 RID: 59971
		[Token(Token = "0x400EA43")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		public static string BackendNotificationTagUrl;

		// Token: 0x0400EA44 RID: 59972
		[Token(Token = "0x400EA44")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		public static Uri backendUri;

		// Token: 0x0400EA45 RID: 59973
		[Token(Token = "0x400EA45")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
		public static Uri backendPurchaseUri;

		// Token: 0x0400EA46 RID: 59974
		[Token(Token = "0x400EA46")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x38")]
		public static Uri backendEventsUri;

		// Token: 0x0400EA47 RID: 59975
		[Token(Token = "0x400EA47")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x40")]
		public static Uri backendStatsUri;

		// Token: 0x0400EA49 RID: 59977
		[Token(Token = "0x400EA49")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		private readonly LinkedList<HttpCommandsHandler> requestList;

		// Token: 0x0400EA4A RID: 59978
		[Token(Token = "0x400EA4A")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		private TimeHelper timeHelper;

		// Token: 0x0400EA4B RID: 59979
		[Token(Token = "0x400EA4B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		private float lastTimeoutChecked;

		// Token: 0x0400EA4C RID: 59980
		[Token(Token = "0x400EA4C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x2C")]
		private float lastCommandSendTime;

		// Token: 0x0400EA4D RID: 59981
		[Token(Token = "0x400EA4D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
		private HttpCommands syncRequiredWaitingCommands;

		// Token: 0x0400EA4E RID: 59982
		[Token(Token = "0x400EA4E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x38")]
		private readonly Dictionary<BackendEndpointTypes, HttpCommands> commandsDictionary;

		// Token: 0x0400EA4F RID: 59983
		[Token(Token = "0x400EA4F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x40")]
		private bool isInMaintenance;

		// Token: 0x0400EA50 RID: 59984
		[Token(Token = "0x400EA50")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x41")]
		private bool isSendingMaintenanceUnityWebRequest;

		// Token: 0x0400EA51 RID: 59985
		[Token(Token = "0x400EA51")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x44")]
		private int currentSyncRequiredCommandsCount;

		// Token: 0x0400EA52 RID: 59986
		[Token(Token = "0x400EA52")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x48")]
		private float lastSyncRequiredAddedTime;

		// Token: 0x0400EA53 RID: 59987
		[Token(Token = "0x400EA53")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x48")]
		private static Dictionary<BackendEndpointTypes, Uri> EndPoints;

		// Token: 0x0400EA54 RID: 59988
		[Token(Token = "0x400EA54")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x4C")]
		private int <TotalSyncRequiredCommandsCount>k__BackingField;

		// Token: 0x0400EA55 RID: 59989
		[Token(Token = "0x400EA55")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x50")]
		private bool shouldSendKeyValueRequest;

		// Token: 0x0400EA56 RID: 59990
		[Token(Token = "0x400EA56")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x51")]
		private bool isSendingKeyValueRequest;

		// Token: 0x0400EA57 RID: 59991
		[Token(Token = "0x400EA57")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x54")]
		private float lastKeyValueRequestSendTime;

		// Token: 0x0400EA58 RID: 59992
		[Token(Token = "0x400EA58")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x58")]
		private float currentKeyValueCommandSendPeriod;

		// Token: 0x0400EA59 RID: 59993
		[Token(Token = "0x400EA59")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x5C")]
		private bool <ShouldSendKeyValuesSeparately>k__BackingField;

		// Token: 0x02002504 RID: 9476
		[Token(Token = "0x2002504")]
		private sealed class <LateBind>d__47 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012827 RID: 75815 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012827")]
			[Address(RVA = "0x1F8B724", Offset = "0x1F8B724", VA = "0x1F8B724")]
			[DebuggerHidden]
			public <LateBind>d__47(int <>1__state)
			{
			}

			// Token: 0x06012828 RID: 75816 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012828")]
			[Address(RVA = "0x1F8DA4C", Offset = "0x1F8DA4C", VA = "0x1F8DA4C", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012829 RID: 75817 RVA: 0x000770B8 File Offset: 0x000752B8
			[Token(Token = "0x6012829")]
			[Address(RVA = "0x1F8DA50", Offset = "0x1F8DA50", VA = "0x1F8DA50", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x170026B5 RID: 9909
			// (get) Token: 0x0601282A RID: 75818 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170026B5")]
			private object Current
			{
				[Token(Token = "0x601282A")]
				[Address(RVA = "0x1F8DB98", Offset = "0x1F8DB98", VA = "0x1F8DB98", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0601282B RID: 75819 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601282B")]
			[Address(RVA = "0x1F8DBA0", Offset = "0x1F8DBA0", VA = "0x1F8DBA0", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x170026B6 RID: 9910
			// (get) Token: 0x0601282C RID: 75820 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170026B6")]
			private object Current
			{
				[Token(Token = "0x601282C")]
				[Address(RVA = "0x1F8DBE0", Offset = "0x1F8DBE0", VA = "0x1F8DBE0", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EA5A RID: 59994
			[Token(Token = "0x400EA5A")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EA5B RID: 59995
			[Token(Token = "0x400EA5B")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EA5C RID: 59996
			[Token(Token = "0x400EA5C")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
			public BackendHttpService <>4__this;
		}

		// Token: 0x02002505 RID: 9477
		[Token(Token = "0x2002505")]
		private sealed class <JoinKeyValueRequests>d__60 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x0601282D RID: 75821 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601282D")]
			[Address(RVA = "0x1F8CB7C", Offset = "0x1F8CB7C", VA = "0x1F8CB7C")]
			[DebuggerHidden]
			public <JoinKeyValueRequests>d__60(int <>1__state)
			{
			}

			// Token: 0x0601282E RID: 75822 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601282E")]
			[Address(RVA = "0x1F8DBE8", Offset = "0x1F8DBE8", VA = "0x1F8DBE8", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x0601282F RID: 75823 RVA: 0x000770D0 File Offset: 0x000752D0
			[Token(Token = "0x601282F")]
			[Address(RVA = "0x1F8DBEC", Offset = "0x1F8DBEC", VA = "0x1F8DBEC", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x170026B7 RID: 9911
			// (get) Token: 0x06012830 RID: 75824 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170026B7")]
			private object Current
			{
				[Token(Token = "0x6012830")]
				[Address(RVA = "0x1F8DD1C", Offset = "0x1F8DD1C", VA = "0x1F8DD1C", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012831 RID: 75825 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012831")]
			[Address(RVA = "0x1F8DD24", Offset = "0x1F8DD24", VA = "0x1F8DD24", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x170026B8 RID: 9912
			// (get) Token: 0x06012832 RID: 75826 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170026B8")]
			private object Current
			{
				[Token(Token = "0x6012832")]
				[Address(RVA = "0x1F8DD64", Offset = "0x1F8DD64", VA = "0x1F8DD64", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EA5D RID: 59997
			[Token(Token = "0x400EA5D")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EA5E RID: 59998
			[Token(Token = "0x400EA5E")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EA5F RID: 59999
			[Token(Token = "0x400EA5F")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
			public BackendHttpService <>4__this;
		}

		// Token: 0x02002506 RID: 9478
		[Token(Token = "0x2002506")]
		private sealed class <CheckWithUnityWebRequestCoroutine>d__68 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012833 RID: 75827 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012833")]
			[Address(RVA = "0x1F8D728", Offset = "0x1F8D728", VA = "0x1F8D728")]
			[DebuggerHidden]
			public <CheckWithUnityWebRequestCoroutine>d__68(int <>1__state)
			{
			}

			// Token: 0x06012834 RID: 75828 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012834")]
			[Address(RVA = "0x1F8DD6C", Offset = "0x1F8DD6C", VA = "0x1F8DD6C", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012835 RID: 75829 RVA: 0x000770E8 File Offset: 0x000752E8
			[Token(Token = "0x6012835")]
			[Address(RVA = "0x1F8DD88", Offset = "0x1F8DD88", VA = "0x1F8DD88", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x06012836 RID: 75830 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012836")]
			[Address(RVA = "0x1F8E2E4", Offset = "0x1F8E2E4", VA = "0x1F8E2E4")]
			private void <>m__Finally1()
			{
			}

			// Token: 0x170026B9 RID: 9913
			// (get) Token: 0x06012837 RID: 75831 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170026B9")]
			private object Current
			{
				[Token(Token = "0x6012837")]
				[Address(RVA = "0x1F8E394", Offset = "0x1F8E394", VA = "0x1F8E394", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012838 RID: 75832 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012838")]
			[Address(RVA = "0x1F8E39C", Offset = "0x1F8E39C", VA = "0x1F8E39C", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x170026BA RID: 9914
			// (get) Token: 0x06012839 RID: 75833 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x170026BA")]
			private object Current
			{
				[Token(Token = "0x6012839")]
				[Address(RVA = "0x1F8E3DC", Offset = "0x1F8E3DC", VA = "0x1F8E3DC", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EA60 RID: 60000
			[Token(Token = "0x400EA60")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EA61 RID: 60001
			[Token(Token = "0x400EA61")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EA62 RID: 60002
			[Token(Token = "0x400EA62")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
			public BackendHttpService <>4__this;

			// Token: 0x0400EA63 RID: 60003
			[Token(Token = "0x400EA63")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
			private UnityWebRequest <unityWebRequest>5__2;
		}
	}
}
