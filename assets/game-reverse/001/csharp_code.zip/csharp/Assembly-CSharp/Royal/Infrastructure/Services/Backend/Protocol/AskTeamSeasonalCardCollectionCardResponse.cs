﻿using System;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x02002344 RID: 9028
	[Token(Token = "0x2002344")]
	public struct AskTeamSeasonalCardCollectionCardResponse : IFlatbufferObject
	{
		// Token: 0x17001EDB RID: 7899
		// (get) Token: 0x06010BC9 RID: 68553 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17001EDB")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x6010BC9")]
			[Address(RVA = "0x21440C4", Offset = "0x21440C4", VA = "0x21440C4", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x06010BCA RID: 68554 RVA: 0x00060240 File Offset: 0x0005E440
		[Token(Token = "0x6010BCA")]
		[Address(RVA = "0x21440CC", Offset = "0x21440CC", VA = "0x21440CC")]
		public static AskTeamSeasonalCardCollectionCardResponse GetRootAsAskTeamSeasonalCardCollectionCardResponse(ByteBuffer _bb)
		{
			return default(AskTeamSeasonalCardCollectionCardResponse);
		}

		// Token: 0x06010BCB RID: 68555 RVA: 0x00060258 File Offset: 0x0005E458
		[Token(Token = "0x6010BCB")]
		[Address(RVA = "0x21440D8", Offset = "0x21440D8", VA = "0x21440D8")]
		public static AskTeamSeasonalCardCollectionCardResponse GetRootAsAskTeamSeasonalCardCollectionCardResponse(ByteBuffer _bb, AskTeamSeasonalCardCollectionCardResponse obj)
		{
			return default(AskTeamSeasonalCardCollectionCardResponse);
		}

		// Token: 0x06010BCC RID: 68556 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BCC")]
		[Address(RVA = "0x2144188", Offset = "0x2144188", VA = "0x2144188", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x06010BCD RID: 68557 RVA: 0x00060270 File Offset: 0x0005E470
		[Token(Token = "0x6010BCD")]
		[Address(RVA = "0x2144150", Offset = "0x2144150", VA = "0x2144150")]
		public AskTeamSeasonalCardCollectionCardResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(AskTeamSeasonalCardCollectionCardResponse);
		}

		// Token: 0x17001EDC RID: 7900
		// (get) Token: 0x06010BCE RID: 68558 RVA: 0x00060288 File Offset: 0x0005E488
		[Token(Token = "0x17001EDC")]
		public SeasonalCardCollectionCardOperationStatus OperationStatus
		{
			[Token(Token = "0x6010BCE")]
			[Address(RVA = "0x2144198", Offset = "0x2144198", VA = "0x2144198")]
			get
			{
				return SeasonalCardCollectionCardOperationStatus.Ok;
			}
		}

		// Token: 0x06010BCF RID: 68559 RVA: 0x000602A0 File Offset: 0x0005E4A0
		[Token(Token = "0x6010BCF")]
		[Address(RVA = "0x21441DC", Offset = "0x21441DC", VA = "0x21441DC")]
		public static Offset<AskTeamSeasonalCardCollectionCardResponse> CreateAskTeamSeasonalCardCollectionCardResponse(FlatBufferBuilder builder, SeasonalCardCollectionCardOperationStatus operation_status = SeasonalCardCollectionCardOperationStatus.Ok)
		{
			return default(Offset<AskTeamSeasonalCardCollectionCardResponse>);
		}

		// Token: 0x06010BD0 RID: 68560 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BD0")]
		[Address(RVA = "0x21442B0", Offset = "0x21442B0", VA = "0x21442B0")]
		public static void StartAskTeamSeasonalCardCollectionCardResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x06010BD1 RID: 68561 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6010BD1")]
		[Address(RVA = "0x2144224", Offset = "0x2144224", VA = "0x2144224")]
		public static void AddOperationStatus(FlatBufferBuilder builder, SeasonalCardCollectionCardOperationStatus operationStatus)
		{
		}

		// Token: 0x06010BD2 RID: 68562 RVA: 0x000602B8 File Offset: 0x0005E4B8
		[Token(Token = "0x6010BD2")]
		[Address(RVA = "0x2144244", Offset = "0x2144244", VA = "0x2144244")]
		public static Offset<AskTeamSeasonalCardCollectionCardResponse> EndAskTeamSeasonalCardCollectionCardResponse(FlatBufferBuilder builder)
		{
			return default(Offset<AskTeamSeasonalCardCollectionCardResponse>);
		}

		// Token: 0x0400E628 RID: 58920
		[Token(Token = "0x400E628")]
		[FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
