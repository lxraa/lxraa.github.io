﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command
{
	// Token: 0x0200251E RID: 9502
	[Token(Token = "0x200251E")]
	public class SocialConnectHttpCommand : BaseHttpCommand
	{
		// Token: 0x170026E9 RID: 9961
		// (get) Token: 0x06012936 RID: 76086 RVA: 0x000777A8 File Offset: 0x000759A8
		[Token(Token = "0x170026E9")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012936")]
			[Address(RVA = "0x1CF21BC", Offset = "0x1CF21BC", VA = "0x1CF21BC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x170026EA RID: 9962
		// (get) Token: 0x06012937 RID: 76087 RVA: 0x000777C0 File Offset: 0x000759C0
		[Token(Token = "0x170026EA")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012937")]
			[Address(RVA = "0x1CF21C4", Offset = "0x1CF21C4", VA = "0x1CF21C4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x170026EB RID: 9963
		// (get) Token: 0x06012938 RID: 76088 RVA: 0x000777D8 File Offset: 0x000759D8
		// (set) Token: 0x06012939 RID: 76089 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x170026EB")]
		public SocialConnectResponse Response
		{
			[Token(Token = "0x6012938")]
			[Address(RVA = "0x1CF21CC", Offset = "0x1CF21CC", VA = "0x1CF21CC")]
			get
			{
				return default(SocialConnectResponse);
			}
			[Token(Token = "0x6012939")]
			[Address(RVA = "0x1CF21D8", Offset = "0x1CF21D8", VA = "0x1CF21D8")]
			private set
			{
			}
		}

		// Token: 0x0601293A RID: 76090 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601293A")]
		[Address(RVA = "0x1CF21E8", Offset = "0x1CF21E8", VA = "0x1CF21E8")]
		public SocialConnectHttpCommand(byte platform, string userId, string name, string authCode, string accessOrIdToken)
		{
		}

		// Token: 0x0601293B RID: 76091 RVA: 0x000777F0 File Offset: 0x000759F0
		[Token(Token = "0x601293B")]
		[Address(RVA = "0x1CF23A4", Offset = "0x1CF23A4", VA = "0x1CF23A4", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x0601293C RID: 76092 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601293C")]
		[Address(RVA = "0x1CF267C", Offset = "0x1CF267C", VA = "0x1CF267C", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x0601293D RID: 76093 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601293D")]
		[Address(RVA = "0x1CF2930", Offset = "0x1CF2930", VA = "0x1CF2930", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EAFA RID: 60154
		[Token(Token = "0x400EAFA")]
		[FieldOffset(Offset = "0x18")]
		private SocialConnectResponse <Response>k__BackingField;

		// Token: 0x0400EAFB RID: 60155
		[Token(Token = "0x400EAFB")]
		[FieldOffset(Offset = "0x28")]
		private readonly string name;

		// Token: 0x0400EAFC RID: 60156
		[Token(Token = "0x400EAFC")]
		[FieldOffset(Offset = "0x30")]
		private readonly string appleId;

		// Token: 0x0400EAFD RID: 60157
		[Token(Token = "0x400EAFD")]
		[FieldOffset(Offset = "0x38")]
		private readonly string appleAuthCode;

		// Token: 0x0400EAFE RID: 60158
		[Token(Token = "0x400EAFE")]
		[FieldOffset(Offset = "0x40")]
		private readonly long facebookId;

		// Token: 0x0400EAFF RID: 60159
		[Token(Token = "0x400EAFF")]
		[FieldOffset(Offset = "0x48")]
		private readonly string googleId;

		// Token: 0x0400EB00 RID: 60160
		[Token(Token = "0x400EB00")]
		[FieldOffset(Offset = "0x50")]
		private readonly string pgsId;

		// Token: 0x0400EB01 RID: 60161
		[Token(Token = "0x400EB01")]
		[FieldOffset(Offset = "0x58")]
		private readonly string accessOrIdToken;
	}
}
