﻿using System;
using System.Runtime.InteropServices;
using FlatBuffers;
using Il2CppDummyDll;

namespace Royal.Infrastructure.Services.Backend.Protocol
{
	// Token: 0x020023C4 RID: 9156
	[Token(Token = "0x20023C4")]
	public struct GetArcheryArenaInfoResponse : IFlatbufferObject
	{
		// Token: 0x170020C5 RID: 8389
		// (get) Token: 0x060112DE RID: 70366 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x170020C5")]
		public ByteBuffer ByteBuffer
		{
			[Token(Token = "0x60112DE")]
			[Address(RVA = "0x1CAC310", Offset = "0x1CAC310", VA = "0x1CAC310", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112DF RID: 70367 RVA: 0x00065E50 File Offset: 0x00064050
		[Token(Token = "0x60112DF")]
		[Address(RVA = "0x1CAC318", Offset = "0x1CAC318", VA = "0x1CAC318")]
		public static GetArcheryArenaInfoResponse GetRootAsGetArcheryArenaInfoResponse(ByteBuffer _bb)
		{
			return default(GetArcheryArenaInfoResponse);
		}

		// Token: 0x060112E0 RID: 70368 RVA: 0x00065E68 File Offset: 0x00064068
		[Token(Token = "0x60112E0")]
		[Address(RVA = "0x1CAC324", Offset = "0x1CAC324", VA = "0x1CAC324")]
		public static GetArcheryArenaInfoResponse GetRootAsGetArcheryArenaInfoResponse(ByteBuffer _bb, GetArcheryArenaInfoResponse obj)
		{
			return default(GetArcheryArenaInfoResponse);
		}

		// Token: 0x060112E1 RID: 70369 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112E1")]
		[Address(RVA = "0x1CAC3D4", Offset = "0x1CAC3D4", VA = "0x1CAC3D4", Slot = "4")]
		public void __init(int _i, ByteBuffer _bb)
		{
		}

		// Token: 0x060112E2 RID: 70370 RVA: 0x00065E80 File Offset: 0x00064080
		[Token(Token = "0x60112E2")]
		[Address(RVA = "0x1CAC39C", Offset = "0x1CAC39C", VA = "0x1CAC39C")]
		public GetArcheryArenaInfoResponse __assign(int _i, ByteBuffer _bb)
		{
			return default(GetArcheryArenaInfoResponse);
		}

		// Token: 0x170020C6 RID: 8390
		// (get) Token: 0x060112E3 RID: 70371 RVA: 0x00065E98 File Offset: 0x00064098
		[Token(Token = "0x170020C6")]
		public ResponseStatusCode Status
		{
			[Token(Token = "0x60112E3")]
			[Address(RVA = "0x1CAC3E4", Offset = "0x1CAC3E4", VA = "0x1CAC3E4")]
			get
			{
				return ResponseStatusCode.Success;
			}
		}

		// Token: 0x170020C7 RID: 8391
		// (get) Token: 0x060112E4 RID: 70372 RVA: 0x00065EB0 File Offset: 0x000640B0
		[Token(Token = "0x170020C7")]
		public ArcheryArenaFailReason FailReason
		{
			[Token(Token = "0x60112E4")]
			[Address(RVA = "0x1CAC428", Offset = "0x1CAC428", VA = "0x1CAC428")]
			get
			{
				return ArcheryArenaFailReason.None;
			}
		}

		// Token: 0x170020C8 RID: 8392
		// (get) Token: 0x060112E5 RID: 70373 RVA: 0x00065EC8 File Offset: 0x000640C8
		[Token(Token = "0x170020C8")]
		public ArcheryArenaGroupInfo? ArcheryArenaGroupInfo
		{
			[Token(Token = "0x60112E5")]
			[Address(RVA = "0x1CAC46C", Offset = "0x1CAC46C", VA = "0x1CAC46C")]
			get
			{
				return null;
			}
		}

		// Token: 0x170020C9 RID: 8393
		// (get) Token: 0x060112E6 RID: 70374 RVA: 0x00065EE0 File Offset: 0x000640E0
		[Token(Token = "0x170020C9")]
		public ArcheryArenaInfo? ArcheryArenaInfo
		{
			[Token(Token = "0x60112E6")]
			[Address(RVA = "0x1CAC52C", Offset = "0x1CAC52C", VA = "0x1CAC52C")]
			get
			{
				return null;
			}
		}

		// Token: 0x060112E7 RID: 70375 RVA: 0x00065EF8 File Offset: 0x000640F8
		[Token(Token = "0x60112E7")]
		[Address(RVA = "0x1CAC5EC", Offset = "0x1CAC5EC", VA = "0x1CAC5EC")]
		public static Offset<GetArcheryArenaInfoResponse> CreateGetArcheryArenaInfoResponse(FlatBufferBuilder builder, ResponseStatusCode status = ResponseStatusCode.Success, ArcheryArenaFailReason fail_reason = ArcheryArenaFailReason.None, [Optional] Offset<ArcheryArenaGroupInfo> archery_arena_group_infoOffset, [Optional] Offset<ArcheryArenaInfo> archery_arena_infoOffset)
		{
			return default(Offset<GetArcheryArenaInfoResponse>);
		}

		// Token: 0x060112E8 RID: 70376 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112E8")]
		[Address(RVA = "0x1CAC758", Offset = "0x1CAC758", VA = "0x1CAC758")]
		public static void StartGetArcheryArenaInfoResponse(FlatBufferBuilder builder)
		{
		}

		// Token: 0x060112E9 RID: 70377 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112E9")]
		[Address(RVA = "0x1CAC6CC", Offset = "0x1CAC6CC", VA = "0x1CAC6CC")]
		public static void AddStatus(FlatBufferBuilder builder, ResponseStatusCode status)
		{
		}

		// Token: 0x060112EA RID: 70378 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112EA")]
		[Address(RVA = "0x1CAC6AC", Offset = "0x1CAC6AC", VA = "0x1CAC6AC")]
		public static void AddFailReason(FlatBufferBuilder builder, ArcheryArenaFailReason failReason)
		{
		}

		// Token: 0x060112EB RID: 70379 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112EB")]
		[Address(RVA = "0x1CAC68C", Offset = "0x1CAC68C", VA = "0x1CAC68C")]
		public static void AddArcheryArenaGroupInfo(FlatBufferBuilder builder, Offset<ArcheryArenaGroupInfo> archeryArenaGroupInfoOffset)
		{
		}

		// Token: 0x060112EC RID: 70380 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60112EC")]
		[Address(RVA = "0x1CAC66C", Offset = "0x1CAC66C", VA = "0x1CAC66C")]
		public static void AddArcheryArenaInfo(FlatBufferBuilder builder, Offset<ArcheryArenaInfo> archeryArenaInfoOffset)
		{
		}

		// Token: 0x060112ED RID: 70381 RVA: 0x00065F10 File Offset: 0x00064110
		[Token(Token = "0x60112ED")]
		[Address(RVA = "0x1CAC6EC", Offset = "0x1CAC6EC", VA = "0x1CAC6EC")]
		public static Offset<GetArcheryArenaInfoResponse> EndGetArcheryArenaInfoResponse(FlatBufferBuilder builder)
		{
			return default(Offset<GetArcheryArenaInfoResponse>);
		}

		// Token: 0x0400E731 RID: 59185
		[Token(Token = "0x400E731")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private Table __p;
	}
}
