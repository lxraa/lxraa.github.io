﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.LightningRush
{
	// Token: 0x0200255C RID: 9564
	[Token(Token = "0x200255C")]
	public class GetLightningRushInfoHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700277B RID: 10107
		// (get) Token: 0x06012B0B RID: 76555 RVA: 0x00078C00 File Offset: 0x00076E00
		[Token(Token = "0x1700277B")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B0B")]
			[Address(RVA = "0x1ECF318", Offset = "0x1ECF318", VA = "0x1ECF318", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700277C RID: 10108
		// (get) Token: 0x06012B0C RID: 76556 RVA: 0x00078C18 File Offset: 0x00076E18
		[Token(Token = "0x1700277C")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B0C")]
			[Address(RVA = "0x1ECF320", Offset = "0x1ECF320", VA = "0x1ECF320", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B0D RID: 76557 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B0D")]
		[Address(RVA = "0x1ECF328", Offset = "0x1ECF328", VA = "0x1ECF328")]
		public GetLightningRushInfoHttpCommand(long group)
		{
		}

		// Token: 0x1700277D RID: 10109
		// (get) Token: 0x06012B0E RID: 76558 RVA: 0x00078C30 File Offset: 0x00076E30
		// (set) Token: 0x06012B0F RID: 76559 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700277D")]
		public GetLightningRushInfoResponse Response
		{
			[Token(Token = "0x6012B0E")]
			[Address(RVA = "0x1ECF350", Offset = "0x1ECF350", VA = "0x1ECF350")]
			get
			{
				return default(GetLightningRushInfoResponse);
			}
			[Token(Token = "0x6012B0F")]
			[Address(RVA = "0x1ECF35C", Offset = "0x1ECF35C", VA = "0x1ECF35C")]
			set
			{
			}
		}

		// Token: 0x06012B10 RID: 76560 RVA: 0x00078C48 File Offset: 0x00076E48
		[Token(Token = "0x6012B10")]
		[Address(RVA = "0x1ECF36C", Offset = "0x1ECF36C", VA = "0x1ECF36C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B11 RID: 76561 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B11")]
		[Address(RVA = "0x1ECF484", Offset = "0x1ECF484", VA = "0x1ECF484", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B12 RID: 76562 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B12")]
		[Address(RVA = "0x1ECF73C", Offset = "0x1ECF73C", VA = "0x1ECF73C", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBB6 RID: 60342
		[Token(Token = "0x400EBB6")]
		[FieldOffset(Offset = "0x18")]
		private long groupId;

		// Token: 0x0400EBB7 RID: 60343
		[Token(Token = "0x400EBB7")]
		[FieldOffset(Offset = "0x20")]
		private GetLightningRushInfoResponse <Response>k__BackingField;
	}
}
