﻿using System;
using FlatBuffers;
using Il2CppDummyDll;
using Royal.Infrastructure.Services.Backend.Protocol;

namespace Royal.Infrastructure.Services.Backend.Http.Command.LavaQuest
{
	// Token: 0x02002562 RID: 9570
	[Token(Token = "0x2002562")]
	public class GetLavaQuestFacebookIdsHttpCommand : BaseHttpCommand
	{
		// Token: 0x1700278D RID: 10125
		// (get) Token: 0x06012B3C RID: 76604 RVA: 0x00078E40 File Offset: 0x00077040
		[Token(Token = "0x1700278D")]
		public override RequestType RequestType
		{
			[Token(Token = "0x6012B3C")]
			[Address(RVA = "0x1ED09EC", Offset = "0x1ED09EC", VA = "0x1ED09EC", Slot = "4")]
			get
			{
				return RequestType.NONE;
			}
		}

		// Token: 0x1700278E RID: 10126
		// (get) Token: 0x06012B3D RID: 76605 RVA: 0x00078E58 File Offset: 0x00077058
		[Token(Token = "0x1700278E")]
		public override ResponseType ResponseType
		{
			[Token(Token = "0x6012B3D")]
			[Address(RVA = "0x1ED09F4", Offset = "0x1ED09F4", VA = "0x1ED09F4", Slot = "5")]
			get
			{
				return ResponseType.NONE;
			}
		}

		// Token: 0x06012B3E RID: 76606 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B3E")]
		[Address(RVA = "0x1ED09FC", Offset = "0x1ED09FC", VA = "0x1ED09FC")]
		public GetLavaQuestFacebookIdsHttpCommand(int imagesVersion, bool increase, bool willBeUsedForCache)
		{
		}

		// Token: 0x06012B3F RID: 76607 RVA: 0x00078E70 File Offset: 0x00077070
		[Token(Token = "0x6012B3F")]
		[Address(RVA = "0x1ED0A3C", Offset = "0x1ED0A3C", VA = "0x1ED0A3C", Slot = "6")]
		public override int Build(FlatBufferBuilder builder)
		{
			return 0;
		}

		// Token: 0x06012B40 RID: 76608 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B40")]
		[Address(RVA = "0x1ED0BAC", Offset = "0x1ED0BAC", VA = "0x1ED0BAC", Slot = "7")]
		public override void Finish(int packageId, ResponsePackage package, int index)
		{
		}

		// Token: 0x06012B41 RID: 76609 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012B41")]
		[Address(RVA = "0x1ED0D20", Offset = "0x1ED0D20", VA = "0x1ED0D20", Slot = "8")]
		public override void PackageFail()
		{
		}

		// Token: 0x0400EBC1 RID: 60353
		[Token(Token = "0x400EBC1")]
		[FieldOffset(Offset = "0x14")]
		private readonly int version;

		// Token: 0x0400EBC2 RID: 60354
		[Token(Token = "0x400EBC2")]
		[FieldOffset(Offset = "0x18")]
		private readonly bool increaseVersion;

		// Token: 0x0400EBC3 RID: 60355
		[Token(Token = "0x400EBC3")]
		[FieldOffset(Offset = "0x19")]
		private readonly bool forCache;
	}
}
