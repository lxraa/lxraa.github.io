﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace Helpshift
{
	// Token: 0x02002626 RID: 9766
	[Token(Token = "0x2002626")]
	public class HelpshiftInternalLogger
	{
		// Token: 0x060130F1 RID: 78065 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130F1")]
		[Address(RVA = "0x24C75AC", Offset = "0x24C75AC", VA = "0x24C75AC")]
		public static void d(string message)
		{
		}

		// Token: 0x0400EFEF RID: 61423
		[Token(Token = "0x400EFEF")]
		[FieldOffset(Offset = "0x0")]
		private static string TAG;

		// Token: 0x0400EFF0 RID: 61424
		[Token(Token = "0x400EFF0")]
		[FieldOffset(Offset = "0x8")]
		private static AndroidJavaClass hsInternalLogger;
	}
}
