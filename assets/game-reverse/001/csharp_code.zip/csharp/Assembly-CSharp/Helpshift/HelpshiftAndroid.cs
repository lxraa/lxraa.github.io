﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace Helpshift
{
	// Token: 0x02002625 RID: 9765
	[Token(Token = "0x2002625")]
	public class HelpshiftAndroid
	{
		// Token: 0x060130E4 RID: 78052 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130E4")]
		[Address(RVA = "0x24C71A4", Offset = "0x24C71A4", VA = "0x24C71A4")]
		public HelpshiftAndroid()
		{
		}

		// Token: 0x060130E5 RID: 78053 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130E5")]
		[Address(RVA = "0x24C7370", Offset = "0x24C7370", VA = "0x24C7370")]
		public void install(string apiKey, string domain, string appId, Dictionary<string, object> configMap)
		{
		}

		// Token: 0x060130E6 RID: 78054 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130E6")]
		[Address(RVA = "0x24C76E4", Offset = "0x24C76E4", VA = "0x24C76E4")]
		public void requestUnreadMessagesCount(bool isAsync)
		{
		}

		// Token: 0x060130E7 RID: 78055 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130E7")]
		[Address(RVA = "0x24C7858", Offset = "0x24C7858", VA = "0x24C7858")]
		public void registerDeviceToken(string deviceToken)
		{
		}

		// Token: 0x060130E8 RID: 78056 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130E8")]
		[Address(RVA = "0x24C79B8", Offset = "0x24C79B8", VA = "0x24C79B8")]
		public void login(HelpshiftUser helpshiftUser)
		{
		}

		// Token: 0x060130E9 RID: 78057 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130E9")]
		[Address(RVA = "0x24C7C2C", Offset = "0x24C7C2C", VA = "0x24C7C2C")]
		private string serializeApiConfig(Dictionary<string, object> configMap)
		{
			return null;
		}

		// Token: 0x060130EA RID: 78058 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130EA")]
		[Address(RVA = "0x24C7D48", Offset = "0x24C7D48", VA = "0x24C7D48")]
		public void showConversation(Dictionary<string, object> configMap)
		{
		}

		// Token: 0x060130EB RID: 78059 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130EB")]
		[Address(RVA = "0x24C7E60", Offset = "0x24C7E60", VA = "0x24C7E60")]
		public void showSingleFAQ(string questionPublishId, Dictionary<string, object> configMap)
		{
		}

		// Token: 0x060130EC RID: 78060 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130EC")]
		[Address(RVA = "0x24C7FB8", Offset = "0x24C7FB8", VA = "0x24C7FB8")]
		public void showFAQs(Dictionary<string, object> configMap)
		{
		}

		// Token: 0x060130ED RID: 78061 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130ED")]
		[Address(RVA = "0x24C7C48", Offset = "0x24C7C48", VA = "0x24C7C48")]
		private Dictionary<string, object> cleanConfig(Dictionary<string, object> configMap)
		{
			return null;
		}

		// Token: 0x060130EE RID: 78062 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130EE")]
		[Address(RVA = "0x24C80D0", Offset = "0x24C80D0", VA = "0x24C80D0")]
		public void registerDelegates()
		{
		}

		// Token: 0x060130EF RID: 78063 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130EF")]
		[Address(RVA = "0x24C81BC", Offset = "0x24C81BC", VA = "0x24C81BC")]
		public void checkIfConversationActive()
		{
		}

		// Token: 0x060130F0 RID: 78064 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130F0")]
		[Address(RVA = "0x24C7AF0", Offset = "0x24C7AF0", VA = "0x24C7AF0")]
		private string jsonifyHelpshiftUser(HelpshiftUser helpshiftUser)
		{
			return null;
		}

		// Token: 0x0400EFEB RID: 61419
		[Token(Token = "0x400EFEB")]
		[FieldOffset(Offset = "0x10")]
		private AndroidJavaClass jc;

		// Token: 0x0400EFEC RID: 61420
		[Token(Token = "0x400EFEC")]
		[FieldOffset(Offset = "0x18")]
		private AndroidJavaObject currentActivity;

		// Token: 0x0400EFED RID: 61421
		[Token(Token = "0x400EFED")]
		[FieldOffset(Offset = "0x20")]
		private AndroidJavaObject application;

		// Token: 0x0400EFEE RID: 61422
		[Token(Token = "0x400EFEE")]
		[FieldOffset(Offset = "0x28")]
		private AndroidJavaClass hsHelpshiftClass;
	}
}
