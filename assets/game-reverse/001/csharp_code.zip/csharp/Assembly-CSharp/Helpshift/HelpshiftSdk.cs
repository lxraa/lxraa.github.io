﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Il2CppDummyDll;

namespace Helpshift
{
	// Token: 0x02002627 RID: 9767
	[Token(Token = "0x2002627")]
	public class HelpshiftSdk
	{
		// Token: 0x060130F3 RID: 78067 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130F3")]
		[Address(RVA = "0x24C8338", Offset = "0x24C8338", VA = "0x24C8338")]
		private HelpshiftSdk()
		{
		}

		// Token: 0x060130F4 RID: 78068 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130F4")]
		[Address(RVA = "0x24C8340", Offset = "0x24C8340", VA = "0x24C8340")]
		public static HelpshiftSdk getInstance()
		{
			return null;
		}

		// Token: 0x060130F5 RID: 78069 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130F5")]
		[Address(RVA = "0x24C840C", Offset = "0x24C840C", VA = "0x24C840C")]
		public void install(string apiKey, string domainName, string appId, [Optional] Dictionary<string, object> config)
		{
		}

		// Token: 0x060130F6 RID: 78070 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130F6")]
		[Address(RVA = "0x24C8594", Offset = "0x24C8594", VA = "0x24C8594")]
		public void requestUnreadMessagesCount(bool isAsync)
		{
		}

		// Token: 0x060130F7 RID: 78071 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130F7")]
		[Address(RVA = "0x24C85EC", Offset = "0x24C85EC", VA = "0x24C85EC")]
		public void login(HelpshiftUser helpshiftUser)
		{
		}

		// Token: 0x060130F8 RID: 78072 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130F8")]
		[Address(RVA = "0x24C8644", Offset = "0x24C8644", VA = "0x24C8644")]
		public void registerDeviceToken(string deviceToken)
		{
		}

		// Token: 0x060130F9 RID: 78073 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130F9")]
		[Address(RVA = "0x24C869C", Offset = "0x24C869C", VA = "0x24C869C")]
		public void showConversation([Optional] Dictionary<string, object> configMap)
		{
		}

		// Token: 0x060130FA RID: 78074 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130FA")]
		[Address(RVA = "0x24C86F4", Offset = "0x24C86F4", VA = "0x24C86F4")]
		public void showSingleFAQ(string questionPublishId, [Optional] Dictionary<string, object> configMap)
		{
		}

		// Token: 0x060130FB RID: 78075 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130FB")]
		[Address(RVA = "0x24C875C", Offset = "0x24C875C", VA = "0x24C875C")]
		public void showFAQs([Optional] Dictionary<string, object> configMap)
		{
		}

		// Token: 0x060130FC RID: 78076 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130FC")]
		[Address(RVA = "0x24C87B4", Offset = "0x24C87B4", VA = "0x24C87B4")]
		public void registerDelegates()
		{
		}

		// Token: 0x060130FD RID: 78077 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130FD")]
		[Address(RVA = "0x24C8804", Offset = "0x24C8804", VA = "0x24C8804")]
		public void checkIfConversationActive()
		{
		}

		// Token: 0x0400EFF1 RID: 61425
		[Token(Token = "0x400EFF1")]
		public const string HS_RATE_ALERT_CLOSE = "HS_RATE_ALERT_CLOSE";

		// Token: 0x0400EFF2 RID: 61426
		[Token(Token = "0x400EFF2")]
		public const string HS_RATE_ALERT_FEEDBACK = "HS_RATE_ALERT_FEEDBACK";

		// Token: 0x0400EFF3 RID: 61427
		[Token(Token = "0x400EFF3")]
		public const string HS_RATE_ALERT_SUCCESS = "HS_RATE_ALERT_SUCCESS";

		// Token: 0x0400EFF4 RID: 61428
		[Token(Token = "0x400EFF4")]
		public const string HS_RATE_ALERT_FAIL = "HS_RATE_ALERT_FAIL";

		// Token: 0x0400EFF5 RID: 61429
		[Token(Token = "0x400EFF5")]
		public const string HSTAGSKEY = "hs-tags";

		// Token: 0x0400EFF6 RID: 61430
		[Token(Token = "0x400EFF6")]
		public const string HSCUSTOMMETADATAKEY = "hs-custom-metadata";

		// Token: 0x0400EFF7 RID: 61431
		[Token(Token = "0x400EFF7")]
		public const string UNITY_GAME_OBJECT = "unityGameObject";

		// Token: 0x0400EFF8 RID: 61432
		[Token(Token = "0x400EFF8")]
		public const string ENABLE_IN_APP_NOTIFICATION = "enableInAppNotification";

		// Token: 0x0400EFF9 RID: 61433
		[Token(Token = "0x400EFF9")]
		public const string ENABLE_DEFAULT_FALLBACK_LANGUAGE = "enableDefaultFallbackLanguage";

		// Token: 0x0400EFFA RID: 61434
		[Token(Token = "0x400EFFA")]
		public const string ENABLE_LOGGING = "enableLogging";

		// Token: 0x0400EFFB RID: 61435
		[Token(Token = "0x400EFFB")]
		public const string ENABLE_INBOX_POLLING = "enableInboxPolling";

		// Token: 0x0400EFFC RID: 61436
		[Token(Token = "0x400EFFC")]
		public const string ENABLE_AUTOMATIC_THEME_SWITCHING = "enableAutomaticThemeSwitching";

		// Token: 0x0400EFFD RID: 61437
		[Token(Token = "0x400EFFD")]
		public const string DISABLE_ENTRY_EXIT_ANIMATIONS = "disableEntryExitAnimations";

		// Token: 0x0400EFFE RID: 61438
		[Token(Token = "0x400EFFE")]
		public const string DISABLE_ERROR_REPORTING = "disableErrorReporting";

		// Token: 0x0400EFFF RID: 61439
		[Token(Token = "0x400EFFF")]
		public const string HSCUSTOMISSUEFIELDKEY = "hs-custom-issue-field";

		// Token: 0x0400F000 RID: 61440
		[Token(Token = "0x400F000")]
		public const string HSTAGSMATCHINGKEY = "withTagsMatching";

		// Token: 0x0400F001 RID: 61441
		[Token(Token = "0x400F001")]
		public const string CONTACT_US_ALWAYS = "always";

		// Token: 0x0400F002 RID: 61442
		[Token(Token = "0x400F002")]
		public const string CONTACT_US_NEVER = "never";

		// Token: 0x0400F003 RID: 61443
		[Token(Token = "0x400F003")]
		public const string CONTACT_US_AFTER_VIEWING_FAQS = "after_viewing_faqs";

		// Token: 0x0400F004 RID: 61444
		[Token(Token = "0x400F004")]
		public const string CONTACT_US_AFTER_MARKING_ANSWER_UNHELPFUL = "after_marking_answer_unhelpful";

		// Token: 0x0400F005 RID: 61445
		[Token(Token = "0x400F005")]
		public const string HSUserAcceptedTheSolution = "User accepted the solution";

		// Token: 0x0400F006 RID: 61446
		[Token(Token = "0x400F006")]
		public const string HSUserRejectedTheSolution = "User rejected the solution";

		// Token: 0x0400F007 RID: 61447
		[Token(Token = "0x400F007")]
		public const string HSUserSentScreenShot = "User sent a screenshot";

		// Token: 0x0400F008 RID: 61448
		[Token(Token = "0x400F008")]
		public const string HSUserReviewedTheApp = "User reviewed the app";

		// Token: 0x0400F009 RID: 61449
		[Token(Token = "0x400F009")]
		public const string HsFlowTypeDefault = "defaultFlow";

		// Token: 0x0400F00A RID: 61450
		[Token(Token = "0x400F00A")]
		public const string HsFlowTypeConversation = "conversationFlow";

		// Token: 0x0400F00B RID: 61451
		[Token(Token = "0x400F00B")]
		public const string HsFlowTypeFaqs = "faqsFlow";

		// Token: 0x0400F00C RID: 61452
		[Token(Token = "0x400F00C")]
		public const string HsFlowTypeFaqSection = "faqSectionFlow";

		// Token: 0x0400F00D RID: 61453
		[Token(Token = "0x400F00D")]
		public const string HsFlowTypeSingleFaq = "singleFaqFlow";

		// Token: 0x0400F00E RID: 61454
		[Token(Token = "0x400F00E")]
		public const string HsFlowTypeNested = "dynamicFormFlow";

		// Token: 0x0400F00F RID: 61455
		[Token(Token = "0x400F00F")]
		public const string HsCustomContactUsFlows = "customContactUsFlows";

		// Token: 0x0400F010 RID: 61456
		[Token(Token = "0x400F010")]
		public const string HsFlowType = "type";

		// Token: 0x0400F011 RID: 61457
		[Token(Token = "0x400F011")]
		public const string HsFlowConfig = "config";

		// Token: 0x0400F012 RID: 61458
		[Token(Token = "0x400F012")]
		public const string HsFlowData = "data";

		// Token: 0x0400F013 RID: 61459
		[Token(Token = "0x400F013")]
		public const string HsFlowTitle = "title";

		// Token: 0x0400F014 RID: 61460
		[Token(Token = "0x400F014")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private static HelpshiftSdk instance;

		// Token: 0x0400F015 RID: 61461
		[Token(Token = "0x400F015")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
		private static HelpshiftAndroid nativeSdk;
	}
}
