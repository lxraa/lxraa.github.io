﻿using System;
using Il2CppDummyDll;

namespace Helpshift
{
	// Token: 0x02002628 RID: 9768
	[Token(Token = "0x2002628")]
	public class HelpshiftUser
	{
		// Token: 0x060130FE RID: 78078 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130FE")]
		[Address(RVA = "0x24C8854", Offset = "0x24C8854", VA = "0x24C8854")]
		private HelpshiftUser(string identifier, string email, string name, string authToken)
		{
		}

		// Token: 0x0400F016 RID: 61462
		[Token(Token = "0x400F016")]
		[FieldOffset(Offset = "0x10")]
		public readonly string identifier;

		// Token: 0x0400F017 RID: 61463
		[Token(Token = "0x400F017")]
		[FieldOffset(Offset = "0x18")]
		public readonly string email;

		// Token: 0x0400F018 RID: 61464
		[Token(Token = "0x400F018")]
		[FieldOffset(Offset = "0x20")]
		public readonly string name;

		// Token: 0x0400F019 RID: 61465
		[Token(Token = "0x400F019")]
		[FieldOffset(Offset = "0x28")]
		public readonly string authToken;

		// Token: 0x02002629 RID: 9769
		[Token(Token = "0x2002629")]
		public sealed class Builder
		{
			// Token: 0x060130FF RID: 78079 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130FF")]
			[Address(RVA = "0x24C88C8", Offset = "0x24C88C8", VA = "0x24C88C8")]
			public Builder(string identifier, string email)
			{
			}

			// Token: 0x06013100 RID: 78080 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6013100")]
			[Address(RVA = "0x24C890C", Offset = "0x24C890C", VA = "0x24C890C")]
			public HelpshiftUser.Builder setName(string name)
			{
				return null;
			}

			// Token: 0x06013101 RID: 78081 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6013101")]
			[Address(RVA = "0x24C8928", Offset = "0x24C8928", VA = "0x24C8928")]
			public HelpshiftUser build()
			{
				return null;
			}

			// Token: 0x0400F01A RID: 61466
			[Token(Token = "0x400F01A")]
			[FieldOffset(Offset = "0x10")]
			private string identifier;

			// Token: 0x0400F01B RID: 61467
			[Token(Token = "0x400F01B")]
			[FieldOffset(Offset = "0x18")]
			private string email;

			// Token: 0x0400F01C RID: 61468
			[Token(Token = "0x400F01C")]
			[FieldOffset(Offset = "0x20")]
			private string name;

			// Token: 0x0400F01D RID: 61469
			[Token(Token = "0x400F01D")]
			[FieldOffset(Offset = "0x28")]
			private string authToken;
		}
	}
}
