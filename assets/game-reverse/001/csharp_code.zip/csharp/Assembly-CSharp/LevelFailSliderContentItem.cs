﻿using System;
using Il2CppDummyDll;
using Royal.Infrastructure.UiComponents.Scroll.Content;
using UnityEngine;

// Token: 0x02000008 RID: 8
[Token(Token = "0x2000008")]
public class LevelFailSliderContentItem : UiScrollCustomContentItem
{
	// Token: 0x06000013 RID: 19 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x6000013")]
	[Address(RVA = "0x1246B60", Offset = "0x1246B60", VA = "0x1246B60", Slot = "4")]
	protected override void SetMaskBounds(Bounds maskBounds)
	{
	}

	// Token: 0x06000014 RID: 20 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x6000014")]
	[Address(RVA = "0x1246B64", Offset = "0x1246B64", VA = "0x1246B64", Slot = "5")]
	public override void Prepare(IUiScrollContentData data, Bounds maskBounds)
	{
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x6000015")]
	[Address(RVA = "0x1246B68", Offset = "0x1246B68", VA = "0x1246B68")]
	public LevelFailSliderContentItem()
	{
	}
}
