﻿using System;
using System.Collections;
using System.Text;
using Il2CppDummyDll;

namespace HSMiniJSON
{
	// Token: 0x02002623 RID: 9763
	[Token(Token = "0x2002623")]
	public static class Json
	{
		// Token: 0x060130DC RID: 78044 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130DC")]
		[Address(RVA = "0x24C61C4", Offset = "0x24C61C4", VA = "0x24C61C4")]
		public static string Serialize(object obj)
		{
			return null;
		}

		// Token: 0x02002624 RID: 9764
		[Token(Token = "0x2002624")]
		private sealed class Serializer
		{
			// Token: 0x060130DD RID: 78045 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130DD")]
			[Address(RVA = "0x24C623C", Offset = "0x24C623C", VA = "0x24C623C")]
			private Serializer()
			{
			}

			// Token: 0x060130DE RID: 78046 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x60130DE")]
			[Address(RVA = "0x24C61C8", Offset = "0x24C61C8", VA = "0x24C61C8")]
			public static string Serialize(object obj)
			{
				return null;
			}

			// Token: 0x060130DF RID: 78047 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130DF")]
			[Address(RVA = "0x24C62B0", Offset = "0x24C62B0", VA = "0x24C62B0")]
			private void SerializeValue(object value)
			{
			}

			// Token: 0x060130E0 RID: 78048 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130E0")]
			[Address(RVA = "0x24C6A9C", Offset = "0x24C6A9C", VA = "0x24C6A9C")]
			private void SerializeObject(IDictionary obj)
			{
			}

			// Token: 0x060130E1 RID: 78049 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130E1")]
			[Address(RVA = "0x24C673C", Offset = "0x24C673C", VA = "0x24C673C")]
			private void SerializeArray(IList anArray)
			{
			}

			// Token: 0x060130E2 RID: 78050 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130E2")]
			[Address(RVA = "0x24C6480", Offset = "0x24C6480", VA = "0x24C6480")]
			private void SerializeString(string str)
			{
			}

			// Token: 0x060130E3 RID: 78051 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130E3")]
			[Address(RVA = "0x24C6F28", Offset = "0x24C6F28", VA = "0x24C6F28")]
			private void SerializeOther(object value)
			{
			}

			// Token: 0x0400EFEA RID: 61418
			[Token(Token = "0x400EFEA")]
			[FieldOffset(Offset = "0x10")]
			private StringBuilder builder;
		}
	}
}
