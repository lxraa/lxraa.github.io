﻿using System;
using Il2CppDummyDll;
using Royal.Scenes.Game.Mechanics.Sortings;
using UnityEngine;

// Token: 0x02000007 RID: 7
[Token(Token = "0x2000007")]
public struct GrassSpriteData
{
	// Token: 0x04000019 RID: 25
	[Token(Token = "0x4000019")]
	[FieldOffset(Offset = "0x0")]
	public Sprite sprite;

	// Token: 0x0400001A RID: 26
	[Token(Token = "0x400001A")]
	[FieldOffset(Offset = "0x8")]
	public SortingData sorting;

	// Token: 0x0400001B RID: 27
	[Token(Token = "0x400001B")]
	[FieldOffset(Offset = "0x14")]
	public Color color;
}
