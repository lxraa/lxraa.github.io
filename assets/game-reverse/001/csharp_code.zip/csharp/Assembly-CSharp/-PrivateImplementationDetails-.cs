﻿using System;
using System.Runtime.InteropServices;
using Il2CppDummyDll;

// Token: 0x020026A7 RID: 9895
[Token(Token = "0x20026A7")]
internal sealed class <PrivateImplementationDetails>
{
	// Token: 0x06013402 RID: 78850 RVA: 0x0007C080 File Offset: 0x0007A280
	[Token(Token = "0x6013402")]
	[Address(RVA = "0x16D4554", Offset = "0x16D4554", VA = "0x16D4554")]
	internal static uint ComputeStringHash(string s)
	{
		return 0U;
	}

	// Token: 0x0400F253 RID: 62035
	[Token(Token = "0x400F253")]
	[MetadataOffset(Offset = "0x70F240")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 023D7B751C712999426B2477D6E3D3A614957E4E93B72490F886561C460DF353;

	// Token: 0x0400F254 RID: 62036
	[Token(Token = "0x400F254")]
	[MetadataOffset(Offset = "0x70F250")]
	[Il2CppDummyDll.FieldOffset(Offset = "0xC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=52 066D6770D9EBA3BBB7AEBC4B33610B0915B8E8A8DD74D931692A4CFE6EC48ED5;

	// Token: 0x0400F255 RID: 62037
	[Token(Token = "0x400F255")]
	[MetadataOffset(Offset = "0x70F288")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x40")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=96 0A0D6BA8A147594F8E2525F66E558400DA1A2E69A71058DC89F69F671AA1323A;

	// Token: 0x0400F256 RID: 62038
	[Token(Token = "0x400F256")]
	[MetadataOffset(Offset = "0x70F2F0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0xA0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 168373A1A68FD6FED438EAD899D65CEEB10FC0AB44E8A911B7D199D462C878EC;

	// Token: 0x0400F257 RID: 62039
	[Token(Token = "0x400F257")]
	[MetadataOffset(Offset = "0x70F308")]
	[Il2CppDummyDll.FieldOffset(Offset = "0xB0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 180829089312A1A43EBBA42DB33608BFE761D94A91399CF42C91D476F9A8C068;

	// Token: 0x0400F258 RID: 62040
	[Token(Token = "0x400F258")]
	[MetadataOffset(Offset = "0x70F320")]
	[Il2CppDummyDll.FieldOffset(Offset = "0xC4")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 224E30CF5DACB250208DE77C781EAD8721ED38EDEB39E0999BDCECF4B9B548B7;

	// Token: 0x0400F259 RID: 62041
	[Token(Token = "0x400F259")]
	[MetadataOffset(Offset = "0x70F330")]
	[Il2CppDummyDll.FieldOffset(Offset = "0xD0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 23414BE09CCA979DA8B3A9AEB09BEE0523F956BD53CB3D254676BB2F97C118E8;

	// Token: 0x0400F25A RID: 62042
	[Token(Token = "0x400F25A")]
	[MetadataOffset(Offset = "0x70F340")]
	[Il2CppDummyDll.FieldOffset(Offset = "0xDC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=60 24D672EE2B6D806D3687E0A961AA1F78239C1F3F17AF6A171D9A734CB3B4895E;

	// Token: 0x0400F25B RID: 62043
	[Token(Token = "0x400F25B")]
	[MetadataOffset(Offset = "0x70F380")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x118")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 254E1B0513CCA69A682D5A133F868AB1E59960573CB85471C786C866E75FED1D;

	// Token: 0x0400F25C RID: 62044
	[Token(Token = "0x400F25C")]
	[MetadataOffset(Offset = "0x70F390")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x124")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=24 25B4D4ECB8DB4D1D6BDFD19F783F4C0D42FD4667B7F697446AC6F87D15EEBE9A;

	// Token: 0x0400F25D RID: 62045
	[Token(Token = "0x400F25D")]
	[MetadataOffset(Offset = "0x70F3B0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x13C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 25D7861D0F6DD8E0D0B92A8B618AA24AEDBE95164638B8A4CECFDE20D9AE97A0;

	// Token: 0x0400F25E RID: 62046
	[Token(Token = "0x400F25E")]
	[MetadataOffset(Offset = "0x70F3C0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x148")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 2B9CC0C629B4D9F8DEC4A8870860CE176BC2CB8EC3E73DD44543469062C9F2C3;

	// Token: 0x0400F25F RID: 62047
	[Token(Token = "0x400F25F")]
	[MetadataOffset(Offset = "0x70F3D8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x15C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 2CE91540078FC843EFFD2356F149E6E62BF711CE2B7F62B8E2D19A026234E80F;

	// Token: 0x0400F260 RID: 62048
	[Token(Token = "0x400F260")]
	[MetadataOffset(Offset = "0x70F3F0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x170")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 331F85A188B274B716F1A1DA384E89D1EB1D78CF8A0D51C4B5C27A41C95000EC;

	// Token: 0x0400F261 RID: 62049
	[Token(Token = "0x400F261")]
	[MetadataOffset(Offset = "0x70F408")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x180")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=40 3B7B2570A6F69A4E2B1A95A0CD590A4DEA3FDC6BB3AFC9B585D61D2D5EDEF62E;

	// Token: 0x0400F262 RID: 62050
	[Token(Token = "0x400F262")]
	[MetadataOffset(Offset = "0x70F438")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x1A8")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 3CE61E6806FC4D37A0AAE06760BDDADD9E8A21E5C528084F853686A2F301027C;

	// Token: 0x0400F263 RID: 62051
	[Token(Token = "0x400F263")]
	[MetadataOffset(Offset = "0x70F450")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x1BC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 4305B5DD74DC7D245663B739668B3574B119788BDA7D4D84D71F6206E4ADEB26;

	// Token: 0x0400F264 RID: 62052
	[Token(Token = "0x400F264")]
	[MetadataOffset(Offset = "0x70F460")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x1C8")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 49C16B6F0EF802F3AAF7FC52DC1E6925199EDDC6E255028182BBA4E236F8F855;

	// Token: 0x0400F265 RID: 62053
	[Token(Token = "0x400F265")]
	[MetadataOffset(Offset = "0x70F478")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x1D8")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 4C470ED8158AE4B92AFFD098F9CD2C17F3994EE59F1868F6786A7AA0BDF0E078;

	// Token: 0x0400F266 RID: 62054
	[Token(Token = "0x400F266")]
	[MetadataOffset(Offset = "0x70F488")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x1E4")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 58D52BBE85F999382A119A10CA9AC71DC3AD6B1AAE8B9287B71CC5FD8F939F0D;

	// Token: 0x0400F267 RID: 62055
	[Token(Token = "0x400F267")]
	[MetadataOffset(Offset = "0x70F498")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x1F0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 5BDF46E090DF9361877A941811DC9CDDEBA08ACEBD62828B4E8A66163B9CF83E;

	// Token: 0x0400F268 RID: 62056
	[Token(Token = "0x400F268")]
	[MetadataOffset(Offset = "0x70F4A8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x1FC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 63F21B34C161581DF8A07312CE59F96797800BD743908228DD4247BDAD718D2C;

	// Token: 0x0400F269 RID: 62057
	[Token(Token = "0x400F269")]
	[MetadataOffset(Offset = "0x70F4C0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x20C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 69055F6165E3D79A59A2F3ED6F45C8B1ED5510C1F48698FC74990D55FDCF16EF;

	// Token: 0x0400F26A RID: 62058
	[Token(Token = "0x400F26A")]
	[MetadataOffset(Offset = "0x70F4D0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x218")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=100 6A32DC2C8739087997E603EFBA4AAFA9061F8357090DF59BE2A256A923D4428F;

	// Token: 0x0400F26B RID: 62059
	[Token(Token = "0x400F26B")]
	[MetadataOffset(Offset = "0x70F538")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x27C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 6B1ADC74665A0B800C6B336FC01617389B791DB623F2489767F964AF0E3CF9F5;

	// Token: 0x0400F26C RID: 62060
	[Token(Token = "0x400F26C")]
	[MetadataOffset(Offset = "0x70F548")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x288")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=24 6B37F2DC3CBC36CB512AAB959CD9F9E3A5ED19A1282D3D8D0EF02E14C2935C71;

	// Token: 0x0400F26D RID: 62061
	[Token(Token = "0x400F26D")]
	[MetadataOffset(Offset = "0x70F568")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x2A0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 706740233257FD5FC1364122936AEC803CE24AC0CA619BB32D2D8D4467EB79AF;

	// Token: 0x0400F26E RID: 62062
	[Token(Token = "0x400F26E")]
	[MetadataOffset(Offset = "0x70F578")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x2AC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 7346A7B9516815DD0FF007F890500BAA12B0F30BA2E0AB1B72C808E00ACBF813;

	// Token: 0x0400F26F RID: 62063
	[Token(Token = "0x400F26F")]
	[MetadataOffset(Offset = "0x70F590")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x2BC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=36 772936A00CC7A3DBBF8C372D21BD0541118EA243C0DA9C644BEE7702B8CF2807;

	// Token: 0x0400F270 RID: 62064
	[Token(Token = "0x400F270")]
	[MetadataOffset(Offset = "0x70F5B8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x2E0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 7E5BBC676CAB163AEF795CD7981DA581A5BCA4E9F9973882DFD7016693EBC953;

	// Token: 0x0400F271 RID: 62065
	[Token(Token = "0x400F271")]
	[MetadataOffset(Offset = "0x70F5D0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x2F0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 7F2D4D4167C64FC6C557929A661A02070F0B5E5F58FBD350069011AA29B4CE9A;

	// Token: 0x0400F272 RID: 62066
	[Token(Token = "0x400F272")]
	[MetadataOffset(Offset = "0x70F5E0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x2FC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 8987857FE5B2B0666E000F513E356B1EDEBB85B619A159864E30E184319FE377;

	// Token: 0x0400F273 RID: 62067
	[Token(Token = "0x400F273")]
	[MetadataOffset(Offset = "0x70F5F8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x30C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 8B31C6363303163DAEB3C89E648E712CCAC26984AA2FBD5D7C1767757DC032F4;

	// Token: 0x0400F274 RID: 62068
	[Token(Token = "0x400F274")]
	[MetadataOffset(Offset = "0x70F608")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x318")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=32 8B4B2444E57AED8C2D05A1293255DA1B048C63224317D4666230760935FA4A18;

	// Token: 0x0400F275 RID: 62069
	[Token(Token = "0x400F275")]
	[MetadataOffset(Offset = "0x70F630")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x338")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 8B55391B24EAAE41D1F85DB7A8F90B6E0611E1939FBF24B625DAE4F4A5E44ED9;

	// Token: 0x0400F276 RID: 62070
	[Token(Token = "0x400F276")]
	[MetadataOffset(Offset = "0x70F648")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x34C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=52 8C3BBEFBF4450EEECE8BF9126ACC7F9A9C434140E2CB6295436B33642534B0DC;

	// Token: 0x0400F277 RID: 62071
	[Token(Token = "0x400F277")]
	[MetadataOffset(Offset = "0x70F680")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x380")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=24 90C97AE3E357E5C53B9ED40D20DB02271A2D171E715770B34E953E33C69203C1;

	// Token: 0x0400F278 RID: 62072
	[Token(Token = "0x400F278")]
	[MetadataOffset(Offset = "0x70F6A0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x398")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=140 94F0C8893A296B63050478C77BBF28FA4A663352B4FF83AC0C9275A5D02A9C32;

	// Token: 0x0400F279 RID: 62073
	[Token(Token = "0x400F279")]
	[MetadataOffset(Offset = "0x70F730")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x424")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 950A185073EC968709D77B996738EB70CE66615CCC434918D0073769334EC88F;

	// Token: 0x0400F27A RID: 62074
	[Token(Token = "0x400F27A")]
	[MetadataOffset(Offset = "0x70F748")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x438")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 9DB984147B13E1B15E653A5F81146120102D36EAC6F36D43EC4ABA49D3F7710C;

	// Token: 0x0400F27B RID: 62075
	[Token(Token = "0x400F27B")]
	[MetadataOffset(Offset = "0x70F760")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x44C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=60 A4B88803116DDD2124716C276C8CF70FD0073D468F8021B8C905A21F3C9389A1;

	// Token: 0x0400F27C RID: 62076
	[Token(Token = "0x400F27C")]
	[MetadataOffset(Offset = "0x70F7A0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x488")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 A5820A03D19E53063FF53151624F652304A9F06B885FDACDAF7DA388BE6C6E12;

	// Token: 0x0400F27D RID: 62077
	[Token(Token = "0x400F27D")]
	[MetadataOffset(Offset = "0x70F7B8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x498")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 A582F019AB78E8B17D17B3C5EF985BCE1E7E888C525454C0F18B126105A042D9;

	// Token: 0x0400F27E RID: 62078
	[Token(Token = "0x400F27E")]
	[MetadataOffset(Offset = "0x70F7D0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x4AC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 A75D02F8CCB1C188B8968D3774EB11060A049DDBF3910B966B150D855C6992D0;

	// Token: 0x0400F27F RID: 62079
	[Token(Token = "0x400F27F")]
	[MetadataOffset(Offset = "0x70F7E8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x4C0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 A8CA10A1CAA103B8BA6008B6125D6FE27C554C88701B9D2644AC50C8547D61FB;

	// Token: 0x0400F280 RID: 62080
	[Token(Token = "0x400F280")]
	[MetadataOffset(Offset = "0x70F800")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x4D0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 ADCC4DFD68128ED66848710D3BB7DEBC7E77222F6D308CAC25A381268B76375B;

	// Token: 0x0400F281 RID: 62081
	[Token(Token = "0x400F281")]
	[MetadataOffset(Offset = "0x70F810")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x4DC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=280 AE83A731040EB21F73D6DE1B34CC16061E2D636E3B94178E06499E29D4C33EA7;

	// Token: 0x0400F282 RID: 62082
	[Token(Token = "0x400F282")]
	[MetadataOffset(Offset = "0x70F930")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x5F4")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=40 B855406C39DB2D736C16B8984A4745017AF6BBE760E7397DF5909F0F078EEA00;

	// Token: 0x0400F283 RID: 62083
	[Token(Token = "0x400F283")]
	[MetadataOffset(Offset = "0x70F960")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x61C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=10 BA468B207145248903F995DE2F172A2CCED87445E94B08E4D39F2EA90ED8987B;

	// Token: 0x0400F284 RID: 62084
	[Token(Token = "0x400F284")]
	[MetadataOffset(Offset = "0x70F970")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x626")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 BAED642339816AFFB3FE8719792D0E4CE82F12DB72B7373D244EAA65445800FE;

	// Token: 0x0400F285 RID: 62085
	[Token(Token = "0x400F285")]
	[MetadataOffset(Offset = "0x70F988")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x636")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 BDA3A8BE2F7A5C9C73B7A7E084571923FA0635A70D918525BEAE67E9B4CD7C53;

	// Token: 0x0400F286 RID: 62086
	[Token(Token = "0x400F286")]
	[MetadataOffset(Offset = "0x70F9A0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x646")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 BFC6AEADC3331E6F96704AE35BFDCC529F721322BD6B92A91B1151B4BF538896;

	// Token: 0x0400F287 RID: 62087
	[Token(Token = "0x400F287")]
	[MetadataOffset(Offset = "0x70F9B0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x652")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 C0679C19542A88B318AAC6EE64E2B7076A9B2E1D3EB5F02AD2410E492434B22C;

	// Token: 0x0400F288 RID: 62088
	[Token(Token = "0x400F288")]
	[MetadataOffset(Offset = "0x70F9C8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x662")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 C357CCDAD9513DC08D4CDB2F5DF7E5679423492B7AFA4A82F6F65F0570658716;

	// Token: 0x0400F289 RID: 62089
	[Token(Token = "0x400F289")]
	[MetadataOffset(Offset = "0x70F9D8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x66E")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 C4BFD54D2F5AED8AA6C4046BCEA73E3A4D68904C78E1F053897131636D7C7210;

	// Token: 0x0400F28A RID: 62090
	[Token(Token = "0x400F28A")]
	[MetadataOffset(Offset = "0x70F9E8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x67A")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 CA4D438D560CF77F1CBC00D48A304697BB0BEB26D7406DE7B0354F95B04AF681;

	// Token: 0x0400F28B RID: 62091
	[Token(Token = "0x400F28B")]
	[MetadataOffset(Offset = "0x70F9F8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x686")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=100 CA7E76EF277D462C0BBBBC6100313F9CC81A2B944CC42D43D5CC6B042557B795;

	// Token: 0x0400F28C RID: 62092
	[Token(Token = "0x400F28C")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x6F0")]
	internal static readonly long CD219A5EA3867D8B0CE828CC3AC7EEF6A381EC1877FA530DF71ACC8263C6FCA4 = 1125908496842752L;

	// Token: 0x0400F28D RID: 62093
	[Token(Token = "0x400F28D")]
	[MetadataOffset(Offset = "0x70FA70")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x6F8")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=24 CD9A54ED1F18BF97DB08914E280EA7349E11CA2C4885A4D8052552CEBA84208D;

	// Token: 0x0400F28E RID: 62094
	[Token(Token = "0x400F28E")]
	[MetadataOffset(Offset = "0x70FA90")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x710")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 CE99AE045C8B2A2A8A58FD1A2120956E74E90322EEF45F7DFE1CA73EEFE655D4;

	// Token: 0x0400F28F RID: 62095
	[Token(Token = "0x400F28F")]
	[MetadataOffset(Offset = "0x70FAA0")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x71C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=16 CF97ADEEDB59E05BFD73A2B4C2A8885708C4F4F70C84C64B27120E72AB733B72;

	// Token: 0x0400F290 RID: 62096
	[Token(Token = "0x400F290")]
	[MetadataOffset(Offset = "0x70FAB8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x72C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 D19C56FE954B4ADBB040580D9AE4E98A692B51F8E2CAB91D7DDECB903CEC9204;

	// Token: 0x0400F291 RID: 62097
	[Token(Token = "0x400F291")]
	[MetadataOffset(Offset = "0x70FAC8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x738")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=100 DB59009EE5BEEFBBA740BE33BC67C7D48C2A90C837CC8F7F4D8256B43CBF971F;

	// Token: 0x0400F292 RID: 62098
	[Token(Token = "0x400F292")]
	[MetadataOffset(Offset = "0x70FB30")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x79C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 DDF3C2877106BA84D7C47B7DEE3A3D948146999CF5B40E123BF678546E786DF0;

	// Token: 0x0400F293 RID: 62099
	[Token(Token = "0x400F293")]
	[MetadataOffset(Offset = "0x70FB40")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x7A8")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 E0C530EC17F37E294CD1BAC85578948A18CAA909890DD602FE6942EF0F2B603B;

	// Token: 0x0400F294 RID: 62100
	[Token(Token = "0x400F294")]
	[MetadataOffset(Offset = "0x70FB58")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x7BC")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 E0E1BA4BD8D250616607C570EDEF48B4803881A9D893B5BD87E7473A3BBDCE96;

	// Token: 0x0400F295 RID: 62101
	[Token(Token = "0x400F295")]
	[MetadataOffset(Offset = "0x70FB68")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x7C8")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=148 E1B19386C6FE75EB7F94D6C0AABBC4256357AAE13711D5C3998E04147843D153;

	// Token: 0x0400F296 RID: 62102
	[Token(Token = "0x400F296")]
	[MetadataOffset(Offset = "0x70FC00")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x85C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 E528F4309E1413E6BC35AEA5D8DB8519384D2FCC33F9DD5D1126D73F104CF92A;

	// Token: 0x0400F297 RID: 62103
	[Token(Token = "0x400F297")]
	[MetadataOffset(Offset = "0x70FC18")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x870")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=20 E7C6A1B96CF1D5341B824E74568AD1F890C9DA2DD557C927FAAFFAA5CC78964F;

	// Token: 0x0400F298 RID: 62104
	[Token(Token = "0x400F298")]
	[MetadataOffset(Offset = "0x70FC30")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x884")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 F25AD643D0AB802C5B25BB9FC21ADA44CFD3496CE7B3F1FDF65AD239017E95BA;

	// Token: 0x0400F299 RID: 62105
	[Token(Token = "0x400F299")]
	[MetadataOffset(Offset = "0x70FC40")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x890")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 F5219C13547949D5ADCF622772FCC1961EC990E5CE76443684898C6525EA2E37;

	// Token: 0x0400F29A RID: 62106
	[Token(Token = "0x400F29A")]
	[MetadataOffset(Offset = "0x70FC50")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x89C")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=40 FA22AD1783F2D31C769230A49B0ADE2088AF4CF928D4251CE0C5F6DE90097506;

	// Token: 0x0400F29B RID: 62107
	[Token(Token = "0x400F29B")]
	[MetadataOffset(Offset = "0x70FC80")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x8C4")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=32 FAED7049102A1787A389A02BB70A59BB11957CE2B9D598BA937152E68DCC169C;

	// Token: 0x0400F29C RID: 62108
	[Token(Token = "0x400F29C")]
	[MetadataOffset(Offset = "0x70FCA8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x8E4")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=12 FEA9BFEA521B6A4FF694FB8C67F153D51252580E2BDEAA09242C6892DAFB68EC;

	// Token: 0x0400F29D RID: 62109
	[Token(Token = "0x400F29D")]
	[MetadataOffset(Offset = "0x70FCB8")]
	[Il2CppDummyDll.FieldOffset(Offset = "0x8F0")]
	internal static readonly <PrivateImplementationDetails>.__StaticArrayInitTypeSize=32 FF1F6EE5D67458CFAC950F62E93042E21FCB867E2234DCC8721801231064AD40;

	// Token: 0x020026A8 RID: 9896
	[Token(Token = "0x20026A8")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=10
	{
	}

	// Token: 0x020026A9 RID: 9897
	[Token(Token = "0x20026A9")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=12
	{
	}

	// Token: 0x020026AA RID: 9898
	[Token(Token = "0x20026AA")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=16
	{
	}

	// Token: 0x020026AB RID: 9899
	[Token(Token = "0x20026AB")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=20
	{
	}

	// Token: 0x020026AC RID: 9900
	[Token(Token = "0x20026AC")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=24
	{
	}

	// Token: 0x020026AD RID: 9901
	[Token(Token = "0x20026AD")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=32
	{
	}

	// Token: 0x020026AE RID: 9902
	[Token(Token = "0x20026AE")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=36
	{
	}

	// Token: 0x020026AF RID: 9903
	[Token(Token = "0x20026AF")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=40
	{
	}

	// Token: 0x020026B0 RID: 9904
	[Token(Token = "0x20026B0")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=52
	{
	}

	// Token: 0x020026B1 RID: 9905
	[Token(Token = "0x20026B1")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=60
	{
	}

	// Token: 0x020026B2 RID: 9906
	[Token(Token = "0x20026B2")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=96
	{
	}

	// Token: 0x020026B3 RID: 9907
	[Token(Token = "0x20026B3")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=100
	{
	}

	// Token: 0x020026B4 RID: 9908
	[Token(Token = "0x20026B4")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=140
	{
	}

	// Token: 0x020026B5 RID: 9909
	[Token(Token = "0x20026B5")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=148
	{
	}

	// Token: 0x020026B6 RID: 9910
	[Token(Token = "0x20026B6")]
	[StructLayout(2)]
	private struct __StaticArrayInitTypeSize=280
	{
	}
}
