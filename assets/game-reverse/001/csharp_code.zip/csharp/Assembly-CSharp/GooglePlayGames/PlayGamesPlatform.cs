﻿using System;
using System.Collections.Generic;
using GooglePlayGames.BasicApi;
using Il2CppDummyDll;

namespace GooglePlayGames
{
	// Token: 0x0200262D RID: 9773
	[Token(Token = "0x200262D")]
	public class PlayGamesPlatform
	{
		// Token: 0x0601310A RID: 78090 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601310A")]
		[Address(RVA = "0x24C92D8", Offset = "0x24C92D8", VA = "0x24C92D8")]
		private PlayGamesPlatform(PlayGamesClientConfiguration configuration)
		{
		}

		// Token: 0x17002828 RID: 10280
		// (get) Token: 0x0601310B RID: 78091 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002828")]
		public static PlayGamesPlatform Instance
		{
			[Token(Token = "0x601310B")]
			[Address(RVA = "0x24C9520", Offset = "0x24C9520", VA = "0x24C9520")]
			get
			{
				return null;
			}
		}

		// Token: 0x0601310C RID: 78092 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601310C")]
		[Address(RVA = "0x24C9608", Offset = "0x24C9608", VA = "0x24C9608")]
		public static void InitializeInstance(PlayGamesClientConfiguration configuration)
		{
		}

		// Token: 0x0601310D RID: 78093 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601310D")]
		[Address(RVA = "0x24C9914", Offset = "0x24C9914", VA = "0x24C9914")]
		public void Authenticate(Action<bool, string> callback, bool silent)
		{
		}

		// Token: 0x0601310E RID: 78094 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601310E")]
		[Address(RVA = "0x24C99F4", Offset = "0x24C99F4", VA = "0x24C99F4")]
		public void Authenticate(SignInInteractivity signInInteractivity, Action<SignInStatus> callback)
		{
		}

		// Token: 0x0601310F RID: 78095 RVA: 0x0007B0D8 File Offset: 0x000792D8
		[Token(Token = "0x601310F")]
		[Address(RVA = "0x24C8CF0", Offset = "0x24C8CF0", VA = "0x24C8CF0")]
		public bool IsAuthenticated()
		{
			return default(bool);
		}

		// Token: 0x06013110 RID: 78096 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013110")]
		[Address(RVA = "0x24C8F80", Offset = "0x24C8F80", VA = "0x24C8F80")]
		public string GetUserId()
		{
			return null;
		}

		// Token: 0x06013111 RID: 78097 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013111")]
		[Address(RVA = "0x24C8E64", Offset = "0x24C8E64", VA = "0x24C8E64")]
		public string GetUserDisplayName()
		{
			return null;
		}

		// Token: 0x06013112 RID: 78098 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013112")]
		[Address(RVA = "0x24C9094", Offset = "0x24C9094", VA = "0x24C9094")]
		public string GetUserImageUrl()
		{
			return null;
		}

		// Token: 0x0400F022 RID: 61474
		[Token(Token = "0x400F022")]
		[FieldOffset(Offset = "0x0")]
		private static PlayGamesPlatform sInstance;

		// Token: 0x0400F023 RID: 61475
		[Token(Token = "0x400F023")]
		[FieldOffset(Offset = "0x10")]
		private readonly PlayGamesClientConfiguration mConfiguration;

		// Token: 0x0400F024 RID: 61476
		[Token(Token = "0x400F024")]
		[FieldOffset(Offset = "0x30")]
		private PlayGamesLocalUser mLocalUser;

		// Token: 0x0400F025 RID: 61477
		[Token(Token = "0x400F025")]
		[FieldOffset(Offset = "0x38")]
		private IPlayGamesClient mClient;

		// Token: 0x0400F026 RID: 61478
		[Token(Token = "0x400F026")]
		[FieldOffset(Offset = "0x40")]
		private Dictionary<string, string> mIdMap;

		// Token: 0x0200262E RID: 9774
		[Token(Token = "0x200262E")]
		private sealed class <>c__DisplayClass33_0
		{
			// Token: 0x06013113 RID: 78099 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013113")]
			[Address(RVA = "0x24C99EC", Offset = "0x24C99EC", VA = "0x24C99EC")]
			public <>c__DisplayClass33_0()
			{
			}

			// Token: 0x06013114 RID: 78100 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013114")]
			[Address(RVA = "0x24CA270", Offset = "0x24CA270", VA = "0x24CA270")]
			internal void <Authenticate>b__0(SignInStatus status)
			{
			}

			// Token: 0x0400F027 RID: 61479
			[Token(Token = "0x400F027")]
			[FieldOffset(Offset = "0x10")]
			public Action<bool, string> callback;
		}

		// Token: 0x0200262F RID: 9775
		[Token(Token = "0x200262F")]
		private sealed class <>c__DisplayClass34_0
		{
			// Token: 0x06013115 RID: 78101 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013115")]
			[Address(RVA = "0x24C9E1C", Offset = "0x24C9E1C", VA = "0x24C9E1C")]
			public <>c__DisplayClass34_0()
			{
			}

			// Token: 0x06013116 RID: 78102 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013116")]
			[Address(RVA = "0x24CA37C", Offset = "0x24CA37C", VA = "0x24CA37C")]
			internal void <Authenticate>b__1(SignInStatus code)
			{
			}

			// Token: 0x06013117 RID: 78103 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013117")]
			[Address(RVA = "0x24CA3E4", Offset = "0x24CA3E4", VA = "0x24CA3E4")]
			internal void <Authenticate>b__2(SignInStatus code)
			{
			}

			// Token: 0x06013118 RID: 78104 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013118")]
			[Address(RVA = "0x24CA44C", Offset = "0x24CA44C", VA = "0x24CA44C")]
			internal void <Authenticate>b__3(SignInStatus silentSignInResultCode)
			{
			}

			// Token: 0x06013119 RID: 78105 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013119")]
			[Address(RVA = "0x24CA72C", Offset = "0x24CA72C", VA = "0x24CA72C")]
			internal void <Authenticate>b__5(SignInStatus interactiveSignInResultCode)
			{
			}

			// Token: 0x0601311A RID: 78106 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601311A")]
			[Address(RVA = "0x24CA884", Offset = "0x24CA884", VA = "0x24CA884")]
			internal void <Authenticate>b__4()
			{
			}

			// Token: 0x0400F028 RID: 61480
			[Token(Token = "0x400F028")]
			[FieldOffset(Offset = "0x10")]
			public Action<SignInStatus> callback;

			// Token: 0x0400F029 RID: 61481
			[Token(Token = "0x400F029")]
			[FieldOffset(Offset = "0x18")]
			public PlayGamesPlatform <>4__this;

			// Token: 0x0400F02A RID: 61482
			[Token(Token = "0x400F02A")]
			[FieldOffset(Offset = "0x20")]
			public Action<SignInStatus> <>9__5;
		}

		// Token: 0x02002630 RID: 9776
		[Token(Token = "0x2002630")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x0601311C RID: 78108 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601311C")]
			[Address(RVA = "0x24CA91C", Offset = "0x24CA91C", VA = "0x24CA91C")]
			public <>c()
			{
			}

			// Token: 0x0601311D RID: 78109 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601311D")]
			[Address(RVA = "0x24CA924", Offset = "0x24CA924", VA = "0x24CA924")]
			internal void <Authenticate>b__34_0(SignInStatus status)
			{
			}

			// Token: 0x0400F02B RID: 61483
			[Token(Token = "0x400F02B")]
			[FieldOffset(Offset = "0x0")]
			public static readonly PlayGamesPlatform.<>c <>9;

			// Token: 0x0400F02C RID: 61484
			[Token(Token = "0x400F02C")]
			[FieldOffset(Offset = "0x8")]
			public static Action<SignInStatus> <>9__34_0;
		}
	}
}
