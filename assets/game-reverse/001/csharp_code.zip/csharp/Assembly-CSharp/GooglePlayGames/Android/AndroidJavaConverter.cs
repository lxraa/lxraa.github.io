﻿using System;
using GooglePlayGames.BasicApi;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.Android
{
	// Token: 0x0200263E RID: 9790
	[Token(Token = "0x200263E")]
	internal class AndroidJavaConverter
	{
		// Token: 0x0601314F RID: 78159 RVA: 0x0007B138 File Offset: 0x00079338
		[Token(Token = "0x601314F")]
		[Address(RVA = "0x24D016C", Offset = "0x24D016C", VA = "0x24D016C")]
		internal static DateTime ToDateTime(long milliseconds)
		{
			return default(DateTime);
		}

		// Token: 0x06013150 RID: 78160 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013150")]
		[Address(RVA = "0x24CE9C0", Offset = "0x24CE9C0", VA = "0x24CE9C0")]
		internal static Player ToPlayer(AndroidJavaObject player)
		{
			return null;
		}
	}
}
