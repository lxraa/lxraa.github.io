﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.Android
{
	// Token: 0x02002645 RID: 9797
	[Token(Token = "0x2002645")]
	internal class AndroidTaskUtils
	{
		// Token: 0x06013164 RID: 78180 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013164")]
		public static void AddOnSuccessListener<T>(AndroidJavaObject task, Action<T> callback)
		{
		}

		// Token: 0x06013165 RID: 78181 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013165")]
		[Address(RVA = "0x24CC370", Offset = "0x24CC370", VA = "0x24CC370")]
		public static void AddOnFailureListener(AndroidJavaObject task, Action<AndroidJavaObject> callback)
		{
		}

		// Token: 0x06013166 RID: 78182 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013166")]
		public static void AddOnCompleteListener<T>(AndroidJavaObject task, Action<T> callback)
		{
		}

		// Token: 0x02002646 RID: 9798
		[Token(Token = "0x2002646")]
		private class TaskOnCompleteProxy<T> : AndroidJavaProxy
		{
			// Token: 0x06013167 RID: 78183 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013167")]
			public TaskOnCompleteProxy(Action<T> callback)
			{
			}

			// Token: 0x06013168 RID: 78184 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013168")]
			public void onComplete(T result)
			{
			}

			// Token: 0x0400F063 RID: 61539
			[Token(Token = "0x400F063")]
			[FieldOffset(Offset = "0x0")]
			private Action<T> mCallback;
		}

		// Token: 0x02002647 RID: 9799
		[Token(Token = "0x2002647")]
		private class TaskOnSuccessProxy<T> : AndroidJavaProxy
		{
			// Token: 0x06013169 RID: 78185 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013169")]
			public TaskOnSuccessProxy(Action<T> callback, bool disposeResult)
			{
			}

			// Token: 0x0601316A RID: 78186 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601316A")]
			public void onSuccess(T result)
			{
			}

			// Token: 0x0400F064 RID: 61540
			[Token(Token = "0x400F064")]
			[FieldOffset(Offset = "0x0")]
			private Action<T> mCallback;

			// Token: 0x0400F065 RID: 61541
			[Token(Token = "0x400F065")]
			[FieldOffset(Offset = "0x0")]
			private bool mDisposeResult;
		}

		// Token: 0x02002648 RID: 9800
		[Token(Token = "0x2002648")]
		private class TaskOnFailedProxy : AndroidJavaProxy
		{
			// Token: 0x0601316B RID: 78187 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601316B")]
			[Address(RVA = "0x24D279C", Offset = "0x24D279C", VA = "0x24D279C")]
			public TaskOnFailedProxy(Action<AndroidJavaObject> callback)
			{
			}

			// Token: 0x0601316C RID: 78188 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601316C")]
			[Address(RVA = "0x24D2828", Offset = "0x24D2828", VA = "0x24D2828")]
			public void onFailure(AndroidJavaObject exception)
			{
			}

			// Token: 0x0400F066 RID: 61542
			[Token(Token = "0x400F066")]
			[FieldOffset(Offset = "0x20")]
			private Action<AndroidJavaObject> mCallback;
		}
	}
}
