﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.Android
{
	// Token: 0x02002649 RID: 9801
	[Token(Token = "0x2002649")]
	internal class AndroidTokenClient
	{
		// Token: 0x0601316D RID: 78189 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601316D")]
		[Address(RVA = "0x24CB7A8", Offset = "0x24CB7A8", VA = "0x24CB7A8", Slot = "4")]
		public void SetRequestAuthCode(bool flag, bool forceRefresh)
		{
		}

		// Token: 0x0601316E RID: 78190 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601316E")]
		[Address(RVA = "0x24D29A4", Offset = "0x24D29A4", VA = "0x24D29A4", Slot = "5")]
		public void SetRequestEmail(bool flag)
		{
		}

		// Token: 0x0601316F RID: 78191 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601316F")]
		[Address(RVA = "0x24D29B0", Offset = "0x24D29B0", VA = "0x24D29B0", Slot = "6")]
		public void SetRequestIdToken(bool flag)
		{
		}

		// Token: 0x06013170 RID: 78192 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013170")]
		[Address(RVA = "0x24D29BC", Offset = "0x24D29BC", VA = "0x24D29BC", Slot = "7")]
		public void SetWebClientId(string webClientId)
		{
		}

		// Token: 0x06013171 RID: 78193 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013171")]
		[Address(RVA = "0x24D29C4", Offset = "0x24D29C4", VA = "0x24D29C4", Slot = "8")]
		public void SetHidePopups(bool flag)
		{
		}

		// Token: 0x06013172 RID: 78194 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013172")]
		[Address(RVA = "0x24D29D0", Offset = "0x24D29D0", VA = "0x24D29D0", Slot = "9")]
		public void SetAccountName(string accountName)
		{
		}

		// Token: 0x06013173 RID: 78195 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013173")]
		[Address(RVA = "0x24CB7BC", Offset = "0x24CB7BC", VA = "0x24CB7BC", Slot = "10")]
		public void AddOauthScopes(params string[] scopes)
		{
		}

		// Token: 0x06013174 RID: 78196 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013174")]
		[Address(RVA = "0x24CBADC", Offset = "0x24CBADC", VA = "0x24CBADC", Slot = "11")]
		public void Signout()
		{
		}

		// Token: 0x06013175 RID: 78197 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013175")]
		[Address(RVA = "0x24CB56C", Offset = "0x24CB56C", VA = "0x24CB56C", Slot = "12")]
		public void FetchTokens(bool silent, Action<int> callback)
		{
		}

		// Token: 0x06013176 RID: 78198 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013176")]
		[Address(RVA = "0x24D29E0", Offset = "0x24D29E0", VA = "0x24D29E0")]
		private void DoFetchToken(bool silent, Action<int> callback)
		{
		}

		// Token: 0x06013177 RID: 78199 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013177")]
		[Address(RVA = "0x24D34B4", Offset = "0x24D34B4", VA = "0x24D34B4")]
		public AndroidJavaObject GetAccount()
		{
			return null;
		}

		// Token: 0x06013178 RID: 78200 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013178")]
		[Address(RVA = "0x24CB7A0", Offset = "0x24CB7A0", VA = "0x24CB7A0")]
		public AndroidTokenClient()
		{
		}

		// Token: 0x0400F067 RID: 61543
		[Token(Token = "0x400F067")]
		[FieldOffset(Offset = "0x10")]
		private bool requestEmail;

		// Token: 0x0400F068 RID: 61544
		[Token(Token = "0x400F068")]
		[FieldOffset(Offset = "0x11")]
		private bool requestAuthCode;

		// Token: 0x0400F069 RID: 61545
		[Token(Token = "0x400F069")]
		[FieldOffset(Offset = "0x12")]
		private bool requestIdToken;

		// Token: 0x0400F06A RID: 61546
		[Token(Token = "0x400F06A")]
		[FieldOffset(Offset = "0x18")]
		private List<string> oauthScopes;

		// Token: 0x0400F06B RID: 61547
		[Token(Token = "0x400F06B")]
		[FieldOffset(Offset = "0x20")]
		private string webClientId;

		// Token: 0x0400F06C RID: 61548
		[Token(Token = "0x400F06C")]
		[FieldOffset(Offset = "0x28")]
		private bool forceRefresh;

		// Token: 0x0400F06D RID: 61549
		[Token(Token = "0x400F06D")]
		[FieldOffset(Offset = "0x29")]
		private bool hidePopups;

		// Token: 0x0400F06E RID: 61550
		[Token(Token = "0x400F06E")]
		[FieldOffset(Offset = "0x30")]
		private string accountName;

		// Token: 0x0400F06F RID: 61551
		[Token(Token = "0x400F06F")]
		[FieldOffset(Offset = "0x38")]
		private AndroidJavaObject account;

		// Token: 0x0400F070 RID: 61552
		[Token(Token = "0x400F070")]
		[FieldOffset(Offset = "0x40")]
		private string email;

		// Token: 0x0400F071 RID: 61553
		[Token(Token = "0x400F071")]
		[FieldOffset(Offset = "0x48")]
		private string authCode;

		// Token: 0x0400F072 RID: 61554
		[Token(Token = "0x400F072")]
		[FieldOffset(Offset = "0x50")]
		private string idToken;

		// Token: 0x0200264A RID: 9802
		[Token(Token = "0x200264A")]
		private class ResultCallbackProxy : AndroidJavaProxy
		{
			// Token: 0x06013179 RID: 78201 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013179")]
			[Address(RVA = "0x24D3428", Offset = "0x24D3428", VA = "0x24D3428")]
			public ResultCallbackProxy(Action<AndroidJavaObject> callback)
			{
			}

			// Token: 0x0601317A RID: 78202 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601317A")]
			[Address(RVA = "0x24D34BC", Offset = "0x24D34BC", VA = "0x24D34BC")]
			public void onResult(AndroidJavaObject tokenResult)
			{
			}

			// Token: 0x0400F073 RID: 61555
			[Token(Token = "0x400F073")]
			[FieldOffset(Offset = "0x20")]
			private Action<AndroidJavaObject> mCallback;
		}

		// Token: 0x0200264B RID: 9803
		[Token(Token = "0x200264B")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x0601317C RID: 78204 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601317C")]
			[Address(RVA = "0x24D3550", Offset = "0x24D3550", VA = "0x24D3550")]
			public <>c()
			{
			}

			// Token: 0x0601317D RID: 78205 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601317D")]
			[Address(RVA = "0x24D3558", Offset = "0x24D3558", VA = "0x24D3558")]
			internal void <Signout>b__20_0()
			{
			}

			// Token: 0x0400F074 RID: 61556
			[Token(Token = "0x400F074")]
			[FieldOffset(Offset = "0x0")]
			public static readonly AndroidTokenClient.<>c <>9;

			// Token: 0x0400F075 RID: 61557
			[Token(Token = "0x400F075")]
			[FieldOffset(Offset = "0x8")]
			public static Action <>9__20_0;
		}

		// Token: 0x0200264C RID: 9804
		[Token(Token = "0x200264C")]
		private sealed class <>c__DisplayClass24_0
		{
			// Token: 0x0601317E RID: 78206 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601317E")]
			[Address(RVA = "0x24D29D8", Offset = "0x24D29D8", VA = "0x24D29D8")]
			public <>c__DisplayClass24_0()
			{
			}

			// Token: 0x0601317F RID: 78207 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601317F")]
			[Address(RVA = "0x24D36A8", Offset = "0x24D36A8", VA = "0x24D36A8")]
			internal void <FetchTokens>b__0()
			{
			}

			// Token: 0x0400F076 RID: 61558
			[Token(Token = "0x400F076")]
			[FieldOffset(Offset = "0x10")]
			public AndroidTokenClient <>4__this;

			// Token: 0x0400F077 RID: 61559
			[Token(Token = "0x400F077")]
			[FieldOffset(Offset = "0x18")]
			public bool silent;

			// Token: 0x0400F078 RID: 61560
			[Token(Token = "0x400F078")]
			[FieldOffset(Offset = "0x20")]
			public Action<int> callback;
		}

		// Token: 0x0200264D RID: 9805
		[Token(Token = "0x200264D")]
		private sealed class <>c__DisplayClass27_0
		{
			// Token: 0x06013180 RID: 78208 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013180")]
			[Address(RVA = "0x24D3420", Offset = "0x24D3420", VA = "0x24D3420")]
			public <>c__DisplayClass27_0()
			{
			}

			// Token: 0x06013181 RID: 78209 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013181")]
			[Address(RVA = "0x24D36CC", Offset = "0x24D36CC", VA = "0x24D36CC")]
			internal void <DoFetchToken>b__0(AndroidJavaObject tokenResult)
			{
			}

			// Token: 0x0400F079 RID: 61561
			[Token(Token = "0x400F079")]
			[FieldOffset(Offset = "0x10")]
			public AndroidTokenClient <>4__this;

			// Token: 0x0400F07A RID: 61562
			[Token(Token = "0x400F07A")]
			[FieldOffset(Offset = "0x18")]
			public Action<int> callback;
		}
	}
}
