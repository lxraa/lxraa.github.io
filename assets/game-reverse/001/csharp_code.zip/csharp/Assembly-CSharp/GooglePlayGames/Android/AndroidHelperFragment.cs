﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.Android
{
	// Token: 0x0200263D RID: 9789
	[Token(Token = "0x200263D")]
	internal class AndroidHelperFragment
	{
		// Token: 0x0601314D RID: 78157 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601314D")]
		[Address(RVA = "0x24CC500", Offset = "0x24CC500", VA = "0x24CC500")]
		public static AndroidJavaObject GetActivity()
		{
			return null;
		}

		// Token: 0x0601314E RID: 78158 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601314E")]
		[Address(RVA = "0x24CD8CC", Offset = "0x24CD8CC", VA = "0x24CD8CC")]
		public static AndroidJavaObject GetDefaultPopupView()
		{
			return null;
		}
	}
}
