﻿using System;
using GooglePlayGames.BasicApi;
using GooglePlayGames.BasicApi.Video;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.Android
{
	// Token: 0x0200264E RID: 9806
	[Token(Token = "0x200264E")]
	internal class AndroidVideoClient : IVideoClient
	{
		// Token: 0x06013182 RID: 78210 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013182")]
		[Address(RVA = "0x24CF158", Offset = "0x24CF158", VA = "0x24CF158")]
		public AndroidVideoClient(bool isCaptureSupported, AndroidJavaObject account)
		{
		}

		// Token: 0x0400F07B RID: 61563
		[Token(Token = "0x400F07B")]
		[FieldOffset(Offset = "0x10")]
		private AndroidJavaObject mVideosClient;

		// Token: 0x0400F07C RID: 61564
		[Token(Token = "0x400F07C")]
		[FieldOffset(Offset = "0x18")]
		private bool mIsCaptureSupported;

		// Token: 0x0200264F RID: 9807
		[Token(Token = "0x200264F")]
		private class OnCaptureOverlayStateListenerProxy : AndroidJavaProxy
		{
			// Token: 0x06013183 RID: 78211 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013183")]
			[Address(RVA = "0x24D39D0", Offset = "0x24D39D0", VA = "0x24D39D0")]
			public OnCaptureOverlayStateListenerProxy(CaptureOverlayStateListener listener)
			{
			}

			// Token: 0x06013184 RID: 78212 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013184")]
			[Address(RVA = "0x24D3A5C", Offset = "0x24D3A5C", VA = "0x24D3A5C")]
			public void onCaptureOverlayStateChanged(int overlayState)
			{
			}

			// Token: 0x06013185 RID: 78213 RVA: 0x0007B168 File Offset: 0x00079368
			[Token(Token = "0x6013185")]
			[Address(RVA = "0x24D3B54", Offset = "0x24D3B54", VA = "0x24D3B54")]
			private static VideoCaptureOverlayState FromVideoCaptureOverlayState(int overlayState)
			{
				return (VideoCaptureOverlayState)0;
			}

			// Token: 0x0400F07D RID: 61565
			[Token(Token = "0x400F07D")]
			[FieldOffset(Offset = "0x20")]
			private CaptureOverlayStateListener mListener;

			// Token: 0x02002650 RID: 9808
			[Token(Token = "0x2002650")]
			private sealed class <>c__DisplayClass2_0
			{
				// Token: 0x06013186 RID: 78214 RVA: 0x00002053 File Offset: 0x00000253
				[Token(Token = "0x6013186")]
				[Address(RVA = "0x24D3B4C", Offset = "0x24D3B4C", VA = "0x24D3B4C")]
				public <>c__DisplayClass2_0()
				{
				}

				// Token: 0x06013187 RID: 78215 RVA: 0x00002053 File Offset: 0x00000253
				[Token(Token = "0x6013187")]
				[Address(RVA = "0x24D3B64", Offset = "0x24D3B64", VA = "0x24D3B64")]
				internal void <onCaptureOverlayStateChanged>b__0()
				{
				}

				// Token: 0x0400F07E RID: 61566
				[Token(Token = "0x400F07E")]
				[FieldOffset(Offset = "0x10")]
				public AndroidVideoClient.OnCaptureOverlayStateListenerProxy <>4__this;

				// Token: 0x0400F07F RID: 61567
				[Token(Token = "0x400F07F")]
				[FieldOffset(Offset = "0x18")]
				public int overlayState;
			}
		}
	}
}
