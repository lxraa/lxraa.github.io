﻿using System;
using System.Text.RegularExpressions;
using GooglePlayGames.BasicApi.SavedGame;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.Android
{
	// Token: 0x02002644 RID: 9796
	[Token(Token = "0x2002644")]
	internal class AndroidSavedGameClient : ISavedGameClient
	{
		// Token: 0x06013162 RID: 78178 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013162")]
		[Address(RVA = "0x24CEBB8", Offset = "0x24CEBB8", VA = "0x24CEBB8")]
		public AndroidSavedGameClient(AndroidClient androidClient, AndroidJavaObject account)
		{
		}

		// Token: 0x0400F060 RID: 61536
		[Token(Token = "0x400F060")]
		[FieldOffset(Offset = "0x0")]
		private static readonly Regex ValidFilenameRegex;

		// Token: 0x0400F061 RID: 61537
		[Token(Token = "0x400F061")]
		[FieldOffset(Offset = "0x10")]
		private AndroidJavaObject mSnapshotsClient;

		// Token: 0x0400F062 RID: 61538
		[Token(Token = "0x400F062")]
		[FieldOffset(Offset = "0x18")]
		private AndroidClient mAndroidClient;
	}
}
