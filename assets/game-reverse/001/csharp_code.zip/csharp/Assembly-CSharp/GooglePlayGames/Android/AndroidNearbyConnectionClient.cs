﻿using System;
using GooglePlayGames.BasicApi.Nearby;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.Android
{
	// Token: 0x0200263F RID: 9791
	[Token(Token = "0x200263F")]
	public class AndroidNearbyConnectionClient
	{
		// Token: 0x06013151 RID: 78161 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013151")]
		[Address(RVA = "0x24D053C", Offset = "0x24D053C", VA = "0x24D053C", Slot = "4")]
		public string GetServiceId()
		{
			return null;
		}

		// Token: 0x06013152 RID: 78162 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013152")]
		[Address(RVA = "0x24D0594", Offset = "0x24D0594", VA = "0x24D0594")]
		private static string ReadServiceId()
		{
			return null;
		}

		// Token: 0x0400F053 RID: 61523
		[Token(Token = "0x400F053")]
		[FieldOffset(Offset = "0x0")]
		private static readonly long NearbyClientId;

		// Token: 0x0400F054 RID: 61524
		[Token(Token = "0x400F054")]
		[FieldOffset(Offset = "0x8")]
		private static readonly int ApplicationInfoFlags;

		// Token: 0x0400F055 RID: 61525
		[Token(Token = "0x400F055")]
		[FieldOffset(Offset = "0x10")]
		private static readonly string ServiceId;

		// Token: 0x0400F056 RID: 61526
		[Token(Token = "0x400F056")]
		[FieldOffset(Offset = "0x10")]
		protected IMessageListener mAdvertisingMessageListener;

		// Token: 0x02002640 RID: 9792
		[Token(Token = "0x2002640")]
		private class AdvertisingConnectionLifecycleCallbackProxy : AndroidJavaProxy
		{
			// Token: 0x06013154 RID: 78164 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013154")]
			[Address(RVA = "0x24D0EAC", Offset = "0x24D0EAC", VA = "0x24D0EAC")]
			public AdvertisingConnectionLifecycleCallbackProxy(Action<AdvertisingResult> resultCallback, Action<ConnectionRequest> connectionRequestCallback, AndroidNearbyConnectionClient client)
			{
			}

			// Token: 0x06013155 RID: 78165 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013155")]
			[Address(RVA = "0x24D0F68", Offset = "0x24D0F68", VA = "0x24D0F68")]
			public void onConnectionInitiated(string endpointId, AndroidJavaObject connectionInfo)
			{
			}

			// Token: 0x06013156 RID: 78166 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013156")]
			[Address(RVA = "0x24D1204", Offset = "0x24D1204", VA = "0x24D1204")]
			public void onConnectionResult(string endpointId, AndroidJavaObject connectionResolution)
			{
			}

			// Token: 0x06013157 RID: 78167 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013157")]
			[Address(RVA = "0x24D1574", Offset = "0x24D1574", VA = "0x24D1574")]
			public void onDisconnected(string endpointId)
			{
			}

			// Token: 0x0400F057 RID: 61527
			[Token(Token = "0x400F057")]
			[FieldOffset(Offset = "0x20")]
			private Action<AdvertisingResult> mResultCallback;

			// Token: 0x0400F058 RID: 61528
			[Token(Token = "0x400F058")]
			[FieldOffset(Offset = "0x28")]
			private Action<ConnectionRequest> mConnectionRequestCallback;

			// Token: 0x0400F059 RID: 61529
			[Token(Token = "0x400F059")]
			[FieldOffset(Offset = "0x30")]
			private AndroidNearbyConnectionClient mClient;

			// Token: 0x0400F05A RID: 61530
			[Token(Token = "0x400F05A")]
			[FieldOffset(Offset = "0x38")]
			private string mLocalEndpointName;
		}

		// Token: 0x02002641 RID: 9793
		[Token(Token = "0x2002641")]
		private class PayloadCallback : AndroidJavaProxy
		{
			// Token: 0x06013158 RID: 78168 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013158")]
			[Address(RVA = "0x24D1634", Offset = "0x24D1634", VA = "0x24D1634")]
			public PayloadCallback(IMessageListener listener)
			{
			}

			// Token: 0x06013159 RID: 78169 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013159")]
			[Address(RVA = "0x24D16C0", Offset = "0x24D16C0", VA = "0x24D16C0")]
			public void onPayloadReceived(string endpointId, AndroidJavaObject payload)
			{
			}

			// Token: 0x0400F05B RID: 61531
			[Token(Token = "0x400F05B")]
			[FieldOffset(Offset = "0x20")]
			private IMessageListener mListener;
		}

		// Token: 0x02002642 RID: 9794
		[Token(Token = "0x2002642")]
		private class DiscoveringConnectionLifecycleCallback : AndroidJavaProxy
		{
			// Token: 0x0601315A RID: 78170 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601315A")]
			[Address(RVA = "0x24D18A0", Offset = "0x24D18A0", VA = "0x24D18A0")]
			public DiscoveringConnectionLifecycleCallback(Action<ConnectionResponse> responseCallback, IMessageListener listener, AndroidJavaObject client)
			{
			}

			// Token: 0x0601315B RID: 78171 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601315B")]
			[Address(RVA = "0x24D195C", Offset = "0x24D195C", VA = "0x24D195C")]
			public void onConnectionInitiated(string endpointId, AndroidJavaObject connectionInfo)
			{
			}

			// Token: 0x0601315C RID: 78172 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601315C")]
			[Address(RVA = "0x24D1CE8", Offset = "0x24D1CE8", VA = "0x24D1CE8")]
			public void onConnectionResult(string endpointId, AndroidJavaObject connectionResolution)
			{
			}

			// Token: 0x0601315D RID: 78173 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601315D")]
			[Address(RVA = "0x24D2208", Offset = "0x24D2208", VA = "0x24D2208")]
			public void onDisconnected(string endpointId)
			{
			}

			// Token: 0x0400F05C RID: 61532
			[Token(Token = "0x400F05C")]
			[FieldOffset(Offset = "0x20")]
			private Action<ConnectionResponse> mResponseCallback;

			// Token: 0x0400F05D RID: 61533
			[Token(Token = "0x400F05D")]
			[FieldOffset(Offset = "0x28")]
			private IMessageListener mListener;

			// Token: 0x0400F05E RID: 61534
			[Token(Token = "0x400F05E")]
			[FieldOffset(Offset = "0x30")]
			private AndroidJavaObject mClient;
		}

		// Token: 0x02002643 RID: 9795
		[Token(Token = "0x2002643")]
		private class EndpointDiscoveryCallback : AndroidJavaProxy
		{
			// Token: 0x0601315E RID: 78174 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601315E")]
			[Address(RVA = "0x24D22B4", Offset = "0x24D22B4", VA = "0x24D22B4")]
			public EndpointDiscoveryCallback(IDiscoveryListener listener)
			{
			}

			// Token: 0x0601315F RID: 78175 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601315F")]
			[Address(RVA = "0x24D2340", Offset = "0x24D2340", VA = "0x24D2340")]
			public void onEndpointFound(string endpointId, AndroidJavaObject endpointInfo)
			{
			}

			// Token: 0x06013160 RID: 78176 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013160")]
			[Address(RVA = "0x24D25A8", Offset = "0x24D25A8", VA = "0x24D25A8")]
			public void onEndpointLost(string endpointId)
			{
			}

			// Token: 0x06013161 RID: 78177 RVA: 0x0007B150 File Offset: 0x00079350
			[Token(Token = "0x6013161")]
			[Address(RVA = "0x24D2444", Offset = "0x24D2444", VA = "0x24D2444")]
			private EndpointDetails CreateEndPointDetails(string endpointId, AndroidJavaObject endpointInfo)
			{
				return default(EndpointDetails);
			}

			// Token: 0x0400F05F RID: 61535
			[Token(Token = "0x400F05F")]
			[FieldOffset(Offset = "0x20")]
			private IDiscoveryListener mListener;
		}
	}
}
