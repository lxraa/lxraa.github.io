﻿using System;
using GooglePlayGames.BasicApi;
using GooglePlayGames.BasicApi.Events;
using GooglePlayGames.BasicApi.SavedGame;
using GooglePlayGames.BasicApi.Video;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.SocialPlatforms;

namespace GooglePlayGames.Android
{
	// Token: 0x02002633 RID: 9779
	[Token(Token = "0x2002633")]
	public class AndroidClient : IPlayGamesClient
	{
		// Token: 0x06013128 RID: 78120 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013128")]
		[Address(RVA = "0x24CAC3C", Offset = "0x24CAC3C", VA = "0x24CAC3C")]
		internal AndroidClient(PlayGamesClientConfiguration configuration)
		{
		}

		// Token: 0x06013129 RID: 78121 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013129")]
		[Address(RVA = "0x24CAFB0", Offset = "0x24CAFB0", VA = "0x24CAFB0", Slot = "4")]
		public void Authenticate(bool silent, Action<SignInStatus> callback)
		{
		}

		// Token: 0x0601312A RID: 78122 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601312A")]
		[Address(RVA = "0x24CB670", Offset = "0x24CB670", VA = "0x24CB670")]
		private static void InvokeCallbackOnGameThread(Action callback)
		{
		}

		// Token: 0x0601312B RID: 78123 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601312B")]
		private static void InvokeCallbackOnGameThread<T>(Action<T> callback, T data)
		{
		}

		// Token: 0x0601312C RID: 78124 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601312C")]
		[Address(RVA = "0x24CB76C", Offset = "0x24CB76C", VA = "0x24CB76C")]
		private void InitializeGameServices()
		{
		}

		// Token: 0x0601312D RID: 78125 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601312D")]
		[Address(RVA = "0x24CB258", Offset = "0x24CB258", VA = "0x24CB258")]
		private void InitializeTokenClient()
		{
		}

		// Token: 0x0601312E RID: 78126 RVA: 0x0007B120 File Offset: 0x00079320
		[Token(Token = "0x601312E")]
		[Address(RVA = "0x24CB87C", Offset = "0x24CB87C", VA = "0x24CB87C", Slot = "5")]
		public bool IsAuthenticated()
		{
			return default(bool);
		}

		// Token: 0x0601312F RID: 78127 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601312F")]
		[Address(RVA = "0x24CB94C", Offset = "0x24CB94C", VA = "0x24CB94C", Slot = "9")]
		public void SignOut()
		{
		}

		// Token: 0x06013130 RID: 78128 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013130")]
		[Address(RVA = "0x24CB954", Offset = "0x24CB954", VA = "0x24CB954")]
		public void SignOut(Action uiCallback)
		{
		}

		// Token: 0x06013131 RID: 78129 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013131")]
		[Address(RVA = "0x24CBC1C", Offset = "0x24CBC1C", VA = "0x24CBC1C", Slot = "6")]
		public string GetUserId()
		{
			return null;
		}

		// Token: 0x06013132 RID: 78130 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013132")]
		[Address(RVA = "0x24CBC5C", Offset = "0x24CBC5C", VA = "0x24CBC5C", Slot = "7")]
		public string GetUserDisplayName()
		{
			return null;
		}

		// Token: 0x06013133 RID: 78131 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013133")]
		[Address(RVA = "0x24CBC9C", Offset = "0x24CBC9C", VA = "0x24CBC9C", Slot = "8")]
		public string GetUserImageUrl()
		{
			return null;
		}

		// Token: 0x06013134 RID: 78132 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013134")]
		[Address(RVA = "0x24CBCDC", Offset = "0x24CBCDC", VA = "0x24CBCDC", Slot = "10")]
		public void LoadAchievements(Action<Achievement[]> callback)
		{
		}

		// Token: 0x06013135 RID: 78133 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013135")]
		[Address(RVA = "0x24CC28C", Offset = "0x24CC28C", VA = "0x24CC28C")]
		private void AddOnFailureListenerWithSignOut(AndroidJavaObject task, Action<AndroidJavaObject> callback)
		{
		}

		// Token: 0x06013136 RID: 78134 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013136")]
		[Address(RVA = "0x24CC160", Offset = "0x24CC160", VA = "0x24CC160")]
		private AndroidJavaObject getAchievementsClient()
		{
			return null;
		}

		// Token: 0x06013137 RID: 78135 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013137")]
		[Address(RVA = "0x24CC6D4", Offset = "0x24CC6D4", VA = "0x24CC6D4")]
		private AndroidJavaObject getGamesClient()
		{
			return null;
		}

		// Token: 0x06013138 RID: 78136 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013138")]
		[Address(RVA = "0x24CC800", Offset = "0x24CC800", VA = "0x24CC800")]
		private AndroidJavaObject getPlayersClient()
		{
			return null;
		}

		// Token: 0x06013139 RID: 78137 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013139")]
		[Address(RVA = "0x24CC92C", Offset = "0x24CC92C", VA = "0x24CC92C")]
		private AndroidJavaObject getVideosClient()
		{
			return null;
		}

		// Token: 0x0400F033 RID: 61491
		[Token(Token = "0x400F033")]
		[FieldOffset(Offset = "0x10")]
		private readonly object GameServicesLock;

		// Token: 0x0400F034 RID: 61492
		[Token(Token = "0x400F034")]
		[FieldOffset(Offset = "0x18")]
		private readonly object AuthStateLock;

		// Token: 0x0400F035 RID: 61493
		[Token(Token = "0x400F035")]
		[FieldOffset(Offset = "0x20")]
		private readonly PlayGamesClientConfiguration mConfiguration;

		// Token: 0x0400F036 RID: 61494
		[Token(Token = "0x400F036")]
		[FieldOffset(Offset = "0x40")]
		private ISavedGameClient mSavedGameClient;

		// Token: 0x0400F037 RID: 61495
		[Token(Token = "0x400F037")]
		[FieldOffset(Offset = "0x48")]
		private IEventsClient mEventsClient;

		// Token: 0x0400F038 RID: 61496
		[Token(Token = "0x400F038")]
		[FieldOffset(Offset = "0x50")]
		private IVideoClient mVideoClient;

		// Token: 0x0400F039 RID: 61497
		[Token(Token = "0x400F039")]
		[FieldOffset(Offset = "0x58")]
		private AndroidTokenClient mTokenClient;

		// Token: 0x0400F03A RID: 61498
		[Token(Token = "0x400F03A")]
		[FieldOffset(Offset = "0x60")]
		private Player mUser;

		// Token: 0x0400F03B RID: 61499
		[Token(Token = "0x400F03B")]
		[FieldOffset(Offset = "0x68")]
		private AndroidClient.AuthState mAuthState;

		// Token: 0x0400F03C RID: 61500
		[Token(Token = "0x400F03C")]
		[FieldOffset(Offset = "0x70")]
		private IUserProfile[] mFriends;

		// Token: 0x0400F03D RID: 61501
		[Token(Token = "0x400F03D")]
		[FieldOffset(Offset = "0x78")]
		private AndroidJavaClass mGamesClass;

		// Token: 0x0400F03E RID: 61502
		[Token(Token = "0x400F03E")]
		[FieldOffset(Offset = "0x0")]
		private static string TasksClassName;

		// Token: 0x0400F03F RID: 61503
		[Token(Token = "0x400F03F")]
		[FieldOffset(Offset = "0x80")]
		private readonly int mLeaderboardMaxResults;

		// Token: 0x0400F040 RID: 61504
		[Token(Token = "0x400F040")]
		[FieldOffset(Offset = "0x84")]
		private readonly int mFriendsMaxResults;

		// Token: 0x02002634 RID: 9780
		[Token(Token = "0x2002634")]
		private enum AuthState
		{
			// Token: 0x0400F042 RID: 61506
			[Token(Token = "0x400F042")]
			Unauthenticated,
			// Token: 0x0400F043 RID: 61507
			[Token(Token = "0x400F043")]
			Authenticated
		}

		// Token: 0x02002635 RID: 9781
		[Token(Token = "0x2002635")]
		private sealed class <>c__DisplayClass18_0
		{
			// Token: 0x0601313B RID: 78139 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601313B")]
			[Address(RVA = "0x24CB250", Offset = "0x24CB250", VA = "0x24CB250")]
			public <>c__DisplayClass18_0()
			{
			}

			// Token: 0x0601313C RID: 78140 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601313C")]
			[Address(RVA = "0x24CCAC4", Offset = "0x24CCAC4", VA = "0x24CCAC4")]
			internal void <Authenticate>b__0(int result)
			{
			}

			// Token: 0x0400F044 RID: 61508
			[Token(Token = "0x400F044")]
			[FieldOffset(Offset = "0x10")]
			public AndroidClient <>4__this;

			// Token: 0x0400F045 RID: 61509
			[Token(Token = "0x400F045")]
			[FieldOffset(Offset = "0x18")]
			public Action<SignInStatus> callback;
		}

		// Token: 0x02002636 RID: 9782
		[Token(Token = "0x2002636")]
		private sealed class <>c__DisplayClass18_1
		{
			// Token: 0x0601313D RID: 78141 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601313D")]
			[Address(RVA = "0x24CD8C4", Offset = "0x24CD8C4", VA = "0x24CD8C4")]
			public <>c__DisplayClass18_1()
			{
			}

			// Token: 0x0601313E RID: 78142 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601313E")]
			[Address(RVA = "0x24CDE14", Offset = "0x24CDE14", VA = "0x24CDE14")]
			internal void <Authenticate>b__1(AndroidJavaObject completeTask)
			{
			}

			// Token: 0x0400F046 RID: 61510
			[Token(Token = "0x400F046")]
			[FieldOffset(Offset = "0x10")]
			public AndroidJavaObject taskGetPlayer;

			// Token: 0x0400F047 RID: 61511
			[Token(Token = "0x400F047")]
			[FieldOffset(Offset = "0x18")]
			public AndroidJavaObject taskIsCaptureSupported;

			// Token: 0x0400F048 RID: 61512
			[Token(Token = "0x400F048")]
			[FieldOffset(Offset = "0x20")]
			public AndroidClient.<>c__DisplayClass18_0 CS$<>8__locals1;
		}

		// Token: 0x02002637 RID: 9783
		[Token(Token = "0x2002637")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06013140 RID: 78144 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013140")]
			[Address(RVA = "0x24CF494", Offset = "0x24CF494", VA = "0x24CF494")]
			public <>c()
			{
			}

			// Token: 0x06013141 RID: 78145 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013141")]
			[Address(RVA = "0x24CF49C", Offset = "0x24CF49C", VA = "0x24CF49C")]
			internal void <Authenticate>b__18_2(Achievement[] ignore)
			{
			}

			// Token: 0x06013142 RID: 78146 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013142")]
			[Address(RVA = "0x24CF4A0", Offset = "0x24CF4A0", VA = "0x24CF4A0")]
			internal void <SignOut>b__42_0()
			{
			}

			// Token: 0x0400F049 RID: 61513
			[Token(Token = "0x400F049")]
			[FieldOffset(Offset = "0x0")]
			public static readonly AndroidClient.<>c <>9;

			// Token: 0x0400F04A RID: 61514
			[Token(Token = "0x400F04A")]
			[FieldOffset(Offset = "0x8")]
			public static Action<Achievement[]> <>9__18_2;

			// Token: 0x0400F04B RID: 61515
			[Token(Token = "0x400F04B")]
			[FieldOffset(Offset = "0x10")]
			public static Action <>9__42_0;
		}

		// Token: 0x02002638 RID: 9784
		[Token(Token = "0x2002638")]
		private sealed class <>c__DisplayClass20_0
		{
			// Token: 0x06013143 RID: 78147 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013143")]
			[Address(RVA = "0x24CB764", Offset = "0x24CB764", VA = "0x24CB764")]
			public <>c__DisplayClass20_0()
			{
			}

			// Token: 0x06013144 RID: 78148 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013144")]
			[Address(RVA = "0x24CF4F0", Offset = "0x24CF4F0", VA = "0x24CF4F0")]
			internal void <InvokeCallbackOnGameThread>b__0()
			{
			}

			// Token: 0x0400F04C RID: 61516
			[Token(Token = "0x400F04C")]
			[FieldOffset(Offset = "0x10")]
			public Action callback;
		}

		// Token: 0x02002639 RID: 9785
		[Token(Token = "0x2002639")]
		private sealed class <>c__DisplayClass21_0<T>
		{
			// Token: 0x06013145 RID: 78149 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013145")]
			public <>c__DisplayClass21_0()
			{
			}

			// Token: 0x06013146 RID: 78150 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013146")]
			internal void <InvokeCallbackOnGameThread>b__0()
			{
			}

			// Token: 0x0400F04D RID: 61517
			[Token(Token = "0x400F04D")]
			[FieldOffset(Offset = "0x0")]
			public Action<T> callback;

			// Token: 0x0400F04E RID: 61518
			[Token(Token = "0x400F04E")]
			[FieldOffset(Offset = "0x0")]
			public T data;
		}

		// Token: 0x0200263A RID: 9786
		[Token(Token = "0x200263A")]
		private sealed class <>c__DisplayClass49_0
		{
			// Token: 0x06013147 RID: 78151 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013147")]
			[Address(RVA = "0x24CC158", Offset = "0x24CC158", VA = "0x24CC158")]
			public <>c__DisplayClass49_0()
			{
			}

			// Token: 0x06013148 RID: 78152 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013148")]
			[Address(RVA = "0x24CF514", Offset = "0x24CF514", VA = "0x24CF514")]
			internal void <LoadAchievements>b__0(AndroidJavaObject annotatedData)
			{
			}

			// Token: 0x06013149 RID: 78153 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013149")]
			[Address(RVA = "0x24D028C", Offset = "0x24D028C", VA = "0x24D028C")]
			internal void <LoadAchievements>b__1(AndroidJavaObject exception)
			{
			}

			// Token: 0x0400F04F RID: 61519
			[Token(Token = "0x400F04F")]
			[FieldOffset(Offset = "0x10")]
			public Action<Achievement[]> callback;
		}

		// Token: 0x0200263B RID: 9787
		[Token(Token = "0x200263B")]
		private sealed class <>c__DisplayClass57_0
		{
			// Token: 0x0601314A RID: 78154 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601314A")]
			[Address(RVA = "0x24CC368", Offset = "0x24CC368", VA = "0x24CC368")]
			public <>c__DisplayClass57_0()
			{
			}

			// Token: 0x0601314B RID: 78155 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601314B")]
			[Address(RVA = "0x24D0430", Offset = "0x24D0430", VA = "0x24D0430")]
			internal void <AddOnFailureListenerWithSignOut>b__0(AndroidJavaObject exception)
			{
			}

			// Token: 0x0400F050 RID: 61520
			[Token(Token = "0x400F050")]
			[FieldOffset(Offset = "0x10")]
			public AndroidClient <>4__this;

			// Token: 0x0400F051 RID: 61521
			[Token(Token = "0x400F051")]
			[FieldOffset(Offset = "0x18")]
			public Action<AndroidJavaObject> callback;
		}
	}
}
