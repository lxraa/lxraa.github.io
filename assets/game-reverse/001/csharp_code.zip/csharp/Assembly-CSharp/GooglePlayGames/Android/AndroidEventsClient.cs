﻿using System;
using GooglePlayGames.BasicApi.Events;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.Android
{
	// Token: 0x0200263C RID: 9788
	[Token(Token = "0x200263C")]
	internal class AndroidEventsClient : IEventsClient
	{
		// Token: 0x0601314C RID: 78156 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601314C")]
		[Address(RVA = "0x24CEE94", Offset = "0x24CEE94", VA = "0x24CEE94")]
		public AndroidEventsClient(AndroidJavaObject account)
		{
		}

		// Token: 0x0400F052 RID: 61522
		[Token(Token = "0x400F052")]
		[FieldOffset(Offset = "0x10")]
		private AndroidJavaObject mEventsClient;
	}
}
