﻿using System;
using GooglePlayGames.BasicApi;
using Il2CppDummyDll;
using UnityEngine.SocialPlatforms;

namespace GooglePlayGames
{
	// Token: 0x0200262C RID: 9772
	[Token(Token = "0x200262C")]
	public class PlayGamesLocalUser : PlayGamesUserProfile, IUserProfile
	{
		// Token: 0x06013106 RID: 78086 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013106")]
		[Address(RVA = "0x24C8BC8", Offset = "0x24C8BC8", VA = "0x24C8BC8")]
		internal PlayGamesLocalUser(PlayGamesPlatform plaf)
		{
		}

		// Token: 0x17002825 RID: 10277
		// (get) Token: 0x06013107 RID: 78087 RVA: 0x0007B0C0 File Offset: 0x000792C0
		[Token(Token = "0x17002825")]
		public bool authenticated
		{
			[Token(Token = "0x6013107")]
			[Address(RVA = "0x24C8CD8", Offset = "0x24C8CD8", VA = "0x24C8CD8", Slot = "6")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17002826 RID: 10278
		// (get) Token: 0x06013108 RID: 78088 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002826")]
		public new string userName
		{
			[Token(Token = "0x6013108")]
			[Address(RVA = "0x24C8DA0", Offset = "0x24C8DA0", VA = "0x24C8DA0", Slot = "7")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002827 RID: 10279
		// (get) Token: 0x06013109 RID: 78089 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002827")]
		public new string id
		{
			[Token(Token = "0x6013109")]
			[Address(RVA = "0x24C9214", Offset = "0x24C9214", VA = "0x24C9214", Slot = "8")]
			get
			{
				return null;
			}
		}

		// Token: 0x0400F01F RID: 61471
		[Token(Token = "0x400F01F")]
		[FieldOffset(Offset = "0x38")]
		internal PlayGamesPlatform mPlatform;

		// Token: 0x0400F020 RID: 61472
		[Token(Token = "0x400F020")]
		[FieldOffset(Offset = "0x40")]
		private string emailAddress;

		// Token: 0x0400F021 RID: 61473
		[Token(Token = "0x400F021")]
		[FieldOffset(Offset = "0x48")]
		private PlayerStats mStats;
	}
}
