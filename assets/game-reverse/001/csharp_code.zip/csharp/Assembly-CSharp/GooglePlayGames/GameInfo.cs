﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames
{
	// Token: 0x0200262B RID: 9771
	[Token(Token = "0x200262B")]
	public static class GameInfo
	{
		// Token: 0x06013104 RID: 78084 RVA: 0x0007B0A8 File Offset: 0x000792A8
		[Token(Token = "0x6013104")]
		[Address(RVA = "0x24C8AE8", Offset = "0x24C8AE8", VA = "0x24C8AE8")]
		public static bool WebClientIdInitialized()
		{
			return default(bool);
		}

		// Token: 0x06013105 RID: 78085 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013105")]
		[Address(RVA = "0x24C8B7C", Offset = "0x24C8B7C", VA = "0x24C8B7C")]
		private static string ToEscapedToken(string token)
		{
			return null;
		}
	}
}
