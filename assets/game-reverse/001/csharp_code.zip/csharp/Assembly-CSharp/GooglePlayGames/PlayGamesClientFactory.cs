﻿using System;
using GooglePlayGames.BasicApi;
using Il2CppDummyDll;

namespace GooglePlayGames
{
	// Token: 0x02002632 RID: 9778
	[Token(Token = "0x2002632")]
	internal class PlayGamesClientFactory
	{
		// Token: 0x06013127 RID: 78119 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013127")]
		[Address(RVA = "0x24C9E24", Offset = "0x24C9E24", VA = "0x24C9E24")]
		internal static IPlayGamesClient GetPlatformPlayGamesClient(PlayGamesClientConfiguration config)
		{
			return null;
		}
	}
}
