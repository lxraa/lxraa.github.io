﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.SocialPlatforms;

namespace GooglePlayGames
{
	// Token: 0x02002631 RID: 9777
	[Token(Token = "0x2002631")]
	public class PlayGamesUserProfile : IUserProfile
	{
		// Token: 0x0601311E RID: 78110 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601311E")]
		[Address(RVA = "0x24C8C70", Offset = "0x24C8C70", VA = "0x24C8C70")]
		internal PlayGamesUserProfile(string displayName, string playerId, string avatarUrl)
		{
		}

		// Token: 0x0601311F RID: 78111 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601311F")]
		[Address(RVA = "0x24C9194", Offset = "0x24C9194", VA = "0x24C9194")]
		protected void ResetIdentity(string displayName, string playerId, string avatarUrl)
		{
		}

		// Token: 0x17002829 RID: 10281
		// (get) Token: 0x06013120 RID: 78112 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002829")]
		public string userName
		{
			[Token(Token = "0x6013120")]
			[Address(RVA = "0x24CAA00", Offset = "0x24CAA00", VA = "0x24CAA00", Slot = "4")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700282A RID: 10282
		// (get) Token: 0x06013121 RID: 78113 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700282A")]
		public string id
		{
			[Token(Token = "0x6013121")]
			[Address(RVA = "0x24CAA08", Offset = "0x24CAA08", VA = "0x24CAA08", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700282B RID: 10283
		// (get) Token: 0x06013122 RID: 78114 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700282B")]
		public string AvatarURL
		{
			[Token(Token = "0x6013122")]
			[Address(RVA = "0x24CAA10", Offset = "0x24CAA10", VA = "0x24CAA10")]
			get
			{
				return null;
			}
		}

		// Token: 0x06013123 RID: 78115 RVA: 0x0007B0F0 File Offset: 0x000792F0
		[Token(Token = "0x6013123")]
		[Address(RVA = "0x24CAA18", Offset = "0x24CAA18", VA = "0x24CAA18", Slot = "0")]
		public override bool Equals(object obj)
		{
			return default(bool);
		}

		// Token: 0x06013124 RID: 78116 RVA: 0x0007B108 File Offset: 0x00079308
		[Token(Token = "0x6013124")]
		[Address(RVA = "0x24CAB38", Offset = "0x24CAB38", VA = "0x24CAB38", Slot = "2")]
		public override int GetHashCode()
		{
			return 0;
		}

		// Token: 0x06013125 RID: 78117 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013125")]
		[Address(RVA = "0x24CABE8", Offset = "0x24CABE8", VA = "0x24CABE8", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x06013126 RID: 78118 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013126")]
		[Address(RVA = "0x24CA928", Offset = "0x24CA928", VA = "0x24CA928")]
		private void setAvatarUrl(string avatarUrl)
		{
		}

		// Token: 0x0400F02D RID: 61485
		[Token(Token = "0x400F02D")]
		[FieldOffset(Offset = "0x10")]
		private string mDisplayName;

		// Token: 0x0400F02E RID: 61486
		[Token(Token = "0x400F02E")]
		[FieldOffset(Offset = "0x18")]
		private string mPlayerId;

		// Token: 0x0400F02F RID: 61487
		[Token(Token = "0x400F02F")]
		[FieldOffset(Offset = "0x20")]
		private string mAvatarUrl;

		// Token: 0x0400F030 RID: 61488
		[Token(Token = "0x400F030")]
		[FieldOffset(Offset = "0x28")]
		private bool mIsFriend;

		// Token: 0x0400F031 RID: 61489
		[Token(Token = "0x400F031")]
		[FieldOffset(Offset = "0x29")]
		private bool mImageLoading;

		// Token: 0x0400F032 RID: 61490
		[Token(Token = "0x400F032")]
		[FieldOffset(Offset = "0x30")]
		private Texture2D mImage;
	}
}
