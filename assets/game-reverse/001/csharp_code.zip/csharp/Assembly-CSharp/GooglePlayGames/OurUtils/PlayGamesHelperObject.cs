﻿using System;
using System.Collections;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.OurUtils
{
	// Token: 0x02002658 RID: 9816
	[Token(Token = "0x2002658")]
	public class PlayGamesHelperObject : MonoBehaviour
	{
		// Token: 0x0601319F RID: 78239 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601319F")]
		[Address(RVA = "0x24CADF4", Offset = "0x24CADF4", VA = "0x24CADF4")]
		public static void CreateObject()
		{
		}

		// Token: 0x060131A0 RID: 78240 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A0")]
		[Address(RVA = "0x24D49B8", Offset = "0x24D49B8", VA = "0x24D49B8")]
		public void Awake()
		{
		}

		// Token: 0x060131A1 RID: 78241 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A1")]
		[Address(RVA = "0x24D4A24", Offset = "0x24D4A24", VA = "0x24D4A24")]
		public void OnDisable()
		{
		}

		// Token: 0x060131A2 RID: 78242 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A2")]
		[Address(RVA = "0x24D4AF0", Offset = "0x24D4AF0", VA = "0x24D4AF0")]
		public static void RunCoroutine(IEnumerator action)
		{
		}

		// Token: 0x060131A3 RID: 78243 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A3")]
		[Address(RVA = "0x24C9F40", Offset = "0x24C9F40", VA = "0x24C9F40")]
		public static void RunOnGameThread(Action action)
		{
		}

		// Token: 0x060131A4 RID: 78244 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A4")]
		[Address(RVA = "0x24D4C44", Offset = "0x24D4C44", VA = "0x24D4C44")]
		public void Update()
		{
		}

		// Token: 0x060131A5 RID: 78245 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A5")]
		[Address(RVA = "0x24D4EC0", Offset = "0x24D4EC0", VA = "0x24D4EC0")]
		public void OnApplicationFocus(bool focused)
		{
		}

		// Token: 0x060131A6 RID: 78246 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A6")]
		[Address(RVA = "0x24D519C", Offset = "0x24D519C", VA = "0x24D519C")]
		public void OnApplicationPause(bool paused)
		{
		}

		// Token: 0x060131A7 RID: 78247 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A7")]
		[Address(RVA = "0x24D5478", Offset = "0x24D5478", VA = "0x24D5478")]
		public static void AddFocusCallback(Action<bool> callback)
		{
		}

		// Token: 0x060131A8 RID: 78248 RVA: 0x0007B198 File Offset: 0x00079398
		[Token(Token = "0x60131A8")]
		[Address(RVA = "0x24D55A0", Offset = "0x24D55A0", VA = "0x24D55A0")]
		public static bool RemoveFocusCallback(Action<bool> callback)
		{
			return default(bool);
		}

		// Token: 0x060131A9 RID: 78249 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131A9")]
		[Address(RVA = "0x24D5620", Offset = "0x24D5620", VA = "0x24D5620")]
		public static void AddPauseCallback(Action<bool> callback)
		{
		}

		// Token: 0x060131AA RID: 78250 RVA: 0x0007B1B0 File Offset: 0x000793B0
		[Token(Token = "0x60131AA")]
		[Address(RVA = "0x24D5748", Offset = "0x24D5748", VA = "0x24D5748")]
		public static bool RemovePauseCallback(Action<bool> callback)
		{
			return default(bool);
		}

		// Token: 0x060131AB RID: 78251 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131AB")]
		[Address(RVA = "0x24D4930", Offset = "0x24D4930", VA = "0x24D4930")]
		public PlayGamesHelperObject()
		{
		}

		// Token: 0x0400F08B RID: 61579
		[Token(Token = "0x400F08B")]
		[FieldOffset(Offset = "0x0")]
		private static PlayGamesHelperObject instance;

		// Token: 0x0400F08C RID: 61580
		[Token(Token = "0x400F08C")]
		[FieldOffset(Offset = "0x8")]
		private static bool sIsDummy;

		// Token: 0x0400F08D RID: 61581
		[Token(Token = "0x400F08D")]
		[FieldOffset(Offset = "0x10")]
		private static List<Action> sQueue;

		// Token: 0x0400F08E RID: 61582
		[Token(Token = "0x400F08E")]
		[FieldOffset(Offset = "0x18")]
		private List<Action> localQueue;

		// Token: 0x0400F08F RID: 61583
		[Token(Token = "0x400F08F")]
		[FieldOffset(Offset = "0x18")]
		private static bool sQueueEmpty;

		// Token: 0x0400F090 RID: 61584
		[Token(Token = "0x400F090")]
		[FieldOffset(Offset = "0x20")]
		private static List<Action<bool>> sPauseCallbackList;

		// Token: 0x0400F091 RID: 61585
		[Token(Token = "0x400F091")]
		[FieldOffset(Offset = "0x28")]
		private static List<Action<bool>> sFocusCallbackList;

		// Token: 0x02002659 RID: 9817
		[Token(Token = "0x2002659")]
		private sealed class <>c__DisplayClass10_0
		{
			// Token: 0x060131AD RID: 78253 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60131AD")]
			[Address(RVA = "0x24D4C3C", Offset = "0x24D4C3C", VA = "0x24D4C3C")]
			public <>c__DisplayClass10_0()
			{
			}

			// Token: 0x060131AE RID: 78254 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60131AE")]
			[Address(RVA = "0x24D591C", Offset = "0x24D591C", VA = "0x24D591C")]
			internal void <RunCoroutine>b__0()
			{
			}

			// Token: 0x0400F092 RID: 61586
			[Token(Token = "0x400F092")]
			[FieldOffset(Offset = "0x10")]
			public IEnumerator action;
		}
	}
}
