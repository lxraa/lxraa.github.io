﻿using System;
using GooglePlayGames.BasicApi.Nearby;
using Il2CppDummyDll;
using UnityEngine;

namespace GooglePlayGames.OurUtils
{
	// Token: 0x02002657 RID: 9815
	[Token(Token = "0x2002657")]
	public class NearbyHelperObject : MonoBehaviour
	{
		// Token: 0x06013197 RID: 78231 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013197")]
		[Address(RVA = "0x24D4304", Offset = "0x24D4304", VA = "0x24D4304")]
		public static void CreateObject(INearbyConnectionClient client)
		{
		}

		// Token: 0x06013198 RID: 78232 RVA: 0x0007B180 File Offset: 0x00079380
		[Token(Token = "0x6013198")]
		[Address(RVA = "0x24D4490", Offset = "0x24D4490", VA = "0x24D4490")]
		private static double ToSeconds(TimeSpan? span)
		{
			return 0.0;
		}

		// Token: 0x06013199 RID: 78233 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013199")]
		[Address(RVA = "0x24D4548", Offset = "0x24D4548", VA = "0x24D4548")]
		public static void StartAdvertisingTimer(TimeSpan? span)
		{
		}

		// Token: 0x0601319A RID: 78234 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601319A")]
		[Address(RVA = "0x24D45AC", Offset = "0x24D45AC", VA = "0x24D45AC")]
		public static void StartDiscoveryTimer(TimeSpan? span)
		{
		}

		// Token: 0x0601319B RID: 78235 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601319B")]
		[Address(RVA = "0x24D4610", Offset = "0x24D4610", VA = "0x24D4610")]
		public void Awake()
		{
		}

		// Token: 0x0601319C RID: 78236 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601319C")]
		[Address(RVA = "0x24D467C", Offset = "0x24D467C", VA = "0x24D467C")]
		public void OnDisable()
		{
		}

		// Token: 0x0601319D RID: 78237 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601319D")]
		[Address(RVA = "0x24D4730", Offset = "0x24D4730", VA = "0x24D4730")]
		public void Update()
		{
		}

		// Token: 0x0601319E RID: 78238 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601319E")]
		[Address(RVA = "0x24D4488", Offset = "0x24D4488", VA = "0x24D4488")]
		public NearbyHelperObject()
		{
		}

		// Token: 0x0400F087 RID: 61575
		[Token(Token = "0x400F087")]
		[FieldOffset(Offset = "0x0")]
		private static NearbyHelperObject instance;

		// Token: 0x0400F088 RID: 61576
		[Token(Token = "0x400F088")]
		[FieldOffset(Offset = "0x8")]
		private static double mAdvertisingRemaining;

		// Token: 0x0400F089 RID: 61577
		[Token(Token = "0x400F089")]
		[FieldOffset(Offset = "0x10")]
		private static double mDiscoveryRemaining;

		// Token: 0x0400F08A RID: 61578
		[Token(Token = "0x400F08A")]
		[FieldOffset(Offset = "0x18")]
		private static INearbyConnectionClient mClient;
	}
}
