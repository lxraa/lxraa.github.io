﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.OurUtils
{
	// Token: 0x02002651 RID: 9809
	[Token(Token = "0x2002651")]
	public class Logger
	{
		// Token: 0x06013188 RID: 78216 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013188")]
		[Address(RVA = "0x24C9404", Offset = "0x24C9404", VA = "0x24C9404")]
		public static void d(string msg)
		{
		}

		// Token: 0x06013189 RID: 78217 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013189")]
		[Address(RVA = "0x24C97F8", Offset = "0x24C97F8", VA = "0x24C97F8")]
		public static void w(string msg)
		{
		}

		// Token: 0x0601318A RID: 78218 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601318A")]
		[Address(RVA = "0x24CA154", Offset = "0x24CA154", VA = "0x24CA154")]
		public static void e(string msg)
		{
		}

		// Token: 0x0601318B RID: 78219 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601318B")]
		[Address(RVA = "0x24D3C38", Offset = "0x24D3C38", VA = "0x24D3C38")]
		private static string ToLogMessage(string prefix, string logType, string msg)
		{
			return null;
		}

		// Token: 0x0400F080 RID: 61568
		[Token(Token = "0x400F080")]
		[FieldOffset(Offset = "0x0")]
		private static bool debugLogEnabled;

		// Token: 0x0400F081 RID: 61569
		[Token(Token = "0x400F081")]
		[FieldOffset(Offset = "0x1")]
		private static bool warningLogEnabled;

		// Token: 0x02002652 RID: 9810
		[Token(Token = "0x2002652")]
		private sealed class <>c__DisplayClass8_0
		{
			// Token: 0x0601318D RID: 78221 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601318D")]
			[Address(RVA = "0x24D3C20", Offset = "0x24D3C20", VA = "0x24D3C20")]
			public <>c__DisplayClass8_0()
			{
			}

			// Token: 0x0601318E RID: 78222 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601318E")]
			[Address(RVA = "0x24D3FC0", Offset = "0x24D3FC0", VA = "0x24D3FC0")]
			internal void <d>b__0()
			{
			}

			// Token: 0x0400F082 RID: 61570
			[Token(Token = "0x400F082")]
			[FieldOffset(Offset = "0x10")]
			public string msg;
		}

		// Token: 0x02002653 RID: 9811
		[Token(Token = "0x2002653")]
		private sealed class <>c__DisplayClass9_0
		{
			// Token: 0x0601318F RID: 78223 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601318F")]
			[Address(RVA = "0x24D3C28", Offset = "0x24D3C28", VA = "0x24D3C28")]
			public <>c__DisplayClass9_0()
			{
			}

			// Token: 0x06013190 RID: 78224 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013190")]
			[Address(RVA = "0x24D4094", Offset = "0x24D4094", VA = "0x24D4094")]
			internal void <w>b__0()
			{
			}

			// Token: 0x0400F083 RID: 61571
			[Token(Token = "0x400F083")]
			[FieldOffset(Offset = "0x10")]
			public string msg;
		}

		// Token: 0x02002654 RID: 9812
		[Token(Token = "0x2002654")]
		private sealed class <>c__DisplayClass10_0
		{
			// Token: 0x06013191 RID: 78225 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013191")]
			[Address(RVA = "0x24D3C30", Offset = "0x24D3C30", VA = "0x24D3C30")]
			public <>c__DisplayClass10_0()
			{
			}

			// Token: 0x06013192 RID: 78226 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013192")]
			[Address(RVA = "0x24D415C", Offset = "0x24D415C", VA = "0x24D415C")]
			internal void <e>b__0()
			{
			}

			// Token: 0x0400F084 RID: 61572
			[Token(Token = "0x400F084")]
			[FieldOffset(Offset = "0x10")]
			public string msg;
		}

		// Token: 0x02002655 RID: 9813
		[Token(Token = "0x2002655")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06013194 RID: 78228 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013194")]
			[Address(RVA = "0x24D4294", Offset = "0x24D4294", VA = "0x24D4294")]
			public <>c()
			{
			}

			// Token: 0x06013195 RID: 78229 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013195")]
			[Address(RVA = "0x24D429C", Offset = "0x24D429C", VA = "0x24D429C")]
			internal void <ToLogMessage>b__12_0()
			{
			}

			// Token: 0x0400F085 RID: 61573
			[Token(Token = "0x400F085")]
			[FieldOffset(Offset = "0x0")]
			public static readonly Logger.<>c <>9;

			// Token: 0x0400F086 RID: 61574
			[Token(Token = "0x400F086")]
			[FieldOffset(Offset = "0x8")]
			public static Action <>9__12_0;
		}
	}
}
