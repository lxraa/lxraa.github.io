﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.OurUtils
{
	// Token: 0x02002656 RID: 9814
	[Token(Token = "0x2002656")]
	public static class Misc
	{
		// Token: 0x06013196 RID: 78230 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013196")]
		public static T CheckNotNull<T>(T value)
		{
			return null;
		}
	}
}
