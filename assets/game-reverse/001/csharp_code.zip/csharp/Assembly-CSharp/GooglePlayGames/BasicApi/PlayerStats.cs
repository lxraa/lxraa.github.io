﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02002660 RID: 9824
	[Token(Token = "0x2002660")]
	public class PlayerStats
	{
		// Token: 0x0400F0AF RID: 61615
		[Token(Token = "0x400F0AF")]
		[FieldOffset(Offset = "0x0")]
		private static float UNSET_VALUE;
	}
}
