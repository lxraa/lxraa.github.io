﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.SavedGame
{
	// Token: 0x02002668 RID: 9832
	[Token(Token = "0x2002668")]
	public interface ISavedGameClient
	{
	}
}
