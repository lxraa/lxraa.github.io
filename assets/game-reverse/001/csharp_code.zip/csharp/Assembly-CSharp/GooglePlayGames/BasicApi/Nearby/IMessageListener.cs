﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200266F RID: 9839
	[Token(Token = "0x200266F")]
	public interface IMessageListener
	{
		// Token: 0x060131F5 RID: 78325
		[Token(Token = "0x60131F5")]
		void OnMessageReceived(string remoteEndpointId, byte[] data, bool isReliableMessage);

		// Token: 0x060131F6 RID: 78326
		[Token(Token = "0x60131F6")]
		void OnRemoteEndpointDisconnected(string remoteEndpointId);
	}
}
