﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02002663 RID: 9827
	[Token(Token = "0x2002663")]
	public class SignInHelper
	{
		// Token: 0x060131E5 RID: 78309 RVA: 0x0007B390 File Offset: 0x00079590
		[Token(Token = "0x60131E5")]
		[Address(RVA = "0x24CDC50", Offset = "0x24CDC50", VA = "0x24CDC50")]
		public static SignInStatus ToSignInStatus(int code)
		{
			return SignInStatus.Success;
		}

		// Token: 0x060131E6 RID: 78310 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131E6")]
		[Address(RVA = "0x24CA7F4", Offset = "0x24CA7F4", VA = "0x24CA7F4")]
		public static void SetPromptUiSignIn(bool value)
		{
		}

		// Token: 0x060131E7 RID: 78311 RVA: 0x0007B3A8 File Offset: 0x000795A8
		[Token(Token = "0x60131E7")]
		[Address(RVA = "0x24CA6A0", Offset = "0x24CA6A0", VA = "0x24CA6A0")]
		public static bool ShouldPromptUiSignIn()
		{
			return default(bool);
		}

		// Token: 0x0400F0C1 RID: 61633
		[Token(Token = "0x400F0C1")]
		[FieldOffset(Offset = "0x0")]
		private static int True;

		// Token: 0x0400F0C2 RID: 61634
		[Token(Token = "0x400F0C2")]
		[FieldOffset(Offset = "0x4")]
		private static int False;
	}
}
