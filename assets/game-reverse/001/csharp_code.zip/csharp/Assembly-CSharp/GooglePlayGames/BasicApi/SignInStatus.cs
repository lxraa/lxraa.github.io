﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02002665 RID: 9829
	[Token(Token = "0x2002665")]
	public enum SignInStatus
	{
		// Token: 0x0400F0C8 RID: 61640
		[Token(Token = "0x400F0C8")]
		Success,
		// Token: 0x0400F0C9 RID: 61641
		[Token(Token = "0x400F0C9")]
		UiSignInRequired,
		// Token: 0x0400F0CA RID: 61642
		[Token(Token = "0x400F0CA")]
		DeveloperError,
		// Token: 0x0400F0CB RID: 61643
		[Token(Token = "0x400F0CB")]
		NetworkError,
		// Token: 0x0400F0CC RID: 61644
		[Token(Token = "0x400F0CC")]
		InternalError,
		// Token: 0x0400F0CD RID: 61645
		[Token(Token = "0x400F0CD")]
		Canceled,
		// Token: 0x0400F0CE RID: 61646
		[Token(Token = "0x400F0CE")]
		AlreadyInProgress,
		// Token: 0x0400F0CF RID: 61647
		[Token(Token = "0x400F0CF")]
		Failed,
		// Token: 0x0400F0D0 RID: 61648
		[Token(Token = "0x400F0D0")]
		NotAuthenticated
	}
}
