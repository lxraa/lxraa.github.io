﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200266A RID: 9834
	[Token(Token = "0x200266A")]
	public struct ConnectionRequest
	{
		// Token: 0x060131EB RID: 78315 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131EB")]
		[Address(RVA = "0x24D1108", Offset = "0x24D1108", VA = "0x24D1108")]
		public ConnectionRequest(string remoteEndpointId, string remoteEndpointName, string serviceId, byte[] payload)
		{
		}

		// Token: 0x0400F0D3 RID: 61651
		[Token(Token = "0x400F0D3")]
		[FieldOffset(Offset = "0x0")]
		private readonly EndpointDetails mRemoteEndpoint;

		// Token: 0x0400F0D4 RID: 61652
		[Token(Token = "0x400F0D4")]
		[FieldOffset(Offset = "0x18")]
		private readonly byte[] mPayload;
	}
}
