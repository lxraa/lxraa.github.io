﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200265B RID: 9819
	[Token(Token = "0x200265B")]
	public enum ResponseStatus
	{
		// Token: 0x0400F0A1 RID: 61601
		[Token(Token = "0x400F0A1")]
		Success = 1,
		// Token: 0x0400F0A2 RID: 61602
		[Token(Token = "0x400F0A2")]
		SuccessWithStale,
		// Token: 0x0400F0A3 RID: 61603
		[Token(Token = "0x400F0A3")]
		LicenseCheckFailed = -1,
		// Token: 0x0400F0A4 RID: 61604
		[Token(Token = "0x400F0A4")]
		InternalError = -2,
		// Token: 0x0400F0A5 RID: 61605
		[Token(Token = "0x400F0A5")]
		NotAuthorized = -3,
		// Token: 0x0400F0A6 RID: 61606
		[Token(Token = "0x400F0A6")]
		VersionUpdateRequired = -4,
		// Token: 0x0400F0A7 RID: 61607
		[Token(Token = "0x400F0A7")]
		Timeout = -5,
		// Token: 0x0400F0A8 RID: 61608
		[Token(Token = "0x400F0A8")]
		ResolutionRequired = -6
	}
}
