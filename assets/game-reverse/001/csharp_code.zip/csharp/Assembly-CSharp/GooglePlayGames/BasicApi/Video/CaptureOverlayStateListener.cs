﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Video
{
	// Token: 0x02002666 RID: 9830
	[Token(Token = "0x2002666")]
	public interface CaptureOverlayStateListener
	{
		// Token: 0x060131E9 RID: 78313
		[Token(Token = "0x60131E9")]
		void OnCaptureOverlayStateChanged(VideoCaptureOverlayState overlayState);
	}
}
