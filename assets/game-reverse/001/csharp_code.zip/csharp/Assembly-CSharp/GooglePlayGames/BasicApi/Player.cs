﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200265F RID: 9823
	[Token(Token = "0x200265F")]
	public class Player : PlayGamesUserProfile
	{
		// Token: 0x060131CB RID: 78283 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131CB")]
		[Address(RVA = "0x24D0538", Offset = "0x24D0538", VA = "0x24D0538")]
		internal Player(string displayName, string playerId, string avatarUrl)
		{
		}
	}
}
