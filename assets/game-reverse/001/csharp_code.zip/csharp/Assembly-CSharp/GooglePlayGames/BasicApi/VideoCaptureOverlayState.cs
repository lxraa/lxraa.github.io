﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200265C RID: 9820
	[Token(Token = "0x200265C")]
	public enum VideoCaptureOverlayState
	{
		// Token: 0x0400F0AA RID: 61610
		[Token(Token = "0x400F0AA")]
		Unknown = -1,
		// Token: 0x0400F0AB RID: 61611
		[Token(Token = "0x400F0AB")]
		Shown = 1,
		// Token: 0x0400F0AC RID: 61612
		[Token(Token = "0x400F0AC")]
		Started,
		// Token: 0x0400F0AD RID: 61613
		[Token(Token = "0x400F0AD")]
		Stopped,
		// Token: 0x0400F0AE RID: 61614
		[Token(Token = "0x400F0AE")]
		Dismissed
	}
}
