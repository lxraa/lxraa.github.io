﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200265D RID: 9821
	[Token(Token = "0x200265D")]
	public class DummyClient : IPlayGamesClient
	{
		// Token: 0x060131BF RID: 78271 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131BF")]
		[Address(RVA = "0x24D5D88", Offset = "0x24D5D88", VA = "0x24D5D88", Slot = "4")]
		public void Authenticate(bool silent, Action<SignInStatus> callback)
		{
		}

		// Token: 0x060131C0 RID: 78272 RVA: 0x0007B1E0 File Offset: 0x000793E0
		[Token(Token = "0x60131C0")]
		[Address(RVA = "0x24D5E1C", Offset = "0x24D5E1C", VA = "0x24D5E1C", Slot = "5")]
		public bool IsAuthenticated()
		{
			return default(bool);
		}

		// Token: 0x060131C1 RID: 78273 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60131C1")]
		[Address(RVA = "0x24D5E30", Offset = "0x24D5E30", VA = "0x24D5E30", Slot = "6")]
		public string GetUserId()
		{
			return null;
		}

		// Token: 0x060131C2 RID: 78274 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60131C2")]
		[Address(RVA = "0x24D5E74", Offset = "0x24D5E74", VA = "0x24D5E74", Slot = "7")]
		public string GetUserDisplayName()
		{
			return null;
		}

		// Token: 0x060131C3 RID: 78275 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60131C3")]
		[Address(RVA = "0x24D5EB8", Offset = "0x24D5EB8", VA = "0x24D5EB8", Slot = "8")]
		public string GetUserImageUrl()
		{
			return null;
		}

		// Token: 0x060131C4 RID: 78276 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131C4")]
		[Address(RVA = "0x24D5DB8", Offset = "0x24D5DB8", VA = "0x24D5DB8")]
		private static void LogUsage()
		{
		}

		// Token: 0x060131C5 RID: 78277 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131C5")]
		[Address(RVA = "0x24CAC34", Offset = "0x24CAC34", VA = "0x24CAC34")]
		public DummyClient()
		{
		}
	}
}
