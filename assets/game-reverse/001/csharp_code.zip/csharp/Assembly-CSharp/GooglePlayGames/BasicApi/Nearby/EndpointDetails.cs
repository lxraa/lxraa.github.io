﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200266D RID: 9837
	[Token(Token = "0x200266D")]
	public struct EndpointDetails
	{
		// Token: 0x060131F1 RID: 78321 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131F1")]
		[Address(RVA = "0x24D2654", Offset = "0x24D2654", VA = "0x24D2654")]
		public EndpointDetails(string endpointId, string name, string serviceId)
		{
		}

		// Token: 0x0400F0E1 RID: 61665
		[Token(Token = "0x400F0E1")]
		[FieldOffset(Offset = "0x0")]
		private readonly string mEndpointId;

		// Token: 0x0400F0E2 RID: 61666
		[Token(Token = "0x400F0E2")]
		[FieldOffset(Offset = "0x8")]
		private readonly string mName;

		// Token: 0x0400F0E3 RID: 61667
		[Token(Token = "0x400F0E3")]
		[FieldOffset(Offset = "0x10")]
		private readonly string mServiceId;
	}
}
