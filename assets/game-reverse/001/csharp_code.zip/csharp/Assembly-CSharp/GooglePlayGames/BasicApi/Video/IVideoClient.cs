﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Video
{
	// Token: 0x02002667 RID: 9831
	[Token(Token = "0x2002667")]
	public interface IVideoClient
	{
	}
}
