﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200266E RID: 9838
	[Token(Token = "0x200266E")]
	public interface INearbyConnectionClient
	{
		// Token: 0x060131F2 RID: 78322
		[Token(Token = "0x60131F2")]
		void StopAdvertising();

		// Token: 0x060131F3 RID: 78323
		[Token(Token = "0x60131F3")]
		void StopDiscovery(string serviceId);

		// Token: 0x060131F4 RID: 78324
		[Token(Token = "0x60131F4")]
		string GetServiceId();
	}
}
