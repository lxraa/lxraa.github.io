﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200265E RID: 9822
	[Token(Token = "0x200265E")]
	public interface IPlayGamesClient
	{
		// Token: 0x060131C6 RID: 78278
		[Token(Token = "0x60131C6")]
		void Authenticate(bool silent, Action<SignInStatus> callback);

		// Token: 0x060131C7 RID: 78279
		[Token(Token = "0x60131C7")]
		bool IsAuthenticated();

		// Token: 0x060131C8 RID: 78280
		[Token(Token = "0x60131C8")]
		string GetUserId();

		// Token: 0x060131C9 RID: 78281
		[Token(Token = "0x60131C9")]
		string GetUserDisplayName();

		// Token: 0x060131CA RID: 78282
		[Token(Token = "0x60131CA")]
		string GetUserImageUrl();
	}
}
