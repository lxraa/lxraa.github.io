﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02002664 RID: 9828
	[Token(Token = "0x2002664")]
	public enum SignInInteractivity
	{
		// Token: 0x0400F0C4 RID: 61636
		[Token(Token = "0x400F0C4")]
		NoPrompt,
		// Token: 0x0400F0C5 RID: 61637
		[Token(Token = "0x400F0C5")]
		CanPromptAlways,
		// Token: 0x0400F0C6 RID: 61638
		[Token(Token = "0x400F0C6")]
		CanPromptOnce
	}
}
