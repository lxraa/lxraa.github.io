﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Events
{
	// Token: 0x02002671 RID: 9841
	[Token(Token = "0x2002671")]
	public interface IEventsClient
	{
	}
}
