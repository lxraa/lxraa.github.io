﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x02002670 RID: 9840
	[Token(Token = "0x2002670")]
	public interface IDiscoveryListener
	{
		// Token: 0x060131F7 RID: 78327
		[Token(Token = "0x60131F7")]
		void OnEndpointFound(EndpointDetails discoveredEndpoint);

		// Token: 0x060131F8 RID: 78328
		[Token(Token = "0x60131F8")]
		void OnEndpointLost(string lostEndpointId);
	}
}
