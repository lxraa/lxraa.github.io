﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x0200266B RID: 9835
	[Token(Token = "0x200266B")]
	public struct ConnectionResponse
	{
		// Token: 0x060131EC RID: 78316 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131EC")]
		[Address(RVA = "0x24D6498", Offset = "0x24D6498", VA = "0x24D6498")]
		private ConnectionResponse(long localClientId, string remoteEndpointId, ConnectionResponse.Status code, byte[] payload)
		{
		}

		// Token: 0x060131ED RID: 78317 RVA: 0x0007B3C0 File Offset: 0x000795C0
		[Token(Token = "0x60131ED")]
		[Address(RVA = "0x24D2184", Offset = "0x24D2184", VA = "0x24D2184")]
		public static ConnectionResponse Rejected(long localClientId, string remoteEndpointId)
		{
			return default(ConnectionResponse);
		}

		// Token: 0x060131EE RID: 78318 RVA: 0x0007B3D8 File Offset: 0x000795D8
		[Token(Token = "0x60131EE")]
		[Address(RVA = "0x24D20E0", Offset = "0x24D20E0", VA = "0x24D20E0")]
		public static ConnectionResponse Accepted(long localClientId, string remoteEndpointId, byte[] payload)
		{
			return default(ConnectionResponse);
		}

		// Token: 0x060131EF RID: 78319 RVA: 0x0007B3F0 File Offset: 0x000795F0
		[Token(Token = "0x60131EF")]
		[Address(RVA = "0x24D2100", Offset = "0x24D2100", VA = "0x24D2100")]
		public static ConnectionResponse AlreadyConnected(long localClientId, string remoteEndpointId)
		{
			return default(ConnectionResponse);
		}

		// Token: 0x0400F0D5 RID: 61653
		[Token(Token = "0x400F0D5")]
		[FieldOffset(Offset = "0x0")]
		private static readonly byte[] EmptyPayload;

		// Token: 0x0400F0D6 RID: 61654
		[Token(Token = "0x400F0D6")]
		[FieldOffset(Offset = "0x0")]
		private readonly long mLocalClientId;

		// Token: 0x0400F0D7 RID: 61655
		[Token(Token = "0x400F0D7")]
		[FieldOffset(Offset = "0x8")]
		private readonly string mRemoteEndpointId;

		// Token: 0x0400F0D8 RID: 61656
		[Token(Token = "0x400F0D8")]
		[FieldOffset(Offset = "0x10")]
		private readonly ConnectionResponse.Status mResponseStatus;

		// Token: 0x0400F0D9 RID: 61657
		[Token(Token = "0x400F0D9")]
		[FieldOffset(Offset = "0x18")]
		private readonly byte[] mPayload;

		// Token: 0x0200266C RID: 9836
		[Token(Token = "0x200266C")]
		public enum Status
		{
			// Token: 0x0400F0DB RID: 61659
			[Token(Token = "0x400F0DB")]
			Accepted,
			// Token: 0x0400F0DC RID: 61660
			[Token(Token = "0x400F0DC")]
			Rejected,
			// Token: 0x0400F0DD RID: 61661
			[Token(Token = "0x400F0DD")]
			ErrorInternal,
			// Token: 0x0400F0DE RID: 61662
			[Token(Token = "0x400F0DE")]
			ErrorNetworkNotConnected,
			// Token: 0x0400F0DF RID: 61663
			[Token(Token = "0x400F0DF")]
			ErrorEndpointNotConnected,
			// Token: 0x0400F0E0 RID: 61664
			[Token(Token = "0x400F0E0")]
			ErrorAlreadyConnected
		}
	}
}
