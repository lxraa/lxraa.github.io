﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x0200265A RID: 9818
	[Token(Token = "0x200265A")]
	public class Achievement
	{
		// Token: 0x060131AF RID: 78255 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60131AF")]
		[Address(RVA = "0x24D5988", Offset = "0x24D5988", VA = "0x24D5988", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x060131B0 RID: 78256 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131B0")]
		[Address(RVA = "0x24D00DC", Offset = "0x24D00DC", VA = "0x24D00DC")]
		public Achievement()
		{
		}

		// Token: 0x1700282C RID: 10284
		// (get) Token: 0x060131B1 RID: 78257 RVA: 0x0007B1C8 File Offset: 0x000793C8
		// (set) Token: 0x060131B2 RID: 78258 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700282C")]
		public bool IsIncremental
		{
			[Token(Token = "0x60131B1")]
			[Address(RVA = "0x24D5C98", Offset = "0x24D5C98", VA = "0x24D5C98")]
			get
			{
				return default(bool);
			}
			[Token(Token = "0x60131B2")]
			[Address(RVA = "0x24D5CA0", Offset = "0x24D5CA0", VA = "0x24D5CA0")]
			set
			{
			}
		}

		// Token: 0x1700282D RID: 10285
		// (set) Token: 0x060131B3 RID: 78259 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700282D")]
		public int CurrentSteps
		{
			[Token(Token = "0x60131B3")]
			[Address(RVA = "0x24D5CAC", Offset = "0x24D5CAC", VA = "0x24D5CAC")]
			set
			{
			}
		}

		// Token: 0x1700282E RID: 10286
		// (set) Token: 0x060131B4 RID: 78260 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700282E")]
		public int TotalSteps
		{
			[Token(Token = "0x60131B4")]
			[Address(RVA = "0x24D5CB4", Offset = "0x24D5CB4", VA = "0x24D5CB4")]
			set
			{
			}
		}

		// Token: 0x1700282F RID: 10287
		// (set) Token: 0x060131B5 RID: 78261 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x1700282F")]
		public bool IsUnlocked
		{
			[Token(Token = "0x60131B5")]
			[Address(RVA = "0x24D5CBC", Offset = "0x24D5CBC", VA = "0x24D5CBC")]
			set
			{
			}
		}

		// Token: 0x17002830 RID: 10288
		// (set) Token: 0x060131B6 RID: 78262 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002830")]
		public bool IsRevealed
		{
			[Token(Token = "0x60131B6")]
			[Address(RVA = "0x24D5CC8", Offset = "0x24D5CC8", VA = "0x24D5CC8")]
			set
			{
			}
		}

		// Token: 0x17002831 RID: 10289
		// (set) Token: 0x060131B7 RID: 78263 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002831")]
		public string Id
		{
			[Token(Token = "0x60131B7")]
			[Address(RVA = "0x24D5CD4", Offset = "0x24D5CD4", VA = "0x24D5CD4")]
			set
			{
			}
		}

		// Token: 0x17002832 RID: 10290
		// (set) Token: 0x060131B8 RID: 78264 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002832")]
		public string Description
		{
			[Token(Token = "0x60131B8")]
			[Address(RVA = "0x24D5CDC", Offset = "0x24D5CDC", VA = "0x24D5CDC")]
			set
			{
			}
		}

		// Token: 0x17002833 RID: 10291
		// (set) Token: 0x060131B9 RID: 78265 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002833")]
		public string Name
		{
			[Token(Token = "0x60131B9")]
			[Address(RVA = "0x24D5CE4", Offset = "0x24D5CE4", VA = "0x24D5CE4")]
			set
			{
			}
		}

		// Token: 0x17002834 RID: 10292
		// (set) Token: 0x060131BA RID: 78266 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002834")]
		public DateTime LastModifiedTime
		{
			[Token(Token = "0x60131BA")]
			[Address(RVA = "0x24D01BC", Offset = "0x24D01BC", VA = "0x24D01BC")]
			set
			{
			}
		}

		// Token: 0x17002835 RID: 10293
		// (set) Token: 0x060131BB RID: 78267 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002835")]
		public ulong Points
		{
			[Token(Token = "0x60131BB")]
			[Address(RVA = "0x24D5CEC", Offset = "0x24D5CEC", VA = "0x24D5CEC")]
			set
			{
			}
		}

		// Token: 0x17002836 RID: 10294
		// (set) Token: 0x060131BC RID: 78268 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002836")]
		public string RevealedImageUrl
		{
			[Token(Token = "0x60131BC")]
			[Address(RVA = "0x24D5CF4", Offset = "0x24D5CF4", VA = "0x24D5CF4")]
			set
			{
			}
		}

		// Token: 0x17002837 RID: 10295
		// (set) Token: 0x060131BD RID: 78269 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002837")]
		public string UnlockedImageUrl
		{
			[Token(Token = "0x60131BD")]
			[Address(RVA = "0x24D5CFC", Offset = "0x24D5CFC", VA = "0x24D5CFC")]
			set
			{
			}
		}

		// Token: 0x0400F093 RID: 61587
		[Token(Token = "0x400F093")]
		[FieldOffset(Offset = "0x0")]
		private static readonly DateTime UnixEpoch;

		// Token: 0x0400F094 RID: 61588
		[Token(Token = "0x400F094")]
		[FieldOffset(Offset = "0x10")]
		private string mId;

		// Token: 0x0400F095 RID: 61589
		[Token(Token = "0x400F095")]
		[FieldOffset(Offset = "0x18")]
		private bool mIsIncremental;

		// Token: 0x0400F096 RID: 61590
		[Token(Token = "0x400F096")]
		[FieldOffset(Offset = "0x19")]
		private bool mIsRevealed;

		// Token: 0x0400F097 RID: 61591
		[Token(Token = "0x400F097")]
		[FieldOffset(Offset = "0x1A")]
		private bool mIsUnlocked;

		// Token: 0x0400F098 RID: 61592
		[Token(Token = "0x400F098")]
		[FieldOffset(Offset = "0x1C")]
		private int mCurrentSteps;

		// Token: 0x0400F099 RID: 61593
		[Token(Token = "0x400F099")]
		[FieldOffset(Offset = "0x20")]
		private int mTotalSteps;

		// Token: 0x0400F09A RID: 61594
		[Token(Token = "0x400F09A")]
		[FieldOffset(Offset = "0x28")]
		private string mDescription;

		// Token: 0x0400F09B RID: 61595
		[Token(Token = "0x400F09B")]
		[FieldOffset(Offset = "0x30")]
		private string mName;

		// Token: 0x0400F09C RID: 61596
		[Token(Token = "0x400F09C")]
		[FieldOffset(Offset = "0x38")]
		private long mLastModifiedTime;

		// Token: 0x0400F09D RID: 61597
		[Token(Token = "0x400F09D")]
		[FieldOffset(Offset = "0x40")]
		private ulong mPoints;

		// Token: 0x0400F09E RID: 61598
		[Token(Token = "0x400F09E")]
		[FieldOffset(Offset = "0x48")]
		private string mRevealedImageUrl;

		// Token: 0x0400F09F RID: 61599
		[Token(Token = "0x400F09F")]
		[FieldOffset(Offset = "0x50")]
		private string mUnlockedImageUrl;
	}
}
