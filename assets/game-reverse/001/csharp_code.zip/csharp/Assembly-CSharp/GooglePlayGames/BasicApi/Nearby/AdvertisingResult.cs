﻿using System;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi.Nearby
{
	// Token: 0x02002669 RID: 9833
	[Token(Token = "0x2002669")]
	public struct AdvertisingResult
	{
		// Token: 0x060131EA RID: 78314 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131EA")]
		[Address(RVA = "0x24D1508", Offset = "0x24D1508", VA = "0x24D1508")]
		public AdvertisingResult(ResponseStatus status, string localEndpointName)
		{
		}

		// Token: 0x0400F0D1 RID: 61649
		[Token(Token = "0x400F0D1")]
		[FieldOffset(Offset = "0x0")]
		private readonly ResponseStatus mStatus;

		// Token: 0x0400F0D2 RID: 61650
		[Token(Token = "0x400F0D2")]
		[FieldOffset(Offset = "0x8")]
		private readonly string mLocalEndpointName;
	}
}
