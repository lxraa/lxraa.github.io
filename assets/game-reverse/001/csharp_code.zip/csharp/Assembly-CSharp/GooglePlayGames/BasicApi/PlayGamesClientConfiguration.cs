﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace GooglePlayGames.BasicApi
{
	// Token: 0x02002661 RID: 9825
	[Token(Token = "0x2002661")]
	public struct PlayGamesClientConfiguration
	{
		// Token: 0x060131CD RID: 78285 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60131CD")]
		[Address(RVA = "0x24D5F18", Offset = "0x24D5F18", VA = "0x24D5F18")]
		private PlayGamesClientConfiguration(PlayGamesClientConfiguration.Builder builder)
		{
		}

		// Token: 0x17002838 RID: 10296
		// (get) Token: 0x060131CE RID: 78286 RVA: 0x0007B1F8 File Offset: 0x000793F8
		[Token(Token = "0x17002838")]
		public bool EnableSavedGames
		{
			[Token(Token = "0x60131CE")]
			[Address(RVA = "0x24D6004", Offset = "0x24D6004", VA = "0x24D6004")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x17002839 RID: 10297
		// (get) Token: 0x060131CF RID: 78287 RVA: 0x0007B210 File Offset: 0x00079410
		[Token(Token = "0x17002839")]
		public bool IsHidingPopups
		{
			[Token(Token = "0x60131CF")]
			[Address(RVA = "0x24D600C", Offset = "0x24D600C", VA = "0x24D600C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x1700283A RID: 10298
		// (get) Token: 0x060131D0 RID: 78288 RVA: 0x0007B228 File Offset: 0x00079428
		[Token(Token = "0x1700283A")]
		public bool IsRequestingAuthCode
		{
			[Token(Token = "0x60131D0")]
			[Address(RVA = "0x24D6014", Offset = "0x24D6014", VA = "0x24D6014")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x1700283B RID: 10299
		// (get) Token: 0x060131D1 RID: 78289 RVA: 0x0007B240 File Offset: 0x00079440
		[Token(Token = "0x1700283B")]
		public bool IsForcingRefresh
		{
			[Token(Token = "0x60131D1")]
			[Address(RVA = "0x24D601C", Offset = "0x24D601C", VA = "0x24D601C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x1700283C RID: 10300
		// (get) Token: 0x060131D2 RID: 78290 RVA: 0x0007B258 File Offset: 0x00079458
		[Token(Token = "0x1700283C")]
		public bool IsRequestingEmail
		{
			[Token(Token = "0x60131D2")]
			[Address(RVA = "0x24D6024", Offset = "0x24D6024", VA = "0x24D6024")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x1700283D RID: 10301
		// (get) Token: 0x060131D3 RID: 78291 RVA: 0x0007B270 File Offset: 0x00079470
		[Token(Token = "0x1700283D")]
		public bool IsRequestingIdToken
		{
			[Token(Token = "0x60131D3")]
			[Address(RVA = "0x24D602C", Offset = "0x24D602C", VA = "0x24D602C")]
			get
			{
				return default(bool);
			}
		}

		// Token: 0x1700283E RID: 10302
		// (get) Token: 0x060131D4 RID: 78292 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700283E")]
		public string AccountName
		{
			[Token(Token = "0x60131D4")]
			[Address(RVA = "0x24D6034", Offset = "0x24D6034", VA = "0x24D6034")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700283F RID: 10303
		// (get) Token: 0x060131D5 RID: 78293 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700283F")]
		public string[] Scopes
		{
			[Token(Token = "0x60131D5")]
			[Address(RVA = "0x24D603C", Offset = "0x24D603C", VA = "0x24D603C")]
			get
			{
				return null;
			}
		}

		// Token: 0x060131D6 RID: 78294 RVA: 0x0007B288 File Offset: 0x00079488
		[Token(Token = "0x60131D6")]
		[Address(RVA = "0x24D6044", Offset = "0x24D6044", VA = "0x24D6044")]
		public static bool operator ==(PlayGamesClientConfiguration c1, PlayGamesClientConfiguration c2)
		{
			return default(bool);
		}

		// Token: 0x060131D7 RID: 78295 RVA: 0x0007B2A0 File Offset: 0x000794A0
		[Token(Token = "0x60131D7")]
		[Address(RVA = "0x24C9760", Offset = "0x24C9760", VA = "0x24C9760")]
		public static bool operator !=(PlayGamesClientConfiguration c1, PlayGamesClientConfiguration c2)
		{
			return default(bool);
		}

		// Token: 0x060131D8 RID: 78296 RVA: 0x0007B2B8 File Offset: 0x000794B8
		[Token(Token = "0x60131D8")]
		[Address(RVA = "0x24D615C", Offset = "0x24D615C", VA = "0x24D615C", Slot = "2")]
		public override int GetHashCode()
		{
			return 0;
		}

		// Token: 0x060131D9 RID: 78297 RVA: 0x0007B2D0 File Offset: 0x000794D0
		[Token(Token = "0x60131D9")]
		[Address(RVA = "0x24D6288", Offset = "0x24D6288", VA = "0x24D6288", Slot = "0")]
		public override bool Equals(object obj)
		{
			return default(bool);
		}

		// Token: 0x0400F0B0 RID: 61616
		[Token(Token = "0x400F0B0")]
		[FieldOffset(Offset = "0x0")]
		public static readonly PlayGamesClientConfiguration DefaultConfiguration;

		// Token: 0x0400F0B1 RID: 61617
		[Token(Token = "0x400F0B1")]
		[FieldOffset(Offset = "0x0")]
		private readonly bool mEnableSavedGames;

		// Token: 0x0400F0B2 RID: 61618
		[Token(Token = "0x400F0B2")]
		[FieldOffset(Offset = "0x8")]
		private readonly string[] mScopes;

		// Token: 0x0400F0B3 RID: 61619
		[Token(Token = "0x400F0B3")]
		[FieldOffset(Offset = "0x10")]
		private readonly bool mRequestAuthCode;

		// Token: 0x0400F0B4 RID: 61620
		[Token(Token = "0x400F0B4")]
		[FieldOffset(Offset = "0x11")]
		private readonly bool mForceRefresh;

		// Token: 0x0400F0B5 RID: 61621
		[Token(Token = "0x400F0B5")]
		[FieldOffset(Offset = "0x12")]
		private readonly bool mHidePopups;

		// Token: 0x0400F0B6 RID: 61622
		[Token(Token = "0x400F0B6")]
		[FieldOffset(Offset = "0x13")]
		private readonly bool mRequestEmail;

		// Token: 0x0400F0B7 RID: 61623
		[Token(Token = "0x400F0B7")]
		[FieldOffset(Offset = "0x14")]
		private readonly bool mRequestIdToken;

		// Token: 0x0400F0B8 RID: 61624
		[Token(Token = "0x400F0B8")]
		[FieldOffset(Offset = "0x18")]
		private readonly string mAccountName;

		// Token: 0x02002662 RID: 9826
		[Token(Token = "0x2002662")]
		public class Builder
		{
			// Token: 0x060131DB RID: 78299 RVA: 0x0007B2E8 File Offset: 0x000794E8
			[Token(Token = "0x60131DB")]
			[Address(RVA = "0x24D63FC", Offset = "0x24D63FC", VA = "0x24D63FC")]
			public PlayGamesClientConfiguration Build()
			{
				return default(PlayGamesClientConfiguration);
			}

			// Token: 0x060131DC RID: 78300 RVA: 0x0007B300 File Offset: 0x00079500
			[Token(Token = "0x60131DC")]
			[Address(RVA = "0x24D6410", Offset = "0x24D6410", VA = "0x24D6410")]
			internal bool HasEnableSaveGames()
			{
				return default(bool);
			}

			// Token: 0x060131DD RID: 78301 RVA: 0x0007B318 File Offset: 0x00079518
			[Token(Token = "0x60131DD")]
			[Address(RVA = "0x24D6418", Offset = "0x24D6418", VA = "0x24D6418")]
			internal bool IsRequestingAuthCode()
			{
				return default(bool);
			}

			// Token: 0x060131DE RID: 78302 RVA: 0x0007B330 File Offset: 0x00079530
			[Token(Token = "0x60131DE")]
			[Address(RVA = "0x24D6420", Offset = "0x24D6420", VA = "0x24D6420")]
			internal bool IsHidingPopups()
			{
				return default(bool);
			}

			// Token: 0x060131DF RID: 78303 RVA: 0x0007B348 File Offset: 0x00079548
			[Token(Token = "0x60131DF")]
			[Address(RVA = "0x24D6428", Offset = "0x24D6428", VA = "0x24D6428")]
			internal bool IsForcingRefresh()
			{
				return default(bool);
			}

			// Token: 0x060131E0 RID: 78304 RVA: 0x0007B360 File Offset: 0x00079560
			[Token(Token = "0x60131E0")]
			[Address(RVA = "0x24D6430", Offset = "0x24D6430", VA = "0x24D6430")]
			internal bool IsRequestingEmail()
			{
				return default(bool);
			}

			// Token: 0x060131E1 RID: 78305 RVA: 0x0007B378 File Offset: 0x00079578
			[Token(Token = "0x60131E1")]
			[Address(RVA = "0x24D6438", Offset = "0x24D6438", VA = "0x24D6438")]
			internal bool IsRequestingIdToken()
			{
				return default(bool);
			}

			// Token: 0x060131E2 RID: 78306 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x60131E2")]
			[Address(RVA = "0x24D6440", Offset = "0x24D6440", VA = "0x24D6440")]
			internal string GetAccountName()
			{
				return null;
			}

			// Token: 0x060131E3 RID: 78307 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x60131E3")]
			[Address(RVA = "0x24D5F90", Offset = "0x24D5F90", VA = "0x24D5F90")]
			internal string[] getScopes()
			{
				return null;
			}

			// Token: 0x060131E4 RID: 78308 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60131E4")]
			[Address(RVA = "0x24D63F4", Offset = "0x24D63F4", VA = "0x24D63F4")]
			public Builder()
			{
			}

			// Token: 0x0400F0B9 RID: 61625
			[Token(Token = "0x400F0B9")]
			[FieldOffset(Offset = "0x10")]
			private bool mEnableSaveGames;

			// Token: 0x0400F0BA RID: 61626
			[Token(Token = "0x400F0BA")]
			[FieldOffset(Offset = "0x18")]
			private List<string> mScopes;

			// Token: 0x0400F0BB RID: 61627
			[Token(Token = "0x400F0BB")]
			[FieldOffset(Offset = "0x20")]
			private bool mHidePopups;

			// Token: 0x0400F0BC RID: 61628
			[Token(Token = "0x400F0BC")]
			[FieldOffset(Offset = "0x21")]
			private bool mRequestAuthCode;

			// Token: 0x0400F0BD RID: 61629
			[Token(Token = "0x400F0BD")]
			[FieldOffset(Offset = "0x22")]
			private bool mForceRefresh;

			// Token: 0x0400F0BE RID: 61630
			[Token(Token = "0x400F0BE")]
			[FieldOffset(Offset = "0x23")]
			private bool mRequestEmail;

			// Token: 0x0400F0BF RID: 61631
			[Token(Token = "0x400F0BF")]
			[FieldOffset(Offset = "0x24")]
			private bool mRequestIdToken;

			// Token: 0x0400F0C0 RID: 61632
			[Token(Token = "0x400F0C0")]
			[FieldOffset(Offset = "0x28")]
			private string mAccountName;
		}
	}
}
