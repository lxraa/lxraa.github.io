﻿using System;
using Il2CppDummyDll;

// Token: 0x02000009 RID: 9
[Token(Token = "0x2000009")]
public enum AutoDialogFlowType
{
	// Token: 0x0400001D RID: 29
	[Token(Token = "0x400001D")]
	Launch,
	// Token: 0x0400001E RID: 30
	[Token(Token = "0x400001E")]
	FocusIn,
	// Token: 0x0400001F RID: 31
	[Token(Token = "0x400001F")]
	ForceHomeScene,
	// Token: 0x04000020 RID: 32
	[Token(Token = "0x4000020")]
	LevelFail
}
