﻿using System;
using Il2CppDummyDll;
using UnityEngine;

// Token: 0x0200000A RID: 10
[Token(Token = "0x200000A")]
public class FillAnimationEnd : StateMachineBehaviour
{
	// Token: 0x14000001 RID: 1
	// (add) Token: 0x06000016 RID: 22 RVA: 0x00002053 File Offset: 0x00000253
	// (remove) Token: 0x06000017 RID: 23 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x14000001")]
	public event Action OnComplete
	{
		[Token(Token = "0x6000016")]
		[Address(RVA = "0x1246B70", Offset = "0x1246B70", VA = "0x1246B70")]
		add
		{
		}
		[Token(Token = "0x6000017")]
		[Address(RVA = "0x1246C0C", Offset = "0x1246C0C", VA = "0x1246C0C")]
		remove
		{
		}
	}

	// Token: 0x06000018 RID: 24 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x6000018")]
	[Address(RVA = "0x1246CA8", Offset = "0x1246CA8", VA = "0x1246CA8", Slot = "6")]
	public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
	{
	}

	// Token: 0x06000019 RID: 25 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x6000019")]
	[Address(RVA = "0x1246CC4", Offset = "0x1246CC4", VA = "0x1246CC4")]
	private void OnDisable()
	{
	}

	// Token: 0x0600001A RID: 26 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x600001A")]
	[Address(RVA = "0x1246CD0", Offset = "0x1246CD0", VA = "0x1246CD0")]
	public FillAnimationEnd()
	{
	}
}
