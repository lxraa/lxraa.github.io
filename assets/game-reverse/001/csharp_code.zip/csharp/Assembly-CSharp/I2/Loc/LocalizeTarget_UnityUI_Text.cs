﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace I2.Loc
{
	// Token: 0x02002602 RID: 9730
	[Token(Token = "0x2002602")]
	public class LocalizeTarget_UnityUI_Text : LocalizeTarget<Text>
	{
		// Token: 0x0601303E RID: 77886 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601303E")]
		[Address(RVA = "0x2623EB8", Offset = "0x2623EB8", VA = "0x2623EB8")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x0601303F RID: 77887 RVA: 0x0007ADD8 File Offset: 0x00078FD8
		[Token(Token = "0x601303F")]
		[Address(RVA = "0x2623F7C", Offset = "0x2623F7C", VA = "0x2623F7C", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013040 RID: 77888 RVA: 0x0007ADF0 File Offset: 0x00078FF0
		[Token(Token = "0x6013040")]
		[Address(RVA = "0x2623F84", Offset = "0x2623F84", VA = "0x2623F84", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013041 RID: 77889 RVA: 0x0007AE08 File Offset: 0x00079008
		[Token(Token = "0x6013041")]
		[Address(RVA = "0x2623F8C", Offset = "0x2623F8C", VA = "0x2623F8C", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x06013042 RID: 77890 RVA: 0x0007AE20 File Offset: 0x00079020
		[Token(Token = "0x6013042")]
		[Address(RVA = "0x2623F94", Offset = "0x2623F94", VA = "0x2623F94", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013043 RID: 77891 RVA: 0x0007AE38 File Offset: 0x00079038
		[Token(Token = "0x6013043")]
		[Address(RVA = "0x2623F9C", Offset = "0x2623F9C", VA = "0x2623F9C", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013044 RID: 77892 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013044")]
		[Address(RVA = "0x2623FA4", Offset = "0x2623FA4", VA = "0x2623FA4", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06013045 RID: 77893 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013045")]
		[Address(RVA = "0x26240D0", Offset = "0x26240D0", VA = "0x26240D0", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06013046 RID: 77894 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013046")]
		[Address(RVA = "0x2624378", Offset = "0x2624378", VA = "0x2624378")]
		private void InitAlignment(bool isRTL, TextAnchor alignment, out TextAnchor alignLTR, out TextAnchor alignRTL)
		{
		}

		// Token: 0x06013047 RID: 77895 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013047")]
		[Address(RVA = "0x2624430", Offset = "0x2624430", VA = "0x2624430")]
		public LocalizeTarget_UnityUI_Text()
		{
		}

		// Token: 0x0400EFAA RID: 61354
		[Token(Token = "0x400EFAA")]
		[FieldOffset(Offset = "0x20")]
		private TextAnchor mAlignment_RTL;

		// Token: 0x0400EFAB RID: 61355
		[Token(Token = "0x400EFAB")]
		[FieldOffset(Offset = "0x24")]
		private TextAnchor mAlignment_LTR;

		// Token: 0x0400EFAC RID: 61356
		[Token(Token = "0x400EFAC")]
		[FieldOffset(Offset = "0x28")]
		private bool mAlignmentWasRTL;

		// Token: 0x0400EFAD RID: 61357
		[Token(Token = "0x400EFAD")]
		[FieldOffset(Offset = "0x29")]
		private bool mInitializeAlignment;
	}
}
