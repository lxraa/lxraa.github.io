﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x02002616 RID: 9750
	[Token(Token = "0x2002616")]
	internal class TashkeelLocation
	{
		// Token: 0x06013087 RID: 77959 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013087")]
		[Address(RVA = "0x2628940", Offset = "0x2628940", VA = "0x2628940")]
		public TashkeelLocation(char tashkeel, int position)
		{
		}

		// Token: 0x0400EFD7 RID: 61399
		[Token(Token = "0x400EFD7")]
		[FieldOffset(Offset = "0x10")]
		public char tashkeel;

		// Token: 0x0400EFD8 RID: 61400
		[Token(Token = "0x400EFD8")]
		[FieldOffset(Offset = "0x14")]
		public int position;
	}
}
