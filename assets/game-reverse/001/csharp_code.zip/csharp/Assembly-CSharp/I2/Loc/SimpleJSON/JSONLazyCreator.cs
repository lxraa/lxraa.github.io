﻿using System;
using Il2CppDummyDll;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x02002621 RID: 9761
	[Token(Token = "0x2002621")]
	internal class JSONLazyCreator : JSONNode
	{
		// Token: 0x060130CF RID: 78031 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130CF")]
		[Address(RVA = "0x24C4C4C", Offset = "0x24C4C4C", VA = "0x24C4C4C")]
		public JSONLazyCreator(JSONNode aNode)
		{
		}

		// Token: 0x060130D0 RID: 78032 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130D0")]
		[Address(RVA = "0x24C53C0", Offset = "0x24C53C0", VA = "0x24C53C0")]
		public JSONLazyCreator(JSONNode aNode, string aKey)
		{
		}

		// Token: 0x060130D1 RID: 78033 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130D1")]
		[Address(RVA = "0x24C5E24", Offset = "0x24C5E24", VA = "0x24C5E24")]
		private void Set(JSONNode aVal)
		{
		}

		// Token: 0x17002821 RID: 10273
		[Token(Token = "0x17002821")]
		public override JSONNode this[int aIndex]
		{
			[Token(Token = "0x60130D2")]
			[Address(RVA = "0x24C5E84", Offset = "0x24C5E84", VA = "0x24C5E84", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002822 RID: 10274
		[Token(Token = "0x17002822")]
		public override JSONNode this[string aKey]
		{
			[Token(Token = "0x60130D3")]
			[Address(RVA = "0x24C5EE4", Offset = "0x24C5EE4", VA = "0x24C5EE4", Slot = "6")]
			get
			{
				return null;
			}
		}

		// Token: 0x060130D4 RID: 78036 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130D4")]
		[Address(RVA = "0x24C5F54", Offset = "0x24C5F54", VA = "0x24C5F54", Slot = "10")]
		public override void Add(JSONNode aItem)
		{
		}

		// Token: 0x060130D5 RID: 78037 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130D5")]
		[Address(RVA = "0x24C5FD4", Offset = "0x24C5FD4", VA = "0x24C5FD4", Slot = "4")]
		public override void Add(string aKey, JSONNode aItem)
		{
		}

		// Token: 0x060130D6 RID: 78038 RVA: 0x0007B060 File Offset: 0x00079260
		[Token(Token = "0x60130D6")]
		[Address(RVA = "0x24C605C", Offset = "0x24C605C", VA = "0x24C605C", Slot = "0")]
		public override bool Equals(object obj)
		{
			return default(bool);
		}

		// Token: 0x060130D7 RID: 78039 RVA: 0x0007B078 File Offset: 0x00079278
		[Token(Token = "0x60130D7")]
		[Address(RVA = "0x24C6074", Offset = "0x24C6074", VA = "0x24C6074", Slot = "2")]
		public override int GetHashCode()
		{
			return 0;
		}

		// Token: 0x060130D8 RID: 78040 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130D8")]
		[Address(RVA = "0x24C607C", Offset = "0x24C607C", VA = "0x24C607C", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x17002823 RID: 10275
		// (get) Token: 0x060130D9 RID: 78041 RVA: 0x0007B090 File Offset: 0x00079290
		// (set) Token: 0x060130DA RID: 78042 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002823")]
		public override int AsInt
		{
			[Token(Token = "0x60130D9")]
			[Address(RVA = "0x24C60BC", Offset = "0x24C60BC", VA = "0x24C60BC", Slot = "11")]
			get
			{
				return 0;
			}
			[Token(Token = "0x60130DA")]
			[Address(RVA = "0x24C613C", Offset = "0x24C613C", VA = "0x24C613C", Slot = "12")]
			set
			{
			}
		}

		// Token: 0x0400EFE8 RID: 61416
		[Token(Token = "0x400EFE8")]
		[FieldOffset(Offset = "0x10")]
		private JSONNode m_Node;

		// Token: 0x0400EFE9 RID: 61417
		[Token(Token = "0x400EFE9")]
		[FieldOffset(Offset = "0x18")]
		private string m_Key;
	}
}
