﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025CE RID: 9678
	[Token(Token = "0x20025CE")]
	public class BaseSpecializationManager
	{
		// Token: 0x06012EE6 RID: 77542 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EE6")]
		[Address(RVA = "0x2452AF8", Offset = "0x2452AF8", VA = "0x2452AF8", Slot = "4")]
		public virtual void InitializeSpecializations()
		{
		}

		// Token: 0x06012EE7 RID: 77543 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EE7")]
		[Address(RVA = "0x24530E4", Offset = "0x24530E4", VA = "0x24530E4", Slot = "5")]
		public virtual string GetCurrentSpecialization()
		{
			return null;
		}

		// Token: 0x06012EE8 RID: 77544 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EE8")]
		[Address(RVA = "0x2453140", Offset = "0x2453140", VA = "0x2453140", Slot = "6")]
		public virtual string GetFallbackSpecialization(string specialization)
		{
			return null;
		}

		// Token: 0x06012EE9 RID: 77545 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EE9")]
		[Address(RVA = "0x24531E8", Offset = "0x24531E8", VA = "0x24531E8")]
		public BaseSpecializationManager()
		{
		}

		// Token: 0x0400EEE7 RID: 61159
		[Token(Token = "0x400EEE7")]
		[FieldOffset(Offset = "0x10")]
		public string[] mSpecializations;

		// Token: 0x0400EEE8 RID: 61160
		[Token(Token = "0x400EEE8")]
		[FieldOffset(Offset = "0x18")]
		public Dictionary<string, string> mSpecializationsFallbacks;
	}
}
