﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02002610 RID: 9744
	[Token(Token = "0x2002610")]
	public class RegisterGlobalParameters : MonoBehaviour, ILocalizationParamsManager
	{
		// Token: 0x06013072 RID: 77938 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013072")]
		[Address(RVA = "0x262575C", Offset = "0x262575C", VA = "0x262575C", Slot = "5")]
		public virtual void OnEnable()
		{
		}

		// Token: 0x06013073 RID: 77939 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013073")]
		[Address(RVA = "0x2625888", Offset = "0x2625888", VA = "0x2625888", Slot = "6")]
		public virtual void OnDisable()
		{
		}

		// Token: 0x06013074 RID: 77940 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013074")]
		[Address(RVA = "0x2625908", Offset = "0x2625908", VA = "0x2625908", Slot = "7")]
		public virtual string GetParameterValue(string ParamName)
		{
			return null;
		}

		// Token: 0x06013075 RID: 77941 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013075")]
		[Address(RVA = "0x2625910", Offset = "0x2625910", VA = "0x2625910")]
		public RegisterGlobalParameters()
		{
		}
	}
}
