﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025E3 RID: 9699
	[Token(Token = "0x20025E3")]
	public class LocalizationReader
	{
		// Token: 0x06012F4B RID: 77643 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F4B")]
		[Address(RVA = "0x261435C", Offset = "0x261435C", VA = "0x261435C")]
		public static List<string[]> ReadI2CSV(string Text)
		{
			return null;
		}
	}
}
