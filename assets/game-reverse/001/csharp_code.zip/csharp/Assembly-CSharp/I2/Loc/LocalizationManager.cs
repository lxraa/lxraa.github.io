﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025E8 RID: 9704
	[Token(Token = "0x20025E8")]
	public static class LocalizationManager
	{
		// Token: 0x06012F73 RID: 77683 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F73")]
		[Address(RVA = "0x261C2A4", Offset = "0x261C2A4", VA = "0x261C2A4")]
		public static void InitializeIfNeeded()
		{
		}

		// Token: 0x06012F74 RID: 77684 RVA: 0x0007A7C0 File Offset: 0x000789C0
		[Token(Token = "0x6012F74")]
		[Address(RVA = "0x2617410", Offset = "0x2617410", VA = "0x2617410")]
		public static int GetRequiredWebServiceVersion()
		{
			return 0;
		}

		// Token: 0x06012F75 RID: 77685 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F75")]
		[Address(RVA = "0x2617268", Offset = "0x2617268", VA = "0x2617268")]
		public static string GetWebServiceURL([Optional] LanguageSourceData source)
		{
			return null;
		}

		// Token: 0x17002808 RID: 10248
		// (get) Token: 0x06012F76 RID: 77686 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012F77 RID: 77687 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002808")]
		public static string CurrentLanguage
		{
			[Token(Token = "0x6012F76")]
			[Address(RVA = "0x2617678", Offset = "0x2617678", VA = "0x2617678")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012F77")]
			[Address(RVA = "0x261AD58", Offset = "0x261AD58", VA = "0x261AD58")]
			set
			{
			}
		}

		// Token: 0x17002809 RID: 10249
		// (get) Token: 0x06012F78 RID: 77688 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002809")]
		public static string CurrentLanguageCode
		{
			[Token(Token = "0x6012F78")]
			[Address(RVA = "0x261D0B0", Offset = "0x261D0B0", VA = "0x261D0B0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06012F79 RID: 77689 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F79")]
		[Address(RVA = "0x261CEB4", Offset = "0x261CEB4", VA = "0x261CEB4")]
		public static void SetLanguageAndCode(string LanguageName, string LanguageCode, bool RememberLanguage = true, bool Force = false)
		{
		}

		// Token: 0x06012F7A RID: 77690 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F7A")]
		[Address(RVA = "0x261D10C", Offset = "0x261D10C", VA = "0x261D10C")]
		private static CultureInfo CreateCultureForCode(string code)
		{
			return null;
		}

		// Token: 0x06012F7B RID: 77691 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F7B")]
		[Address(RVA = "0x261D2FC", Offset = "0x261D2FC", VA = "0x261D2FC")]
		public static void EnableChangingCultureInfo(bool bEnable)
		{
		}

		// Token: 0x06012F7C RID: 77692 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F7C")]
		[Address(RVA = "0x261D200", Offset = "0x261D200", VA = "0x261D200")]
		private static void SetCurrentCultureInfo()
		{
		}

		// Token: 0x06012F7D RID: 77693 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F7D")]
		[Address(RVA = "0x261C5CC", Offset = "0x261C5CC", VA = "0x261C5CC")]
		private static void SelectStartupLanguage()
		{
		}

		// Token: 0x06012F7E RID: 77694 RVA: 0x0007A7D8 File Offset: 0x000789D8
		[Token(Token = "0x6012F7E")]
		[Address(RVA = "0x261D42C", Offset = "0x261D42C", VA = "0x261D42C")]
		public static bool HasLanguage(string Language, bool AllowDiscartingRegion = true, bool Initialize = true, bool SkipDisabled = true)
		{
			return default(bool);
		}

		// Token: 0x06012F7F RID: 77695 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F7F")]
		[Address(RVA = "0x261C9A0", Offset = "0x261C9A0", VA = "0x261C9A0")]
		public static string GetSupportedLanguage(string Language, bool ignoreDisabled = false)
		{
			return null;
		}

		// Token: 0x06012F80 RID: 77696 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F80")]
		[Address(RVA = "0x261CCFC", Offset = "0x261CCFC", VA = "0x261CCFC")]
		public static string GetLanguageCode(string Language)
		{
			return null;
		}

		// Token: 0x06012F81 RID: 77697 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F81")]
		[Address(RVA = "0x261D5E4", Offset = "0x261D5E4", VA = "0x261D5E4")]
		public static List<string> GetAllLanguages(bool SkipDisabled = true)
		{
			return null;
		}

		// Token: 0x06012F82 RID: 77698 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F82")]
		[Address(RVA = "0x261D864", Offset = "0x261D864", VA = "0x261D864")]
		private static void LoadCurrentLanguage()
		{
		}

		// Token: 0x06012F83 RID: 77699 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F83")]
		[Address(RVA = "0x261C368", Offset = "0x261C368", VA = "0x261C368")]
		public static void AutoLoadGlobalParamManagers()
		{
		}

		// Token: 0x06012F84 RID: 77700 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F84")]
		[Address(RVA = "0x261D98C", Offset = "0x261D98C", VA = "0x261D98C")]
		public static void ApplyLocalizationParams(ref string translation, bool allowLocalizedParameters = true)
		{
		}

		// Token: 0x06012F85 RID: 77701 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F85")]
		[Address(RVA = "0x2619F90", Offset = "0x2619F90", VA = "0x2619F90")]
		public static void ApplyLocalizationParams(ref string translation, GameObject root, bool allowLocalizedParameters = true)
		{
		}

		// Token: 0x06012F86 RID: 77702 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F86")]
		[Address(RVA = "0x261DB80", Offset = "0x261DB80", VA = "0x261DB80")]
		public static void ApplyLocalizationParams(ref string translation, LocalizationManager._GetParam getParam, bool allowLocalizedParameters = true)
		{
		}

		// Token: 0x06012F87 RID: 77703 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F87")]
		[Address(RVA = "0x261E0F4", Offset = "0x261E0F4", VA = "0x261E0F4")]
		internal static string GetLocalizationParam(string ParamName, GameObject root)
		{
			return null;
		}

		// Token: 0x06012F88 RID: 77704 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F88")]
		[Address(RVA = "0x261A4E0", Offset = "0x261A4E0", VA = "0x261A4E0")]
		public static string ApplyRTLfix(string line)
		{
			return null;
		}

		// Token: 0x06012F89 RID: 77705 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F89")]
		[Address(RVA = "0x261A080", Offset = "0x261A080", VA = "0x261A080")]
		public static string ApplyRTLfix(string line, int maxCharacters, bool ignoreNumbers)
		{
			return null;
		}

		// Token: 0x06012F8A RID: 77706 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F8A")]
		[Address(RVA = "0x261EA28", Offset = "0x261EA28", VA = "0x261EA28")]
		public static string FixRTL_IfNeeded(string text, int maxCharacters = 0, bool ignoreNumber = false)
		{
			return null;
		}

		// Token: 0x06012F8B RID: 77707 RVA: 0x0007A7F0 File Offset: 0x000789F0
		[Token(Token = "0x6012F8B")]
		[Address(RVA = "0x261D278", Offset = "0x261D278", VA = "0x261D278")]
		public static bool IsRTL(string Code)
		{
			return default(bool);
		}

		// Token: 0x06012F8C RID: 77708 RVA: 0x0007A808 File Offset: 0x00078A08
		[Token(Token = "0x6012F8C")]
		[Address(RVA = "0x261C548", Offset = "0x261C548", VA = "0x261C548")]
		public static bool UpdateSources()
		{
			return default(bool);
		}

		// Token: 0x06012F8D RID: 77709 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F8D")]
		[Address(RVA = "0x261EAC4", Offset = "0x261EAC4", VA = "0x261EAC4")]
		private static void UnregisterDeletededSources()
		{
		}

		// Token: 0x06012F8E RID: 77710 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F8E")]
		[Address(RVA = "0x261ED68", Offset = "0x261ED68", VA = "0x261ED68")]
		private static void RegisterSceneSources()
		{
		}

		// Token: 0x06012F8F RID: 77711 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F8F")]
		[Address(RVA = "0x261EBCC", Offset = "0x261EBCC", VA = "0x261EBCC")]
		private static void RegisterSourceInResources()
		{
		}

		// Token: 0x06012F90 RID: 77712 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F90")]
		[Address(RVA = "0x261322C", Offset = "0x261322C", VA = "0x261322C")]
		internal static void AddSource(LanguageSourceData Source)
		{
		}

		// Token: 0x06012F91 RID: 77713 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F91")]
		[Address(RVA = "0x261EEFC", Offset = "0x261EEFC", VA = "0x261EEFC")]
		private static IEnumerator Delayed_Import_Google(LanguageSourceData source, float delay, bool justCheck)
		{
			return null;
		}

		// Token: 0x06012F92 RID: 77714 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F92")]
		[Address(RVA = "0x2613BB8", Offset = "0x2613BB8", VA = "0x2613BB8")]
		internal static void RemoveSource(LanguageSourceData Source)
		{
		}

		// Token: 0x06012F93 RID: 77715 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F93")]
		[Address(RVA = "0x261EFBC", Offset = "0x261EFBC", VA = "0x261EFBC")]
		public static UnityEngine.Object FindAsset(string value)
		{
			return null;
		}

		// Token: 0x06012F94 RID: 77716 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F94")]
		[Address(RVA = "0x261D390", Offset = "0x261D390", VA = "0x261D390")]
		public static string GetCurrentDeviceLanguage(bool force = false)
		{
			return null;
		}

		// Token: 0x06012F95 RID: 77717 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F95")]
		[Address(RVA = "0x261F0EC", Offset = "0x261F0EC", VA = "0x261F0EC")]
		private static void DetectDeviceLanguage()
		{
		}

		// Token: 0x06012F96 RID: 77718 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F96")]
		[Address(RVA = "0x261F56C", Offset = "0x261F56C", VA = "0x261F56C")]
		public static void RegisterTarget(ILocalizeTargetDescriptor desc)
		{
		}

		// Token: 0x140000A7 RID: 167
		// (add) Token: 0x06012F97 RID: 77719 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012F98 RID: 77720 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A7")]
		public static event LocalizationManager.OnLocalizeCallback OnLocalizeEvent
		{
			[Token(Token = "0x6012F97")]
			[Address(RVA = "0x261B388", Offset = "0x261B388", VA = "0x261B388")]
			add
			{
			}
			[Token(Token = "0x6012F98")]
			[Address(RVA = "0x261B5EC", Offset = "0x261B5EC", VA = "0x261B5EC")]
			remove
			{
			}
		}

		// Token: 0x06012F99 RID: 77721 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F99")]
		[Address(RVA = "0x2619EDC", Offset = "0x2619EDC", VA = "0x2619EDC")]
		public static string GetTranslation(string Term, bool FixForRTL = true, int maxLineLengthForRTL = 0, bool ignoreRTLnumbers = true, bool applyParameters = false, [Optional] GameObject localParametersRoot, [Optional] string overrideLanguage)
		{
			return null;
		}

		// Token: 0x06012F9A RID: 77722 RVA: 0x0007A820 File Offset: 0x00078A20
		[Token(Token = "0x6012F9A")]
		[Address(RVA = "0x261F824", Offset = "0x261F824", VA = "0x261F824")]
		public static bool TryGetTranslation(string Term, out string Translation, bool FixForRTL = true, int maxLineLengthForRTL = 0, bool ignoreRTLnumbers = true, bool applyParameters = false, [Optional] GameObject localParametersRoot, [Optional] string overrideLanguage)
		{
			return default(bool);
		}

		// Token: 0x06012F9B RID: 77723 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F9B")]
		[Address(RVA = "0x2613AF0", Offset = "0x2613AF0", VA = "0x2613AF0")]
		public static void LocalizeAll(bool Force = false)
		{
		}

		// Token: 0x06012F9C RID: 77724 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F9C")]
		[Address(RVA = "0x261FB84", Offset = "0x261FB84", VA = "0x261FB84")]
		private static IEnumerator Coroutine_LocalizeAll()
		{
			return null;
		}

		// Token: 0x06012F9D RID: 77725 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F9D")]
		[Address(RVA = "0x261FA0C", Offset = "0x261FA0C", VA = "0x261FA0C")]
		private static void DoLocalizeAll(bool Force = false)
		{
		}

		// Token: 0x06012F9E RID: 77726 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F9E")]
		[Address(RVA = "0x261DF9C", Offset = "0x261DF9C", VA = "0x261DF9C")]
		public static TermData GetTermData(string term, out LanguageSourceData source)
		{
			return null;
		}

		// Token: 0x0400EF7E RID: 61310
		[Token(Token = "0x400EF7E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		private static string mCurrentLanguage;

		// Token: 0x0400EF7F RID: 61311
		[Token(Token = "0x400EF7F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
		private static string mLanguageCode;

		// Token: 0x0400EF80 RID: 61312
		[Token(Token = "0x400EF80")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		private static CultureInfo mCurrentCulture;

		// Token: 0x0400EF81 RID: 61313
		[Token(Token = "0x400EF81")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		private static bool mChangeCultureInfo;

		// Token: 0x0400EF82 RID: 61314
		[Token(Token = "0x400EF82")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x19")]
		public static bool IsRight2Left;

		// Token: 0x0400EF83 RID: 61315
		[Token(Token = "0x400EF83")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x1A")]
		public static bool HasJoinedWords;

		// Token: 0x0400EF84 RID: 61316
		[Token(Token = "0x400EF84")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		public static List<ILocalizationParamsManager> ParamManagers;

		// Token: 0x0400EF85 RID: 61317
		[Token(Token = "0x400EF85")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		private static string[] LanguagesRTL;

		// Token: 0x0400EF86 RID: 61318
		[Token(Token = "0x400EF86")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
		public static List<LanguageSourceData> Sources;

		// Token: 0x0400EF87 RID: 61319
		[Token(Token = "0x400EF87")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x38")]
		public static string[] GlobalSources;

		// Token: 0x0400EF88 RID: 61320
		[Token(Token = "0x400EF88")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x40")]
		private static string mCurrentDeviceLanguage;

		// Token: 0x0400EF89 RID: 61321
		[Token(Token = "0x400EF89")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x48")]
		public static List<ILocalizeTargetDescriptor> mLocalizeTargets;

		// Token: 0x0400EF8B RID: 61323
		[Token(Token = "0x400EF8B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x58")]
		private static bool mLocalizeIsScheduled;

		// Token: 0x0400EF8C RID: 61324
		[Token(Token = "0x400EF8C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x59")]
		private static bool mLocalizeIsScheduledWithForcedValue;

		// Token: 0x0400EF8D RID: 61325
		[Token(Token = "0x400EF8D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x5A")]
		public static bool HighlightLocalizedTargets;

		// Token: 0x020025E9 RID: 9705
		// (Invoke) Token: 0x06012FA1 RID: 77729
		[Token(Token = "0x20025E9")]
		public delegate object _GetParam(string param);

		// Token: 0x020025EA RID: 9706
		// (Invoke) Token: 0x06012FA3 RID: 77731
		[Token(Token = "0x20025EA")]
		public delegate void OnLocalizeCallback();

		// Token: 0x020025EB RID: 9707
		[Token(Token = "0x20025EB")]
		private sealed class <>c__DisplayClass33_0
		{
			// Token: 0x06012FA4 RID: 77732 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FA4")]
			[Address(RVA = "0x261D85C", Offset = "0x261D85C", VA = "0x261D85C")]
			public <>c__DisplayClass33_0()
			{
			}

			// Token: 0x06012FA5 RID: 77733 RVA: 0x0007A838 File Offset: 0x00078A38
			[Token(Token = "0x6012FA5")]
			[Address(RVA = "0x26205F0", Offset = "0x26205F0", VA = "0x26205F0")]
			internal bool <GetAllLanguages>b__0(string x)
			{
				return default(bool);
			}

			// Token: 0x0400EF8E RID: 61326
			[Token(Token = "0x400EF8E")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public List<string> Languages;

			// Token: 0x0400EF8F RID: 61327
			[Token(Token = "0x400EF8F")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			public Func<string, bool> <>9__0;
		}

		// Token: 0x020025EC RID: 9708
		[Token(Token = "0x20025EC")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06012FA7 RID: 77735 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FA7")]
			[Address(RVA = "0x26206C4", Offset = "0x26206C4", VA = "0x26206C4")]
			public <>c()
			{
			}

			// Token: 0x06012FA8 RID: 77736 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012FA8")]
			[Address(RVA = "0x26206CC", Offset = "0x26206CC", VA = "0x26206CC")]
			internal object <ApplyLocalizationParams>b__41_0(string p)
			{
				return null;
			}

			// Token: 0x0400EF90 RID: 61328
			[Token(Token = "0x400EF90")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
			public static readonly LocalizationManager.<>c <>9;

			// Token: 0x0400EF91 RID: 61329
			[Token(Token = "0x400EF91")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
			public static LocalizationManager._GetParam <>9__41_0;
		}

		// Token: 0x020025ED RID: 9709
		[Token(Token = "0x20025ED")]
		private sealed class <>c__DisplayClass42_0
		{
			// Token: 0x06012FA9 RID: 77737 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FA9")]
			[Address(RVA = "0x261DF94", Offset = "0x261DF94", VA = "0x261DF94")]
			public <>c__DisplayClass42_0()
			{
			}

			// Token: 0x06012FAA RID: 77738 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012FAA")]
			[Address(RVA = "0x2620724", Offset = "0x2620724", VA = "0x2620724")]
			internal object <ApplyLocalizationParams>b__0(string p)
			{
				return null;
			}

			// Token: 0x0400EF92 RID: 61330
			[Token(Token = "0x400EF92")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public GameObject root;
		}

		// Token: 0x020025EE RID: 9710
		[Token(Token = "0x20025EE")]
		private sealed class <Delayed_Import_Google>d__59 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012FAB RID: 77739 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FAB")]
			[Address(RVA = "0x261EF94", Offset = "0x261EF94", VA = "0x261EF94")]
			[DebuggerHidden]
			public <Delayed_Import_Google>d__59(int <>1__state)
			{
			}

			// Token: 0x06012FAC RID: 77740 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FAC")]
			[Address(RVA = "0x262078C", Offset = "0x262078C", VA = "0x262078C", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012FAD RID: 77741 RVA: 0x0007A850 File Offset: 0x00078A50
			[Token(Token = "0x6012FAD")]
			[Address(RVA = "0x2620790", Offset = "0x2620790", VA = "0x2620790", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x1700280A RID: 10250
			// (get) Token: 0x06012FAE RID: 77742 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x1700280A")]
			private object Current
			{
				[Token(Token = "0x6012FAE")]
				[Address(RVA = "0x2620850", Offset = "0x2620850", VA = "0x2620850", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012FAF RID: 77743 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FAF")]
			[Address(RVA = "0x2620858", Offset = "0x2620858", VA = "0x2620858", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x1700280B RID: 10251
			// (get) Token: 0x06012FB0 RID: 77744 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x1700280B")]
			private object Current
			{
				[Token(Token = "0x6012FB0")]
				[Address(RVA = "0x2620898", Offset = "0x2620898", VA = "0x2620898", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EF93 RID: 61331
			[Token(Token = "0x400EF93")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EF94 RID: 61332
			[Token(Token = "0x400EF94")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EF95 RID: 61333
			[Token(Token = "0x400EF95")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
			public float delay;

			// Token: 0x0400EF96 RID: 61334
			[Token(Token = "0x400EF96")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
			public LanguageSourceData source;

			// Token: 0x0400EF97 RID: 61335
			[Token(Token = "0x400EF97")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
			public bool justCheck;
		}

		// Token: 0x020025EF RID: 9711
		[Token(Token = "0x20025EF")]
		private sealed class <>c__DisplayClass69_0
		{
			// Token: 0x06012FB1 RID: 77745 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FB1")]
			[Address(RVA = "0x261F81C", Offset = "0x261F81C", VA = "0x261F81C")]
			public <>c__DisplayClass69_0()
			{
			}

			// Token: 0x06012FB2 RID: 77746 RVA: 0x0007A868 File Offset: 0x00078A68
			[Token(Token = "0x6012FB2")]
			[Address(RVA = "0x26208A0", Offset = "0x26208A0", VA = "0x26208A0")]
			internal bool <RegisterTarget>b__0(ILocalizeTargetDescriptor x)
			{
				return default(bool);
			}

			// Token: 0x0400EF98 RID: 61336
			[Token(Token = "0x400EF98")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public ILocalizeTargetDescriptor desc;
		}

		// Token: 0x020025F0 RID: 9712
		[Token(Token = "0x20025F0")]
		private sealed class <Coroutine_LocalizeAll>d__84 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012FB3 RID: 77747 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FB3")]
			[Address(RVA = "0x261FBE4", Offset = "0x261FBE4", VA = "0x261FBE4")]
			[DebuggerHidden]
			public <Coroutine_LocalizeAll>d__84(int <>1__state)
			{
			}

			// Token: 0x06012FB4 RID: 77748 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FB4")]
			[Address(RVA = "0x26208C8", Offset = "0x26208C8", VA = "0x26208C8", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012FB5 RID: 77749 RVA: 0x0007A880 File Offset: 0x00078A80
			[Token(Token = "0x6012FB5")]
			[Address(RVA = "0x26208CC", Offset = "0x26208CC", VA = "0x26208CC", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x1700280C RID: 10252
			// (get) Token: 0x06012FB6 RID: 77750 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x1700280C")]
			private object Current
			{
				[Token(Token = "0x6012FB6")]
				[Address(RVA = "0x2620990", Offset = "0x2620990", VA = "0x2620990", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012FB7 RID: 77751 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012FB7")]
			[Address(RVA = "0x2620998", Offset = "0x2620998", VA = "0x2620998", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x1700280D RID: 10253
			// (get) Token: 0x06012FB8 RID: 77752 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x1700280D")]
			private object Current
			{
				[Token(Token = "0x6012FB8")]
				[Address(RVA = "0x26209D8", Offset = "0x26209D8", VA = "0x26209D8", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EF99 RID: 61337
			[Token(Token = "0x400EF99")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EF9A RID: 61338
			[Token(Token = "0x400EF9A")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			private object <>2__current;
		}
	}
}
