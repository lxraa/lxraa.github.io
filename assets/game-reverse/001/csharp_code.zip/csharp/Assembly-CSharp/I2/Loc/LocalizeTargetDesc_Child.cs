﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025F9 RID: 9721
	[Token(Token = "0x20025F9")]
	public class LocalizeTargetDesc_Child : LocalizeTargetDesc<LocalizeTarget_UnityStandard_Child>
	{
		// Token: 0x06012FF0 RID: 77808 RVA: 0x0007AA30 File Offset: 0x00078C30
		[Token(Token = "0x6012FF0")]
		[Address(RVA = "0x26221A4", Offset = "0x26221A4", VA = "0x26221A4", Slot = "4")]
		public override bool CanLocalize(Localize cmp)
		{
			return default(bool);
		}

		// Token: 0x06012FF1 RID: 77809 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FF1")]
		[Address(RVA = "0x26221D8", Offset = "0x26221D8", VA = "0x26221D8")]
		public LocalizeTargetDesc_Child()
		{
		}
	}
}
