﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Il2CppDummyDll;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x0200261E RID: 9758
	[Token(Token = "0x200261E")]
	public class JSONClass : JSONNode, IEnumerable
	{
		// Token: 0x1700281B RID: 10267
		[Token(Token = "0x1700281B")]
		public override JSONNode this[string aKey]
		{
			[Token(Token = "0x60130BC")]
			[Address(RVA = "0x24C52FC", Offset = "0x24C52FC", VA = "0x24C52FC", Slot = "6")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700281C RID: 10268
		[Token(Token = "0x1700281C")]
		public override JSONNode this[int aIndex]
		{
			[Token(Token = "0x60130BD")]
			[Address(RVA = "0x24C5404", Offset = "0x24C5404", VA = "0x24C5404", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x1700281D RID: 10269
		// (get) Token: 0x060130BE RID: 78014 RVA: 0x0007B030 File Offset: 0x00079230
		[Token(Token = "0x1700281D")]
		public override int Count
		{
			[Token(Token = "0x60130BE")]
			[Address(RVA = "0x24C54A4", Offset = "0x24C54A4", VA = "0x24C54A4", Slot = "9")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060130BF RID: 78015 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130BF")]
		[Address(RVA = "0x24C54F4", Offset = "0x24C54F4", VA = "0x24C54F4", Slot = "4")]
		public override void Add(string aKey, JSONNode aItem)
		{
		}

		// Token: 0x060130C0 RID: 78016 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130C0")]
		[Address(RVA = "0x24C5608", Offset = "0x24C5608", VA = "0x24C5608", Slot = "13")]
		public IEnumerator GetEnumerator()
		{
			return null;
		}

		// Token: 0x060130C1 RID: 78017 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130C1")]
		[Address(RVA = "0x24C56A4", Offset = "0x24C56A4", VA = "0x24C56A4", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x060130C2 RID: 78018 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130C2")]
		[Address(RVA = "0x24C4A18", Offset = "0x24C4A18", VA = "0x24C4A18")]
		public JSONClass()
		{
		}

		// Token: 0x0400EFE2 RID: 61410
		[Token(Token = "0x400EFE2")]
		[FieldOffset(Offset = "0x10")]
		private Dictionary<string, JSONNode> m_Dict;

		// Token: 0x0200261F RID: 9759
		[Token(Token = "0x200261F")]
		private sealed class <GetEnumerator>d__15 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x060130C3 RID: 78019 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130C3")]
			[Address(RVA = "0x24C567C", Offset = "0x24C567C", VA = "0x24C567C")]
			[DebuggerHidden]
			public <GetEnumerator>d__15(int <>1__state)
			{
			}

			// Token: 0x060130C4 RID: 78020 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130C4")]
			[Address(RVA = "0x24C5AE8", Offset = "0x24C5AE8", VA = "0x24C5AE8", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x060130C5 RID: 78021 RVA: 0x0007B048 File Offset: 0x00079248
			[Token(Token = "0x60130C5")]
			[Address(RVA = "0x24C5B04", Offset = "0x24C5B04", VA = "0x24C5B04", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x060130C6 RID: 78022 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130C6")]
			[Address(RVA = "0x24C5CE8", Offset = "0x24C5CE8", VA = "0x24C5CE8")]
			private void <>m__Finally1()
			{
			}

			// Token: 0x1700281E RID: 10270
			// (get) Token: 0x060130C7 RID: 78023 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x1700281E")]
			private object Current
			{
				[Token(Token = "0x60130C7")]
				[Address(RVA = "0x24C5D38", Offset = "0x24C5D38", VA = "0x24C5D38", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x060130C8 RID: 78024 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130C8")]
			[Address(RVA = "0x24C5D40", Offset = "0x24C5D40", VA = "0x24C5D40", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x1700281F RID: 10271
			// (get) Token: 0x060130C9 RID: 78025 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x1700281F")]
			private object Current
			{
				[Token(Token = "0x60130C9")]
				[Address(RVA = "0x24C5D80", Offset = "0x24C5D80", VA = "0x24C5D80", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EFE3 RID: 61411
			[Token(Token = "0x400EFE3")]
			[FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EFE4 RID: 61412
			[Token(Token = "0x400EFE4")]
			[FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EFE5 RID: 61413
			[Token(Token = "0x400EFE5")]
			[FieldOffset(Offset = "0x20")]
			public JSONClass <>4__this;

			// Token: 0x0400EFE6 RID: 61414
			[Token(Token = "0x400EFE6")]
			[FieldOffset(Offset = "0x28")]
			private Dictionary<string, JSONNode>.Enumerator <>7__wrap1;
		}
	}
}
