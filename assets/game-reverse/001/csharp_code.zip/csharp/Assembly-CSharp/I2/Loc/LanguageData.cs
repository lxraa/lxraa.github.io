﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025D6 RID: 9686
	[Token(Token = "0x20025D6")]
	[Serializable]
	public class LanguageData
	{
		// Token: 0x06012F00 RID: 77568 RVA: 0x0007A5C8 File Offset: 0x000787C8
		[Token(Token = "0x6012F00")]
		[Address(RVA = "0x26122FC", Offset = "0x26122FC", VA = "0x26122FC")]
		public bool IsEnabled()
		{
			return default(bool);
		}

		// Token: 0x06012F01 RID: 77569 RVA: 0x0007A5E0 File Offset: 0x000787E0
		[Token(Token = "0x6012F01")]
		[Address(RVA = "0x261230C", Offset = "0x261230C", VA = "0x261230C")]
		public bool IsLoaded()
		{
			return default(bool);
		}

		// Token: 0x06012F02 RID: 77570 RVA: 0x0007A5F8 File Offset: 0x000787F8
		[Token(Token = "0x6012F02")]
		[Address(RVA = "0x261231C", Offset = "0x261231C", VA = "0x261231C")]
		public bool CanBeUnloaded()
		{
			return default(bool);
		}

		// Token: 0x06012F03 RID: 77571 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F03")]
		[Address(RVA = "0x261232C", Offset = "0x261232C", VA = "0x261232C")]
		public void SetLoaded(bool loaded)
		{
		}

		// Token: 0x06012F04 RID: 77572 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F04")]
		[Address(RVA = "0x2612348", Offset = "0x2612348", VA = "0x2612348")]
		public LanguageData()
		{
		}

		// Token: 0x0400EEFA RID: 61178
		[Token(Token = "0x400EEFA")]
		[FieldOffset(Offset = "0x10")]
		public string Name;

		// Token: 0x0400EEFB RID: 61179
		[Token(Token = "0x400EEFB")]
		[FieldOffset(Offset = "0x18")]
		public string Code;

		// Token: 0x0400EEFC RID: 61180
		[Token(Token = "0x400EEFC")]
		[FieldOffset(Offset = "0x20")]
		public byte Flags;

		// Token: 0x0400EEFD RID: 61181
		[Token(Token = "0x400EEFD")]
		[FieldOffset(Offset = "0x21")]
		[NonSerialized]
		public bool Compressed;
	}
}
