﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025FF RID: 9727
	[Token(Token = "0x20025FF")]
	public class LocalizeTarget_UnityStandard_TextMesh : LocalizeTarget<TextMesh>
	{
		// Token: 0x06013020 RID: 77856 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013020")]
		[Address(RVA = "0x262329C", Offset = "0x262329C", VA = "0x262329C")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x06013021 RID: 77857 RVA: 0x0007AC70 File Offset: 0x00078E70
		[Token(Token = "0x6013021")]
		[Address(RVA = "0x2623360", Offset = "0x2623360", VA = "0x2623360", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013022 RID: 77858 RVA: 0x0007AC88 File Offset: 0x00078E88
		[Token(Token = "0x6013022")]
		[Address(RVA = "0x2623368", Offset = "0x2623368", VA = "0x2623368", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013023 RID: 77859 RVA: 0x0007ACA0 File Offset: 0x00078EA0
		[Token(Token = "0x6013023")]
		[Address(RVA = "0x2623370", Offset = "0x2623370", VA = "0x2623370", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x06013024 RID: 77860 RVA: 0x0007ACB8 File Offset: 0x00078EB8
		[Token(Token = "0x6013024")]
		[Address(RVA = "0x2623378", Offset = "0x2623378", VA = "0x2623378", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013025 RID: 77861 RVA: 0x0007ACD0 File Offset: 0x00078ED0
		[Token(Token = "0x6013025")]
		[Address(RVA = "0x2623380", Offset = "0x2623380", VA = "0x2623380", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013026 RID: 77862 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013026")]
		[Address(RVA = "0x2623388", Offset = "0x2623388", VA = "0x2623388", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06013027 RID: 77863 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013027")]
		[Address(RVA = "0x26234AC", Offset = "0x26234AC", VA = "0x26234AC", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06013028 RID: 77864 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013028")]
		[Address(RVA = "0x2623708", Offset = "0x2623708", VA = "0x2623708")]
		public LocalizeTarget_UnityStandard_TextMesh()
		{
		}

		// Token: 0x0400EFA6 RID: 61350
		[Token(Token = "0x400EFA6")]
		[FieldOffset(Offset = "0x20")]
		private TextAlignment mAlignment_RTL;

		// Token: 0x0400EFA7 RID: 61351
		[Token(Token = "0x400EFA7")]
		[FieldOffset(Offset = "0x24")]
		private TextAlignment mAlignment_LTR;

		// Token: 0x0400EFA8 RID: 61352
		[Token(Token = "0x400EFA8")]
		[FieldOffset(Offset = "0x28")]
		private bool mAlignmentWasRTL;

		// Token: 0x0400EFA9 RID: 61353
		[Token(Token = "0x400EFA9")]
		[FieldOffset(Offset = "0x29")]
		private bool mInitializeAlignment;
	}
}
