﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025CD RID: 9677
	[Token(Token = "0x20025CD")]
	public class I2CustomPersistentStorage : I2BasePersistentStorage
	{
		// Token: 0x06012EE5 RID: 77541 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EE5")]
		[Address(RVA = "0x245165C", Offset = "0x245165C", VA = "0x245165C")]
		public I2CustomPersistentStorage()
		{
		}
	}
}
