﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x02002614 RID: 9748
	[Token(Token = "0x2002614")]
	internal class ArabicMapping
	{
		// Token: 0x06013083 RID: 77955 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013083")]
		[Address(RVA = "0x2626E68", Offset = "0x2626E68", VA = "0x2626E68")]
		public ArabicMapping(int from, int to)
		{
		}

		// Token: 0x0400EFD3 RID: 61395
		[Token(Token = "0x400EFD3")]
		[FieldOffset(Offset = "0x10")]
		public int from;

		// Token: 0x0400EFD4 RID: 61396
		[Token(Token = "0x400EFD4")]
		[FieldOffset(Offset = "0x14")]
		public int to;
	}
}
