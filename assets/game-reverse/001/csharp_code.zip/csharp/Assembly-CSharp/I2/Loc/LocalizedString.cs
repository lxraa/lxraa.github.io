﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x0200260F RID: 9743
	[Token(Token = "0x200260F")]
	[Serializable]
	public struct LocalizedString
	{
		// Token: 0x0601306E RID: 77934 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601306E")]
		[Address(RVA = "0x2625610", Offset = "0x2625610", VA = "0x2625610")]
		public static implicit operator string(LocalizedString s)
		{
			return null;
		}

		// Token: 0x0601306F RID: 77935 RVA: 0x0007AEC8 File Offset: 0x000790C8
		[Token(Token = "0x601306F")]
		[Address(RVA = "0x26256CC", Offset = "0x26256CC", VA = "0x26256CC")]
		public static implicit operator LocalizedString(string term)
		{
			return default(LocalizedString);
		}

		// Token: 0x06013070 RID: 77936 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013070")]
		[Address(RVA = "0x2625708", Offset = "0x2625708", VA = "0x2625708")]
		public LocalizedString(LocalizedString str)
		{
		}

		// Token: 0x06013071 RID: 77937 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013071")]
		[Address(RVA = "0x2625614", Offset = "0x2625614", VA = "0x2625614", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x0400EFCA RID: 61386
		[Token(Token = "0x400EFCA")]
		[FieldOffset(Offset = "0x0")]
		public string mTerm;

		// Token: 0x0400EFCB RID: 61387
		[Token(Token = "0x400EFCB")]
		[FieldOffset(Offset = "0x8")]
		public bool mRTL_IgnoreArabicFix;

		// Token: 0x0400EFCC RID: 61388
		[Token(Token = "0x400EFCC")]
		[FieldOffset(Offset = "0xC")]
		public int mRTL_MaxLineLength;

		// Token: 0x0400EFCD RID: 61389
		[Token(Token = "0x400EFCD")]
		[FieldOffset(Offset = "0x10")]
		public bool mRTL_ConvertNumbers;

		// Token: 0x0400EFCE RID: 61390
		[Token(Token = "0x400EFCE")]
		[FieldOffset(Offset = "0x11")]
		public bool m_DontLocalizeParameters;
	}
}
