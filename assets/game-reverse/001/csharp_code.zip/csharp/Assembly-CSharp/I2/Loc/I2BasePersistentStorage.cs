﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025CC RID: 9676
	[Token(Token = "0x20025CC")]
	public abstract class I2BasePersistentStorage
	{
		// Token: 0x06012ED9 RID: 77529 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ED9")]
		[Address(RVA = "0x2451D50", Offset = "0x2451D50", VA = "0x2451D50", Slot = "4")]
		public virtual void SetSetting_String(string key, string value)
		{
		}

		// Token: 0x06012EDA RID: 77530 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EDA")]
		[Address(RVA = "0x2451FEC", Offset = "0x2451FEC", VA = "0x2451FEC", Slot = "5")]
		public virtual string GetSetting_String(string key, string defaultValue)
		{
			return null;
		}

		// Token: 0x06012EDB RID: 77531 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EDB")]
		[Address(RVA = "0x2452228", Offset = "0x2452228", VA = "0x2452228", Slot = "6")]
		public virtual void DeleteSetting(string key)
		{
		}

		// Token: 0x06012EDC RID: 77532 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EDC")]
		[Address(RVA = "0x2452428", Offset = "0x2452428", VA = "0x2452428", Slot = "7")]
		public virtual void ForceSaveSettings()
		{
		}

		// Token: 0x06012EDD RID: 77533 RVA: 0x0007A4C0 File Offset: 0x000786C0
		[Token(Token = "0x6012EDD")]
		[Address(RVA = "0x2452430", Offset = "0x2452430", VA = "0x2452430", Slot = "8")]
		public virtual bool HasSetting(string key)
		{
			return default(bool);
		}

		// Token: 0x06012EDE RID: 77534 RVA: 0x0007A4D8 File Offset: 0x000786D8
		[Token(Token = "0x6012EDE")]
		[Address(RVA = "0x245243C", Offset = "0x245243C", VA = "0x245243C", Slot = "9")]
		public virtual bool CanAccessFiles()
		{
			return default(bool);
		}

		// Token: 0x06012EDF RID: 77535 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EDF")]
		[Address(RVA = "0x2452444", Offset = "0x2452444", VA = "0x2452444")]
		private string UpdateFilename(PersistentStorage.eFileType fileType, string fileName)
		{
			return null;
		}

		// Token: 0x06012EE0 RID: 77536 RVA: 0x0007A4F0 File Offset: 0x000786F0
		[Token(Token = "0x6012EE0")]
		[Address(RVA = "0x24524DC", Offset = "0x24524DC", VA = "0x24524DC", Slot = "10")]
		public virtual bool SaveFile(PersistentStorage.eFileType fileType, string fileName, string data, bool logExceptions = true)
		{
			return default(bool);
		}

		// Token: 0x06012EE1 RID: 77537 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EE1")]
		[Address(RVA = "0x2452670", Offset = "0x2452670", VA = "0x2452670", Slot = "11")]
		public virtual string LoadFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			return null;
		}

		// Token: 0x06012EE2 RID: 77538 RVA: 0x0007A508 File Offset: 0x00078708
		[Token(Token = "0x6012EE2")]
		[Address(RVA = "0x24527F8", Offset = "0x24527F8", VA = "0x24527F8", Slot = "12")]
		public virtual bool DeleteFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			return default(bool);
		}

		// Token: 0x06012EE3 RID: 77539 RVA: 0x0007A520 File Offset: 0x00078720
		[Token(Token = "0x6012EE3")]
		[Address(RVA = "0x2452974", Offset = "0x2452974", VA = "0x2452974", Slot = "13")]
		public virtual bool HasFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			return default(bool);
		}

		// Token: 0x06012EE4 RID: 77540 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EE4")]
		[Address(RVA = "0x2452AF0", Offset = "0x2452AF0", VA = "0x2452AF0")]
		protected I2BasePersistentStorage()
		{
		}
	}
}
