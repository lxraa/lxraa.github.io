﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025D9 RID: 9689
	[Token(Token = "0x20025D9")]
	public class LanguageSourceAsset : ScriptableObject, ILanguageSource
	{
		// Token: 0x17002803 RID: 10243
		// (get) Token: 0x06012F11 RID: 77585 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012F12 RID: 77586 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002803")]
		public LanguageSourceData SourceData
		{
			[Token(Token = "0x6012F11")]
			[Address(RVA = "0x2613110", Offset = "0x2613110", VA = "0x2613110", Slot = "4")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012F12")]
			[Address(RVA = "0x2613118", Offset = "0x2613118", VA = "0x2613118", Slot = "5")]
			set
			{
			}
		}

		// Token: 0x06012F13 RID: 77587 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F13")]
		[Address(RVA = "0x2613120", Offset = "0x2613120", VA = "0x2613120")]
		public LanguageSourceAsset()
		{
		}

		// Token: 0x0400EF13 RID: 61203
		[Token(Token = "0x400EF13")]
		[FieldOffset(Offset = "0x18")]
		public LanguageSourceData mSource;
	}
}
