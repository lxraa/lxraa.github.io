﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025FD RID: 9725
	[Token(Token = "0x20025FD")]
	public class LocalizeTarget_UnityStandard_Prefab : LocalizeTarget<GameObject>
	{
		// Token: 0x0601300A RID: 77834 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601300A")]
		[Address(RVA = "0x2622A50", Offset = "0x2622A50", VA = "0x2622A50")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x0601300B RID: 77835 RVA: 0x0007AB68 File Offset: 0x00078D68
		[Token(Token = "0x601300B")]
		[Address(RVA = "0x2622AFC", Offset = "0x2622AFC", VA = "0x2622AFC", Slot = "4")]
		public override bool IsValid(Localize cmp)
		{
			return default(bool);
		}

		// Token: 0x0601300C RID: 77836 RVA: 0x0007AB80 File Offset: 0x00078D80
		[Token(Token = "0x601300C")]
		[Address(RVA = "0x2622B04", Offset = "0x2622B04", VA = "0x2622B04", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x0601300D RID: 77837 RVA: 0x0007AB98 File Offset: 0x00078D98
		[Token(Token = "0x601300D")]
		[Address(RVA = "0x2622B0C", Offset = "0x2622B0C", VA = "0x2622B0C", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x0601300E RID: 77838 RVA: 0x0007ABB0 File Offset: 0x00078DB0
		[Token(Token = "0x601300E")]
		[Address(RVA = "0x2622B14", Offset = "0x2622B14", VA = "0x2622B14", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x0601300F RID: 77839 RVA: 0x0007ABC8 File Offset: 0x00078DC8
		[Token(Token = "0x601300F")]
		[Address(RVA = "0x2622B1C", Offset = "0x2622B1C", VA = "0x2622B1C", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013010 RID: 77840 RVA: 0x0007ABE0 File Offset: 0x00078DE0
		[Token(Token = "0x6013010")]
		[Address(RVA = "0x2622B24", Offset = "0x2622B24", VA = "0x2622B24", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013011 RID: 77841 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013011")]
		[Address(RVA = "0x2622B2C", Offset = "0x2622B2C", VA = "0x2622B2C", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06013012 RID: 77842 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013012")]
		[Address(RVA = "0x2622B78", Offset = "0x2622B78", VA = "0x2622B78", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06013013 RID: 77843 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013013")]
		[Address(RVA = "0x2622D7C", Offset = "0x2622D7C", VA = "0x2622D7C")]
		private Transform InstantiateNewPrefab(Localize cmp, string mainTranslation)
		{
			return null;
		}

		// Token: 0x06013014 RID: 77844 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013014")]
		[Address(RVA = "0x2622F30", Offset = "0x2622F30", VA = "0x2622F30")]
		public LocalizeTarget_UnityStandard_Prefab()
		{
		}
	}
}
