﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025D5 RID: 9685
	[Token(Token = "0x20025D5")]
	public class TranslationJob : IDisposable
	{
		// Token: 0x06012EFF RID: 77567 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EFF")]
		[Address(RVA = "0x26122F8", Offset = "0x26122F8", VA = "0x26122F8", Slot = "5")]
		public virtual void Dispose()
		{
		}
	}
}
