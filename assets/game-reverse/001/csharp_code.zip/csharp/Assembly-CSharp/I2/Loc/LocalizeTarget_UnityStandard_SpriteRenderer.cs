﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025FE RID: 9726
	[Token(Token = "0x20025FE")]
	public class LocalizeTarget_UnityStandard_SpriteRenderer : LocalizeTarget<SpriteRenderer>
	{
		// Token: 0x06013016 RID: 77846 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013016")]
		[Address(RVA = "0x2622F7C", Offset = "0x2622F7C", VA = "0x2622F7C")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x06013017 RID: 77847 RVA: 0x0007ABF8 File Offset: 0x00078DF8
		[Token(Token = "0x6013017")]
		[Address(RVA = "0x2623040", Offset = "0x2623040", VA = "0x2623040", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013018 RID: 77848 RVA: 0x0007AC10 File Offset: 0x00078E10
		[Token(Token = "0x6013018")]
		[Address(RVA = "0x2623048", Offset = "0x2623048", VA = "0x2623048", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013019 RID: 77849 RVA: 0x0007AC28 File Offset: 0x00078E28
		[Token(Token = "0x6013019")]
		[Address(RVA = "0x2623050", Offset = "0x2623050", VA = "0x2623050", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x0601301A RID: 77850 RVA: 0x0007AC40 File Offset: 0x00078E40
		[Token(Token = "0x601301A")]
		[Address(RVA = "0x2623058", Offset = "0x2623058", VA = "0x2623058", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x0601301B RID: 77851 RVA: 0x0007AC58 File Offset: 0x00078E58
		[Token(Token = "0x601301B")]
		[Address(RVA = "0x2623060", Offset = "0x2623060", VA = "0x2623060", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x0601301C RID: 77852 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601301C")]
		[Address(RVA = "0x2623068", Offset = "0x2623068", VA = "0x2623068", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x0601301D RID: 77853 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601301D")]
		[Address(RVA = "0x2623154", Offset = "0x2623154", VA = "0x2623154", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x0601301E RID: 77854 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601301E")]
		[Address(RVA = "0x2623250", Offset = "0x2623250", VA = "0x2623250")]
		public LocalizeTarget_UnityStandard_SpriteRenderer()
		{
		}
	}
}
