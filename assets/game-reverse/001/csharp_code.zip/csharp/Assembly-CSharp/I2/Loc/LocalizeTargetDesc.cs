﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025F4 RID: 9716
	[Token(Token = "0x20025F4")]
	public abstract class LocalizeTargetDesc<T> : ILocalizeTargetDescriptor where T : ILocalizeTarget
	{
		// Token: 0x06012FC8 RID: 77768 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012FC8")]
		public override ILocalizeTarget CreateTarget(Localize cmp)
		{
			return null;
		}

		// Token: 0x06012FC9 RID: 77769 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012FC9")]
		public override Type GetTargetType()
		{
			return null;
		}

		// Token: 0x06012FCA RID: 77770 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FCA")]
		protected LocalizeTargetDesc()
		{
		}
	}
}
