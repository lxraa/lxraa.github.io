﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025D1 RID: 9681
	[Token(Token = "0x20025D1")]
	public enum ePluralType
	{
		// Token: 0x0400EEED RID: 61165
		[Token(Token = "0x400EEED")]
		Zero,
		// Token: 0x0400EEEE RID: 61166
		[Token(Token = "0x400EEEE")]
		One,
		// Token: 0x0400EEEF RID: 61167
		[Token(Token = "0x400EEEF")]
		Two,
		// Token: 0x0400EEF0 RID: 61168
		[Token(Token = "0x400EEF0")]
		Few,
		// Token: 0x0400EEF1 RID: 61169
		[Token(Token = "0x400EEF1")]
		Many,
		// Token: 0x0400EEF2 RID: 61170
		[Token(Token = "0x400EEF2")]
		Plural
	}
}
