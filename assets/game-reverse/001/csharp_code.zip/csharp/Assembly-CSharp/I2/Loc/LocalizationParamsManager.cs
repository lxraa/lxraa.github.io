﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x0200260D RID: 9741
	[Token(Token = "0x200260D")]
	public class LocalizationParamsManager : MonoBehaviour, ILocalizationParamsManager
	{
		// Token: 0x06013067 RID: 77927 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013067")]
		[Address(RVA = "0x2625074", Offset = "0x2625074", VA = "0x2625074", Slot = "4")]
		public string GetParameterValue(string ParamName)
		{
			return null;
		}

		// Token: 0x06013068 RID: 77928 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013068")]
		[Address(RVA = "0x2625138", Offset = "0x2625138", VA = "0x2625138")]
		public void SetParameterValue(string ParamName, string ParamValue, bool localize = true)
		{
		}

		// Token: 0x06013069 RID: 77929 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013069")]
		[Address(RVA = "0x2625318", Offset = "0x2625318", VA = "0x2625318")]
		public void OnLocalize()
		{
		}

		// Token: 0x0601306A RID: 77930 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601306A")]
		[Address(RVA = "0x26253CC", Offset = "0x26253CC", VA = "0x26253CC", Slot = "5")]
		public virtual void OnEnable()
		{
		}

		// Token: 0x0601306B RID: 77931 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601306B")]
		[Address(RVA = "0x26253DC", Offset = "0x26253DC", VA = "0x26253DC")]
		public void DoAutoRegister()
		{
		}

		// Token: 0x0601306C RID: 77932 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601306C")]
		[Address(RVA = "0x2625508", Offset = "0x2625508", VA = "0x2625508")]
		public void OnDisable()
		{
		}

		// Token: 0x0601306D RID: 77933 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601306D")]
		[Address(RVA = "0x2625588", Offset = "0x2625588", VA = "0x2625588")]
		public LocalizationParamsManager()
		{
		}

		// Token: 0x0400EFC6 RID: 61382
		[Token(Token = "0x400EFC6")]
		[FieldOffset(Offset = "0x18")]
		[SerializeField]
		public List<LocalizationParamsManager.ParamValue> _Params;

		// Token: 0x0400EFC7 RID: 61383
		[Token(Token = "0x400EFC7")]
		[FieldOffset(Offset = "0x20")]
		public bool _IsGlobalManager;

		// Token: 0x0200260E RID: 9742
		[Token(Token = "0x200260E")]
		[Serializable]
		public struct ParamValue
		{
			// Token: 0x0400EFC8 RID: 61384
			[Token(Token = "0x400EFC8")]
			[FieldOffset(Offset = "0x0")]
			public string Name;

			// Token: 0x0400EFC9 RID: 61385
			[Token(Token = "0x400EFC9")]
			[FieldOffset(Offset = "0x8")]
			public string Value;
		}
	}
}
