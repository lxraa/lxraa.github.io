﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025F1 RID: 9713
	[Token(Token = "0x20025F1")]
	public abstract class ILocalizeTarget : ScriptableObject
	{
		// Token: 0x06012FB9 RID: 77753
		[Token(Token = "0x6012FB9")]
		public abstract bool IsValid(Localize cmp);

		// Token: 0x06012FBA RID: 77754
		[Token(Token = "0x6012FBA")]
		public abstract void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm);

		// Token: 0x06012FBB RID: 77755
		[Token(Token = "0x6012FBB")]
		public abstract void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation);

		// Token: 0x06012FBC RID: 77756
		[Token(Token = "0x6012FBC")]
		public abstract bool CanUseSecondaryTerm();

		// Token: 0x06012FBD RID: 77757
		[Token(Token = "0x6012FBD")]
		public abstract bool AllowMainTermToBeRTL();

		// Token: 0x06012FBE RID: 77758
		[Token(Token = "0x6012FBE")]
		public abstract bool AllowSecondTermToBeRTL();

		// Token: 0x06012FBF RID: 77759
		[Token(Token = "0x6012FBF")]
		public abstract eTermType GetPrimaryTermType(Localize cmp);

		// Token: 0x06012FC0 RID: 77760
		[Token(Token = "0x6012FC0")]
		public abstract eTermType GetSecondaryTermType(Localize cmp);

		// Token: 0x06012FC1 RID: 77761 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FC1")]
		[Address(RVA = "0x26209E0", Offset = "0x26209E0", VA = "0x26209E0")]
		protected ILocalizeTarget()
		{
		}
	}
}
