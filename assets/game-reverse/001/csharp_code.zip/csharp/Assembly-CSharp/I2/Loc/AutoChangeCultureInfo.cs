﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02002605 RID: 9733
	[Token(Token = "0x2002605")]
	public class AutoChangeCultureInfo : MonoBehaviour
	{
		// Token: 0x0601304D RID: 77901 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601304D")]
		[Address(RVA = "0x2624488", Offset = "0x2624488", VA = "0x2624488")]
		public void Start()
		{
		}

		// Token: 0x0601304E RID: 77902 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601304E")]
		[Address(RVA = "0x26244D8", Offset = "0x26244D8", VA = "0x26244D8")]
		public AutoChangeCultureInfo()
		{
		}
	}
}
