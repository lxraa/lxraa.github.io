﻿using System;
using System.Collections.Generic;
using System.Linq;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Events;

namespace I2.Loc
{
	// Token: 0x020025E4 RID: 9700
	[Token(Token = "0x20025E4")]
	public class Localize : MonoBehaviour
	{
		// Token: 0x17002806 RID: 10246
		// (get) Token: 0x06012F4C RID: 77644 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012F4D RID: 77645 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002806")]
		public string Term
		{
			[Token(Token = "0x6012F4C")]
			[Address(RVA = "0x2618AE8", Offset = "0x2618AE8", VA = "0x2618AE8")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012F4D")]
			[Address(RVA = "0x2618AF0", Offset = "0x2618AF0", VA = "0x2618AF0")]
			set
			{
			}
		}

		// Token: 0x17002807 RID: 10247
		// (get) Token: 0x06012F4E RID: 77646 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012F4F RID: 77647 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002807")]
		public string SecondaryTerm
		{
			[Token(Token = "0x6012F4E")]
			[Address(RVA = "0x2618B48", Offset = "0x2618B48", VA = "0x2618B48")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012F4F")]
			[Address(RVA = "0x2618B50", Offset = "0x2618B50", VA = "0x2618B50")]
			set
			{
			}
		}

		// Token: 0x06012F50 RID: 77648 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F50")]
		[Address(RVA = "0x2618BD4", Offset = "0x2618BD4", VA = "0x2618BD4")]
		private void Awake()
		{
		}

		// Token: 0x06012F51 RID: 77649 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F51")]
		[Address(RVA = "0x2619CF4", Offset = "0x2619CF4", VA = "0x2619CF4")]
		private void OnEnable()
		{
		}

		// Token: 0x06012F52 RID: 77650 RVA: 0x0007A760 File Offset: 0x00078960
		[Token(Token = "0x6012F52")]
		[Address(RVA = "0x2619CFC", Offset = "0x2619CFC", VA = "0x2619CFC")]
		public bool HasCallback()
		{
			return default(bool);
		}

		// Token: 0x06012F53 RID: 77651 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F53")]
		[Address(RVA = "0x2619420", Offset = "0x2619420", VA = "0x2619420")]
		public void OnLocalize(bool Force = false)
		{
		}

		// Token: 0x06012F54 RID: 77652 RVA: 0x0007A778 File Offset: 0x00078978
		[Token(Token = "0x6012F54")]
		[Address(RVA = "0x2618F70", Offset = "0x2618F70", VA = "0x2618F70")]
		public bool FindTarget()
		{
			return default(bool);
		}

		// Token: 0x06012F55 RID: 77653 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F55")]
		[Address(RVA = "0x2619D44", Offset = "0x2619D44", VA = "0x2619D44")]
		public void GetFinalTerms(out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06012F56 RID: 77654 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F56")]
		[Address(RVA = "0x261A53C", Offset = "0x261A53C", VA = "0x261A53C")]
		public string GetMainTargetsText()
		{
			return null;
		}

		// Token: 0x06012F57 RID: 77655 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F57")]
		[Address(RVA = "0x261A604", Offset = "0x261A604", VA = "0x261A604")]
		public void SetFinalTerms(string Main, string Secondary, out string primaryTerm, out string secondaryTerm, bool RemoveNonASCII)
		{
		}

		// Token: 0x06012F58 RID: 77656 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F58")]
		[Address(RVA = "0x2618AF4", Offset = "0x2618AF4", VA = "0x2618AF4")]
		public void SetTerm(string primary)
		{
		}

		// Token: 0x06012F59 RID: 77657 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F59")]
		[Address(RVA = "0x2618B5C", Offset = "0x2618B5C", VA = "0x2618B5C")]
		public void SetTerm(string primary, string secondary)
		{
		}

		// Token: 0x06012F5A RID: 77658 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F5A")]
		internal T GetSecondaryTranslatedObj<T>(ref string mainTranslation, ref string secondaryTranslation) where T : UnityEngine.Object
		{
			return null;
		}

		// Token: 0x06012F5B RID: 77659 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F5B")]
		[Address(RVA = "0x2618C08", Offset = "0x2618C08", VA = "0x2618C08")]
		public void UpdateAssetDictionary()
		{
		}

		// Token: 0x06012F5C RID: 77660 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F5C")]
		internal T GetObject<T>(string Translation) where T : UnityEngine.Object
		{
			return null;
		}

		// Token: 0x06012F5D RID: 77661 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F5D")]
		private T GetTranslatedObject<T>(string Translation) where T : UnityEngine.Object
		{
			return null;
		}

		// Token: 0x06012F5E RID: 77662 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F5E")]
		[Address(RVA = "0x261A650", Offset = "0x261A650", VA = "0x261A650")]
		private void DeserializeTranslation(string translation, out string value, out string secondary)
		{
		}

		// Token: 0x06012F5F RID: 77663 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F5F")]
		public T FindTranslatedObject<T>(string value) where T : UnityEngine.Object
		{
			return null;
		}

		// Token: 0x06012F60 RID: 77664 RVA: 0x0007A790 File Offset: 0x00078990
		[Token(Token = "0x6012F60")]
		[Address(RVA = "0x261A760", Offset = "0x261A760", VA = "0x261A760")]
		public bool HasTranslatedObject(UnityEngine.Object Obj)
		{
			return default(bool);
		}

		// Token: 0x06012F61 RID: 77665 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F61")]
		[Address(RVA = "0x261AC18", Offset = "0x261AC18", VA = "0x261AC18")]
		public void AddTranslatedObject(UnityEngine.Object Obj)
		{
		}

		// Token: 0x06012F62 RID: 77666 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F62")]
		[Address(RVA = "0x261AD04", Offset = "0x261AD04", VA = "0x261AD04")]
		public void SetGlobalLanguage(string Language)
		{
		}

		// Token: 0x06012F63 RID: 77667 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F63")]
		[Address(RVA = "0x261AE28", Offset = "0x261AE28", VA = "0x261AE28")]
		public Localize()
		{
		}

		// Token: 0x0400EF53 RID: 61267
		[Token(Token = "0x400EF53")]
		[FieldOffset(Offset = "0x18")]
		public string mTerm;

		// Token: 0x0400EF54 RID: 61268
		[Token(Token = "0x400EF54")]
		[FieldOffset(Offset = "0x20")]
		public string mTermSecondary;

		// Token: 0x0400EF55 RID: 61269
		[Token(Token = "0x400EF55")]
		[FieldOffset(Offset = "0x28")]
		[NonSerialized]
		public string FinalTerm;

		// Token: 0x0400EF56 RID: 61270
		[Token(Token = "0x400EF56")]
		[FieldOffset(Offset = "0x30")]
		[NonSerialized]
		public string FinalSecondaryTerm;

		// Token: 0x0400EF57 RID: 61271
		[Token(Token = "0x400EF57")]
		[FieldOffset(Offset = "0x38")]
		public Localize.TermModification PrimaryTermModifier;

		// Token: 0x0400EF58 RID: 61272
		[Token(Token = "0x400EF58")]
		[FieldOffset(Offset = "0x3C")]
		public Localize.TermModification SecondaryTermModifier;

		// Token: 0x0400EF59 RID: 61273
		[Token(Token = "0x400EF59")]
		[FieldOffset(Offset = "0x40")]
		public string TermPrefix;

		// Token: 0x0400EF5A RID: 61274
		[Token(Token = "0x400EF5A")]
		[FieldOffset(Offset = "0x48")]
		public string TermSuffix;

		// Token: 0x0400EF5B RID: 61275
		[Token(Token = "0x400EF5B")]
		[FieldOffset(Offset = "0x50")]
		public bool LocalizeOnAwake;

		// Token: 0x0400EF5C RID: 61276
		[Token(Token = "0x400EF5C")]
		[FieldOffset(Offset = "0x58")]
		private string LastLocalizedLanguage;

		// Token: 0x0400EF5D RID: 61277
		[Token(Token = "0x400EF5D")]
		[FieldOffset(Offset = "0x60")]
		public bool IgnoreRTL;

		// Token: 0x0400EF5E RID: 61278
		[Token(Token = "0x400EF5E")]
		[FieldOffset(Offset = "0x64")]
		public int MaxCharactersInRTL;

		// Token: 0x0400EF5F RID: 61279
		[Token(Token = "0x400EF5F")]
		[FieldOffset(Offset = "0x68")]
		public bool IgnoreNumbersInRTL;

		// Token: 0x0400EF60 RID: 61280
		[Token(Token = "0x400EF60")]
		[FieldOffset(Offset = "0x69")]
		public bool CorrectAlignmentForRTL;

		// Token: 0x0400EF61 RID: 61281
		[Token(Token = "0x400EF61")]
		[FieldOffset(Offset = "0x6A")]
		public bool AddSpacesToJoinedLanguages;

		// Token: 0x0400EF62 RID: 61282
		[Token(Token = "0x400EF62")]
		[FieldOffset(Offset = "0x6B")]
		public bool AllowLocalizedParameters;

		// Token: 0x0400EF63 RID: 61283
		[Token(Token = "0x400EF63")]
		[FieldOffset(Offset = "0x70")]
		public List<UnityEngine.Object> TranslatedObjects;

		// Token: 0x0400EF64 RID: 61284
		[Token(Token = "0x400EF64")]
		[FieldOffset(Offset = "0x78")]
		[NonSerialized]
		public Dictionary<string, UnityEngine.Object> mAssetDictionary;

		// Token: 0x0400EF65 RID: 61285
		[Token(Token = "0x400EF65")]
		[FieldOffset(Offset = "0x80")]
		public UnityEvent LocalizeEvent;

		// Token: 0x0400EF66 RID: 61286
		[Token(Token = "0x400EF66")]
		[FieldOffset(Offset = "0x0")]
		public static string MainTranslation;

		// Token: 0x0400EF67 RID: 61287
		[Token(Token = "0x400EF67")]
		[FieldOffset(Offset = "0x8")]
		public static string SecondaryTranslation;

		// Token: 0x0400EF68 RID: 61288
		[Token(Token = "0x400EF68")]
		[FieldOffset(Offset = "0x10")]
		public static string CallBackTerm;

		// Token: 0x0400EF69 RID: 61289
		[Token(Token = "0x400EF69")]
		[FieldOffset(Offset = "0x18")]
		public static string CallBackSecondaryTerm;

		// Token: 0x0400EF6A RID: 61290
		[Token(Token = "0x400EF6A")]
		[FieldOffset(Offset = "0x20")]
		public static Localize CurrentLocalizeComponent;

		// Token: 0x0400EF6B RID: 61291
		[Token(Token = "0x400EF6B")]
		[FieldOffset(Offset = "0x88")]
		public bool AlwaysForceLocalize;

		// Token: 0x0400EF6C RID: 61292
		[Token(Token = "0x400EF6C")]
		[FieldOffset(Offset = "0x90")]
		[SerializeField]
		public EventCallback LocalizeCallBack;

		// Token: 0x0400EF6D RID: 61293
		[Token(Token = "0x400EF6D")]
		[FieldOffset(Offset = "0x98")]
		public bool mGUI_ShowReferences;

		// Token: 0x0400EF6E RID: 61294
		[Token(Token = "0x400EF6E")]
		[FieldOffset(Offset = "0x99")]
		public bool mGUI_ShowTems;

		// Token: 0x0400EF6F RID: 61295
		[Token(Token = "0x400EF6F")]
		[FieldOffset(Offset = "0x9A")]
		public bool mGUI_ShowCallback;

		// Token: 0x0400EF70 RID: 61296
		[Token(Token = "0x400EF70")]
		[FieldOffset(Offset = "0xA0")]
		public ILocalizeTarget mLocalizeTarget;

		// Token: 0x0400EF71 RID: 61297
		[Token(Token = "0x400EF71")]
		[FieldOffset(Offset = "0xA8")]
		public string mLocalizeTargetName;

		// Token: 0x020025E5 RID: 9701
		[Token(Token = "0x20025E5")]
		public enum TermModification
		{
			// Token: 0x0400EF73 RID: 61299
			[Token(Token = "0x400EF73")]
			DontModify,
			// Token: 0x0400EF74 RID: 61300
			[Token(Token = "0x400EF74")]
			ToUpper,
			// Token: 0x0400EF75 RID: 61301
			[Token(Token = "0x400EF75")]
			ToLower,
			// Token: 0x0400EF76 RID: 61302
			[Token(Token = "0x400EF76")]
			ToUpperFirst,
			// Token: 0x0400EF77 RID: 61303
			[Token(Token = "0x400EF77")]
			ToTitle
		}

		// Token: 0x020025E6 RID: 9702
		[Token(Token = "0x20025E6")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06012F65 RID: 77669 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012F65")]
			[Address(RVA = "0x261B0B8", Offset = "0x261B0B8", VA = "0x261B0B8")]
			public <>c()
			{
			}

			// Token: 0x06012F66 RID: 77670 RVA: 0x0007A7A8 File Offset: 0x000789A8
			[Token(Token = "0x6012F66")]
			[Address(RVA = "0x261B0C0", Offset = "0x261B0C0", VA = "0x261B0C0")]
			internal bool <UpdateAssetDictionary>b__49_0(UnityEngine.Object x)
			{
				return default(bool);
			}

			// Token: 0x06012F67 RID: 77671 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012F67")]
			[Address(RVA = "0x261B11C", Offset = "0x261B11C", VA = "0x261B11C")]
			internal string <UpdateAssetDictionary>b__49_1(UnityEngine.Object o)
			{
				return null;
			}

			// Token: 0x06012F68 RID: 77672 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012F68")]
			[Address(RVA = "0x261B134", Offset = "0x261B134", VA = "0x261B134")]
			internal string <UpdateAssetDictionary>b__49_2(IGrouping<string, UnityEngine.Object> g)
			{
				return null;
			}

			// Token: 0x06012F69 RID: 77673 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012F69")]
			[Address(RVA = "0x261B1D0", Offset = "0x261B1D0", VA = "0x261B1D0")]
			internal UnityEngine.Object <UpdateAssetDictionary>b__49_3(IGrouping<string, UnityEngine.Object> g)
			{
				return null;
			}

			// Token: 0x0400EF78 RID: 61304
			[Token(Token = "0x400EF78")]
			[FieldOffset(Offset = "0x0")]
			public static readonly Localize.<>c <>9;

			// Token: 0x0400EF79 RID: 61305
			[Token(Token = "0x400EF79")]
			[FieldOffset(Offset = "0x8")]
			public static Predicate<UnityEngine.Object> <>9__49_0;

			// Token: 0x0400EF7A RID: 61306
			[Token(Token = "0x400EF7A")]
			[FieldOffset(Offset = "0x10")]
			public static Func<UnityEngine.Object, string> <>9__49_1;

			// Token: 0x0400EF7B RID: 61307
			[Token(Token = "0x400EF7B")]
			[FieldOffset(Offset = "0x18")]
			public static Func<IGrouping<string, UnityEngine.Object>, string> <>9__49_2;

			// Token: 0x0400EF7C RID: 61308
			[Token(Token = "0x400EF7C")]
			[FieldOffset(Offset = "0x20")]
			public static Func<IGrouping<string, UnityEngine.Object>, UnityEngine.Object> <>9__49_3;
		}
	}
}
