﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025D2 RID: 9682
	[Token(Token = "0x20025D2")]
	public static class GoogleLanguages
	{
		// Token: 0x06012EF3 RID: 77555 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EF3")]
		[Address(RVA = "0x2453D00", Offset = "0x2453D00", VA = "0x2453D00")]
		public static string GetLanguageCode(string Filter, bool ShowWarnings = false)
		{
			return null;
		}

		// Token: 0x06012EF4 RID: 77556 RVA: 0x0007A550 File Offset: 0x00078750
		[Token(Token = "0x6012EF4")]
		[Address(RVA = "0x2453FB4", Offset = "0x2453FB4", VA = "0x2453FB4")]
		private static bool LanguageMatchesFilter(string Language, string[] Filters)
		{
			return default(bool);
		}

		// Token: 0x06012EF5 RID: 77557 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EF5")]
		[Address(RVA = "0x24540FC", Offset = "0x24540FC", VA = "0x24540FC")]
		public static void UnPackCodeFromLanguageName(string CodedLanguage, out string Language, out string code)
		{
		}

		// Token: 0x06012EF6 RID: 77558 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EF6")]
		[Address(RVA = "0x2454280", Offset = "0x2454280", VA = "0x2454280")]
		public static string GetLanguageName(string code, bool useParenthesesForRegion = false, bool allowDiscardRegion = true)
		{
			return null;
		}

		// Token: 0x06012EF7 RID: 77559 RVA: 0x0007A568 File Offset: 0x00078768
		[Token(Token = "0x6012EF7")]
		[Address(RVA = "0x245457C", Offset = "0x245457C", VA = "0x245457C")]
		public static bool LanguageCode_HasJoinedWord(string languageCode)
		{
			return default(bool);
		}

		// Token: 0x06012EF8 RID: 77560 RVA: 0x0007A580 File Offset: 0x00078780
		[Token(Token = "0x6012EF8")]
		[Address(RVA = "0x245473C", Offset = "0x245473C", VA = "0x245473C")]
		private static int GetPluralRule(string langCode)
		{
			return 0;
		}

		// Token: 0x06012EF9 RID: 77561 RVA: 0x0007A598 File Offset: 0x00078798
		[Token(Token = "0x6012EF9")]
		[Address(RVA = "0x245491C", Offset = "0x245491C", VA = "0x245491C")]
		public static ePluralType GetPluralType(string langCode, int n)
		{
			return ePluralType.Zero;
		}

		// Token: 0x06012EFA RID: 77562 RVA: 0x0007A5B0 File Offset: 0x000787B0
		[Token(Token = "0x6012EFA")]
		[Address(RVA = "0x2454FA4", Offset = "0x2454FA4", VA = "0x2454FA4")]
		private static bool inRange(int amount, int min, int max)
		{
			return default(bool);
		}

		// Token: 0x0400EEF3 RID: 61171
		[Token(Token = "0x400EEF3")]
		[FieldOffset(Offset = "0x0")]
		public static Dictionary<string, GoogleLanguages.LanguageCodeDef> mLanguageDef;

		// Token: 0x020025D3 RID: 9683
		[Token(Token = "0x20025D3")]
		public struct LanguageCodeDef
		{
			// Token: 0x0400EEF4 RID: 61172
			[Token(Token = "0x400EEF4")]
			[FieldOffset(Offset = "0x0")]
			public string Code;

			// Token: 0x0400EEF5 RID: 61173
			[Token(Token = "0x400EEF5")]
			[FieldOffset(Offset = "0x8")]
			public string GoogleCode;

			// Token: 0x0400EEF6 RID: 61174
			[Token(Token = "0x400EEF6")]
			[FieldOffset(Offset = "0x10")]
			public bool HasJoinedWords;

			// Token: 0x0400EEF7 RID: 61175
			[Token(Token = "0x400EEF7")]
			[FieldOffset(Offset = "0x14")]
			public int PluralRule;
		}
	}
}
