﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025FA RID: 9722
	[Token(Token = "0x20025FA")]
	public class LocalizeTarget_UnityStandard_Child : LocalizeTarget<GameObject>
	{
		// Token: 0x06012FF3 RID: 77811 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FF3")]
		[Address(RVA = "0x2622224", Offset = "0x2622224", VA = "0x2622224")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x06012FF4 RID: 77812 RVA: 0x0007AA48 File Offset: 0x00078C48
		[Token(Token = "0x6012FF4")]
		[Address(RVA = "0x26222D0", Offset = "0x26222D0", VA = "0x26222D0", Slot = "4")]
		public override bool IsValid(Localize cmp)
		{
			return default(bool);
		}

		// Token: 0x06012FF5 RID: 77813 RVA: 0x0007AA60 File Offset: 0x00078C60
		[Token(Token = "0x6012FF5")]
		[Address(RVA = "0x2622304", Offset = "0x2622304", VA = "0x2622304", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06012FF6 RID: 77814 RVA: 0x0007AA78 File Offset: 0x00078C78
		[Token(Token = "0x6012FF6")]
		[Address(RVA = "0x262230C", Offset = "0x262230C", VA = "0x262230C", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06012FF7 RID: 77815 RVA: 0x0007AA90 File Offset: 0x00078C90
		[Token(Token = "0x6012FF7")]
		[Address(RVA = "0x2622314", Offset = "0x2622314", VA = "0x2622314", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x06012FF8 RID: 77816 RVA: 0x0007AAA8 File Offset: 0x00078CA8
		[Token(Token = "0x6012FF8")]
		[Address(RVA = "0x262231C", Offset = "0x262231C", VA = "0x262231C", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06012FF9 RID: 77817 RVA: 0x0007AAC0 File Offset: 0x00078CC0
		[Token(Token = "0x6012FF9")]
		[Address(RVA = "0x2622324", Offset = "0x2622324", VA = "0x2622324", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06012FFA RID: 77818 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FFA")]
		[Address(RVA = "0x262232C", Offset = "0x262232C", VA = "0x262232C", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06012FFB RID: 77819 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FFB")]
		[Address(RVA = "0x2622378", Offset = "0x2622378", VA = "0x2622378", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06012FFC RID: 77820 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FFC")]
		[Address(RVA = "0x26224B8", Offset = "0x26224B8", VA = "0x26224B8")]
		public LocalizeTarget_UnityStandard_Child()
		{
		}
	}
}
