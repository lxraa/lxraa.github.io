﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace I2.Loc
{
	// Token: 0x02002600 RID: 9728
	[Token(Token = "0x2002600")]
	public class LocalizeTarget_UnityUI_Image : LocalizeTarget<Image>
	{
		// Token: 0x0601302A RID: 77866 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601302A")]
		[Address(RVA = "0x2623764", Offset = "0x2623764", VA = "0x2623764")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x0601302B RID: 77867 RVA: 0x0007ACE8 File Offset: 0x00078EE8
		[Token(Token = "0x601302B")]
		[Address(RVA = "0x2623828", Offset = "0x2623828", VA = "0x2623828", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x0601302C RID: 77868 RVA: 0x0007AD00 File Offset: 0x00078F00
		[Token(Token = "0x601302C")]
		[Address(RVA = "0x2623830", Offset = "0x2623830", VA = "0x2623830", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x0601302D RID: 77869 RVA: 0x0007AD18 File Offset: 0x00078F18
		[Token(Token = "0x601302D")]
		[Address(RVA = "0x2623838", Offset = "0x2623838", VA = "0x2623838", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x0601302E RID: 77870 RVA: 0x0007AD30 File Offset: 0x00078F30
		[Token(Token = "0x601302E")]
		[Address(RVA = "0x2623840", Offset = "0x2623840", VA = "0x2623840", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x0601302F RID: 77871 RVA: 0x0007AD48 File Offset: 0x00078F48
		[Token(Token = "0x601302F")]
		[Address(RVA = "0x26238C0", Offset = "0x26238C0", VA = "0x26238C0", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013030 RID: 77872 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013030")]
		[Address(RVA = "0x26238C8", Offset = "0x26238C8", VA = "0x26238C8", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06013031 RID: 77873 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013031")]
		[Address(RVA = "0x2623A64", Offset = "0x2623A64", VA = "0x2623A64", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06013032 RID: 77874 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013032")]
		[Address(RVA = "0x2623B54", Offset = "0x2623B54", VA = "0x2623B54")]
		public LocalizeTarget_UnityUI_Image()
		{
		}
	}
}
