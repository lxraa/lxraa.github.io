﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x02002603 RID: 9731
	[Token(Token = "0x2002603")]
	public enum eTermType
	{
		// Token: 0x0400EFAF RID: 61359
		[Token(Token = "0x400EFAF")]
		Text,
		// Token: 0x0400EFB0 RID: 61360
		[Token(Token = "0x400EFB0")]
		Font,
		// Token: 0x0400EFB1 RID: 61361
		[Token(Token = "0x400EFB1")]
		Texture,
		// Token: 0x0400EFB2 RID: 61362
		[Token(Token = "0x400EFB2")]
		AudioClip,
		// Token: 0x0400EFB3 RID: 61363
		[Token(Token = "0x400EFB3")]
		GameObject,
		// Token: 0x0400EFB4 RID: 61364
		[Token(Token = "0x400EFB4")]
		Sprite,
		// Token: 0x0400EFB5 RID: 61365
		[Token(Token = "0x400EFB5")]
		Material,
		// Token: 0x0400EFB6 RID: 61366
		[Token(Token = "0x400EFB6")]
		Child,
		// Token: 0x0400EFB7 RID: 61367
		[Token(Token = "0x400EFB7")]
		Mesh,
		// Token: 0x0400EFB8 RID: 61368
		[Token(Token = "0x400EFB8")]
		TextMeshPFont,
		// Token: 0x0400EFB9 RID: 61369
		[Token(Token = "0x400EFB9")]
		Object
	}
}
