﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x02002617 RID: 9751
	[Token(Token = "0x2002617")]
	internal class RTLFixerTool
	{
		// Token: 0x06013088 RID: 77960 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013088")]
		[Address(RVA = "0x2628970", Offset = "0x2628970", VA = "0x2628970")]
		internal static string RemoveTashkeel(string str, out List<TashkeelLocation> tashkeelLocation)
		{
			return null;
		}

		// Token: 0x06013089 RID: 77961 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013089")]
		[Address(RVA = "0x2628EA0", Offset = "0x2628EA0", VA = "0x2628EA0")]
		internal static char[] ReturnTashkeel(char[] letters, List<TashkeelLocation> tashkeelLocation)
		{
			return null;
		}

		// Token: 0x0601308A RID: 77962 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601308A")]
		[Address(RVA = "0x2625E60", Offset = "0x2625E60", VA = "0x2625E60")]
		internal static string FixLine(string str)
		{
			return null;
		}

		// Token: 0x0601308B RID: 77963 RVA: 0x0007AF10 File Offset: 0x00079110
		[Token(Token = "0x601308B")]
		[Address(RVA = "0x26290C8", Offset = "0x26290C8", VA = "0x26290C8")]
		internal static bool IsIgnoredCharacter(char ch)
		{
			return default(bool);
		}

		// Token: 0x0601308C RID: 77964 RVA: 0x0007AF28 File Offset: 0x00079128
		[Token(Token = "0x601308C")]
		[Address(RVA = "0x2629698", Offset = "0x2629698", VA = "0x2629698")]
		internal static bool IsLeadingLetter(char[] letters, int index)
		{
			return default(bool);
		}

		// Token: 0x0601308D RID: 77965 RVA: 0x0007AF40 File Offset: 0x00079140
		[Token(Token = "0x601308D")]
		[Address(RVA = "0x2629554", Offset = "0x2629554", VA = "0x2629554")]
		internal static bool IsFinishingLetter(char[] letters, int index)
		{
			return default(bool);
		}

		// Token: 0x0601308E RID: 77966 RVA: 0x0007AF58 File Offset: 0x00079158
		[Token(Token = "0x601308E")]
		[Address(RVA = "0x2629224", Offset = "0x2629224", VA = "0x2629224")]
		internal static bool IsMiddleLetter(char[] letters, int index)
		{
			return default(bool);
		}

		// Token: 0x0400EFD9 RID: 61401
		[Token(Token = "0x400EFD9")]
		[FieldOffset(Offset = "0x0")]
		internal static bool showTashkeel;

		// Token: 0x0400EFDA RID: 61402
		[Token(Token = "0x400EFDA")]
		[FieldOffset(Offset = "0x1")]
		internal static bool useHinduNumbers;
	}
}
