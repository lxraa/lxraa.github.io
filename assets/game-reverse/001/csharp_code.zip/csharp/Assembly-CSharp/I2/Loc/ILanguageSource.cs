﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025DA RID: 9690
	[Token(Token = "0x20025DA")]
	public interface ILanguageSource
	{
	}
}
