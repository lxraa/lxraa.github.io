﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025CF RID: 9679
	[Token(Token = "0x20025CF")]
	public class SpecializationManager : BaseSpecializationManager
	{
		// Token: 0x06012EEA RID: 77546 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EEA")]
		[Address(RVA = "0x24531F0", Offset = "0x24531F0", VA = "0x24531F0")]
		private SpecializationManager()
		{
		}

		// Token: 0x06012EEB RID: 77547 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EEB")]
		[Address(RVA = "0x2453214", Offset = "0x2453214", VA = "0x2453214")]
		public static string GetSpecializedText(string text, [Optional] string specialization)
		{
			return null;
		}

		// Token: 0x06012EEC RID: 77548 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EEC")]
		[Address(RVA = "0x2453400", Offset = "0x2453400", VA = "0x2453400")]
		public static string SetSpecializedText(string text, string newText, string specialization)
		{
			return null;
		}

		// Token: 0x06012EED RID: 77549 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EED")]
		[Address(RVA = "0x2453720", Offset = "0x2453720", VA = "0x2453720")]
		public static string SetSpecializedText(Dictionary<string, string> specializations)
		{
			return null;
		}

		// Token: 0x06012EEE RID: 77550 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EEE")]
		[Address(RVA = "0x2453520", Offset = "0x2453520", VA = "0x2453520")]
		public static Dictionary<string, string> GetSpecializations(string text, [Optional] Dictionary<string, string> buffer)
		{
			return null;
		}

		// Token: 0x0400EEE9 RID: 61161
		[Token(Token = "0x400EEE9")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		public static SpecializationManager Singleton;
	}
}
