﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace I2.Loc
{
	// Token: 0x02002612 RID: 9746
	[Token(Token = "0x2002612")]
	public class ResourceManager : MonoBehaviour
	{
		// Token: 0x1700280F RID: 10255
		// (get) Token: 0x06013077 RID: 77943 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700280F")]
		public static ResourceManager pInstance
		{
			[Token(Token = "0x6013077")]
			[Address(RVA = "0x261A7DC", Offset = "0x261A7DC", VA = "0x261A7DC")]
			get
			{
				return null;
			}
		}

		// Token: 0x06013078 RID: 77944 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013078")]
		[Address(RVA = "0x2625918", Offset = "0x2625918", VA = "0x2625918")]
		public static void MyOnLevelWasLoaded(Scene scene, LoadSceneMode mode)
		{
		}

		// Token: 0x06013079 RID: 77945 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013079")]
		public T GetAsset<T>(string Name) where T : UnityEngine.Object
		{
			return null;
		}

		// Token: 0x0601307A RID: 77946 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601307A")]
		[Address(RVA = "0x26259D0", Offset = "0x26259D0", VA = "0x26259D0")]
		private UnityEngine.Object FindAsset(string Name)
		{
			return null;
		}

		// Token: 0x0601307B RID: 77947 RVA: 0x0007AEE0 File Offset: 0x000790E0
		[Token(Token = "0x601307B")]
		[Address(RVA = "0x261ABB8", Offset = "0x261ABB8", VA = "0x261ABB8")]
		public bool HasAsset(UnityEngine.Object Obj)
		{
			return default(bool);
		}

		// Token: 0x0601307C RID: 77948 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601307C")]
		public T LoadFromResources<T>(string Path) where T : UnityEngine.Object
		{
			return null;
		}

		// Token: 0x0601307D RID: 77949 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601307D")]
		public T LoadFromBundle<T>(string path) where T : UnityEngine.Object
		{
			return null;
		}

		// Token: 0x0601307E RID: 77950 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601307E")]
		[Address(RVA = "0x262596C", Offset = "0x262596C", VA = "0x262596C")]
		public void CleanResourceCache()
		{
		}

		// Token: 0x0601307F RID: 77951 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601307F")]
		[Address(RVA = "0x2625AF4", Offset = "0x2625AF4", VA = "0x2625AF4")]
		public ResourceManager()
		{
		}

		// Token: 0x0400EFCF RID: 61391
		[Token(Token = "0x400EFCF")]
		[FieldOffset(Offset = "0x0")]
		private static ResourceManager mInstance;

		// Token: 0x0400EFD0 RID: 61392
		[Token(Token = "0x400EFD0")]
		[FieldOffset(Offset = "0x18")]
		public List<IResourceManager_Bundles> mBundleManagers;

		// Token: 0x0400EFD1 RID: 61393
		[Token(Token = "0x400EFD1")]
		[FieldOffset(Offset = "0x20")]
		public UnityEngine.Object[] Assets;

		// Token: 0x0400EFD2 RID: 61394
		[Token(Token = "0x400EFD2")]
		[FieldOffset(Offset = "0x28")]
		private readonly Dictionary<string, UnityEngine.Object> mResourcesCache;
	}
}
