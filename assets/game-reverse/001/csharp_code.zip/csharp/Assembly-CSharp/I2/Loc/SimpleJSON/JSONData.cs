﻿using System;
using Il2CppDummyDll;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x02002620 RID: 9760
	[Token(Token = "0x2002620")]
	public class JSONData : JSONNode
	{
		// Token: 0x17002820 RID: 10272
		// (get) Token: 0x060130CA RID: 78026 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x060130CB RID: 78027 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002820")]
		public override string Value
		{
			[Token(Token = "0x60130CA")]
			[Address(RVA = "0x24C5D88", Offset = "0x24C5D88", VA = "0x24C5D88", Slot = "7")]
			get
			{
				return null;
			}
			[Token(Token = "0x60130CB")]
			[Address(RVA = "0x24C5D90", Offset = "0x24C5D90", VA = "0x24C5D90", Slot = "8")]
			set
			{
			}
		}

		// Token: 0x060130CC RID: 78028 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130CC")]
		[Address(RVA = "0x24C404C", Offset = "0x24C404C", VA = "0x24C404C")]
		public JSONData(string aData)
		{
		}

		// Token: 0x060130CD RID: 78029 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130CD")]
		[Address(RVA = "0x24C5D98", Offset = "0x24C5D98", VA = "0x24C5D98")]
		public JSONData(int aData)
		{
		}

		// Token: 0x060130CE RID: 78030 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130CE")]
		[Address(RVA = "0x24C5DCC", Offset = "0x24C5DCC", VA = "0x24C5DCC", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x0400EFE7 RID: 61415
		[Token(Token = "0x400EFE7")]
		[FieldOffset(Offset = "0x10")]
		private string m_Data;
	}
}
