﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine.Networking;

namespace I2.Loc
{
	// Token: 0x020025D4 RID: 9684
	[Token(Token = "0x20025D4")]
	public static class GoogleTranslation
	{
		// Token: 0x06012EFC RID: 77564 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EFC")]
		[Address(RVA = "0x2612070", Offset = "0x2612070", VA = "0x2612070")]
		public static string UppercaseFirst(string s)
		{
			return null;
		}

		// Token: 0x06012EFD RID: 77565 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012EFD")]
		[Address(RVA = "0x2612158", Offset = "0x2612158", VA = "0x2612158")]
		public static string TitleCase(string s)
		{
			return null;
		}

		// Token: 0x0400EEF8 RID: 61176
		[Token(Token = "0x400EEF8")]
		[FieldOffset(Offset = "0x0")]
		private static List<UnityWebRequest> mCurrentTranslations;

		// Token: 0x0400EEF9 RID: 61177
		[Token(Token = "0x400EEF9")]
		[FieldOffset(Offset = "0x8")]
		private static List<TranslationJob> mTranslationJobs;
	}
}
