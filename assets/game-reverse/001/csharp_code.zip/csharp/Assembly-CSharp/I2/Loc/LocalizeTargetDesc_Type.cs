﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025F5 RID: 9717
	[Token(Token = "0x20025F5")]
	public class LocalizeTargetDesc_Type<T, G> : LocalizeTargetDesc<G> where T : UnityEngine.Object where G : LocalizeTarget<T>
	{
		// Token: 0x06012FCB RID: 77771 RVA: 0x0007A8B0 File Offset: 0x00078AB0
		[Token(Token = "0x6012FCB")]
		public override bool CanLocalize(Localize cmp)
		{
			return default(bool);
		}

		// Token: 0x06012FCC RID: 77772 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012FCC")]
		public override ILocalizeTarget CreateTarget(Localize cmp)
		{
			return null;
		}

		// Token: 0x06012FCD RID: 77773 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FCD")]
		public LocalizeTargetDesc_Type()
		{
		}
	}
}
