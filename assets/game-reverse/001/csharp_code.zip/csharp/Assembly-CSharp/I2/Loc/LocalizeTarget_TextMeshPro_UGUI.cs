﻿using System;
using Il2CppDummyDll;
using TMPro;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025F7 RID: 9719
	[Token(Token = "0x20025F7")]
	public class LocalizeTarget_TextMeshPro_UGUI : LocalizeTarget<TextMeshProUGUI>
	{
		// Token: 0x06012FDD RID: 77789 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FDD")]
		[Address(RVA = "0x26216FC", Offset = "0x26216FC", VA = "0x26216FC")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x06012FDE RID: 77790 RVA: 0x0007A940 File Offset: 0x00078B40
		[Token(Token = "0x6012FDE")]
		[Address(RVA = "0x26217C0", Offset = "0x26217C0", VA = "0x26217C0", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06012FDF RID: 77791 RVA: 0x0007A958 File Offset: 0x00078B58
		[Token(Token = "0x6012FDF")]
		[Address(RVA = "0x26217C8", Offset = "0x26217C8", VA = "0x26217C8", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06012FE0 RID: 77792 RVA: 0x0007A970 File Offset: 0x00078B70
		[Token(Token = "0x6012FE0")]
		[Address(RVA = "0x26217D0", Offset = "0x26217D0", VA = "0x26217D0", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x06012FE1 RID: 77793 RVA: 0x0007A988 File Offset: 0x00078B88
		[Token(Token = "0x6012FE1")]
		[Address(RVA = "0x26217D8", Offset = "0x26217D8", VA = "0x26217D8", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06012FE2 RID: 77794 RVA: 0x0007A9A0 File Offset: 0x00078BA0
		[Token(Token = "0x6012FE2")]
		[Address(RVA = "0x26217E0", Offset = "0x26217E0", VA = "0x26217E0", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06012FE3 RID: 77795 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FE3")]
		[Address(RVA = "0x26217E8", Offset = "0x26217E8", VA = "0x26217E8", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06012FE4 RID: 77796 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FE4")]
		[Address(RVA = "0x2621904", Offset = "0x2621904", VA = "0x2621904", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06012FE5 RID: 77797 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FE5")]
		[Address(RVA = "0x2621DB8", Offset = "0x2621DB8", VA = "0x2621DB8")]
		public LocalizeTarget_TextMeshPro_UGUI()
		{
		}

		// Token: 0x0400EFA2 RID: 61346
		[Token(Token = "0x400EFA2")]
		[FieldOffset(Offset = "0x20")]
		public TextAlignmentOptions mAlignment_RTL;

		// Token: 0x0400EFA3 RID: 61347
		[Token(Token = "0x400EFA3")]
		[FieldOffset(Offset = "0x24")]
		public TextAlignmentOptions mAlignment_LTR;

		// Token: 0x0400EFA4 RID: 61348
		[Token(Token = "0x400EFA4")]
		[FieldOffset(Offset = "0x28")]
		public bool mAlignmentWasRTL;

		// Token: 0x0400EFA5 RID: 61349
		[Token(Token = "0x400EFA5")]
		[FieldOffset(Offset = "0x29")]
		public bool mInitializeAlignment;
	}
}
