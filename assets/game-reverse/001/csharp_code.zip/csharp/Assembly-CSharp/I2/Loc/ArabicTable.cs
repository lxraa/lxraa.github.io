﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x02002615 RID: 9749
	[Token(Token = "0x2002615")]
	internal class ArabicTable
	{
		// Token: 0x06013084 RID: 77956 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013084")]
		[Address(RVA = "0x2626E94", Offset = "0x2626E94", VA = "0x2626E94")]
		private ArabicTable()
		{
		}

		// Token: 0x17002810 RID: 10256
		// (get) Token: 0x06013085 RID: 77957 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x17002810")]
		internal static ArabicTable ArabicMapper
		{
			[Token(Token = "0x6013085")]
			[Address(RVA = "0x2628728", Offset = "0x2628728", VA = "0x2628728")]
			get
			{
				return null;
			}
		}

		// Token: 0x06013086 RID: 77958 RVA: 0x0007AEF8 File Offset: 0x000790F8
		[Token(Token = "0x6013086")]
		[Address(RVA = "0x26287AC", Offset = "0x26287AC", VA = "0x26287AC")]
		internal int Convert(int toBeConverted)
		{
			return 0;
		}

		// Token: 0x0400EFD5 RID: 61397
		[Token(Token = "0x400EFD5")]
		[FieldOffset(Offset = "0x0")]
		private static List<ArabicMapping> mapList;

		// Token: 0x0400EFD6 RID: 61398
		[Token(Token = "0x400EFD6")]
		[FieldOffset(Offset = "0x8")]
		private static ArabicTable arabicMapper;
	}
}
