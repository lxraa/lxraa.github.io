﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

namespace I2.Loc
{
	// Token: 0x020025DB RID: 9691
	[Token(Token = "0x20025DB")]
	[ExecuteInEditMode]
	[Serializable]
	public class LanguageSourceData
	{
		// Token: 0x140000A6 RID: 166
		// (add) Token: 0x06012F14 RID: 77588 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012F15 RID: 77589 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A6")]
		public event LanguageSource.fnOnSourceUpdated Event_OnSourceUpdateFromGoogle
		{
			[Token(Token = "0x6012F14")]
			[Address(RVA = "0x2612D90", Offset = "0x2612D90", VA = "0x2612D90")]
			add
			{
			}
			[Token(Token = "0x6012F15")]
			[Address(RVA = "0x2613190", Offset = "0x2613190", VA = "0x2613190")]
			remove
			{
			}
		}

		// Token: 0x06012F16 RID: 77590 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F16")]
		[Address(RVA = "0x26124C8", Offset = "0x26124C8", VA = "0x26124C8")]
		public void Awake()
		{
		}

		// Token: 0x06012F17 RID: 77591 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F17")]
		[Address(RVA = "0x2612558", Offset = "0x2612558", VA = "0x2612558")]
		public void OnDestroy()
		{
		}

		// Token: 0x06012F18 RID: 77592 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F18")]
		[Address(RVA = "0x2613C38", Offset = "0x2613C38", VA = "0x2613C38")]
		public void ClearAllData()
		{
		}

		// Token: 0x06012F19 RID: 77593 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F19")]
		[Address(RVA = "0x2613D1C", Offset = "0x2613D1C", VA = "0x2613D1C")]
		public void Editor_SetDirty()
		{
		}

		// Token: 0x06012F1A RID: 77594 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F1A")]
		[Address(RVA = "0x2613788", Offset = "0x2613788", VA = "0x2613788")]
		public void UpdateAssetDictionary()
		{
		}

		// Token: 0x06012F1B RID: 77595 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F1B")]
		[Address(RVA = "0x2613D20", Offset = "0x2613D20", VA = "0x2613D20")]
		public UnityEngine.Object FindAsset(string Name)
		{
			return null;
		}

		// Token: 0x06012F1C RID: 77596 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F1C")]
		[Address(RVA = "0x2613DF4", Offset = "0x2613DF4", VA = "0x2613DF4")]
		private string Export_Language_to_Cache(int langIndex, bool fillTermWithFallback)
		{
			return null;
		}

		// Token: 0x06012F1D RID: 77597 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F1D")]
		[Address(RVA = "0x2614324", Offset = "0x2614324", VA = "0x2614324")]
		public string Import_I2CSV(string Category, string I2CSVstring, eSpreadsheetUpdateMode UpdateMode = eSpreadsheetUpdateMode.Replace)
		{
			return null;
		}

		// Token: 0x06012F1E RID: 77598 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F1E")]
		[Address(RVA = "0x26145A8", Offset = "0x26145A8", VA = "0x26145A8")]
		public string Import_CSV(string Category, List<string[]> CSV, eSpreadsheetUpdateMode UpdateMode = eSpreadsheetUpdateMode.Replace)
		{
			return null;
		}

		// Token: 0x06012F1F RID: 77599 RVA: 0x0007A610 File Offset: 0x00078810
		[Token(Token = "0x6012F1F")]
		[Address(RVA = "0x2615254", Offset = "0x2615254", VA = "0x2615254")]
		private bool ArrayContains(string MainText, params string[] texts)
		{
			return default(bool);
		}

		// Token: 0x06012F20 RID: 77600 RVA: 0x0007A628 File Offset: 0x00078828
		[Token(Token = "0x6012F20")]
		[Address(RVA = "0x2615AC4", Offset = "0x2615AC4", VA = "0x2615AC4")]
		public static eTermType GetTermType(string type)
		{
			return eTermType.Text;
		}

		// Token: 0x06012F21 RID: 77601 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F21")]
		[Address(RVA = "0x2615DF0", Offset = "0x2615DF0", VA = "0x2615DF0")]
		private void Import_Language_from_Cache(int langIndex, string langData, bool useFallback, bool onlyCurrentSpecialization)
		{
		}

		// Token: 0x06012F22 RID: 77602 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F22")]
		[Address(RVA = "0x261601C", Offset = "0x261601C", VA = "0x261601C")]
		public void Import_Google_FromCache()
		{
		}

		// Token: 0x06012F23 RID: 77603 RVA: 0x0007A640 File Offset: 0x00078840
		[Token(Token = "0x6012F23")]
		[Address(RVA = "0x2616458", Offset = "0x2616458", VA = "0x2616458")]
		private bool IsNewerVersion(string currentVersion, string newVersion)
		{
			return default(bool);
		}

		// Token: 0x06012F24 RID: 77604 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F24")]
		[Address(RVA = "0x2616B14", Offset = "0x2616B14", VA = "0x2616B14")]
		public void Import_Google(bool ForceUpdate, bool justCheck)
		{
		}

		// Token: 0x06012F25 RID: 77605 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F25")]
		[Address(RVA = "0x2616298", Offset = "0x2616298", VA = "0x2616298")]
		private string GetSourcePlayerPrefName()
		{
			return null;
		}

		// Token: 0x06012F26 RID: 77606 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F26")]
		[Address(RVA = "0x2616D80", Offset = "0x2616D80", VA = "0x2616D80")]
		private IEnumerator Import_Google_Coroutine(bool JustCheck)
		{
			return null;
		}

		// Token: 0x06012F27 RID: 77607 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F27")]
		[Address(RVA = "0x2616E54", Offset = "0x2616E54", VA = "0x2616E54")]
		private void ApplyDownloadedDataOnSceneLoaded(Scene scene, LoadSceneMode mode)
		{
		}

		// Token: 0x06012F28 RID: 77608 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F28")]
		[Address(RVA = "0x2616F00", Offset = "0x2616F00", VA = "0x2616F00")]
		public void ApplyDownloadedDataFromGoogle()
		{
		}

		// Token: 0x06012F29 RID: 77609 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F29")]
		[Address(RVA = "0x2617060", Offset = "0x2617060", VA = "0x2617060")]
		public UnityWebRequest Import_Google_CreateWWWcall(bool ForceUpdate, bool justCheck)
		{
			return null;
		}

		// Token: 0x06012F2A RID: 77610 RVA: 0x0007A658 File Offset: 0x00078858
		[Token(Token = "0x6012F2A")]
		[Address(RVA = "0x26171D8", Offset = "0x26171D8", VA = "0x26171D8")]
		public bool HasGoogleSpreadsheet()
		{
			return default(bool);
		}

		// Token: 0x06012F2B RID: 77611 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F2B")]
		[Address(RVA = "0x26164E8", Offset = "0x26164E8", VA = "0x26164E8")]
		public string Import_Google_Result(string JsonString, eSpreadsheetUpdateMode UpdateMode, bool saveInPlayerPrefs = false)
		{
			return null;
		}

		// Token: 0x06012F2C RID: 77612 RVA: 0x0007A670 File Offset: 0x00078870
		[Token(Token = "0x6012F2C")]
		[Address(RVA = "0x2615458", Offset = "0x2615458", VA = "0x2615458")]
		public int GetLanguageIndex(string language, bool AllowDiscartingRegion = true, bool SkipDisabled = true)
		{
			return 0;
		}

		// Token: 0x06012F2D RID: 77613 RVA: 0x0007A688 File Offset: 0x00078888
		[Token(Token = "0x6012F2D")]
		[Address(RVA = "0x26175D4", Offset = "0x26175D4", VA = "0x26175D4")]
		public bool IsCurrentLanguage(int languageIndex)
		{
			return default(bool);
		}

		// Token: 0x06012F2E RID: 77614 RVA: 0x0007A6A0 File Offset: 0x000788A0
		[Token(Token = "0x6012F2E")]
		[Address(RVA = "0x26152E4", Offset = "0x26152E4", VA = "0x26152E4")]
		public int GetLanguageIndexFromCode(string Code, bool exactMatch = true, bool ignoreDisabled = false)
		{
			return 0;
		}

		// Token: 0x06012F2F RID: 77615 RVA: 0x0007A6B8 File Offset: 0x000788B8
		[Token(Token = "0x6012F2F")]
		[Address(RVA = "0x2617418", Offset = "0x2617418", VA = "0x2617418")]
		public static int GetCommonWordInLanguageNames(string Language1, string Language2)
		{
			return 0;
		}

		// Token: 0x06012F30 RID: 77616 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F30")]
		[Address(RVA = "0x26176D4", Offset = "0x26176D4", VA = "0x26176D4")]
		public List<string> GetLanguages(bool skipDisabled = true)
		{
			return null;
		}

		// Token: 0x06012F31 RID: 77617 RVA: 0x0007A6D0 File Offset: 0x000788D0
		[Token(Token = "0x6012F31")]
		[Address(RVA = "0x261784C", Offset = "0x261784C", VA = "0x261784C")]
		public bool AllowUnloadingLanguages()
		{
			return default(bool);
		}

		// Token: 0x06012F32 RID: 77618 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F32")]
		[Address(RVA = "0x261785C", Offset = "0x261785C", VA = "0x261785C")]
		private string GetSavedLanguageFileName(int languageIndex)
		{
			return null;
		}

		// Token: 0x06012F33 RID: 77619 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F33")]
		[Address(RVA = "0x2617AA4", Offset = "0x2617AA4", VA = "0x2617AA4")]
		public void LoadLanguage(int languageIndex, bool UnloadOtherLanguages, bool useFallback, bool onlyCurrentSpecialization, bool forceLoad)
		{
		}

		// Token: 0x06012F34 RID: 77620 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F34")]
		[Address(RVA = "0x2617C08", Offset = "0x2617C08", VA = "0x2617C08")]
		public void UnloadLanguage(int languageIndex)
		{
		}

		// Token: 0x06012F35 RID: 77621 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F35")]
		[Address(RVA = "0x2615CD8", Offset = "0x2615CD8", VA = "0x2615CD8")]
		public void SaveLanguages(bool unloadAll, PersistentStorage.eFileType fileLocation = PersistentStorage.eFileType.Temporal)
		{
		}

		// Token: 0x06012F36 RID: 77622 RVA: 0x0007A6E8 File Offset: 0x000788E8
		[Token(Token = "0x6012F36")]
		[Address(RVA = "0x2615C40", Offset = "0x2615C40", VA = "0x2615C40")]
		public bool HasUnloadedLanguages()
		{
			return default(bool);
		}

		// Token: 0x06012F37 RID: 77623 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F37")]
		[Address(RVA = "0x2617E70", Offset = "0x2617E70", VA = "0x2617E70")]
		public static string GetKeyFromFullTerm(string FullTerm, bool OnlyMainCategory = false)
		{
			return null;
		}

		// Token: 0x06012F38 RID: 77624 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F38")]
		[Address(RVA = "0x2613484", Offset = "0x2613484", VA = "0x2613484")]
		public void UpdateDictionary(bool force = false)
		{
		}

		// Token: 0x06012F39 RID: 77625 RVA: 0x0007A700 File Offset: 0x00078900
		[Token(Token = "0x6012F39")]
		[Address(RVA = "0x2618118", Offset = "0x2618118", VA = "0x2618118")]
		public bool TryGetTranslation(string term, out string Translation, [Optional] string overrideLanguage, [Optional] string overrideSpecialization, bool skipDisabled = false, bool allowCategoryMistmatch = false)
		{
			return default(bool);
		}

		// Token: 0x06012F3A RID: 77626 RVA: 0x0007A718 File Offset: 0x00078918
		[Token(Token = "0x6012F3A")]
		[Address(RVA = "0x26140A8", Offset = "0x26140A8", VA = "0x26140A8")]
		private bool TryGetFallbackTranslation(TermData termData, out string Translation, int langIndex, [Optional] string overrideSpecialization, bool skipDisabled = false)
		{
			return default(bool);
		}

		// Token: 0x06012F3B RID: 77627 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F3B")]
		[Address(RVA = "0x26157A8", Offset = "0x26157A8", VA = "0x26157A8")]
		public TermData GetTermData(string term, bool allowCategoryMistmatch = false)
		{
			return null;
		}

		// Token: 0x06012F3C RID: 77628 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F3C")]
		[Address(RVA = "0x2615608", Offset = "0x2615608", VA = "0x2615608")]
		public static void ValidateFullTerm(ref string Term)
		{
		}

		// Token: 0x06012F3D RID: 77629 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F3D")]
		[Address(RVA = "0x2612AF0", Offset = "0x2612AF0", VA = "0x2612AF0")]
		public LanguageSourceData()
		{
		}

		// Token: 0x0400EF14 RID: 61204
		[Token(Token = "0x400EF14")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		[NonSerialized]
		public ILanguageSource owner;

		// Token: 0x0400EF15 RID: 61205
		[Token(Token = "0x400EF15")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		public bool UserAgreesToHaveItOnTheScene;

		// Token: 0x0400EF16 RID: 61206
		[Token(Token = "0x400EF16")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x19")]
		public bool UserAgreesToHaveItInsideThePluginsFolder;

		// Token: 0x0400EF17 RID: 61207
		[Token(Token = "0x400EF17")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x1A")]
		public bool GoogleLiveSyncIsUptoDate;

		// Token: 0x0400EF18 RID: 61208
		[Token(Token = "0x400EF18")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x1B")]
		[NonSerialized]
		public bool mIsGlobalSource;

		// Token: 0x0400EF19 RID: 61209
		[Token(Token = "0x400EF19")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		public List<TermData> mTerms;

		// Token: 0x0400EF1A RID: 61210
		[Token(Token = "0x400EF1A")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		public bool CaseInsensitiveTerms;

		// Token: 0x0400EF1B RID: 61211
		[Token(Token = "0x400EF1B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
		[NonSerialized]
		public Dictionary<string, TermData> mDictionary;

		// Token: 0x0400EF1C RID: 61212
		[Token(Token = "0x400EF1C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x38")]
		public LanguageSourceData.MissingTranslationAction OnMissingTranslation;

		// Token: 0x0400EF1D RID: 61213
		[Token(Token = "0x400EF1D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x40")]
		public string mTerm_AppName;

		// Token: 0x0400EF1E RID: 61214
		[Token(Token = "0x400EF1E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x48")]
		public List<LanguageData> mLanguages;

		// Token: 0x0400EF1F RID: 61215
		[Token(Token = "0x400EF1F")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x50")]
		public bool IgnoreDeviceLanguage;

		// Token: 0x0400EF20 RID: 61216
		[Token(Token = "0x400EF20")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x54")]
		public LanguageSourceData.eAllowUnloadLanguages _AllowUnloadingLanguages;

		// Token: 0x0400EF21 RID: 61217
		[Token(Token = "0x400EF21")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x58")]
		public string Google_WebServiceURL;

		// Token: 0x0400EF22 RID: 61218
		[Token(Token = "0x400EF22")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x60")]
		public string Google_SpreadsheetKey;

		// Token: 0x0400EF23 RID: 61219
		[Token(Token = "0x400EF23")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x68")]
		public string Google_SpreadsheetName;

		// Token: 0x0400EF24 RID: 61220
		[Token(Token = "0x400EF24")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x70")]
		public string Google_LastUpdatedVersion;

		// Token: 0x0400EF25 RID: 61221
		[Token(Token = "0x400EF25")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x78")]
		public LanguageSourceData.eGoogleUpdateFrequency GoogleUpdateFrequency;

		// Token: 0x0400EF26 RID: 61222
		[Token(Token = "0x400EF26")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x7C")]
		public LanguageSourceData.eGoogleUpdateFrequency GoogleInEditorCheckFrequency;

		// Token: 0x0400EF27 RID: 61223
		[Token(Token = "0x400EF27")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x80")]
		public LanguageSourceData.eGoogleUpdateSynchronization GoogleUpdateSynchronization;

		// Token: 0x0400EF28 RID: 61224
		[Token(Token = "0x400EF28")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x84")]
		public float GoogleUpdateDelay;

		// Token: 0x0400EF2A RID: 61226
		[Token(Token = "0x400EF2A")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x90")]
		public List<UnityEngine.Object> Assets;

		// Token: 0x0400EF2B RID: 61227
		[Token(Token = "0x400EF2B")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x98")]
		[NonSerialized]
		public Dictionary<string, UnityEngine.Object> mAssetDictionary;

		// Token: 0x0400EF2C RID: 61228
		[Token(Token = "0x400EF2C")]
		[Il2CppDummyDll.FieldOffset(Offset = "0xA0")]
		private string mDelayedGoogleData;

		// Token: 0x0400EF2D RID: 61229
		[Token(Token = "0x400EF2D")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
		public static string EmptyCategory;

		// Token: 0x0400EF2E RID: 61230
		[Token(Token = "0x400EF2E")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
		public static char[] CategorySeparators;

		// Token: 0x020025DC RID: 9692
		[Token(Token = "0x20025DC")]
		public enum MissingTranslationAction
		{
			// Token: 0x0400EF30 RID: 61232
			[Token(Token = "0x400EF30")]
			Empty,
			// Token: 0x0400EF31 RID: 61233
			[Token(Token = "0x400EF31")]
			Fallback,
			// Token: 0x0400EF32 RID: 61234
			[Token(Token = "0x400EF32")]
			ShowWarning,
			// Token: 0x0400EF33 RID: 61235
			[Token(Token = "0x400EF33")]
			ShowTerm
		}

		// Token: 0x020025DD RID: 9693
		[Token(Token = "0x20025DD")]
		public enum eAllowUnloadLanguages
		{
			// Token: 0x0400EF35 RID: 61237
			[Token(Token = "0x400EF35")]
			Never,
			// Token: 0x0400EF36 RID: 61238
			[Token(Token = "0x400EF36")]
			OnlyInDevice,
			// Token: 0x0400EF37 RID: 61239
			[Token(Token = "0x400EF37")]
			EditorAndDevice
		}

		// Token: 0x020025DE RID: 9694
		[Token(Token = "0x20025DE")]
		public enum eGoogleUpdateFrequency
		{
			// Token: 0x0400EF39 RID: 61241
			[Token(Token = "0x400EF39")]
			Always,
			// Token: 0x0400EF3A RID: 61242
			[Token(Token = "0x400EF3A")]
			Never,
			// Token: 0x0400EF3B RID: 61243
			[Token(Token = "0x400EF3B")]
			Daily,
			// Token: 0x0400EF3C RID: 61244
			[Token(Token = "0x400EF3C")]
			Weekly,
			// Token: 0x0400EF3D RID: 61245
			[Token(Token = "0x400EF3D")]
			Monthly,
			// Token: 0x0400EF3E RID: 61246
			[Token(Token = "0x400EF3E")]
			OnlyOnce,
			// Token: 0x0400EF3F RID: 61247
			[Token(Token = "0x400EF3F")]
			EveryOtherDay
		}

		// Token: 0x020025DF RID: 9695
		[Token(Token = "0x20025DF")]
		public enum eGoogleUpdateSynchronization
		{
			// Token: 0x0400EF41 RID: 61249
			[Token(Token = "0x400EF41")]
			Manual,
			// Token: 0x0400EF42 RID: 61250
			[Token(Token = "0x400EF42")]
			OnSceneLoaded,
			// Token: 0x0400EF43 RID: 61251
			[Token(Token = "0x400EF43")]
			AsSoonAsDownloaded
		}

		// Token: 0x020025E0 RID: 9696
		[Token(Token = "0x20025E0")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06012F40 RID: 77632 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012F40")]
			[Address(RVA = "0x2618648", Offset = "0x2618648", VA = "0x2618648")]
			public <>c()
			{
			}

			// Token: 0x06012F41 RID: 77633 RVA: 0x0007A730 File Offset: 0x00078930
			[Token(Token = "0x6012F41")]
			[Address(RVA = "0x2618650", Offset = "0x2618650", VA = "0x2618650")]
			internal bool <UpdateAssetDictionary>b__39_0(UnityEngine.Object x)
			{
				return default(bool);
			}

			// Token: 0x06012F42 RID: 77634 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012F42")]
			[Address(RVA = "0x26186AC", Offset = "0x26186AC", VA = "0x26186AC")]
			internal string <UpdateAssetDictionary>b__39_1(UnityEngine.Object o)
			{
				return null;
			}

			// Token: 0x06012F43 RID: 77635 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012F43")]
			[Address(RVA = "0x26186C4", Offset = "0x26186C4", VA = "0x26186C4")]
			internal string <UpdateAssetDictionary>b__39_2(IGrouping<string, UnityEngine.Object> g)
			{
				return null;
			}

			// Token: 0x06012F44 RID: 77636 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x6012F44")]
			[Address(RVA = "0x2618760", Offset = "0x2618760", VA = "0x2618760")]
			internal UnityEngine.Object <UpdateAssetDictionary>b__39_3(IGrouping<string, UnityEngine.Object> g)
			{
				return null;
			}

			// Token: 0x0400EF44 RID: 61252
			[Token(Token = "0x400EF44")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x0")]
			public static readonly LanguageSourceData.<>c <>9;

			// Token: 0x0400EF45 RID: 61253
			[Token(Token = "0x400EF45")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x8")]
			public static Predicate<UnityEngine.Object> <>9__39_0;

			// Token: 0x0400EF46 RID: 61254
			[Token(Token = "0x400EF46")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public static Func<UnityEngine.Object, string> <>9__39_1;

			// Token: 0x0400EF47 RID: 61255
			[Token(Token = "0x400EF47")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			public static Func<IGrouping<string, UnityEngine.Object>, string> <>9__39_2;

			// Token: 0x0400EF48 RID: 61256
			[Token(Token = "0x400EF48")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
			public static Func<IGrouping<string, UnityEngine.Object>, UnityEngine.Object> <>9__39_3;
		}

		// Token: 0x020025E1 RID: 9697
		[Token(Token = "0x20025E1")]
		private sealed class <Import_Google_Coroutine>d__65 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x06012F45 RID: 77637 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012F45")]
			[Address(RVA = "0x2616E2C", Offset = "0x2616E2C", VA = "0x2616E2C")]
			[DebuggerHidden]
			public <Import_Google_Coroutine>d__65(int <>1__state)
			{
			}

			// Token: 0x06012F46 RID: 77638 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012F46")]
			[Address(RVA = "0x26187A8", Offset = "0x26187A8", VA = "0x26187A8", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x06012F47 RID: 77639 RVA: 0x0007A748 File Offset: 0x00078948
			[Token(Token = "0x6012F47")]
			[Address(RVA = "0x26187AC", Offset = "0x26187AC", VA = "0x26187AC", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x17002804 RID: 10244
			// (get) Token: 0x06012F48 RID: 77640 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x17002804")]
			private object Current
			{
				[Token(Token = "0x6012F48")]
				[Address(RVA = "0x2618A98", Offset = "0x2618A98", VA = "0x2618A98", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x06012F49 RID: 77641 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6012F49")]
			[Address(RVA = "0x2618AA0", Offset = "0x2618AA0", VA = "0x2618AA0", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x17002805 RID: 10245
			// (get) Token: 0x06012F4A RID: 77642 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x17002805")]
			private object Current
			{
				[Token(Token = "0x6012F4A")]
				[Address(RVA = "0x2618AE0", Offset = "0x2618AE0", VA = "0x2618AE0", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EF49 RID: 61257
			[Token(Token = "0x400EF49")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EF4A RID: 61258
			[Token(Token = "0x400EF4A")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EF4B RID: 61259
			[Token(Token = "0x400EF4B")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
			public LanguageSourceData <>4__this;

			// Token: 0x0400EF4C RID: 61260
			[Token(Token = "0x400EF4C")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
			public bool JustCheck;

			// Token: 0x0400EF4D RID: 61261
			[Token(Token = "0x400EF4D")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
			private UnityWebRequest <www>5__2;
		}
	}
}
