﻿using System;
using System.Runtime.InteropServices;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02002604 RID: 9732
	[Token(Token = "0x2002604")]
	[Serializable]
	public class TermData
	{
		// Token: 0x06013048 RID: 77896 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013048")]
		[Address(RVA = "0x261836C", Offset = "0x261836C", VA = "0x261836C")]
		public string GetTranslation(int idx, [Optional] string specialization, bool editMode = false)
		{
			return null;
		}

		// Token: 0x06013049 RID: 77897 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013049")]
		[Address(RVA = "0x2615B5C", Offset = "0x2615B5C", VA = "0x2615B5C")]
		public void SetTranslation(int idx, string translation, [Optional] string specialization)
		{
		}

		// Token: 0x0601304A RID: 77898 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601304A")]
		[Address(RVA = "0x2617F1C", Offset = "0x2617F1C", VA = "0x2617F1C")]
		public void Validate()
		{
		}

		// Token: 0x0601304B RID: 77899 RVA: 0x0007AE50 File Offset: 0x00079050
		[Token(Token = "0x601304B")]
		[Address(RVA = "0x2618480", Offset = "0x2618480", VA = "0x2618480")]
		public bool IsTerm(string name, bool allowCategoryMistmatch)
		{
			return default(bool);
		}

		// Token: 0x0601304C RID: 77900 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601304C")]
		[Address(RVA = "0x26159FC", Offset = "0x26159FC", VA = "0x26159FC")]
		public TermData()
		{
		}

		// Token: 0x0400EFBA RID: 61370
		[Token(Token = "0x400EFBA")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		public string Term;

		// Token: 0x0400EFBB RID: 61371
		[Token(Token = "0x400EFBB")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		public eTermType TermType;

		// Token: 0x0400EFBC RID: 61372
		[Token(Token = "0x400EFBC")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x20")]
		[NonSerialized]
		public string Description;

		// Token: 0x0400EFBD RID: 61373
		[Token(Token = "0x400EFBD")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x28")]
		public string[] Languages;

		// Token: 0x0400EFBE RID: 61374
		[Token(Token = "0x400EFBE")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x30")]
		public byte[] Flags;

		// Token: 0x0400EFBF RID: 61375
		[Token(Token = "0x400EFBF")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x38")]
		[SerializeField]
		private string[] Languages_Touch;
	}
}
