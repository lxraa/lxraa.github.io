﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025F2 RID: 9714
	[Token(Token = "0x20025F2")]
	public abstract class LocalizeTarget<T> : ILocalizeTarget where T : UnityEngine.Object
	{
		// Token: 0x06012FC2 RID: 77762 RVA: 0x0007A898 File Offset: 0x00078A98
		[Token(Token = "0x6012FC2")]
		public override bool IsValid(Localize cmp)
		{
			return default(bool);
		}

		// Token: 0x06012FC3 RID: 77763 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FC3")]
		protected LocalizeTarget()
		{
		}

		// Token: 0x0400EF9B RID: 61339
		[Token(Token = "0x400EF9B")]
		[FieldOffset(Offset = "0x0")]
		public T mTarget;
	}
}
