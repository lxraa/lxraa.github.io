﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025F8 RID: 9720
	[Token(Token = "0x20025F8")]
	public class LocalizeTarget_UnityStandard_AudioSource : LocalizeTarget<AudioSource>
	{
		// Token: 0x06012FE7 RID: 77799 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FE7")]
		[Address(RVA = "0x2621E18", Offset = "0x2621E18", VA = "0x2621E18")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x06012FE8 RID: 77800 RVA: 0x0007A9B8 File Offset: 0x00078BB8
		[Token(Token = "0x6012FE8")]
		[Address(RVA = "0x2621EDC", Offset = "0x2621EDC", VA = "0x2621EDC", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06012FE9 RID: 77801 RVA: 0x0007A9D0 File Offset: 0x00078BD0
		[Token(Token = "0x6012FE9")]
		[Address(RVA = "0x2621EE4", Offset = "0x2621EE4", VA = "0x2621EE4", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06012FEA RID: 77802 RVA: 0x0007A9E8 File Offset: 0x00078BE8
		[Token(Token = "0x6012FEA")]
		[Address(RVA = "0x2621EEC", Offset = "0x2621EEC", VA = "0x2621EEC", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x06012FEB RID: 77803 RVA: 0x0007AA00 File Offset: 0x00078C00
		[Token(Token = "0x6012FEB")]
		[Address(RVA = "0x2621EF4", Offset = "0x2621EF4", VA = "0x2621EF4", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06012FEC RID: 77804 RVA: 0x0007AA18 File Offset: 0x00078C18
		[Token(Token = "0x6012FEC")]
		[Address(RVA = "0x2621EFC", Offset = "0x2621EFC", VA = "0x2621EFC", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06012FED RID: 77805 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FED")]
		[Address(RVA = "0x2621F04", Offset = "0x2621F04", VA = "0x2621F04", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06012FEE RID: 77806 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FEE")]
		[Address(RVA = "0x2621FEC", Offset = "0x2621FEC", VA = "0x2621FEC", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06012FEF RID: 77807 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FEF")]
		[Address(RVA = "0x262215C", Offset = "0x262215C", VA = "0x262215C")]
		public LocalizeTarget_UnityStandard_AudioSource()
		{
		}
	}
}
