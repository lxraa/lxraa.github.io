﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Events;

namespace I2.Loc
{
	// Token: 0x02002607 RID: 9735
	[Token(Token = "0x2002607")]
	public class CustomLocalizeCallback : MonoBehaviour
	{
		// Token: 0x06013053 RID: 77907 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013053")]
		[Address(RVA = "0x26246BC", Offset = "0x26246BC", VA = "0x26246BC")]
		public void OnEnable()
		{
		}

		// Token: 0x06013054 RID: 77908 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013054")]
		[Address(RVA = "0x2624784", Offset = "0x2624784", VA = "0x2624784")]
		public void OnDisable()
		{
		}

		// Token: 0x06013055 RID: 77909 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013055")]
		[Address(RVA = "0x2624820", Offset = "0x2624820", VA = "0x2624820")]
		public void OnLocalize()
		{
		}

		// Token: 0x06013056 RID: 77910 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013056")]
		[Address(RVA = "0x262483C", Offset = "0x262483C", VA = "0x262483C")]
		public CustomLocalizeCallback()
		{
		}

		// Token: 0x0400EFC1 RID: 61377
		[Token(Token = "0x400EFC1")]
		[FieldOffset(Offset = "0x18")]
		public UnityEvent _OnLocalize;
	}
}
