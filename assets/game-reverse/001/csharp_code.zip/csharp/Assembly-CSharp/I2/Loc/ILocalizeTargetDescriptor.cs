﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025F3 RID: 9715
	[Token(Token = "0x20025F3")]
	public abstract class ILocalizeTargetDescriptor
	{
		// Token: 0x06012FC4 RID: 77764
		[Token(Token = "0x6012FC4")]
		public abstract bool CanLocalize(Localize cmp);

		// Token: 0x06012FC5 RID: 77765
		[Token(Token = "0x6012FC5")]
		public abstract ILocalizeTarget CreateTarget(Localize cmp);

		// Token: 0x06012FC6 RID: 77766
		[Token(Token = "0x6012FC6")]
		public abstract Type GetTargetType();

		// Token: 0x06012FC7 RID: 77767 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FC7")]
		[Address(RVA = "0x26209E8", Offset = "0x26209E8", VA = "0x26209E8")]
		protected ILocalizeTargetDescriptor()
		{
		}

		// Token: 0x0400EF9C RID: 61340
		[Token(Token = "0x400EF9C")]
		[FieldOffset(Offset = "0x10")]
		public string Name;

		// Token: 0x0400EF9D RID: 61341
		[Token(Token = "0x400EF9D")]
		[FieldOffset(Offset = "0x18")]
		public int Priority;
	}
}
