﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025CA RID: 9674
	[Token(Token = "0x20025CA")]
	public static class PersistentStorage
	{
		// Token: 0x06012ECF RID: 77519 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ECF")]
		[Address(RVA = "0x2451594", Offset = "0x2451594", VA = "0x2451594")]
		public static void SetSetting_String(string key, string value)
		{
		}

		// Token: 0x06012ED0 RID: 77520 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012ED0")]
		[Address(RVA = "0x2451664", Offset = "0x2451664", VA = "0x2451664")]
		public static string GetSetting_String(string key, string defaultValue)
		{
			return null;
		}

		// Token: 0x06012ED1 RID: 77521 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ED1")]
		[Address(RVA = "0x245172C", Offset = "0x245172C", VA = "0x245172C")]
		public static void DeleteSetting(string key)
		{
		}

		// Token: 0x06012ED2 RID: 77522 RVA: 0x0007A448 File Offset: 0x00078648
		[Token(Token = "0x6012ED2")]
		[Address(RVA = "0x24517E4", Offset = "0x24517E4", VA = "0x24517E4")]
		public static bool HasSetting(string key)
		{
			return default(bool);
		}

		// Token: 0x06012ED3 RID: 77523 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012ED3")]
		[Address(RVA = "0x245189C", Offset = "0x245189C", VA = "0x245189C")]
		public static void ForceSaveSettings()
		{
		}

		// Token: 0x06012ED4 RID: 77524 RVA: 0x0007A460 File Offset: 0x00078660
		[Token(Token = "0x6012ED4")]
		[Address(RVA = "0x245194C", Offset = "0x245194C", VA = "0x245194C")]
		public static bool CanAccessFiles()
		{
			return default(bool);
		}

		// Token: 0x06012ED5 RID: 77525 RVA: 0x0007A478 File Offset: 0x00078678
		[Token(Token = "0x6012ED5")]
		[Address(RVA = "0x24519FC", Offset = "0x24519FC", VA = "0x24519FC")]
		public static bool SaveFile(PersistentStorage.eFileType fileType, string fileName, string data, bool logExceptions = true)
		{
			return default(bool);
		}

		// Token: 0x06012ED6 RID: 77526 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012ED6")]
		[Address(RVA = "0x2451ADC", Offset = "0x2451ADC", VA = "0x2451ADC")]
		public static string LoadFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			return null;
		}

		// Token: 0x06012ED7 RID: 77527 RVA: 0x0007A490 File Offset: 0x00078690
		[Token(Token = "0x6012ED7")]
		[Address(RVA = "0x2451BAC", Offset = "0x2451BAC", VA = "0x2451BAC")]
		public static bool DeleteFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			return default(bool);
		}

		// Token: 0x06012ED8 RID: 77528 RVA: 0x0007A4A8 File Offset: 0x000786A8
		[Token(Token = "0x6012ED8")]
		[Address(RVA = "0x2451C7C", Offset = "0x2451C7C", VA = "0x2451C7C")]
		public static bool HasFile(PersistentStorage.eFileType fileType, string fileName, bool logExceptions = true)
		{
			return default(bool);
		}

		// Token: 0x0400EEE1 RID: 61153
		[Token(Token = "0x400EEE1")]
		[FieldOffset(Offset = "0x0")]
		private static I2CustomPersistentStorage mStorage;

		// Token: 0x020025CB RID: 9675
		[Token(Token = "0x20025CB")]
		public enum eFileType
		{
			// Token: 0x0400EEE3 RID: 61155
			[Token(Token = "0x400EEE3")]
			Raw,
			// Token: 0x0400EEE4 RID: 61156
			[Token(Token = "0x400EEE4")]
			Persistent,
			// Token: 0x0400EEE5 RID: 61157
			[Token(Token = "0x400EEE5")]
			Temporal,
			// Token: 0x0400EEE6 RID: 61158
			[Token(Token = "0x400EEE6")]
			Streaming
		}
	}
}
