﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02002611 RID: 9745
	[Token(Token = "0x2002611")]
	public interface IResourceManager_Bundles
	{
		// Token: 0x06013076 RID: 77942
		[Token(Token = "0x6013076")]
		UnityEngine.Object LoadFromBundle(string path, Type assetType);
	}
}
