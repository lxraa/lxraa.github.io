﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02002619 RID: 9753
	[Token(Token = "0x2002619")]
	public class SetLanguageDropdown : MonoBehaviour
	{
		// Token: 0x06013093 RID: 77971 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013093")]
		[Address(RVA = "0x24C364C", Offset = "0x24C364C", VA = "0x24C364C")]
		private void OnEnable()
		{
		}

		// Token: 0x06013094 RID: 77972 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013094")]
		[Address(RVA = "0x24C38A4", Offset = "0x24C38A4", VA = "0x24C38A4")]
		private void OnValueChanged(int index)
		{
		}

		// Token: 0x06013095 RID: 77973 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013095")]
		[Address(RVA = "0x24C3990", Offset = "0x24C3990", VA = "0x24C3990")]
		public SetLanguageDropdown()
		{
		}
	}
}
