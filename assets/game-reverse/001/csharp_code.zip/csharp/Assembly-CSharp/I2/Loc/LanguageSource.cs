﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025D7 RID: 9687
	[Token(Token = "0x20025D7")]
	[ExecuteInEditMode]
	public class LanguageSource : MonoBehaviour, ISerializationCallbackReceiver, ILanguageSource
	{
		// Token: 0x17002802 RID: 10242
		// (get) Token: 0x06012F05 RID: 77573 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x06012F06 RID: 77574 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002802")]
		public LanguageSourceData SourceData
		{
			[Token(Token = "0x6012F05")]
			[Address(RVA = "0x2612350", Offset = "0x2612350", VA = "0x2612350", Slot = "6")]
			get
			{
				return null;
			}
			[Token(Token = "0x6012F06")]
			[Address(RVA = "0x2612358", Offset = "0x2612358", VA = "0x2612358", Slot = "7")]
			set
			{
			}
		}

		// Token: 0x140000A5 RID: 165
		// (add) Token: 0x06012F07 RID: 77575 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x06012F08 RID: 77576 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A5")]
		public event LanguageSource.fnOnSourceUpdated Event_OnSourceUpdateFromGoogle
		{
			[Token(Token = "0x6012F07")]
			[Address(RVA = "0x2612360", Offset = "0x2612360", VA = "0x2612360")]
			add
			{
			}
			[Token(Token = "0x6012F08")]
			[Address(RVA = "0x26123FC", Offset = "0x26123FC", VA = "0x26123FC")]
			remove
			{
			}
		}

		// Token: 0x06012F09 RID: 77577 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F09")]
		[Address(RVA = "0x2612498", Offset = "0x2612498", VA = "0x2612498")]
		private void Awake()
		{
		}

		// Token: 0x06012F0A RID: 77578 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F0A")]
		[Address(RVA = "0x2612538", Offset = "0x2612538", VA = "0x2612538")]
		private void OnDestroy()
		{
		}

		// Token: 0x06012F0B RID: 77579 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012F0B")]
		[Address(RVA = "0x26125AC", Offset = "0x26125AC", VA = "0x26125AC")]
		public string GetSourceName()
		{
			return null;
		}

		// Token: 0x06012F0C RID: 77580 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F0C")]
		[Address(RVA = "0x261269C", Offset = "0x261269C", VA = "0x261269C", Slot = "4")]
		public void OnBeforeSerialize()
		{
		}

		// Token: 0x06012F0D RID: 77581 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F0D")]
		[Address(RVA = "0x26126A8", Offset = "0x26126A8", VA = "0x26126A8", Slot = "5")]
		public void OnAfterDeserialize()
		{
		}

		// Token: 0x06012F0E RID: 77582 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F0E")]
		[Address(RVA = "0x2612E2C", Offset = "0x2612E2C", VA = "0x2612E2C")]
		public LanguageSource()
		{
		}

		// Token: 0x0400EEFE RID: 61182
		[Token(Token = "0x400EEFE")]
		[FieldOffset(Offset = "0x18")]
		public LanguageSourceData mSource;

		// Token: 0x0400EEFF RID: 61183
		[Token(Token = "0x400EEFF")]
		[FieldOffset(Offset = "0x20")]
		public int version;

		// Token: 0x0400EF00 RID: 61184
		[Token(Token = "0x400EF00")]
		[FieldOffset(Offset = "0x24")]
		public bool NeverDestroy;

		// Token: 0x0400EF01 RID: 61185
		[Token(Token = "0x400EF01")]
		[FieldOffset(Offset = "0x25")]
		public bool UserAgreesToHaveItOnTheScene;

		// Token: 0x0400EF02 RID: 61186
		[Token(Token = "0x400EF02")]
		[FieldOffset(Offset = "0x26")]
		public bool UserAgreesToHaveItInsideThePluginsFolder;

		// Token: 0x0400EF03 RID: 61187
		[Token(Token = "0x400EF03")]
		[FieldOffset(Offset = "0x27")]
		public bool GoogleLiveSyncIsUptoDate;

		// Token: 0x0400EF04 RID: 61188
		[Token(Token = "0x400EF04")]
		[FieldOffset(Offset = "0x28")]
		public List<UnityEngine.Object> Assets;

		// Token: 0x0400EF05 RID: 61189
		[Token(Token = "0x400EF05")]
		[FieldOffset(Offset = "0x30")]
		public string Google_WebServiceURL;

		// Token: 0x0400EF06 RID: 61190
		[Token(Token = "0x400EF06")]
		[FieldOffset(Offset = "0x38")]
		public string Google_SpreadsheetKey;

		// Token: 0x0400EF07 RID: 61191
		[Token(Token = "0x400EF07")]
		[FieldOffset(Offset = "0x40")]
		public string Google_SpreadsheetName;

		// Token: 0x0400EF08 RID: 61192
		[Token(Token = "0x400EF08")]
		[FieldOffset(Offset = "0x48")]
		public string Google_LastUpdatedVersion;

		// Token: 0x0400EF09 RID: 61193
		[Token(Token = "0x400EF09")]
		[FieldOffset(Offset = "0x50")]
		public LanguageSourceData.eGoogleUpdateFrequency GoogleUpdateFrequency;

		// Token: 0x0400EF0A RID: 61194
		[Token(Token = "0x400EF0A")]
		[FieldOffset(Offset = "0x54")]
		public float GoogleUpdateDelay;

		// Token: 0x0400EF0C RID: 61196
		[Token(Token = "0x400EF0C")]
		[FieldOffset(Offset = "0x60")]
		public List<LanguageData> mLanguages;

		// Token: 0x0400EF0D RID: 61197
		[Token(Token = "0x400EF0D")]
		[FieldOffset(Offset = "0x68")]
		public bool IgnoreDeviceLanguage;

		// Token: 0x0400EF0E RID: 61198
		[Token(Token = "0x400EF0E")]
		[FieldOffset(Offset = "0x6C")]
		public LanguageSourceData.eAllowUnloadLanguages _AllowUnloadingLanguages;

		// Token: 0x0400EF0F RID: 61199
		[Token(Token = "0x400EF0F")]
		[FieldOffset(Offset = "0x70")]
		public List<TermData> mTerms;

		// Token: 0x0400EF10 RID: 61200
		[Token(Token = "0x400EF10")]
		[FieldOffset(Offset = "0x78")]
		public bool CaseInsensitiveTerms;

		// Token: 0x0400EF11 RID: 61201
		[Token(Token = "0x400EF11")]
		[FieldOffset(Offset = "0x7C")]
		public LanguageSourceData.MissingTranslationAction OnMissingTranslation;

		// Token: 0x0400EF12 RID: 61202
		[Token(Token = "0x400EF12")]
		[FieldOffset(Offset = "0x80")]
		public string mTerm_AppName;

		// Token: 0x020025D8 RID: 9688
		// (Invoke) Token: 0x06012F10 RID: 77584
		[Token(Token = "0x20025D8")]
		public delegate void fnOnSourceUpdated(LanguageSourceData source, bool ReceivedNewData, string errorMsg);
	}
}
