﻿using System;
using Il2CppDummyDll;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x0200261B RID: 9755
	[Token(Token = "0x200261B")]
	public class JSONNode
	{
		// Token: 0x0601309C RID: 77980 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601309C")]
		[Address(RVA = "0x24C3E6C", Offset = "0x24C3E6C", VA = "0x24C3E6C", Slot = "4")]
		public virtual void Add(string aKey, JSONNode aItem)
		{
		}

		// Token: 0x17002811 RID: 10257
		[Token(Token = "0x17002811")]
		public virtual JSONNode this[int aIndex]
		{
			[Token(Token = "0x601309D")]
			[Address(RVA = "0x24C3E70", Offset = "0x24C3E70", VA = "0x24C3E70", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002812 RID: 10258
		[Token(Token = "0x17002812")]
		public virtual JSONNode this[string aKey]
		{
			[Token(Token = "0x601309E")]
			[Address(RVA = "0x24C3E78", Offset = "0x24C3E78", VA = "0x24C3E78", Slot = "6")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002813 RID: 10259
		// (get) Token: 0x0601309F RID: 77983 RVA: 0x00002050 File Offset: 0x00000250
		// (set) Token: 0x060130A0 RID: 77984 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002813")]
		public virtual string Value
		{
			[Token(Token = "0x601309F")]
			[Address(RVA = "0x24C3E80", Offset = "0x24C3E80", VA = "0x24C3E80", Slot = "7")]
			get
			{
				return null;
			}
			[Token(Token = "0x60130A0")]
			[Address(RVA = "0x24C3EC0", Offset = "0x24C3EC0", VA = "0x24C3EC0", Slot = "8")]
			set
			{
			}
		}

		// Token: 0x17002814 RID: 10260
		// (get) Token: 0x060130A1 RID: 77985 RVA: 0x0007AF70 File Offset: 0x00079170
		[Token(Token = "0x17002814")]
		public virtual int Count
		{
			[Token(Token = "0x60130A1")]
			[Address(RVA = "0x24C3EC4", Offset = "0x24C3EC4", VA = "0x24C3EC4", Slot = "9")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060130A2 RID: 77986 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130A2")]
		[Address(RVA = "0x24C3ECC", Offset = "0x24C3ECC", VA = "0x24C3ECC", Slot = "10")]
		public virtual void Add(JSONNode aItem)
		{
		}

		// Token: 0x060130A3 RID: 77987 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130A3")]
		[Address(RVA = "0x24C3F2C", Offset = "0x24C3F2C", VA = "0x24C3F2C", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x17002815 RID: 10261
		// (get) Token: 0x060130A4 RID: 77988 RVA: 0x0007AF88 File Offset: 0x00079188
		// (set) Token: 0x060130A5 RID: 77989 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x17002815")]
		public virtual int AsInt
		{
			[Token(Token = "0x60130A4")]
			[Address(RVA = "0x24C3F6C", Offset = "0x24C3F6C", VA = "0x24C3F6C", Slot = "11")]
			get
			{
				return 0;
			}
			[Token(Token = "0x60130A5")]
			[Address(RVA = "0x24C3FA0", Offset = "0x24C3FA0", VA = "0x24C3FA0", Slot = "12")]
			set
			{
			}
		}

		// Token: 0x060130A6 RID: 77990 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130A6")]
		[Address(RVA = "0x24C3FDC", Offset = "0x24C3FDC", VA = "0x24C3FDC")]
		public static implicit operator JSONNode(string s)
		{
			return null;
		}

		// Token: 0x060130A7 RID: 77991 RVA: 0x0007AFA0 File Offset: 0x000791A0
		[Token(Token = "0x60130A7")]
		[Address(RVA = "0x24C407C", Offset = "0x24C407C", VA = "0x24C407C")]
		public static bool operator ==(JSONNode a, object b)
		{
			return default(bool);
		}

		// Token: 0x060130A8 RID: 77992 RVA: 0x0007AFB8 File Offset: 0x000791B8
		[Token(Token = "0x60130A8")]
		[Address(RVA = "0x24C4104", Offset = "0x24C4104", VA = "0x24C4104")]
		public static bool operator !=(JSONNode a, object b)
		{
			return default(bool);
		}

		// Token: 0x060130A9 RID: 77993 RVA: 0x0007AFD0 File Offset: 0x000791D0
		[Token(Token = "0x60130A9")]
		[Address(RVA = "0x24C411C", Offset = "0x24C411C", VA = "0x24C411C", Slot = "0")]
		public override bool Equals(object obj)
		{
			return default(bool);
		}

		// Token: 0x060130AA RID: 77994 RVA: 0x0007AFE8 File Offset: 0x000791E8
		[Token(Token = "0x60130AA")]
		[Address(RVA = "0x24C4128", Offset = "0x24C4128", VA = "0x24C4128", Slot = "2")]
		public override int GetHashCode()
		{
			return 0;
		}

		// Token: 0x060130AB RID: 77995 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130AB")]
		[Address(RVA = "0x24C4130", Offset = "0x24C4130", VA = "0x24C4130")]
		internal static string Escape(string aText)
		{
			return null;
		}

		// Token: 0x060130AC RID: 77996 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130AC")]
		[Address(RVA = "0x24C42FC", Offset = "0x24C42FC", VA = "0x24C42FC")]
		public static JSONNode Parse(string aJSON)
		{
			return null;
		}

		// Token: 0x060130AD RID: 77997 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130AD")]
		[Address(RVA = "0x24C4B94", Offset = "0x24C4B94", VA = "0x24C4B94")]
		public JSONNode()
		{
		}
	}
}
