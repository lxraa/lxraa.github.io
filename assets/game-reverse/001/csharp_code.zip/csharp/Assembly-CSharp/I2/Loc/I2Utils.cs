﻿using System;
using Il2CppDummyDll;
using UnityEngine.Networking;

namespace I2.Loc
{
	// Token: 0x0200260A RID: 9738
	[Token(Token = "0x200260A")]
	public static class I2Utils
	{
		// Token: 0x0601305B RID: 77915 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601305B")]
		[Address(RVA = "0x26215E0", Offset = "0x26215E0", VA = "0x26215E0")]
		public static string ReverseText(string source)
		{
			return null;
		}

		// Token: 0x0601305C RID: 77916 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601305C")]
		[Address(RVA = "0x2624D40", Offset = "0x2624D40", VA = "0x2624D40")]
		public static string RemoveNonASCII(string text, bool allowCategory = false)
		{
			return null;
		}

		// Token: 0x0601305D RID: 77917 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601305D")]
		[Address(RVA = "0x2618504", Offset = "0x2618504", VA = "0x2618504")]
		public static string GetValidTermName(string text, bool allowCategory = false)
		{
			return null;
		}

		// Token: 0x0601305E RID: 77918 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601305E")]
		[Address(RVA = "0x261E508", Offset = "0x261E508", VA = "0x261E508")]
		public static string SplitLine(string line, int maxCharacters)
		{
			return null;
		}

		// Token: 0x0601305F RID: 77919 RVA: 0x0007AE80 File Offset: 0x00079080
		[Token(Token = "0x601305F")]
		[Address(RVA = "0x261E384", Offset = "0x261E384", VA = "0x261E384")]
		public static bool FindNextTag(string line, int iStart, out int tagStart, out int tagEnd)
		{
			return default(bool);
		}

		// Token: 0x06013060 RID: 77920 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013060")]
		[Address(RVA = "0x2624F68", Offset = "0x2624F68", VA = "0x2624F68")]
		public static string RemoveTags(string text)
		{
			return null;
		}

		// Token: 0x06013061 RID: 77921 RVA: 0x0007AE98 File Offset: 0x00079098
		[Token(Token = "0x6013061")]
		[Address(RVA = "0x2616290", Offset = "0x2616290", VA = "0x2616290")]
		public static bool IsPlaying()
		{
			return default(bool);
		}

		// Token: 0x06013062 RID: 77922 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013062")]
		[Address(RVA = "0x26173FC", Offset = "0x26173FC", VA = "0x26173FC")]
		public static void SendWebRequest(UnityWebRequest www)
		{
		}

		// Token: 0x0200260B RID: 9739
		[Token(Token = "0x200260B")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06013064 RID: 77924 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013064")]
			[Address(RVA = "0x2625060", Offset = "0x2625060", VA = "0x2625060")]
			public <>c()
			{
			}

			// Token: 0x06013065 RID: 77925 RVA: 0x0007AEB0 File Offset: 0x000790B0
			[Token(Token = "0x6013065")]
			[Address(RVA = "0x2625068", Offset = "0x2625068", VA = "0x2625068")]
			internal bool <SplitLine>b__6_0(char c)
			{
				return default(bool);
			}

			// Token: 0x0400EFC4 RID: 61380
			[Token(Token = "0x400EFC4")]
			[FieldOffset(Offset = "0x0")]
			public static readonly I2Utils.<>c <>9;

			// Token: 0x0400EFC5 RID: 61381
			[Token(Token = "0x400EFC5")]
			[FieldOffset(Offset = "0x8")]
			public static Func<char, bool> <>9__6_0;
		}
	}
}
