﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x0200260C RID: 9740
	[Token(Token = "0x200260C")]
	public interface ILocalizationParamsManager
	{
		// Token: 0x06013066 RID: 77926
		[Token(Token = "0x6013066")]
		string GetParameterValue(string Param);
	}
}
