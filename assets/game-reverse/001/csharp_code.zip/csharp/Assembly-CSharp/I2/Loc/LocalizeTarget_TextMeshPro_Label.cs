﻿using System;
using Il2CppDummyDll;
using TMPro;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025F6 RID: 9718
	[Token(Token = "0x20025F6")]
	public class LocalizeTarget_TextMeshPro_Label : LocalizeTarget<TextMeshPro>
	{
		// Token: 0x06012FCF RID: 77775 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FCF")]
		[Address(RVA = "0x26209F4", Offset = "0x26209F4", VA = "0x26209F4")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x06012FD0 RID: 77776 RVA: 0x0007A8C8 File Offset: 0x00078AC8
		[Token(Token = "0x6012FD0")]
		[Address(RVA = "0x2620AB8", Offset = "0x2620AB8", VA = "0x2620AB8", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06012FD1 RID: 77777 RVA: 0x0007A8E0 File Offset: 0x00078AE0
		[Token(Token = "0x6012FD1")]
		[Address(RVA = "0x2620AC0", Offset = "0x2620AC0", VA = "0x2620AC0", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06012FD2 RID: 77778 RVA: 0x0007A8F8 File Offset: 0x00078AF8
		[Token(Token = "0x6012FD2")]
		[Address(RVA = "0x2620AC8", Offset = "0x2620AC8", VA = "0x2620AC8", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x06012FD3 RID: 77779 RVA: 0x0007A910 File Offset: 0x00078B10
		[Token(Token = "0x6012FD3")]
		[Address(RVA = "0x2620AD0", Offset = "0x2620AD0", VA = "0x2620AD0", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06012FD4 RID: 77780 RVA: 0x0007A928 File Offset: 0x00078B28
		[Token(Token = "0x6012FD4")]
		[Address(RVA = "0x2620AD8", Offset = "0x2620AD8", VA = "0x2620AD8", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06012FD5 RID: 77781 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FD5")]
		[Address(RVA = "0x2620AE0", Offset = "0x2620AE0", VA = "0x2620AE0", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06012FD6 RID: 77782 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FD6")]
		[Address(RVA = "0x2620BFC", Offset = "0x2620BFC", VA = "0x2620BFC", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06012FD7 RID: 77783 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6012FD7")]
		[Address(RVA = "0x2621190", Offset = "0x2621190", VA = "0x2621190")]
		internal static TMP_FontAsset GetTMPFontFromMaterial(Localize cmp, string matName)
		{
			return null;
		}

		// Token: 0x06012FD8 RID: 77784 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FD8")]
		[Address(RVA = "0x26213F8", Offset = "0x26213F8", VA = "0x26213F8")]
		internal static void InitAlignment_TMPro(bool isRTL, TextAlignmentOptions alignment, out TextAlignmentOptions alignLTR, out TextAlignmentOptions alignRTL)
		{
		}

		// Token: 0x06012FD9 RID: 77785 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FD9")]
		[Address(RVA = "0x26210B0", Offset = "0x26210B0", VA = "0x26210B0")]
		internal static void SetFont(TMP_Text label, TMP_FontAsset newFont)
		{
		}

		// Token: 0x06012FDA RID: 77786 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FDA")]
		[Address(RVA = "0x26212F8", Offset = "0x26212F8", VA = "0x26212F8")]
		internal static void SetMaterial(TMP_Text label, Material newMat)
		{
		}

		// Token: 0x06012FDB RID: 77787 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FDB")]
		[Address(RVA = "0x262169C", Offset = "0x262169C", VA = "0x262169C")]
		public LocalizeTarget_TextMeshPro_Label()
		{
		}

		// Token: 0x0400EF9E RID: 61342
		[Token(Token = "0x400EF9E")]
		[FieldOffset(Offset = "0x20")]
		private TextAlignmentOptions mAlignment_RTL;

		// Token: 0x0400EF9F RID: 61343
		[Token(Token = "0x400EF9F")]
		[FieldOffset(Offset = "0x24")]
		private TextAlignmentOptions mAlignment_LTR;

		// Token: 0x0400EFA0 RID: 61344
		[Token(Token = "0x400EFA0")]
		[FieldOffset(Offset = "0x28")]
		private bool mAlignmentWasRTL;

		// Token: 0x0400EFA1 RID: 61345
		[Token(Token = "0x400EFA1")]
		[FieldOffset(Offset = "0x29")]
		private bool mInitializeAlignment;
	}
}
