﻿using System;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.UI;

namespace I2.Loc
{
	// Token: 0x02002601 RID: 9729
	[Token(Token = "0x2002601")]
	public class LocalizeTarget_UnityUI_RawImage : LocalizeTarget<RawImage>
	{
		// Token: 0x06013034 RID: 77876 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013034")]
		[Address(RVA = "0x2623BA0", Offset = "0x2623BA0", VA = "0x2623BA0")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x06013035 RID: 77877 RVA: 0x0007AD60 File Offset: 0x00078F60
		[Token(Token = "0x6013035")]
		[Address(RVA = "0x2623C64", Offset = "0x2623C64", VA = "0x2623C64", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013036 RID: 77878 RVA: 0x0007AD78 File Offset: 0x00078F78
		[Token(Token = "0x6013036")]
		[Address(RVA = "0x2623C6C", Offset = "0x2623C6C", VA = "0x2623C6C", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013037 RID: 77879 RVA: 0x0007AD90 File Offset: 0x00078F90
		[Token(Token = "0x6013037")]
		[Address(RVA = "0x2623C74", Offset = "0x2623C74", VA = "0x2623C74", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x06013038 RID: 77880 RVA: 0x0007ADA8 File Offset: 0x00078FA8
		[Token(Token = "0x6013038")]
		[Address(RVA = "0x2623C7C", Offset = "0x2623C7C", VA = "0x2623C7C", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013039 RID: 77881 RVA: 0x0007ADC0 File Offset: 0x00078FC0
		[Token(Token = "0x6013039")]
		[Address(RVA = "0x2623C84", Offset = "0x2623C84", VA = "0x2623C84", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x0601303A RID: 77882 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601303A")]
		[Address(RVA = "0x2623C8C", Offset = "0x2623C8C", VA = "0x2623C8C", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x0601303B RID: 77883 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601303B")]
		[Address(RVA = "0x2623D7C", Offset = "0x2623D7C", VA = "0x2623D7C", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x0601303C RID: 77884 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601303C")]
		[Address(RVA = "0x2623E6C", Offset = "0x2623E6C", VA = "0x2623E6C")]
		public LocalizeTarget_UnityUI_RawImage()
		{
		}
	}
}
