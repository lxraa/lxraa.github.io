﻿using System;
using System.Collections.Generic;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025E7 RID: 9703
	[Token(Token = "0x20025E7")]
	public class LocalizeDropdown : MonoBehaviour
	{
		// Token: 0x06012F6A RID: 77674 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F6A")]
		[Address(RVA = "0x261B218", Offset = "0x261B218", VA = "0x261B218")]
		public void Start()
		{
		}

		// Token: 0x06012F6B RID: 77675 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F6B")]
		[Address(RVA = "0x261B550", Offset = "0x261B550", VA = "0x261B550")]
		public void OnDestroy()
		{
		}

		// Token: 0x06012F6C RID: 77676 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F6C")]
		[Address(RVA = "0x261B6C8", Offset = "0x261B6C8", VA = "0x261B6C8")]
		private void OnEnable()
		{
		}

		// Token: 0x06012F6D RID: 77677 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F6D")]
		[Address(RVA = "0x261B464", Offset = "0x261B464", VA = "0x261B464")]
		public void OnLocalize()
		{
		}

		// Token: 0x06012F6E RID: 77678 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F6E")]
		[Address(RVA = "0x261B720", Offset = "0x261B720", VA = "0x261B720")]
		private void FillValues()
		{
		}

		// Token: 0x06012F6F RID: 77679 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F6F")]
		[Address(RVA = "0x261B984", Offset = "0x261B984", VA = "0x261B984")]
		public void UpdateLocalization()
		{
		}

		// Token: 0x06012F70 RID: 77680 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F70")]
		[Address(RVA = "0x261BEFC", Offset = "0x261BEFC", VA = "0x261BEFC")]
		public void UpdateLocalizationTMPro()
		{
		}

		// Token: 0x06012F71 RID: 77681 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F71")]
		[Address(RVA = "0x261BCB0", Offset = "0x261BCB0", VA = "0x261BCB0")]
		private void FillValuesTMPro()
		{
		}

		// Token: 0x06012F72 RID: 77682 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012F72")]
		[Address(RVA = "0x261C21C", Offset = "0x261C21C", VA = "0x261C21C")]
		public LocalizeDropdown()
		{
		}

		// Token: 0x0400EF7D RID: 61309
		[Token(Token = "0x400EF7D")]
		[FieldOffset(Offset = "0x18")]
		public List<string> _Terms;
	}
}
