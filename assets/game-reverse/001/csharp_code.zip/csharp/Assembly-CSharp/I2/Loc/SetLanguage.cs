﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02002618 RID: 9752
	[Token(Token = "0x2002618")]
	public class SetLanguage : MonoBehaviour
	{
		// Token: 0x06013090 RID: 77968 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013090")]
		[Address(RVA = "0x24C35A8", Offset = "0x24C35A8", VA = "0x24C35A8")]
		private void OnClick()
		{
		}

		// Token: 0x06013091 RID: 77969 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013091")]
		[Address(RVA = "0x24C35AC", Offset = "0x24C35AC", VA = "0x24C35AC")]
		public void ApplyLanguage()
		{
		}

		// Token: 0x06013092 RID: 77970 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013092")]
		[Address(RVA = "0x24C3644", Offset = "0x24C3644", VA = "0x24C3644")]
		public SetLanguage()
		{
		}

		// Token: 0x0400EFDB RID: 61403
		[Token(Token = "0x400EFDB")]
		[FieldOffset(Offset = "0x18")]
		public string _Language;
	}
}
