﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x0200261A RID: 9754
	[Token(Token = "0x200261A")]
	public class StringObfucator
	{
		// Token: 0x06013096 RID: 77974 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013096")]
		[Address(RVA = "0x24C3998", Offset = "0x24C3998", VA = "0x24C3998")]
		public static string Encode(string NormalString)
		{
			return null;
		}

		// Token: 0x06013097 RID: 77975 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013097")]
		[Address(RVA = "0x24C3C8C", Offset = "0x24C3C8C", VA = "0x24C3C8C")]
		public static string Decode(string ObfucatedString)
		{
			return null;
		}

		// Token: 0x06013098 RID: 77976 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013098")]
		[Address(RVA = "0x24C3C08", Offset = "0x24C3C08", VA = "0x24C3C08")]
		private static string ToBase64(string regularString)
		{
			return null;
		}

		// Token: 0x06013099 RID: 77977 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013099")]
		[Address(RVA = "0x24C3D64", Offset = "0x24C3D64", VA = "0x24C3D64")]
		private static string FromBase64(string base64string)
		{
			return null;
		}

		// Token: 0x0601309A RID: 77978 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601309A")]
		[Address(RVA = "0x24C3A70", Offset = "0x24C3A70", VA = "0x24C3A70")]
		private static string XoREncode(string NormalString)
		{
			return null;
		}

		// Token: 0x0400EFDC RID: 61404
		[Token(Token = "0x400EFDC")]
		[FieldOffset(Offset = "0x0")]
		public static char[] StringObfuscatorPassword;
	}
}
