﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025FB RID: 9723
	[Token(Token = "0x20025FB")]
	public class LocalizeTarget_UnityStandard_MeshRenderer : LocalizeTarget<MeshRenderer>
	{
		// Token: 0x06012FFE RID: 77822 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012FFE")]
		[Address(RVA = "0x2622504", Offset = "0x2622504", VA = "0x2622504")]
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void AutoRegister()
		{
		}

		// Token: 0x06012FFF RID: 77823 RVA: 0x0007AAD8 File Offset: 0x00078CD8
		[Token(Token = "0x6012FFF")]
		[Address(RVA = "0x26225C8", Offset = "0x26225C8", VA = "0x26225C8", Slot = "10")]
		public override eTermType GetPrimaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013000 RID: 77824 RVA: 0x0007AAF0 File Offset: 0x00078CF0
		[Token(Token = "0x6013000")]
		[Address(RVA = "0x26225D0", Offset = "0x26225D0", VA = "0x26225D0", Slot = "11")]
		public override eTermType GetSecondaryTermType(Localize cmp)
		{
			return eTermType.Text;
		}

		// Token: 0x06013001 RID: 77825 RVA: 0x0007AB08 File Offset: 0x00078D08
		[Token(Token = "0x6013001")]
		[Address(RVA = "0x26225D8", Offset = "0x26225D8", VA = "0x26225D8", Slot = "7")]
		public override bool CanUseSecondaryTerm()
		{
			return default(bool);
		}

		// Token: 0x06013002 RID: 77826 RVA: 0x0007AB20 File Offset: 0x00078D20
		[Token(Token = "0x6013002")]
		[Address(RVA = "0x26225E0", Offset = "0x26225E0", VA = "0x26225E0", Slot = "8")]
		public override bool AllowMainTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013003 RID: 77827 RVA: 0x0007AB38 File Offset: 0x00078D38
		[Token(Token = "0x6013003")]
		[Address(RVA = "0x26225E8", Offset = "0x26225E8", VA = "0x26225E8", Slot = "9")]
		public override bool AllowSecondTermToBeRTL()
		{
			return default(bool);
		}

		// Token: 0x06013004 RID: 77828 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013004")]
		[Address(RVA = "0x26225F0", Offset = "0x26225F0", VA = "0x26225F0", Slot = "5")]
		public override void GetFinalTerms(Localize cmp, string Main, string Secondary, out string primaryTerm, out string secondaryTerm)
		{
		}

		// Token: 0x06013005 RID: 77829 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013005")]
		[Address(RVA = "0x26227E8", Offset = "0x26227E8", VA = "0x26227E8", Slot = "6")]
		public override void DoLocalize(Localize cmp, string mainTranslation, string secondaryTranslation)
		{
		}

		// Token: 0x06013006 RID: 77830 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013006")]
		[Address(RVA = "0x26229B4", Offset = "0x26229B4", VA = "0x26229B4")]
		public LocalizeTarget_UnityStandard_MeshRenderer()
		{
		}
	}
}
