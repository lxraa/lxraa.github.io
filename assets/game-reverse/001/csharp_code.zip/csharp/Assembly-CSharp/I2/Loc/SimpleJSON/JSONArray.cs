﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Il2CppDummyDll;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x0200261C RID: 9756
	[Token(Token = "0x200261C")]
	public class JSONArray : JSONNode, IEnumerable
	{
		// Token: 0x17002816 RID: 10262
		[Token(Token = "0x17002816")]
		public override JSONNode this[int aIndex]
		{
			[Token(Token = "0x60130AE")]
			[Address(RVA = "0x24C4B9C", Offset = "0x24C4B9C", VA = "0x24C4B9C", Slot = "5")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002817 RID: 10263
		[Token(Token = "0x17002817")]
		public override JSONNode this[string aKey]
		{
			[Token(Token = "0x60130AF")]
			[Address(RVA = "0x24C4C8C", Offset = "0x24C4C8C", VA = "0x24C4C8C", Slot = "6")]
			get
			{
				return null;
			}
		}

		// Token: 0x17002818 RID: 10264
		// (get) Token: 0x060130B0 RID: 78000 RVA: 0x0007B000 File Offset: 0x00079200
		[Token(Token = "0x17002818")]
		public override int Count
		{
			[Token(Token = "0x60130B0")]
			[Address(RVA = "0x24C4CEC", Offset = "0x24C4CEC", VA = "0x24C4CEC", Slot = "9")]
			get
			{
				return 0;
			}
		}

		// Token: 0x060130B1 RID: 78001 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130B1")]
		[Address(RVA = "0x24C4D34", Offset = "0x24C4D34", VA = "0x24C4D34", Slot = "4")]
		public override void Add(string aKey, JSONNode aItem)
		{
		}

		// Token: 0x060130B2 RID: 78002 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130B2")]
		[Address(RVA = "0x24C4DE4", Offset = "0x24C4DE4", VA = "0x24C4DE4", Slot = "13")]
		public IEnumerator GetEnumerator()
		{
			return null;
		}

		// Token: 0x060130B3 RID: 78003 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130B3")]
		[Address(RVA = "0x24C4E80", Offset = "0x24C4E80", VA = "0x24C4E80", Slot = "3")]
		public override string ToString()
		{
			return null;
		}

		// Token: 0x060130B4 RID: 78004 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x60130B4")]
		[Address(RVA = "0x24C4B0C", Offset = "0x24C4B0C", VA = "0x24C4B0C")]
		public JSONArray()
		{
		}

		// Token: 0x0400EFDD RID: 61405
		[Token(Token = "0x400EFDD")]
		[FieldOffset(Offset = "0x10")]
		private List<JSONNode> m_List;

		// Token: 0x0200261D RID: 9757
		[Token(Token = "0x200261D")]
		private sealed class <GetEnumerator>d__14 : IEnumerator<object>, IEnumerator, IDisposable
		{
			// Token: 0x060130B5 RID: 78005 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130B5")]
			[Address(RVA = "0x24C4E58", Offset = "0x24C4E58", VA = "0x24C4E58")]
			[DebuggerHidden]
			public <GetEnumerator>d__14(int <>1__state)
			{
			}

			// Token: 0x060130B6 RID: 78006 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130B6")]
			[Address(RVA = "0x24C5098", Offset = "0x24C5098", VA = "0x24C5098", Slot = "5")]
			[DebuggerHidden]
			private void Dispose()
			{
			}

			// Token: 0x060130B7 RID: 78007 RVA: 0x0007B018 File Offset: 0x00079218
			[Token(Token = "0x60130B7")]
			[Address(RVA = "0x24C50B4", Offset = "0x24C50B4", VA = "0x24C50B4", Slot = "6")]
			private bool MoveNext()
			{
				return default(bool);
			}

			// Token: 0x060130B8 RID: 78008 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130B8")]
			[Address(RVA = "0x24C525C", Offset = "0x24C525C", VA = "0x24C525C")]
			private void <>m__Finally1()
			{
			}

			// Token: 0x17002819 RID: 10265
			// (get) Token: 0x060130B9 RID: 78009 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x17002819")]
			private object Current
			{
				[Token(Token = "0x60130B9")]
				[Address(RVA = "0x24C52AC", Offset = "0x24C52AC", VA = "0x24C52AC", Slot = "4")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x060130BA RID: 78010 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60130BA")]
			[Address(RVA = "0x24C52B4", Offset = "0x24C52B4", VA = "0x24C52B4", Slot = "8")]
			[DebuggerHidden]
			private void Reset()
			{
			}

			// Token: 0x1700281A RID: 10266
			// (get) Token: 0x060130BB RID: 78011 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x1700281A")]
			private object Current
			{
				[Token(Token = "0x60130BB")]
				[Address(RVA = "0x24C52F4", Offset = "0x24C52F4", VA = "0x24C52F4", Slot = "7")]
				[DebuggerHidden]
				get
				{
					return null;
				}
			}

			// Token: 0x0400EFDE RID: 61406
			[Token(Token = "0x400EFDE")]
			[FieldOffset(Offset = "0x10")]
			private int <>1__state;

			// Token: 0x0400EFDF RID: 61407
			[Token(Token = "0x400EFDF")]
			[FieldOffset(Offset = "0x18")]
			private object <>2__current;

			// Token: 0x0400EFE0 RID: 61408
			[Token(Token = "0x400EFE0")]
			[FieldOffset(Offset = "0x20")]
			public JSONArray <>4__this;

			// Token: 0x0400EFE1 RID: 61409
			[Token(Token = "0x400EFE1")]
			[FieldOffset(Offset = "0x28")]
			private List<JSONNode>.Enumerator <>7__wrap1;
		}
	}
}
