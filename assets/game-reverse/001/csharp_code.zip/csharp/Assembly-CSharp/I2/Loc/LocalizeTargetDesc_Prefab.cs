﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025FC RID: 9724
	[Token(Token = "0x20025FC")]
	public class LocalizeTargetDesc_Prefab : LocalizeTargetDesc<LocalizeTarget_UnityStandard_Prefab>
	{
		// Token: 0x06013007 RID: 77831 RVA: 0x0007AB50 File Offset: 0x00078D50
		[Token(Token = "0x6013007")]
		[Address(RVA = "0x26229FC", Offset = "0x26229FC", VA = "0x26229FC", Slot = "4")]
		public override bool CanLocalize(Localize cmp)
		{
			return default(bool);
		}

		// Token: 0x06013008 RID: 77832 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013008")]
		[Address(RVA = "0x2622A04", Offset = "0x2622A04", VA = "0x2622A04")]
		public LocalizeTargetDesc_Prefab()
		{
		}
	}
}
