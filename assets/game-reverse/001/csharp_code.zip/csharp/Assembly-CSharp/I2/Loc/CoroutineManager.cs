﻿using System;
using System.Collections;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x02002606 RID: 9734
	[Token(Token = "0x2002606")]
	public class CoroutineManager : MonoBehaviour
	{
		// Token: 0x1700280E RID: 10254
		// (get) Token: 0x0601304F RID: 77903 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x1700280E")]
		private static CoroutineManager pInstance
		{
			[Token(Token = "0x601304F")]
			[Address(RVA = "0x26244E0", Offset = "0x26244E0", VA = "0x26244E0")]
			get
			{
				return null;
			}
		}

		// Token: 0x06013050 RID: 77904 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013050")]
		[Address(RVA = "0x2624630", Offset = "0x2624630", VA = "0x2624630")]
		private void Awake()
		{
		}

		// Token: 0x06013051 RID: 77905 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013051")]
		[Address(RVA = "0x2616E08", Offset = "0x2616E08", VA = "0x2616E08")]
		public static Coroutine Start(IEnumerator coroutine)
		{
			return null;
		}

		// Token: 0x06013052 RID: 77906 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013052")]
		[Address(RVA = "0x26246B4", Offset = "0x26246B4", VA = "0x26246B4")]
		public CoroutineManager()
		{
		}

		// Token: 0x0400EFC0 RID: 61376
		[Token(Token = "0x400EFC0")]
		[FieldOffset(Offset = "0x0")]
		private static CoroutineManager mInstance;
	}
}
