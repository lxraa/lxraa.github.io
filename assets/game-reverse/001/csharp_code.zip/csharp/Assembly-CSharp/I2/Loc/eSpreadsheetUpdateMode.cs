﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x020025E2 RID: 9698
	[Token(Token = "0x20025E2")]
	public enum eSpreadsheetUpdateMode
	{
		// Token: 0x0400EF4F RID: 61263
		[Token(Token = "0x400EF4F")]
		None,
		// Token: 0x0400EF50 RID: 61264
		[Token(Token = "0x400EF50")]
		Replace,
		// Token: 0x0400EF51 RID: 61265
		[Token(Token = "0x400EF51")]
		Merge,
		// Token: 0x0400EF52 RID: 61266
		[Token(Token = "0x400EF52")]
		AddNewTerms
	}
}
