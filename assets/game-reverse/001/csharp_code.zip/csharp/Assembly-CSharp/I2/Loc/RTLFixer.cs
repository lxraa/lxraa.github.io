﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x02002613 RID: 9747
	[Token(Token = "0x2002613")]
	public class RTLFixer
	{
		// Token: 0x06013080 RID: 77952 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013080")]
		[Address(RVA = "0x2625C30", Offset = "0x2625C30", VA = "0x2625C30")]
		public static string Fix(string str)
		{
			return null;
		}

		// Token: 0x06013081 RID: 77953 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013081")]
		[Address(RVA = "0x2625C3C", Offset = "0x2625C3C", VA = "0x2625C3C")]
		public static string Fix(string str, bool rtl)
		{
			return null;
		}

		// Token: 0x06013082 RID: 77954 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013082")]
		[Address(RVA = "0x261E7AC", Offset = "0x261E7AC", VA = "0x261E7AC")]
		public static string Fix(string str, bool showTashkeel, bool useHinduNumbers)
		{
			return null;
		}
	}
}
