﻿using System;
using Il2CppDummyDll;

namespace I2.Loc.SimpleJSON
{
	// Token: 0x02002622 RID: 9762
	[Token(Token = "0x2002622")]
	public static class JSON
	{
		// Token: 0x060130DB RID: 78043 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60130DB")]
		[Address(RVA = "0x24C61C0", Offset = "0x24C61C0", VA = "0x24C61C0")]
		public static JSONNode Parse(string aJSON)
		{
			return null;
		}
	}
}
