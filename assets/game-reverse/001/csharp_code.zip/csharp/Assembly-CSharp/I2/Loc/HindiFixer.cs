﻿using System;
using Il2CppDummyDll;

namespace I2.Loc
{
	// Token: 0x02002608 RID: 9736
	[Token(Token = "0x2002608")]
	public class HindiFixer
	{
		// Token: 0x06013057 RID: 77911 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013057")]
		[Address(RVA = "0x26248B0", Offset = "0x26248B0", VA = "0x26248B0")]
		internal static string Fix(string text)
		{
			return null;
		}

		// Token: 0x02002609 RID: 9737
		[Token(Token = "0x2002609")]
		[Serializable]
		private sealed class <>c
		{
			// Token: 0x06013059 RID: 77913 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013059")]
			[Address(RVA = "0x2624D2C", Offset = "0x2624D2C", VA = "0x2624D2C")]
			public <>c()
			{
			}

			// Token: 0x0601305A RID: 77914 RVA: 0x0007AE68 File Offset: 0x00079068
			[Token(Token = "0x601305A")]
			[Address(RVA = "0x2624D34", Offset = "0x2624D34", VA = "0x2624D34")]
			internal bool <Fix>b__0_0(char x)
			{
				return default(bool);
			}

			// Token: 0x0400EFC2 RID: 61378
			[Token(Token = "0x400EFC2")]
			[FieldOffset(Offset = "0x0")]
			public static readonly HindiFixer.<>c <>9;

			// Token: 0x0400EFC3 RID: 61379
			[Token(Token = "0x400EFC3")]
			[FieldOffset(Offset = "0x8")]
			public static Func<char, bool> <>9__0_0;
		}
	}
}
