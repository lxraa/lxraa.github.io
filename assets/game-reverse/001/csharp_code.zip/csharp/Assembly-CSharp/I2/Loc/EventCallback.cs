﻿using System;
using System.Runtime.InteropServices;
using Il2CppDummyDll;
using UnityEngine;

namespace I2.Loc
{
	// Token: 0x020025D0 RID: 9680
	[Token(Token = "0x20025D0")]
	[Serializable]
	public class EventCallback
	{
		// Token: 0x06012EF0 RID: 77552 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EF0")]
		[Address(RVA = "0x2453BB8", Offset = "0x2453BB8", VA = "0x2453BB8")]
		public void Execute([Optional] UnityEngine.Object Sender)
		{
		}

		// Token: 0x06012EF1 RID: 77553 RVA: 0x0007A538 File Offset: 0x00078738
		[Token(Token = "0x6012EF1")]
		[Address(RVA = "0x2453C1C", Offset = "0x2453C1C", VA = "0x2453C1C")]
		public bool HasCallback()
		{
			return default(bool);
		}

		// Token: 0x06012EF2 RID: 77554 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6012EF2")]
		[Address(RVA = "0x2453CA0", Offset = "0x2453CA0", VA = "0x2453CA0")]
		public EventCallback()
		{
		}

		// Token: 0x0400EEEA RID: 61162
		[Token(Token = "0x400EEEA")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
		public MonoBehaviour Target;

		// Token: 0x0400EEEB RID: 61163
		[Token(Token = "0x400EEEB")]
		[Il2CppDummyDll.FieldOffset(Offset = "0x18")]
		public string MethodName;
	}
}
