﻿using System;
using Il2CppDummyDll;
using Royal.Scenes.Game.Mechanics.Board.Cell;
using Royal.Scenes.Game.Mechanics.Items.StaticItems.GrassItem.View;

// Token: 0x02000006 RID: 6
[Token(Token = "0x2000006")]
public struct GrassViewData
{
	// Token: 0x06000012 RID: 18 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x6000012")]
	[Address(RVA = "0x124697C", Offset = "0x124697C", VA = "0x124697C")]
	public void Init(GrassItemAssets itemAssets, CellPoint point, int layer)
	{
	}

	// Token: 0x04000016 RID: 22
	[Token(Token = "0x4000016")]
	[FieldOffset(Offset = "0x0")]
	public GrassSpriteData baseData;

	// Token: 0x04000017 RID: 23
	[Token(Token = "0x4000017")]
	[FieldOffset(Offset = "0x28")]
	public GrassSpriteData patchData;

	// Token: 0x04000018 RID: 24
	[Token(Token = "0x4000018")]
	[FieldOffset(Offset = "0x50")]
	public GrassSpriteData shadowData;
}
