﻿using System;
using System.Configuration.Assemblies;
using System.Reflection;

[assembly: AssemblyAlgorithmId(AssemblyHashAlgorithm.None)]
[assembly: AssemblyVersion("0.0.0.0")]
