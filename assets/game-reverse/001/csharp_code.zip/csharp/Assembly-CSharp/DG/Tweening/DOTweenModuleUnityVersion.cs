﻿using System;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Il2CppDummyDll;
using UnityEngine;

namespace DG.Tweening
{
	// Token: 0x02002675 RID: 9845
	[Token(Token = "0x2002675")]
	public static class DOTweenModuleUnityVersion
	{
		// Token: 0x06013201 RID: 78337 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013201")]
		[Address(RVA = "0x24D6974", Offset = "0x24D6974", VA = "0x24D6974")]
		public static TweenerCore<Vector2, Vector2, VectorOptions> DOOffset(Material target, Vector2 endValue, int propertyID, float duration)
		{
			return null;
		}

		// Token: 0x02002676 RID: 9846
		[Token(Token = "0x2002676")]
		private sealed class <>c__DisplayClass8_0
		{
			// Token: 0x06013202 RID: 78338 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013202")]
			[Address(RVA = "0x24D6B78", Offset = "0x24D6B78", VA = "0x24D6B78")]
			public <>c__DisplayClass8_0()
			{
			}

			// Token: 0x06013203 RID: 78339 RVA: 0x0007B438 File Offset: 0x00079638
			[Token(Token = "0x6013203")]
			[Address(RVA = "0x24D6B80", Offset = "0x24D6B80", VA = "0x24D6B80")]
			internal Vector2 <DOOffset>b__0()
			{
				return default(Vector2);
			}

			// Token: 0x06013204 RID: 78340 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013204")]
			[Address(RVA = "0x24D6BA4", Offset = "0x24D6BA4", VA = "0x24D6BA4")]
			internal void <DOOffset>b__1(Vector2 x)
			{
			}

			// Token: 0x0400F0E6 RID: 61670
			[Token(Token = "0x400F0E6")]
			[FieldOffset(Offset = "0x10")]
			public Material target;

			// Token: 0x0400F0E7 RID: 61671
			[Token(Token = "0x400F0E7")]
			[FieldOffset(Offset = "0x18")]
			public int propertyID;
		}
	}
}
