﻿using System;
using System.Runtime.InteropServices;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Il2CppDummyDll;
using TMPro;
using UnityEngine;

namespace DG.Tweening
{
	// Token: 0x0200267E RID: 9854
	[Token(Token = "0x200267E")]
	public static class ShortcutExtensionsTMPText
	{
		// Token: 0x06013231 RID: 78385 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013231")]
		[Address(RVA = "0x24D836C", Offset = "0x24D836C", VA = "0x24D836C")]
		public static TweenerCore<Color, Color, ColorOptions> DOColor(TMP_Text target, Color endValue, float duration)
		{
			return null;
		}

		// Token: 0x06013232 RID: 78386 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013232")]
		[Address(RVA = "0x24D8518", Offset = "0x24D8518", VA = "0x24D8518")]
		public static TweenerCore<Color, Color, ColorOptions> DOFade(TMP_Text target, float endValue, float duration)
		{
			return null;
		}

		// Token: 0x06013233 RID: 78387 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013233")]
		[Address(RVA = "0x24D9910", Offset = "0x24D9910", VA = "0x24D9910")]
		public static TweenerCore<Vector3, Vector3, VectorOptions> DOScale(TMP_Text target, float endValue, float duration)
		{
			return null;
		}

		// Token: 0x06013234 RID: 78388 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x6013234")]
		[Address(RVA = "0x24D869C", Offset = "0x24D869C", VA = "0x24D869C")]
		public static TweenerCore<string, string, StringOptions> DOText(TMP_Text target, string endValue, float duration, bool richTextEnabled = true, ScrambleMode scrambleMode = ScrambleMode.None, [Optional] string scrambleChars)
		{
			return null;
		}

		// Token: 0x0200267F RID: 9855
		[Token(Token = "0x200267F")]
		private sealed class <>c__DisplayClass0_0
		{
			// Token: 0x06013235 RID: 78389 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013235")]
			[Address(RVA = "0x24D9900", Offset = "0x24D9900", VA = "0x24D9900")]
			public <>c__DisplayClass0_0()
			{
			}

			// Token: 0x06013236 RID: 78390 RVA: 0x0007B498 File Offset: 0x00079698
			[Token(Token = "0x6013236")]
			[Address(RVA = "0x24D9AB8", Offset = "0x24D9AB8", VA = "0x24D9AB8")]
			internal Color <DOColor>b__0()
			{
				return default(Color);
			}

			// Token: 0x06013237 RID: 78391 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013237")]
			[Address(RVA = "0x24D9ADC", Offset = "0x24D9ADC", VA = "0x24D9ADC")]
			internal void <DOColor>b__1(Color x)
			{
			}

			// Token: 0x0400F138 RID: 61752
			[Token(Token = "0x400F138")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public TMP_Text target;
		}

		// Token: 0x02002680 RID: 9856
		[Token(Token = "0x2002680")]
		private sealed class <>c__DisplayClass4_0
		{
			// Token: 0x06013238 RID: 78392 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013238")]
			[Address(RVA = "0x24D9908", Offset = "0x24D9908", VA = "0x24D9908")]
			public <>c__DisplayClass4_0()
			{
			}

			// Token: 0x06013239 RID: 78393 RVA: 0x0007B4B0 File Offset: 0x000796B0
			[Token(Token = "0x6013239")]
			[Address(RVA = "0x24D9B00", Offset = "0x24D9B00", VA = "0x24D9B00")]
			internal Color <DOFade>b__0()
			{
				return default(Color);
			}

			// Token: 0x0601323A RID: 78394 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601323A")]
			[Address(RVA = "0x24D9B24", Offset = "0x24D9B24", VA = "0x24D9B24")]
			internal void <DOFade>b__1(Color x)
			{
			}

			// Token: 0x0400F139 RID: 61753
			[Token(Token = "0x400F139")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public TMP_Text target;
		}

		// Token: 0x02002681 RID: 9857
		[Token(Token = "0x2002681")]
		private sealed class <>c__DisplayClass6_0
		{
			// Token: 0x0601323B RID: 78395 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601323B")]
			[Address(RVA = "0x24D9AA8", Offset = "0x24D9AA8", VA = "0x24D9AA8")]
			public <>c__DisplayClass6_0()
			{
			}

			// Token: 0x0601323C RID: 78396 RVA: 0x0007B4C8 File Offset: 0x000796C8
			[Token(Token = "0x601323C")]
			[Address(RVA = "0x24D9B48", Offset = "0x24D9B48", VA = "0x24D9B48")]
			internal Vector3 <DOScale>b__0()
			{
				return default(Vector3);
			}

			// Token: 0x0601323D RID: 78397 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601323D")]
			[Address(RVA = "0x24D9B64", Offset = "0x24D9B64", VA = "0x24D9B64")]
			internal void <DOScale>b__1(Vector3 x)
			{
			}

			// Token: 0x0400F13A RID: 61754
			[Token(Token = "0x400F13A")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public Transform trans;
		}

		// Token: 0x02002682 RID: 9858
		[Token(Token = "0x2002682")]
		private sealed class <>c__DisplayClass9_0
		{
			// Token: 0x0601323E RID: 78398 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x601323E")]
			[Address(RVA = "0x24D9AB0", Offset = "0x24D9AB0", VA = "0x24D9AB0")]
			public <>c__DisplayClass9_0()
			{
			}

			// Token: 0x0601323F RID: 78399 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x601323F")]
			[Address(RVA = "0x24D9B80", Offset = "0x24D9B80", VA = "0x24D9B80")]
			internal string <DOText>b__0()
			{
				return null;
			}

			// Token: 0x06013240 RID: 78400 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013240")]
			[Address(RVA = "0x24D9BA4", Offset = "0x24D9BA4", VA = "0x24D9BA4")]
			internal void <DOText>b__1(string x)
			{
			}

			// Token: 0x0400F13B RID: 61755
			[Token(Token = "0x400F13B")]
			[Il2CppDummyDll.FieldOffset(Offset = "0x10")]
			public TMP_Text target;
		}
	}
}
