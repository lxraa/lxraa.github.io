﻿using System;
using System.Collections.Generic;
using DG.Tweening.Core;
using Il2CppDummyDll;
using UnityEngine;

namespace DG.Tweening
{
	// Token: 0x0200267B RID: 9851
	[Token(Token = "0x200267B")]
	public class DOTweenAnimation : ABSAnimationComponent
	{
		// Token: 0x140000A8 RID: 168
		// (add) Token: 0x0601320C RID: 78348 RVA: 0x00002053 File Offset: 0x00000253
		// (remove) Token: 0x0601320D RID: 78349 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x140000A8")]
		public static event Action<DOTweenAnimation> OnReset
		{
			[Token(Token = "0x601320C")]
			[Address(RVA = "0x24D6E04", Offset = "0x24D6E04", VA = "0x24D6E04")]
			add
			{
			}
			[Token(Token = "0x601320D")]
			[Address(RVA = "0x24D6ED0", Offset = "0x24D6ED0", VA = "0x24D6ED0")]
			remove
			{
			}
		}

		// Token: 0x0601320E RID: 78350 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601320E")]
		[Address(RVA = "0x24D6F9C", Offset = "0x24D6F9C", VA = "0x24D6F9C")]
		private static void Dispatch_OnReset(DOTweenAnimation anim)
		{
		}

		// Token: 0x0601320F RID: 78351 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601320F")]
		[Address(RVA = "0x24D7008", Offset = "0x24D7008", VA = "0x24D7008")]
		private void Awake()
		{
		}

		// Token: 0x06013210 RID: 78352 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013210")]
		[Address(RVA = "0x24D8128", Offset = "0x24D8128", VA = "0x24D8128")]
		private void Start()
		{
		}

		// Token: 0x06013211 RID: 78353 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013211")]
		[Address(RVA = "0x24D8160", Offset = "0x24D8160", VA = "0x24D8160")]
		private void Reset()
		{
		}

		// Token: 0x06013212 RID: 78354 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013212")]
		[Address(RVA = "0x24D8164", Offset = "0x24D8164", VA = "0x24D8164")]
		private void OnDestroy()
		{
		}

		// Token: 0x06013213 RID: 78355 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013213")]
		[Address(RVA = "0x24D704C", Offset = "0x24D704C", VA = "0x24D704C")]
		public void CreateTween()
		{
		}

		// Token: 0x06013214 RID: 78356 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013214")]
		[Address(RVA = "0x24D8850", Offset = "0x24D8850", VA = "0x24D8850", Slot = "4")]
		public override void DOPlay()
		{
		}

		// Token: 0x06013215 RID: 78357 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013215")]
		[Address(RVA = "0x24D88BC", Offset = "0x24D88BC", VA = "0x24D88BC", Slot = "5")]
		public override void DOPlayBackwards()
		{
		}

		// Token: 0x06013216 RID: 78358 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013216")]
		[Address(RVA = "0x24D8928", Offset = "0x24D8928", VA = "0x24D8928", Slot = "6")]
		public override void DOPlayForward()
		{
		}

		// Token: 0x06013217 RID: 78359 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013217")]
		[Address(RVA = "0x24D8994", Offset = "0x24D8994", VA = "0x24D8994", Slot = "7")]
		public override void DOPause()
		{
		}

		// Token: 0x06013218 RID: 78360 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013218")]
		[Address(RVA = "0x24D8A00", Offset = "0x24D8A00", VA = "0x24D8A00", Slot = "8")]
		public override void DOTogglePause()
		{
		}

		// Token: 0x06013219 RID: 78361 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013219")]
		[Address(RVA = "0x24D8A6C", Offset = "0x24D8A6C", VA = "0x24D8A6C", Slot = "9")]
		public override void DORewind()
		{
		}

		// Token: 0x0601321A RID: 78362 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601321A")]
		[Address(RVA = "0x24D8B50", Offset = "0x24D8B50", VA = "0x24D8B50", Slot = "10")]
		public override void DORestart()
		{
		}

		// Token: 0x0601321B RID: 78363 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601321B")]
		[Address(RVA = "0x24D8B60", Offset = "0x24D8B60", VA = "0x24D8B60", Slot = "11")]
		public override void DORestart(bool fromHere)
		{
		}

		// Token: 0x0601321C RID: 78364 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601321C")]
		[Address(RVA = "0x24D8EAC", Offset = "0x24D8EAC", VA = "0x24D8EAC", Slot = "12")]
		public override void DOComplete()
		{
		}

		// Token: 0x0601321D RID: 78365 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601321D")]
		[Address(RVA = "0x24D8F1C", Offset = "0x24D8F1C", VA = "0x24D8F1C", Slot = "13")]
		public override void DOKill()
		{
		}

		// Token: 0x0601321E RID: 78366 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601321E")]
		[Address(RVA = "0x24D8F9C", Offset = "0x24D8F9C", VA = "0x24D8F9C")]
		public void DOPlayById(string id)
		{
		}

		// Token: 0x0601321F RID: 78367 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601321F")]
		[Address(RVA = "0x24D9018", Offset = "0x24D9018", VA = "0x24D9018")]
		public void DOPlayAllById(string id)
		{
		}

		// Token: 0x06013220 RID: 78368 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013220")]
		[Address(RVA = "0x24D9070", Offset = "0x24D9070", VA = "0x24D9070")]
		public void DOPauseAllById(string id)
		{
		}

		// Token: 0x06013221 RID: 78369 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013221")]
		[Address(RVA = "0x24D90C8", Offset = "0x24D90C8", VA = "0x24D90C8")]
		public void DOPlayBackwardsById(string id)
		{
		}

		// Token: 0x06013222 RID: 78370 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013222")]
		[Address(RVA = "0x24D9144", Offset = "0x24D9144", VA = "0x24D9144")]
		public void DOPlayBackwardsAllById(string id)
		{
		}

		// Token: 0x06013223 RID: 78371 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013223")]
		[Address(RVA = "0x24D919C", Offset = "0x24D919C", VA = "0x24D919C")]
		public void DOPlayForwardById(string id)
		{
		}

		// Token: 0x06013224 RID: 78372 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013224")]
		[Address(RVA = "0x24D9218", Offset = "0x24D9218", VA = "0x24D9218")]
		public void DOPlayForwardAllById(string id)
		{
		}

		// Token: 0x06013225 RID: 78373 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013225")]
		[Address(RVA = "0x24D9270", Offset = "0x24D9270", VA = "0x24D9270")]
		public void DOPlayNext()
		{
		}

		// Token: 0x06013226 RID: 78374 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013226")]
		[Address(RVA = "0x24D93A4", Offset = "0x24D93A4", VA = "0x24D93A4")]
		public void DORewindAndPlayNext()
		{
		}

		// Token: 0x06013227 RID: 78375 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013227")]
		[Address(RVA = "0x24D9424", Offset = "0x24D9424", VA = "0x24D9424")]
		public void DORewindAllById(string id)
		{
		}

		// Token: 0x06013228 RID: 78376 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013228")]
		[Address(RVA = "0x24D9494", Offset = "0x24D9494", VA = "0x24D9494")]
		public void DORestartById(string id)
		{
		}

		// Token: 0x06013229 RID: 78377 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013229")]
		[Address(RVA = "0x24D9520", Offset = "0x24D9520", VA = "0x24D9520")]
		public void DORestartAllById(string id)
		{
		}

		// Token: 0x0601322A RID: 78378 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601322A")]
		[Address(RVA = "0x24D9594", Offset = "0x24D9594", VA = "0x24D9594")]
		public List<Tween> GetTweens()
		{
			return null;
		}

		// Token: 0x0601322B RID: 78379 RVA: 0x0007B480 File Offset: 0x00079680
		[Token(Token = "0x601322B")]
		[Address(RVA = "0x24D81BC", Offset = "0x24D81BC", VA = "0x24D81BC")]
		public static DOTweenAnimation.TargetType TypeToDOTargetType(Type t)
		{
			return DOTweenAnimation.TargetType.Unset;
		}

		// Token: 0x0601322C RID: 78380 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601322C")]
		[Address(RVA = "0x24D96E0", Offset = "0x24D96E0", VA = "0x24D96E0")]
		public Tween CreateEditorPreview()
		{
			return null;
		}

		// Token: 0x0601322D RID: 78381 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x601322D")]
		[Address(RVA = "0x24D81A4", Offset = "0x24D81A4", VA = "0x24D81A4")]
		private GameObject GetTweenGO()
		{
			return null;
		}

		// Token: 0x0601322E RID: 78382 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601322E")]
		[Address(RVA = "0x24D8C58", Offset = "0x24D8C58", VA = "0x24D8C58")]
		private void ReEvaluateRelativeTween()
		{
		}

		// Token: 0x0601322F RID: 78383 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x601322F")]
		[Address(RVA = "0x24D9710", Offset = "0x24D9710", VA = "0x24D9710")]
		public DOTweenAnimation()
		{
		}

		// Token: 0x06013230 RID: 78384 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013230")]
		[Address(RVA = "0x24D98F4", Offset = "0x24D98F4", VA = "0x24D98F4")]
		private void <CreateTween>b__47_0()
		{
		}

		// Token: 0x0400F0EB RID: 61675
		[Token(Token = "0x400F0EB")]
		[FieldOffset(Offset = "0x68")]
		public bool targetIsSelf;

		// Token: 0x0400F0EC RID: 61676
		[Token(Token = "0x400F0EC")]
		[FieldOffset(Offset = "0x70")]
		public GameObject targetGO;

		// Token: 0x0400F0ED RID: 61677
		[Token(Token = "0x400F0ED")]
		[FieldOffset(Offset = "0x78")]
		public bool tweenTargetIsTargetGO;

		// Token: 0x0400F0EE RID: 61678
		[Token(Token = "0x400F0EE")]
		[FieldOffset(Offset = "0x7C")]
		public float delay;

		// Token: 0x0400F0EF RID: 61679
		[Token(Token = "0x400F0EF")]
		[FieldOffset(Offset = "0x80")]
		public float duration;

		// Token: 0x0400F0F0 RID: 61680
		[Token(Token = "0x400F0F0")]
		[FieldOffset(Offset = "0x84")]
		public Ease easeType;

		// Token: 0x0400F0F1 RID: 61681
		[Token(Token = "0x400F0F1")]
		[FieldOffset(Offset = "0x88")]
		public AnimationCurve easeCurve;

		// Token: 0x0400F0F2 RID: 61682
		[Token(Token = "0x400F0F2")]
		[FieldOffset(Offset = "0x90")]
		public LoopType loopType;

		// Token: 0x0400F0F3 RID: 61683
		[Token(Token = "0x400F0F3")]
		[FieldOffset(Offset = "0x94")]
		public int loops;

		// Token: 0x0400F0F4 RID: 61684
		[Token(Token = "0x400F0F4")]
		[FieldOffset(Offset = "0x98")]
		public string id;

		// Token: 0x0400F0F5 RID: 61685
		[Token(Token = "0x400F0F5")]
		[FieldOffset(Offset = "0xA0")]
		public bool isRelative;

		// Token: 0x0400F0F6 RID: 61686
		[Token(Token = "0x400F0F6")]
		[FieldOffset(Offset = "0xA1")]
		public bool isFrom;

		// Token: 0x0400F0F7 RID: 61687
		[Token(Token = "0x400F0F7")]
		[FieldOffset(Offset = "0xA2")]
		public bool isIndependentUpdate;

		// Token: 0x0400F0F8 RID: 61688
		[Token(Token = "0x400F0F8")]
		[FieldOffset(Offset = "0xA3")]
		public bool autoKill;

		// Token: 0x0400F0F9 RID: 61689
		[Token(Token = "0x400F0F9")]
		[FieldOffset(Offset = "0xA4")]
		public bool isActive;

		// Token: 0x0400F0FA RID: 61690
		[Token(Token = "0x400F0FA")]
		[FieldOffset(Offset = "0xA5")]
		public bool isValid;

		// Token: 0x0400F0FB RID: 61691
		[Token(Token = "0x400F0FB")]
		[FieldOffset(Offset = "0xA8")]
		public Component target;

		// Token: 0x0400F0FC RID: 61692
		[Token(Token = "0x400F0FC")]
		[FieldOffset(Offset = "0xB0")]
		public DOTweenAnimation.AnimationType animationType;

		// Token: 0x0400F0FD RID: 61693
		[Token(Token = "0x400F0FD")]
		[FieldOffset(Offset = "0xB4")]
		public DOTweenAnimation.TargetType targetType;

		// Token: 0x0400F0FE RID: 61694
		[Token(Token = "0x400F0FE")]
		[FieldOffset(Offset = "0xB8")]
		public DOTweenAnimation.TargetType forcedTargetType;

		// Token: 0x0400F0FF RID: 61695
		[Token(Token = "0x400F0FF")]
		[FieldOffset(Offset = "0xBC")]
		public bool autoPlay;

		// Token: 0x0400F100 RID: 61696
		[Token(Token = "0x400F100")]
		[FieldOffset(Offset = "0xBD")]
		public bool useTargetAsV3;

		// Token: 0x0400F101 RID: 61697
		[Token(Token = "0x400F101")]
		[FieldOffset(Offset = "0xC0")]
		public float endValueFloat;

		// Token: 0x0400F102 RID: 61698
		[Token(Token = "0x400F102")]
		[FieldOffset(Offset = "0xC4")]
		public Vector3 endValueV3;

		// Token: 0x0400F103 RID: 61699
		[Token(Token = "0x400F103")]
		[FieldOffset(Offset = "0xD0")]
		public Vector2 endValueV2;

		// Token: 0x0400F104 RID: 61700
		[Token(Token = "0x400F104")]
		[FieldOffset(Offset = "0xD8")]
		public Color endValueColor;

		// Token: 0x0400F105 RID: 61701
		[Token(Token = "0x400F105")]
		[FieldOffset(Offset = "0xE8")]
		public string endValueString;

		// Token: 0x0400F106 RID: 61702
		[Token(Token = "0x400F106")]
		[FieldOffset(Offset = "0xF0")]
		public Rect endValueRect;

		// Token: 0x0400F107 RID: 61703
		[Token(Token = "0x400F107")]
		[FieldOffset(Offset = "0x100")]
		public Transform endValueTransform;

		// Token: 0x0400F108 RID: 61704
		[Token(Token = "0x400F108")]
		[FieldOffset(Offset = "0x108")]
		public bool optionalBool0;

		// Token: 0x0400F109 RID: 61705
		[Token(Token = "0x400F109")]
		[FieldOffset(Offset = "0x10C")]
		public float optionalFloat0;

		// Token: 0x0400F10A RID: 61706
		[Token(Token = "0x400F10A")]
		[FieldOffset(Offset = "0x110")]
		public int optionalInt0;

		// Token: 0x0400F10B RID: 61707
		[Token(Token = "0x400F10B")]
		[FieldOffset(Offset = "0x114")]
		public RotateMode optionalRotationMode;

		// Token: 0x0400F10C RID: 61708
		[Token(Token = "0x400F10C")]
		[FieldOffset(Offset = "0x118")]
		public ScrambleMode optionalScrambleMode;

		// Token: 0x0400F10D RID: 61709
		[Token(Token = "0x400F10D")]
		[FieldOffset(Offset = "0x120")]
		public string optionalString;

		// Token: 0x0400F10E RID: 61710
		[Token(Token = "0x400F10E")]
		[FieldOffset(Offset = "0x128")]
		private bool _tweenCreated;

		// Token: 0x0400F10F RID: 61711
		[Token(Token = "0x400F10F")]
		[FieldOffset(Offset = "0x12C")]
		private int _playCount;

		// Token: 0x0200267C RID: 9852
		[Token(Token = "0x200267C")]
		public enum AnimationType
		{
			// Token: 0x0400F111 RID: 61713
			[Token(Token = "0x400F111")]
			None,
			// Token: 0x0400F112 RID: 61714
			[Token(Token = "0x400F112")]
			Move,
			// Token: 0x0400F113 RID: 61715
			[Token(Token = "0x400F113")]
			LocalMove,
			// Token: 0x0400F114 RID: 61716
			[Token(Token = "0x400F114")]
			Rotate,
			// Token: 0x0400F115 RID: 61717
			[Token(Token = "0x400F115")]
			LocalRotate,
			// Token: 0x0400F116 RID: 61718
			[Token(Token = "0x400F116")]
			Scale,
			// Token: 0x0400F117 RID: 61719
			[Token(Token = "0x400F117")]
			Color,
			// Token: 0x0400F118 RID: 61720
			[Token(Token = "0x400F118")]
			Fade,
			// Token: 0x0400F119 RID: 61721
			[Token(Token = "0x400F119")]
			Text,
			// Token: 0x0400F11A RID: 61722
			[Token(Token = "0x400F11A")]
			PunchPosition,
			// Token: 0x0400F11B RID: 61723
			[Token(Token = "0x400F11B")]
			PunchRotation,
			// Token: 0x0400F11C RID: 61724
			[Token(Token = "0x400F11C")]
			PunchScale,
			// Token: 0x0400F11D RID: 61725
			[Token(Token = "0x400F11D")]
			ShakePosition,
			// Token: 0x0400F11E RID: 61726
			[Token(Token = "0x400F11E")]
			ShakeRotation,
			// Token: 0x0400F11F RID: 61727
			[Token(Token = "0x400F11F")]
			ShakeScale,
			// Token: 0x0400F120 RID: 61728
			[Token(Token = "0x400F120")]
			CameraAspect,
			// Token: 0x0400F121 RID: 61729
			[Token(Token = "0x400F121")]
			CameraBackgroundColor,
			// Token: 0x0400F122 RID: 61730
			[Token(Token = "0x400F122")]
			CameraFieldOfView,
			// Token: 0x0400F123 RID: 61731
			[Token(Token = "0x400F123")]
			CameraOrthoSize,
			// Token: 0x0400F124 RID: 61732
			[Token(Token = "0x400F124")]
			CameraPixelRect,
			// Token: 0x0400F125 RID: 61733
			[Token(Token = "0x400F125")]
			CameraRect,
			// Token: 0x0400F126 RID: 61734
			[Token(Token = "0x400F126")]
			UIWidthHeight
		}

		// Token: 0x0200267D RID: 9853
		[Token(Token = "0x200267D")]
		public enum TargetType
		{
			// Token: 0x0400F128 RID: 61736
			[Token(Token = "0x400F128")]
			Unset,
			// Token: 0x0400F129 RID: 61737
			[Token(Token = "0x400F129")]
			Camera,
			// Token: 0x0400F12A RID: 61738
			[Token(Token = "0x400F12A")]
			CanvasGroup,
			// Token: 0x0400F12B RID: 61739
			[Token(Token = "0x400F12B")]
			Image,
			// Token: 0x0400F12C RID: 61740
			[Token(Token = "0x400F12C")]
			Light,
			// Token: 0x0400F12D RID: 61741
			[Token(Token = "0x400F12D")]
			RectTransform,
			// Token: 0x0400F12E RID: 61742
			[Token(Token = "0x400F12E")]
			Renderer,
			// Token: 0x0400F12F RID: 61743
			[Token(Token = "0x400F12F")]
			SpriteRenderer,
			// Token: 0x0400F130 RID: 61744
			[Token(Token = "0x400F130")]
			Rigidbody,
			// Token: 0x0400F131 RID: 61745
			[Token(Token = "0x400F131")]
			Rigidbody2D,
			// Token: 0x0400F132 RID: 61746
			[Token(Token = "0x400F132")]
			Text,
			// Token: 0x0400F133 RID: 61747
			[Token(Token = "0x400F133")]
			Transform,
			// Token: 0x0400F134 RID: 61748
			[Token(Token = "0x400F134")]
			tk2dBaseSprite,
			// Token: 0x0400F135 RID: 61749
			[Token(Token = "0x400F135")]
			tk2dTextMesh,
			// Token: 0x0400F136 RID: 61750
			[Token(Token = "0x400F136")]
			TextMeshPro,
			// Token: 0x0400F137 RID: 61751
			[Token(Token = "0x400F137")]
			TextMeshProUGUI
		}
	}
}
