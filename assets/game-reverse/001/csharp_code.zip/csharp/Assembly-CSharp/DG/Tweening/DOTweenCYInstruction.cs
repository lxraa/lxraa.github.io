﻿using System;
using Il2CppDummyDll;
using UnityEngine;

namespace DG.Tweening
{
	// Token: 0x02002677 RID: 9847
	[Token(Token = "0x2002677")]
	public static class DOTweenCYInstruction
	{
		// Token: 0x02002678 RID: 9848
		[Token(Token = "0x2002678")]
		public class WaitForCompletion : CustomYieldInstruction
		{
			// Token: 0x17002840 RID: 10304
			// (get) Token: 0x06013205 RID: 78341 RVA: 0x0007B450 File Offset: 0x00079650
			[Token(Token = "0x17002840")]
			public override bool keepWaiting
			{
				[Token(Token = "0x6013205")]
				[Address(RVA = "0x24D6BC8", Offset = "0x24D6BC8", VA = "0x24D6BC8", Slot = "7")]
				get
				{
					return default(bool);
				}
			}

			// Token: 0x06013206 RID: 78342 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013206")]
			[Address(RVA = "0x24D6BF8", Offset = "0x24D6BF8", VA = "0x24D6BF8")]
			public WaitForCompletion(Tween tween)
			{
			}

			// Token: 0x0400F0E8 RID: 61672
			[Token(Token = "0x400F0E8")]
			[FieldOffset(Offset = "0x10")]
			private readonly Tween t;
		}
	}
}
