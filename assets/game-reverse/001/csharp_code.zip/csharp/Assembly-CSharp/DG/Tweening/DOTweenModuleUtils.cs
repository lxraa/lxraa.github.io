﻿using System;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Core.PathCore;
using DG.Tweening.Plugins.Options;
using Il2CppDummyDll;
using UnityEngine;
using UnityEngine.Scripting;

namespace DG.Tweening
{
	// Token: 0x02002679 RID: 9849
	[Token(Token = "0x2002679")]
	public static class DOTweenModuleUtils
	{
		// Token: 0x06013207 RID: 78343 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013207")]
		[Address(RVA = "0x24D6C28", Offset = "0x24D6C28", VA = "0x24D6C28")]
		[Preserve]
		public static void Init()
		{
		}

		// Token: 0x06013208 RID: 78344 RVA: 0x00002053 File Offset: 0x00000253
		[Token(Token = "0x6013208")]
		[Address(RVA = "0x24D6CDC", Offset = "0x24D6CDC", VA = "0x24D6CDC")]
		[Preserve]
		private static void Preserver()
		{
		}

		// Token: 0x0400F0E9 RID: 61673
		[Token(Token = "0x400F0E9")]
		[FieldOffset(Offset = "0x0")]
		private static bool _initialized;

		// Token: 0x0200267A RID: 9850
		[Token(Token = "0x200267A")]
		public static class Physics
		{
			// Token: 0x06013209 RID: 78345 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013209")]
			[Address(RVA = "0x24D6D84", Offset = "0x24D6D84", VA = "0x24D6D84")]
			public static void SetOrientationOnPath(PathOptions options, Tween t, Quaternion newRot, Transform trans)
			{
			}

			// Token: 0x0601320A RID: 78346 RVA: 0x0007B468 File Offset: 0x00079668
			[Token(Token = "0x601320A")]
			[Address(RVA = "0x24D6D9C", Offset = "0x24D6D9C", VA = "0x24D6D9C")]
			[Preserve]
			public static bool HasRigidbody(Component target)
			{
				return default(bool);
			}

			// Token: 0x0601320B RID: 78347 RVA: 0x00002050 File Offset: 0x00000250
			[Token(Token = "0x601320B")]
			[Address(RVA = "0x24D6DA4", Offset = "0x24D6DA4", VA = "0x24D6DA4")]
			[Preserve]
			public static TweenerCore<Vector3, Path, PathOptions> CreateDOTweenPathTween(MonoBehaviour target, bool tweenRigidbody, bool isLocal, Path path, float duration, PathMode pathMode)
			{
				return null;
			}
		}
	}
}
