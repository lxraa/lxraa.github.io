﻿using System;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Il2CppDummyDll;
using UnityEngine;

namespace DG.Tweening
{
	// Token: 0x02002672 RID: 9842
	[Token(Token = "0x2002672")]
	public static class DOTweenModuleSprite
	{
		// Token: 0x060131F9 RID: 78329 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60131F9")]
		[Address(RVA = "0x24D65C4", Offset = "0x24D65C4", VA = "0x24D65C4")]
		public static TweenerCore<Color, Color, ColorOptions> DOColor(SpriteRenderer target, Color endValue, float duration)
		{
			return null;
		}

		// Token: 0x060131FA RID: 78330 RVA: 0x00002050 File Offset: 0x00000250
		[Token(Token = "0x60131FA")]
		[Address(RVA = "0x24D6778", Offset = "0x24D6778", VA = "0x24D6778")]
		public static TweenerCore<Color, Color, ColorOptions> DOFade(SpriteRenderer target, float endValue, float duration)
		{
			return null;
		}

		// Token: 0x02002673 RID: 9843
		[Token(Token = "0x2002673")]
		private sealed class <>c__DisplayClass0_0
		{
			// Token: 0x060131FB RID: 78331 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60131FB")]
			[Address(RVA = "0x24D6770", Offset = "0x24D6770", VA = "0x24D6770")]
			public <>c__DisplayClass0_0()
			{
			}

			// Token: 0x060131FC RID: 78332 RVA: 0x0007B408 File Offset: 0x00079608
			[Token(Token = "0x60131FC")]
			[Address(RVA = "0x24D6904", Offset = "0x24D6904", VA = "0x24D6904")]
			internal Color <DOColor>b__0()
			{
				return default(Color);
			}

			// Token: 0x060131FD RID: 78333 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60131FD")]
			[Address(RVA = "0x24D6920", Offset = "0x24D6920", VA = "0x24D6920")]
			internal void <DOColor>b__1(Color x)
			{
			}

			// Token: 0x0400F0E4 RID: 61668
			[Token(Token = "0x400F0E4")]
			[FieldOffset(Offset = "0x10")]
			public SpriteRenderer target;
		}

		// Token: 0x02002674 RID: 9844
		[Token(Token = "0x2002674")]
		private sealed class <>c__DisplayClass1_0
		{
			// Token: 0x060131FE RID: 78334 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x60131FE")]
			[Address(RVA = "0x24D68FC", Offset = "0x24D68FC", VA = "0x24D68FC")]
			public <>c__DisplayClass1_0()
			{
			}

			// Token: 0x060131FF RID: 78335 RVA: 0x0007B420 File Offset: 0x00079620
			[Token(Token = "0x60131FF")]
			[Address(RVA = "0x24D693C", Offset = "0x24D693C", VA = "0x24D693C")]
			internal Color <DOFade>b__0()
			{
				return default(Color);
			}

			// Token: 0x06013200 RID: 78336 RVA: 0x00002053 File Offset: 0x00000253
			[Token(Token = "0x6013200")]
			[Address(RVA = "0x24D6958", Offset = "0x24D6958", VA = "0x24D6958")]
			internal void <DOFade>b__1(Color x)
			{
			}

			// Token: 0x0400F0E5 RID: 61669
			[Token(Token = "0x400F0E5")]
			[FieldOffset(Offset = "0x10")]
			public SpriteRenderer target;
		}
	}
}
