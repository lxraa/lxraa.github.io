﻿using System;
using Il2CppDummyDll;
using UnityEngine;

// Token: 0x02000005 RID: 5
[Token(Token = "0x2000005")]
[Serializable]
public class HelpshiftConfig : ScriptableObject
{
	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000010 RID: 16 RVA: 0x00002050 File Offset: 0x00000250
	[Token(Token = "0x17000003")]
	public static HelpshiftConfig Instance
	{
		[Token(Token = "0x6000010")]
		[Address(RVA = "0x12467FC", Offset = "0x12467FC", VA = "0x12467FC")]
		get
		{
			return null;
		}
	}

	// Token: 0x06000011 RID: 17 RVA: 0x00002053 File Offset: 0x00000253
	[Token(Token = "0x6000011")]
	[Address(RVA = "0x1246974", Offset = "0x1246974", VA = "0x1246974")]
	public HelpshiftConfig()
	{
	}

	// Token: 0x04000012 RID: 18
	[Token(Token = "0x4000012")]
	[FieldOffset(Offset = "0x0")]
	private static HelpshiftConfig instance;

	// Token: 0x04000013 RID: 19
	[Token(Token = "0x4000013")]
	private const string helpshiftConfigAssetName = "HelpshiftConfig";

	// Token: 0x04000014 RID: 20
	[Token(Token = "0x4000014")]
	private const string helpshiftConfigPath = "Helpshift/Resources";

	// Token: 0x04000015 RID: 21
	[Token(Token = "0x4000015")]
	public const string pluginVersion = "5.6.1";
}
